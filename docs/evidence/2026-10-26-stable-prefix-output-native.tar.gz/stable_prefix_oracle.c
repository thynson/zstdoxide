/* Test oracle only. Pinned facebook/zstd v1.5.7; never linked into Rust. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "zstd_errors.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static size_t number(char const* text, size_t limit) {
    char* end = NULL;
    errno = 0;
    unsigned long long n = strtoull(text, &end, 10);
    if (errno || !end || end == text || *end || n > limit) exit(2);
    return (size_t)n;
}
int main(int argc, char** argv) {
    if (argc != 7) return 2;
    size_t const capacity = number(argv[2], 16U * 1024U * 1024U);
    size_t const chunk = number(argv[4], 4U * 1024U * 1024U);
    if (chunk == 0 || strcmp(argv[6], "prefix")) return 2;
    FILE* f = fopen(argv[1], "rb");
    if (!f || fseek(f, 0, SEEK_END)) return 2;
    long const file_size = ftell(f);
    if (file_size < 0 || file_size > 4 * 1024 * 1024 || fseek(f, 0, SEEK_SET)) return 2;
    size_t const size = (size_t)file_size;
    unsigned char* source = malloc(size ? size : 1);
    unsigned char* storage = malloc(capacity + 64);
    if (!source || !storage || fread(source, 1, size, f) != size || fclose(f)) return 2;
    memset(storage, 0xa5, capacity + 64);
    ZSTD_DCtx* ctx = ZSTD_createDCtx();
    if (!ctx) return 2;
    size_t const initial_workspace = ZSTD_sizeof_DCtx(ctx);
    if (ZSTD_isError(ZSTD_DCtx_setParameter(ctx, ZSTD_d_stableOutBuffer, 1))) return 2;
    FILE* df = fopen(argv[5], "rb");
    if (!df || fseek(df, 0, SEEK_END)) return 2;
    long dn = ftell(df);
    if (dn < 0 || dn > 4 * 1024 * 1024 || fseek(df, 0, SEEK_SET)) return 2;
    unsigned char* dictionary = malloc(dn ? (size_t)dn : 1);
    if (!dictionary || fread(dictionary, 1, (size_t)dn, df) != (size_t)dn || fclose(df)) return 2;
    if (ZSTD_isError(ZSTD_DCtx_refPrefix_advanced(ctx, dictionary, (size_t)dn,
                                                 ZSTD_dct_auto))) return 2;
    ZSTD_inBuffer in = {source, 0, 0};
    ZSTD_outBuffer out = {storage + 32, capacity, 0};
    size_t result = 1, calls = 0, frames = 0;
    {
        while (calls < 2 * (size + 1) + 8) {
            if (in.pos == in.size) {
                size_t const remaining = size - in.size;
                in.size += remaining < chunk ? remaining : chunk;
            }
            size_t const before = in.pos;
            result = ZSTD_decompressStream(ctx, &out, &in);
            calls++;
            if (ZSTD_isError(result)) break;
            if (result == 0) frames++;
            if (in.pos == size) break;
            if (in.pos == before) return 3;
        }
    }
    unsigned const error = ZSTD_isError(result);
    unsigned const complete = !error && result == 0 && in.pos == size;
    unsigned guards = 1;
    for (size_t i = 0; i < 32; i++) {
        if (storage[i] != 0xa5 || storage[32 + capacity + i] != 0xa5) guards = 0;
    }
    if (out.pos > capacity) return 3;
    f = fopen(argv[3], "wb");
    if (!f || (complete && out.pos && fwrite(storage + 32, 1, out.pos, f) != out.pos) || fclose(f)) return 2;
    printf("{\"version\":%u,\"error\":%u,\"error_code\":%u,\"complete\":%u,\"consumed\":%zu,\"written\":%zu,\"frames\":%zu,\"calls\":%zu,\"guards\":%u,\"initial_workspace\":%zu,\"final_workspace\":%zu}\n", ZSTD_versionNumber(), error, (unsigned)ZSTD_getErrorCode(result), complete, in.pos, out.pos, frames, calls, guards, initial_workspace, ZSTD_sizeof_DCtx(ctx));
    ZSTD_freeDCtx(ctx);
    free(dictionary);
    free(source);
    free(storage);
    return guards ? 0 : 3;
}
