from pathlib import Path
import subprocess,json,hashlib,time
D=Path(__file__).parent;R=Path('/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=sorted((R/'lib/common').glob('*.c'))+sorted((R/'lib/decompress').glob('*.c'))
e=dict(status='running',reference_revision='f8745da6ff1ad1e7bab384bd1f9d742439278e99',helper_sha256=sha(D/'stable_prefix_oracle.c'),reference_identity_sha256=sha(R.parent/'reference-identity.json'),library={str(p.relative_to(R)):sha(p) for p in (R/'lib').rglob('*') if p.is_file() and p.suffix in ['.c','.h','.S']},commands=[])
def save():(D/'build.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [('normal',['-O2']),('sanitized',['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'])]:
  args=['cc','-std=c99','-Wall','-Wextra','-Werror','-DZSTD_MULTITHREAD=0','-I'+str(R/'lib'),'-I'+str(R/'lib/common'),*flags,str(D/'stable_prefix_oracle.c'),*[str(p) for p in sources],'-o',str(D/('oracle-'+name))];start=time.monotonic()
  with (D/(name+'-build.log')).open('xb') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=name,argv=args,seconds=time.monotonic()-start,exit_code=p.returncode));save();assert p.returncode==0,name
  e.setdefault('executables',{})[name]=sha(D/('oracle-'+name));save();print(name,'built',flush=True)
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
