from pathlib import Path
import json,hashlib,shutil,subprocess
D=Path(__file__).parent;P=Path('/private/tmp/module25-native');I=D/'inputs';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((D/'build.json').read_text());assert b['status']=='passed';shutil.copytree(P/'inputs',I)
base=json.loads((P/'cases.json').read_text());assert len(base)==119
for row in base:
 if row['name'].startswith(('persistent-concatenation','prefix-reused-concatenation')):
  row['native']='error';row['rust']='error';row['qualification']='Second dictionary-dependent standard frame cannot reuse a consumed prefix.'
skip=bytes([0x50,0x2a,0x4d,0x18,1,0,0,0,42]);empty=bytes.fromhex('28b52ffd2000010000')
for prefix,original in [('skip','formatted-id'),('skip','p0-far-dictionary'),('empty','formatted-id')]:
 name=prefix+'-then-'+original
 (I/(name+'.zst')).write_bytes((skip if prefix=='skip' else empty)+(I/(original+'.zst')).read_bytes())
 for ext in ['dict','raw']:shutil.copyfile(I/(original+'.'+ext),I/(name+'.'+ext))
 length=(I/(name+'.raw')).stat().st_size
 for capacity in [length,length+17]:
  base.append(dict(name=name,capacity=capacity,native='error',rust='ok' if prefix=='skip' else 'error',qualification='Native streaming consumes its single-use dictionary on skips; Rust preserves an unclaimed prefix. Empty standard frames consume the prefix in both APIs.'))
cases=[dict(row,chunk=chunk) for row in base for chunk in [1,7,4194304]]
(D/'cases.json').write_text(json.dumps(cases,indent=2)+'\n');(D/'rust-cases.tsv').write_text(''.join(f"{r['name']}\t{r['capacity']}\t{r['chunk']}\t{r['rust']}\n" for r in cases))
e=dict(status='running',build_sha256=sha(D/'build.json'),cases_sha256=sha(D/'cases.json'),inputs={p.name:sha(p) for p in I.iterdir()},common_cases=len(cases),results=[],qualification='Original119 dictionary destination descriptors use a true single-use auto-detected native prefix, with12 repeated-prefix expectations adjusted before execution; six new skip/empty-leading descriptors expose lifecycle differences. Whole/one/seven-byte schedules, normal/sanitized. Prepared dictionaries use refPrefix_advanced auto content; no prepared DDict persistent path is substituted.')
def save():(D/'native.json').write_text(json.dumps(e,indent=2)+'\n')
assert not (D/'native.json').exists();save()
try:
 for backend in ['normal','sanitized']:
  assert sha(D/('oracle-'+backend))==b['executables'][backend];O=D/backend;O.mkdir()
  for index,case in enumerate(cases):
   name=case['name'];args=[str(D/('oracle-'+backend)),str(I/(name+'.zst')),str(case['capacity']),str(O/(str(index)+'.bin')),str(case['chunk']),str(I/(name+'.dict')),'prefix'];p=subprocess.run(args,capture_output=True,timeout=30);(O/(str(index)+'.stdout')).write_bytes(p.stdout);(O/(str(index)+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(backend,index,p.stderr)
   result=json.loads(p.stdout);assert result['version']==10507 and result['guards']==1
   expect=case['native']
   if expect=='ok':assert result['complete'] and not result['error'] and (O/(str(index)+'.bin')).read_bytes()==(I/(name+'.raw')).read_bytes(),(backend,index,case,result)
   else:
    assert not result['complete'],(backend,index,case,result)
    if expect in ['small','checksum','dictionary']:assert result['error_code']=={'small':70,'checksum':22,'dictionary':32}[expect],(backend,index,case,result)
   e['results'].append(dict(backend=backend,index=index,case=case,result=result,output_sha256=sha(O/(str(index)+'.bin'))));save()
  print(backend,len(cases),'cases passed',flush=True)
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
