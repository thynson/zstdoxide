use zstdoxide::{Encoder,EncoderOptions,CompressionStrategy,EndDirective,StreamStatus,Dictionary};
fn main() {
 let dict=Dictionary::from_bytes(include_bytes!("/Users/lanxingcan/Workspace/zstdoxize/tests/upstream/dictionaries/formatted.dict")).unwrap().into_shared();
 let mut hash=0xcbf29ce484222325u64; let mut cases=0;
 for strategy in [CompressionStrategy::Greedy,CompressionStrategy::Chain,CompressionStrategy::Lazy] {
  for length in [0,1,17,1024,2053,131089] { for kind in 0..3 { for dictionary in [false,true] {
   let input:Vec<u8>=(0..length).map(|i| match kind {0=>b'x',1=>((i*17+i/13)%251) as u8,_=>((i%11)*19) as u8}).collect();
   let options=EncoderOptions{strategy,window_log:10,pledged_size:Some(length as u64),..EncoderOptions::default()};
   let mut encoder=Encoder::with_options(options).unwrap(); if dictionary {encoder.set_dictionary(Some(dict.clone())).unwrap();}
   let mut position=0;let mut encoded=Vec::new();let mut output=[0u8;129];
   loop { let p=encoder.process(&input[position..],&mut output,EndDirective::Finish).unwrap();position+=p.consumed;encoded.extend_from_slice(&output[..p.produced]);if p.status==StreamStatus::FrameFinished {break}}
   for b in (encoded.len() as u64).to_le_bytes().iter().chain(encoded.iter()) { hash=(hash^u64::from(*b)).wrapping_mul(0x100000001b3); }
   println!("CASE {:?} {} {} {} {}",strategy,length,kind,dictionary,encoded.len());cases+=1;
  }}}
 }
 println!("BASELINE {cases} {hash}");
}
