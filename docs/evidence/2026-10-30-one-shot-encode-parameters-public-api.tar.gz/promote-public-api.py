"""Promote the qualified module36 public parameterized-dictionary API item."""
from pathlib import Path
import json, hashlib, subprocess, shutil

D = Path(__file__).parent
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
S = Path('/private/tmp/module36-public-api/source')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = Path('/private/tmp/module36-archives/promotion-state.json')
prev = json.loads(state.read_text())
assert prev['stage'] == 'entropy'
assert prev['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == prev['production_source']
name = '2026-10-30-one-shot-encode-parameters-public-api'
p = D / (name + '.json')
r = json.loads(p.read_text())
assert r['status'] == 'passed' and sha(D / r['archive']) == r['archive_sha256']
changed = []
for n in [
    'src/frame_sink.rs',
    'src/lib.rs',
    'src/one_shot_encode.rs',
    'src/reference_encode.rs',
    'src/reference_frame_encode.rs',
    'src/reference_search.rs',
    'tests/one_shot_encode_parameters.rs',
    'docs/one-shot-encode-parameters-usage.md',
]:
    assert sha(S / n) == r['source'][n], n
    (R / n).parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(S / n, R / n)
    changed.append(n)
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == r['production_source']
for q in [p, D / r['archive']]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
    changed.append('docs/evidence/' + q.name)
p = R / 'TODO.md'
s = p.read_text()
task = '- [ ] Expose documented parameterized dictionary and coordinator compression with exact output/lifetime guards and independent allocator failure qualification.'
assert s.count(task) == 1
s = s.replace(task, task.replace('[ ]', '[x]'))
p.write_text(s)
changed.append('TODO.md')
p = R / 'docs/one-shot-encode-parameters-validation.md'
s = p.read_text()
old = '''Module 36 is in progress. Only the internal combined-staging engine, its
DoubleFast extension, the Greedy chain-and-row family extension, the
BinaryTreeLazy2 tree-family extension with the explicit optimal-family
rejection, and prepared formatted-dictionary entropy reuse are qualified and
integrated. Public parameterized dictionary APIs, native/corpus/platform
validation, the complete feature/release regression, measurements and
reconciliation remain open.'''
assert s.count(old) == 1
s = s.replace(old, '''Module 36 is in progress. The internal combined-staging engine, its DoubleFast
extension, the Greedy chain-and-row family extension, the BinaryTreeLazy2
tree-family extension with the explicit optimal-family rejection, prepared
formatted-dictionary entropy reuse, and the public allocating, caller-owned and
coordinator parameterized dictionary calls are qualified and integrated.
Native/corpus/platform validation, the complete feature/release regression,
measurements and reconciliation remain open.''')
old = '''Evidence: `evidence/2026-10-30-one-shot-encode-parameters-entropy.json`.'''
assert s.count(old) == 1
s = s.replace(old, old + '''

## Public allocating, caller-owned and coordinator calls

`compress_with_parameters_and_dictionary(_in)` resolves a request against the
source and the dictionary's matchable content length, then emits the admitted
combined-staging profile. `compress_into_with_parameters(_in)` and
`compress_into_with_parameters_and_dictionary(_in)` write complete headers and
blocks atomically into caller storage and return the exact written length;
short output reports `ResourceLimit` after earlier whole appends without
touching guard bytes. `OneShotEncoder::compress_into_with_parameters(_in)` keeps
requests call-scoped, claims pending prefixes before resolution, preserves
persistent selection across success and failure, and clones no handle. A
nonzero dictionary that resolves to Optimal/Ultra/Ultra2 is rejected with
`UnsupportedFeature` before the first output byte instead of dropping the
dictionary; empty and raw attachments preserve the dictionary-free
parameterized bytes.

Twenty-three focused commands pass: the complete library suite, true no_std
compilation, strict Clippy and the public integration suite under safe, the
isolated frame-sink, huffman-codebook and dictionary backends, and all
features, plus safe/all doctests and formatting. Every library suite reports
{passed} passed and {ignored} ignored across {groups} result groups. Six public
integration tests cover exact caller-owned byte equality and guards, formatted
and raw dictionary frames with header flags, unsupported-profile rejection
before writes, coordinator persistence and prefix consumption, and every
observed allocation failure for allocating and caller-owned entry points with
independent owner release. Doctests establish dictionary-view and input/output
non-overlap; the usage guide records the supported subset and limits.
Evidence: `evidence/{name}.json`.'''.format(passed=r['full_suite_counts']['passed'], ignored=r['full_suite_counts']['ignored'], groups=r['full_suite_counts']['result_groups'], name=name))
p.write_text(s)
changed.append('docs/one-shot-encode-parameters-validation.md')
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *changed], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Expose parameterized dictionary and coordinator compression APIs'], cwd=R, check=True)
prev.update(stage='public-api', head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(), production_source={str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')})
state.write_text(json.dumps(prev, indent=2) + '\n')
print('module36 public parameterized dictionary API promoted at', prev['head'][:12])
