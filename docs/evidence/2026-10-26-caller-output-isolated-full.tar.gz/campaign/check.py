from pathlib import Path
import os,subprocess,json,time,hashlib,tomllib,signal,datetime
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path(__file__).parent
# New user-authorized seven-hour window begins 2026-10-26 01:59:25 UTC.
deadline=datetime.datetime(2026,10,26,8,59,25,tzinfo=datetime.timezone.utc).timestamp()
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module23-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
features=sorted(n for n in tomllib.loads((R/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
features.remove('unsafe-slice-history');features.insert(0,'unsafe-slice-history')
paths=list(R.glob('src/*.rs'))+[R/'Cargo.toml',R/'Cargo.lock']+list(R.glob('tests/*.rs'))
source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
gate=Path('/private/tmp/module23-feature-matrix/resume-20261026.json');g=json.loads(gate.read_text());assert g['status']=='passed' and g['source']==source
assert not (D/'evidence.json').exists()
e={'status':'running','source':source,'commands':[],'features':features,'deadline_utc':'2026-10-26T08:59:25Z','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prerequisite_sha256':hashlib.sha256(gate.read_bytes()).hexdigest()}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [(f,['--features',f]) for f in features]+[('all-release',['--all-features','--release'])]:
  remaining=deadline-time.time()-20
  if remaining<150:
   e.update(status='deferred-at-user-deadline',next_feature=name);save();print('next feature deferred at user deadline',name,flush=True);break
  args=['cargo','test','--offline','--locked',*flags];start=time.monotonic();timed_out=False
  with (D/(name+'.log')).open('xb') as f:
   p=subprocess.Popen(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=remaining)
   except subprocess.TimeoutExpired:
    timed_out=True;os.killpg(p.pid,signal.SIGTERM)
    try:code=p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
  row=dict(label=name,argv=args,exit_code=code,seconds=time.monotonic()-start,interrupted_at_user_deadline=timed_out);e['commands'].append(row);save();print(name,code,flush=True)
  if timed_out:e.update(status='interrupted-at-user-deadline',next_feature=name);save();break
  assert code==0,name
 else:e['status']='passed';save()
 assert source=={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
