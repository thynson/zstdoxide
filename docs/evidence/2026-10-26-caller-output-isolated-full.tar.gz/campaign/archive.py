from pathlib import Path
import json,hashlib,tarfile,re,tomllib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path(__file__).parent;E=R/'docs/evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
j=json.loads((D/'evidence.json').read_text());assert j['status']=='passed' and len(j['commands'])==21
features=set(f for f in tomllib.loads((R/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'))
assert {c['label'] for c in j['commands']}==features|{'all-release'}
base=E/'2026-10-26-caller-output-feature-matrix.json';b=json.loads(base.read_text())
for n,h in b['complete_source'].items():assert sha(R/n)==h,n
commands=[]
for c in j['commands']:
 assert c['exit_code']==0 and not c['interrupted_at_user_deadline']
 p=D/(c['label']+'.log');results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.read_text())
 assert results and all(int(f)==0 for _,f,_ in results)
 commands.append({**c,'log_sha256':sha(p),'result_groups':len(results),'passed':sum(int(v[0]) for v in results),'ignored':sum(int(v[2]) for v in results),'test_result_groups':[dict(passed=int(a),failed=int(f),ignored=int(i)) for a,f,i in results]})
name='2026-10-26-caller-output-isolated-full';archive=E/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(D.iterdir()):
  if p.is_file():t.add(p,arcname='campaign/'+p.name)
 for n in sorted(b['complete_source']):
  p=R/n
  if p.suffix in ['.rs','.toml','.lock','.py','.md','.json','.sh','.tsv','.csv']:t.add(p,arcname='source/'+n)
result=dict(status='passed',qualification='Every isolated unsafe feature ran the complete default-profile suite, then all features ran the complete release suite. Paused predecessor commands are not reused as completed commands. Test-only external and unsupported ignored entrypoints remain explicit.',source=j['source'],complete_source=b['complete_source'],fixture_provenance=b['fixture_provenance'],base_evidence_sha256=sha(base),commands=commands,archive=archive.name,archive_sha256=sha(archive))
(E/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print('Archived',len(commands),'complete suites',archive.stat().st_size,'bytes')
