from pathlib import Path
import json,time,subprocess
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize')
while True:
 j=json.loads((D/'evidence.json').read_text())
 if j['status']=='passed':break
 assert j['status']=='running',j['status']
 time.sleep(15)
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
subprocess.run(['python3',str(D/'archive.py')],check=True)
p=R/'TODO.md';s=p.read_text();old='- [ ] Complete whole-suite regression under every isolated storage feature and all-feature release.';assert old in s;p.write_text(s.replace(old,old.replace('[ ]','[x]')))
p=R/'docs/caller-output-validation.md';s=p.read_text();s=s.replace('Isolated-feature whole-suite regression, all-feature full release and\ndeterministic allocation/performance comparisons remain open until their own\nevidence is recorded. Stable incremental destination','Whole-suite isolated-feature regression and all-feature full release are\ncomplete in the additive receipt below. Deterministic allocation/performance\ncomparisons remain open until their own evidence is recorded. Stable incremental destination')
s=s.replace('Whole suites for\nevery isolated feature and the full all-feature release suite remain a separate\nqualification item.','The separate receipt below completes every isolated feature whole suite and\nthe full all-feature release suite.')
e=json.loads((R/'docs/evidence/2026-10-26-caller-output-isolated-full.json').read_text());counts={(c['result_groups'],c['passed'],c['ignored']) for c in e['commands']};assert len(counts)==1;groups,passed,ignored=next(iter(counts))
s+=f'''\n## Complete isolated-feature and all-feature release regression\n\n`evidence/2026-10-26-caller-output-isolated-full.json` records 21 successful\ncomplete-suite executions: every one of twenty independent unsafe features and\nthe full all-feature release suite. Each reports {passed:,} passed and {ignored}\nexplicitly ignored tests across {groups} result groups, including Rustdoc.\nThe previously completed safe/all full suites and all no_std/Clippy checks remain\nin their separate feature-matrix receipt. No interrupted or ignored execution\nis relabelled as a passed test.\n\nEvery final source/test/fixture hash agrees with the frozen baseline. The compact\narchive retains code, all logs and commands; omitted binary fixtures are bound\nto their Git baseline and individual hashes. Deterministic timing and the final\nbounded milestone reconciliation remain open.\n''';p.write_text(s)
paths=['TODO.md','docs/caller-output-validation.md','docs/evidence/2026-10-26-caller-output-isolated-full.json','docs/evidence/2026-10-26-caller-output-isolated-full.tar.gz']
subprocess.run(['git','diff','--check'],cwd=R,check=True);subprocess.run(['git','add','--',*paths],cwd=R,check=True);subprocess.run(['git','commit','-m','Complete caller-output isolated whole-suite regression'],cwd=R,check=True)
print('Module23 isolated whole-suite regression archived and committed',flush=True)
