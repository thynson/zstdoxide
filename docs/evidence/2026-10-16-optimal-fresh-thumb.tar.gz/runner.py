from pathlib import Path
import hashlib,json,os,subprocess,time,tomllib
R=Path.cwd();O=Path('/tmp/zstdoxide-optimal-fresh-thumb-1016-checks');O.mkdir();caller=O/'caller';(caller/'src').mkdir(parents=True)
features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'})
(caller/'Cargo.toml').write_text('[package]\nname="optimal-fresh-thumb"\nversion="0.0.0"\nedition="2024"\n[features]\n'+''.join(f'{f}=[]\n'for f in features)+'[lib]\npath="src/lib.rs"\n')
mods=['error','constants','greedy_key','tree_layout','optimal_search_layout','optimal_price','optimal_frequencies','optimal_matches','optimal_path_layout','optimal_paths','optimal_parse','reference_tree','optimal_short_key','optimal_search']
(caller/'src/lib.rs').write_text("#![no_std]\n#![feature(allocator_api)]\n#![deny(unsafe_op_in_unsafe_fn)]\n#![allow(dead_code)]\nextern crate alloc;\n"+''.join(f'#[path="{R}/src/{m}.rs"] mod {m};\n'for m in mods)+r"""
pub use error::{Error,Result};
use core::alloc::Allocator;
struct Provider;
impl optimal_parse::PathProvider for Provider {
 fn query<A:Allocator>(&mut self,q:optimal_search_layout::OptimalQuery,m:&mut optimal_matches::OptimalMatches<A>)->Result<()> {
  if q.position==1 {m.push(optimal_search_layout::OptimalMatch::new(4,15)?)?;}Ok(())
 }
}
struct Observer;
impl optimal_parse::PathObserver for Observer {
 fn event<P:Allocator,F:Allocator>(&mut self,_:optimal_parse::PathEvent,_:&optimal_paths::OptimalPaths<P>,_:&optimal_frequencies::OptimalFrequencies<F>,_:&[optimal_search_layout::OptimalMatch])->Result<()>{Ok(())}
}
pub fn exercise()->Result<usize>{
 use alloc::alloc::Global;
 use optimal_search_layout::OptimalSearchLayout;
 let source=[b'a';64];
 let layout=OptimalSearchLayout::new(10,6,6,1,3,0,Some(10))?;
 let owners=[Global;7];let [f,p,m,h,n,s,b]=owners.each_ref();
 let frequencies=optimal_frequencies::OptimalFrequencies::new_in(true,f)?;
 let paths=optimal_paths::OptimalPaths::new_in(p)?;
 let matches=optimal_matches::OptimalMatches::new_in(m)?;
 let mut parser=optimal_parse::OptimalParser::from_parts(&source,3,0,frequencies,paths,matches)?;
 let mut search=optimal_search::OptimalSearch::from_parts(&source,layout,
   reference_tree::ReferenceTree::new_in(layout.tree(),h,n)?,
   optimal_short_key::OptimalShortKey::new_in(layout.short_log(),s)?,
   optimal_matches::OptimalMatches::new_in(b)?)?;
 let result=parser.parse_fresh(&mut search,&mut Observer)?;
 parser.reset()?;search.reset();
 let repeated=parser.parse_fresh(&mut search,&mut Observer)?;
 if result!=repeated{return Err(Error::CorruptData);}
 Ok(result.sequences)
}
""")

env={k:v for k,v in os.environ.items()if k in ['PATH','HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR']};env.update(RUSTUP_TOOLCHAIN='nightly-2026-10-08',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-fresh-thumb-1016-target')
source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in list((R/'src').rglob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock']};commands=[]
def save(status,error=None):(O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,commands=commands,qualification='Actual thumbv6m no_std library checks and concrete private ordinary fresh caller with seven borrowed Global owners code generation; no firmware execution.'),indent=2)+'\n')
def run(label,argv,cwd):
 print('START',label,flush=True);start=time.monotonic()
 with(O/(label+'.log')).open('wb')as f:p=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 data=(O/(label+'.log')).read_bytes();commands.append(dict(label=label,argv=argv,cwd=str(cwd),exit_code=p.returncode,seconds=time.monotonic()-start,log=label+'.log',sha256=hashlib.sha256(data).hexdigest()));save('running')
 if p.returncode:raise RuntimeError(label)
 print('END',label,flush=True)
try:
 modes=[('safe',[]),('frequencies',['--features','unsafe-optimal-frequencies']),('paths',['--features','unsafe-optimal-paths']),('search',['--features','unsafe-reference-tree,unsafe-optimal-short-key,unsafe-optimal-matches']),('all',['--features',','.join(features)])]
 for mode,flags in modes:run('library-'+mode,['cargo','check','--offline','--locked','--lib','--no-default-features','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc',*flags],R)
 for mode,flags in modes:run('caller-'+mode,['cargo','build','--offline','--lib','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc',*flags],caller)
 assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in source.items())
 save('passed')
except BaseException as e:save('failed',repr(e));raise
