from pathlib import Path
import hashlib,json,sys
root=Path(sys.argv[1]);out=Path(sys.argv[2]);
if out.exists():raise ValueError('fresh output required')
for row in json.loads((root/'manifest.json').read_text())['files']:
 p=Path(row['path']);
 if p.is_absolute()or '..'in p.parts:raise ValueError('relative member required')
 b=(root/'blobs'/row['sha256']).read_bytes();
 if len(b)!=row['bytes']or hashlib.sha256(b).hexdigest()!=row['sha256']:raise ValueError('content mismatch')
 target=out/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
