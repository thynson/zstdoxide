# Pre-execution review packet

No C compilation/execution or Rust compilation has run. `driver.py --prepare-only`
created `/tmp/zstdoxide-negative-level-review/{oracle.c,extraction.json,compare.rs,support.rs,prepared.json}`.
The prepared file preserves the exact four writers and target assertions from
hash-pinned `tests/fuzzer.c`; the source origin is recorded per verbatim span.

- Reference revision f8745da6ff1ad1e7bab384bd1f9d742439278e99, unchanged datagen.c.
- Fixed seed0, P50, original all-compressors preprocessor gate. No CLI-selectable
  dimensions, inputs, levels or source probabilities. Exact replay scope only.
- Target1MiB from5MiB source; destination5,263,360; decoded buffer5MiB; each owned
  malloc has64-byte front/end guards. All allocations and paths bounded.
- Three buffers are initialized, source overwritten by full RDG before use.
  Initial-match writes0..29; flat regeneration31744 bytes; final byte0=1.
- Original target block retained; two save/decode hooks inserted after existing
  success checks, simple before its shared destination is overwritten.
- Every C frame is independently decoded with a fresh DCtx into capacity1MiB;
  original non-error/equal-size assertion retained, header/frame EOF checked.
- Simple context internals inaccessible: applied parameters recorded null. Fresh
  advanced context records actual applied/query parameters and no dictionary.
- Four full5MiB stage files remain outsidegit. Safe Rust comparison helper uses
  the existing unchanged support::noise file copied by hash, no codec or Fast.
  Compares exactly4*5,242,880 +1,048,576 =22,020,096 per mode.
- Exact output argument count/path length; fresh directory and disjoint reference,
  repository/helper roots checked before mkdir; output files opened exclusive.
- C has no binary input protocol. All binary output bounded by originalbuffers;
  Python checks exact sizes and complete frame boundaries, strict JSON types.
- Normal helper/datagen + pinned archive; sanitizer compiles unchanged datagen,
  zstd_compress.c, zstd_fast.c plus helper with ASan/UBSan. Other archive code
  uninstrumented, leak sanitizer disabled. No claim of full codec sanitization.
- Python checks source identity before/after each command, preserves commands,
  environment, return codes, stdout/stderr and all failures. Compilerflags explicit
  no fast-math. Timeout180seconds per subprocess; no full fuzzer harness runs.

Please review extraction fidelity, integer/guard bounds, initialization/private
context reads and the two capture hooks before the first external run.
