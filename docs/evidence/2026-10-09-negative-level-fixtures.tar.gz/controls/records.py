#!/usr/bin/env python3
from pathlib import Path
import copy,hashlib,importlib.util,json,shutil,subprocess,sys
sys.dont_write_bytecode=True
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize')
COL=ROOT/'tests/upstream/negative-level'
OUT=Path(sys.argv[1]).resolve()
if OUT.exists():raise SystemExit('fresh output required')
OUT.mkdir()
rows=[]
for optimized in (False,True):
 tag='optimized' if optimized else 'normal'
 py=[sys.executable]+(['-O'] if optimized else [])
 for name,statement in {
  'positive':'pass',
  'full-prefix-claim':"data[0]['full_prefix_executed']=True",
  'boolean-seed':"data[0]['seed']=False",
  'dictionary-claim':"data[0]['dictionary_bytes']=1",
  'missing-stage':'data.pop(2)',
  'stage-bool-size':"data[1]['size']=True",
  'stage-bad-hex':"data[2]['xxh64']='g'*16",
  'frame-bool-window':"data[5]['window_size']=True",
  'frame-size':"data[5]['size']+=1",
  'frame-unknown-field':"data[6]['unused']=0",
  'applied-bool-strategy':"data[6]['applied_parameters'][-1]=True",
  'requested-level':"data[6]['requested_level']=0",
  'simple-fake-applied':"data[5]['applied_parameters']=data[6]['applied_parameters']",
  'guard-false':"data[5]['guards_intact']=False",
  'original-assertion-false':"data[7]['original_size_assertion']=False",
  'decode-flag-integer':"data[5]['decoded_equal']=1",
 }.items():
  record=OUT/(tag+'-'+name+'.jsonl')
  script="import sys;sys.dont_write_bytecode=True;import importlib.util,json;from pathlib import Path;spec=importlib.util.spec_from_file_location('capture',"+repr(str(COL/'capture.py'))+");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);data=[json.loads(x) for x in Path("+repr(str(COL/'observations.jsonl'))+").read_text().splitlines()];"+statement+";Path("+repr(str(record))+").write_text(''.join(json.dumps(x)+'\\n' for x in data));m.validate(Path("+repr(str(COL))+"),Path("+repr(str(record))+"),require_stages=False)"
  stdout=OUT/(tag+'-'+name+'.stdout');stderr=OUT/(tag+'-'+name+'.stderr')
  with stdout.open('w') as o,stderr.open('w') as e:p=subprocess.run(py+['-c',script],stdout=o,stderr=e,timeout=15)
  success=name=='positive'
  if (p.returncode==0)!=success:raise AssertionError((name,p.returncode))
  rows.append({'name':tag+'-'+name,'exit_code':p.returncode,'expected_success':success,'stderr_sha256':hashlib.sha256(stderr.read_bytes()).hexdigest()})
summary={'passed':True,'checks':rows,'count':len(rows),'positive':sum(r['expected_success'] for r in rows),'rejections':sum(not r['expected_success'] for r in rows)}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print({k:v for k,v in summary.items() if k!='checks'})
