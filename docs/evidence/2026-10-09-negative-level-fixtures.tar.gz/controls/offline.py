#!/usr/bin/env python3
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys

sys.dont_write_bytecode=True
REPO=Path('/Users/lanxingcan/Workspace/zstdoxize')
COLLECTION=REPO/'tests/upstream/negative-level'
OUT=Path(sys.argv[1]).resolve()
if OUT.exists():raise SystemExit('fresh controls directory required')
OUT.mkdir(parents=True)
rows=[]
def command(name, argv, success):
    out=OUT/(name+'.stdout');err=OUT/(name+'.stderr')
    with out.open('w') as stdout,err.open('w') as stderr:
        p=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=45,check=False)
    if (p.returncode==0)!=success:raise AssertionError((name,p.returncode,err.read_text()))
    rows.append({'name':name,'argv':argv,'exit_code':p.returncode,'expected_success':success,
                 'stdout_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
                 'stderr_sha256':hashlib.sha256(err.read_bytes()).hexdigest()})
    (OUT/'summary.json').write_text(json.dumps({'status':'running','checks':rows},indent=2)+'\n')

mutations={
 'source-byte':lambda p: byte_change(p/'source.raw',77),
 'frame-byte':lambda p: byte_change(p/'simple.zst',22),
 'source-truncated':lambda p:(p/'source.raw').write_bytes((p/'source.raw').read_bytes()[:-1]),
 'frame-trailing':lambda p:(p/'advanced.zst').write_bytes((p/'advanced.zst').read_bytes()+b'\0'),
 'missing-frame':lambda p:(p/'simple.zst').unlink(),
 'unlisted-file':lambda p:(p/'extra').write_text('extra'),
 'extraction-text':lambda p: json_change(p/'extraction.json',lambda x:x['spans'][4].__setitem__('text','changed')),
 'manifest-scope':lambda p:json_change(p/'manifest.json',lambda x:x['coverage'].__setitem__('full_prefix_executed',True)),
 'capture-mode':lambda p:json_change(p/'capture.json',lambda x:x.__setitem__('modes',['normal'])),
 'observation-boolean':lambda p: row_change(p,lambda x:x[0].__setitem__('seed',False)),
 'generator-byte':lambda p:(p/'oracle.c.in').write_text((p/'oracle.c.in').read_text()+'\n'),
 'driver-byte':lambda p:(p/'capture.py').write_text((p/'capture.py').read_text()+'\n'),
 'comparison-byte':lambda p:(p/'compare.rs').write_text((p/'compare.rs').read_text()+'\n'),
 'source-catalog':lambda p:json_change(p/'manifest.json',lambda x:x['source_sha256'].__setitem__('tests/fuzzer.c','0'*64)),
 'updated-file-hash':lambda p: updated_hash(p),
 'escaping-source':lambda p: escaped_source(p),
}
def byte_change(p,i):
 b=bytearray(p.read_bytes());b[i]^=1;p.write_bytes(b)
def json_change(p,f):
 x=json.loads(p.read_text());f(x);p.write_text(json.dumps(x)+'\n')
def row_change(p,f):
 q=p/'observations.jsonl';x=[json.loads(z) for z in q.read_text().splitlines()];f(x);q.write_text(''.join(json.dumps(z)+'\n' for z in x))
def updated_hash(p):
 byte_change(p/'source.raw',1)
 def update(m):
  for r in m['fixtures']:
   if r['path']=='source.raw':r['sha256']=hashlib.sha256((p/'source.raw').read_bytes()).hexdigest()
  m['fixture_catalog_sha256']=hashlib.sha256(json.dumps(m['fixtures'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
 json_change(p/'manifest.json',update)
def escaped_source(p):
 (p/'source.raw').unlink();(p/'source.raw').symlink_to(COLLECTION/'source.raw')

for optimized in (False,True):
    prefix='optimized' if optimized else 'normal'
    python=[sys.executable]+(['-O'] if optimized else [])
    command(prefix+'-positive',python+[str(REPO/'scripts/import_negative_level_fixture.py'),'--check'],True)
    spy="import subprocess,runpy,sys; subprocess.run=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('unexpected subprocess')); subprocess.check_output=subprocess.run;sys.argv=['importer','--check'];runpy.run_path("+repr(str(REPO/'scripts/import_negative_level_fixture.py'))+",run_name='__main__')"
    command(prefix+'-no-subprocess',python+['-c',spy],True)
    for name,mutate in mutations.items():
        directory=OUT/(prefix+'-'+name)
        shutil.copytree(COLLECTION,directory);mutate(directory)
        command(prefix+'-'+name,python+[str(REPO/'scripts/import_negative_level_fixture.py'),'--check','--collection',str(directory)],False)
    command(prefix+'-offline-cc',python+[str(REPO/'scripts/import_negative_level_fixture.py'),'--check','--cc','cc'],False)
    for name,output,report in (
      ('report-inside-output',OUT/(prefix+'-fresh-output'),OUT/(prefix+'-fresh-output')/'log'),
      ('output-inside-report',OUT/(prefix+'-fresh-report')/'child',OUT/(prefix+'-fresh-report')),
      ('same-report-output',OUT/(prefix+'-equal'),OUT/(prefix+'-equal')),
      ('output-in-source',COLLECTION/(prefix+'-invalid'),OUT/(prefix+'-unused-report')),
    ):
        command(prefix+'-'+name,python+[str(REPO/'scripts/import_negative_level_fixture.py'),'--upstream','/tmp/zstdoxize-upstream-1.5.7','--output',str(output),'--report',str(report)],False)
        if output.exists() or report.exists():raise AssertionError('overlap rejection created output')
    sandbox=OUT/(prefix+'-fake-repo')
    (sandbox/'scripts').mkdir(parents=True)
    shutil.copyfile(REPO/'scripts/import_negative_level_fixture.py',sandbox/'scripts/import_negative_level_fixture.py')
    (sandbox/'tests/upstream/negative-level').mkdir(parents=True)
    sentinel=OUT/(prefix+'-bad-import-executed')
    (sandbox/'tests/upstream/negative-level/capture.py').write_text('from pathlib import Path\nPath('+repr(str(sentinel))+').write_text("bad")\n'+(COLLECTION/'capture.py').read_text())
    command(prefix+'-before-import-hash',python+[str(sandbox/'scripts/import_negative_level_fixture.py'),'--check'],False)
    if sentinel.exists():raise AssertionError('modified driver executed')

summary={'status':'passed','checks':rows,'count':len(rows),'positive':sum(r['expected_success'] for r in rows),'rejections':sum(not r['expected_success'] for r in rows)}
(OUT/'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='checks'}))
