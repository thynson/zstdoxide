# Exact inherited input for the negative-level assertion

Planning only, 2026-10-09. No C build, fixture generation, codec execution, or
coverage promotion has been performed for this proposal. The original complete
unit-test prefix must not be executed for this work item.

Reference: facebook/zstd v1.5.7,
`f8745da6ff1ad1e7bab384bd1f9d742439278e99`. All upstream paths below are
repository-relative to that revision, not to the Rust repository.

## Conclusion and precise claim

A bounded, source-state-equivalent replay is practical for the official default
`basicUnitTests(0, 0.50)` configuration with every compressor family present.
Extract the unchanged final CNBuffer-writing statements and the target assertion
from the hash-pinned C file, call unchanged `programs/datagen.c`, and retain each
stage's complete byte fingerprints. This can reproduce the inherited source
state without executing unrelated compression/dictionary campaigns.

Call the result an **exact extracted source-state replay**, not a capture from a
complete successful run of all preceding unit tests. A fresh one-call RDG input
must not be substituted or advertised as the inherited input. Do not simplify
away the 31 KiB regeneration even if a later comparison shows equal prefixes.

The original assertion at `tests/fuzzer.c:3469-3489` checks that level -1 simple
compression and fresh-context advanced compression both succeed and return the
same size. It does not compare compressed bytes: both calls reuse and overwrite
one destination. Byte equality, decoded-byte equality, frame parsing, and Rust
convenience/request equality are useful additional assertions, clearly labeled.

## Entry point and input dependencies

Original entry path: `main` (`fuzzer.c:5021`) parses arguments, then calls
`basicUnitTests(0, probfloat)` at `:5132` when the starting test is zero. Thus the
basic-test seed is always zero; `-s0` does not select that seed. `-P50` determines
compressibility 0.5. Default long tests are disabled; `-i0` affects the later
random fuzz loop, not the preceding basic tests. The original full CLI shape
would be `-s0 -P50 -i0 -t0 --no-long-tests`, but it is **not an execution command
for this bounded plan**.

The bounded derivative should use an explicitly named capture/replay entry
point with the same seed and probability. It may be a capture-only branch in a
temporary copied harness or a generated small translation unit containing the
extracted source statements. Prefer the small generated translation unit:
there is no reason to compile/run discarded unrelated tests. Preserve the
original entry-path facts in metadata and explicitly record that its skipped
prefix assertions were not executed. Do not use jumps into existing C scopes
whose declarations/initializations have not run.

Fixed dimensions and state:

| Item | Exact value / source |
| --- | --- |
| Basic source allocation | 5,242,880 bytes, `5 MB`, :652 |
| Target source prefix | 1,048,576 bytes, `CNBuffSize / 5`, :3471 |
| Original destination capacity | 5,263,360 bytes, `ZSTD_compressBound(CNBuffSize)`, :654 |
| Source-size compression bound | 1,052,672 bytes; useful additional bound, not replacement for original capacity |
| Basic seed | 0; constant argument at :5132 |
| Match probability / literal argument | 0.50 / 0.0 (auto) |
| Compression level | -1 |
| Dictionary size | Known zero; no attachment APIs occur on the fresh target context |
| Original advanced settings | Fresh CCtx, only `ZSTD_c_compressionLevel=-1` setter |
| Expected profile from source | window19, chain12, hash13, search1, minMatch6, target1, Fast |
| Reference frame defaults | content size on, checksum off, dictionary-ID flag on; actual frame dictionary ID is zero |

The expected profile follows `lib/compress/clevels.h` default tier row0 and
`lib/compress/zstd_compress.c:7759-7782`; record observed query/applied values
later rather than treating this static deduction as an executed oracle result.
The 1 MiB source spans eight 128 KiB blocks, while the selected window is 512 KiB.
This is a meaningful persistent Fast whole-frame case.

## Reverse last-writer proof

The full reset at :1541 dominates all bytes subsequently read by the target.
Before it, :667 initializes the source and earlier tests overwrite portions or
the complete allocation; these earlier values and any advanced codec state are
irrelevant after :1541. For easy audit, the bounded replay may retain :667 as an
extra initialization before the dominating reset, but no correctness argument
needs earlier codec executions.

| Stage | Original source | Exact writes and retained dependencies |
| --- | --- | --- |
| Full restore | `fuzzer.c:1541` | `RDG_genBuffer(CNBuffer, CNBuffSize, compressibility, 0., seed)` overwrites all 5 MiB. |
| Difficult initial match | `:1640-1642` | First20 bytes become 0..19; source first10 copied to bytes20..29. The following codec loop only reads CNBuffer. |
| Default-profile flat dictionary | `:2521-2534`, `:2556` | Under the original no-excluded-compressor gate and P50 condition, regenerate exactly `(22+9) KiB = 31,744` bytes from the same seed/probabilities. This overwrites the previous30 bytes. Preserve the full gate in extraction metadata; reject replay requests for any excluded family or a non50 probability. |
| Bad-magic source byte | `:3447` | Set byte0 to1. The following decoder and pledged-size error tests read CNBuffer, writing other buffers. |
| Target read | `:3475-3482` | Both compressors receive source range `[0, 1,048,576)`. |

Final byte provenance is therefore:

- byte0: the literal assignment at :3447;
- `[1,31744)`: the bounded RDG regeneration at :2556;
- `[31744,1048576)`: the full RDG regeneration at :1541.

`basicUnitTests` receives `U32 const seed`; it is not mutated. The local
`seed32` variables used by dictionary tests are separate objects. In
`programs/datagen.c:144-152`, every RDG_genBuffer call constructs fresh local
`seed32` and `ldt`. RDG_genBlock's recurrence, previous offset and output cursor
are local, and its lookback reads only bytes already written into that call's
own output. Therefore there is no dependence on prior fuzz/codec RNG calls or
trained dictionaries. The .50/0 literal-probability path uses deterministic
binary64 arithmetic; preserve compiler/floating-point flags and reject fast-math.

Source-use audit from :1541 through :3468: remaining occurrences of CNBuffer are
compression sources, const dictionary/content aliases, const training samples,
comparisons, or decoder inputs. Decoder destinations are `decodedBuffer`;
dictionary training destinations are separate `dictBuffer` allocations. The
`const void* dict` alias in the flat-dictionary group and `contentStart` derived
from it are used as sources, never output destinations. This argument assumes
the documented input-const contracts of the pinned C implementations, not
absence of arbitrary corruption from unrelated tests that are deliberately not
run. A separate read-only audit by the fuzzer_tests agent confirmed this writer chain and the absence of a later output alias; it also checked that dictBuffer, rawDictBuffer and dictBufferMulti are separate allocations. Neither reviewer executed the original prefix.

## Bounded capture and independent checks

1. Verify the clean reference revision and the exact full-file hashes below.
   Extract exact byte ranges for allocations/constants, the four writer stages,
   gate/condition constants, and the :3469 target block. Store each original
   span's start/end lines, SHA256, verbatim text, and generated-unit source hash.
   Exact byte matching plus a fixed full-file hash guards against stale line
   numbers, duplicate anchors, or silent source edits.
2. Build a small external oracle against unchanged datagen.c and pinned libzstd.
   Do not transplant the multi-GiB unit-test prefix. The target uses two fresh
   compression paths and no dictionary; it does not need execution of MT,
   training, attached-dictionary, or static-workspace prerequisites.
3. Apply all four writers in source order. Record SHA256 plus XXH64 of the full
   5 MiB allocation and the target1MiB at each stage; also record boundary bytes
   around offsets0/20/30/31744/1048576. The hashes are pending until actually run.
   Retain the exact final1MiB fixture. Full5MiB bytes need not be checked in.
4. Independently regenerate the same stages using the existing safe Rust
   `tests/upstream/support/mod.rs::noise` implementation and explicit indexed
   writes. Compare every byte at every stage against the C output; existing
   small RDG vectors alone do not establish this larger inherited input. This
   comparison is source generation only and must not depend on Rust Fast output.
5. Execute the original target non-error and size-equality assertions. Save the
   first frame immediately after ZSTD_compress succeeds, before compress2
   overwrites the shared destination. Save the second after its checks. Inspect
   actual source size, dictionary ID, flags, block count/types, selected/applied
   parameters, and byte equality without assuming equality beforehand.
6. A separate bounded oracle consumes the frozen input file, enforces exact EOF
   and expected hash, and repeats the fresh simple/advanced pair. Independently
   C-decode both outputs into exactly1MiB and compare input bytes. A later Rust
   decoder check and C decoding of Rust outputs give bidirectional evidence.
7. Preserve normal/sanitized commands, compiler identity/flags, environment,
   binary/support-library hashes, capture source, extraction manifest and all
   failed diagnostics. If only the wrapper/datagen are instrumented while a
   static archive is used, explicitly state that the archive codec is not fully
   sanitized. Full C sanitization is not necessary for initial source extraction.

All binary I/O must be exact-length and bounded. With the original three buffers
retained, explicit payload allocation is 15,749,120 bytes (5MiB +5,263,360 +5MiB),
plus small metadata and C contexts. Saving frames to files between calls avoids
a second large in-memory destination. Store at most the returned valid frame
bytes and reject sizes above the declared destination; optionally check the
source-size compression bound as an additional documented invariant. No
multi-GiB allocation or compression loop belongs to this campaign. Use a small
fixed timeout after approval; report rather than weaken any failing assertion.

Pinned source hashes:

- tests/fuzzer.c: `dedcfca725c18810ccb8fce1d2b9995f14f8fb879c8b277158a8316ac2cf690c`
- programs/datagen.c: `fdc1e21f374f7ce3d45f26702583ed2c606f9b5b7124c673bb3a4cbb09a62397`
- programs/datagen.h: `fce55139b80280516108ca2a0377b43239389c2e7a927a1c804f9e01d10a715c`
- lib/compress/clevels.h: `d764daa89b7a636d26fe96ff3536c5075e9867fb5dddbf8c9d57023a8ff4a155`

## Rust assertion boundary and current inventory

Once the admitted reference Fast execution API exists, call
`compress_at_level(source,-1)` and
`compress_with_parameters(source,&CompressionParameterRequest(-1))` using the
actual request constructor. Both resolve Known(1MiB), dictionary0. Require
successful equal-sized results and strengthen to identical complete Rust frame
bytes; decode exactly. The request API is an adaptation of the original
fresh advanced CCtx + setter sequence. Do not claim live numeric-context API
parity or C-identical entropy decisions, compressed bytes, or ratios.

Current `tests/upstream/manifest.json` and FUZZER.md still mark :3469 blocked;
this planning task changes nothing. Relevant existing groups:

| Source anchor | Current state / Module12 treatment |
| --- | --- |
| fuzzer.c:3469-3495 inventory group | Blocked. Original -1 non-error/equal-size assertion is the first candidate after exact inherited-input fixture and public execution. The actual assertion ends before the next parameter-order group. |
| :680, :685, :804 | Minimum/default level and parameter validation scalar assertions already ported; no execution claim. |
| :570, :1721, :1808, :1832 | Partial validation/getters/frame flags and named-policy lifecycle; original numeric bulk/live setters remain qualified. |
| :1554-1568 | Original empty-source loop spans levels-1..22. The -1/1 admitted subset is useful, but cannot complete the positive-level loop or reusable live CCtx behavior. |
| :1637-1679 | Original30-byte CCtx reuse loop levels1..19 includes advanced, bound-minus1 streaming and end calls. Level1 fresh whole-buffer determinism is only a subset. |
| :3013, :3088, :3104 | Existing named-policy dictionary ordering/session-vs-parameter resets partial. Numeric7/dictionary Fast not implemented by no-dictionary whole-buffer Fast. |
| :3181, :3208, :3235 | Blocked attached Fast/DoubleFast/Lazy dictionaries and hash25/29 resource requirements. |
| :3496, :3513 | Blocked level2 + LDM enabled + window18 setter-order equal-size/XXH64 assertions; a no-LDM request-order test is not their port. |
| :4332, :4346 | Exact dictionary-size profile query/adjust equalities already ported as scalar contracts. |
| :2192, :4357, :4373 | Static workspaces/context-size estimator contracts blocked; allocator counters are not replacements. |
| :4438-4505 | Full static multi-level index-reduction campaign still blocked. |
| zstreamtest.c:1599-1628 | Numeric11/9 requested-context state is separate; source-hint scalar bounds already work. |
| cli-tests/compression/levels.sh:14-47 | CLI remains blocked. Bare --fast==-1 is a related library normalization idea; ratios/default3/argument parsing/env and file behavior remain outside scope. |

## Matching upstream fuzz candidates, in priority order

The shared `tests/fuzz/zstd_helpers.c:23-24` scalar level range is **-3..19**, not
all negative levels. Exact tail consumption must be preserved and independently
checked; selecting only supported profiles is an explicit subset, never a full
corpus success claim. An unsupported case must be counted/reported, not silently
rewritten to another level or dropped from corpus totals.

1. `tests/fuzz/simple_round_trip.c:52-100`, especially :79-91: the simple branch
   selects a level, compresses twice on the same CCtx, and checks identical size
   and XXH64 before exact decoded size/content. For -3/-2/-1 and other actually
   admitted Fast profiles, whole-buffer deterministic output can cover a useful
   subset once implemented. Preserve preceding reserve-prefix, bound-minus0/1,
   branch and signed-level selector positions. Original one-shot context reuse,
   atomic caller-capacity behavior, advanced random branch, max-block control,
   in-place decode and external sequence-producer variants remain qualified.
   Current inventory is partial, mapped to upstream_fuzz_targets.rs.
2. `tests/fuzz/simple_compress.c:29-59`: exact simple numeric levels plus a
   tail-selected capacity0..compressBound(source). Only dstSize_tooSmall errors
   are permitted. Current blocked defining contract is caller-owned one-shot
   destination exhaustion. Vec-returning Fast APIs do not port this by checking
   their result size afterward; defer until a real atomic caller-buffer API.
3. `tests/fuzz/block_round_trip.c:34-53,56-94`: numeric -3..19, source truncation to
   128KiB, raw-block compression returning0 as incompressible signal, then raw
   block decode. Current blocked public raw-block/context API. Private candidate
   parser tests or complete frames cannot be described as a full port.
4. `tests/fuzz/dictionary_round_trip.c:38-59`: one-in16 simple numeric branch
   has repeated size/hash assertions, but uses a newly trained dictionary.
   Current partial training adapter; dictionary Fast remains unavailable. Do not
   force dictsize0 merely to admit the case; only naturally observed exact
   training-fallback-to-empty inputs could form a carefully qualified subset.
5. `tests/fuzz/stream_round_trip.c:62-143` calls FUZZ_setRandomParameters; it
   does **not** select a signed numeric level. `zstd_helpers.c:44-56` samples
   concrete parameters and :101-165 adds flags, worker, split/sequence controls.
   Existing partial streaming replay does not become a numeric Fast port.
   Future Fast concrete/live streaming mode is a separate checkpoint.
6. `tests/fuzz/sequence_compression_api.c:366-371` samples -3..22 but requires
   public sequence generation/compression APIs; currently blocked.
   `tests/fuzz/seekable_roundtrip.c:30,46` samples full min..max level but needs
   seekable stream/index APIs; currently blocked.

## Suggested small follow-on work items

1. Review the last-writer proof and independent alias audit; approve extracted
   spans, fixed settings and explicit source-state-only provenance.
2. Implement the bounded external extraction/generation oracle; capture the
   exact source and both original C frames before Rust numeric execution tests.
   Validate generation byte-for-byte independently and freeze fixture hashes.
3. Add the public -1 convenience/request assertion and bidirectional oracle
   against that fixture; maintain partial advanced-entry-point qualification.
4. Separately add the exact simple-round-trip selector and admitted negative
   profiles; preserve unsupported-branch counts and all existing gap reasons.

No repository changes, status changes, compilation, or runtime checks accompany
this document. All proposed output hashes and observed C frame properties remain
pending an approved implementation/capture checkpoint.
