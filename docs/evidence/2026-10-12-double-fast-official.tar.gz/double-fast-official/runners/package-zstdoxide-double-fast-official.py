from pathlib import Path
import hashlib,io,json,re,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-double-fast-official-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
def require(v,m):
 if not v:raise ValueError(m)
e=json.loads((O/'evidence.json').read_bytes());require(e['status']=='passed' and e['source_unchanged'],'completed run')
for n,h in e['source'].items():require(sha((R/n).read_bytes())==h,'source '+n)
count=0
for c in e['commands']:
 b=(O/c['log']).read_bytes();require(c['exit_code']==c['expected_exit'] and sha(b)==c['log_sha256'],'command')
 for n,f,i in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b):require(f==b'0' and i==b'0','tests');count+=int(n)
require(count==77 and len(e['commands'])==19,'counts')
require(b'188 source units remain unported' in (O/'completion-gate.log').read_bytes(),'completion gate')
members={p.name:p.read_bytes() for p in O.iterdir() if p.is_file()}
for n in e['source']:members['source/'+n]=(R/n).read_bytes()
for n in ['check-zstdoxide-double-fast-official.py','package-zstdoxide-double-fast-official.py']:members['runners/'+n]=(Path('/tmp')/n).read_bytes()
members['bootstrap.log']=Path('/tmp/zstdoxide-double-fast-official-bootstrap.log').read_bytes()
report={'date':'2026-10-12','status':'passed','commands':19,'official_test_executions':55,'baseline_test_executions':22,'total_test_executions':77,'source':e['source'],'scope':e['scope'],'source_units_unfinished':188,'fixture_registry':{'files':838,'collections':20},'selector_classifications':{'historical':[57,20,4],'successor':[61,16,4]},'new_selector_cases':['tier-44','tier-49','unsupported-55','unsupported-56'],'loop_successor_classifications':{'empty':[5,19],'initial_match':[3,16]},'inventory_source_status_unchanged':True,'archive':'2026-10-12-double-fast-official.tar.gz'}
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
members['report.json']=enc(report);members['manifest.json']=enc({n:sha(b) for n,b in members.items()})
a=R/'docs/evidence'/report['archive'];require(not a.exists(),'fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('double-fast-official/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:require({m.name:t.extractfile(m).read() for m in t}=={'double-fast-official/'+n:b for n,b in members.items()},'archive exact bytes')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(members))
(R/'docs/evidence/2026-10-12-double-fast-official.json').write_bytes(enc(report));print(len(e['commands']),count,len(members))
