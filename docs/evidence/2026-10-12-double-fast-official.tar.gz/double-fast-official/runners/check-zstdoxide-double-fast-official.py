from pathlib import Path
import hashlib,json,subprocess,sys,time,tomllib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-double-fast-official-2026-10-12');O.mkdir(exist_ok=False)
sys.path.insert(0,str(R/'scripts'));import benchmark_search
env=benchmark_search.effective_environment()|{'CARGO_TARGET_DIR':'/tmp/zstdoxide-double-fast-plan-target','CARGO_NET_OFFLINE':'true','CARGO_TERM_COLOR':'never'}
paths=list((R/'src').rglob('*.rs'))+[R/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/upstream_reference_fast.rs','tests/upstream/manifest.json','tests/upstream/fuzz_support.rs','tests/upstream/reference-fast-fuzz/observations.tsv','tests/reference_fast_defaults.rs','tests/match_search_defaults.rs']]+list((R/'tests/fixtures/reference-admission-v2').iterdir())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source():return {str(p.relative_to(R)):sha(p) for p in sorted(paths)}
e={'date':'2026-10-12','status':'running','scope':'Successor official numeric/fuzz assertions with original selectors, frozen historical classifications and exact newly admitted DoubleFast subsets. Inventory remains partial; no new C execution, Miri or timing.','source':source(),'environment':env,'commands':[]}
def save():(O/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
def run(label,args,expected=0):
 p=O/(label+'.log');start=time.monotonic()
 with p.open('wb') as f:c=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 e['commands'].append(dict(label=label,argv=args,expected_exit=expected,exit_code=c.returncode,seconds=time.monotonic()-start,log=p.name,log_sha256=sha(p)));save();print(label,c.returncode,flush=True)
 if c.returncode!=expected:raise RuntimeError(label)
cargo=['cargo','+nightly-2026-10-08'];flags=[f for f in tomllib.loads((R/'Cargo.toml').read_text())['features'] if f not in ['default','std']]
try:
 run('rustc',['rustc','+nightly-2026-10-08','-vV'])
 for name,f in [('safe',[]),('table',['--features','unsafe-match-table']),('all',['--all-features']),('nostd',['--no-default-features']),('nostd-all',['--no-default-features','--features',','.join(flags)])]:run('official-'+name,cargo+['test','--offline','--locked','--test','upstream_reference_fast']+f)
 for name,f in [('safe',[]),('all',['--all-features'])]:
  run('baselines-'+name,cargo+['test','--offline','--locked','--test','reference_fast_defaults','--test','match_search_defaults']+f)
  run('clippy-'+name,cargo+['clippy','--offline','--locked','--test','upstream_reference_fast']+f+['--','-D','warnings'])
 for name,f in [('safe',[]),('all',['--features',','.join(flags)])]:run('nostd-'+name,cargo+['check','--offline','--locked','--no-default-features']+f)
 for mode,extra in [('normal',[]),('optimized',['-O'])]:
  run('inventory-'+mode,['python3']+extra+['scripts/audit_upstream_tests.py','--upstream','/tmp/zstdoxize-upstream-1.5.7'])
  run('policy-'+mode,['python3']+extra+['scripts/check_reference_admission_v2.py','--check'])
 run('fixtures',['python3','scripts/check_upstream_fixtures.py'])
 run('completion-gate',['python3','scripts/audit_upstream_tests.py','--require-complete'],1)
 run('format',['rustfmt','--edition','2024','--config','skip_children=true','--check','tests/upstream_reference_fast.rs'])
 e['source_unchanged']=source()==e['source'];assert e['source_unchanged'];e['status']='passed';save()
except BaseException as error:e['status']='failed';e['error']=repr(error);save();raise
