from pathlib import Path
import hashlib,io,json,os,re,shutil,subprocess,tarfile,time,shlex
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-module15-final-matrix');OUT.mkdir();WORK=OUT/'source';WORK.mkdir();TARGET=OUT/'target'
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();archive=subprocess.check_output(['git','archive',base],cwd=ROOT)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(WORK,filter='data')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
overlay=[]
for directory in ['src','tests','scripts','examples','benches','test-support','docs']:
 for current,dirs,files in os.walk(ROOT/directory):
  dirs[:]=[d for d in dirs if d not in ['.git','target','__pycache__']]
  for name in files:
   p=Path(current)/name
   if p.suffix=='.pyc':continue
   relative=p.relative_to(ROOT);dest=WORK/relative
   if not dest.exists() or sha(dest)!=sha(p):
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);overlay.append({'path':str(relative),'sha256':sha(dest),'size':dest.stat().st_size})
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','AGENTS.md','TODO.md']:
 p=ROOT/name;dest=WORK/name
 if sha(p)!=sha(dest):shutil.copy2(p,dest);overlay.append({'path':name,'sha256':sha(dest),'size':dest.stat().st_size})
def source():return {str(p.relative_to(WORK)):sha(p) for p in sorted(WORK.rglob('*')) if p.is_file()}
before=source();(OUT/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n');(OUT/'snapshot.json').write_text(json.dumps({'base':base,'base_archive_sha256':hashlib.sha256(archive).hexdigest(),'overlays':overlay},indent=2)+'\n')
# Whitelist execution inputs; no inherited Rust flags/wrappers/target/fuzz corpus.
env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','TMPDIR','TMP','TEMP','SYSTEMROOT','SDKROOT','MACOSX_DEPLOYMENT_TARGET','DEVELOPER_DIR','RUSTUP_HOME','CARGO_HOME']};env.update(CARGO_TARGET_DIR=str(TARGET),CARGO_TERM_COLOR='never',CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C',LANG='C',TZ='UTC')
v={'schema_version':1,'status':'running','base':base,'snapshot':str(OUT/'snapshot.json'),'snapshot_sha256':sha(OUT/'snapshot.json'),'source_before':str(OUT/'source-before.json'),'source_before_sha256':sha(OUT/'source-before.json'),'environment':env,'commands':[],'scope':'Complete scripts/check.sh command matrix with pinned source audit, explicit known-incomplete gate and safe/all usage-doc examples. No benchmark timing and no ignored giant campaign rerun.'}
def save(): (OUT/'evidence.json').write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def run(label,argv,kind='check',expected=0):
 start=time.monotonic();log=OUT/(label+'.log');print('START',label,flush=True)
 code=None;error=None
 with log.open('xb') as f:
  try:r=subprocess.run(argv,cwd=WORK,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200,check=False);code=r.returncode
  except (OSError,subprocess.TimeoutExpired) as e:error=repr(e)
 data=log.read_bytes();counts=[list(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',data)]
 row={'label':label,'argv':argv,'cwd':str(WORK),'exit_code':code,'expected_exit':expected,'exception':error,'seconds':time.monotonic()-start,'log':str(log),'log_sha256':sha(log),'kind':kind}
 if kind in ['full-suite','allocator-suite','doc-examples']:
  row['test_harnesses']=counts;row['totals']=[sum(c[i] for c in counts) for i in range(5)]
  row['ignored_tests']=[x.decode() for x in re.findall(rb'^test (.+) \.\.\. ignored(?:,.*)?$',data,re.M)]
  if not counts or row['totals'][0]==0 or row['totals'][1]!=0 or row['totals'][4]!=0:row['count_error']=True
  if kind=='full-suite' and not all(s in data for s in [b'Running tests/upstream_reference_fast.rs',b'Running tests/reference_double_fast.rs',b'Running tests/reference_double_fast_platform.rs',b'Running tests/reference_greedy.rs',b'Running tests/reference_greedy_platform.rs',b'Running tests/reference_lazy.rs',b'Running tests/reference_lazy_platform.rs']):row['missing_new_target']=True
 if kind=='full-suite':
  preceding=[r for r in v['commands'] if r['kind']=='full-suite']
  if preceding and row['totals']!=preceding[0]['totals']:row['count_error']=True
 if kind=='known-incomplete':
  row['unfinished_source_units']=[int(x) for x in re.findall(rb'Migration incomplete: (\d+) source units remain unported',data)]
  if not row['unfinished_source_units'] or b'Inventory error:' in data:row['count_error']=True
 v['commands'].append(row);save();print('END',label,code,row.get('totals',[]),flush=True)
 if code!=expected or error or row.get('count_error') or row.get('missing_new_target'):raise RuntimeError(label)
try:
 print('SNAPSHOT READY',sha(OUT/'snapshot.json'),flush=True);save()
 run('rustc',['rustc','-Vv']);run('cargo',['cargo','-V'])
 run('inventory-pinned',['python3','scripts/audit_upstream_tests.py','--upstream','/private/tmp/zstdoxide-reference-lazy-1.5.7'])
 run('known-incomplete',['python3','scripts/audit_upstream_tests.py','--require-complete'],'known-incomplete',1)
 for line in (WORK/'scripts/check.sh').read_text().splitlines():
  if line.startswith('cargo fmt'):break
  if line.startswith('python3 '):
   argv=shlex.split(line);run('offline-'+Path(argv[1]).stem,argv)
 run('format',['cargo','fmt','--all','--','--check']);run('allocator-format',['cargo','fmt','--manifest-path','test-support/allocator/Cargo.toml','--','--check'])
 run('allocator-tests',['cargo','test','--offline','--locked','--manifest-path','test-support/allocator/Cargo.toml'],'allocator-suite')
 run('allocator-clippy',['cargo','clippy','--offline','--locked','--manifest-path','test-support/allocator/Cargo.toml','--all-targets','--','-D','warnings'])
 run('tests-safe',['cargo','test','--offline','--locked'],'full-suite')
 run('docs-safe',['python3','scripts/check_doc_examples.py'],'doc-examples')
 run('clippy-safe',['cargo','clippy','--offline','--locked','--all-targets','--','-D','warnings'])
 run('nostd-safe',['cargo','check','--offline','--locked','--no-default-features'])
 flags=['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-reference-chain','unsafe-row-table','unsafe-dictionary','unsafe-training']
 for flag in flags:
  run('tests-'+flag,['cargo','test','--offline','--locked','--features',flag],'full-suite')
  run('nostd-'+flag,['cargo','check','--offline','--locked','--no-default-features','--features',flag])
 run('tests-all',['cargo','test','--offline','--locked','--all-features'],'full-suite')
 run('tests-release-all',['cargo','test','--offline','--locked','--release','--all-features'],'full-suite')
 run('nostd-all',['cargo','check','--offline','--locked','--no-default-features','--features',','.join(flags)])
 run('clippy-all',['cargo','clippy','--offline','--locked','--all-targets','--all-features','--','-D','warnings'])
 run('docs-all',['python3','scripts/check_doc_examples.py','--all-features'],'doc-examples')
 after=source();(OUT/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n');v['source_after']=str(OUT/'source-after.json');v['source_after_sha256']=sha(OUT/'source-after.json');v['source_unchanged']=before==after
 if before!=after:raise RuntimeError('immutable source changed')
 suites=[r for r in v['commands'] if r['kind']=='full-suite'];v['full_suites']=len(suites);v['full_suite_totals']=[sum(r['totals'][i] for r in suites) for i in range(5)];v['status']='passed';save();print('COMPLETE',sha(OUT/'evidence.json'),flush=True)
except BaseException as e:
 v['status']='failed';v['error']=repr(e);save();print('FAILED',repr(e),flush=True);raise
