import sys,random,json,time
from pathlib import Path
sys.path.insert(0,'/tmp')
from ultra_path_model_draft import Replay
from oracles.optimal_paths_wide import Request
class Fast(Replay):
 def emit(self,*args,**kwargs):pass
rng=random.Random(0x155702);found={};start=time.monotonic();attempts=0
for attempt in range(30000):
 attempts+=1
 target=rng.choice([8,12,16,24]);prefix=[];position=1
 for i in range(rng.randrange(3,12)):
  prefix.append((position,((4,target+1),)));position+=target+2
 size=min(512,position+rng.choice([32,48,64,96]));tail=[]
 for pos in range(position,size-8):
  if rng.random()>.32:continue
  ends=sorted(rng.sample(range(3,min(target,size-pos)+1),rng.randrange(1,min(5,target-2))))
  tail.append((pos,tuple((rng.choice([1,2,3,4,5,7,11,19,31]),length)for length in ends)))
 if len(prefix)+len(tail)>64:continue
 r=Request(b'a'*size,tuple(prefix+tail),3,target,rng.randrange(2))
 try:m=Fast(r,2);m.run()
 except ValueError:continue
 for key in m.coverage:
  if key.startswith('ultra_alternative')and key not in found:
   found[key]=dict(attempt=attempt,source_bytes=size,scripts=r.scripts,min_match=r.min_match,target=target,literal_mode=r.literal_mode,coverage=sorted(m.coverage),witnesses=m.witnesses)
   print('FOUND',key,attempt,flush=True);Path('/tmp/ultra-path-alternative-draft-inputs.json').write_text(json.dumps(dict(seed=0x155702,attempts=attempts,seconds=time.monotonic()-start,cases=found),indent=2)+'\n')
 if len(found)==4:break
 if time.monotonic()-start>50:break
print('DONE',attempts,time.monotonic()-start,sorted(found),flush=True)
