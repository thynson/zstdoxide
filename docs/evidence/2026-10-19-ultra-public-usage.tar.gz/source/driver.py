import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/private/tmp/zstdoxide-ultra-public-candidate');out=Path('/private/tmp/ultra-public-usage-checks');out.mkdir();(out/'logs').mkdir();(out/'source').mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
names=['docs/'+n+'-usage.md' for n in ['dictionary','streaming','allocator','parameter','match-search','reference-fast']]+['scripts/check_doc_examples.py']
source={n:sha(root/n) for n in names}
for n in names:
 p=out/'source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/n).read_bytes())
(out/'source/driver.py').write_bytes(Path(__file__).read_bytes())
env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/zstdoxide-ultra-public-usage-target',CARGO_BUILD_JOBS='2')
e=dict(status='running',source=source,commands=[]);path=out/'evidence.json'
for mode,flags in [('safe',[]),('all',['--all-features'])]:
 argv=['python3','-B','scripts/check_doc_examples.py',*flags];log=out/'logs'/(mode+'.log');t=time.monotonic()
 with log.open('xb') as f:p=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 e['commands'].append(dict(label=mode,argv=argv,exit_code=p.returncode,seconds=time.monotonic()-t,log={'path':str(log.relative_to(out)),'bytes':log.stat().st_size,'sha256':sha(log)}));path.write_text(json.dumps(e,indent=2)+'\n');print(mode,p.returncode,flush=True)
 if p.returncode:raise ValueError('usage failed')
if {n:sha(root/n) for n in names}!=source:raise ValueError('source changed')
e.update(status='passed',source_unchanged=True,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat());path.write_text(json.dumps(e,indent=2)+'\n')
