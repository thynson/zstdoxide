from pathlib import Path
import hashlib,json,tarfile
D=Path(__file__).parent;S=Path('/private/tmp/module27-attachment');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((S/'evidence.json').read_text());c=json.loads((S/'clippy.json').read_text());assert b['status']==c['status']=='passed' and len(b['commands'])==46 and len(c['commands'])==4
assert sha(S/'slice_attachment.rs')==b['source_sha256']==c['source_sha256']
assert c['component_evidence_sha256']==sha(S/'evidence.json')
for row in b['commands']+c['commands']:assert row['exit_code']==0
name='2026-10-26-stable-prefix-attachment-state';archive=D/(name+'.tar.gz');assert not archive.exists()
files=[p for p in S.rglob('*') if p.is_file() and 'target' not in p.relative_to(S).parts and not p.name.startswith('test-')]
omitted={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in S.glob('test-*') if p.is_file()}
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(S)))
 t.add(__file__,arcname='archive-attachment.py')
r=dict(status='passed',component=b,strict=c,archive=archive.name,archive_sha256=sha(archive),omitted_unit_test_binaries=omitted,qualification='Standalone ownership component, not integrated into SliceDecoder. All22 backend flag selections run three ownership/lifetime tests; safe/all strict Clippy, warning-free no_std host IR/object emission and formatting pass. Plain value operations have one shared safe representation, no artificial unsafe feature. Unit compiler outputs are reproducible from retained source/commands; their hashes are recorded but binaries are omitted. The initial successful no_std command filename warning and the first strict-driver log-name collision are preserved; the latter is not counted as a passing gate. Prefix format/native/full-matrix/timing work remains separate.')
(D/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(archive.name,archive.stat().st_size)
