; ModuleID = 'probe.1c21c9d3068420d5-cgu.0'
source_filename = "probe.1c21c9d3068420d5-cgu.0"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx11.0.0"

@alloc_6d37ee3a77ed41f696bafa7f77aac302 = private unnamed_addr constant [42 x i8] c"/private/tmp/module27-attachment/probe.rs\00", align 1, !guid !0
@alloc_976064b6503a64c5f0497d417c29d461 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_6d37ee3a77ed41f696bafa7f77aac302, [16 x i8] c")\00\00\00\00\00\00\00\08\00\00\00'\00\00\00" }>, align 8, !guid !1
@alloc_47e279c2415d81556f5a37802afa1a9f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_6d37ee3a77ed41f696bafa7f77aac302, [16 x i8] c")\00\00\00\00\00\00\00\0A\00\00\00&\00\00\00" }>, align 8, !guid !2

; core::mem::replace::<probe::attachment::Attachment<usize>>
; Function Attrs: inlinehint uwtable
define { i64, i64 } @_RINvNtCs8ky83SScw0Q_4core3mem7replaceINtNtCs2pKfeYUG4NR_5probe10attachment10AttachmentjEEBE_(ptr align 8 %dest, i64 %src.0, i64 %src.1) unnamed_addr #0 !guid !7 {
start:
  %_0.0 = load i64, ptr %dest, align 8
  %0 = getelementptr inbounds i8, ptr %dest, i64 8
  %_0.1 = load i64, ptr %0, align 8
  store i64 %src.0, ptr %dest, align 8
  %1 = getelementptr inbounds i8, ptr %dest, i64 8
  store i64 %src.1, ptr %1, align 8
  %2 = insertvalue { i64, i64 } poison, i64 %_0.0, 0
  %3 = insertvalue { i64, i64 } %2, i64 %_0.1, 1
  ret { i64, i64 } %3
}

; probe::prefix_attachment_probe
; Function Attrs: uwtable
define i64 @_RNvCs2pKfeYUG4NR_5probe23prefix_attachment_probe(i64 %value, i1 zeroext %persistent) unnamed_addr #1 !guid !8 {
start:
  %self.i1 = alloca [8 x i8], align 8
  %self.i = alloca [8 x i8], align 8
  %selected = alloca [16 x i8], align 8
  br i1 %persistent, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %0 = getelementptr inbounds i8, ptr %selected, i64 8
  store i64 %value, ptr %0, align 8
  store i64 2, ptr %selected, align 8
  br label %bb3

bb1:                                              ; preds = %start
  %1 = getelementptr inbounds i8, ptr %selected, i64 8
  store i64 %value, ptr %1, align 8
  store i64 1, ptr %selected, align 8
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
; call <probe::attachment::Attachment<usize>>::retained
  %_6 = call align 8 ptr @_RNvMNtCs2pKfeYUG4NR_5probe10attachmentINtB2_10AttachmentjE8retainedB4_(ptr align 8 %selected)
  store ptr %_6, ptr %self.i1, align 8
  %2 = load ptr, ptr %self.i1, align 8
  %3 = ptrtoint ptr %2 to i64
  %4 = icmp eq i64 %3, 0
  %_2.i2 = select i1 %4, i64 0, i64 1
  %5 = trunc nuw i64 %_2.i2 to i1
  br i1 %5, label %_RNvMNtCs8ky83SScw0Q_4core6optionINtB2_6OptionRjE6unwrapCs2pKfeYUG4NR_5probe.exit5, label %bb2.i3

bb2.i3:                                           ; preds = %bb3
; call core::option::unwrap_failed
  call void @_RNvNtCs8ky83SScw0Q_4core6option13unwrap_failed(ptr align 8 @alloc_976064b6503a64c5f0497d417c29d461) #4
  unreachable

_RNvMNtCs8ky83SScw0Q_4core6optionINtB2_6OptionRjE6unwrapCs2pKfeYUG4NR_5probe.exit5: ; preds = %bb3
  %val.i4 = load ptr, ptr %self.i1, align 8
  %before = load i64, ptr %val.i4, align 8
; call <probe::attachment::Attachment<usize>>::claim
  call void @_RNvMNtCs2pKfeYUG4NR_5probe10attachmentINtB2_10AttachmentjE5claimB4_(ptr align 8 %selected)
; call <probe::attachment::Attachment<usize>>::current
  %_12 = call align 8 ptr @_RNvMNtCs2pKfeYUG4NR_5probe10attachmentINtB2_10AttachmentjE7currentB4_(ptr align 8 %selected)
  store ptr %_12, ptr %self.i, align 8
  %6 = load ptr, ptr %self.i, align 8
  %7 = ptrtoint ptr %6 to i64
  %8 = icmp eq i64 %7, 0
  %_2.i = select i1 %8, i64 0, i64 1
  %9 = trunc nuw i64 %_2.i to i1
  br i1 %9, label %_RNvMNtCs8ky83SScw0Q_4core6optionINtB2_6OptionRjE6unwrapCs2pKfeYUG4NR_5probe.exit, label %bb2.i

bb2.i:                                            ; preds = %_RNvMNtCs8ky83SScw0Q_4core6optionINtB2_6OptionRjE6unwrapCs2pKfeYUG4NR_5probe.exit5
; call core::option::unwrap_failed
  call void @_RNvNtCs8ky83SScw0Q_4core6option13unwrap_failed(ptr align 8 @alloc_47e279c2415d81556f5a37802afa1a9f) #4
  unreachable

_RNvMNtCs8ky83SScw0Q_4core6optionINtB2_6OptionRjE6unwrapCs2pKfeYUG4NR_5probe.exit: ; preds = %_RNvMNtCs8ky83SScw0Q_4core6optionINtB2_6OptionRjE6unwrapCs2pKfeYUG4NR_5probe.exit5
  %val.i = load ptr, ptr %self.i, align 8
  %active = load i64, ptr %val.i, align 8
; call <probe::attachment::Attachment<usize>>::release_active
  call void @_RNvMNtCs2pKfeYUG4NR_5probe10attachmentINtB2_10AttachmentjE14release_activeB4_(ptr align 8 %selected)
  %_16 = xor i64 %before, %active
; call <probe::attachment::Attachment<usize>>::retained
  %_19 = call align 8 ptr @_RNvMNtCs2pKfeYUG4NR_5probe10attachmentINtB2_10AttachmentjE8retainedB4_(ptr align 8 %selected)
; call <core::option::Option<&usize>>::copied
  %10 = call { i64, i64 } @_RNvMs1_NtCs8ky83SScw0Q_4core6optionINtB5_6OptionRjE6copiedCs2pKfeYUG4NR_5probe(ptr align 8 %_19)
  %_18.0 = extractvalue { i64, i64 } %10, 0
  %_18.1 = extractvalue { i64, i64 } %10, 1
; call <core::option::Option<usize>>::unwrap_or
  %_17 = call i64 @_RNvMNtCs8ky83SScw0Q_4core6optionINtB2_6OptionjE9unwrap_orCs2pKfeYUG4NR_5probe(i64 %_18.0, i64 %_18.1, i64 0)
  %_0 = xor i64 %_16, %_17
  ret i64 %_0
}

; <probe::attachment::Attachment<usize>>::release_active
; Function Attrs: uwtable
define internal void @_RNvMNtCs2pKfeYUG4NR_5probe10attachmentINtB2_10AttachmentjE14release_activeB4_(ptr align 8 %self) unnamed_addr #1 personality ptr @rust_eh_personality !guid !9 {
start:
  %0 = alloca [16 x i8], align 8
  %_2 = alloca [1 x i8], align 1
  %_3 = load i64, ptr %self, align 8
  %1 = getelementptr inbounds i8, ptr %self, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = icmp eq i64 %_3, 3
  br i1 %3, label %bb2, label %bb1

bb2:                                              ; preds = %start
  store i8 1, ptr %_2, align 1
  br label %bb3

bb1:                                              ; preds = %start
  store i8 0, ptr %_2, align 1
  br label %bb3

bb3:                                              ; preds = %bb1, %bb2
  %4 = load i8, ptr %_2, align 1
  %5 = trunc nuw i8 %4 to i1
  br i1 %5, label %bb4, label %bb7

bb7:                                              ; preds = %bb5, %bb3
  ret void

bb4:                                              ; preds = %bb3
  br label %bb5

bb5:                                              ; preds = %bb4
  store i64 0, ptr %self, align 8
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 undef, ptr %6, align 8
  br label %bb7

bb6:                                              ; No predecessors!
  store i64 0, ptr %self, align 8
  %7 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 undef, ptr %7, align 8
  %8 = load ptr, ptr %0, align 8
  %9 = getelementptr inbounds i8, ptr %0, i64 8
  %10 = load i32, ptr %9, align 8
  %11 = insertvalue { ptr, i32 } poison, ptr %8, 0
  %12 = insertvalue { ptr, i32 } %11, i32 %10, 1
  resume { ptr, i32 } %12
}

; <probe::attachment::Attachment<usize>>::claim
; Function Attrs: uwtable
define internal void @_RNvMNtCs2pKfeYUG4NR_5probe10attachmentINtB2_10AttachmentjE5claimB4_(ptr align 8 %self) unnamed_addr #1 personality ptr @rust_eh_personality !guid !10 {
start:
  %0 = alloca [16 x i8], align 8
  %_8 = alloca [1 x i8], align 1
  %_3 = alloca [16 x i8], align 8
  %_2 = alloca [16 x i8], align 8
  store i8 0, ptr %_8, align 1
; call core::mem::replace::<probe::attachment::Attachment<usize>>
  %1 = call { i64, i64 } @_RINvNtCs8ky83SScw0Q_4core3mem7replaceINtNtCs2pKfeYUG4NR_5probe10attachment10AttachmentjEEBE_(ptr align 8 %self, i64 0, i64 undef)
  %2 = extractvalue { i64, i64 } %1, 0
  %3 = extractvalue { i64, i64 } %1, 1
  store i64 %2, ptr %_3, align 8
  %4 = getelementptr inbounds i8, ptr %_3, i64 8
  store i64 %3, ptr %4, align 8
  store i8 1, ptr %_8, align 1
  %_5 = load i64, ptr %_3, align 8
  %5 = getelementptr inbounds i8, ptr %_3, i64 8
  %6 = load i64, ptr %5, align 8
  %7 = icmp eq i64 %_5, 2
  br i1 %7, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %8 = getelementptr inbounds i8, ptr %_3, i64 8
  %value = load i64, ptr %8, align 8
  %9 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %value, ptr %9, align 8
  store i64 3, ptr %_2, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store i8 0, ptr %_8, align 1
  %other.0 = load i64, ptr %_3, align 8
  %10 = getelementptr inbounds i8, ptr %_3, i64 8
  %other.1 = load i64, ptr %10, align 8
  store i64 %other.0, ptr %_2, align 8
  %11 = getelementptr inbounds i8, ptr %_2, i64 8
  store i64 %other.1, ptr %11, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  br label %bb5

bb5:                                              ; preds = %bb4
  %12 = load i64, ptr %_2, align 8
  %13 = getelementptr inbounds i8, ptr %_2, i64 8
  %14 = load i64, ptr %13, align 8
  store i64 %12, ptr %self, align 8
  %15 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %14, ptr %15, align 8
  %16 = load i8, ptr %_8, align 1
  %17 = trunc nuw i8 %16 to i1
  br i1 %17, label %bb10, label %bb8

bb8:                                              ; preds = %bb9, %bb10, %bb5
  store i8 0, ptr %_8, align 1
  store i8 0, ptr %_8, align 1
  ret void

bb10:                                             ; preds = %bb5
  %_9 = load i64, ptr %_3, align 8
  %18 = getelementptr inbounds i8, ptr %_3, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = icmp eq i64 %_9, 2
  br i1 %20, label %bb8, label %bb9

bb9:                                              ; preds = %bb10
  br label %bb8

bb6:                                              ; No predecessors!
  %21 = load i64, ptr %_2, align 8
  %22 = getelementptr inbounds i8, ptr %_2, i64 8
  %23 = load i64, ptr %22, align 8
  store i64 %21, ptr %self, align 8
  %24 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %23, ptr %24, align 8
  %25 = load i8, ptr %_8, align 1
  %26 = trunc nuw i8 %25 to i1
  br i1 %26, label %bb12, label %bb7

bb7:                                              ; preds = %bb11, %bb12, %bb6
  %27 = load ptr, ptr %0, align 8
  %28 = getelementptr inbounds i8, ptr %0, i64 8
  %29 = load i32, ptr %28, align 8
  %30 = insertvalue { ptr, i32 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i32 } %30, i32 %29, 1
  resume { ptr, i32 } %31

bb12:                                             ; preds = %bb6
  %_10 = load i64, ptr %_3, align 8
  %32 = getelementptr inbounds i8, ptr %_3, i64 8
  %33 = load i64, ptr %32, align 8
  %34 = icmp eq i64 %_10, 2
  br i1 %34, label %bb7, label %bb11

bb11:                                             ; preds = %bb12
  br label %bb7
}

; <probe::attachment::Attachment<usize>>::current
; Function Attrs: uwtable
define internal align 8 ptr @_RNvMNtCs2pKfeYUG4NR_5probe10attachmentINtB2_10AttachmentjE7currentB4_(ptr align 8 %self) unnamed_addr #1 !guid !11 {
start:
  %value = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %_2 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  switch i64 %_2, label %bb1 [
    i64 0, label %bb5
    i64 1, label %bb3
    i64 2, label %bb5
    i64 3, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb5:                                              ; preds = %start, %start
  store ptr null, ptr %_0, align 8
  br label %bb6

bb3:                                              ; preds = %start
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %2, ptr %value, align 8
  br label %bb4

bb2:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %value, align 8
  br label %bb4

bb4:                                              ; preds = %bb2, %bb3
  %_4 = load ptr, ptr %value, align 8
  store ptr %_4, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb4, %bb5
  %4 = load ptr, ptr %_0, align 8
  ret ptr %4
}

; <probe::attachment::Attachment<usize>>::retained
; Function Attrs: uwtable
define internal align 8 ptr @_RNvMNtCs2pKfeYUG4NR_5probe10attachmentINtB2_10AttachmentjE8retainedB4_(ptr align 8 %self) unnamed_addr #1 !guid !12 {
start:
  %value = alloca [8 x i8], align 8
  %_0 = alloca [8 x i8], align 8
  %_2 = load i64, ptr %self, align 8
  %0 = getelementptr inbounds i8, ptr %self, i64 8
  %1 = load i64, ptr %0, align 8
  switch i64 %_2, label %bb1 [
    i64 0, label %bb5
    i64 1, label %bb4
    i64 2, label %bb3
    i64 3, label %bb2
  ]

bb1:                                              ; preds = %start
  unreachable

bb5:                                              ; preds = %start
  store ptr null, ptr %_0, align 8
  br label %bb7

bb4:                                              ; preds = %start
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %2, ptr %value, align 8
  br label %bb6

bb3:                                              ; preds = %start
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %3, ptr %value, align 8
  br label %bb6

bb2:                                              ; preds = %start
  %4 = getelementptr inbounds i8, ptr %self, i64 8
  store ptr %4, ptr %value, align 8
  br label %bb6

bb7:                                              ; preds = %bb6, %bb5
  %5 = load ptr, ptr %_0, align 8
  ret ptr %5

bb6:                                              ; preds = %bb2, %bb3, %bb4
  %_4 = load ptr, ptr %value, align 8
  store ptr %_4, ptr %_0, align 8
  br label %bb7
}

; <core::option::Option<usize>>::unwrap_or
; Function Attrs: inlinehint uwtable
define i64 @_RNvMNtCs8ky83SScw0Q_4core6optionINtB2_6OptionjE9unwrap_orCs2pKfeYUG4NR_5probe(i64 %0, i64 %1, i64 %default) unnamed_addr #0 !guid !13 {
start:
  %x = alloca [8 x i8], align 8
  %self = alloca [16 x i8], align 8
  store i64 %0, ptr %self, align 8
  %2 = getelementptr inbounds i8, ptr %self, i64 8
  store i64 %1, ptr %2, align 8
  %_3 = load i64, ptr %self, align 8
  %3 = getelementptr inbounds i8, ptr %self, i64 8
  %4 = load i64, ptr %3, align 8
  %5 = trunc nuw i64 %_3 to i1
  br i1 %5, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %6 = getelementptr inbounds i8, ptr %self, i64 8
  %7 = load i64, ptr %6, align 8
  store i64 %7, ptr %x, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store i64 %default, ptr %x, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %8 = load i64, ptr %x, align 8
  ret i64 %8

bb1:                                              ; No predecessors!
  unreachable
}

; <core::option::Option<&usize>>::copied
; Function Attrs: uwtable
define { i64, i64 } @_RNvMs1_NtCs8ky83SScw0Q_4core6optionINtB5_6OptionRjE6copiedCs2pKfeYUG4NR_5probe(ptr align 8 %0) unnamed_addr #1 !guid !14 {
start:
  %_0 = alloca [16 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  %1 = load ptr, ptr %self, align 8
  %2 = ptrtoint ptr %1 to i64
  %3 = icmp eq i64 %2, 0
  %_2 = select i1 %3, i64 0, i64 1
  %4 = trunc nuw i64 %_2 to i1
  br i1 %4, label %bb3, label %bb2

bb3:                                              ; preds = %start
  %_4 = load ptr, ptr %self, align 8
  %v = load i64, ptr %_4, align 8
  %5 = getelementptr inbounds i8, ptr %_0, i64 8
  store i64 %v, ptr %5, align 8
  store i64 1, ptr %_0, align 8
  br label %bb4

bb2:                                              ; preds = %start
  store i64 0, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb3, %bb2
  %6 = load i64, ptr %_0, align 8
  %7 = getelementptr inbounds i8, ptr %_0, i64 8
  %8 = load i64, ptr %7, align 8
  %9 = insertvalue { i64, i64 } poison, i64 %6, 0
  %10 = insertvalue { i64, i64 } %9, i64 %8, 1
  ret { i64, i64 } %10

bb1:                                              ; No predecessors!
  unreachable
}

declare i32 @rust_eh_personality(...) unnamed_addr #2

; core::option::unwrap_failed
; Function Attrs: cold noinline noreturn uwtable
declare void @_RNvNtCs8ky83SScw0Q_4core6option13unwrap_failed(ptr align 8) unnamed_addr #3

attributes #0 = { inlinehint uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #1 = { uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #2 = { "target-cpu"="apple-m1" }
attributes #3 = { cold noinline noreturn uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #4 = { noreturn }

!llvm.module.flags = !{!3, !4, !5}
!llvm.ident = !{!6}

!0 = !{i64 7118478752770155593}
!1 = !{i64 3493610532233885329}
!2 = !{i64 -6684574051706482702}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 7, !"frame-pointer", i32 1}
!6 = !{!"rustc version 1.101.0-nightly (1d81eb4ad 2026-10-07)"}
!7 = !{i64 2224977945951533956}
!8 = !{i64 -6091164189718455588}
!9 = !{i64 -1120833509738140293}
!10 = !{i64 -7571710089689988513}
!11 = !{i64 6538869446272432619}
!12 = !{i64 4697845428268923716}
!13 = !{i64 2525694917797201995}
!14 = !{i64 -3000270593081370283}
