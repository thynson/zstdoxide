from pathlib import Path
import json,subprocess,hashlib,time,tomllib
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
features=sorted(f for f in tomllib.loads((R/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'))
source=D/'slice_attachment.rs';e=dict(status='running',source_sha256=sha(source),design_commit='d4dcc23',commands=[],qualification='Standalone plain ownership record only, not integrated decoding. Real dictionary/output access retains its existing storage features; the same value representation is compiled for safe, each isolated feature and all. No decoder full-matrix or prefix interoperability claim.')
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t));save();assert p.returncode==0,label
save()
try:
 for name,selected in [('safe',[]),*[(f,[f]) for f in features],('all',features)]:
  flags=[x for f in selected for x in ['--cfg','feature="'+f+'"']];exe=D/('test-'+name)
  run(name+'-build',['rustc','--edition=2024','--test',str(source),'-Dwarnings','-Dunsafe_op_in_unsafe_fn','-Dclippy::undocumented_unsafe_blocks','--forbid','unsafe_code',*flags,'-o',str(exe)])
  run(name+'-tests',[str(exe)])
  assert '3 passed; 0 failed; 0 ignored' in (D/(name+'-tests.log')).read_text()
 probe=D/'probe.rs';probe.write_text('''#![no_std]
#![forbid(unsafe_code)]
#[path = "slice_attachment.rs"]
mod attachment;
use attachment::Attachment;
#[unsafe(no_mangle)]
pub fn prefix_attachment_probe(value: usize, persistent: bool) -> usize {
    let mut selected = if persistent { Attachment::Persistent(value) } else { Attachment::PendingPrefix(value) };
    let before = *selected.retained().unwrap();
    selected.claim();
    let active = *selected.current().unwrap();
    selected.release_active();
    before ^ active ^ selected.retained().copied().unwrap_or(0)
}
'''.replace('#[unsafe(no_mangle)]\n',''))
 run('no-std',['rustc','--edition=2024','--crate-type=lib','--emit=llvm-ir,obj',str(probe),'-Dwarnings','-o',str(D/'probe')])
 run('format',['rustfmt','--edition','2024','--check',str(source)])
 assert sha(source)==e['source_sha256'];e['status']='passed';save();print('Standalone attachment ownership checks passed:',len(e['commands']))
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
