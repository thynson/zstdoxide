#![no_std]
#![forbid(unsafe_code)]
#[path = "slice_attachment.rs"]
mod attachment;
use attachment::Attachment;
pub fn prefix_attachment_probe(value: usize, persistent: bool) -> usize {
    let mut selected = if persistent { Attachment::Persistent(value) } else { Attachment::PendingPrefix(value) };
    let before = *selected.retained().unwrap();
    selected.claim();
    let active = *selected.current().unwrap();
    selected.release_active();
    before ^ active ^ selected.retained().copied().unwrap_or(0)
}
