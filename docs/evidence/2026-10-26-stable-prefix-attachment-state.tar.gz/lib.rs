#![no_std]
#![forbid(unsafe_code)]
#![deny(unsafe_op_in_unsafe_fn)]
#[cfg(test)]
extern crate std;
// The standalone harness does not expose an integrated decoder yet.
#[allow(dead_code)]
#[path = "slice_attachment.rs"]
mod attachment;
