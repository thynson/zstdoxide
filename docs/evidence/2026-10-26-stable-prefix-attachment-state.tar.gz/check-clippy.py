from pathlib import Path
import json,hashlib,subprocess,os,tomllib
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((D/'evidence.json').read_text());assert base['status']=='passed' and len(base['commands'])==46
features=sorted(f for f in tomllib.loads((R/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'))
(D/'Cargo.toml').write_text('[package]\nname="zstdoxide-attachment-check"\nversion="0.0.0"\nedition="2024"\n[lib]\npath="lib.rs"\n[features]\n'+''.join(f+'=[]\n' for f in features))
(D/'rust-toolchain.toml').write_bytes((R/'rust-toolchain.toml').read_bytes())
(D/'lib.rs').write_text('''#![no_std]
#![forbid(unsafe_code)]
#![deny(unsafe_op_in_unsafe_fn)]
#[cfg(test)]
extern crate std;
// The standalone harness does not expose an integrated decoder yet.
#[allow(dead_code)]
#[path = "slice_attachment.rs"]
mod attachment;
''')
(D/'artifacts').mkdir(exist_ok=True);e=dict(status='running',component_evidence_sha256=sha(D/'evidence.json'),source_sha256=sha(D/'slice_attachment.rs'),commands=[])
def save():(D/'clippy.json').write_text(json.dumps(e,indent=2)+'\n')
env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0'}
save()
try:
 for label,args in [('safe-clippy',['cargo','clippy','--offline','--lib','--tests','--','-D','warnings']),('all-clippy',['cargo','clippy','--offline','--lib','--tests','--all-features','--','-D','warnings']),('no-std-clean',['rustc','--edition=2024','--crate-type=lib','--emit=llvm-ir,obj',str(D/'probe.rs'),'-Dwarnings','--out-dir',str(D/'artifacts')]),('clippy-format',['rustfmt','--edition','2024','--check',str(D/'slice_attachment.rs'),str(D/'lib.rs')])]:
  with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=D,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode));save();assert p.returncode==0,label
  if label=='no-std-clean':assert not (D/(label+'.log')).read_text()
 ir=D/'artifacts/probe.ll';assert any(line.startswith(b'define ') and b'prefix_attachment_probe' in line for line in ir.read_bytes().splitlines())
 assert sha(D/'slice_attachment.rs')==base['source_sha256'];e.update(status='passed',artifacts={str(p.relative_to(D)):sha(p) for p in (D/'artifacts').iterdir()},qualification='Standalone component only. Safe/all strict Clippy and explicit no_std concrete LLVM IR/host object code generation pass. The initial successful rustc command emitted a multi-output filename warning; its unchanged log is preserved, and this additive out-dir invocation is warning-free. Full decoder integration and foreign-platform qualification remain separate.');save();print('Strict component checks passed')
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
