#![no_std]
#![feature(allocator_api)]
#![deny(unsafe_op_in_unsafe_fn)]
#![allow(dead_code)]
extern crate alloc;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/error.rs"] mod error;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/constants.rs"] mod constants;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/greedy_key.rs"] mod greedy_key;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/tree_layout.rs"] mod tree_layout;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_search_layout.rs"] mod optimal_search_layout;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_price.rs"] mod optimal_price;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_frequencies.rs"] mod optimal_frequencies;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_matches.rs"] mod optimal_matches;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_path_layout.rs"] mod optimal_path_layout;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_paths.rs"] mod optimal_paths;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_parse.rs"] mod optimal_parse;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_retained.rs"] mod optimal_retained;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/reference_tree.rs"] mod reference_tree;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_short_key.rs"] mod optimal_short_key;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_search.rs"] mod optimal_search;

pub use error::{Error,Result};
use core::alloc::Allocator;
struct Provider;
impl optimal_parse::PathProvider for Provider {
 fn query<A:Allocator>(&mut self,q:optimal_search_layout::OptimalQuery,m:&mut optimal_matches::OptimalMatches<A>)->Result<()> {
  if q.position==1 {m.push(optimal_search_layout::OptimalMatch::new(4,15)?)?;}Ok(())
 }
}
struct Observer;
impl optimal_parse::PathObserver for Observer {
 fn event<P:Allocator,F:Allocator>(&mut self,_:optimal_parse::PathEvent,_:&optimal_paths::OptimalPaths<P>,_:&optimal_frequencies::OptimalFrequencies<F>,_:&[optimal_search_layout::OptimalMatch])->Result<()>{Ok(())}
}
pub fn exercise()->Result<usize>{
 use alloc::alloc::Global;
 use optimal_search_layout::OptimalSearchLayout;
 let source=[b'a';128];
 let layout=OptimalSearchLayout::new(10,6,6,1,3,0,Some(10))?;
 let owners=[Global;7];let [f,p,m,h,n,s,b]=owners.each_ref();
 let frequencies=optimal_frequencies::OptimalFrequencies::new_in(true,f)?;
 let paths=optimal_paths::OptimalPaths::new_in(p)?;
 let matches=optimal_matches::OptimalMatches::new_in(m)?;
 let parser=optimal_parse::OptimalParser::from_parts(&source,3,0,frequencies,paths,matches)?;
 let search=optimal_search::OptimalSearch::from_parts(&source,layout,
   reference_tree::ReferenceTree::new_in(layout.tree(),h,n)?,
   optimal_short_key::OptimalShortKey::new_in(layout.short_log(),s)?,
   optimal_matches::OptimalMatches::new_in(b)?)?;
 let mut state=optimal_retained::RetainedOptimal::from_parts(parser,search,&[64,64])?;
 let first=state.parse_next(&mut Observer)?;
 state.publish(optimal_retained::Publication::Compressed)?;
 let second=state.parse_next(&mut Observer)?;
 state.publish(optimal_retained::Publication::Rle)?;
 if !state.is_finished(){return Err(Error::CorruptData);}
 state.reset()?;
 let repeated=state.parse_next(&mut Observer)?;
 if first!=repeated{return Err(Error::CorruptData);}
 Ok(first.sequences+second.sequences)
}
