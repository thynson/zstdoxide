from pathlib import Path
import hashlib,json,tarfile,re,tomllib,time
D=Path(__file__).parent;S=Path('/private/tmp/module27-candidate');M=Path('/private/tmp/module27-matrix')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# No-run preparation earns no test credit; collect its logs only after completion.
precompile=M/'release-precompile.json'
while precompile.exists():
 preparation=json.loads(precompile.read_text())
 if preparation['status']!='running':break
 time.sleep(5)
j=json.loads((M/'evidence.json').read_text());assert j['status']=='passed' and len(j['commands'])==69
features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
expected={n+'-'+suffix for n in ['safe','all',*features] for suffix in ['full','no-std','clippy']}|{'safe-release','all-release','format'}
assert {c['label'] for c in j['commands']}==expected
for n,h in j['source'].items():assert sha(S/n)==h,n
b=json.loads((D/'2026-10-26-stable-prefix-output-public-api.json').read_text())
complete={str(p.relative_to(S)):sha(p) for folder in ['src','tests','test-support','benches','examples','scripts'] for p in (S/folder).rglob('*') if p.is_file()}
complete.update({n:sha(S/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']})
for n,h in b['fixture_provenance']['omitted_binary_files'].items():assert sha(S/n)==h,n
expected_counts=None
commands=[]
for c in j['commands']:
 assert c['exit_code']==0
 p=M/(c['label']+'.log');g=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.read_text());assert all(int(f)==0 for _,f,_ in g)
 if c['label'].endswith(('-full','-release')):
  counts=(len(g),sum(int(a) for a,_,_ in g),sum(int(i) for _,_,i in g))
  if expected_counts is None:expected_counts=counts
  assert counts==expected_counts==(91,1628,61),c['label']
 commands.append({**c,'log_sha256':sha(p),'result_groups':len(g),'passed':sum(int(a) for a,_,_ in g),'ignored':sum(int(i) for _,_,i in g)})
name='2026-10-26-stable-prefix-output-feature-matrix';archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(M.iterdir()):
  if p.is_file():t.add(p,arcname='campaign/'+p.name)
 for n in complete:
  if Path(n).suffix in {'.rs','.toml','.lock','.md','.json','.py','.sh','.tsv','.csv'}:t.add(S/n,arcname='source/'+n)
 t.add(__file__,arcname='archive-matrix.py')
result=dict(status='passed',source=j['source'],complete_source=complete,fixture_provenance=b['fixture_provenance'],commands=commands,archive=archive.name,archive_sha256=sha(archive),qualification='Final frozen candidate includes stable-selector streaming fuzz, native prefix, prefix platform and updated persistent/prefix dictionary fuzz adapter tests before the matrix. Safe/all/20 isolated full suites, true no_std and strict Clippy plus safe/all release and formatting pass. External corpus/native ignored adapters have separate explicit execution receipts. A later inventory-only reconciliation is qualified separately; no production/test changes are implied.',full_suite_counts=dict(result_groups=expected_counts[0],passed=expected_counts[1],ignored=expected_counts[2]))
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
