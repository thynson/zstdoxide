"""Resume an interrupted frozen 24--27 matrix, retaining every prior receipt.

This script is deliberately not scheduled. A future explicitly authorized work
window must supply a new UTC deadline. Completed commands are accepted only after
checking exact source hashes, command order/arguments and their zero exit codes.
The original evidence and any interrupted log remain next to the resumed logs so
existing archive drivers collect them. A failed assertion does not silently retry.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,signal,subprocess,time,tomllib,re
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--module',type=int,choices=[24,25,26,27],required=True)
p.add_argument('--deadline',help='New authorized UTC deadline; required for execution')
p.add_argument('--check-only',action='store_true',help='Verify current source and completed logs without changing files or running checks')
p.add_argument('--jobs',type=int,default=6)
a=p.parse_args();assert 1<=a.jobs<=10
end=None
if not a.check_only:
 assert a.deadline,'A newly authorized deadline is required for resumption'
 end=datetime.datetime.fromisoformat(a.deadline);assert end.tzinfo is not None and end.utcoffset().total_seconds()==0
 assert end.timestamp()>time.time()+60,'A new future work window is required'
D=Path(f'/private/tmp/module{a.module}-matrix');S=Path(f'/private/tmp/module{a.module}-candidate');receipt=D/'evidence.json'
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest()
old=json.loads(receipt.read_text());assert old['status'] in (['running','passed','interrupted-at-user-deadline'] if a.check_only else ['interrupted-at-user-deadline']),old['status']
for name,digest in old['source'].items():assert sha(S/name)==digest,('changed source',name)
current_names={str(q.relative_to(S)) for folder in ['src','tests'] for q in (S/folder).rglob('*.rs')}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/upstream/manifest.json'}
assert current_names==set(old['source']),('frozen source inventory changed',sorted(current_names-set(old['source'])),sorted(set(old['source'])-current_names))
slug={24:'stable-output',25:'dictionary-output',26:'stable-dictionary-output',27:'stable-prefix-output'}[a.module]
public=json.loads((Path(f'/private/tmp/module{a.module}-archives')/f'2026-10-26-{slug}-public-api.json').read_text())
for name,digest in public['complete_source'].items():
 if name.startswith('test-support/'):assert sha(S/name)==digest,('test support changed',name)
features=sorted(f for f in tomllib.loads((S/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'))
assert old['features']==features
plan=[]
for name,flags,no in [('safe',[],[]),('all',['--all-features'],['--features',','.join(features)]),*[(f,['--features',f],['--features',f]) for f in features]]:
 plan += [(name+'-full',['cargo','test','--offline','--locked',*flags]),(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*no]),(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])]
plan += [('safe-release',['cargo','test','--offline','--locked','--release']),('all-release',['cargo','test','--offline','--locked','--release','--all-features']),('format',['cargo','fmt','--all','--','--check'])]
assert len(plan)==69 and len(old['commands'])<=len(plan)
if not a.check_only:assert len(old['commands'])<len(plan)
logs={}
for command,(label,args) in zip(old['commands'],plan):
 assert command['label']==label and command['argv']==args and command['exit_code']==0
 q=D/(label+'.log');assert q.is_file();logs[q.name]=sha(q)
 if label.endswith(('-full','-release')):
  groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',q.read_text())
  expected={24:(80,1580,57),25:(84,1598,59),26:(88,1612,60),27:(91,1628,61)}[a.module]
  assert all(int(f)==0 for _,f,_ in groups)
  assert (len(groups),sum(int(v) for v,_,_ in groups),sum(int(v) for _,_,v in groups))==expected,label
if a.check_only:
 print(json.dumps(dict(status='verified-read-only',matrix_status=old['status'],completed_commands=len(old['commands']),next_command=plan[len(old['commands'])][0] if len(old['commands'])<len(plan) else None,qualification='Verified current frozen source hashes, completed command arguments and full-suite log counts. No file writes, tests, process changes or future scheduling.')))
 raise SystemExit(0)
# Verify no existing process still owns this frozen matrix or its compiler target.
ps=subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True)
target=Path(f'/private/tmp/module{a.module}-candidate-target')
assert str(target) not in ps
assert not any(str(D/'check.py') in line for line in ps.splitlines())
assert not any(str(D/'check-release-precompile.py') in line for line in ps.splitlines())
number=1
while (D/f'resume-{number:02}-prior-evidence.json').exists():number+=1
prefix=f'resume-{number:02}'
prior=D/(prefix+'-prior-evidence.json');prior.write_bytes(receipt.read_bytes())
driver=D/(prefix+'-driver.py');driver.write_bytes(Path(__file__).read_bytes())
interrupted=[]
for label,_ in plan[len(old['commands']):]:
 q=D/(label+'.log')
 if q.exists():
  dest=D/(prefix+'-interrupted-'+q.name);assert not dest.exists();q.rename(dest)
  interrupted.append(dict(path=dest.name,sha256=sha(dest)))
e={**old,'status':'running'};e.pop('error',None)
e.setdefault('resumptions',[]).append(dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),deadline_utc=end.isoformat(),prior_receipt=prior.name,prior_sha256=sha(prior),completed_logs=logs,interrupted_logs=interrupted,driver_path=driver.name,driver_sha256=sha(driver),build_jobs=a.jobs,process_snapshot=ps,qualification='Prior completed commands retained with the same exact frozen source and arguments; interrupted commands are rerun, never counted as passed. The prior receipt and interrupted logs remain archived.'))
def save():receipt.write_text(json.dumps(e,indent=2)+'\n')
env={**os.environ,'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':str(a.jobs),'CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
save()
try:
 for label,args in plan[len(old['commands']):]:
  remaining=end.timestamp()-time.time()-30
  if remaining<30:raise TimeoutError('User work window elapsed before '+label)
  started=time.monotonic()
  with (D/(label+'.log')).open('xb') as f:
   child=subprocess.Popen(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=child.wait(timeout=remaining)
   except subprocess.TimeoutExpired:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    raise TimeoutError('User work window elapsed during '+label)
  e['commands'].append(dict(label=label,argv=args,exit_code=code,seconds=time.monotonic()-started));save();print(label,code,flush=True);assert code==0,label
 for name,digest in old['source'].items():assert sha(S/name)==digest,name
 e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except TimeoutError as ex:e.update(status='interrupted-at-user-deadline',error=repr(ex));save();raise
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
