from pathlib import Path
import json,hashlib,shutil,subprocess
T=Path('/private/tmp');D=Path(__file__).parent;R=T/'module27-candidate';A=T/'module27-archives';ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Defer the next full matrix until the preceding milestone and timing close.
closure=ROOT/'docs/evidence/2026-10-26-stable-dictionary-output-closure.json';assert json.loads(closure.read_text())['status']=='passed'
for name in ['engine','public-api','native','platform','corpus']:
 p=A/('2026-10-26-stable-prefix-output-'+name+'.json');j=json.loads(p.read_text());assert j['status']=='passed';assert sha(A/j['archive'])==j['archive_sha256']
assert not (D/'preparation.json').exists()
files={T/'module27-native/rust/stable_prefix_output_native.rs':'tests/stable_prefix_output_native.rs',T/'module27-platform/stable_prefix_output_platform.rs':'tests/stable_prefix_output_platform.rs',T/'module27-fuzz/source/tests/upstream_trained_dictionary_fuzz.rs':'tests/upstream_trained_dictionary_fuzz.rs'}
for source,target in files.items():shutil.copyfile(source,R/target)
m=json.loads((ROOT/'tests/upstream/manifest.json').read_text())
for source in m['sources']:
 if source['path']=='tests/zstreamtest.c':
  for case in source['cases']:
   if case['line_start'] in [1198,1240,1299]:
    case['rust_tests']+=['tests/stable_prefix_output.rs#every_prepared_split_consumes_one_prefix_and_boundary_replacement_keeps_output','tests/stable_prefix_output.rs#replacement_rejection_preserves_counters_output_and_original_selection_at_every_phase','tests/stable_prefix_output_native.rs#pinned_native_stable_prefix_destinations_and_guarded_errors']
    case['reason']+=' Fixed borrowed sessions additionally support prefix-once ownership and transactional clean-boundary replacement. Native stable prefix oracles and actual destination guards qualify common success/error cases and explicit differences: native streaming consumes its prefix on skippable frames, while Rust retains an unclaimed prefix. C opaque context/reset/workspace equivalence is not asserted.'
 if source['path']=='tests/fuzz/dictionary_decompress.c':
  for value in [source,*source['cases']]:
   assert value['status']=='partial'
   value['reason']+=' A separately labelled seven-byte stable prefix supplement now covers all 1,133 prefix selections in the full 12,063-input safe/all corpus, comparing guarded prefix-once output with buffered Rust output. Original tail selectors and training choices remain unchanged; this is not an original one-shot native streaming selector.'
   name='tests/upstream_trained_dictionary_fuzz.rs#fixed_prefix_supplement_preserves_skips_and_rejects_reused_prepared_prefixes'
   if name not in value['rust_tests']:value['rust_tests'].append(name)
(R/'tests/upstream/manifest.json').write_text(json.dumps(m,indent=2)+'\n')
args=['python3','scripts/audit_upstream_tests.py','--upstream',str(T/'module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99')]
with (D/'inventory.log').open('xb') as f:p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
(D/'preparation.json').write_text(json.dumps(dict(status='passed',predecessor_closure_sha256=sha(closure),added_tests={n:sha(R/n) for n in files.values()},manifest_sha256=sha(R/'tests/upstream/manifest.json'),inventory_argv=args,inventory_log_sha256=sha(D/'inventory.log'),qualification='Qualified test additions and metadata merged before the full matrix begins; production source unchanged. Full matrix, performance and closure remain open.'),indent=2)+'\n')
