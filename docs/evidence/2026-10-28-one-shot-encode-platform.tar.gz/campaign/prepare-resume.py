from pathlib import Path
import json,hashlib,datetime,shutil
D=Path(__file__).parent;p=D/'check.py';original=p.read_text();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=original.replace('2026,10,27,7,10,0','2026,10,27,7,40,0')
a=s.index("S=D/'source';");b=s.index('env={',a)
s=s[:a]+'''S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=(D/'evidence.json').read_bytes();old=json.loads(prior);assert old['status']=='failed' and old.get('error','').startswith('TimeoutError('), old.get('error')
assert not (D/'probe').exists(), 'This recovery is limited to the observed Miri-stage cutoff'
for n,h in old['source'].items():assert sha(S/n)==h,n
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');attempt=D/'interrupted-attempts'/stamp;attempt.mkdir(parents=True)
(attempt/'evidence.json').write_bytes(prior);shutil.copyfile(D/'check.py',attempt/'check.py');shutil.copyfile(__file__,attempt/'resume.py')
reused={}
for label in ['safe-clippy','all-clippy','i686-safe','i686-all','s390x-safe','s390x-all']:
 receipt=D/(label+'.json');log=D/(label+'.log')
 if receipt.exists():
  row=json.loads(receipt.read_text());assert row['exit_code']==0 and sha(log)==row['log_sha256'],label
  if label.startswith(('i686-','s390x-')):assert __import__('re').findall(r'test result: ok\\. (\\d+) passed; (\\d+) failed; (\\d+) ignored;',log.read_text())==[('1','0','0')],label
  reused[label]=row
 elif log.exists():log.rename(attempt/log.name)
source=old['source']
'''+s[b:]
s=s.replace("'commands':[]}","'commands':[],'resumption':{'prior_evidence_sha256':hashlib.sha256(prior).hexdigest(),'attempt_directory':str(attempt.relative_to(D)),'reused_labels':sorted(reused),'new_cutoff_utc':'2026-10-27T07:40:00+00:00','qualification':'Reuse only exact successful per-command receipts and logs on the unchanged source; retain cutoff evidence and partial logs. This remains within the original user-authorized seven-hour window.'}}",1)
needle='def run(label,args,cwd,extra):\n t=time.monotonic()';replacement="""def run(label,args,cwd,extra):
 if label in reused:
  row=reused[label];assert row['argv']==args and row['environment']==extra,label;return row
 t=time.monotonic()""";assert needle in s;s=s.replace(needle,replacement)
s=s.replace('a07:10UTC cutoff','a07:40UTC resumed cutoff')
compile(s,str(D/'resume.py'),'exec');(D/'resume.py').write_text(s)
(D/'resume-preparation.json').write_text(json.dumps(dict(status='prepared-not-run',prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_controller_sha256=sha(p),resume_controller_sha256=sha(D/'resume.py'),qualification='Only an actual TimeoutError during the Miri stage permits resume. Active or genuinely failed tests are refused. Source/commands/environments/logs and exact positive test counts must match. Existing successful rows are reused; partial logs are retained. No source or test case changes.'),indent=2)+'\n')
