from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,tomllib,concurrent.futures,datetime,signal
R=Path('/private/tmp/module35-public/source');D=Path(__file__).parent;deadline=datetime.datetime(2026,10,27,7,40,0,tzinfo=datetime.timezone.utc).timestamp()
assert os.getpriority(os.PRIO_PROCESS,0)==19
gate_path=Path('/private/tmp/module35-public-preflight-v2/evidence.json');gate=json.loads(gate_path.read_text());assert gate['status']=='passed' and len(gate['commands'])==9
S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=(D/'evidence.json').read_bytes();old=json.loads(prior);assert old['status']=='failed' and old.get('error','').startswith('TimeoutError('), old.get('error')
assert not (D/'probe').exists(), 'This recovery is limited to the observed Miri-stage cutoff'
for n,h in old['source'].items():assert sha(S/n)==h,n
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');attempt=D/'interrupted-attempts'/stamp;attempt.mkdir(parents=True)
(attempt/'evidence.json').write_bytes(prior);shutil.copyfile(D/'check.py',attempt/'check.py');shutil.copyfile(__file__,attempt/'resume.py')
reused={}
for label in ['safe-clippy','all-clippy','i686-safe','i686-all','s390x-safe','s390x-all']:
 receipt=D/(label+'.json');log=D/(label+'.log')
 if receipt.exists():
  row=json.loads(receipt.read_text());assert row['exit_code']==0 and sha(log)==row['log_sha256'],label
  if label.startswith(('i686-','s390x-')):assert __import__('re').findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text())==[('1','0','0')],label
  reused[label]=row
 elif log.exists():log.rename(attempt/log.name)
source=old['source']
env={**os.environ,'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
e={'status':'running','source':source,'public_preflight_sha256':sha(gate_path),'qualification':'Supplementary candidate platform preflight only; formal Module35 and predecessor closure gates remain pending. Verified nice19, sequential foreign interpretations and a07:40UTC resumed cutoff.','commands':[],'resumption':{'prior_evidence_sha256':hashlib.sha256(prior).hexdigest(),'attempt_directory':str(attempt.relative_to(D)),'reused_labels':sorted(reused),'new_cutoff_utc':'2026-10-27T07:40:00+00:00','qualification':'Reuse only exact successful per-command receipts and logs on the unchanged source; retain cutoff evidence and partial logs. This remains within the original user-authorized seven-hour window.'}}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,cwd,extra):
 if label in reused:
  row=reused[label];assert row['argv']==args and row['environment']==extra,label;return row
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:
  assert time.time()<deadline-30,label
  p=subprocess.Popen(args,cwd=cwd,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:p.wait(timeout=max(1,deadline-time.time()-30))
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   raise TimeoutError('Work window reached during '+label)
 row={'label':label,'argv':args,'environment':extra,'exit_code':p.returncode,'seconds':time.monotonic()-t,'log_sha256':sha(D/(label+'.log'))};(D/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode:raise ValueError(label)
 return row
save()
def interpret(target,suffix):
 rows=[]
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  row=run(suffix+'-'+name,['cargo','miri','test','--offline','--locked','--target',target,'--test','one_shot_encode_platform',*flags,'borrowed_compression_selection_consumes_attempts_and_preserves_wire_guards','--','--exact'],S,{'CARGO_TARGET_DIR':str(D/('miri-'+suffix)),'MIRI_SYSROOT':'/private/tmp/zstdoxide-ultra-miri-'+suffix,'MIRIFLAGS':'-Zmiri-strict-provenance'})
  assert __import__('re').findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (D/(row['label']+'.log')).read_text())==[('1','0','0')];rows.append(row)
 return rows
try:
 for label,flags in [('safe',[]),('all',['--all-features'])]:
  e['commands'].append(run(label+'-clippy',['cargo','clippy','--offline','--locked','--lib','--test','one_shot_encode_platform',*flags,'--','-D','warnings'],S,{'CARGO_TARGET_DIR':str(D/'host-check')}));save()
 with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
  futures=[pool.submit(interpret,t,s) for t,s in [('i686-unknown-linux-gnu','i686'),('s390x-unknown-linux-gnu','s390x')]]
  for f in concurrent.futures.as_completed(futures):e['commands']+=f.result();save()
 probe=D/'probe';subprocess.run(['cp','-cR',str(S),str(probe)],check=True)
 with (probe/'src/lib.rs').open('a') as f:f.write("\n// Instantiate actual prefix and persistent ownership with bounded output on ARM.\n#[inline(never)]\npub fn one_shot_encode_prefix_codegen_probe(input: &[u8], output: &mut [u8], dictionary: DictionaryView<'_>) -> Result<usize> { let mut encoder=OneShotEncoder::with_prefix(dictionary); let result=encoder.compress_into_in(input,output,alloc::alloc::Global); if encoder.prefix_pending() || encoder.dictionary().is_some() { return Err(Error::InvalidState); } result }\n#[inline(never)]\npub fn one_shot_encode_persistent_codegen_probe(input: &[u8], output: &mut [u8], dictionary: DictionaryView<'_>) -> Result<usize> { let mut encoder=OneShotEncoder::with_dictionary(dictionary); let result=encoder.compress_into_in(input,output,alloc::alloc::Global); if encoder.prefix_pending() || encoder.dictionary().is_none() { return Err(Error::InvalidState); } result }\n")

 features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
 for name,flags in [('safe',[]),('all',['--features',','.join(features)])]:
  common=['--offline','--locked','-Zbuild-std=core,alloc','--target','thumbv6m-none-eabi','--no-default-features','--lib',*flags]
  e['commands'].append(run('thumb-'+name+'-check',['cargo','check',*common],S,{'CARGO_TARGET_DIR':str(D/'thumb-check')}));save()
  target=D/('thumb-'+name)
  e['commands'].append(run('thumb-'+name+'-objects',['cargo','rustc','--release',*common,'--','--emit=llvm-ir,obj'],probe,{'CARGO_TARGET_DIR':str(target)}));save()
  ir=[p for p in target.rglob('*.ll') if any(line.startswith(b'define ') and b'one_shot_encode_prefix_codegen_probe' in line for line in p.read_bytes().splitlines())];assert len(ir)==1
  assert b'llvm.memcpy' in ir[0].read_bytes(), 'Actual encoded-output copy not instantiated'
  assert any(line.startswith(b'define ') and b'one_shot_encode_persistent_codegen_probe' in line for line in ir[0].read_bytes().splitlines())
  objects=list(ir[0].parent.glob('*.o'));assert objects
  artifacts=[]
  for p in [ir[0],*objects]:
   if p.suffix=='.o':
    h=p.read_bytes()[:20];assert h[:6]==b'\x7fELF\x01\x01' and int.from_bytes(h[18:20],'little')==40
   q=D/'artifacts'/(name+'-'+p.name);q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q);artifacts.append({'path':str(q.relative_to(D)),'sha256':sha(q)})
  e.setdefault('artifacts',{})[name]=artifacts;save()
 e['commands'].append(run('format',['cargo','fmt','--all','--','--check'],S,{}));save();assert len(e['commands'])==11
 for n,h in source.items():
  assert sha(S/n)==h,n
  if n.startswith('src/'):assert sha(R/n)==h,n
 e.update(status='passed',qualification='Supplementary candidate platform preflight: four strict-provenance i686/s390x safe/all executions of actual raw/prepared selection, empty/success/short attempts, prefix consumption, persistent recovery, exact stateless bytes, dictionary identifier endian layout, known size, independent decode and guards. Four thumbv6m core+alloc check/object commands instantiate both prefix and persistent compression plus output copies. Two strict Clippy checks and format pass. Interpreter/code-generation evidence only, not foreign hardware execution. Formal predecessor/core/public/full-feature/release/benchmark gates remain separate.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
