/* External supplementary oracle for streaming compiled dictionaries against pinned v1.5.7. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "zstd_errors.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

static const char *dict_names[2] = {"raw-a", "prepared-a"};
static unsigned char *dicts[2];
static size_t dict_sizes[2];
static ZSTD_DDict *ddicts[2];
static const char *input_root, *output_root;

static void path_of(char *path, size_t capacity, const char *root, const char *name, const char *suffix) {
    int n = snprintf(path, capacity, "%s/%s.%s", root, name, suffix);
    if (n < 0 || (size_t)n >= capacity) exit(21);
}
static unsigned char *read_file(const char *root, const char *name, const char *suffix, size_t *size) {
    char path[4096]; FILE *f; long n; unsigned char *p;
    path_of(path, sizeof(path), root, name, suffix); f = fopen(path, "rb");
    if (!f || fseek(f, 0, SEEK_END) || (n = ftell(f)) < 0 || fseek(f, 0, SEEK_SET)) exit(22);
    *size = (size_t)n; p = malloc(*size ? *size : 1);
    if (!p || fread(p, 1, *size, f) != *size || fclose(f)) exit(23);
    return p;
}
static void write_file(const char *name, const char *suffix, const void *bytes, size_t size) {
    char path[4096]; FILE *f;
    path_of(path, sizeof(path), output_root, name, suffix);
    f = fopen(path, "wb");
    if (!f || fwrite(bytes, 1, size, f) != size || fclose(f)) exit(24);
}
static void guards(const unsigned char *p, size_t capacity) {
    size_t i;
    for (i = 0; i < 16; i++) if (p[i] != 0xa5 || p[16 + capacity + i] != 0xa5) exit(25);
}
static int dict_index(const char *name) {
    int i;
    for (i = 0; i < 2; i++) if (!strcmp(name, dict_names[i])) return i;
    exit(26);
}
static ZSTD_dictContentType_e content_type(int index) { return index == 1 ? ZSTD_dct_fullDict : ZSTD_dct_rawContent; }
static int decode_matches(ZSTD_DCtx *dc, int index, const unsigned char *frame, size_t frame_size,
                          const unsigned char *input, size_t n) {
    unsigned char *out = malloc(n + 32);
    size_t result; int equal;
    if (!out) exit(31);
    memset(out, 0xa5, n + 32);
    result = ZSTD_decompress_usingDDict(dc, out + 16, n, frame, frame_size, ddicts[index]);
    guards(out, n);
    equal = !ZSTD_isError(result) && result == n && !memcmp(out + 16, input, n);
    free(out);
    return equal;
}
/* Feed one frame in fixed fragments and a bounded output window. */
static int stream_frame(ZSTD_CCtx *cc, const unsigned char *input, size_t n, size_t chunk,
                        size_t outchunk, unsigned char *out, size_t cap, size_t *frame_size) {
    size_t in_pos = 0, out_pos = 0;
    for (;;) {
        size_t remain = n - in_pos;
        size_t take = remain < chunk ? remain : chunk;
        int last = in_pos + take == n;
        ZSTD_inBuffer in;
        ZSTD_outBuffer outb;
        ZSTD_EndDirective mode = last ? ZSTD_e_end : ZSTD_e_continue;
        size_t ocap = cap - out_pos, ret;
        if (ocap > outchunk) ocap = outchunk;
        if (ocap == 0) return 0;
        in.src = input + in_pos; in.size = take; in.pos = 0;
        outb.dst = out + out_pos; outb.size = ocap; outb.pos = 0;
        ret = ZSTD_compressStream2(cc, &outb, &in, mode);
        if (ZSTD_isError(ret)) return 0;
        in_pos += in.pos; out_pos += outb.pos;
        if (last && ret == 0) { *frame_size = out_pos; return 1; }
    }
}
int main(int argc, char **argv) {
    FILE *steps; char input_path[4096], path[4096], id[128], dict[64], input_name[64];
    int level, window, frames, i; unsigned long chunk, outchunk;
    size_t rows = 0, supported = 0;
    ZSTD_CCtx *cc; ZSTD_DCtx *dc;
    if (argc != 3 || ZSTD_versionNumber() != 10507) return 2;
    if (snprintf(input_path, sizeof(input_path), "%s/inputs", argv[1]) < 0) return 3;
    input_root = input_path; output_root = argv[2];
    for (i = 0; i < 2; i++) {
        dicts[i] = read_file(input_root, dict_names[i], "dict", &dict_sizes[i]);
        ddicts[i] = ZSTD_createDDict_advanced(dicts[i], dict_sizes[i], ZSTD_dlm_byRef,
                                             content_type(i), ZSTD_defaultCMem);
        if (!ddicts[i]) return 4;
    }
    path_of(path, sizeof(path), argv[1], "steps", "tsv");
    steps = fopen(path, "r");
    cc = ZSTD_createCCtx(); dc = ZSTD_createDCtx();
    if (!steps || !cc || !dc) return 5;
    while ((i = fscanf(steps, "%127s %d %d %63s %63s %lu %lu %d", id, &level, &window, dict,
                       input_name, &chunk, &outchunk, &frames)) == 8) {
        size_t n, cap, frame_size, total = 0;
        int index = dict_index(dict), rust_decode = -1;
        unsigned char *input = read_file(input_root, input_name, "input", &n);
        ZSTD_compressionParameters cparams = ZSTD_getCParams(level, 0, dict_sizes[index]);
        ZSTD_CDict *cdict;
        char frame_name[256];
        if (!chunk || !outchunk || frames <= 0) return 30;
        if (window) cparams.windowLog = (unsigned)window;
        cdict = ZSTD_createCDict_advanced(dicts[index], dict_sizes[index], ZSTD_dlm_byRef,
                                          content_type(index), cparams, ZSTD_defaultCMem);
        if (!cdict) return 6;
        cap = ZSTD_compressBound(n) + 64;
        if (ZSTD_CCtx_reset(cc, ZSTD_reset_session_and_parameters)) return 7;
        if (ZSTD_isError(ZSTD_CCtx_refCDict(cc, cdict))) return 8;
        for (i = 0; i < frames; i++) {
            size_t changed = 0;
            unsigned char *storage = malloc(cap + 32);
            if (!storage) return 9;
            memset(storage, 0xa5, cap + 32);
            if (!stream_frame(cc, input, n, (size_t)chunk, (size_t)outchunk, storage + 16, cap,
                              &frame_size)) return 10;
            guards(storage, cap);
            for (size_t j = 0; j < cap - frame_size; j++)
                if (storage[16 + frame_size + j] != 0xa5) changed++;
            if (changed) return 11;
            if (!decode_matches(dc, index, storage + 16, frame_size, input, n)) return 12;
            snprintf(frame_name, sizeof(frame_name), "%s-%d", id, i);
            write_file(frame_name, "zst", storage + 16, frame_size);
            total += frame_size;
            free(storage);
        }
        {
            int have_all = 1;
            for (i = 0; i < frames; i++) {
                char rust_path[4096]; FILE *f; char rust_name[256];
                snprintf(rust_name, sizeof(rust_name), "%s-%d", id, i);
                path_of(rust_path, sizeof(rust_path), input_root, rust_name, "rust");
                f = fopen(rust_path, "rb");
                if (!f) { have_all = 0; break; }
                if (fseek(f, 0, SEEK_END)) return 13;
                {
                    long m = ftell(f);
                    unsigned char *rust;
                    if (m < 0 || fseek(f, 0, SEEK_SET)) return 13;
                    rust = malloc((size_t)m ? (size_t)m : 1);
                    if (!rust || fread(rust, 1, (size_t)m, f) != (size_t)m || fclose(f)) return 14;
                    if (!decode_matches(dc, index, rust, (size_t)m, input, n)) have_all = 0;
                    free(rust);
                }
                if (!have_all) break;
            }
            if (have_all) { rust_decode = 1; supported++; } else rust_decode = -1;
        }
        printf("%s\tok\t%zu\t%d\t0\t%d\t1\t1\n", id, total, frames, rust_decode);
        free(input); ZSTD_freeCDict(cdict);
        rows++;
    }
    if (i != EOF || ferror(steps) || fclose(steps)) return 15;
    if (rows != 12 || supported != 10) return 16;
    ZSTD_freeCCtx(cc); ZSTD_freeDCtx(dc);
    for (i = 0; i < 2; i++) {
        size_t again;
        unsigned char *copy = read_file(input_root, dict_names[i], "dict", &again);
        if (again != dict_sizes[i] || memcmp(copy, dicts[i], again)) return 17;
        free(copy); ZSTD_freeDDict(ddicts[i]); free(dicts[i]);
    }
    return 0;
}
