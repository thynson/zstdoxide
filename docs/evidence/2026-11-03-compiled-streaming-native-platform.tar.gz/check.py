"""Module38 guarded native streaming and concrete atomic-free ARM checks.

Normal and sanitized pinned v1.5.7 streaming controls use
ZSTD_CCtx_refCDict + ZSTD_compressStream2 with tiny caller output windows,
window-capped inputs, a multi-block source and two consecutive frames that
retain the compiled dictionary. Rust streaming frames decode natively and
native frames decode in Rust. Unsupported Optimal/Ultra2 compiled construction
is asserted on the Rust side. Concrete thumbv6m checks and release IR/objects
cover the safe and all-feature library. No Miri runs because no unsafe code was
added.
"""
from pathlib import Path
import datetime, hashlib, json, os, re, shutil, signal, subprocess, time

D = Path(__file__).parent
S = D / 'source'
U = Path('/private/tmp/module24-preparation/zstd-git')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
deadline = datetime.datetime.fromisoformat(datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat()) .timestamp() + 3 * 3600
ALL = 'unsafe-bitstream,unsafe-byte-cursor,unsafe-dictionary,unsafe-frame-sink,unsafe-fse,unsafe-fse-encoder,unsafe-history,unsafe-huffman,unsafe-huffman-codebook,unsafe-in-place-buffer,unsafe-match-chain,unsafe-match-table,unsafe-optimal-frequencies,unsafe-optimal-matches,unsafe-optimal-paths,unsafe-optimal-short-key,unsafe-reference-chain,unsafe-reference-tree,unsafe-ring-history,unsafe-row-table,unsafe-slice-history,unsafe-training'
env = {**os.environ, 'CARGO_TARGET_DIR': str(D / 'target'), 'CARGO_BUILD_JOBS': '6',
       'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
       'CARGO_PROFILE_TEST_OPT_LEVEL': '1', 'CARGO_PROFILE_DEV_DEBUG': '0'}

assert not S.exists()
shutil.copytree('/Users/lanxingcan/Workspace/zstdoxize', S,
                ignore=shutil.ignore_patterns('.git', 'target', 'SESSION_HANDOFF.md'))

source = {}
for folder in ['src', 'tests', 'test-support']:
    for p in (S / folder).rglob('*'):
        if p.is_file():
            source[str(p.relative_to(S))] = sha(p)
for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']:
    source[n] = sha(S / n)
library = {str(p.relative_to(U)): sha(p) for p in (U / 'lib').rglob('*')
           if p.is_file() and p.suffix in ['.c', '.h', '.S']}
assert not (D / 'evidence.json').exists()
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         deadline_utc=datetime.datetime.fromtimestamp(deadline, datetime.timezone.utc).isoformat(),
         source=source, production_source={n: h for n, h in source.items() if n.startswith('src/')},
         reference_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=U, text=True).strip(),
         library=library, helper_sha256=sha(D / 'compiled_stream_oracle.c'), commands=[],
         qualification='Focused Module38 native streaming item only: 12 typed schedules cover supported Fast/DoubleFast/chain/tree streaming profiles, raw/formatted attachments, tiny output windows, a window-capped dictionary, a multi-block source and two frames that retain the compiled dictionary; Optimal/Ultra2 remain unsupported Rust compiled construction and native-only controls. Every Rust streaming frame decodes natively and every native streaming frame decodes in Rust. Native byte/workspace identity is not required. Concrete thumbv6m checks and IR/objects cover safe and all-feature builds. No full matrix, timing or milestone closure is claimed.')


def save():
    (D / 'evidence.json').write_text(json.dumps(e, indent=2) + '\n')


def run(label, args, extra=None, cwd=S, expected=None):
    remaining = deadline - time.time() - 30
    if remaining < 30:
        raise TimeoutError('deadline before ' + label)
    e['active_command'] = dict(label=label, argv=args, environment=extra or {},
                               started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    start = time.monotonic()
    log = D / (label + '.log')
    with log.open('xb') as f:
        p = subprocess.Popen(args, cwd=cwd, env={**env, **(extra or {})}, stdout=f,
                             stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = p.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGTERM)
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                p.wait()
            raise TimeoutError('deadline during ' + label)
    row = dict(label=label, argv=args, environment=extra or {}, exit_code=code,
               seconds=time.monotonic() - start, log_sha256=sha(log))
    if code == 0 and expected is not None:
        groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text())
        assert groups == [(str(expected), '0', '0')], (label, groups)
        row.update(passed=expected, failed=0, ignored=0)
    e['commands'].append(row)
    e.pop('active_command', None)
    save()
    print(label, code, flush=True)
    assert code == 0, (label, log.read_text()[-4000:])


def inventory(folder):
    return {str(p.relative_to(folder)): sha(p) for p in folder.rglob('*') if p.is_file()}


save()
try:
    export = D / 'export'
    export.mkdir(exist_ok=True)
    run('safe-export', ['cargo', 'test', '--offline', '--locked', '--test', 'compiled_stream_native',
                        'compiled_stream_schedules_interoperate_with_guarded_native_controls',
                        '--', '--ignored', '--exact', '--nocapture'],
        dict(ZSTDOXIDE_COMPILED_STREAM_NATIVE=str(export), ZSTDOXIDE_COMPILED_STREAM_EXPORT='1'),
        expected=1)
    e['inputs'] = inventory(export)
    save()
    sources = sorted((U / 'lib/common').glob('*.c')) + sorted((U / 'lib/decompress').glob('*.c')) + sorted((U / 'lib/compress').glob('*.c'))
    for label, flags in [('normal', ['-O2']),
                         ('sanitized', ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer'])]:
        exe = D / ('oracle-' + label)
        run(label + '-build', ['cc', '-std=c99', '-Wall', '-Wextra', '-Werror', '-DZSTD_MULTITHREAD=0',
                               '-I' + str(U / 'lib'), '-I' + str(U / 'lib/common'), *flags,
                               str(D / 'compiled_stream_oracle.c'),
                               *[str(p) for p in sources], '-o', str(exe)])
        e.setdefault('executables', {})[label] = sha(exe)
        save()
        output = export / ('outputs' if label == 'normal' else 'outputs-' + label)
        output.mkdir(exist_ok=True)
        run(label + '-capture', [str(exe), str(export), str(output)],
            dict(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',
                 UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'), cwd=D)
        shutil.copyfile(D / (label + '-capture.log'), D / (label + '.tsv'))
    normal = (D / 'normal.tsv').read_text().splitlines()
    assert len(normal) == 12, len(normal)
    assert (D / 'normal.tsv').read_bytes() == (D / 'sanitized.tsv').read_bytes()
    assert inventory(export / 'outputs') == inventory(export / 'outputs-sanitized')
    shutil.copyfile(D / 'normal.tsv', export / 'native.tsv')
    outputs = inventory(export / 'outputs')
    assert len(outputs) == 13, len(outputs)  # 11 single frames + 2 in the multiframe case
    rows = [line.split('\t') for line in normal]
    assert all(len(row) == 8 and row[1] == 'ok' and row[6] == '1' for row in rows)
    assert sum(row[5] == '1' for row in rows) == 10
    assert sum(row[5] == '-1' for row in rows) == 2
    assert sum(int(row[3]) for row in rows) == 13
    # Replay native frames through the public Rust streaming test.
    run('safe-replay', ['cargo', 'test', '--offline', '--locked', '--test', 'compiled_stream_native',
                        'compiled_stream_schedules_interoperate_with_guarded_native_controls',
                        '--', '--ignored', '--exact', '--nocapture'],
        dict(ZSTDOXIDE_COMPILED_STREAM_NATIVE=str(export)), expected=1)
    e['native_tsv'] = normal
    save()
    run('safe-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--tests', '--', '-D', 'warnings'])
    run('all-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--tests', '--all-features', '--', '-D', 'warnings'])
    e['artifacts'] = {}
    save()
    for label, flags in [('safe', []), ('all', ['--features', ALL])]:
        run('thumb-' + label + '-check', ['cargo', 'check', '--offline', '--locked',
                                          '-Zbuild-std=core,alloc', '--target', 'thumbv6m-none-eabi',
                                          '--lib', '--no-default-features', *flags])
        target_dir = D / ('target-' + label)
        run('thumb-' + label + '-objects', ['cargo', 'rustc', '--release', '--offline', '--locked',
                                            '-Zbuild-std=core,alloc', '--target', 'thumbv6m-none-eabi',
                                            '--target-dir', str(target_dir), '--no-default-features',
                                            '--lib', *flags, '--', '--emit=llvm-ir,obj'])
        for suffix in ['.ll', '.o']:
            candidates = sorted(target_dir.rglob('*' + suffix), key=lambda p: p.stat().st_mtime)
            assert candidates, (label, suffix)
            e['artifacts'][label + suffix] = sha(candidates[-1])
        save()
    run('format', ['cargo', 'fmt', '--all', '--', '--check'])
    for n, h in source.items():
        assert sha(S / n) == h, ('Final source changed during campaign', n)
    e['status'] = 'complete'
    e['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    e['outputs'] = outputs
    save()
    print('complete', flush=True)
except BaseException as error:
    e['status'] = 'failed'
    e['error'] = repr(error)
    save()
    raise
