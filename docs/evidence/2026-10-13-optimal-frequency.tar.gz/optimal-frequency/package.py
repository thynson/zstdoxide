from pathlib import Path
import hashlib,io,json,subprocess,tarfile
R=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize');sha=lambda b:hashlib.sha256(b).hexdigest();enc=lambda v:(json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
roots={k:Path('/tmp/zstdoxide-'+n+'-checks') for k,n in [('focused','optimal-frequency-v2'),('miri','optimal-frequency-platform-v2'),('thumb','optimal-frequency-thumb')]};reports={};files={}
def need(v,s):
 if not v:raise ValueError(s)
for kind,root in roots.items():
 e=json.loads((root/'evidence.json').read_bytes());need(e['status']=='passed','passed '+kind);reports[kind]=e
 for c in e['commands']:
  need(c['exit_code']==0 and sha((root/c['log']).read_bytes())==c['sha256'],'command '+kind)
 for n,h in e['source'].items():
  b=(R/n).read_bytes();need(sha(b)==h,'source '+n);files['source/'+n]=b
 for p in root.rglob('*'):
  if p.is_file():files[kind+'/'+str(p.relative_to(root))]=p.read_bytes()
for name in ['optimal-frequency','optimal-frequency-platform']:
 root=Path('/tmp/zstdoxide-'+name+'-checks')
 for p in root.rglob('*'):
  if p.is_file():files['initial/'+name+'/'+str(p.relative_to(root))]=p.read_bytes()
for name in ['optimal-frequency-checks','optimal-frequency-v2-checks','optimal-frequency-platform-checks','optimal-frequency-platform-v2-checks','optimal-frequency-thumb-checks']:
 files['runners/'+name+'.py']=Path('/tmp/zstdoxide-'+name+'.py').read_bytes()
for p in Path('/tmp/zstdoxide-optimal-frequency-thumb-target/thumbv6m-none-eabi/debug/build/optimal-frequency-thumb').rglob('*.rlib'):
 files['thumb-codegen/'+p.name]=p.read_bytes()
need(len([n for n in files if n.startswith('thumb-codegen/')])==2,'both monomorphized caller artifacts')
e=reports['focused'];owners=[c for c in e['commands'] if c['label'].startswith('owner-')];nostd=[c for c in e['commands'] if c['label'].startswith('nostd-')]
need(len(owners)==19 and all(c['tests']==[[8,0,0]] for c in owners),'152 focused tests')
need(len(nostd)==18 and all('--no-default-features' in c['argv'] and '--all-features' not in c['argv'] for c in nostd),'18 genuine no_std')
need(len(reports['miri']['commands'])==42 and len(reports['thumb']['commands'])==5,'platform totals')
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();need(base.startswith('1fb5249'),'isolated integration base')
need(not subprocess.check_output(['git','diff','--','tests','test-support'],cwd=R),'unchanged inherited test inputs')
files['tracked-change.patch']=subprocess.check_output(['git','diff','--binary'],cwd=R);files['package.py']=Path(__file__).read_bytes()
report=dict(date='2026-10-13',status='passed',base=base,branch='codex/optimal-frequency',source=e['source'],focused_configurations=19,focused_tests=152,captured_transitions_per_configuration=2018,captured_queries_per_configuration=1420,no_std_configurations=18,public_and_predecessor_tests=54,strict_provenance_interpretations=42,thumb_library_configurations=3,thumb_concrete_callers=2,archive='2026-10-13-optimal-frequency.tar.gz',qualification='Private scalar/frequency modules and isolated unsafe leaf only. Public strategy7 remains unsupported; separate branch pending integration after Module16 closure. No full library-wide matrix, native foreign execution or timing claim. Initial allocator test used wrong ordinal type, fixed before final checks; initial new-feature gate and default Miri cache-path failures are preserved, corrected by explicit feature admission and existing pinned temporary sysroots.')
files['report.json']=enc(report);files['manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())});a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('optimal-frequency/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:actual={i.name:t.extractfile(i).read() for i in t}
need(actual=={'optimal-frequency/'+n:b for n,b in files.items()},'archive exact bytes');report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files));(R/'docs/evidence/2026-10-13-optimal-frequency.json').write_bytes(enc(report));print(len(files),a.stat().st_size)
