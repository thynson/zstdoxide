#![no_std]
#![feature(allocator_api)]
#![deny(unsafe_op_in_unsafe_fn)]
#![allow(dead_code)]
extern crate alloc;
#[path="/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize/src/error.rs"] mod error;
pub use error::{Error, Result};
#[path="/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize/src/constants.rs"] mod constants;
#[path="/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize/src/optimal_price.rs"] mod optimal_price;
#[path="/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize/src/optimal_frequencies.rs"] mod optimal_frequencies;
pub fn exercise(input: &[u8]) -> Result<[u32; 3]> {
    let mut model = optimal_frequencies::OptimalFrequencies::new_in(false, alloc::alloc::Global)?;
    model.begin_block(input)?;
    model.update(&input[..input.len().min(15)], 1, 3)?;
    model.refresh()?;
    model.prices(input, input.len() as u32, 1, 3)
}
