from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize');O=Path('/tmp/zstdoxide-optimal-frequency-platform-v2-checks');O.mkdir();env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR']};env.update(RUSTUP_TOOLCHAIN='nightly-2026-10-08',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-frequency-miri-target',MIRIFLAGS='-Zmiri-strict-provenance')
paths=[str(p.relative_to(R)) for p in (R/'src').rglob('*.rs')]+['Cargo.toml','Cargo.lock','rust-toolchain.toml','test-support/allocator/src/lib.rs','tests/support/optimal_price_fixture.rs','tests/fixtures/reference-optimal-prices/cases.bin'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths};commands=[]
selectors=['phase_and_invalid_requests_preserve_the_complete_model','counter_overflow_rejects_without_partial_literal_or_symbol_updates','malformed_live_length_and_scalar_indices_reject_before_access','borrowed_non_clone_owner_outlives_source_and_reset_reuses_storage','initial_allocation_failure_drops_the_exact_moved_owner','disabled_literals_and_predefined_transition_keep_separate_statistics','malformed_consumed_statistics_reject_without_mutation']
def save(status='running',error=None):
 v=dict(status=status,source=source,commands=commands,strict_provenance=True,qualification='Selected private frequency ownership, phase, overflow and malformed-state tests interpreted on i686 and s390x under safe/isolated/all builds; no native foreign claim.')
 if error:v['error']=error
 (O/'evidence.json').write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
try:
 for target in ['i686-unknown-linux-gnu','s390x-unknown-linux-gnu']:
  for mode,flags in [('safe',[]),('frequency',['--features','unsafe-optimal-frequencies']),('all',['--all-features'])]:
   for index,test in enumerate(selectors):
    env['MIRI_SYSROOT']='/tmp/zstdoxide-platform-sysroot-'+target.split('-')[0]
    label=target+'-'+mode+'-'+str(index);argv=['cargo','miri','test','--offline','--locked','--target',target,*flags,'--lib','--','--exact','optimal_frequencies::tests::'+test];log=O/(label+'.log');start=time.monotonic();print('START',label,flush=True)
    with log.open('wb') as f:p=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
    b=log.read_bytes();commands.append(dict(label=label,argv=argv,exit_code=p.returncode,seconds=time.monotonic()-start,environment={k:env[k] for k in ('MIRI_SYSROOT','MIRIFLAGS','CARGO_TARGET_DIR','RUSTUP_TOOLCHAIN')},log=log.name,sha256=hashlib.sha256(b).hexdigest()));save()
    if p.returncode or b'test result: ok. 1 passed; 0 failed; 0 ignored;' not in b:raise ValueError(label)
    print('END',label,flush=True)
 if source!={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}:raise ValueError('source changed')
 save('passed')
except BaseException as e:save('failed',repr(e));raise
