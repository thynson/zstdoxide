from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize');O=Path('/tmp/zstdoxide-optimal-frequency-checks');O.mkdir();env=os.environ.copy();env.update(CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-frequency-target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
features=['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-reference-chain','unsafe-reference-tree','unsafe-row-table','unsafe-dictionary','unsafe-training','unsafe-optimal-frequencies']
paths=[str(p.relative_to(R)) for p in (R/'src').rglob('*.rs')]+['Cargo.toml','Cargo.lock','rust-toolchain.toml','scripts/check.sh','docs/data-structures.md','tests/support/optimal_price_fixture.rs','tests/fixtures/reference-optimal-prices/cases.bin','test-support/allocator/src/lib.rs'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths};rows=[]
def save(status='running',error=None):
 value=dict(status=status,commands=rows,source=source,features=features,qualification='Private frequency owner integration in an isolated branch; public Optimal remains unsupported. Focused owner/captured-state tests in safe/every-leaf/all/release-all, all corresponding true no_std checks, safe/all Clippy and predecessor public/baseline regressions. No complete library-wide feature matrix or performance claim; Module16 retains its independent snapshot.')
 if error:value['error']=error
 (O/'evidence.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def run(label,args,tests=None):
 log=O/(label+'.log');start=time.monotonic();print('START',label,flush=True)
 with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest());rows.append(r);save();print('END',label,p.returncode,flush=True)
 counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)]
 if tests is not None:
  r['tests']=counts
  if counts!=[tests]:raise ValueError('test totals '+label)
 if label.startswith('public-'):
  if len(counts)!=3 or any(f or i for _,f,i in counts):raise ValueError('public counts')
  r['tests']=counts
 if p.returncode:raise ValueError(label)
 save()
try:
 configs=[('safe',[]),('unsafe-optimal-frequencies',['--features','unsafe-optimal-frequencies']),('all',['--all-features']),('release-all',['--release','--all-features'])]+[(f,['--features',f]) for f in features if f!='unsafe-optimal-frequencies']
 for name,flags in configs:run('owner-'+name,['cargo','test','--offline','--locked',*flags,'--lib','optimal_frequencies::tests'],(7,0,0))
 for name,flags in [('safe',[]),*[(f,['--features',f]) for f in features],('all',['--features',','.join(features)])]:run('nostd-'+name,['cargo','check','--offline','--locked','--no-default-features',*flags])
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  run('public-'+name,['cargo','test','--offline','--locked',*flags,'--test','reference_tree','--test','reference_tree_defaults','--test','upstream_reference_fast'])
  run('clippy-'+name,['cargo','clippy','--offline','--locked','--all-targets',*flags,'--','-D','warnings'])
 run('format',['cargo','fmt','--all','--','--check'])
 if source!={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}:raise ValueError('source changed')
 save('passed')
except BaseException as error:
 save('failed',repr(error));raise
