from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize');O=Path('/tmp/zstdoxide-optimal-frequency-thumb-checks');O.mkdir();caller=O/'caller';(caller/'src').mkdir(parents=True)
(caller/'Cargo.toml').write_text('[package]\nname="optimal-frequency-thumb"\nversion="0.0.0"\nedition="2024"\n[features]\nunsafe-optimal-frequencies=[]\n[lib]\npath="src/lib.rs"\n')
(caller/'src/lib.rs').write_text('''#![no_std]
#![feature(allocator_api)]
#![deny(unsafe_op_in_unsafe_fn)]
#![allow(dead_code)]
extern crate alloc;
#[path="ROOT/src/error.rs"] mod error;
pub use error::{Error, Result};
#[path="ROOT/src/constants.rs"] mod constants;
#[path="ROOT/src/optimal_price.rs"] mod optimal_price;
#[path="ROOT/src/optimal_frequencies.rs"] mod optimal_frequencies;
pub fn exercise(input: &[u8]) -> Result<[u32; 3]> {
    let mut model = optimal_frequencies::OptimalFrequencies::new_in(false, alloc::alloc::Global)?;
    model.begin_block(input)?;
    model.update(&input[..input.len().min(15)], 1, 3)?;
    model.refresh()?;
    model.prices(input, input.len() as u32, 1, 3)
}
'''.replace('ROOT',str(R)))
env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR']};env.update(RUSTUP_TOOLCHAIN='nightly-2026-10-08',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-frequency-thumb-target')
paths=[str(p.relative_to(R)) for p in (R/'src').rglob('*.rs')]+['Cargo.toml','Cargo.lock','rust-toolchain.toml'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths};commands=[]
features=['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-reference-chain','unsafe-reference-tree','unsafe-row-table','unsafe-dictionary','unsafe-training','unsafe-optimal-frequencies']
def save(status='running',error=None):
 v=dict(status=status,source=source,commands=commands,qualification='Actual no_std library checks on thumbv6m for safe/isolated/all and concrete Global frequency-owner caller code generation for safe/isolated. Explicit pinned nightly; no firmware/native execution.')
 if error:v['error']=error
 (O/'evidence.json').write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def run(label,argv,cwd):
 log=O/(label+'.log');start=time.monotonic();print('START',label,flush=True)
 with log.open('wb') as f:p=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 b=log.read_bytes();commands.append(dict(label=label,argv=argv,cwd=str(cwd),exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest()));save()
 if p.returncode:raise ValueError(label)
 print('END',label,flush=True)
try:
 for mode,flags in [('safe',[]),('frequency',['--features','unsafe-optimal-frequencies']),('all',['--features',','.join(features)])]:run('library-'+mode,['cargo','check','--offline','--locked','--lib','--no-default-features','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc',*flags],R)
 for mode,flags in [('safe',[]),('frequency',['--features','unsafe-optimal-frequencies'])]:run('caller-'+mode,['cargo','build','--offline','--lib','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc',*flags],caller)
 if source!={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}:raise ValueError('source changed')
 save('passed')
except BaseException as e:save('failed',repr(e));raise
