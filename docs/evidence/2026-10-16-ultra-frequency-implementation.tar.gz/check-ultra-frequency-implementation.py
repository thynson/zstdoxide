from pathlib import Path
import subprocess,os,json,hashlib,time,tomllib
R=Path.cwd();O=Path('/tmp/zstdoxide-ultra-frequency-implementation-1016');O.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();paths=[*R.glob('src/*.rs'),R/'tests/support/ultra_frequency_fixture.rs',R/'Cargo.toml',R/'Cargo.lock'];source={str(p.relative_to(R)):sha(p)for p in paths};records=[];features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'})
env=os.environ|dict(CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-ultra-frequencies-target')
commands=[(m,['cargo','test',*f,'--lib','optimal_'])for m,f in [('safe',[]),('frequencies',['--features','unsafe-optimal-frequencies']),('all',['--all-features'])]]+[(m,['cargo','check','--no-default-features',*f])for m,f in [('nostd-safe',[]),('nostd-all',['--features',','.join(features)])]]+[('clippy',['cargo','clippy','--all-targets','--all-features','--','-D','warnings']),('fmt',['cargo','fmt','--all','--check'])]
def save(status): (O/'evidence.json').write_text(json.dumps(dict(status=status,source=source,source_unchanged=all(sha(R/p)==h for p,h in source.items()),commands=records),indent=2)+'\n')
for name,argv in commands:
 print('START',name,flush=True);p=O/(name+'.log');start=time.monotonic()
 with p.open('w')as f:r=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 records.append(dict(label=name,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)));save('running')
 if r.returncode:save('failed');raise ValueError(name)
 print('END',name,flush=True)
if any(sha(R/p)!=h for p,h in source.items()):raise ValueError('source changed')
save('passed')
