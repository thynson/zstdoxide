from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,s):
 if not v:raise ValueError(s)
checks={mode:json.loads(Path('/tmp/zstdoxide-lazy-transport-'+mode+'.json').read_bytes()) for mode in ['normal','optimized']}
for mode,e in checks.items():
 need(e['status']=='passed' and e['python_optimized']==(mode=='optimized') and e['accepted']==259 and e['rejected']==52 and e['child_processes']==0,'complete controls')
 for n,h in e['source'].items():need(sha((R/n).read_bytes())==h,'unchanged source '+n)
report={'date':'2026-10-12','status':'passed','source':checks['normal']['source'],'accepted_per_mode':259,'rejected_per_mode':52,'packet_roundtrips_per_mode':108,'translated_depth_zero_cases_per_mode':36,'synthetic_metadata_cases_per_mode':108,'synthetic_salt_schema_cases_per_mode':6,'child_processes':0,'qualification':checks['normal']['qualification'],'archive':'2026-10-12-lazy-transport.tar.gz'}
files={'controls-'+mode+'.json':enc(e) for mode,e in checks.items()}
for n in ['scripts/oracles/lazy_direct.py','scripts/oracles/greedy_direct.py']:files['source/'+n]=(R/n).read_bytes()
for n in ['check-zstdoxide-lazy-transport.py','package-zstdoxide-lazy-transport.py']:files['runners/'+n]=(Path('/tmp')/n).read_bytes()
files['review.json']=enc(report);files['bundle-manifest.json']=enc({n:{'bytes':len(v),'sha256':sha(v)} for n,v in files.items()})
a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh archive');prefix='lazy-transport/'
with tarfile.open(a,'w:gz') as t:
 for n,v in sorted(files.items()):
  i=tarfile.TarInfo(prefix+n);i.size=len(v);i.mode=0o644;t.addfile(i,io.BytesIO(v))
with tarfile.open(a) as t:found={v.name:t.extractfile(v).read() for v in t}
need(found=={prefix+n:v for n,v in files.items()},'archive byte identity')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files));(R/'docs/evidence/2026-10-12-lazy-transport.json').write_bytes(enc(report));print(report['archive_members'],report['archive_bytes'])
