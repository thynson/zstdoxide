from pathlib import Path
from dataclasses import fields,replace
import contextlib,copy,hashlib,json,os,struct,subprocess,sys
from unittest.mock import patch
sys.dont_write_bytecode=True
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(R/'scripts'))
from oracles import lazy_direct as m
import check_greedy_tiny_capture as accepted
records=[];children=[]
def deny(*a,**kw):children.append('process');raise RuntimeError('child execution forbidden')
def encode(rows):return ('\n'.join(json.dumps(r,allow_nan=False) for r in rows)+'\n').encode()
def case_for(old,depth=0):return m.Recipe(**{f.name:getattr(old,f.name) for f in fields(m.predecessor.Recipe)},depth=depth)
def convert(data,depth=0,salt=False):
 rows=m.records(data);rows[0].update(protocol=m.PROTOCOL,depth=depth,strategy=3+depth)
 if not salt:rows[0]['entry_point']=m.entry_point(depth,rows[0]['branch'])
 for row in rows[1:3]:
  row['depth']=depth
  if salt:row['resolved'][-1]=3+depth
  else:row['strategy']=3+depth
 rows[3]['depth']=depth;return rows
def check(name,call,positive=False):
 try:call()
 except (ValueError,TypeError,KeyError,IndexError,UnicodeError,struct.error) as error:
  if positive:raise RuntimeError('positive failed: '+name) from error
  result='rejected'
 else:
  if not positive:raise RuntimeError('mutation accepted: '+name)
  result='accepted'
 records.append({'name':name,'result':result})
with contextlib.ExitStack() as stack:
 for module,name in [(subprocess,'Popen'),(os,'system'),(os,'posix_spawn'),(os,'posix_spawnp')]:
  if hasattr(module,name):stack.enter_context(patch.object(module,name,deny))
 frozen,observed=accepted.fixture();old_cases=m.predecessor.recipes();positive=[]
 for old in old_cases:
  for depth in range(3):
   case=case_for(old,depth)
   def packet_roundtrip(case=case):
    if m.decode_packet(case.packet())!=case:raise ValueError('packet roundtrip')
    if case.metadata()['strategy']!=3+case.depth:raise ValueError('metadata strategy')
   check('packet-'+str(depth)+'-'+old.name,packet_roundtrip,True)
   metadata=convert(observed[old.name],depth)[0]
   check('synthetic-selector-metadata-'+str(depth)+'-'+old.name,lambda r=metadata,c=case:m.validate_metadata(r,c.branch,c.depth),True)
  case=case_for(old);rows=convert(observed[old.name]);check('translated-depth-zero-'+old.name,lambda c=case,r=rows:m.validate(c,encode(r)),True);positive.append((case,rows))
 for mode in ['normal','sanitized']:
  for depth in range(3):
   rows=convert(observed['salt-'+mode],depth,True)
   check('synthetic-salt-schema-'+mode+'-'+str(depth),lambda r=rows,d=depth:m.validate_salt(encode(r),d),True)
 focus=next((c,r) for c,r in positive if r[1]['sequences'] and r[1]['first_table']['changes'])
 case,base=focus;packet=case.packet()
 def packet_mutation(offset,value):return packet[:offset]+struct.pack('<I',value)+packet[offset+4:]
 for name,data in [('old-magic',b'ZGRDY01\0'+packet[8:]),('depth-three',packet_mutation(144,3)),('depth-max',packet_mutation(144,0xffffffff)),('reserved-word',packet_mutation(148,1)),('branch-two',packet_mutation(72,2)),('truncated-header',packet[:151]),('truncated-source',packet[:-1]),('trailing-source',packet+b'x'),('invalid-id',packet[:8]+b'!'+packet[9:]),('unterminated-id',packet[:8]+b'a'*64+packet[72:])]:
  check('packet-reject-'+name,lambda d=data:m.decode_packet(d))
 for value in [False,True,1.0,-1,3]:check('recipe-depth-'+repr(value),lambda v=value:replace(case,depth=v).packet())
 def altered(name,edit):
  rows=copy.deepcopy(base);edit(rows);check(name,lambda:m.validate(case,encode(rows)))
 altered('metadata-depth',lambda r:r[0].update(depth=1))
 altered('metadata-bool-depth',lambda r:r[0].update(depth=False))
 altered('metadata-strategy',lambda r:r[0].update(strategy=4))
 altered('metadata-entry-point',lambda r:r[0].update(entry_point='ZSTD_compressBlock_lazy'))
 altered('metadata-old-protocol',lambda r:r[0].update(protocol='ZGRDY01'))
 altered('metadata-extra',lambda r:r[0].update(extra=0))
 altered('case-depth',lambda r:r[1].update(depth=1))
 altered('case-float-depth',lambda r:r[1].update(depth=0.0))
 altered('case-strategy',lambda r:r[1].update(strategy=4))
 altered('completion-depth',lambda r:r[3].update(depth=1))
 altered('completion-missing-depth',lambda r:r[3].pop('depth'))
 altered('coherent-wrong-depth',lambda r:[row.update(depth=1,**({'strategy':4} if i<3 else {})) for i,row in enumerate(r)])
 altered('common-table-delta',lambda r:r[1]['first_table']['changes'][0].__setitem__(2,0xffffffff))
 altered('common-sequence-distance',lambda r:r[1]['sequences'][0].__setitem__('distance',0))
 altered('common-owner-total',lambda r:r[1].update(requested_allocation_bytes=0))
 altered('common-source-hash',lambda r:r[1].update(source_fnv1a64='0'*16))
 altered('common-wire-repeats',lambda r:r[1]['wire_repeats'].__setitem__(0,0))
 altered('common-literal-consumption',lambda r:r[1].update(stored_literal_bytes=0xffffffff))
 data=encode(base)
 check('duplicate-json-key',lambda:m.validate(case,data.replace(b'{',b'{"depth":0,',1)))
 check('non-finite-json',lambda:m.validate(case,data.replace(b'"depth": 0',b'"depth": NaN',1)))
 check('no-final-newline',lambda:m.validate(case,data[:-1]))
 check('extra-record',lambda:m.validate(case,data+b'{}\n'))
 for depth in range(3):
  salt=convert(observed['salt-normal'],depth,True)
  def salt_altered(name,edit):
   rows=copy.deepcopy(salt);edit(rows);check('salt-'+str(depth)+'-'+name,lambda:m.validate_salt(encode(rows),depth))
  salt_altered('wrong-strategy',lambda r:r[1]['resolved'].__setitem__(-1,9))
  salt_altered('wrong-case-depth',lambda r:r[1].update(depth=3))
  salt_altered('wrong-completion-depth',lambda r:r[3].update(depth=3))
  salt_altered('common-salt',lambda r:r[1].update(final_salt='0'*16))
  salt_altered('common-owner-release',lambda r:r[1].update(free_calls=0))
 check('restored-depth-zero',lambda:m.validate(case,encode(base)),True)
if children:raise RuntimeError('child process attempted')
e={'status':'passed','python_optimized':not __debug__,'child_processes':len(children),'predecessor_cases':len(old_cases),'packet_roundtrips':3*len(old_cases),'translated_depth_zero_cases':len(old_cases),'synthetic_metadata_cases':3*len(old_cases),'synthetic_salt_schema_cases':6,'rejected':sum(v['result']=='rejected' for v in records),'accepted':sum(v['result']=='accepted' for v in records),'qualification':'Packets and checked replay only. Depth-zero outputs are source-only schema projections of frozen Greedy observations. Depth-one/two metadata and salt-schema positives are synthetic structural controls, not new C observations or expected Lazy/Lazy2 outputs. No helper executable runs.','source':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['scripts/oracles/lazy_direct.py','scripts/oracles/greedy_direct.py','scripts/check_greedy_tiny_capture.py','scripts/check_greedy_tiny_recipes.py','tests/fixtures/reference-greedy-tiny/observations.ndjson','tests/fixtures/reference-greedy-tiny/capture.json','tests/fixtures/reference-greedy-tiny/recipes.json']},'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':records}
print(json.dumps(e,sort_keys=True,indent=2))
