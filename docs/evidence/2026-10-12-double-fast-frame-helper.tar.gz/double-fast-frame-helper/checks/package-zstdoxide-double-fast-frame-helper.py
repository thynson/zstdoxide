from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize')
def sha(b):return hashlib.sha256(b).hexdigest()
members={}
for mode in ['normal','optimized']:
 p=Path('/tmp/zstdoxide-double-fast-frame-validator-'+mode+'-2026-10-12/report.json')
 value=json.loads(p.read_bytes());assert value['status']=='passed' and value['positive']==4 and value['rejected']==22
 members[mode+'/report.json']=p.read_bytes();members[mode+'/runner.log']=Path('/tmp/zstdoxide-double-fast-frame-validator-'+mode+'.log').read_bytes()
for name in ['docs/reference-double-fast-frame-helper-review.md','docs/reference-double-fast-frame-oracle.md','scripts/oracles/double_fast_frame.c','scripts/oracles/double_fast_frame_validation.py','scripts/oracles/double_fast_frames.py','scripts/check_double_fast_frame_recipes.py','tests/fixtures/reference-double-fast-frame-recipes/recipes.json']:
 members['source/'+name]=(R/name).read_bytes()
for name in ['zstdoxide-double-fast-frame-helper-syntax.log','zstdoxide-double-fast-frame-helper-syntax-final.log','zstdoxide-double-fast-frame-helper-format.log','zstdoxide-double-fast-frame-helper-recipes.log','check-zstdoxide-double-fast-frame-validator.py','build-zstdoxide-double-fast-frame-helper.py','package-zstdoxide-double-fast-frame-helper.py']:
 members['checks/'+name]=(Path('/tmp')/name).read_bytes()
report={'date':'2026-10-12','status':'passed','scope':'Ordinary DoubleFast helper implementation and pre-execution allocation/bounds/state review. Strict C11 syntax, formatting, source recipes and synthetic validator/hash controls only; no helper mode or ordinary C compression executed.',
 'helper_sha256':sha((R/'scripts/oracles/double_fast_frame.c').read_bytes()),'validator_sha256':sha((R/'scripts/oracles/double_fast_frame_validation.py').read_bytes()),'frozen_hash_vectors':512,'controls_per_mode':{'positive':4,'rejected':22},'modes':['normal','optimized'],'persistent_guarded_helper_buffers':7,'maximum_persistent_guarded_helper_bytes':21498073,'archive':'2026-10-12-double-fast-frame-helper.tar.gz',
 'syntax_argv':['clang','-std=c11','-Wall','-Wextra','-Werror','-Wno-deprecated-declarations','-I','/tmp/zstdoxize-upstream-1.5.7/lib','-I','/tmp/zstdoxize-upstream-1.5.7/lib/common','-I','/tmp/zstdoxize-upstream-1.5.7/lib/compress','-fsyntax-only','scripts/oracles/double_fast_frame.c']}
members['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();members['bundle-manifest.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},sort_keys=True,indent=2)+'\n').encode()
a=R/'docs/evidence'/report['archive'];assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('double-fast-frame-helper/'+n);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 assert set(t.getnames())=={'double-fast-frame-helper/'+n for n in members}
 for n,b in members.items():assert t.extractfile('double-fast-frame-helper/'+n).read()==b
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(members))
(R/'docs/evidence/2026-10-12-double-fast-frame-helper.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(len(members),'archive members')
