from pathlib import Path
import copy,hashlib,json,sys
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(R/'scripts/oracles'))
import double_fast_frame_validation as v
O=Path(sys.argv[1]);O.mkdir(exist_ok=False)
controls=[]
def test(name,fn,reject=False):
 try:fn()
 except (ValueError,TypeError,KeyError,IndexError,OverflowError) as e:
  if not reject:raise
  controls.append({'name':name,'rejected':True,'reason':str(e)})
 else:
  if reject:raise RuntimeError('accepted '+name)
  controls.append({'name':name,'rejected':False})
patterns=(R/'tests/upstream/match-search/patterns.bin').read_bytes()
rows=(R/'tests/upstream/double-fast-hashes/vectors.tsv').read_text().splitlines()[1:]
for index,row in enumerate(rows):
 log,shift,pattern,key,bucket=row.split('\t');log=int(log);pattern=int(pattern)
 raw=patterns[pattern*8:pattern*8+8]
 if raw.hex()!=key:raise RuntimeError('frozen key')
 if v.key_bucket(raw,0,8,log)!=int(bucket):raise RuntimeError('frozen hash '+str(index))
controls.append({'name':'512-frozen-direct-C-hashes','rejected':False})
source=patterns[:8];slot=v.key_bucket(source,0,8,6)
def hashed(values):return v.fingerprint(b''.join(x.to_bytes(4,'little') for x in values))
before=[0]*64;after=before.copy();after[slot]=2
valid={'log':6,'width':8,'entries':64,'before_fnv64':hashed(before),'after_fnv64':hashed(after),'changed':[[slot,0,2]]}
def update(table,consumed=8,fresh=True):
 v.base.scalar_types(table);v.table_shape(table);v.table_update(table,before.copy(),source,consumed,6,8,fresh)
test('synthetic-complete-table',lambda:update(valid))
for field,value in [('log',7),('width',7),('entries',128),('entries',True),('before_fnv64','0'*16),('after_fnv64','0'*16),('changed',[[64,0,2]]),('changed',[[slot,1,2]]),('changed',[[slot,0,0]]),('changed',[[slot,0,1]]),('changed',[[slot,0,1<<32]]),('changed',[[slot,0,2],[slot,2,3]]),('changed',[[slot,False,2]])]:
 row=copy.deepcopy(valid);row[field]=value
 test('table-'+field+'-'+str(value),lambda row=row:update(row),True)
test('incomplete-key',lambda:update(valid,7),True)
test('tiny-table-mutation',lambda:update(valid,fresh=False),True)
# Independently specified format header; this is a validator control, not C capture.
header={'type':'header','case':'header_only','pledge':2097152,'window_log':21,'window':2097152,'single_segment':1,'fcs_bytes':4,'bytes':'28b52ffda000002000'}
partial={'type':'partial','completed_frame':False,'decoded':False,'pointer_bits':64,'int_bits':32}
test('synthetic-window21-header',lambda:v.validate_partial([header,partial],2097152,21))
for field,value in [('decoded',True),('completed_frame',True),('int_bits',64),('pointer_bits',16)]:
 row=copy.deepcopy(partial);row[field]=value
 test('partial-'+field,lambda row=row:v.validate_partial([header,row],2097152,21),True)
for off in [0,2,3]:test('invalid-DoubleFast-intent-'+str(off),lambda off=off:v.resolve([1,4,8],off,1),True)
for off,ll,expected in [(1,1,(1,[1,4,8])),(1,0,(4,[4,1,8])),(7,0,(4,[4,1,4]))]:
 if v.resolve([1,4,8],off,ll)!=expected:raise RuntimeError('valid offset')
controls.append({'name':'three-independent-repeat-transitions','rejected':False})
report={'status':'passed','optimized':not __debug__,'positive':sum(not x['rejected'] for x in controls),'rejected':sum(x['rejected'] for x in controls),'controls':controls,'scope':'Frozen direct hash primitive checks plus synthetic validator structures; no ordinary DoubleFast observations or C execution.'}
(O/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(report['positive'],'positive;',report['rejected'],'rejected')
