from pathlib import Path
root=Path('/Users/lanxingcan/Workspace/zstdoxize')
s=(root/'tests/upstream/fast-frame-publication/frame_oracle.c').read_text()
def change(a,b):
 global s
 if a not in s:raise ValueError('missing original fragment: '+a[:100])
 s=s.replace(a,b)
change('normal Fast frames.','normal DoubleFast frames.')
change(' * Setup, checked observations and independent sequence replay only.',' * Setup, checked observations and independent sequence replay only.\n * Adapted from this project\'s frozen Fast frame helper; no upstream codec copied.')
change('#define SOURCE_CAP (2u * 1024u * 1024u)','#define SOURCE_CAP (4u * 1024u * 1024u)')
change('fopen(path,"wb")','fopen(path,"wbx")')
change('static ZSTD_CCtx_params parameters(unsigned w,unsigned h,unsigned m,unsigned t)',
       'static ZSTD_CCtx_params parameters(unsigned w,unsigned h,unsigned chain,unsigned search,unsigned m,unsigned t)')
change('w>=10 && w<=20 && h>=6 && h<=18 && m>=3 && m<=7 && t<=TARGET_CAP',
       'w>=10 && w<=21 && h>=6 && h<=18 && chain>=6 && chain<=18 && search>=1 && search<=29 && m>=3 && m<=7 && t<=TARGET_CAP')
change('p.cParams.chainLog=12; p.cParams.hashLog=h; p.cParams.searchLog=1;',
       'p.cParams.chainLog=chain; p.cParams.hashLog=h; p.cParams.searchLog=search;')
change('p.cParams.strategy=ZSTD_fast;', 'p.cParams.strategy=ZSTD_dfast;')
change('    if(pledge<expected) expected=(size_t)pledge;', '''    need(c->blockState.matchState.hashTable!=NULL && c->blockState.matchState.chainTable!=NULL &&
         c->blockState.matchState.hashTable!=c->blockState.matchState.chainTable,"independent table owners");
    need((uintptr_t)c->blockState.matchState.hashTable % _Alignof(U32)==0 &&
         (uintptr_t)c->blockState.matchState.chainTable % _Alignof(U32)==0,"table alignment");
    if(pledge<expected) expected=(size_t)pledge;''')
change('static void table_changes(const U32* before,const U32* after,size_t n,const BYTE* source,size_t consumed,unsigned h,unsigned m)',
       'static void table_changes(const U32* before,const U32* after,size_t n,const BYTE* source,size_t consumed,unsigned h,unsigned width)')
change('    size_t i; int first=1;\n    printf("{\\"entries\\":%zu,',
       '    size_t i; int first=1;\n    need(h>=6 && h<=18 && width>=4 && width<=8 && n==((size_t)1<<h),"table observation dimensions");\n    printf("{\\"log\\":%u,\\"width\\":%u,\\"entries\\":%zu,')
change('n,hash_table(before,n),hash_table(after,n));','h,width,n,hash_table(before,n),hash_table(after,n));')
change('size_t key_size=m<4?4:m,position;', 'size_t key_size=width,position;')
change('unsigned w,unsigned h,unsigned m,unsigned t) {\n    Buffer arena,copy,scratch,frame,replay,before_table;',
       'unsigned w,unsigned h,unsigned chain,unsigned search,unsigned m,unsigned t) {\n    Buffer arena,copy,scratch,frame,replay,before_table,before_short;')
change('ZSTD_CCtx_params p=parameters(w,h,m,t);', 'ZSTD_CCtx_params p=parameters(w,h,chain,search,m,t);')
change('replay=buffer(n?n:1); before_table=buffer(times((size_t)1<<h,sizeof(U32)));',
       '''replay=buffer(n?n:1); before_table=buffer(times((size_t)1<<h,sizeof(U32)));
    before_short=buffer(times((size_t)1<<chain,sizeof(U32)));
    need((uintptr_t)before_table.data % _Alignof(U32)==0 && (uintptr_t)before_short.data % _Alignof(U32)==0,"table-copy alignment");
    { size_t j; for(j=0;j<((size_t)1<<h);++j) need(c->blockState.matchState.hashTable[j]==0,"initial long table");
      for(j=0;j<((size_t)1<<chain);++j) need(c->blockState.matchState.chainTable[j]==0,"initial short table"); }''')
change('memcpy(before_table.data,c->blockState.matchState.hashTable,before_table.size); memcpy(trial,semantic,sizeof(trial));',
       '''memcpy(before_table.data,c->blockState.matchState.hashTable,before_table.size);
        memcpy(before_short.data,c->blockState.matchState.chainTable,before_short.size); memcpy(trial,semantic,sizeof(trial));''')
change('            printf("{\\"type\\":\\"zero_continue',
       '''            need(!memcmp(before_table.data,c->blockState.matchState.hashTable,before_table.size) &&
                 !memcmp(before_short.data,c->blockState.matchState.chainTable,before_short.size),"zero Continue changed sampled tables");
            printf("{\\"type\\":\\"zero_continue''')
change('"Fast first-two candidate repeats mismatch"', '"DoubleFast first-two candidate repeats mismatch"')
change('            fputs(",\\"hash\\":",stdout); table_changes((const U32*)before_table.data,c->blockState.matchState.hashTable,(size_t)1<<h,source,consumed,h,m); fputs("}\\n",stdout);',
       '''            fputs(",\\"long_table\\":",stdout); table_changes((const U32*)before_table.data,c->blockState.matchState.hashTable,(size_t)1<<h,source,consumed,h,8);
            fputs(",\\"short_table\\":",stdout); table_changes((const U32*)before_short.data,c->blockState.matchState.chainTable,(size_t)1<<chain,source,consumed,chain,m<4?4:m); fputs("}\\n",stdout);''')
change('drop(&before_table); drop(&replay);', 'drop(&before_short); drop(&before_table); drop(&replay);')
change('p=parameters((unsigned)wv,14,4,0);','p=parameters((unsigned)wv,14,12,1,4,0);')
change('need(argc==11 && !strcmp(argv[1],"frame"),"usage: frame CASE INPUT SCHEDULE OUTPUT WHOLE_OR_DASH W H M T | header PLEDGE W");',
       'need(argc==13 && !strcmp(argv[1],"frame"),"usage: frame CASE INPUT SCHEDULE OUTPUT WHOLE_OR_DASH W H C S M T | header PLEDGE W");')
change('case_name=argv[2]; { const char* q=case_name; while(*q)',
       'case_name=argv[2]; need(strlen(case_name)>0 && strlen(case_name)<=63,"case ID length"); { const char* q=case_name; while(*q)')
change('uint64_t w=number(argv[7]),h=number(argv[8]),m=number(argv[9]),t=number(argv[10]);',
       'uint64_t w=number(argv[7]),h=number(argv[8]),chain=number(argv[9]),search=number(argv[10]),m=number(argv[11]),t=number(argv[12]);')
change('w<=UINT_MAX && h<=UINT_MAX && m<=UINT_MAX && t<=UINT_MAX',
       'w<=UINT_MAX && h<=UINT_MAX && chain<=UINT_MAX && search<=UINT_MAX && m<=UINT_MAX && t<=UINT_MAX')
change('(unsigned)w,(unsigned)h,(unsigned)m,(unsigned)t);',
       '(unsigned)w,(unsigned)h,(unsigned)chain,(unsigned)search,(unsigned)m,(unsigned)t);')
# Record host/codec ABI separately without serializing any addresses.
change('    if(argc==4 && !strcmp(argv[1],"header")) {', '''    if(argc==2 && !strcmp(argv[1],"metadata")) {
        printf("{\\"type\\":\\"metadata\\",\\"revision\\":\\"f8745da6ff1ad1e7bab384bd1f9d742439278e99\\",\\"strategy\\":2,\\"pointer_bits\\":%zu,\\"int_bits\\":%zu,\\"u32_bytes\\":%zu,\\"source_cap\\":%u,\\"block_cap\\":%u,\\"call_cap\\":%u,\\"leading_bytes\\":%u,\\"suffix_bytes\\":%u,\\"guard_bytes\\":%u,\\"scratch_bytes\\":%u}\\n",
               sizeof(void*)*CHAR_BIT,sizeof(int)*CHAR_BIT,sizeof(U32),SOURCE_CAP,BLOCK_CAP,CALL_CAP,LEADING_BYTES,SUFFIX_BYTES,GUARD_BYTES,SCRATCH_BYTES);
        need(!ferror(stdout),"metadata output error"); return 0;
    }
    if(argc==4 && !strcmp(argv[1],"header")) {''')
(root/'scripts/oracles/double_fast_frame.c').write_text(s)
