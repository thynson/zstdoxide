//! Temporary bounded Module 12 portability harness; not a repository test.
#![feature(allocator_api)]
#![forbid(unsafe_code)]
use std::num::NonZeroU64;
use zstdoxide::{
    CompressionParameterRequest as Request, Error, FrameHeader, ReferenceStrategy,
    compress_at_level_in, compress_with_parameters_in, decompress,
};
use zstdoxide_test_allocator::{AllocatorConfig, TrackingAllocator};
fn owner(fail_at: Option<u64>) -> TrackingAllocator {
    TrackingAllocator::new(AllocatorConfig {
        max_live_allocations: 64,
        fail_at: fail_at.map(|n| NonZeroU64::new(n).unwrap()),
    })
    .unwrap()
}
#[test]
fn public_empty_owned_output_and_failure_have_exact_owners() {
    for by_request in [false, true] {
        let request = Request::with_level(-1);
        let allocator = owner(None);
        let identity = allocator.identity();
        let monitor = allocator.monitor();
        let frame = if by_request {
            compress_with_parameters_in(&[], &request, allocator)
        } else {
            compress_at_level_in(&[], -1, allocator)
        }
        .unwrap();
        assert_eq!(frame.as_slice(), [0x28, 0xb5, 0x2f, 0xfd, 0x20, 0, 1, 0, 0]);
        assert_eq!(frame.allocator().identity(), identity);
        assert_eq!(monitor.snapshot().attempts, 1);
        assert_eq!(monitor.snapshot().identities_created, 1);
        assert_eq!(monitor.snapshot().live_blocks, 1);
        assert_eq!(decompress(&frame, 0).unwrap(), []);
        drop(frame);
        monitor.assert_released();
        assert_eq!(monitor.snapshot().owners_dropped, 1);
        let allocator = owner(Some(1));
        let monitor = allocator.monitor();
        let failure = if by_request {
            compress_with_parameters_in(&[], &request, allocator)
        } else {
            compress_at_level_in(&[], -1, allocator)
        }
        .err();
        assert_eq!(failure, Some(Error::AllocationFailed));
        assert_eq!(monitor.snapshot().attempts, 1);
        assert_eq!(monitor.snapshot().failures, 1);
        assert_eq!(monitor.snapshot().identities_created, 1);
        assert_eq!(monitor.snapshot().owners_dropped, 1);
        monitor.assert_released();
    }
}
#[test]
fn public_tiny_borrowed_nonclone_owners_roundtrip_both_entry_points() {
    for input in [
        b"sixsix".as_slice(),
        b"abcdefg",
        b"aaaaaaaaaaaaaaaa",
        b"abcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcdabcd",
    ] {
        let allocator = owner(None).into_non_clone();
        let monitor = allocator.monitor();
        let request = Request::with_level(-1);
        let before = request;
        let simple = compress_at_level_in(input, -1, &allocator).unwrap();
        let explicit = compress_with_parameters_in(input, &request, &allocator).unwrap();
        assert_eq!(simple, explicit);
        assert_eq!(request, before);
        assert!(std::ptr::eq(*simple.allocator(), &allocator));
        assert!(std::ptr::eq(*explicit.allocator(), &allocator));
        assert_eq!(monitor.snapshot().identities_created, 1);
        assert_eq!(monitor.snapshot().live_blocks, 2);
        for frame in [&simple, &explicit] {
            let (header, _) = FrameHeader::parse(frame).unwrap();
            assert_eq!(header.content_size, Some(input.len() as u64));
            assert_eq!(header.window_size, input.len() as u64);
            assert_eq!(header.dictionary_id, 0);
            assert!(!header.has_checksum);
            assert_eq!(decompress(frame, input.len()).unwrap(), input);
        }
        drop((simple, explicit));
        monitor.assert_released();
        assert_eq!(monitor.snapshot().owners_dropped, 0);
        drop(allocator);
        assert_eq!(monitor.snapshot().owners_dropped, 1);
    }
}
#[test]
fn public_unsupported_rejection_precedes_clone_and_allocation() {
    let mut advanced = Request::with_level(-1);
    advanced.set_strategy(Some(ReferenceStrategy::DoubleFast));
    for input in [b"".as_slice(), b"small input"] {
        for request in [Request::new(), advanced] {
            let allocator = owner(Some(1));
            let monitor = allocator.monitor();
            let before = monitor.snapshot();
            let original = request;
            assert_eq!(
                compress_with_parameters_in(input, &request, allocator).err(),
                Some(Error::UnsupportedFeature)
            );
            let after = monitor.snapshot();
            assert_eq!(after.attempts, before.attempts);
            assert_eq!(after.identities_created, before.identities_created);
            assert_eq!(after.failures, 0);
            assert_eq!(after.owners_dropped, 1);
            assert_eq!(request, original);
            monitor.assert_released();
        }
        let allocator = owner(Some(1));
        let monitor = allocator.monitor();
        assert_eq!(
            compress_at_level_in(input, 0, allocator).err(),
            Some(Error::UnsupportedFeature)
        );
        assert_eq!(monitor.snapshot().attempts, 0);
        assert_eq!(monitor.snapshot().identities_created, 1);
        assert_eq!(monitor.snapshot().owners_dropped, 1);
        monitor.assert_released();
    }
}
