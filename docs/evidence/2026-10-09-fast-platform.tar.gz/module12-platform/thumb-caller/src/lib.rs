//! Compile/codegen-only caller for the nightly allocator API on thumbv6m.
#![no_std]
#![feature(allocator_api)]
#![forbid(unsafe_code)]
extern crate alloc;
use alloc::{alloc::Global, rc::Rc, vec::Vec};
use core::alloc::Allocator;
use zstdoxide::{
    CompressionParameterRequest, Dictionary, Result, SharedDictionary, compress_at_level_in,
    compress_with_parameters_in,
};
#[cfg(target_has_atomic = "ptr")]
compile_error!("This probe requires the no-pointer-atomics target.");
// Existing dictionary fallback is checked separately from the new Fast APIs.
pub fn shared_is_rc<A: Allocator>(dictionary: SharedDictionary<A>) -> Rc<Dictionary<A>> {
    dictionary
}
// The outer public function concretely specializes both generic codec calls;
// the allocator value is borrowed and need not itself implement Clone.
pub fn borrowed<'a>(input: &[u8], allocator: &'a Global) -> Result<Vec<u8, &'a Global>> {
    let first = compress_at_level_in(input, -1, allocator)?;
    let request = CompressionParameterRequest::with_level(-1);
    let second = compress_with_parameters_in(input, &request, allocator)?;
    drop(first);
    Ok(second)
}
