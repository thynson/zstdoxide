import hashlib,json,pathlib,tarfile
OUT=pathlib.Path('/tmp/zstdoxide-module12-platform');ROOT=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize')
sha=lambda b:hashlib.sha256(b).hexdigest()
e=json.loads((OUT/'evidence.json').read_text());m=json.loads((OUT/'source-manifest.json').read_text())
if e['status']!='passed' or len(e['commands'])!=19:raise RuntimeError('Incomplete execution')
for c in e['commands']:
 if not c['passed'] or sha(pathlib.Path(c['log']).read_bytes())!=c['log_sha256']:raise RuntimeError('Invalid record '+c['name'])
critical=['Cargo.toml','Cargo.lock','rust-toolchain.toml']+[x for x in m['files'] if x.startswith('src/') or x.startswith('test-support/allocator/')]
comparison={x:sha((ROOT/x).read_bytes())==m['files'][x]['sha256'] for x in critical}
if not all(comparison.values()):raise RuntimeError('Root production/dependency changed')
e['final_root_source_comparison']={'files':comparison,'all_equal':True}
e['diagnostics']={'failures':0,'legacy_feature_attribute_warning':'The two temporary caller harnesses explicitly enable allocator_api. The dated compiler reports partial stabilization since 1.100.0 and recommends allocator_ext or removing this unneeded attribute. This warning is preserved in successful native/public-Miri/caller-build logs; production files are unchanged. Warning-free temporary compilation and stable-toolchain validation are not claimed.'}
e['validation_counts']={'commands_total':19,'metadata_and_lock_commands':6,'native_smoke_commands':1,'native_temporary_tests':3,'miri_commands':8,'miri_repository_test_executions':12,'miri_temporary_test_executions':12,'miri_total_test_executions':24,'thumb_library_checks':2,'thumb_caller_codegen_builds':2,'failed_commands':0}
(OUT/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
report='''# Module 12 bounded Fast platform validation

The frozen production snapshot is commit `'''+e['revision']+'''`. All repository source files, Cargo inputs, the allocator test helper, saved test fixtures and matching-feature declarations are hashed in `source-manifest.json`; source identity was checked before and after every command. Current production/dependency files were compared with that snapshot at completion. No repository files were edited for this work.

| Target | Backend | Existing parser tests | Temporary public tests | Execution |
| --- | --- | ---: | ---: | --- |
| i686-unknown-linux-gnu | Safe/default | 3 | 3 | Strict-provenance Miri, 32-bit little-endian |
| i686-unknown-linux-gnu | All 12 unsafe features | 3 | 3 | Strict-provenance Miri, 32-bit little-endian |
| s390x-unknown-linux-gnu | Safe/default | 3 | 3 | Strict-provenance Miri, 64-bit big-endian |
| s390x-unknown-linux-gnu | All 12 unsafe features | 3 | 3 | Strict-provenance Miri, 64-bit big-endian |

All **24 interpreted executions** passed, with exact selector names and nonzero counts required. The existing parser tests cover distance-one overlap and lengths 7/8/9/12/16/64, seven-byte cleanup, invalid ranges/windows/steps and usize overflow boundaries, and each of the two parser output-reservation failures followed by successful retry and balanced exact-owner release. They do not execute the full 142-case direct corpus.

The three temporary functions exist only in the external snapshot, not in repository test suites. They cover both public APIs with the exact empty frame and injected output allocation failure; borrowed non-Clone owners on 6/7/16/64-byte sources with matching bytes, headers, source-size windows and full decoder roundtrips; and unsupported request/level rejection before allocator clone or allocation. They also passed a three-test native host smoke command before interpretation. This is the only native runtime execution in this record.

Four thumbv6m checks passed: safe and all-12-unsafe-feature `no_std` library compilation, and safe/all caller rlib code generation. The caller concretely instantiates `compress_at_level_in` and `compress_with_parameters_in` with a borrowed Global allocator. A separate exact Rc type equality checks the existing dictionary fallback on a target without `target_has_atomic="ptr"`; it is not a new Fast dictionary capability. No target runtime, final firmware link, hardware allocator, hardware memory-fit or performance result is claimed.

The dated compiler is `nightly-2026-10-08`, rustc 1.101.0-nightly (1d81eb4ad, 2026-10-07). Both cached interpreted sysroots are fully hashed. Miri uses `-Zmiri-strict-provenance`. The temporary harnesses unnecessarily enable the older `allocator_api` feature name, and the compiler emits a partial-stabilization warning. Those diagnostics are retained; production files were not changed, and this report does not claim warning-free temporary code or stable-toolchain support.

There were 19 commands: 6 compiler/target/lock metadata commands, 1 native temporary smoke command, 8 Miri commands and 4 thumb library/caller commands. All returned zero; no failures, ignored tests or task-owned processes remain. Each command, effective explicit environment, duration, log hash and actual selected test name is recorded in `evidence.json`. Durations are validation timings, not benchmarks.

The archive excludes executables, compiler build artifacts, copied reference source and the repository snapshot. It includes the complete snapshot hash catalog, both temporary harnesses, their Cargo/lock configuration, exact runner, report and all logs. The repository snapshot can be reconstructed from the recorded commit and archive paths, with only the explicitly hashed temporary test added.
'''
(OUT/'REPORT.md').write_text(report)
files=[p for p in OUT.iterdir() if p.is_file() and p.name!='bundle-manifest.json']
files+=list((OUT/'thumb-caller').rglob('*'))
files=[p for p in files if p.is_file()]
manifest={str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(files)}
(OUT/'bundle-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(OUT/'bundle-manifest.json')
archive=pathlib.Path('/tmp/zstdoxide-module12-platform-evidence.tar.gz')
with tarfile.open(archive,'w:gz') as tf:
 for p in sorted(files):tf.add(p,arcname='module12-platform/'+str(p.relative_to(OUT)))
with tarfile.open(archive) as tf:
 for rel,info in manifest.items():
  raw=tf.extractfile('module12-platform/'+rel).read()
  if len(raw)!=info['bytes'] or sha(raw)!=info['sha256']:raise RuntimeError('Archive differs '+rel)
print(json.dumps({'evidence':str(OUT/'evidence.json'),'evidence_sha256':sha((OUT/'evidence.json').read_bytes()),'manifest_sha256':sha((OUT/'source-manifest.json').read_bytes()),'report_sha256':sha((OUT/'REPORT.md').read_bytes()),'archive':str(archive),'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'members':len(files),'command_count':len(e['commands'])},indent=2))
