//! Cold stable versus buffered sessions, with fixed whole/seven-byte input schedules.
//! Destinations and source preparation are outside clocks; session creation/drop,
//! scratch ownership, frame validation and full decoding are inside each sample.
//! TrackingAllocator is used only for clock-free qualification, never timing.
use std::{alloc::Allocator, hint::black_box, time::Instant};
use zstdoxide::{DecodeOptions, Decoder, SliceDecoder};
use zstdoxide_test_allocator::{AllocatorConfig, TrackingAllocator};

fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |hash, byte| {
        (hash ^ u64::from(*byte)).wrapping_mul(0x100000001b3)
    })
}
fn cases() -> Vec<(&'static str, Vec<u8>, Vec<u8>)> {
    let mut cases = Vec::new();
    macro_rules! generated {
        ($name:literal) => {
            cases.push((
                $name,
                include_bytes!(concat!("../tests/upstream/decodecorpus/", $name, ".zst")).to_vec(),
                include_bytes!(concat!("../tests/upstream/decodecorpus/", $name, ".raw")).to_vec(),
            ));
        };
    }
    generated!("mixed-04");
    generated!("raw-07");
    generated!("rle-03");
    generated!("compressed-05");
    generated!("small-blocks-07");
    generated!("large-content-04");
    cases.push((
        "http",
        include_bytes!("../tests/upstream/data/generated/http.zst").to_vec(),
        include_bytes!("../tests/upstream/data/golden-compression/http").to_vec(),
    ));
    cases.push((
        "larger",
        include_bytes!("../tests/upstream/data/generated/huffman-compressed-larger.zst").to_vec(),
        include_bytes!("../tests/upstream/data/golden-compression/huffman-compressed-larger")
            .to_vec(),
    ));
    cases.push((
        "empty",
        vec![0x28, 0xb5, 0x2f, 0xfd, 0x20, 0, 1, 0, 0],
        Vec::new(),
    ));
    let mut frame = cases[0].1.clone();
    frame.extend_from_slice(&cases[3].1);
    let mut original = cases[0].2.clone();
    original.extend_from_slice(&cases[3].2);
    cases.push(("concatenated", frame, original));
    cases
}
fn stable<A: Allocator + Clone>(
    encoded: &[u8],
    output: &mut [u8],
    limit: usize,
    chunk: usize,
    allocator: A,
) -> usize {
    let mut decoder = SliceDecoder::new_in(output, DecodeOptions::new(limit), allocator);
    let mut consumed = 0;
    while consumed < encoded.len() {
        let end = consumed + chunk.min(encoded.len() - consumed);
        let p = decoder.process(&encoded[consumed..end]).unwrap();
        assert!(p.consumed > 0 || p.produced > 0);
        consumed += p.consumed;
    }
    decoder.finish().unwrap();
    decoder.output().unwrap().len()
}
fn buffered<A: Allocator + Clone>(
    encoded: &[u8],
    output: &mut [u8],
    limit: usize,
    chunk: usize,
    allocator: A,
) -> usize {
    let mut decoder = Decoder::new_in(DecodeOptions::new(limit), allocator);
    let mut consumed = 0;
    let mut produced = 0;
    while consumed < encoded.len() || produced < limit {
        let end = consumed + chunk.min(encoded.len() - consumed);
        let p = decoder
            .process(&encoded[consumed..end], &mut output[produced..])
            .unwrap();
        assert!(p.consumed > 0 || p.produced > 0);
        consumed += p.consumed;
        produced += p.produced;
    }
    decoder.finish().unwrap();
    produced
}
fn decode<A: Allocator + Clone>(
    mode: &str,
    encoded: &[u8],
    output: &mut [u8],
    limit: usize,
    allocator: A,
) -> usize {
    let chunk = if mode.ends_with("whole") {
        usize::MAX
    } else {
        7
    };
    if mode.starts_with("stable") {
        stable(encoded, output, limit, chunk, allocator)
    } else {
        buffered(encoded, output, limit, chunk, allocator)
    }
}
fn main() {
    let command = std::env::args().nth(1).expect("qualify or measure");
    assert!(command == "qualify" || command == "measure");
    for (name, encoded, original) in cases() {
        let mut output = vec![0xa5; original.len() + 16];
        for mode in [
            "stable-whole",
            "buffered-whole",
            "stable-fragmented",
            "buffered-fragmented",
        ] {
            output.fill(0xa5);
            assert_eq!(
                decode(
                    mode,
                    &encoded,
                    &mut output,
                    original.len(),
                    std::alloc::Global
                ),
                original.len()
            );
            assert_eq!(&output[..original.len()], original);
            assert_eq!(&output[original.len()..], &[0xa5; 16]);
            if command == "qualify" {
                let allocator = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                let monitor = allocator.monitor();
                assert_eq!(
                    decode(mode, &encoded, &mut output, original.len(), allocator),
                    original.len()
                );
                assert_eq!(&output[..original.len()], original);
                assert_eq!(&output[original.len()..], &[0xa5; 16]);
                monitor.assert_released();
                let s = monitor.snapshot();
                assert_eq!(s.identities_created, s.owners_dropped);
                println!(
                    "{name}\t{mode}\t{}\t{:016x}\t{}\t{}\t{}\t{}",
                    original.len(),
                    fingerprint(&original),
                    s.attempts,
                    s.requested_bytes,
                    s.peak_bytes,
                    s.deallocate_calls
                );
            } else {
                let iterations = (512 * 1024 / original.len().max(1)).clamp(8, 1024);
                for sample in 0..5 {
                    let start = Instant::now();
                    for _ in 0..iterations {
                        black_box(decode(
                            black_box(mode),
                            black_box(&encoded),
                            black_box(&mut output),
                            black_box(original.len()),
                            std::alloc::Global,
                        ));
                    }
                    let elapsed = start.elapsed().as_nanos();
                    assert_eq!(&output[..original.len()], original);
                    assert_eq!(&output[original.len()..], &[0xa5; 16]);
                    println!("{name}\t{mode}\t{sample}\t{iterations}\t{elapsed}");
                }
            }
        }
    }
}
