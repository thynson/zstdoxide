from pathlib import Path
import hashlib,json,subprocess,datetime
import measure
D=Path(__file__).parent;Q=D/'repeat'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b,gates=measure.validate();primary=json.loads((D/'timed.json').read_text());assert primary['status']=='passed'
r=json.loads((Q/'evidence.json').read_text());assert r['status']=='qualified-not-timed' and len(r['builds'])==2
assert r['source_evidence_sha256']==sha(D/'evidence.json')
for row in r['builds']:
 assert sha(Q/row['executable'])==row['sha256']
 assert (Q/(row['name']+'-qualify.tsv')).read_bytes()==(D/'safe-qualify.tsv').read_bytes()
assert not (Q/'timed.json').exists()
e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),primary_timing_sha256=sha(D/'timed.json'),build_evidence_sha256=sha(Q/'evidence.json'),gates=gates,runs=[])
def save():(Q/'timed.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for row in r['builds']:
  name=row['name'];p=subprocess.run([str(Q/row['executable']),'measure'],capture_output=True);(Q/(name+'-timed.tsv')).write_bytes(p.stdout);(Q/(name+'-timed.stderr')).write_bytes(p.stderr);assert p.returncode==0
  lines=p.stdout.decode().splitlines();assert len(lines)==200
  seen=set()
  for line in lines:
   case,mode,sample,iterations,elapsed=line.split('\t');sample=int(sample);iterations=int(iterations);elapsed=int(elapsed)
   assert mode in ['stable-whole','buffered-whole','stable-fragmented','buffered-fragmented'] and 0<=sample<5 and 8<=iterations<=1024 and elapsed>0
   key=(case,mode,sample);assert key not in seen;seen.add(key)
  expected={(line.split('\t')[0],line.split('\t')[1],sample) for line in (D/'safe-qualify.tsv').read_text().splitlines() for sample in range(5)}
  assert seen==expected
  e['runs'].append(dict(name=name,rows=len(lines),sha256=sha(Q/(name+'-timed.tsv')),executable_sha256=row['sha256']));save();print(name,'200 repeated samples',flush=True)
 measure.validate();e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
