from pathlib import Path
import os,subprocess,json,time,hashlib,shutil
D=Path(__file__).parent;S=D/'source';Q=D/'repeat';Q.mkdir(exist_ok=False)
b=json.loads((D/'evidence.json').read_text());assert b['status']=='qualified-not-timed'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**os.environ,'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(Q/'target')}
e={'status':'building','builds':[],'source_evidence_sha256':sha(D/'evidence.json')}
def save():(Q/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
try:
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  args=['cargo','bench','--offline','--locked','--bench','stable_output','--no-run','--message-format=json',*flags]
  with (Q/(name+'-build.jsonl')).open('xb') as out,(Q/(name+'-build.log')).open('xb') as err:p=subprocess.run(args,cwd=S,env=env,stdout=out,stderr=err)
  assert p.returncode==0
  artifacts=[json.loads(line) for line in (Q/(name+'-build.jsonl')).read_text().splitlines() if line.startswith('{')]
  exes=[a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='stable_output' and a.get('executable')];assert len(exes)==1
  exe=Q/name;shutil.copyfile(exes[0],exe);exe.chmod(0o755)
  p=subprocess.run([str(exe),'qualify'],capture_output=True);(Q/(name+'-qualify.tsv')).write_bytes(p.stdout);(Q/(name+'-qualify.stderr')).write_bytes(p.stderr)
  assert p.returncode==0 and p.stdout==(D/'safe-qualify.tsv').read_bytes()
  e['builds'].append(dict(name=name,argv=args,executable=name,sha256=sha(exe)));save();print(name,'independently rebuilt',flush=True)
 for n,h in b['source'].items():assert sha(S/n)==h
 e['status']='qualified-not-timed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
