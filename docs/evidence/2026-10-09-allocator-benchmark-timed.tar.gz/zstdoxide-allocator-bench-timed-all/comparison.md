# Allocator benchmark comparison, 2026-10-09

This is one fixed-order sequential host campaign, not a randomized statistical experiment.
The codec/harness source and five input fixtures were identical to the validated smoke campaign.
Safe ran first, then the twelve individual unsafe features in script order, and all features ran last.
Each configuration ran eleven workloads in the recorded order, each in Global, owned tracking, then borrowed tracking mode.
Every row has five samples, each at least 150 ms. Host scheduling, caches, CPU frequency and thermal drift can affect the differences;
no claim of statistical significance or universal speedup is made. No C throughput comparison was performed.
The coordinator held other codec builds, tests, Miri and benchmarks idle; system-wide activity and temperature were not instrumented.

Streaming rows measure warm reset/process. Other rows measure fresh operation construction/allocation and result drop.
All full correctness scans, fingerprints, source preparation, file I/O and ledger setup were outside timed regions.
TrackingAllocator forwards storage to Global and adds mutex/ledger and owner-clone bookkeeping.
A tracked row faster than its Global row does not establish that tracking accelerates allocation: modes ran sequentially and generate different generic code.
Global allocation counters remain null. Cumulative tracked peaks exclude allocator-internal rounding and transient backing-allocation overlap.
Owned and borrowed tracking payload requests/live/peak/capacity metrics agree; identity creation/drop counters intentionally differ.

## Global: safe versus all unsafe features

Median ns per workload byte with observed five-sample minimum–maximum in brackets. Negative change is a lower observed median.
Codec rows use uncompressed bytes, dictionary preparation uses serialized dictionary bytes, and training uses sample bytes.

| Workload | Safe | All features | Median change | Ranges overlap |
| --- | ---: | ---: | ---: | --- |
| one_shot_encode | 12.055 [11.859, 12.069] | 9.724 [9.712, 10.063] | -19.3% | no |
| one_shot_decode | 1.386 [1.378, 1.396] | 1.120 [1.092, 1.197] | -19.2% | no |
| stream_encode_greedy | 9.418 [9.196, 13.093] | 9.131 [9.104, 9.234] | -3.0% | yes |
| stream_encode_chain | 10.920 [10.327, 11.426] | 10.819 [10.555, 10.881] | -0.9% | yes |
| stream_encode_lazy | 14.346 [13.177, 14.740] | 13.841 [13.412, 14.109] | -3.5% | yes |
| stream_decode | 2.975 [2.856, 2.991] | 2.791 [2.781, 2.881] | -6.2% | yes |
| prepare_dictionary | 3.568 [3.563, 3.580] | 3.633 [3.530, 3.680] | +1.8% | yes |
| dictionary_stream_encode | 10.225 [10.207, 10.277] | 10.204 [9.995, 10.226] | -0.2% | yes |
| dictionary_stream_decode | 5.866 [5.684, 7.058] | 5.707 [5.566, 6.494] | -2.7% | yes |
| raw_training | 8.670 [8.570, 8.690] | 8.562 [8.460, 8.592] | -1.2% | yes |
| formatted_training | 10.127 [9.841, 10.200] | 9.687 [9.671, 10.407] | -4.3% | yes |

## Individual backend values

Each cell is median ns per byte [minimum, maximum], followed by its observed median change from the safe Global row.
These isolated builds test the feature independently; changes in workloads that do not exercise the modified access path are also possible from noise or code layout.
The TSV/JSON records retain full precision, each allocator mode, iteration counts and all samples.

### one_shot_encode

| Configuration | Global timing | Change from safe |
| --- | ---: | ---: |
| safe | 12.055 [11.859, 12.069] | +0.0% |
| unsafe-byte-cursor | 9.847 [9.777, 10.076] | -18.3% |
| unsafe-bitstream | 12.042 [10.624, 12.124] | -0.1% |
| unsafe-history | 10.014 [9.799, 10.338] | -16.9% |
| unsafe-ring-history | 10.348 [10.080, 10.586] | -14.2% |
| unsafe-fse | 9.854 [9.850, 9.973] | -18.3% |
| unsafe-fse-encoder | 10.656 [10.442, 10.803] | -11.6% |
| unsafe-huffman | 10.105 [9.799, 10.196] | -16.2% |
| unsafe-huffman-codebook | 9.845 [9.792, 9.951] | -18.3% |
| unsafe-match-table | 9.766 [9.693, 10.368] | -19.0% |
| unsafe-match-chain | 9.805 [9.779, 10.089] | -18.7% |
| unsafe-dictionary | 9.778 [9.771, 9.855] | -18.9% |
| unsafe-training | 10.255 [9.840, 11.219] | -14.9% |
| all | 9.724 [9.712, 10.063] | -19.3% |

### one_shot_decode

| Configuration | Global timing | Change from safe |
| --- | ---: | ---: |
| safe | 1.386 [1.378, 1.396] | +0.0% |
| unsafe-byte-cursor | 1.331 [1.325, 1.347] | -4.0% |
| unsafe-bitstream | 1.386 [1.335, 1.479] | -0.1% |
| unsafe-history | 1.106 [1.102, 1.135] | -20.3% |
| unsafe-ring-history | 1.453 [1.443, 1.524] | +4.8% |
| unsafe-fse | 1.352 [1.330, 1.378] | -2.5% |
| unsafe-fse-encoder | 1.328 [1.326, 1.352] | -4.2% |
| unsafe-huffman | 1.448 [1.420, 1.573] | +4.5% |
| unsafe-huffman-codebook | 1.357 [1.355, 1.369] | -2.1% |
| unsafe-match-table | 1.365 [1.315, 1.398] | -1.6% |
| unsafe-match-chain | 1.391 [1.372, 1.487] | +0.3% |
| unsafe-dictionary | 1.375 [1.346, 1.415] | -0.8% |
| unsafe-training | 1.334 [1.306, 1.342] | -3.8% |
| all | 1.120 [1.092, 1.197] | -19.2% |

### stream_encode_greedy

| Configuration | Global timing | Change from safe |
| --- | ---: | ---: |
| safe | 9.418 [9.196, 13.093] | +0.0% |
| unsafe-byte-cursor | 9.168 [9.141, 9.301] | -2.7% |
| unsafe-bitstream | 9.090 [9.070, 9.113] | -3.5% |
| unsafe-history | 9.128 [9.110, 9.192] | -3.1% |
| unsafe-ring-history | 9.341 [9.186, 9.409] | -0.8% |
| unsafe-fse | 9.211 [9.123, 9.354] | -2.2% |
| unsafe-fse-encoder | 9.269 [9.197, 11.052] | -1.6% |
| unsafe-huffman | 9.342 [9.149, 9.723] | -0.8% |
| unsafe-huffman-codebook | 9.471 [9.348, 9.884] | +0.6% |
| unsafe-match-table | 9.079 [9.062, 9.246] | -3.6% |
| unsafe-match-chain | 9.086 [9.051, 9.143] | -3.5% |
| unsafe-dictionary | 9.135 [9.133, 9.203] | -3.0% |
| unsafe-training | 9.114 [9.101, 9.156] | -3.2% |
| all | 9.131 [9.104, 9.234] | -3.0% |

### stream_encode_chain

| Configuration | Global timing | Change from safe |
| --- | ---: | ---: |
| safe | 10.920 [10.327, 11.426] | +0.0% |
| unsafe-byte-cursor | 10.708 [10.388, 11.855] | -1.9% |
| unsafe-bitstream | 10.883 [10.722, 11.293] | -0.3% |
| unsafe-history | 11.051 [10.902, 11.439] | +1.2% |
| unsafe-ring-history | 10.913 [10.890, 11.224] | -0.1% |
| unsafe-fse | 10.985 [10.534, 11.018] | +0.6% |
| unsafe-fse-encoder | 10.693 [10.523, 10.937] | -2.1% |
| unsafe-huffman | 10.847 [10.433, 11.019] | -0.7% |
| unsafe-huffman-codebook | 10.962 [10.876, 11.039] | +0.4% |
| unsafe-match-table | 10.829 [10.328, 11.069] | -0.8% |
| unsafe-match-chain | 10.993 [10.480, 11.409] | +0.7% |
| unsafe-dictionary | 10.796 [10.567, 11.378] | -1.1% |
| unsafe-training | 10.868 [10.469, 10.917] | -0.5% |
| all | 10.819 [10.555, 10.881] | -0.9% |

### stream_encode_lazy

| Configuration | Global timing | Change from safe |
| --- | ---: | ---: |
| safe | 14.346 [13.177, 14.740] | +0.0% |
| unsafe-byte-cursor | 13.606 [13.506, 14.890] | -5.2% |
| unsafe-bitstream | 13.967 [13.544, 14.559] | -2.6% |
| unsafe-history | 13.939 [13.701, 14.220] | -2.8% |
| unsafe-ring-history | 13.977 [13.772, 14.667] | -2.6% |
| unsafe-fse | 14.810 [14.201, 14.973] | +3.2% |
| unsafe-fse-encoder | 13.569 [13.525, 13.877] | -5.4% |
| unsafe-huffman | 14.208 [14.061, 14.556] | -1.0% |
| unsafe-huffman-codebook | 14.175 [13.400, 14.496] | -1.2% |
| unsafe-match-table | 14.358 [14.282, 14.513] | +0.1% |
| unsafe-match-chain | 14.060 [13.505, 14.224] | -2.0% |
| unsafe-dictionary | 13.440 [13.352, 13.625] | -6.3% |
| unsafe-training | 13.486 [13.286, 14.839] | -6.0% |
| all | 13.841 [13.412, 14.109] | -3.5% |

### stream_decode

| Configuration | Global timing | Change from safe |
| --- | ---: | ---: |
| safe | 2.975 [2.856, 2.991] | +0.0% |
| unsafe-byte-cursor | 2.997 [2.946, 3.057] | +0.7% |
| unsafe-bitstream | 2.912 [2.900, 2.931] | -2.1% |
| unsafe-history | 2.914 [2.857, 2.982] | -2.1% |
| unsafe-ring-history | 2.971 [2.923, 2.991] | -0.1% |
| unsafe-fse | 2.881 [2.850, 2.912] | -3.2% |
| unsafe-fse-encoder | 2.880 [2.852, 2.948] | -3.2% |
| unsafe-huffman | 3.031 [2.985, 3.073] | +1.9% |
| unsafe-huffman-codebook | 2.926 [2.920, 2.991] | -1.7% |
| unsafe-match-table | 2.960 [2.885, 2.987] | -0.5% |
| unsafe-match-chain | 3.009 [2.936, 3.036] | +1.1% |
| unsafe-dictionary | 3.010 [2.933, 3.060] | +1.1% |
| unsafe-training | 2.884 [2.882, 2.895] | -3.1% |
| all | 2.791 [2.781, 2.881] | -6.2% |

### prepare_dictionary

| Configuration | Global timing | Change from safe |
| --- | ---: | ---: |
| safe | 3.568 [3.563, 3.580] | +0.0% |
| unsafe-byte-cursor | 3.576 [3.558, 3.609] | +0.2% |
| unsafe-bitstream | 3.619 [3.555, 3.662] | +1.4% |
| unsafe-history | 3.578 [3.564, 3.616] | +0.3% |
| unsafe-ring-history | 3.711 [3.596, 3.768] | +4.0% |
| unsafe-fse | 3.597 [3.585, 3.626] | +0.8% |
| unsafe-fse-encoder | 3.618 [3.578, 3.664] | +1.4% |
| unsafe-huffman | 3.478 [3.475, 3.517] | -2.5% |
| unsafe-huffman-codebook | 3.573 [3.570, 3.581] | +0.2% |
| unsafe-match-table | 3.631 [3.613, 3.647] | +1.8% |
| unsafe-match-chain | 3.566 [3.556, 3.575] | -0.1% |
| unsafe-dictionary | 3.577 [3.563, 3.590] | +0.3% |
| unsafe-training | 3.561 [3.501, 3.576] | -0.2% |
| all | 3.633 [3.530, 3.680] | +1.8% |

### dictionary_stream_encode

| Configuration | Global timing | Change from safe |
| --- | ---: | ---: |
| safe | 10.225 [10.207, 10.277] | +0.0% |
| unsafe-byte-cursor | 10.681 [10.342, 10.738] | +4.5% |
| unsafe-bitstream | 10.294 [10.179, 10.427] | +0.7% |
| unsafe-history | 10.135 [9.819, 10.508] | -0.9% |
| unsafe-ring-history | 10.365 [10.350, 10.527] | +1.4% |
| unsafe-fse | 10.486 [10.374, 10.635] | +2.6% |
| unsafe-fse-encoder | 10.366 [10.350, 10.637] | +1.4% |
| unsafe-huffman | 10.505 [9.864, 10.668] | +2.7% |
| unsafe-huffman-codebook | 10.407 [10.118, 10.631] | +1.8% |
| unsafe-match-table | 10.352 [10.210, 10.851] | +1.2% |
| unsafe-match-chain | 10.232 [10.021, 10.305] | +0.1% |
| unsafe-dictionary | 10.296 [10.291, 10.298] | +0.7% |
| unsafe-training | 10.500 [9.919, 10.856] | +2.7% |
| all | 10.204 [9.995, 10.226] | -0.2% |

### dictionary_stream_decode

| Configuration | Global timing | Change from safe |
| --- | ---: | ---: |
| safe | 5.866 [5.684, 7.058] | +0.0% |
| unsafe-byte-cursor | 5.657 [5.378, 5.673] | -3.5% |
| unsafe-bitstream | 5.748 [5.701, 5.794] | -2.0% |
| unsafe-history | 5.606 [5.492, 5.687] | -4.4% |
| unsafe-ring-history | 5.529 [5.435, 5.537] | -5.7% |
| unsafe-fse | 5.383 [5.361, 5.549] | -8.2% |
| unsafe-fse-encoder | 5.461 [5.417, 5.474] | -6.9% |
| unsafe-huffman | 5.469 [5.363, 5.504] | -6.8% |
| unsafe-huffman-codebook | 5.747 [5.492, 5.828] | -2.0% |
| unsafe-match-table | 5.466 [5.350, 5.636] | -6.8% |
| unsafe-match-chain | 5.463 [5.439, 5.579] | -6.9% |
| unsafe-dictionary | 5.682 [5.527, 5.698] | -3.1% |
| unsafe-training | 5.642 [5.410, 5.750] | -3.8% |
| all | 5.707 [5.566, 6.494] | -2.7% |

### raw_training

| Configuration | Global timing | Change from safe |
| --- | ---: | ---: |
| safe | 8.670 [8.570, 8.690] | +0.0% |
| unsafe-byte-cursor | 8.561 [8.476, 10.398] | -1.3% |
| unsafe-bitstream | 8.693 [8.678, 8.723] | +0.3% |
| unsafe-history | 8.674 [8.624, 10.839] | +0.1% |
| unsafe-ring-history | 8.742 [8.605, 8.861] | +0.8% |
| unsafe-fse | 8.781 [8.589, 8.892] | +1.3% |
| unsafe-fse-encoder | 8.471 [8.456, 8.566] | -2.3% |
| unsafe-huffman | 8.591 [8.585, 8.649] | -0.9% |
| unsafe-huffman-codebook | 8.613 [8.529, 8.699] | -0.7% |
| unsafe-match-table | 8.813 [8.595, 8.968] | +1.7% |
| unsafe-match-chain | 8.712 [8.578, 8.767] | +0.5% |
| unsafe-dictionary | 8.505 [8.464, 8.596] | -1.9% |
| unsafe-training | 8.445 [8.363, 8.459] | -2.6% |
| all | 8.562 [8.460, 8.592] | -1.2% |

### formatted_training

| Configuration | Global timing | Change from safe |
| --- | ---: | ---: |
| safe | 10.127 [9.841, 10.200] | +0.0% |
| unsafe-byte-cursor | 9.857 [9.744, 9.967] | -2.7% |
| unsafe-bitstream | 9.899 [9.811, 10.023] | -2.2% |
| unsafe-history | 9.872 [9.870, 10.070] | -2.5% |
| unsafe-ring-history | 10.338 [10.257, 10.670] | +2.1% |
| unsafe-fse | 9.838 [9.706, 9.880] | -2.9% |
| unsafe-fse-encoder | 9.907 [9.827, 10.080] | -2.2% |
| unsafe-huffman | 9.927 [9.801, 9.987] | -2.0% |
| unsafe-huffman-codebook | 9.768 [9.750, 9.777] | -3.5% |
| unsafe-match-table | 9.854 [9.852, 10.032] | -2.7% |
| unsafe-match-chain | 9.854 [9.821, 9.914] | -2.7% |
| unsafe-dictionary | 10.120 [9.952, 10.209] | -0.1% |
| unsafe-training | 9.605 [9.582, 9.640] | -5.2% |
| all | 9.687 [9.671, 10.407] | -4.3% |

## Validation and artifacts

All fourteen commands exited zero. The runner validated 462 rows and 2,310 samples.
Every row matched the safe configuration in all non-timing fields, including full-output/source/dictionary fingerprints, output sizes,
cold/reset/final-drop allocation counts, peaks, owner metrics and retained capacities.
All 308 tracked final-drop records have zero live blocks, bytes and requested bytes, balanced owner creation/drop, no violations and no failures.
Global counters are uninstrumented. Prepared-context retained capacity includes the external dictionary whereas its payload is outside that context allocator survey.
Dictionary/training retained capacity remains null because the public dictionary API does not expose it.

- `summary.md`: allocation counts, capacities and safe-backend allocator-mode timings.
- `timings.tsv`: all 462 rows, medians, ranges and same-mode safe-relative differences.
- `samples.tsv`: all 2,310 samples with iterations, elapsed nanoseconds and normalized value.
- `allocation-surveys.tsv`: every raw snapshot counter and capacity.
- `results.json` and fourteen `*.jsonl`: complete machine-readable results.
- `commands.json`, fourteen `*.cargo.log`, `validation.log`: commands and validation.
- `source.json`, `environment.json`, `host-details.json`: compiler, revision, source/input hashes and host probes.
- `comparison.json`: full-precision Global safe/all comparisons.

Source/input fingerprint: `2b2c51a395d53d658db1089fdbbc7937c28f5543759c5962a09729d808d11686`.
Captured Git revision: `2e12c1862bf7c8b882977ee1daf2a73037a0f47b`; initial worktree clean.
Compiler: `rustc 1.101.0-nightly (1d81eb4ad 2026-10-07)`, target `aarch64-apple-darwin`, macOS 15.7.7.
Cargo bench uses release optimization and repository `overflow-checks = true`; no custom RUSTFLAGS override was requested.
Some hardware sysctl probes were denied by the sandbox; their exact exit status and diagnostics are preserved, with no inferred CPU model.
