# Allocator benchmark measurements

All 33 workload/allocation-mode rows agree across 14 backend configurations.
Full output bytes are compared against each workload's Global reference before and after timing;
source, dictionary and full-output FNV-1a fingerprints also match across configurations.
These noncryptographic fingerprints supplement the codec's separate interoperability tests.

Streaming rows time reset/process with reused context and fixed caller buffers. Whole-buffer,
parsing and training rows time fresh operation allocation and result destruction. Full scans,
fingerprints, correctness comparisons, allocator setup, source/dictionary preparation and I/O
are outside timing. Progress/stall checks and black_box observation remain in streaming drivers.

TrackingAllocator delegates storage to Global. Its timings include lock/ledger bookkeeping and
fresh allocator-owner identities where applicable; this does not measure a different heap allocator.
Owned tracking clones are deliberately non-equivalent domains. Borrowed tracking uses one non-Clone
owner and reference copies. Global payload counters are uninstrumented null values, never inferred.

Each allocation survey uses its own fresh monitor, independently of timing: before construction,
after one cold operation with results/context live, after streaming reset, and after final owner drop.
Peak values are cumulative high-water marks, not differences or per-operation peak estimates.
Live/peak bytes describe returned payload layouts; they exclude underlying allocator rounding
beyond returned sizes and transient Global old/new overlap during resizing. Separate retained
capacities describe reachable context heap or result Vec capacity, excluding inline objects and
caller buffers. Prepared streaming context capacity includes the external borrowed dictionary;
its payload, any Arc/Rc control blocks, fixture setup, helper Arc/Mutex/ledger, and caller buffers
are outside the context's measured allocator domain. Dictionary/training retained capacity is null
because the public Dictionary API does not expose it; serialized length is not relabeled capacity.

Values below are median ns per workload byte, followed by the observed sample range.
Codec units are uncompressed bytes; parsing uses serialized dictionary bytes; training uses sample bytes.
They include the stated harness/API costs, are host/configuration specific, and are not universal speedups.
All raw samples and all backend configurations remain in the adjacent JSONL/JSON records.

| Safe-backend workload | Global | Tracking owned | Tracking borrowed |
| --- | ---: | ---: | ---: |
| one_shot_encode | 12.055 [11.859, 12.069] | 10.591 [10.455, 12.652] | 11.477 [9.856, 12.251] |
| one_shot_decode | 1.386 [1.378, 1.396] | 1.340 [1.336, 1.413] | 1.423 [1.338, 1.679] |
| stream_encode_greedy | 9.418 [9.196, 13.093] | 10.161 [9.736, 10.444] | 9.253 [9.203, 9.305] |
| stream_encode_chain | 10.920 [10.327, 11.426] | 11.360 [11.080, 11.643] | 10.791 [10.393, 11.264] |
| stream_encode_lazy | 14.346 [13.177, 14.740] | 14.248 [14.042, 14.992] | 14.246 [13.741, 14.597] |
| stream_decode | 2.975 [2.856, 2.991] | 2.974 [2.931, 3.025] | 2.944 [2.924, 3.003] |
| prepare_dictionary | 3.568 [3.563, 3.580] | 4.112 [4.067, 4.169] | 3.571 [3.510, 3.588] |
| dictionary_stream_encode | 10.225 [10.207, 10.277] | 11.262 [10.828, 11.307] | 10.608 [10.453, 21.310] |
| dictionary_stream_decode | 5.866 [5.684, 7.058] | 6.400 [6.342, 6.413] | 5.837 [5.587, 5.947] |
| raw_training | 8.670 [8.570, 8.690] | 9.138 [9.128, 9.151] | 8.565 [8.500, 8.600] |
| formatted_training | 10.127 [9.841, 10.200] | 10.455 [10.452, 10.483] | 9.832 [9.722, 9.850] |

| Workload | Allocator | Output bytes | Cold attempts | Cold live bytes | Cold peak bytes | Cold identities | Cold / reset capacity |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| one_shot_encode | global | 3131 | not instrumented | not instrumented | not instrumented | not instrumented | 32788 / not exposed |
| one_shot_encode | tracking_owned | 3131 | 132 | 32788 | 1100879 | 124 | 32788 / not exposed |
| one_shot_encode | tracking_borrowed | 3131 | 132 | 32788 | 1100879 | 1 | 32788 / not exposed |
| one_shot_decode | global | 32768 | not instrumented | not instrumented | not instrumented | not instrumented | 34816 / not exposed |
| one_shot_decode | tracking_owned | 32768 | 15 | 34816 | 41210 | 8 | 34816 / not exposed |
| one_shot_decode | tracking_borrowed | 32768 | 15 | 34816 | 41210 | 1 | 34816 / not exposed |
| stream_encode_greedy | global | 3130 | not instrumented | not instrumented | not instrumented | not instrumented | 1263821 / 1263821 |
| stream_encode_greedy | tracking_owned | 3130 | 134 | 1263821 | 1330242 | 125 | 1263821 / 1263821 |
| stream_encode_greedy | tracking_borrowed | 3130 | 134 | 1263821 | 1330242 | 1 | 1263821 / 1263821 |
| stream_encode_chain | global | 2738 | not instrumented | not instrumented | not instrumented | not instrumented | 10056019 / 10056019 |
| stream_encode_chain | tracking_owned | 2738 | 135 | 10056019 | 10192861 | 126 | 10056019 / 10056019 |
| stream_encode_chain | tracking_borrowed | 2738 | 135 | 10056019 | 10192861 | 1 | 10056019 / 10056019 |
| stream_encode_lazy | global | 2721 | not instrumented | not instrumented | not instrumented | not instrumented | 10055656 / 10055656 |
| stream_encode_lazy | tracking_owned | 2721 | 135 | 10055656 | 10192530 | 126 | 10055656 / 10055656 |
| stream_encode_lazy | tracking_borrowed | 2721 | 135 | 10055656 | 10192530 | 1 | 10055656 / 10055656 |
| stream_decode | global | 32768 | not instrumented | not instrumented | not instrumented | not instrumented | 68653 / 68653 |
| stream_decode | tracking_owned | 32768 | 7 | 68653 | 75047 | 10 | 68653 / 68653 |
| stream_decode | tracking_borrowed | 32768 | 7 | 68653 | 75047 | 1 | 68653 / 68653 |
| prepare_dictionary | global | 2197 | not instrumented | not instrumented | not instrumented | not instrumented | not exposed / not exposed |
| prepare_dictionary | tracking_owned | 2197 | 8 | 11413 | 11413 | 8 | not exposed / not exposed |
| prepare_dictionary | tracking_borrowed | 2197 | 8 | 11413 | 11413 | 1 | not exposed / not exposed |
| dictionary_stream_encode | global | 2598 | not instrumented | not instrumented | not instrumented | not instrumented | 1939204 / 1939204 |
| dictionary_stream_encode | tracking_owned | 2598 | 140 | 1927791 | 2052388 | 135 | 1939204 / 1939204 |
| dictionary_stream_encode | tracking_borrowed | 2598 | 140 | 1927791 | 2052388 | 1 | 1939204 / 1939204 |
| dictionary_stream_decode | global | 1189 | not instrumented | not instrumented | not instrumented | not instrumented | 17099 / 17099 |
| dictionary_stream_decode | tracking_owned | 1189 | 7 | 2787 | 3713 | 10 | 17099 / 17099 |
| dictionary_stream_decode | tracking_borrowed | 1189 | 7 | 2787 | 3713 | 1 | 17099 / 17099 |
| raw_training | global | 2048 | not instrumented | not instrumented | not instrumented | not instrumented | not exposed / not exposed |
| raw_training | tracking_owned | 2048 | 20 | 2048 | 299008 | 6 | not exposed / not exposed |
| raw_training | tracking_borrowed | 2048 | 20 | 2048 | 299008 | 1 | not exposed / not exposed |
| formatted_training | global | 2048 | not instrumented | not instrumented | not instrumented | not instrumented | not exposed / not exposed |
| formatted_training | tracking_owned | 2048 | 48 | 6784 | 299008 | 24 | not exposed / not exposed |
| formatted_training | tracking_borrowed | 2048 | 48 | 6784 | 299008 | 1 | not exposed / not exposed |

All tracked final-drop snapshots report zero live payload and no violations or failures.
Allocation counts/capacities are checked for equality across backend builds on this host;
they are not assumed invariant across pointer widths, operating systems, or allocators.
