from pathlib import Path
import hashlib,json,sys
base=Path(__file__).resolve().parent;out=Path(sys.argv[1]).resolve()
if out.exists() or out.is_relative_to(base) or base.is_relative_to(out):raise ValueError("fresh disjoint output required")
rows=json.loads((base/"file-map.json").read_bytes());out.mkdir(parents=True)
for name,row in rows.items():
 p=Path(name)
 if p.is_absolute() or ".." in p.parts:raise ValueError("unsafe relative name")
 chunks=[]
 for key in row["chunks"]:
  b=(base/"chunks"/(key+".bin")).read_bytes()
  if hashlib.sha256(b).hexdigest()!=key:raise ValueError("chunk digest")
  chunks.append(b)
 b=b"".join(chunks)
 if len(b)!=row["bytes"] or hashlib.sha256(b).hexdigest()!=row["sha256"]:raise ValueError("file digest")
 target=out/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
print("Reconstructed",len(rows),"exact files into",out)
