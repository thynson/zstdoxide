import os, pathlib, subprocess, json, hashlib, time, re, tempfile
REPO=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize')
PREFIX=pathlib.Path('/tmp/zstdoxide-module9-final-8703ff4')
REV='8703ff4d74f9a87b40ab63a491408848de198a0c'
PREFIX.mkdir(exist_ok=True)
ROOT=PREFIX/'source'
if ROOT.exists(): raise SystemExit('refusing to replace existing isolated source')
ROOT.mkdir()
archive=PREFIX/'source.tar'
with archive.open('wb') as output: subprocess.run(['git','archive','--format=tar',REV],cwd=REPO,stdout=output,check=True)
subprocess.run(['tar','-xf',str(archive),'-C',str(ROOT)],check=True)
def source_hashes():
 return {str(p.relative_to(ROOT)):hashlib.sha256((os.readlink(p).encode() if p.is_symlink() else p.read_bytes())).hexdigest() for p in sorted(ROOT.rglob('*')) if p.is_file() or p.is_symlink()}
initial=source_hashes()
(PREFIX/'source-hashes-before.json').write_text(json.dumps(initial,indent=2)+'\n')
env=os.environ.copy();env.update({'CARGO_TARGET_DIR':str(PREFIX/'target'),'RUSTUP_TOOLCHAIN':'nightly-2026-10-08','ZSTD_UPSTREAM':'/tmp/zstdoxize-upstream-1.5.7','ZSTD_BIN':'/tmp/zstdoxize-upstream-1.5.7/programs/zstd','ZSTD_DECODECORPUS':'/tmp/zstdoxize-upstream-1.5.7/tests/decodecorpus'})
features=['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-dictionary','unsafe-training']
commands=[]
def add(name,command,kind='check'):commands.append((name,command,kind))
add('compiler',['rustc','--version','--verbose']);add('cargo',['cargo','--version','--verbose']);add('official-version',[env['ZSTD_BIN'],'--version'])
add('inventory',['python3','scripts/audit_upstream_tests.py','--upstream',env['ZSTD_UPSTREAM']]);add('fixtures',['python3','scripts/check_upstream_fixtures.py'])
add('fmt',['cargo','fmt','--all','--','--check']);add('allocator-fmt',['cargo','fmt','--manifest-path','test-support/allocator/Cargo.toml','--','--check'])
add('allocator-tests',['cargo','test','--manifest-path','test-support/allocator/Cargo.toml'],'tests');add('allocator-clippy',['cargo','clippy','--manifest-path','test-support/allocator/Cargo.toml','--all-targets','--','-D','warnings'])
add('tests-default',['cargo','test','--locked'],'tests')
add('usage-default',['python3','scripts/check_doc_examples.py'],'tests')
add('clippy-default',['cargo','clippy','--locked','--all-targets','--','-D','warnings'])
add('no-std-default',['cargo','check','--locked','--no-default-features'])
for feature in features:
 add('tests-'+feature,['cargo','test','--locked','--features',feature],'tests')
 add('no-std-'+feature,['cargo','check','--locked','--no-default-features','--features',feature])
add('tests-all',['cargo','test','--locked','--all-features'],'tests')
add('tests-release-all',['cargo','test','--locked','--release','--all-features'],'tests')
add('no-std-all',['cargo','check','--locked','--no-default-features','--features',','.join(features)])
add('clippy-all',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings'])
add('usage-all',['python3','scripts/check_doc_examples.py','--all-features'],'tests')
for config,flags in [('safe',[]),('all',['--all-features'])]:
 base=['cargo','test','--locked','--release',*flags]
 add('oracle-interop-'+config,base+['--test','interop','--','--ignored','--nocapture'],'oracle')
 add('oracle-streaming-'+config,base+['--test','upstream_streaming','official_codec_accepts_streamed_frames_and_stream_decoder_accepts_official_frames','--','--ignored','--exact','--nocapture'],'oracle')
 add('oracle-dictionary-'+config,base+['--test','upstream_dictionary_encode','--','--ignored','--nocapture'],'oracle')
 add('oracle-raw-training-'+config,base+['--test','upstream_training','--','--ignored','--nocapture'],'oracle')
 add('oracle-formatted-training-'+config,base+['--test','upstream_formatted_training','official_codec_loads_learned_metadata_and_roundtrips_in_both_directions','--','--ignored','--exact','--nocapture'],'oracle')
 for name,selector in [
   ('allocator-one-shot','encode::tests::official_codec_decodes_allocator_one_shot_frames'),
   ('allocator-stream-encoder','stream_encode::tests::official_codec_decodes_custom_allocator_streams_with_independent_dictionary_owners'),
   ('allocator-stream-decoder','stream_decode::tests::official_frames_decode_through_custom_shared_and_borrowed_allocators')]:
  add('oracle-'+name+'-'+config,base+['--lib',selector,'--','--ignored','--exact','--nocapture'],'oracle')
(PREFIX/'plan.json').write_text(json.dumps({'revision':REV,'source_root':str(ROOT),'source_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'initial_file_count':len(initial),'environment':{k:env[k] for k in ['CARGO_TARGET_DIR','RUSTUP_TOOLCHAIN','ZSTD_UPSTREAM','ZSTD_BIN','ZSTD_DECODECORPUS']},'commands':commands},indent=2)+'\n')
records=[]
for name,command,kind in commands:
 start=time.monotonic();log=PREFIX/(name+'.log')
 print('START',name,flush=True)
 with log.open('wb') as output:
  result=subprocess.run(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT)
 text=log.read_text(errors='replace')
 counts=[{'passed':int(p),'failed':int(f),'ignored':int(i),'measured':int(m),'filtered_out':int(x)} for p,f,i,m,x in re.findall(r'test result: .*?\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)]
 totals={key:sum(row[key] for row in counts) for key in ['passed','failed','ignored','measured','filtered_out']}
 current=source_hashes();changed=[path for path,sha in initial.items() if current.get(path)!=sha]
 record={'name':name,'command':command,'kind':kind,'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'test_results':counts,'test_totals':totals,'source_changed':changed}
 if kind in ['tests','oracle'] and totals['passed']==0: record['validation_failure']='test selector ran no passing tests'
 if changed:record['validation_failure']='tracked archive source mutated'
 records.append(record);(PREFIX/'records.json').write_text(json.dumps(records,indent=2)+'\n')
 print('DONE',name,result.returncode,totals,'seconds',record['seconds'],flush=True)
 if result.returncode or 'validation_failure' in record:
  print('FAILURE',str(log),flush=True);raise SystemExit(1)
final=source_hashes();(PREFIX/'source-hashes-after.json').write_text(json.dumps(final,indent=2)+'\n')
(PREFIX/'summary.json').write_text(json.dumps({'revision':REV,'source_root':str(ROOT),'initial_file_count':len(initial),'tracked_source_unchanged':all(final.get(p)==sha for p,sha in initial.items()),'generated_files':sorted(set(final)-set(initial)),'records':len(records),'all_passed':True,'excluded':'Concurrent benchmark inputs, giant Miri and 89MiB campaigns are intentionally separate.'},indent=2)+'\n')
print('COMPLETE',len(records),flush=True)
