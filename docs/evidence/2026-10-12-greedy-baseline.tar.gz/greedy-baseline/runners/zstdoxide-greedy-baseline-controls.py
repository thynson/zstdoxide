from pathlib import Path
import contextlib,hashlib,json,os,runpy,shutil,subprocess,tempfile
from unittest.mock import patch
repo=Path('/Users/lanxingcan/Workspace/zstdoxize')
m=runpy.run_path(str(repo/'scripts/check_reference_greedy_baseline.py'))
root=Path(tempfile.mkdtemp(prefix='zstdoxide-greedy-baseline-controls-',dir='/tmp')).resolve()
archive=root/m['ARCHIVE'];archive.parent.mkdir(parents=True)
shutil.copyfile(repo/m['ARCHIVE'],archive)
fixture=root/m['COLLECTION'];shutil.copytree(repo/m['COLLECTION'],fixture)
original={n:p.read_bytes() for n,p in [(n,fixture/n) for n in ('expected.tsv','frames.bin','provenance.json','README.md')]}
original_archive=archive.read_bytes();calls=[];results=[]
def denied(*a,**kw):calls.append('process');raise RuntimeError('process creation forbidden')
def control(name,edit,undo):
 edit()
 try:
  try:m['audit'](root)
  except (ValueError,OSError,KeyError,TypeError):results.append({'case':name,'rejected':True})
  else:raise RuntimeError('mutation accepted: '+name)
 finally:undo()
def file_case(name,file,transform):
 p=fixture/file
 changed=transform(original[file])
 if changed==original[file]:raise RuntimeError('ineffective mutation: '+name)
 control(name,lambda:p.write_bytes(changed),lambda:p.write_bytes(original[file]))
def change_json(field,value):
 def transform(b):
  d=json.loads(b);d[field]=value;return (json.dumps(d)+'\n').encode()
 return transform
with contextlib.ExitStack() as st:
 for module,name in [(subprocess,'Popen'),(os,'system'),(os,'posix_spawn'),(os,'posix_spawnp')]:
  if hasattr(module,name):st.enter_context(patch.object(module,name,denied))
 if m['audit'](root)!=32:raise RuntimeError('positive count')
 file_case('complete-frame-byte','frames.bin',lambda b:bytes([b[0]^1])+b[1:])
 file_case('truncated-frame-pack','frames.bin',lambda b:b[:-1])
 file_case('extra-frame-byte','frames.bin',lambda b:b+b'\0')
 file_case('allocation-field','expected.tsv',lambda b:b.replace(b'\t553\t453\t100\t',b'\t554\t453\t100\t',1))
 file_case('source-fingerprint','expected.tsv',lambda b:b.replace(b'2023247e1659a142',b'2023247e1659a143',1))
 file_case('missing-row','expected.tsv',lambda b:b.rsplit(b'\n',2)[0]+b'\n')
 file_case('provenance-bool-count','provenance.json',change_json('rows',True))
 file_case('provenance-float-count','provenance.json',change_json('rows',32.0))
 file_case('provenance-source','provenance.json',change_json('source',{}))
 file_case('duplicate-json-key','provenance.json',lambda b:b.replace(b'{',b'{"rows":32,',1))
 file_case('non-finite-json','provenance.json',lambda b:b.replace(b'"rows": 32',b'"rows": NaN',1))
 file_case('empty-readme','README.md',lambda b:b'')
 extra=fixture/'unexpected'
 control('extra-fixture',lambda:extra.write_text('x'),lambda:extra.unlink())
 p=fixture/'frames.bin'
 def link():p.unlink();p.symlink_to(repo/m['COLLECTION']/'frames.bin')
 def unlink():p.unlink();p.write_bytes(original['frames.bin'])
 control('escaping-fixture-link',link,unlink)
 control('changed-archive',lambda:archive.write_bytes(bytes([original_archive[0]^1])+original_archive[1:]),lambda:archive.write_bytes(original_archive))
 if m['audit'](root)!=32:raise RuntimeError('restored count')
if calls:raise RuntimeError('child creation attempted')
if len(results)!=15:raise RuntimeError('wrong controls')
report={'positive':2,'rejected':len(results),'child_processes':len(calls),'cases':results,'optimized':not __debug__,'checker_sha256':hashlib.sha256((repo/'scripts/check_reference_greedy_baseline.py').read_bytes()).hexdigest()}
print(json.dumps(report,sort_keys=True))
shutil.rmtree(root)
