from pathlib import Path
import hashlib,json,os,re,subprocess,time,sys
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-greedy-baseline-checks');O.mkdir()
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'scripts'))
import benchmark_search as shared
paths=set((R/'src').rglob('*.rs'))|set((R/'test-support/allocator').rglob('*.rs'))|set((R/'tests/fixtures/reference-greedy-baseline').iterdir())
paths.update(R/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/reference_greedy_defaults.rs','scripts/check_reference_greedy_baseline.py'])
def manifest():return {str(p.relative_to(R)):shared.sha(p) for p in sorted(paths)}
before=manifest();env=shared.effective_environment()|{'CARGO_TARGET_DIR':'/tmp/zstdoxide-module13-final-matrix/target','CARGO_TERM_COLOR':'never'}
e={'status':'running','source':before,'environment':env,'commands':[]}
def save():(O/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
commands=[]
for mode,flags in [('safe',[]),('chain',['--features','unsafe-reference-chain']),('row',['--features','unsafe-row-table']),('all',['--all-features'])]:commands.append(('test-'+mode,['cargo','+nightly-2026-10-08','test','--offline','--locked','--test','reference_greedy_defaults',*flags]))
for mode,flags in [('safe',[]),('all',['--all-features'])]:commands.append(('clippy-'+mode,['cargo','+nightly-2026-10-08','clippy','--offline','--locked','--test','reference_greedy_defaults',*flags,'--','-D','warnings']))
commands.append(('format',['rustfmt','+nightly-2026-10-08','--edition','2024','--config','skip_children=true','--check','tests/reference_greedy_defaults.rs']))
try:
 for label,argv in commands:
  if manifest()!=before:raise RuntimeError('source changed')
  print('START',label,flush=True);p=O/(label+'.log');start=time.monotonic()
  with p.open('wb') as log:r=subprocess.run(argv,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
  raw=p.read_bytes();row={'label':label,'argv':argv,'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':p.name,'log_sha256':shared.sha(p)}
  if label.startswith('test-'):
   row['totals']=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',raw)
   row['totals']=[list(map(int,x)) for x in row['totals']]
   if row['totals']!=[[9,0,0,0,0]]:raise RuntimeError('unexpected tests '+label)
  e['commands'].append(row);save();print('END',label,r.returncode,flush=True)
  if r.returncode:raise RuntimeError(label)
 if manifest()!=before:raise RuntimeError('source changed')
 e.update(status='passed',source_unchanged=True,test_executions=36);save()
except BaseException as error:
 e.update(status='failed',error=repr(error));save();raise
