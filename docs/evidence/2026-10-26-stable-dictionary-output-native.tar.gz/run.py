from pathlib import Path
import json,hashlib,shutil,subprocess
D=Path(__file__).parent;P=Path('/private/tmp/module25-native');I=D/'inputs'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((D/'build.json').read_text());assert b['status']=='passed'
shutil.copytree(P/'inputs',I)
base=json.loads((P/'cases.json').read_text());assert len(base)==119
cases=[dict(row,chunk=chunk) for row in base for chunk in [1,7,4194304]]
(D/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(D/'rust-cases.tsv').write_text(''.join(f"{r['name']}\t{r['capacity']}\t{r['chunk']}\t{r['rust']}\n" for r in cases))
e=dict(status='running',build_sha256=sha(D/'build.json'),cases_sha256=sha(D/'cases.json'),inputs={p.name:sha(p) for p in I.iterdir()},valid_frames=22,common_cases=len(cases),results=[])
def save():(D/'native.json').write_text(json.dumps(e,indent=2)+'\n')
assert not (D/'native.json').exists();save()
try:
 for backend in ['normal','sanitized']:
  assert sha(D/('oracle-'+backend))==b['executables'][backend]
  for mode in ['prepared','loaded']:
   O=D/(backend+'-'+mode);O.mkdir()
   for index,case in enumerate(cases):
    name=case['name'];args=[str(D/('oracle-'+backend)),str(I/(name+'.zst')),str(case['capacity']),str(O/(str(index)+'.bin')),str(case['chunk']),str(I/(name+'.dict')),mode]
    p=subprocess.run(args,capture_output=True,timeout=30);(O/(str(index)+'.stdout')).write_bytes(p.stdout);(O/(str(index)+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(backend,mode,index,p.stderr)
    result=json.loads(p.stdout);assert result['version']==10507 and result['guards']==1
    expect=case['native']
    if expect=='ok':assert result['complete'] and not result['error'] and (O/(str(index)+'.bin')).read_bytes()==(I/(name+'.raw')).read_bytes(),(backend,mode,index,result)
    else:
     assert not result['complete'],(backend,mode,index,result)
     if expect in ['small','checksum','dictionary']:assert result['error_code']=={'small':70,'checksum':22,'dictionary':32}[expect],(backend,mode,index,result)
    e['results'].append(dict(backend=backend,mode=mode,index=index,case=case,result=result,output_sha256=sha(O/(str(index)+'.bin'))));save()
   print(backend,mode,len(cases),'cases passed',flush=True)
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
