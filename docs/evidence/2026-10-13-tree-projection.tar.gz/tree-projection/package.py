from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';sha=lambda b:hashlib.sha256(b).hexdigest()
reports={m:json.loads(Path('/tmp/zstdoxide-tree-projection-'+m+'.json').read_text()) for m in ('write','normal','optimized')}
if not all(r==reports['write'] for r in reports.values()):raise ValueError('projection agreement')
controls={m:json.loads(Path('/tmp/zstdoxide-tree-projection-controls-'+m+'.json').read_text()) for m in ('normal','optimized')}
for mode,c in controls.items():
 if c['status']!='passed' or len(c['rejected'])!=4 or c['child_processes']!=0 or c['optimized']!=(mode=='optimized'):raise ValueError('controls')
 if c['projector_sha256']!=sha((R/'scripts/pack_tree_fixtures.py').read_bytes()):raise ValueError('source')
files={str(p.relative_to(R)):p.read_bytes() for p in (R/'tests/fixtures/reference-tree').iterdir() if p.is_file()}
for n in ['scripts/pack_tree_fixtures.py','docs/reference-tree-fixtures.md']:files[n]=(R/n).read_bytes()
for p in Path('/tmp').glob('zstdoxide-tree-projection-*'):
 if p.is_file():files['checks/'+p.name]=p.read_bytes()
files['package.py']=Path(__file__).read_bytes()
a=E/'2026-10-13-tree-projection.tar.gz'
if a.exists():raise ValueError('fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('tree-projection/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:actual={m.name:t.extractfile(m).read() for m in t}
if actual!={'tree-projection/'+n:b for n,b in files.items()}:raise ValueError('archive bytes')
r=dict(status='passed',projection=reports['write'],controls=controls,archive=a.name,archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files),qualification='Immutable C artifact projection, independently compared in both Python modes. A later Rust reader review caught a prose parameter-order typo, corrected to the unchanged upstream W,C,H order before this checkpoint. Captured and projected bytes were unchanged; no tree implementation is claimed.')
(E/'2026-10-13-tree-projection.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print(r['projection'])
