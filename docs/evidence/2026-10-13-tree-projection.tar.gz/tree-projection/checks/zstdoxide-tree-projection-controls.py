from pathlib import Path
import hashlib,json,sys,tempfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'scripts'))
import pack_tree_fixtures as p
attempts=[]
def hook(event,args):
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec','os.spawn'):attempts.append(event);raise RuntimeError('child forbidden')
sys.addaudithook(hook)
original=sys.argv;results=[]
with tempfile.TemporaryDirectory(prefix='zstdoxide-tree-projection-') as d:
 d=Path(d);f=R/'tests/fixtures/reference-tree'
 # The real CLI must reject a truncated fixture and coherently altered provenance.
 for name,data,metadata in [('truncated',(f/'cases.bin').read_bytes()[:-1],(f/'provenance.json').read_bytes()),('provenance',(f/'cases.bin').read_bytes(),b'{}\n')]:
  (d/'cases.bin').write_bytes(data);(d/'provenance.json').write_bytes(metadata)
  sys.argv=['pack_tree_fixtures.py','--directory',str(d)]
  try:p.main()
  except SystemExit as e:
   if e.code!=1:raise
   results.append(name)
  else:raise ValueError('forgery accepted')
for name,field,call in [('archive','ARCHIVE_SHA',p.archived_files),('input-owner','INPUTS_SHA',p.project)]:
 old=getattr(p,field);setattr(p,field,'0'*64)
 try:
  try:call()
  except ValueError:results.append(name)
  else:raise ValueError('identity accepted')
 finally:setattr(p,field,old)
sys.argv=original
if attempts:raise ValueError('children')
print(json.dumps(dict(status='passed',optimized=not __debug__,rejected=results,child_processes=0,projector_sha256=hashlib.sha256((R/'scripts/pack_tree_fixtures.py').read_bytes()).hexdigest()),sort_keys=True))
