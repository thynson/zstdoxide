from pathlib import Path
import json,hashlib,subprocess,os,time,shutil
D=Path(__file__).parent;S=D/'source';R=Path('/private/tmp/module33-public/source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while True:
 try:gate=json.loads(Path('/private/tmp/module33-public/evidence.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):gate={'status':'running'}
 assert gate['status']!='failed',gate.get('error')
 if gate['status']=='passed':break
 time.sleep(5)
assert not S.exists();subprocess.run(['cp','-cR',str(R),str(S)],check=True);p=S/'tests/upstream_fuzz_targets.rs';s=p.read_text();needle='    assert_eq!(first, second, "compression must be deterministic");';assert s.count(needle)==1;s=s.replace(needle,needle+'''
    // Supplemental caller-owned output contract on the unchanged upstream
    // source selection. This is not its random destination-capacity selector.
    let mut output = vec![0xa5; first.len() + 34];
    let written = zstdoxide::compress_into(source, &mut output[16..16 + first.len() + 2])
        .expect("actual encoded length fits below a sufficient bound");
    assert_eq!(written, first.len());
    assert_eq!(&output[16..16 + written], first);
    assert!(output[..16].iter().chain(&output[16 + written..]).all(|&b| b == 0xa5));
    output.fill(0xa5);
    assert_eq!(zstdoxide::compress_into(source, &mut output[16..15 + first.len()]), Err(Error::ResourceLimit));
    assert!(output[..16].iter().chain(&output[15 + first.len()..]).all(|&b| b == 0xa5));
''');needle='fn simple_round_trip_deterministic_corpus() {\n    for case in deterministic_corpus() {';assert needle in s;s=s.replace(needle,'fn simple_round_trip_deterministic_corpus() {\n    let cases = deterministic_corpus();\n    assert_eq!(cases.len(), 347);\n    for case in cases {');p.write_text(s);subprocess.run(['cargo','fmt','--all'],cwd=S,check=True)
e=dict(status='running',source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()},commands=[]);env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for label,args in [(name,['cargo','test','--offline','--locked','--test','upstream_fuzz_targets',*flags,'simple_round_trip_deterministic_corpus','--','--exact']) for name,flags in [('safe',[]),('sink',['--features','unsafe-frame-sink']),('all',['--all-features'])]]+[('clippy',['cargo','clippy','--offline','--locked','--test','upstream_fuzz_targets','--all-features','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check'])]:
  t=time.monotonic()
  with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log'))));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
  if label in ['safe','sink','all']:assert '1 passed; 0 failed; 0 ignored' in (D/(label+'.log')).read_text()
 for n,h in e['source'].items():assert sha(S/n)==h,n
 e.update(status='passed',cases=347,qualification='All347 unchanged deterministic fuzz inputs retain exact tail-selected source prefixes and original deterministic allocating-output/decode assertions. Supplemental caller-owned actual-size-plus-two and actual-size-minus-one calls compare complete success bytes, typed short errors and guards under safe/sink/all. The original random destination selector and unsupported advanced parameter/context branches are not newly claimed. This is the retained deterministic corpus, not an external complete rolling corpus run.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
