from pathlib import Path
import argparse,json,hashlib,tarfile,datetime,re
p=argparse.ArgumentParser();p.add_argument('stage',choices=['engine','public-api','native','platform','corpus']);a=p.parse_args();D=Path(__file__).parent;T=Path('/private/tmp');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
config={'engine':('module33-engine','source',['evidence.json'],13),'public-api':('module33-public','source',['evidence.json'],21),'native':('module33-native','replay-source',['build.json','export.json','native.json','replay.json'],6),'platform':('module33-platform','source',['evidence.json'],8),'corpus':('module33-corpus','source',['evidence.json'],5)};folder,source,receipts,count=config[a.stage];C=T/folder;S=C/source;records={n:json.loads((C/n).read_text()) for n in receipts}
for n,j in records.items():assert j['status']=='passed',(n,j['status']);assert all(r['exit_code']==0 for r in j.get('commands',[])),n
assert len(records[receipts[-1]]['commands'])==count
complete={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};production={n:h for n,h in complete.items() if n.startswith('src/')}
for n,j in records.items():
 for path,h in j.get('source',{}).items():assert complete[path]==h,(n,path)
 for row in j.get('commands',[]):
  if 'log_sha256' in row:assert any(sha(p)==row['log_sha256'] for p in C.glob('*.log')),(n,row.get('label'))
if a.stage in ['engine','public-api']:
 for row in records['evidence.json']['commands']:
  count={'unit':6,'header':1,'public':4,'docs':2}.get(row['label'].rsplit('-',1)[-1])
  if count is not None:
   g=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (C/(row['label']+'.log')).read_text());assert sum(int(x) for x,_,_ in g)==count and all(b==c=='0' for _,b,c in g),(row['label'],g)
files={};payloads={};extensions={'.rs','.toml','.lock','.json','.py','.md','.log','.tsv','.stderr','.c','.txt','.ll','.o'};excluded={'target','miri-i686','miri-s390x','thumb-check','thumb-safe','thumb-all','source','replay-source','probe','__pycache__'}
for p in C.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(C)
 if any(x in excluded or x.endswith('-target') or x.endswith('.dSYM') for x in rel.parts):continue
 if any(x in ['inputs','all-inputs','normal-outputs','sanitized-outputs'] for x in rel.parts):
  h=sha(p);payloads[str(rel)]=h;files.setdefault('payloads/'+h,p);continue
 if p.suffix in extensions or p.name.startswith('oracle-'):files['campaign/'+str(rel)]=p
for p in S.rglob('*'):
 if p.is_file() and p.suffix in {'.rs','.toml','.lock','.json','.py','.md','.sh','.csv','.tsv'}:files['source/'+str(p.relative_to(S))]=p
if a.stage=='platform':files['probe/lib.rs']=C/'probe/src/lib.rs'
files['LICENSE.zstd']=Path('/Users/lanxingcan/Workspace/zstdoxize/LICENSE.zstd');files['archive-focused.py']=Path(__file__);name='2026-10-27-slice-encode-'+a.stage;archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
result=dict(status='passed',stage=a.stage,recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,complete_source=complete,records=records,receipt_sha256={n:sha(C/n) for n in receipts},external_fixture_payloads=payloads,members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()},archive=archive.name,archive_sha256=sha(archive),qualification='Completed source-bound focused gate only. Full feature/release regression, whole compression timing, broader retained corpus and milestone closure remain separate. Exact allocating Rust output is preserved through initialized header sharing and one-block staging. Native helpers are independent external v1.5.7 oracles; no C byte identity, native capacity-error precedence, reference-level/dictionary/streaming compression or complete codec parity is claimed. Rejected setup/test attempts remain historical failures.')
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
