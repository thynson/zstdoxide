from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
D=Path(__file__).parent
S=Path('/Users/lanxingcan/Workspace/zstdoxize')
U=Path('/private/tmp/module24-preparation/zstd-git')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e={'status':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
   'source':{str(p.relative_to(S)):sha(p) for folder in ['src','tests','test-support'] for p in (S/folder).rglob('*') if p.is_file()},
   'reference_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=U,text=True).strip(),
   'reference_sources':{str(p.relative_to(U)):sha(p) for p in (U/'lib').rglob('*') if p.suffix in ['.c','.h','.S']},
   'helper_sha256':sha(D/'oracle.c'),'commands':[],
   'qualification':'Module 41 bulk replacement, clean parameter/all resets, active stage rejection, reset-all recovery and completed-frame parameter/session reset; 72 frames: six explicit families, six input/pledge/prefix cases, two sessions each. Normal and ASan/UBSan native encoding, native decoding of Rust and native frames, Rust decoding of native frames, caller output guards and dictionary-free native header-window checks. Prefix frames cross-decode; formatted-prefix profile equality is not claimed. Initial empty Continue preserves explicit unknown-size semantics.'}
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module41-target','CARGO_PROFILE_TEST_OPT_LEVEL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_BUILD_JOBS':'3','CARGO_INCREMENTAL':'0'}
def save(): (D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(name,cmd,extra=None):
    start=time.monotonic();e['active']=name;save()
    with (D/(name+'.log')).open('w') as log:
        p=subprocess.run(cmd,cwd=S,env={**env,**(extra or {})},stdout=log,stderr=subprocess.STDOUT)
    e['commands'].append({'label':name,'argv':cmd,'environment':extra or {},'exit_code':p.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(D/(name+'.log'))});save()
    assert p.returncode==0,(name,(D/(name+'.log')).read_text()[-4000:])
    print(name,flush=True)
save()
try:
    export=D/'qualified-export';export.mkdir(exist_ok=True)
    run('qualified-rust-export',['cargo','test','--offline','--locked','--test','reference_stream_parameters_native','--','--ignored'],{'ZSTDOXIDE_REFERENCE_PARAMETER_NATIVE':str(export),'ZSTDOXIDE_REFERENCE_PARAMETER_EXPORT':'1'})
    sources=[str(p) for folder in ['common','compress','decompress'] for p in sorted((U/'lib'/folder).glob('*.c'))]
    for label,flags in [('normal',['-O2']),('sanitized',['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'])]:
        exe=D/('qualified-'+label)
        run('qualified-'+label+'-build',['cc','-std=c99','-Wall','-Wextra','-Werror',*flags,'-I'+str(U/'lib'),'-I'+str(U/'lib/common'),str(D/'oracle.c'),*sources,'-o',str(exe)])
        out=export/('outputs' if label=='normal' else 'outputs-sanitized');out.mkdir(exist_ok=True)
        run('qualified-'+label+'-capture',[str(exe),str(export),str(out)],{'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
        e[label+'_executable_sha256']=sha(exe)
    assert (D/'qualified-normal-capture.log').read_bytes()==(D/'qualified-sanitized-capture.log').read_bytes()
    rows=(D/'qualified-normal-capture.log').read_text().splitlines();assert len(rows)==72
    for p in (export/'outputs').glob('*.zst'):assert p.read_bytes()==(export/'outputs-sanitized'/p.name).read_bytes()
    for mode,flags in [('safe',[]),('all',['--all-features'])]:
        run('qualified-'+mode+'-replay',['cargo','test','--offline','--locked',*flags,'--test','reference_stream_parameters_native','--','--ignored'],{'ZSTDOXIDE_REFERENCE_PARAMETER_NATIVE':str(export)})
    e['outputs']={str(p.relative_to(export)):sha(p) for p in export.rglob('*') if p.is_file()}
    e['rows']=rows
    for n,h in e['source'].items():assert sha(S/n)==h
    e['status']='complete';e.pop('active',None);e['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
except BaseException as ex:
    e['status']='failed';e['error']=repr(ex);save();raise
