from pathlib import Path
import hashlib,json,tarfile
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((D/'evidence.json').read_text());assert e['status']=='complete' and e['all_export_byte_identical'] and len(e['rows'])==72
for n,h in e['source'].items():assert sha(R/n)==h
for row in e['commands']:assert row['exit_code']==0 and sha(D/(row['label']+'.log'))==row['log_sha256']
for n,h in e['outputs'].items():assert sha(D/'qualified-export'/n)==h
archive=R/'docs/evidence/2026-11-05-reference-streaming-parameters-native.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n in ['oracle.c','check.py','supplement.py','finalize.py','evidence.json','driver.log','qualified-export']:
  t.add(D/n,arcname=n)
 for row in e['commands']:t.add(D/(row['label']+'.log'),arcname=row['label']+'.log')
e['archive']={'path':str(archive.relative_to(R)),'sha256':sha(archive)}
e['limitations']=['This native campaign is complete; Module 41 full isolated-feature/release and timing qualification remain separate gates.','Native automatic completed-frame init differs from explicit Rust reset. Native parameter-only pledge retention is separately evidenced in the analysis receipt.','Sanitizers cover the native oracle only; leak detection disabled. No native byte identity claim.','Workspace failure coverage is Rust focused tests, including first allocation after default reset and the existing exhaustive fresh-session ordinal campaign.']
(R/'docs/evidence/2026-11-05-reference-streaming-parameters-native.json').write_text(json.dumps(e,indent=2)+'\n')
p=R/'TODO.md';p.write_text(p.read_text().replace('- [ ] Qualify guarded native parameter/reset schedules and allocator failures.','- [x] Qualify guarded native parameter/reset schedules and allocator failures.'))
print('Native lifecycle evidence verified and archived')
