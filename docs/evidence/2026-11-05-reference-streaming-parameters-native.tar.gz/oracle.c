/* Supplementary test oracle only, built with pinned facebook/zstd v1.5.7. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "zstd_errors.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

static void check(size_t result) {
    if (ZSTD_isError(result)) { fprintf(stderr, "%s\n", ZSTD_getErrorName(result)); exit(2); }
}
static void path(char *out, const char *root, const char *id, const char *ext) {
    if (snprintf(out, 4096, "%s/%s.%s", root, id, ext) >= 4096) exit(3);
}
static unsigned char *read_bytes(const char *root, const char *id, const char *ext, size_t *len) {
    char name[4096]; FILE *f; long size; unsigned char *p;
    path(name, root, id, ext); f = fopen(name, "rb");
    if (!f || fseek(f,0,SEEK_END) || (size=ftell(f))<0 || fseek(f,0,SEEK_SET)) exit(4);
    *len=(size_t)size; p=malloc(*len+1);
    if (!p || fread(p,1,*len,f)!=*len || fclose(f)) exit(5);
    return p;
}
static void guards(const unsigned char *p, size_t capacity) {
    size_t i; for(i=0;i<16;i++) if(p[i]!=0xa5 || p[16+capacity+i]!=0xa5) exit(6);
}
static void decode(const unsigned char *frame, size_t size, const unsigned char *source, size_t len,
                   const unsigned char *dict, size_t dict_len) {
    ZSTD_DCtx *dc=ZSTD_createDCtx(); unsigned char *out=malloc(len+32); size_t result;
    if(!dc || !out) exit(7);
    memset(out,0xa5,len+32);
    result=ZSTD_decompress_usingDict(dc,out+16,len,frame,size,dict,dict_len); check(result);
    if(result!=len || memcmp(out+16,source,len)) exit(8);
    guards(out,len); free(out); ZSTD_freeDCtx(dc);
}
static void apply(ZSTD_CCtx *cc, int strategy, int show, long long pledge) {
    ZSTD_CCtx_params *p=ZSTD_createCCtxParams();
    if(!p) exit(17);
    check(ZSTD_CCtxParams_setParameter(p,ZSTD_c_compressionLevel,3));
    check(ZSTD_CCtxParams_setParameter(p,ZSTD_c_strategy,strategy));
    check(ZSTD_CCtxParams_setParameter(p,ZSTD_c_windowLog,17));
    check(ZSTD_CCtxParams_setParameter(p,ZSTD_c_hashLog,14));
    check(ZSTD_CCtxParams_setParameter(p,ZSTD_c_chainLog,14));
    check(ZSTD_CCtxParams_setParameter(p,ZSTD_c_contentSizeFlag,show));
    check(ZSTD_CCtxParams_setParameter(p,ZSTD_c_checksumFlag,1));
    check(ZSTD_CCtx_setParametersUsingCCtxParams(cc,p));
    check(ZSTD_CCtx_setPledgedSrcSize(cc,pledge<0?ZSTD_CONTENTSIZE_UNKNOWN:(unsigned long long)pledge));
    ZSTD_freeCCtxParams(p);
}
static void defaults(ZSTD_CCtx *cc) {
    int level,checksum,strategy;
    check(ZSTD_CCtx_getParameter(cc,ZSTD_c_compressionLevel,&level));
    check(ZSTD_CCtx_getParameter(cc,ZSTD_c_checksumFlag,&checksum));
    check(ZSTD_CCtx_getParameter(cc,ZSTD_c_strategy,&strategy));
    if(level!=3 || checksum!=0 || strategy!=0) exit(18);
}
int main(int argc, char **argv) {
    char name[4096],id[100]; FILE *manifest; int strategy,show,kind; long long pledge; unsigned long long window;
    size_t raw_len,prepared_len; unsigned char *raw,*prepared; ZSTD_CCtx *cc;
    if(argc!=3) return 1;
    raw=read_bytes(argv[1],"raw","dict",&raw_len); prepared=read_bytes(argv[1],"prepared","dict",&prepared_len);
    path(name,argv[1],"schedule","tsv"); manifest=fopen(name,"r"); cc=ZSTD_createCCtx();
    if(!manifest || !cc) return 9;
    while(fscanf(manifest,"%99s %d %lld %d %d %llu",id,&strategy,&pledge,&show,&kind,&window)==6) {
        size_t len,rust_len,cap,written=0,pos=0,ret; unsigned char *src,*rust,*storage,*out;
        const unsigned char *dict=kind==1?raw:kind==2?prepared:NULL;
        size_t dict_len=kind==1?raw_len:kind==2?prepared_len:0;
        ZSTD_frameHeader header; FILE *f;
        src=read_bytes(argv[1],id,"input",&len); rust=read_bytes(argv[1],id,"rust",&rust_len);
        decode(rust,rust_len,src,len,dict,dict_len);
        {
            int family,scenario,session;
            if(sscanf(id,"s%d-c%d-f%d",&family,&scenario,&session)!=3 || family!=strategy) exit(19);
            if(session==0) {
                check(ZSTD_CCtx_reset(cc,ZSTD_reset_session_and_parameters));
                apply(cc,strategy,show,pledge);
                if(dict) check(ZSTD_CCtx_refPrefix_advanced(cc,dict,dict_len,kind==1?ZSTD_dct_rawContent:ZSTD_dct_fullDict));
                if(scenario==0) { check(ZSTD_CCtx_reset(cc,ZSTD_reset_parameters)); defaults(cc); }
                else if(scenario==1) { check(ZSTD_CCtx_reset(cc,ZSTD_reset_session_and_parameters)); defaults(cc); }
                else if(scenario==2 || scenario==5) {
                    unsigned char scratch[32]; ZSTD_inBuffer in={src,0,0}; ZSTD_outBuffer ob={scratch,sizeof(scratch),0};
                    ZSTD_CCtx_params *p=ZSTD_createCCtxParams(); if(!p) exit(20);
                    check(ZSTD_compressStream2(cc,&ob,&in,ZSTD_e_continue));
                    if(ZSTD_getErrorCode(ZSTD_CCtx_setParametersUsingCCtxParams(cc,p))!=ZSTD_error_stage_wrong) exit(21);
                    if(ZSTD_getErrorCode(ZSTD_CCtx_reset(cc,ZSTD_reset_parameters))!=ZSTD_error_stage_wrong) exit(22);
                    ZSTD_freeCCtxParams(p);
                    check(ZSTD_CCtx_reset(cc,ZSTD_reset_session_and_parameters)); defaults(cc);
                    if(dict) check(ZSTD_CCtx_refPrefix_advanced(cc,dict,dict_len,kind==1?ZSTD_dct_rawContent:ZSTD_dct_fullDict));
                } else if(scenario==3) { apply(cc,1,show,pledge); }
            } else {
                /* Native finished frames are already init; Rust resets explicitly. */
                check(ZSTD_CCtx_reset(cc,ZSTD_reset_parameters)); defaults(cc);
                check(ZSTD_CCtx_reset(cc,ZSTD_reset_session_only));
            }
            apply(cc,strategy,show,pledge);
        }
        cap=ZSTD_compressBound(len)+1024; storage=malloc(cap+32); if(!storage) exit(10);
        memset(storage,0xa5,cap+32); out=storage+16;
        { ZSTD_inBuffer in={src,0,0}; ZSTD_outBuffer ob={out,17,0};
          check(ZSTD_compressStream2(cc,&ob,&in,ZSTD_e_continue)); written=ob.pos; }
        do {
            size_t take=len-pos<317?len-pos:317;
            ZSTD_EndDirective mode=pos+take==len?ZSTD_e_end:ZSTD_e_continue;
            unsigned char chunk[49]; ZSTD_inBuffer in={src+pos,take,0}; ZSTD_outBuffer ob={chunk+16,17,0};
            memset(chunk,0xa5,sizeof(chunk));
            ret=ZSTD_compressStream2(cc,&ob,&in,mode); check(ret); guards(chunk,17);
            if(written+ob.pos>cap) exit(11);
            memcpy(out+written,chunk+16,ob.pos); written+=ob.pos; pos+=in.pos;
            if(mode==ZSTD_e_end && ret==0) break;
        } while(1);
        if(pos!=len) exit(12);
        guards(storage,cap); decode(out,written,src,len,dict,dict_len);
        ret=ZSTD_getFrameHeader(&header,out,written); check(ret); if(ret) exit(13);
        if(header.frameContentSize!=(show && pledge>=0?(unsigned long long)pledge:ZSTD_CONTENTSIZE_UNKNOWN)) exit(14);
        if(!kind) {
            unsigned long long expected=show && pledge>=0 && (unsigned long long)pledge<=window?(unsigned long long)pledge:window;
            if(header.windowSize!=expected) { fprintf(stderr,"%s window %llu != %llu\n",id,header.windowSize,expected); exit(15); }
        }
        path(name,argv[2],id,"zst"); f=fopen(name,"wb"); if(!f || fwrite(out,1,written,f)!=written || fclose(f)) exit(16);
        printf("%s\tok\t%zu\t%zu\t%llu\t%llu\n",id,rust_len,written,header.windowSize,header.frameContentSize);
        free(storage);free(src);free(rust);
    }
    fclose(manifest);ZSTD_freeCCtx(cc);free(raw);free(prepared);return 0;
}
