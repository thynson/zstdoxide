from pathlib import Path
import hashlib,json,os,subprocess,time
D=Path(__file__).parent;S=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((D/'evidence.json').read_text());assert e['status']=='complete'
for n,h in e['source'].items():assert sha(S/n)==h
out=D/'all-export';out.mkdir(exist_ok=True)
cmd=['cargo','test','--offline','--locked','--all-features','--test','reference_stream_parameters_native','--','--ignored']
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module41-target','CARGO_PROFILE_TEST_OPT_LEVEL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_BUILD_JOBS':'3','CARGO_INCREMENTAL':'0','ZSTDOXIDE_REFERENCE_PARAMETER_NATIVE':str(out),'ZSTDOXIDE_REFERENCE_PARAMETER_EXPORT':'1'}
start=time.monotonic()
with (D/'all-export.log').open('w') as f:p=subprocess.run(cmd,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
for f in out.iterdir():assert f.read_bytes()==(D/'qualified-export'/f.name).read_bytes(),f.name
e['commands'].append({'label':'all-export','argv':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(D/'all-export.log')})
e['all_export_byte_identical']=True
e['build_environment']={k:v for k,v in env.items() if k.startswith('CARGO_')}
(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
print('All 72 Rust frames and schedules byte-identical across safe/all builds')
