from pathlib import Path
import hashlib,json,os,subprocess,statistics,struct,time,tomllib,tarfile,io
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-owner-timing');O.mkdir();env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/zstdoxide-tree-reader-target'
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=sorted((R/'src').glob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock'];source={str(p.relative_to(R)):sha(p.read_bytes()) for p in paths};commands=[];binaries={}
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree']),('all',['--all-features'])]:
 args=['cargo','test','--offline','--locked','--release','--lib','--no-run','--message-format=json',*flags];p=subprocess.run(args,cwd=R,env=env,capture_output=True,timeout=240);(O/(name+'-build.log')).write_bytes(p.stdout+p.stderr)
 if p.returncode:raise ValueError(name)
 records=[json.loads(l) for l in p.stdout.splitlines()];bins=[r['executable'] for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test']];assert len(bins)==1
 binaries[name]=dict(path=bins[0],sha256=sha(Path(bins[0]).read_bytes()));commands.append(args)
print('all binaries prepared; sequential timing starts',flush=True)
results={}
for name in binaries:
 e=env.copy();e['ZSTDOXIDE_TREE_OWNER_OUTPUT']=str(O/name);args=[binaries[name]['path'],'reference_tree::tests::measure_identical_owner_workloads','--ignored','--exact','--nocapture','--test-threads=1'];p=subprocess.run(args,cwd=R,env=e,capture_output=True,timeout=120);(O/(name+'-run.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0
 rows=[]
 for l in p.stdout.decode().splitlines():
  if 'TREE_OWNER ' in l:rows.append(json.loads(l.split('TREE_OWNER ',1)[1]))
 assert len(rows)==3;results[name]=rows;commands.append(args);print(name,'finished',flush=True)
ratios=[]
for h,c,count in [(6,6,4096),(12,12,16384),(19,19,32768)]:
 heads=[0]*(1<<h);edges=[0]*(1<<c);state=0x5eedb71e20261013;mask=(1<<64)-1
 for p in range(count):
  state^=(state<<13)&mask;state^=state>>7;state^=(state<<17)&mask
  bucket=((state&0xffffffff)*2654435761&0xffffffff)>>(32-h);previous=heads[bucket];heads[bucket]=p+2;index=((p+2)% (1<<(c-1)))*2
  edges[index]=0 if p%5==0 else previous;edges[index+1]=0 if p%7==0 else previous if p%5==0 else 1
 expected=struct.pack('<'+'Q'*(len(heads)+len(edges)),*(heads+edges));case=f'h{h}-c{c}';med={}
 for name in results:
  assert (O/name/(case+'.bin')).read_bytes()==expected
  row=next(r for r in results[name] if r['case']==case);assert row['unsafe_tree']==(name!='safe') and row['keys']==count and len(row['samples'])==5
  assert all(s['iterations']>0 and s['nanoseconds']>=100000000 for s in row['samples']);med[name]=statistics.median(s['iterations']*count*1e9/s['nanoseconds'] for s in row['samples'])
 ratios.append(dict(case=case,map_sha256=sha(expected),median_keys_per_second=med,tree_over_safe=med['tree']/med['safe'],all_over_safe=med['all']/med['safe']))
assert source=={n:sha((R/n).read_bytes()) for n in source}
e=dict(status='passed',source=source,commands=commands,binaries=binaries,results=results,comparisons=ratios,samples=45,qualification='Primitive reset/read/write microbenchmarks only; allocations, keys and complete map verification are untimed. All binaries built before sequential timing; no frame speed claim.')
(O/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
files={str(p.relative_to(O)):p.read_bytes() for p in O.rglob('*') if p.is_file()};files.update({'source/'+n:(R/n).read_bytes() for n in source});files['runner.py']=Path(__file__).read_bytes();a=R/'docs/evidence/2026-10-13-tree-owner-timing.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:assert {m.name:t.extractfile(m).read() for m in t}==files
e.update(archive=a.name,archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()));(R/'docs/evidence/2026-10-13-tree-owner-timing.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n');print(json.dumps(ratios),flush=True)
