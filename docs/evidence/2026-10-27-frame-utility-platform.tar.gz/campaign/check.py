from pathlib import Path
import json,hashlib,shutil,subprocess,time,os,tomllib,concurrent.futures
D=Path(__file__).parent;S=D/'source';S.mkdir();R=Path('/private/tmp/module31-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['cursor.rs','frame.rs','error.rs','frame_layout.rs','frame_utilities.rs']:shutil.copyfile(R/'src'/name,S/name)
(S/'lib.rs').write_text('''#![no_std]
#![deny(unsafe_op_in_unsafe_fn)]
#![deny(clippy::undocumented_unsafe_blocks, clippy::missing_safety_doc)]
#[cfg(test)]
extern crate alloc;
#[allow(dead_code)]
mod cursor;
mod error;
#[allow(dead_code)]
mod frame;
mod frame_layout;
mod frame_utilities;
pub use frame_utilities::{compression_bound,write_skippable_frame};\npub use error::{Error,Result};
pub use frame::FrameHeader;
pub use frame_layout::{FrameInfo,FrameKind,frame_info,frame_compressed_size,decompressed_size,decompression_bound,decompression_margin,is_skippable_frame,skippable_payload};
''')
features=sorted(n for n in tomllib.loads((R/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
(S/'Cargo.toml').write_text('[package]\nname="frame-utility-core-component"\nversion="0.0.0"\nedition="2024"\n[lib]\nname="zstdoxide"\npath="lib.rs"\n[features]\ndefault=[]\n'+''.join(f'{n}=[]\n' for n in features))
shutil.copyfile(R/'rust-toolchain.toml',S/'rust-toolchain.toml');(S/'tests').mkdir();shutil.copyfile(D/'frame_utilities_platform.rs',S/'tests/frame_utilities_platform.rs');subprocess.run(['cargo','generate-lockfile','--offline'],cwd=S,check=True);subprocess.run(['cargo','fmt','--all'],cwd=S,check=True)
# Formatting copied production modules must not alter their frozen bytes.
for n in ['cursor.rs','frame.rs','error.rs','frame_layout.rs','frame_utilities.rs']:assert sha(S/n)==sha(R/'src'/n),n
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};e=dict(status='running',production_source={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')},source=source,commands=[]);env={**os.environ,'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,cwd,extra):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=cwd,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT)
 row=dict(label=label,argv=args,environment=extra,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log')));(D/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');assert p.returncode==0,label;print(label,'passed',flush=True);return row
save()
def interpret(target,suffix):
 rows=[]
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  scalar=run(suffix+'-'+name+'-numeric',['cargo','miri','test','--offline','--locked','--target',target,'--lib','limits',*flags],S,{'CARGO_TARGET_DIR':str(D/('miri-'+suffix)),'MIRI_SYSROOT':'/private/tmp/zstdoxide-ultra-miri-'+suffix,'MIRIFLAGS':'-Zmiri-strict-provenance'});assert '2 passed; 0 failed; 0 ignored' in (D/(scalar['label']+'.log')).read_text();rows.append(scalar)
  row=run(suffix+'-'+name,['cargo','miri','test','--offline','--locked','--target',target,'--test','frame_utilities_platform',*flags],S,{'CARGO_TARGET_DIR':str(D/('miri-'+suffix)),'MIRI_SYSROOT':'/private/tmp/zstdoxide-ultra-miri-'+suffix,'MIRIFLAGS':'-Zmiri-strict-provenance'});assert '2 passed; 0 failed; 0 ignored' in (D/(row['label']+'.log')).read_text();rows.append(row)
 return rows
try:
 e['commands'].append(run('host-core-only',['cargo','check','--offline','--locked','--lib'],S,{'CARGO_TARGET_DIR':str(D/'host-check')}));save()
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(interpret,t,s) for t,s in [('i686-unknown-linux-gnu','i686'),('s390x-unknown-linux-gnu','s390x')]]
  for f in concurrent.futures.as_completed(futures):e['commands']+=f.result();save()
 probe=D/'probe';shutil.copytree(S,probe)
 with (probe/'lib.rs').open('a') as f:f.write('\n#[inline(never)]\npub fn frame_utilities_codegen_probe(output: &mut [u8], input: &[u8], variant: u8) -> Result<(usize,usize)> { Ok((compression_bound(input.len())?,write_skippable_frame(output,input,variant)?)) }\n')
 e['probe_source_sha256']=sha(probe/'lib.rs')
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  common=['--offline','--locked','-Zbuild-std=core','--target','thumbv6m-none-eabi','--no-default-features','--lib',*flags]
  e['commands'].append(run('thumb-'+name+'-core-only',['cargo','check',*common],S,{'CARGO_TARGET_DIR':str(D/'thumb-check')}));save()
  target=D/('thumb-'+name);e['commands'].append(run('thumb-'+name+'-objects',['cargo','rustc','--release',*common,'--','--emit=llvm-ir,obj'],probe,{'CARGO_TARGET_DIR':str(target)}));save()
  ir=[p for p in target.rglob('*.ll') if any(line.startswith(b'define ') and b'frame_utilities_codegen_probe' in line for line in p.read_bytes().splitlines())];assert len(ir)==1;assert b'__rust_alloc' not in ir[0].read_bytes();objects=list(ir[0].parent.glob('*.o'));assert objects;artifacts=[]
  for p in [ir[0],*objects]:
   if p.suffix=='.o':
    h=p.read_bytes()[:20];assert h[:6]==b'\x7fELF\x01\x01' and int.from_bytes(h[18:20],'little')==40
   q=D/'artifacts'/(name+'-'+p.name);q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q);artifacts.append(dict(path=str(q.relative_to(D)),sha256=sha(q)))
  e.setdefault('artifacts',{})[name]=artifacts;save()
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='Eight actual i686/s390x strict-provenance Miri executions run two numeric-limit unit tests and two real borrowed-write/guard/error tests in safe/all modes. Exact production utility/scan/cursor/frame/error modules also compile and emit concrete ARM objects with core only; emitted write/bound probe IR has no Rust allocator entrypoint. The full codec remains no_std plus alloc. This is interpreter/code-generation evidence, not foreign hardware execution.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
