; ModuleID = 'zstdoxide.c2e047d3532f2198-cgu.0'
source_filename = "zstdoxide.c2e047d3532f2198-cgu.0"
target datalayout = "e-m:e-p:32:32-Fi8-i64:64-v128:64:128-a:0:32-n32-S64"
target triple = "thumbv6m-unknown-none-eabi"

@alloc_c21f614fcb860badb88d0f8b8ac2b1e9 = private unnamed_addr constant [10 x i8] c"cursor.rs\00", align 1, !guid !0
@alloc_f98695e4aa1fd53eef7097a70735602a = private unnamed_addr constant <{ ptr, [12 x i8] }> <{ ptr @alloc_c21f614fcb860badb88d0f8b8ac2b1e9, [12 x i8] c"\09\00\00\00\1D\00\00\00 \00\00\00" }>, align 4, !guid !1
@alloc_49187a1a9102f6fabfbd4ff8645930a8 = private unnamed_addr constant [16 x i8] c"frame_layout.rs\00", align 1, !guid !2
@alloc_5e6a025b48b26689566b9e005edba7db = private unnamed_addr constant <{ ptr, [12 x i8] }> <{ ptr @alloc_49187a1a9102f6fabfbd4ff8645930a8, [12 x i8] c"\0F\00\00\00\E8\00\00\00\17\00\00\00" }>, align 4, !guid !3
@alloc_7435913fe0ee9560e916ffcef5e2af54 = private unnamed_addr constant <{ ptr, [12 x i8] }> <{ ptr @alloc_49187a1a9102f6fabfbd4ff8645930a8, [12 x i8] c"\0F\00\00\00\FC\00\00\00\17\00\00\00" }>, align 4, !guid !4
@alloc_048330390765a63cc99a694538bdf970 = private unnamed_addr constant <{ ptr, [12 x i8] }> <{ ptr @alloc_49187a1a9102f6fabfbd4ff8645930a8, [12 x i8] c"\0F\00\00\00R\01\00\00\17\00\00\00" }>, align 4, !guid !5
@alloc_bdac395b1457309b01119d6ee7241f45 = private unnamed_addr constant [23 x i8] c"invalid codec parameter", align 1, !guid !6
@alloc_a831c82912810798379f6d40f5aa0bba = private unnamed_addr constant [27 x i8] c"invalid codec context state", align 1, !guid !7
@alloc_7b392dc8ea31c8e6782cf57e8779c179 = private unnamed_addr constant [23 x i8] c"unexpected end of input", align 1, !guid !8
@alloc_ac0217ade07e90bc94cc456679817822 = private unnamed_addr constant [19 x i8] c"invalid frame magic", align 1, !guid !9
@alloc_7ff98b587660cdced76113da7cb03293 = private unnamed_addr constant [22 x i8] c"corrupt Zstandard data", align 1, !guid !10
@alloc_d54e75b67645a5578e757e031fa62642 = private unnamed_addr constant [24 x i8] c"a dictionary is required", align 1, !guid !11
@alloc_235b61828294feeeb2172ca04092afbd = private unnamed_addr constant [28 x i8] c"invalid Zstandard dictionary", align 1, !guid !12
@alloc_43353d327e5fe4ba2f2a23fb232c29f0 = private unnamed_addr constant [22 x i8] c"dictionary ID mismatch", align 1, !guid !13
@alloc_358d882c88585a0b91bdd46f073d6817 = private unnamed_addr constant [40 x i8] c"insufficient dictionary training samples", align 1, !guid !14
@alloc_46538b36b8c48fbfe6a4f94227e7fbd0 = private unnamed_addr constant [29 x i8] c"unsupported Zstandard feature", align 1, !guid !15
@alloc_d1b0c6bc606a538edf406f6115094080 = private unnamed_addr constant [23 x i8] c"resource limit exceeded", align 1, !guid !16
@alloc_afc2a81fe13a0b3a87a4890cf54edc49 = private unnamed_addr constant [17 x i8] c"allocation failed", align 1, !guid !17
@alloc_959af6a03cd01ca999bfcd6a252429f4 = private unnamed_addr constant [27 x i8] c"frame content size mismatch", align 1, !guid !18
@alloc_d644fd8040ac32617306136b0f3eecf4 = private unnamed_addr constant [23 x i8] c"frame checksum mismatch", align 1, !guid !19
@switch.table._RNvXNtCsgJjTu8wsiG2_9zstdoxide5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt = private unnamed_addr constant [14 x i8] c"\17\1B\17\13\16\18\1C\16(\1D\17\11\1B\17", align 4, !guid !20
@switch.table._RNvXNtCsgJjTu8wsiG2_9zstdoxide5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt.2 = private unnamed_addr constant [14 x ptr] [ptr @alloc_bdac395b1457309b01119d6ee7241f45, ptr @alloc_a831c82912810798379f6d40f5aa0bba, ptr @alloc_7b392dc8ea31c8e6782cf57e8779c179, ptr @alloc_ac0217ade07e90bc94cc456679817822, ptr @alloc_7ff98b587660cdced76113da7cb03293, ptr @alloc_d54e75b67645a5578e757e031fa62642, ptr @alloc_235b61828294feeeb2172ca04092afbd, ptr @alloc_43353d327e5fe4ba2f2a23fb232c29f0, ptr @alloc_358d882c88585a0b91bdd46f073d6817, ptr @alloc_46538b36b8c48fbfe6a4f94227e7fbd0, ptr @alloc_d1b0c6bc606a538edf406f6115094080, ptr @alloc_afc2a81fe13a0b3a87a4890cf54edc49, ptr @alloc_959af6a03cd01ca999bfcd6a252429f4, ptr @alloc_d644fd8040ac32617306136b0f3eecf4], align 4, !guid !21

; zstdoxide::frame_utilities_codegen_probe
; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite)
define dso_local void @_RNvCsgJjTu8wsiG2_9zstdoxide29frame_utilities_codegen_probe(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([12 x i8]) align 4 captures(none) dereferenceable(12) initializes((0, 1)) %_0, ptr noalias nofree noundef nonnull writeonly captures(none) %output.0, i32 noundef range(i32 0, -2147483648) %output.1, ptr noalias nofree noundef nonnull readonly captures(none) %input.0, i32 noundef range(i32 0, -2147483648) %input.1, i8 noundef %variant) unnamed_addr #0 !guid !24 {
bb7:
  %_4.i = icmp samesign ult i32 %input.1, 131072
  %_5.i = sub nuw nsw i32 131072, %input.1
  %0 = lshr i32 %_5.i, 11
  %margin.sroa.0.0.i = select i1 %_4.i, i32 %0, i32 0
  %_8.i = lshr i32 %input.1, 8
  %_11.0.i = add nuw i32 %_8.i, %input.1
  %_17.0.i = add nuw i32 %_11.0.i, %margin.sroa.0.0.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !25)
  %_4.i5 = icmp ugt i8 %variant, 15
  br i1 %_4.i5, label %bb8, label %bb7.i

bb7.i:                                            ; preds = %bb7
  %_15.0.i.i = add nuw i32 %input.1, 8
  %_32.not.i = icmp ugt i32 %_15.0.i.i, %output.1
  br i1 %_32.not.i, label %bb8, label %bb9

bb8:                                              ; preds = %bb7, %bb7.i
  %_11.sroa.5.0.ph = phi i8 [ 10, %bb7.i ], [ 0, %bb7 ]
  %1 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 %_11.sroa.5.0.ph, ptr %1, align 1
  br label %bb5

bb9:                                              ; preds = %bb7.i
  %_20.i = zext nneg i8 %variant to i32
  %_19.i = or disjoint i32 %_20.i, 407710288
  store i32 %_19.i, ptr %output.0, align 1, !alias.scope !28, !noalias !33
  %_61.i = getelementptr inbounds nuw i8, ptr %output.0, i32 4
  store i32 %input.1, ptr %_61.i, align 1, !alias.scope !36, !noalias !40
  %_68.i = getelementptr inbounds nuw i8, ptr %output.0, i32 8
  tail call void @llvm.memcpy.p0.p0.i32(ptr nonnull align 1 %_68.i, ptr nonnull readonly align 1 %input.0, i32 range(i32 0, 2147483640) %input.1, i1 false), !alias.scope !42, !noalias !46
  %2 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %_17.0.i, ptr %2, align 4
  %3 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i32 %_15.0.i.i, ptr %3, align 4
  br label %bb5

bb5:                                              ; preds = %bb8, %bb9
  %storemerge = phi i8 [ 0, %bb9 ], [ 1, %bb8 ]
  store i8 %storemerge, ptr %_0, align 4
  ret void
}

; <zstdoxide::frame_layout::FrameLayout>::read
; Function Attrs: nounwind
define internal fastcc void @_RNvMNtCsgJjTu8wsiG2_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly align 8 captures(none) dereferenceable(48) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #1 !guid !48 {
start:
  %header.sroa.3 = alloca [19 x i8], align 1
  %header.sroa.5 = alloca [3 x i8], align 1
  %_66 = alloca [8 x i8], align 4
  %_31 = alloca [40 x i8], align 8
  %cursor = alloca [12 x i8], align 4
  call void @llvm.lifetime.start.p0(ptr nonnull %cursor)
  %0 = getelementptr inbounds nuw i8, ptr %cursor, i32 4
  %1 = getelementptr inbounds nuw i8, ptr %cursor, i32 8
  %_3.i.i = icmp samesign ult i32 %input.1, 4
  br i1 %_3.i.i, label %bb32, label %bb33

bb32:                                             ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %2, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb31

bb33:                                             ; preds = %start
  %word.sroa.0.i.0.copyload = load i32, ptr %input.0, align 1, !alias.scope !49, !noalias !53
  %3 = and i32 %word.sroa.0.i.0.copyload, -16
  %4 = icmp eq i32 %3, 407710288
  br i1 %4, label %bb3, label %bb4

bb3:                                              ; preds = %bb33
  %5 = and i32 %input.1, 2147483644
  %_3.i.i47 = icmp eq i32 %5, 4
  br i1 %_3.i.i47, label %bb34, label %bb35

bb4:                                              ; preds = %bb33
  call void @llvm.lifetime.start.p0(ptr nonnull %_31)
; call <zstdoxide::frame::FrameHeader>::parse
  call void @_RNvMNtCsgJjTu8wsiG2_9zstdoxide5frameNtB2_11FrameHeader5parse(ptr noalias nofree noundef nonnull sret([40 x i8]) align 8 captures(none) dereferenceable(40) %_31, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef %input.1) #8
  %6 = load i64, ptr %_31, align 8, !range !58, !noundef !59
  %7 = icmp eq i64 %6, 2
  %8 = getelementptr inbounds nuw i8, ptr %_31, i32 8
  %_111 = load i8, ptr %8, align 8
  br i1 %7, label %bb40, label %bb41

bb34:                                             ; preds = %bb3
  %9 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %9, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb31

bb35:                                             ; preds = %bb3
  %_22.i.i55 = getelementptr inbounds nuw i8, ptr %input.0, i32 4
  %word.sroa.0.i43.0.copyload = load i32, ptr %_22.i.i55, align 1, !alias.scope !60, !noalias !64
  %_4.i = add nsw i32 %input.1, -8
  %_3.i = icmp ugt i32 %word.sroa.0.i43.0.copyload, %_4.i
  br i1 %_3.i, label %bb38, label %bb2.i

bb2.i:                                            ; preds = %bb35
  %end.i = add nuw nsw i32 %word.sroa.0.i43.0.copyload, 8
  %_13.not.i = icmp samesign ugt i32 %end.i, %input.1
  br i1 %_13.not.i, label %bb6.i, label %bb39, !prof !69

bb6.i:                                            ; preds = %bb2.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef 8, i32 noundef %end.i, i32 noundef %input.1, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_f98695e4aa1fd53eef7097a70735602a) #9, !noalias !70
  unreachable

bb38:                                             ; preds = %bb35
  %10 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %10, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb31

bb39:                                             ; preds = %bb2.i
  %11 = trunc i32 %word.sroa.0.i.0.copyload to i8
  %_28 = and i8 %11, 15
  store i64 2, ptr %_0, align 8
  %_24.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 32
  store i32 %end.i, ptr %_24.sroa.4.0._0.sroa_idx, align 8
  %_24.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 36
  store i32 %end.i, ptr %_24.sroa.5.0._0.sroa_idx, align 4
  %_24.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 40
  store i32 0, ptr %_24.sroa.6.0._0.sroa_idx, align 8
  %_24.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 44
  store i8 %_28, ptr %_24.sroa.7.0._0.sroa_idx, align 4
  br label %bb31

bb40:                                             ; preds = %bb4
  call void @llvm.lifetime.end.p0(ptr nonnull %_31)
  %12 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_111, ptr %12, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb31

bb41:                                             ; preds = %bb4
  %_110.sroa.5.0._31.sroa_idx = getelementptr inbounds nuw i8, ptr %_31, i32 9
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %header.sroa.3, ptr noundef nonnull align 1 dereferenceable(19) %_110.sroa.5.0._31.sroa_idx, i32 19, i1 false)
  %_110.sroa.5.sroa.4.0._110.sroa.5.0._31.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_31, i32 28
  %_110.sroa.5.sroa.4.0.copyload = load i8, ptr %_110.sroa.5.sroa.4.0._110.sroa.5.0._31.sroa_idx.sroa_idx, align 4
  %_110.sroa.5.sroa.5.0._110.sroa.5.0._31.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_31, i32 29
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(3) %header.sroa.5, ptr noundef nonnull align 1 dereferenceable(3) %_110.sroa.5.sroa.5.0._110.sroa.5.0._31.sroa_idx.sroa_idx, i32 3, i1 false)
  %_110.sroa.6.0._31.sroa_idx = getelementptr inbounds nuw i8, ptr %_31, i32 32
  %_110.sroa.6.0.copyload = load i32, ptr %_110.sroa.6.0._31.sroa_idx, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %_31)
  store ptr %input.0, ptr %cursor, align 4
  store i32 %input.1, ptr %0, align 4
  %_3.i63 = icmp ugt i32 %_110.sroa.6.0.copyload, %input.1
  br i1 %_3.i63, label %bb42, label %bb9

bb42:                                             ; preds = %bb41
  %13 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %13, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb31

bb9:                                              ; preds = %bb41, %bb52
  %_6.i94145 = phi i32 [ %end.i98, %bb52 ], [ %_110.sroa.6.0.copyload, %bb41 ]
  %block_count.sroa.0.0 = phi i32 [ %_144.0, %bb52 ], [ 0, %bb41 ]
  %_4.i.i79 = sub nsw i32 %input.1, %_6.i94145
  %_3.i.i80 = icmp ult i32 %_4.i.i79, 3
  br i1 %_3.i.i80, label %bb44, label %bb2.i.i81

bb2.i.i81:                                        ; preds = %bb9
  %end.i.i82 = add nuw i32 %_6.i94145, 3
  %_13.not.i.i84 = icmp ugt i32 %end.i.i82, %input.1
  br i1 %_13.not.i.i84, label %bb6.i.i90, label %bb45, !prof !69

bb6.i.i90:                                        ; preds = %bb2.i.i81
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_6.i94145, i32 noundef %end.i.i82, i32 noundef %input.1, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_f98695e4aa1fd53eef7097a70735602a) #9, !noalias !74
  unreachable

bb44:                                             ; preds = %bb9
  %14 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %14, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb31

bb45:                                             ; preds = %bb2.i.i81
  %_22.i.i88 = getelementptr inbounds nuw i8, ptr %input.0, i32 %_6.i94145
  %word.sroa.0.i75.0.copyload = load i24, ptr %_22.i.i88, align 1, !alias.scope !81, !noalias !85
  %word.sroa.0.i75.0.insert.ext = zext i24 %word.sroa.0.i75.0.copyload to i64
  %_45 = lshr i64 %word.sroa.0.i75.0.insert.ext, 1
  %trunc = trunc i64 %_45 to i2
  switch i2 %trunc, label %bb45.unreachabledefault153 [
    i2 0, label %bb47
    i2 -2, label %bb47
    i2 1, label %bb14
    i2 -1, label %bb11
  ]

bb45.unreachabledefault153:                       ; preds = %bb45
  unreachable

bb11:                                             ; preds = %bb45
  %15 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 4, ptr %15, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb31

bb47:                                             ; preds = %bb45, %bb45
  %_49 = lshr i64 %word.sroa.0.i75.0.insert.ext, 3
  %_131 = trunc nuw nsw i64 %_49 to i32
  br label %bb14

bb14:                                             ; preds = %bb45, %bb47
  %payload_size.sroa.0.0 = phi i32 [ %_131, %bb47 ], [ 1, %bb45 ]
  %_4.i95 = sub nsw i32 %input.1, %end.i.i82
  %_3.i96 = icmp ugt i32 %payload_size.sroa.0.0, %_4.i95
  br i1 %_3.i96, label %bb48, label %bb2.i97

bb2.i97:                                          ; preds = %bb14
  %end.i98 = add nuw i32 %end.i.i82, %payload_size.sroa.0.0
  %_13.not.i100 = icmp ugt i32 %end.i98, %input.1
  br i1 %_13.not.i100, label %bb6.i105, label %bb49, !prof !69

bb6.i105:                                         ; preds = %bb2.i97
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %end.i.i82, i32 noundef %end.i98, i32 noundef %input.1, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_f98695e4aa1fd53eef7097a70735602a) #9, !noalias !87
  unreachable

bb48:                                             ; preds = %bb14
  %16 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %16, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb31

bb49:                                             ; preds = %bb2.i97
  %_144.1 = icmp eq i32 %block_count.sroa.0.0, -1
  br i1 %_144.1, label %bb50, label %bb52, !prof !91

bb52:                                             ; preds = %bb49
  %_144.0 = add nuw i32 %block_count.sroa.0.0, 1
  %_62 = and i64 %word.sroa.0.i75.0.insert.ext, 1
  %17 = icmp eq i64 %_62, 0
  br i1 %17, label %bb9, label %bb16

bb50:                                             ; preds = %bb49
  %18 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 10, ptr %18, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb31

bb16:                                             ; preds = %bb52
  store i32 %end.i98, ptr %1, align 4
  %19 = zext i8 %_110.sroa.5.sroa.4.0.copyload to i32
  %. = shl nuw nsw i32 %19, 2
  call void @llvm.lifetime.start.p0(ptr nonnull %_66)
; call <zstdoxide::cursor::ByteCursor>::take
  call fastcc void @_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take(ptr noalias nofree noundef align 4 captures(none) dereferenceable(8) %_66, ptr noalias nofree noundef align 4 dereferenceable(12) %cursor, i32 noundef %.) #8
  %20 = load ptr, ptr %_66, align 4, !noundef !59
  %21 = icmp eq ptr %20, null
  br i1 %21, label %bb53, label %bb57

bb53:                                             ; preds = %bb16
  %22 = getelementptr inbounds nuw i8, ptr %_66, i32 4
  %_159 = load i8, ptr %22, align 4, !range !92, !noundef !59
  call void @llvm.lifetime.end.p0(ptr nonnull %_66)
  %23 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_159, ptr %23, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb31

bb57:                                             ; preds = %bb16
  call void @llvm.lifetime.end.p0(ptr nonnull %_66)
  %_165.0 = add nuw i32 %_110.sroa.6.0.copyload, %.
  %_72 = load i32, ptr %1, align 4, !noundef !59
  %_71.sroa.0.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 9
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %_71.sroa.0.sroa.6.0._0.sroa_idx, ptr noundef nonnull align 1 dereferenceable(19) %header.sroa.3, i32 19, i1 false)
  %_71.sroa.0.sroa.8.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 29
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(3) %_71.sroa.0.sroa.8.0._0.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %header.sroa.5, i32 3, i1 false)
  store i64 %6, ptr %_0, align 8
  %_71.sroa.0.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_111, ptr %_71.sroa.0.sroa.5.0._0.sroa_idx, align 8
  %_71.sroa.0.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 28
  store i8 %_110.sroa.5.sroa.4.0.copyload, ptr %_71.sroa.0.sroa.7.0._0.sroa_idx, align 4
  %_71.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 32
  store i32 %_72, ptr %_71.sroa.5.0._0.sroa_idx, align 8
  %_71.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 36
  store i32 %_165.0, ptr %_71.sroa.6.0._0.sroa_idx, align 4
  %_71.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 40
  store i32 %_144.0, ptr %_71.sroa.7.0._0.sroa_idx, align 8
  %_71.sroa.8.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 44
  store i8 0, ptr %_71.sroa.8.0._0.sroa_idx, align 4
  br label %bb31

bb31:                                             ; preds = %bb40, %bb32, %bb34, %bb38, %bb39, %bb44, %bb11, %bb48, %bb50, %bb53, %bb42, %bb57
  call void @llvm.lifetime.end.p0(ptr nonnull %cursor)
  ret void
}

; <zstdoxide::frame::FrameHeader>::parse
; Function Attrs: nounwind
define dso_local void @_RNvMNtCsgJjTu8wsiG2_9zstdoxide5frameNtB2_11FrameHeader5parse(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([40 x i8]) align 8 captures(none) dereferenceable(40) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #1 !guid !93 {
start:
  %word.sroa.0.i62 = alloca i64, align 8
  %word.sroa.0.i45 = alloca i64, align 8
  %_29 = alloca [16 x i8], align 4
  %_3.i.i = icmp samesign ult i32 %input.1, 4
  br i1 %_3.i.i, label %bb31, label %bb32

bb31:                                             ; preds = %start
  %0 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %0, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb32:                                             ; preds = %start
  %word.sroa.0.i.0.copyload = load i32, ptr %input.0, align 1, !alias.scope !94, !noalias !98
  %1 = icmp eq i32 %word.sroa.0.i.0.copyload, -47205080
  br i1 %1, label %bb4, label %bb3

bb4:                                              ; preds = %bb32
  %_3.i.i26 = icmp eq i32 %input.1, 4
  br i1 %_3.i.i26, label %bb33, label %bb2.i.i27

bb2.i.i27:                                        ; preds = %bb4
  %_22.i.i31 = getelementptr inbounds nuw i8, ptr %input.0, i32 4
  %_2.i = load i8, ptr %_22.i.i31, align 1, !noalias !103, !noundef !59
  %_13 = and i8 %_2.i, 8
  %2 = icmp eq i8 %_13, 0
  br i1 %2, label %bb7, label %bb6

bb3:                                              ; preds = %bb32
  %3 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 3, ptr %3, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb33:                                             ; preds = %bb4
  %4 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %4, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb7:                                              ; preds = %bb2.i.i27
  %_15 = and i8 %_2.i, 32
  %single_segment.not = icmp eq i8 %_15, 0
  br i1 %single_segment.not, label %bb8, label %bb10

bb6:                                              ; preds = %bb2.i.i27
  %5 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 4, ptr %5, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb8:                                              ; preds = %bb7
  %_3.i.i34 = icmp eq i32 %input.1, 5
  br i1 %_3.i.i34, label %bb35, label %bb2.i.i35

bb2.i.i35:                                        ; preds = %bb8
  %_22.i.i41 = getelementptr inbounds nuw i8, ptr %input.0, i32 5
  %_2.i42 = load i8, ptr %_22.i.i41, align 1, !noalias !106, !noundef !59
  %_23 = lshr i8 %_2.i42, 3
  %_22 = add nuw nsw i8 %_23, 10
  %6 = zext nneg i8 %_22 to i64
  %base = shl nuw nsw i64 1, %6
  %_2523 = lshr i64 %base, 3
  %_27 = and i8 %_2.i42, 7
  %_26 = zext nneg i8 %_27 to i64
  %_24 = mul nuw nsw i64 %_2523, %_26
  %7 = add nuw nsw i64 %_24, %base
  br label %bb10

bb10:                                             ; preds = %bb2.i.i35, %bb7
  %cursor.sroa.15.0 = phi i32 [ 6, %bb2.i.i35 ], [ 5, %bb7 ]
  %window_size.sroa.0.0 = phi i64 [ %7, %bb2.i.i35 ], [ 0, %bb7 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_29)
  store i32 0, ptr %_29, align 4
  %8 = getelementptr inbounds nuw i8, ptr %_29, i32 4
  store i32 1, ptr %8, align 4
  %9 = getelementptr inbounds nuw i8, ptr %_29, i32 8
  store i32 2, ptr %9, align 4
  %10 = getelementptr inbounds nuw i8, ptr %_29, i32 12
  store i32 4, ptr %10, align 4
  %_31 = and i8 %_2.i, 3
  %_30 = zext nneg i8 %_31 to i32
  %11 = getelementptr inbounds nuw [4 x i8], ptr %_29, i32 %_30
  %dictionary_bytes = load i32, ptr %11, align 4, !noundef !59
  call void @llvm.lifetime.end.p0(ptr nonnull %_29)
  %_3.i = icmp ugt i32 %dictionary_bytes, 8
  br i1 %_3.i, label %bb37, label %bb2.i

bb2.i:                                            ; preds = %bb10
  call void @llvm.lifetime.start.p0(ptr nonnull %word.sroa.0.i45)
  store i64 0, ptr %word.sroa.0.i45, align 8, !noalias !109
  %_4.i.i48 = sub nsw i32 %input.1, %cursor.sroa.15.0
  %_3.i.i49 = icmp ugt i32 %dictionary_bytes, %_4.i.i48
  br i1 %_3.i.i49, label %bb10.i60, label %bb2.i.i50

bb2.i.i50:                                        ; preds = %bb2.i
  %end.i.i51 = add nuw nsw i32 %dictionary_bytes, %cursor.sroa.15.0
  %_13.not.i.i53 = icmp samesign ugt i32 %end.i.i51, %input.1
  br i1 %_13.not.i.i53, label %bb6.i.i59, label %bb38, !prof !69

bb6.i.i59:                                        ; preds = %bb2.i.i50
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %cursor.sroa.15.0, i32 noundef %end.i.i51, i32 noundef %input.1, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_f98695e4aa1fd53eef7097a70735602a) #9, !noalias !113
  unreachable

bb10.i60:                                         ; preds = %bb2.i
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i45)
  br label %bb37

bb35:                                             ; preds = %bb8
  %12 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %12, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb37:                                             ; preds = %bb10.i60, %bb10
  %_35.sroa.7.0.ph = phi i8 [ 4, %bb10 ], [ 2, %bb10.i60 ]
  %13 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_35.sroa.7.0.ph, ptr %13, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb38:                                             ; preds = %bb2.i.i50
  %_22.i.i57 = getelementptr inbounds nuw i8, ptr %input.0, i32 %cursor.sroa.15.0
  call void @llvm.memcpy.p0.p0.i32(ptr nonnull align 8 %word.sroa.0.i45, ptr nonnull readonly align 1 %_22.i.i57, i32 range(i32 0, 2147483640) %dictionary_bytes, i1 false), !alias.scope !117, !noalias !121
  %word.sroa.0.i45.0.word.sroa.0.i45.0.word.sroa.0.i45.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i58 = load i64, ptr %word.sroa.0.i45, align 8, !noalias !109
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i45)
  %dictionary_id = trunc i64 %word.sroa.0.i45.0.word.sroa.0.i45.0.word.sroa.0.i45.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i58 to i32
  %_40 = lshr i8 %_2.i, 6
  switch i8 %_40, label %default.unreachable111 [
    i8 0, label %bb16
    i8 1, label %bb15
    i8 2, label %bb14
    i8 3, label %bb18
  ]

default.unreachable111:                           ; preds = %bb38
  unreachable

bb16:                                             ; preds = %bb38
  br i1 %single_segment.not, label %bb23, label %bb18

bb15:                                             ; preds = %bb38
  br label %bb18

bb14:                                             ; preds = %bb38
  br label %bb18

bb18:                                             ; preds = %bb38, %bb15, %bb14, %bb16
  %14 = phi i1 [ false, %bb16 ], [ true, %bb15 ], [ false, %bb14 ], [ false, %bb38 ]
  %size_bytes.sroa.0.0 = phi i32 [ 1, %bb16 ], [ 2, %bb15 ], [ 4, %bb14 ], [ 8, %bb38 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %word.sroa.0.i62)
  store i64 0, ptr %word.sroa.0.i62, align 8, !noalias !123
  %_4.i.i67 = sub nsw i32 %input.1, %end.i.i51
  %_3.i.i68 = icmp ugt i32 %size_bytes.sroa.0.0, %_4.i.i67
  br i1 %_3.i.i68, label %bb39, label %bb2.i.i69

bb2.i.i69:                                        ; preds = %bb18
  %end.i.i70 = add nuw nsw i32 %size_bytes.sroa.0.0, %end.i.i51
  %_22.i.i76 = getelementptr inbounds nuw i8, ptr %input.0, i32 %end.i.i51
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(1) %word.sroa.0.i62, ptr noundef nonnull readonly align 1 dereferenceable(1) %_22.i.i76, i32 range(i32 0, 2147483640) %size_bytes.sroa.0.0, i1 false), !alias.scope !127, !noalias !131
  %word.sroa.0.i62.0.word.sroa.0.i62.0.word.sroa.0.i62.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i77 = load i64, ptr %word.sroa.0.i62, align 8, !noalias !123
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i62)
  %15 = add i64 %word.sroa.0.i62.0.word.sroa.0.i62.0.word.sroa.0.i62.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i77, 256
  %_50.sroa.0.0 = select i1 %14, i64 %15, i64 %word.sroa.0.i62.0.word.sroa.0.i62.0.word.sroa.0.i62.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i77
  %spec.select = select i1 %single_segment.not, i64 %window_size.sroa.0.0, i64 %_50.sroa.0.0
  br label %bb23

bb23:                                             ; preds = %bb2.i.i69, %bb16
  %cursor.sroa.15.1 = phi i32 [ %end.i.i51, %bb16 ], [ %end.i.i70, %bb2.i.i69 ]
  %content_size.sroa.0.0 = phi i64 [ 0, %bb16 ], [ 1, %bb2.i.i69 ]
  %content_size.sroa.4.0 = phi i64 [ undef, %bb16 ], [ %_50.sroa.0.0, %bb2.i.i69 ]
  %window_size.sroa.0.1 = phi i64 [ %window_size.sroa.0.0, %bb16 ], [ %spec.select, %bb2.i.i69 ]
  %_59 = lshr i8 %_2.i, 2
  %_59.lobit = and i8 %_59, 1
  store i64 %content_size.sroa.0.0, ptr %_0, align 8
  %_56.sroa.0.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i64 %content_size.sroa.4.0, ptr %_56.sroa.0.sroa.4.0._0.sroa_idx, align 8
  %_56.sroa.0.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 16
  store i64 %window_size.sroa.0.1, ptr %_56.sroa.0.sroa.5.0._0.sroa_idx, align 8
  %_56.sroa.0.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 24
  store i32 %dictionary_id, ptr %_56.sroa.0.sroa.6.0._0.sroa_idx, align 8
  %_56.sroa.0.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 28
  store i8 %_59.lobit, ptr %_56.sroa.0.sroa.7.0._0.sroa_idx, align 4
  %_56.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 32
  store i32 %cursor.sroa.15.1, ptr %_56.sroa.4.0._0.sroa_idx, align 8
  br label %bb30

bb39:                                             ; preds = %bb18
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i62)
  %16 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %16, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb30:                                             ; preds = %bb37, %bb39, %bb35, %bb33, %bb6, %bb31, %bb3, %bb23
  ret void
}

; <zstdoxide::cursor::ByteCursor>::take
; Function Attrs: nounwind
define internal fastcc void @_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly align 4 captures(none) dereferenceable(8) %_0, ptr noalias nofree noundef nonnull align 4 captures(none) dereferenceable(12) %self, i32 noundef %count) unnamed_addr #1 !guid !133 {
start:
  %0 = getelementptr inbounds nuw i8, ptr %self, i32 4
  %_11.1 = load i32, ptr %0, align 4, !noundef !59
  %1 = getelementptr inbounds nuw i8, ptr %self, i32 8
  %_6 = load i32, ptr %1, align 4, !noundef !59
  %_4 = sub i32 %_11.1, %_6
  %_3 = icmp ugt i32 %count, %_4
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %end = add i32 %_6, %count
  %_19 = icmp ult i32 %end, %_6
  %_13.not = icmp ugt i32 %end, %_11.1
  %or.cond = or i1 %_19, %_13.not
  br i1 %or.cond, label %bb6, label %bb4, !prof !69

bb1:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i8 2, ptr %2, align 4
  store ptr null, ptr %_0, align 4
  br label %bb3

bb4:                                              ; preds = %bb2
  %_12.0 = load ptr, ptr %self, align 4, !nonnull !59, !noundef !59
  %_22 = getelementptr inbounds nuw i8, ptr %_12.0, i32 %_6
  store i32 %end, ptr %1, align 4
  store ptr %_22, ptr %_0, align 4
  %3 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %count, ptr %3, align 4
  br label %bb3

bb6:                                              ; preds = %bb2
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_6, i32 noundef %end, i32 noundef %_11.1, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_f98695e4aa1fd53eef7097a70735602a) #9
  unreachable

bb3:                                              ; preds = %bb1, %bb4
  ret void
}

; zstdoxide::frame_layout::frame_info
; Function Attrs: nounwind
define dso_local void @_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout10frame_info(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([40 x i8]) align 8 captures(none) dereferenceable(40) initializes((0, 9)) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #1 !guid !134 {
start:
  %layout.sroa.7 = alloca [19 x i8], align 1
  %kind.sroa.5 = alloca [19 x i8], align 1
  %_3 = alloca [48 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_3)
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCsgJjTu8wsiG2_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_3, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef %input.1) #8
  %0 = load i64, ptr %_3, align 8, !range !135, !noundef !59
  %1 = icmp eq i64 %0, -1
  %2 = getelementptr inbounds nuw i8, ptr %_3, i32 8
  %_16 = load i8, ptr %2, align 8
  br i1 %1, label %bb7, label %bb8

bb7:                                              ; preds = %start
  call void @llvm.lifetime.end.p0(ptr nonnull %_3)
  %3 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_16, ptr %3, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb8:                                              ; preds = %start
  %_15.sroa.5.0._3.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 9
  %_15.sroa.5.sroa.0.0.copyload = load i24, ptr %_15.sroa.5.0._3.sroa_idx, align 1
  %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 12
  %_15.sroa.5.sroa.4.0.copyload = load i8, ptr %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx, align 4
  %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 13
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %layout.sroa.7, ptr noundef nonnull align 1 dereferenceable(19) %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx, i32 19, i1 false)
  %_15.sroa.6.0._3.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 32
  %_15.sroa.6.0.copyload = load i32, ptr %_15.sroa.6.0._3.sroa_idx, align 8
  %_15.sroa.8.0._3.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 40
  %_15.sroa.8.0.copyload = load i32, ptr %_15.sroa.8.0._3.sroa_idx, align 8
  %_15.sroa.9.0._3.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 44
  %_15.sroa.9.0.copyload = load i8, ptr %_15.sroa.9.0._3.sroa_idx, align 4
  call void @llvm.lifetime.end.p0(ptr nonnull %_3)
  %.not = icmp eq i64 %0, 2
  br i1 %.not, label %bb3, label %bb4

bb4:                                              ; preds = %bb8
  %layout.sroa.3.sroa.2.0.insert.ext = zext i24 %_15.sroa.5.sroa.0.0.copyload to i32
  %layout.sroa.3.sroa.2.0.insert.shift = shl nuw i32 %layout.sroa.3.sroa.2.0.insert.ext, 8
  %layout.sroa.3.sroa.0.0.insert.ext = zext i8 %_16 to i32
  %layout.sroa.3.sroa.0.0.insert.insert = or disjoint i32 %layout.sroa.3.sroa.2.0.insert.shift, %layout.sroa.3.sroa.0.0.insert.ext
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %kind.sroa.5, ptr noundef nonnull align 1 dereferenceable(19) %layout.sroa.7, i32 19, i1 false)
  br label %bb5

bb3:                                              ; preds = %bb8
  %_10 = add i32 %_15.sroa.6.0.copyload, -8
  br label %bb5

bb5:                                              ; preds = %bb4, %bb3
  %kind.sroa.3.0 = phi i32 [ %layout.sroa.3.sroa.0.0.insert.insert, %bb4 ], [ %_10, %bb3 ]
  %kind.sroa.4.0 = phi i8 [ %_15.sroa.5.sroa.4.0.copyload, %bb4 ], [ %_15.sroa.9.0.copyload, %bb3 ]
  store i64 %0, ptr %_0, align 8
  %_13.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i32 %kind.sroa.3.0, ptr %_13.sroa.4.0._0.sroa_idx, align 8
  %_13.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 12
  store i8 %kind.sroa.4.0, ptr %_13.sroa.5.0._0.sroa_idx, align 4
  %_13.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 13
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %_13.sroa.6.0._0.sroa_idx, ptr noundef nonnull align 1 dereferenceable(19) %kind.sroa.5, i32 19, i1 false)
  %_13.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 32
  store i32 %_15.sroa.6.0.copyload, ptr %_13.sroa.7.0._0.sroa_idx, align 8
  %_13.sroa.8.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 36
  store i32 %_15.sroa.8.0.copyload, ptr %_13.sroa.8.0._0.sroa_idx, align 4
  br label %bb6

bb6:                                              ; preds = %bb7, %bb5
  ret void
}

; zstdoxide::frame_layout::decompressed_size
; Function Attrs: nounwind
define dso_local void @_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout17decompressed_size(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([16 x i8]) align 8 captures(none) dereferenceable(16) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %0, i32 noundef range(i32 0, -2147483648) %1) unnamed_addr #1 !guid !136 {
start:
  %layout.sroa.7.i = alloca [19 x i8], align 1
  %_3.i = alloca [48 x i8], align 8
  %_6.sroa.7 = alloca [8 x i8], align 8
  %_331 = icmp eq i32 %1, 0
  br i1 %_331, label %bb2.thread, label %bb3.lr.ph

bb3.lr.ph:                                        ; preds = %start
  %_15.sroa.4.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 8
  %_15.sroa.5.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 9
  %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 12
  %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 13
  %_15.sroa.6.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 32
  %_6.sroa.7.13._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_6.sroa.7, i32 5
  %_6.sroa.7.4._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_6.sroa.7, i32 4
  %_6.sroa.7.1._6.sroa_idx = getelementptr inbounds nuw i8, ptr %_6.sroa.7, i32 1
  br label %bb3

bb3:                                              ; preds = %bb3.lr.ph, %bb22
  %input.sroa.0.035 = phi ptr [ %0, %bb3.lr.ph ], [ %_45, %bb22 ]
  %input.sroa.6.034 = phi i32 [ %1, %bb3.lr.ph ], [ %_41, %bb22 ]
  %known.sroa.0.0.off033 = phi i1 [ true, %bb3.lr.ph ], [ %known.sroa.0.1.off0, %bb22 ]
  %total.sroa.0.032 = phi i64 [ 0, %bb3.lr.ph ], [ %total.sroa.0.1, %bb22 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_6.sroa.7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !137)
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.i), !noalias !140
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCsgJjTu8wsiG2_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_3.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.035, i32 noundef range(i32 0, -2147483648) %input.sroa.6.034) #8, !noalias !137
  %2 = load i64, ptr %_3.i, align 8, !range !135, !noalias !140, !noundef !59
  %3 = icmp eq i64 %2, -1
  %_16.i = load i8, ptr %_15.sroa.4.0._3.sroa_idx.i, align 8, !noalias !140
  br i1 %3, label %bb14, label %bb8.i

bb8.i:                                            ; preds = %bb3
  %_15.sroa.5.sroa.0.0.copyload.i = load i24, ptr %_15.sroa.5.0._3.sroa_idx.i, align 1, !noalias !140
  %_15.sroa.5.sroa.4.0.copyload.i = load i8, ptr %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i, align 4, !noalias !140
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %layout.sroa.7.i, ptr noundef nonnull align 1 dereferenceable(19) %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i, i32 19, i1 false)
  %_15.sroa.6.0.copyload.i = load i32, ptr %_15.sroa.6.0._3.sroa_idx.i, align 8, !noalias !140
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i), !noalias !140
  %.not.i = icmp eq i64 %2, 2
  br i1 %.not.i, label %bb15.thread, label %bb17

bb15.thread:                                      ; preds = %bb8.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.sroa.7)
  br label %bb6

bb2:                                              ; preds = %bb22
  %. = zext i1 %known.sroa.0.1.off0 to i64
  br label %bb2.thread

bb2.thread:                                       ; preds = %bb2, %start
  %.52 = phi i64 [ 1, %start ], [ %., %bb2 ]
  %4 = phi i64 [ 0, %start ], [ %total.sroa.0.1, %bb2 ]
  store i64 %.52, ptr %_0, align 8
  %5 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i64 %4, ptr %5, align 8
  br label %bb10

bb14:                                             ; preds = %bb3
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i), !noalias !140
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.sroa.7)
  %6 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_16.i, ptr %6, align 8
  store i64 2, ptr %_0, align 8
  br label %bb10

bb17:                                             ; preds = %bb8.i
  %layout.sroa.3.sroa.2.0.insert.ext.i = zext i24 %_15.sroa.5.sroa.0.0.copyload.i to i32
  %layout.sroa.3.sroa.2.0.insert.shift.i = shl nuw i32 %layout.sroa.3.sroa.2.0.insert.ext.i, 8
  %layout.sroa.3.sroa.0.0.insert.ext.i = zext i8 %_16.i to i32
  %layout.sroa.3.sroa.0.0.insert.insert.i = or disjoint i32 %layout.sroa.3.sroa.2.0.insert.shift.i, %layout.sroa.3.sroa.0.0.insert.ext.i
  store i32 %layout.sroa.3.sroa.0.0.insert.insert.i, ptr %_6.sroa.7, align 8, !alias.scope !137, !noalias !142
  store i8 %_15.sroa.5.sroa.4.0.copyload.i, ptr %_6.sroa.7.4._0.sroa_idx, align 4, !alias.scope !137, !noalias !142
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(3) %_6.sroa.7.13._0.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %layout.sroa.7.i, i32 3, i1 false)
  %_6.sroa.7.1._6.sroa.7.1._6.sroa.7.1._6.sroa.7.9._20.sroa.5.sroa.0.0.copyload = load i56, ptr %_6.sroa.7.1._6.sroa_idx, align 1
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.sroa.7)
  %info.sroa.3.sroa.2.0.insert.ext = zext i56 %_6.sroa.7.1._6.sroa.7.1._6.sroa.7.1._6.sroa.7.9._20.sroa.5.sroa.0.0.copyload to i64
  %info.sroa.3.sroa.2.0.insert.shift = shl nuw i64 %info.sroa.3.sroa.2.0.insert.ext, 8
  %info.sroa.3.sroa.0.0.insert.ext = zext i8 %_16.i to i64
  %info.sroa.3.sroa.0.0.insert.insert = or disjoint i64 %info.sroa.3.sroa.2.0.insert.shift, %info.sroa.3.sroa.0.0.insert.ext
  %7 = trunc nuw i64 %2 to i1
  br i1 %7, label %bb6, label %bb8

bb6:                                              ; preds = %bb15.thread, %bb17
  %_9.sroa.7.0 = phi i64 [ %info.sroa.3.sroa.0.0.insert.insert, %bb17 ], [ 0, %bb15.thread ]
  %_28.0 = add i64 %_9.sroa.7.0, %total.sroa.0.032
  %_28.1 = icmp ult i64 %_28.0, %total.sroa.0.032
  br i1 %_28.1, label %bb18, label %bb8, !prof !91

bb8:                                              ; preds = %bb6, %bb17
  %total.sroa.0.1 = phi i64 [ %total.sroa.0.032, %bb17 ], [ %_28.0, %bb6 ]
  %known.sroa.0.1.off0 = phi i1 [ false, %bb17 ], [ %known.sroa.0.0.off033, %bb6 ]
  %_38 = icmp ugt i32 %_15.sroa.6.0.copyload.i, %input.sroa.6.034
  br i1 %_38, label %bb21, label %bb22, !prof !91

bb18:                                             ; preds = %bb6
  %8 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 10, ptr %8, align 8
  store i64 2, ptr %_0, align 8
  br label %bb10

bb22:                                             ; preds = %bb8
  %_41 = sub nuw nsw i32 %input.sroa.6.034, %_15.sroa.6.0.copyload.i
  %_45 = getelementptr inbounds nuw i8, ptr %input.sroa.0.035, i32 %_15.sroa.6.0.copyload.i
  %_3 = icmp eq i32 %_41, 0
  br i1 %_3, label %bb2, label %bb3

bb21:                                             ; preds = %bb8
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_15.sroa.6.0.copyload.i, i32 noundef %input.sroa.6.034, i32 noundef %input.sroa.6.034, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_5e6a025b48b26689566b9e005edba7db) #9
  unreachable

bb10:                                             ; preds = %bb18, %bb14, %bb2.thread
  ret void
}

; zstdoxide::frame_layout::skippable_payload
; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define dso_local void @_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout17skippable_payload(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([12 x i8]) align 4 captures(none) dereferenceable(12) initializes((0, 1), (4, 8)) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #2 !guid !143 {
start:
  %_3.i.i = icmp samesign ult i32 %input.1, 4
  br i1 %_3.i.i, label %bb11, label %bb12

bb11:                                             ; preds = %start
  store i8 2, ptr %_0, align 4
  %0 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store ptr null, ptr %0, align 4
  br label %bb10

bb12:                                             ; preds = %start
  %word.sroa.0.i.0.copyload = load i32, ptr %input.0, align 1, !alias.scope !144, !noalias !148
  %1 = and i32 %word.sroa.0.i.0.copyload, -16
  %2 = icmp eq i32 %1, 407710288
  br i1 %2, label %bb4, label %bb3

bb4:                                              ; preds = %bb12
  %_3.i.i15 = icmp samesign ult i32 %input.1, 8
  br i1 %_3.i.i15, label %bb13, label %bb14

bb3:                                              ; preds = %bb12
  store i8 3, ptr %_0, align 4
  %3 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store ptr null, ptr %3, align 4
  br label %bb10

bb13:                                             ; preds = %bb4
  store i8 2, ptr %_0, align 4
  %4 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store ptr null, ptr %4, align 4
  br label %bb10

bb14:                                             ; preds = %bb4
  %_22.i.i23 = getelementptr inbounds nuw i8, ptr %input.0, i32 4
  %word.sroa.0.i11.0.copyload = load i32, ptr %_22.i.i23, align 1, !alias.scope !153, !noalias !157
  %_4.i = add nsw i32 %input.1, -8
  %_3.i = icmp ugt i32 %word.sroa.0.i11.0.copyload, %_4.i
  br i1 %_3.i, label %bb17, label %bb2.i

bb2.i:                                            ; preds = %bb14
  %_22.i = getelementptr inbounds nuw i8, ptr %input.0, i32 8
  %5 = trunc i32 %word.sroa.0.i.0.copyload to i8
  %_25 = and i8 %5, 15
  store i8 %_25, ptr %_0, align 4
  %_24.sroa.410.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store ptr %_22.i, ptr %_24.sroa.410.0._0.sroa_idx, align 4
  %_24.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i32 %word.sroa.0.i11.0.copyload, ptr %_24.sroa.5.0._0.sroa_idx, align 4
  br label %bb10

bb17:                                             ; preds = %bb14
  store i8 2, ptr %_0, align 4
  %6 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store ptr null, ptr %6, align 4
  br label %bb10

bb10:                                             ; preds = %bb3, %bb11, %bb17, %bb13, %bb2.i
  ret void
}

; zstdoxide::frame_layout::is_skippable_frame
; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define dso_local noundef zeroext i1 @_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout18is_skippable_frame(ptr noalias nofree noundef nonnull readonly captures(none) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #3 !guid !162 {
start:
  %_3.i.i = icmp samesign ugt i32 %input.1, 3
  br i1 %_3.i.i, label %bb11.i, label %_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian.exit

bb11.i:                                           ; preds = %start
  %word.sroa.0.i.0.copyload = load i32, ptr %input.0, align 1, !alias.scope !163, !noalias !167
  %0 = and i32 %word.sroa.0.i.0.copyload, -16
  %1 = icmp eq i32 %0, 407710288
  br label %_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian.exit

_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian.exit: ; preds = %start, %bb11.i
  %_0.sroa.0.0.off0 = phi i1 [ %1, %bb11.i ], [ false, %start ]
  ret i1 %_0.sroa.0.0.off0
}

; zstdoxide::frame_layout::decompression_bound
; Function Attrs: nounwind
define dso_local void @_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout19decompression_bound(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([16 x i8]) align 8 captures(none) dereferenceable(16) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %0, i32 noundef range(i32 0, -2147483648) %1) unnamed_addr #1 !guid !172 {
start:
  %_3.i = alloca [48 x i8], align 8
  %_246 = icmp eq i32 %1, 0
  br i1 %_246, label %bb2, label %bb3.lr.ph

bb3.lr.ph:                                        ; preds = %start
  %_15.sroa.4.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 8
  %_15.sroa.5.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 9
  %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 12
  %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 13
  %layout.sroa.7.i.sroa.4.0._15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_3.i, i32 16
  %_15.sroa.6.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 32
  %_15.sroa.8.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 40
  br label %bb3

bb3:                                              ; preds = %bb3.lr.ph, %bb18
  %input.sroa.0.049 = phi ptr [ %0, %bb3.lr.ph ], [ %_49, %bb18 ]
  %input.sroa.6.048 = phi i32 [ %1, %bb3.lr.ph ], [ %_45, %bb18 ]
  %total.sroa.0.047 = phi i64 [ 0, %bb3.lr.ph ], [ %_32.0, %bb18 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.i), !noalias !173
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCsgJjTu8wsiG2_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_3.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.049, i32 noundef range(i32 0, -2147483648) %input.sroa.6.048) #8, !noalias !177
  %2 = load i64, ptr %_3.i, align 8, !range !135, !noalias !173, !noundef !59
  %3 = icmp eq i64 %2, -1
  %_16.i = load i8, ptr %_15.sroa.4.0._3.sroa_idx.i, align 8, !noalias !173
  br i1 %3, label %bb10, label %bb8.i

bb8.i:                                            ; preds = %bb3
  %_15.sroa.5.sroa.0.0.copyload.i = load i24, ptr %_15.sroa.5.0._3.sroa_idx.i, align 1, !noalias !173
  %_15.sroa.5.sroa.4.0.copyload.i = load i8, ptr %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i, align 4, !noalias !173
  %layout.sroa.7.i.sroa.0.0.copyload = load i24, ptr %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i, align 1, !noalias !173
  %layout.sroa.7.i.sroa.4.0.copyload = load i64, ptr %layout.sroa.7.i.sroa.4.0._15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.sroa_idx, align 8, !noalias !173
  %_15.sroa.6.0.copyload.i = load i32, ptr %_15.sroa.6.0._3.sroa_idx.i, align 8, !noalias !173
  %_15.sroa.8.0.copyload.i = load i32, ptr %_15.sroa.8.0._3.sroa_idx.i, align 8, !noalias !173
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i), !noalias !173
  %.not.i = icmp eq i64 %2, 2
  br i1 %.not.i, label %bb13, label %bb11

bb2:                                              ; preds = %bb18, %start
  %total.sroa.0.0.lcssa = phi i64 [ 0, %start ], [ %_32.0, %bb18 ]
  %4 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i64 %total.sroa.0.0.lcssa, ptr %4, align 8
  br label %bb9

bb10:                                             ; preds = %bb3
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i), !noalias !173
  %5 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 %_16.i, ptr %5, align 1
  br label %bb9

bb11:                                             ; preds = %bb8.i
  %trunc.i = trunc nuw nsw i64 %2 to i2
  %cond = icmp eq i2 %trunc.i, 0
  br i1 %cond, label %bb11.i, label %bb5.i14

bb5.i14:                                          ; preds = %bb11
  %.sroa.4.sroa.6.0.insert.ext = zext i24 %layout.sroa.7.i.sroa.0.0.copyload to i64
  %.sroa.4.sroa.6.0.insert.shift = shl nuw i64 %.sroa.4.sroa.6.0.insert.ext, 40
  %.sroa.4.sroa.5.0.insert.ext = zext i8 %_15.sroa.5.sroa.4.0.copyload.i to i64
  %.sroa.4.sroa.5.0.insert.shift = shl nuw nsw i64 %.sroa.4.sroa.5.0.insert.ext, 32
  %.sroa.4.sroa.4.0.insert.ext = zext i24 %_15.sroa.5.sroa.0.0.copyload.i to i64
  %.sroa.4.sroa.4.0.insert.shift = shl nuw nsw i64 %.sroa.4.sroa.4.0.insert.ext, 8
  %.sroa.4.sroa.0.0.insert.ext = zext i8 %_16.i to i64
  %.sroa.4.sroa.5.0.insert.insert = or disjoint i64 %.sroa.4.sroa.4.0.insert.shift, %.sroa.4.sroa.0.0.insert.ext
  %.sroa.4.sroa.4.0.insert.insert = or disjoint i64 %.sroa.4.sroa.5.0.insert.insert, %.sroa.4.sroa.5.0.insert.shift
  %.sroa.4.sroa.0.0.insert.insert = or disjoint i64 %.sroa.4.sroa.4.0.insert.insert, %.sroa.4.sroa.6.0.insert.shift
  br label %bb13

bb11.i:                                           ; preds = %bb11
  %_11.i = tail call i64 @llvm.umin.i64(i64 %layout.sroa.7.i.sroa.4.0.copyload, i64 131072)
  %_12.i = zext i32 %_15.sroa.8.0.copyload.i to i64
  %6 = mul nuw nsw i64 %_11.i, %_12.i
  br label %bb13

bb13:                                             ; preds = %bb8.i, %bb11.i, %bb5.i14
  %.sink.i = phi i64 [ %6, %bb11.i ], [ %.sroa.4.sroa.0.0.insert.insert, %bb5.i14 ], [ 0, %bb8.i ]
  %_32.0 = add i64 %.sink.i, %total.sroa.0.047
  %_32.1 = icmp ult i64 %_32.0, %total.sroa.0.047
  br i1 %_32.1, label %bb7, label %bb16, !prof !91

bb16:                                             ; preds = %bb13
  %_42 = icmp ugt i32 %_15.sroa.6.0.copyload.i, %input.sroa.6.048
  br i1 %_42, label %bb17, label %bb18, !prof !91

bb18:                                             ; preds = %bb16
  %_45 = sub nuw nsw i32 %input.sroa.6.048, %_15.sroa.6.0.copyload.i
  %_49 = getelementptr inbounds nuw i8, ptr %input.sroa.0.049, i32 %_15.sroa.6.0.copyload.i
  %_2 = icmp eq i32 %_45, 0
  br i1 %_2, label %bb2, label %bb3

bb17:                                             ; preds = %bb16
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_15.sroa.6.0.copyload.i, i32 noundef %input.sroa.6.048, i32 noundef %input.sroa.6.048, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_7435913fe0ee9560e916ffcef5e2af54) #9
  unreachable

bb7:                                              ; preds = %bb13
  %7 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %7, align 1
  br label %bb9

bb9:                                              ; preds = %bb7, %bb10, %bb2
  %.sink = phi i8 [ 1, %bb7 ], [ 1, %bb10 ], [ 0, %bb2 ]
  store i8 %.sink, ptr %_0, align 8
  ret void
}

; zstdoxide::frame_layout::decompression_margin
; Function Attrs: nounwind
define dso_local void @_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout20decompression_margin(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([8 x i8]) align 4 captures(none) dereferenceable(8) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %0, i32 noundef range(i32 0, -2147483648) %1) unnamed_addr #1 !guid !178 {
start:
  %_6 = alloca [48 x i8], align 8
  %_331 = icmp eq i32 %1, 0
  br i1 %_331, label %bb11, label %bb3.lr.ph

bb3.lr.ph:                                        ; preds = %start
  %_24.sroa.5.sroa.4.0._24.sroa.5.0._6.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_6, i32 16
  %_24.sroa.6.0._6.sroa_idx = getelementptr inbounds nuw i8, ptr %_6, i32 32
  %_24.sroa.7.0._6.sroa_idx = getelementptr inbounds nuw i8, ptr %_6, i32 36
  %_24.sroa.7.sroa.4.0._24.sroa.7.0._6.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_6, i32 40
  br label %bb3

bb3:                                              ; preds = %bb3.lr.ph, %bb22
  %input.sroa.0.035 = phi ptr [ %0, %bb3.lr.ph ], [ %_47, %bb22 ]
  %input.sroa.6.034 = phi i32 [ %1, %bb3.lr.ph ], [ %_43, %bb22 ]
  %maximum_block.sroa.0.033 = phi i32 [ 0, %bb3.lr.ph ], [ %_15.sroa.0.0, %bb22 ]
  %overhead.sroa.0.032 = phi i32 [ 0, %bb3.lr.ph ], [ %_31.0.i, %bb22 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_6)
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCsgJjTu8wsiG2_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_6, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.035, i32 noundef %input.sroa.6.034) #8
  %2 = load i64, ptr %_6, align 8, !range !135, !noundef !59
  %3 = icmp eq i64 %2, -1
  br i1 %3, label %bb12, label %bb13

bb2:                                              ; preds = %bb22
  %_20.0 = add i32 %_15.sroa.0.0, %_31.0.i
  %_20.1 = icmp ult i32 %_20.0, %_31.0.i
  br i1 %_20.1, label %bb9, label %bb11, !prof !179

bb12:                                             ; preds = %bb3
  %4 = getelementptr inbounds nuw i8, ptr %_6, i32 8
  %_25 = load i8, ptr %4, align 8, !range !92, !noundef !59
  call void @llvm.lifetime.end.p0(ptr nonnull %_6)
  %5 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 %_25, ptr %5, align 1
  br label %bb8

bb13:                                             ; preds = %bb3
  %_24.sroa.5.sroa.4.0.copyload = load i64, ptr %_24.sroa.5.sroa.4.0._24.sroa.5.0._6.sroa_idx.sroa_idx, align 8
  %_24.sroa.6.0.copyload = load i32, ptr %_24.sroa.6.0._6.sroa_idx, align 8
  %_24.sroa.7.sroa.0.0.copyload = load i32, ptr %_24.sroa.7.0._6.sroa_idx, align 4
  %_24.sroa.7.sroa.4.0.copyload = load i32, ptr %_24.sroa.7.sroa.4.0._24.sroa.7.0._6.sroa_idx.sroa_idx, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %_6)
  %6 = tail call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %_24.sroa.7.sroa.4.0.copyload, i32 3)
  %_14.0.i = extractvalue { i32, i1 } %6, 0
  %_14.1.i = extractvalue { i32, i1 } %6, 1
  br i1 %_14.1.i, label %bb14, label %bb4.i, !prof !91

bb4.i:                                            ; preds = %bb13
  %_23.0.i = add i32 %_24.sroa.7.sroa.0.0.copyload, %overhead.sroa.0.032
  %_23.1.i = icmp ult i32 %_23.0.i, %overhead.sroa.0.032
  br i1 %_23.1.i, label %bb14, label %bb7.i, !prof !91

bb7.i:                                            ; preds = %bb4.i
  %_31.0.i = add i32 %_14.0.i, %_23.0.i
  %_31.1.i = icmp ult i32 %_31.0.i, %_23.0.i
  br i1 %_31.1.i, label %bb14, label %bb15, !prof !91

bb14:                                             ; preds = %bb4.i, %bb7.i, %bb13
  %7 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %7, align 1
  br label %bb8

bb15:                                             ; preds = %bb7.i
  %.not = icmp eq i64 %2, 2
  br i1 %.not, label %bb16, label %bb18

bb18:                                             ; preds = %bb15
  %_35 = tail call i64 @llvm.umin.i64(i64 %_24.sroa.5.sroa.4.0.copyload, i64 131072)
  %8 = trunc nuw nsw i64 %_35 to i32
  %9 = tail call i32 @llvm.umax.i32(i32 %maximum_block.sroa.0.033, i32 %8)
  br label %bb16

bb16:                                             ; preds = %bb15, %bb18
  %_15.sroa.0.0 = phi i32 [ %9, %bb18 ], [ %maximum_block.sroa.0.033, %bb15 ]
  %_40 = icmp ugt i32 %_24.sroa.6.0.copyload, %input.sroa.6.034
  br i1 %_40, label %bb21, label %bb22, !prof !91

bb22:                                             ; preds = %bb16
  %_43 = sub nuw nsw i32 %input.sroa.6.034, %_24.sroa.6.0.copyload
  %_47 = getelementptr inbounds nuw i8, ptr %input.sroa.0.035, i32 %_24.sroa.6.0.copyload
  %_3 = icmp eq i32 %_43, 0
  br i1 %_3, label %bb2, label %bb3

bb21:                                             ; preds = %bb16
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_24.sroa.6.0.copyload, i32 noundef %input.sroa.6.034, i32 noundef %input.sroa.6.034, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_048330390765a63cc99a694538bdf970) #9
  unreachable

bb8:                                              ; preds = %bb11, %bb9, %bb14, %bb12
  %.sink = phi i8 [ 1, %bb14 ], [ 1, %bb12 ], [ 0, %bb11 ], [ 1, %bb9 ]
  store i8 %.sink, ptr %_0, align 4
  ret void

bb11:                                             ; preds = %start, %bb2
  %_20.049 = phi i32 [ %_20.0, %bb2 ], [ 0, %start ]
  %10 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %_20.049, ptr %10, align 4
  br label %bb8

bb9:                                              ; preds = %bb2
  %11 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %11, align 1
  br label %bb8
}

; zstdoxide::frame_layout::frame_compressed_size
; Function Attrs: nounwind
define dso_local void @_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout21frame_compressed_size(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([8 x i8]) align 4 captures(none) dereferenceable(8) initializes((0, 1)) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #1 !guid !180 {
start:
  %_3 = alloca [48 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_3)
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCsgJjTu8wsiG2_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_3, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef %input.1) #8
  %0 = load i64, ptr %_3, align 8, !range !135, !noundef !59
  %1 = icmp eq i64 %0, -1
  br i1 %1, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %_3, i32 8
  %_7 = load i8, ptr %2, align 8, !range !92, !noundef !59
  call void @llvm.lifetime.end.p0(ptr nonnull %_3)
  %3 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 %_7, ptr %3, align 1
  br label %bb3

bb5:                                              ; preds = %start
  %_6.sroa.6.0._3.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 32
  %_6.sroa.6.0.copyload = load i32, ptr %_6.sroa.6.0._3.sroa_idx, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %_3)
  %4 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %_6.sroa.6.0.copyload, ptr %4, align 4
  br label %bb3

bb3:                                              ; preds = %bb4, %bb5
  %storemerge = phi i8 [ 0, %bb5 ], [ 1, %bb4 ]
  store i8 %storemerge, ptr %_0, align 4
  ret void
}

; zstdoxide::frame_utilities::write_skippable_frame
; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define dso_local void @_RNvNtCsgJjTu8wsiG2_9zstdoxide15frame_utilities21write_skippable_frame(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([8 x i8]) align 4 captures(none) dereferenceable(8) initializes((0, 1)) %_0, ptr noalias nofree noundef nonnull writeonly captures(none) %output.0, i32 noundef range(i32 0, -2147483648) %output.1, ptr noalias nofree noundef nonnull readonly captures(none) %payload.0, i32 noundef range(i32 0, -2147483648) %payload.1, i8 noundef %variant) unnamed_addr #2 !guid !181 {
start:
  %_4 = icmp ugt i8 %variant, 15
  br i1 %_4, label %bb1, label %bb7

bb1:                                              ; preds = %start
  %0 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 0, ptr %0, align 1
  br label %bb5

bb7:                                              ; preds = %start
  %_15.0.i = add nuw i32 %payload.1, 8
  %_32.not = icmp ugt i32 %_15.0.i, %output.1
  br i1 %_32.not, label %bb10, label %_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide.exit

bb10:                                             ; preds = %bb7
  %1 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %1, align 1
  br label %bb5

_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide.exit: ; preds = %bb7
  %_20 = zext nneg i8 %variant to i32
  %_19 = or disjoint i32 %_20, 407710288
  store i32 %_19, ptr %output.0, align 1, !alias.scope !182, !noalias !186
  %_61 = getelementptr inbounds nuw i8, ptr %output.0, i32 4
  store i32 %payload.1, ptr %_61, align 1, !alias.scope !188, !noalias !192
  %_68 = getelementptr inbounds nuw i8, ptr %output.0, i32 8
  tail call void @llvm.memcpy.p0.p0.i32(ptr nonnull align 1 %_68, ptr nonnull readonly align 1 %payload.0, i32 range(i32 0, 2147483640) %payload.1, i1 false), !alias.scope !194, !noalias !198
  %2 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %_15.0.i, ptr %2, align 4
  br label %bb5

bb5:                                              ; preds = %bb1, %bb10, %_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide.exit
  %.sink = phi i8 [ 1, %bb1 ], [ 1, %bb10 ], [ 0, %_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide.exit ]
  store i8 %.sink, ptr %_0, align 4
  ret void
}

; <zstdoxide::error::Error as core::fmt::Display>::fmt
; Function Attrs: nounwind
define dso_local noundef zeroext i1 @_RNvXNtCsgJjTu8wsiG2_9zstdoxide5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt(ptr noalias nofree noundef readonly captures(none) dereferenceable(1) %self, ptr noalias nofree noundef align 4 dereferenceable(16) %f) unnamed_addr #1 !guid !200 {
start:
  %0 = load i8, ptr %self, align 1, !range !92, !noundef !59
  %1 = zext nneg i8 %0 to i32
  %switch.gep = getelementptr inbounds nuw i8, ptr @switch.table._RNvXNtCsgJjTu8wsiG2_9zstdoxide5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt, i32 %1
  %switch.load = load i8, ptr %switch.gep, align 1
  %switch.ext = zext i8 %switch.load to i32
  %2 = zext nneg i8 %0 to i32
  %switch.gep2 = getelementptr inbounds nuw [4 x i8], ptr @switch.table._RNvXNtCsgJjTu8wsiG2_9zstdoxide5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt.2, i32 %2
  %switch.load3 = load ptr, ptr %switch.gep2, align 4
; call <core::fmt::Formatter>::write_str
  %_0 = tail call noundef zeroext i1 @_RNvMsa_NtCsavDHSl9k1eG_4core3fmtNtB5_9Formatter9write_str(ptr noalias nofree noundef nonnull align 4 dereferenceable(16) %f, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %switch.load3, i32 noundef %switch.ext) #8
  ret i1 %_0
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i32, i1 immarg) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #4

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #4

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #5

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nounwind
declare dso_local void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef, i32 noundef, i32 noundef, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16)) unnamed_addr #6

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #5

; <core::fmt::Formatter>::write_str
; Function Attrs: nounwind
declare dso_local noundef zeroext i1 @_RNvMsa_NtCsavDHSl9k1eG_4core3fmtNtB5_9Formatter9write_str(ptr noalias nofree noundef align 4 dereferenceable(16), ptr noalias nofree noundef nonnull readonly captures(address, read_provenance), i32 noundef) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #7

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite, inaccessiblemem: readwrite) "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #1 = { nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #2 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #3 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { cold noinline noreturn nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #8 = { nounwind }
attributes #9 = { noreturn nounwind }

!llvm.module.flags = !{!22}
!llvm.ident = !{!23}

!0 = !{i64 8320939517513768669}
!1 = !{i64 -7876700357024202234}
!2 = !{i64 8229175007843846267}
!3 = !{i64 -1522874307099014385}
!4 = !{i64 7512126743259060610}
!5 = !{i64 -4642687049923981367}
!6 = !{i64 -2761552684497579345}
!7 = !{i64 -7843684625569795435}
!8 = !{i64 -2767616829044611954}
!9 = !{i64 5267307681198218931}
!10 = !{i64 -7894723260664342736}
!11 = !{i64 -3761644508677843679}
!12 = !{i64 8733207373168963049}
!13 = !{i64 -5633018024390486693}
!14 = !{i64 9121937281366145253}
!15 = !{i64 2648930756245448138}
!16 = !{i64 3522713088270311916}
!17 = !{i64 5147435254309794859}
!18 = !{i64 -2512769954043039240}
!19 = !{i64 4095519572073047103}
!20 = !{i64 8398202349256621521}
!21 = !{i64 -8009460748660006076}
!22 = !{i32 7, !"frame-pointer", i32 2}
!23 = !{!"rustc version 1.101.0-nightly (1d81eb4ad 2026-10-07)"}
!24 = !{i64 -3895076251321697326}
!25 = !{!26}
!26 = distinct !{!26, !27, !"_RNvNtCsgJjTu8wsiG2_9zstdoxide15frame_utilities21write_skippable_frame: %payload.0"}
!27 = distinct !{!27, !"_RNvNtCsgJjTu8wsiG2_9zstdoxide15frame_utilities21write_skippable_frame"}
!28 = !{!29, !31, !32}
!29 = distinct !{!29, !30, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!30 = distinct !{!30, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!31 = distinct !{!31, !30, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!32 = distinct !{!32, !27, !"_RNvNtCsgJjTu8wsiG2_9zstdoxide15frame_utilities21write_skippable_frame: %output.0"}
!33 = !{!34, !35, !26}
!34 = distinct !{!34, !30, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!35 = distinct !{!35, !27, !"_RNvNtCsgJjTu8wsiG2_9zstdoxide15frame_utilities21write_skippable_frame: %_0"}
!36 = !{!37, !39, !32}
!37 = distinct !{!37, !38, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!38 = distinct !{!38, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!39 = distinct !{!39, !38, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!40 = !{!41, !35, !26}
!41 = distinct !{!41, !38, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!42 = !{!43, !45, !32, !26}
!43 = distinct !{!43, !44, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!44 = distinct !{!44, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!45 = distinct !{!45, !44, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!46 = !{!47, !35}
!47 = distinct !{!47, !44, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!48 = !{i64 -1533938313586882742}
!49 = !{!50, !52}
!50 = distinct !{!50, !51, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!51 = distinct !{!51, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!52 = distinct !{!52, !51, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!53 = !{!54, !55, !57}
!54 = distinct !{!54, !51, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!55 = distinct !{!55, !56, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!56 = distinct !{!56, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!57 = distinct !{!57, !56, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!58 = !{i64 0, i64 3}
!59 = !{}
!60 = !{!61, !63}
!61 = distinct !{!61, !62, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!62 = distinct !{!62, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!63 = distinct !{!63, !62, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!64 = !{!65, !66, !68}
!65 = distinct !{!65, !62, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!66 = distinct !{!66, !67, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!67 = distinct !{!67, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!68 = distinct !{!68, !67, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!69 = !{!"branch_weights", i32 4001, i32 4000000}
!70 = !{!71, !73}
!71 = distinct !{!71, !72, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take: %_0"}
!72 = distinct !{!72, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take"}
!73 = distinct !{!73, !72, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take: %self"}
!74 = !{!75, !77, !78, !80}
!75 = distinct !{!75, !76, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take: %_0"}
!76 = distinct !{!76, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take"}
!77 = distinct !{!77, !76, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take: %self"}
!78 = distinct !{!78, !79, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!79 = distinct !{!79, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!80 = distinct !{!80, !79, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!81 = !{!82, !84}
!82 = distinct !{!82, !83, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!83 = distinct !{!83, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!84 = distinct !{!84, !83, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!85 = !{!86, !78, !80}
!86 = distinct !{!86, !83, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!87 = !{!88, !90}
!88 = distinct !{!88, !89, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take: %_0"}
!89 = distinct !{!89, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take"}
!90 = distinct !{!90, !89, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take: %self"}
!91 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!92 = !{i8 0, i8 14}
!93 = !{i64 -306959669232683882}
!94 = !{!95, !97}
!95 = distinct !{!95, !96, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!96 = distinct !{!96, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!97 = distinct !{!97, !96, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!98 = !{!99, !100, !102}
!99 = distinct !{!99, !96, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!100 = distinct !{!100, !101, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!101 = distinct !{!101, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!102 = distinct !{!102, !101, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!103 = !{!104}
!104 = distinct !{!104, !105, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4byte: %self"}
!105 = distinct !{!105, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4byte"}
!106 = !{!107}
!107 = distinct !{!107, !108, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4byte: %self"}
!108 = distinct !{!108, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4byte"}
!109 = !{!110, !112}
!110 = distinct !{!110, !111, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!111 = distinct !{!111, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!112 = distinct !{!112, !111, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!113 = !{!114, !116, !110, !112}
!114 = distinct !{!114, !115, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take: %_0"}
!115 = distinct !{!115, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take"}
!116 = distinct !{!116, !115, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor4take: %self"}
!117 = !{!118, !120}
!118 = distinct !{!118, !119, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!119 = distinct !{!119, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!120 = distinct !{!120, !119, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!121 = !{!122, !110, !112}
!122 = distinct !{!122, !119, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!123 = !{!124, !126}
!124 = distinct !{!124, !125, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!125 = distinct !{!125, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!126 = distinct !{!126, !125, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!127 = !{!128, !130}
!128 = distinct !{!128, !129, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!129 = distinct !{!129, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!130 = distinct !{!130, !129, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!131 = !{!132, !124, !126}
!132 = distinct !{!132, !129, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!133 = !{i64 7101517776886865034}
!134 = !{i64 -6763040429494130263}
!135 = !{i64 -1, i64 3}
!136 = !{i64 768202378184905707}
!137 = !{!138}
!138 = distinct !{!138, !139, !"_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout10frame_info: %_0"}
!139 = distinct !{!139, !"_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout10frame_info"}
!140 = !{!138, !141}
!141 = distinct !{!141, !139, !"_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout10frame_info: %input.0"}
!142 = !{!141}
!143 = !{i64 8881124294804055647}
!144 = !{!145, !147}
!145 = distinct !{!145, !146, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!146 = distinct !{!146, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!147 = distinct !{!147, !146, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!148 = !{!149, !150, !152}
!149 = distinct !{!149, !146, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!150 = distinct !{!150, !151, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!151 = distinct !{!151, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!152 = distinct !{!152, !151, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!153 = !{!154, !156}
!154 = distinct !{!154, !155, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!155 = distinct !{!155, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!156 = distinct !{!156, !155, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!157 = !{!158, !159, !161}
!158 = distinct !{!158, !155, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!159 = distinct !{!159, !160, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!160 = distinct !{!160, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!161 = distinct !{!161, !160, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!162 = !{i64 8938425428340608332}
!163 = !{!164, !166}
!164 = distinct !{!164, !165, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!165 = distinct !{!165, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!166 = distinct !{!166, !165, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!167 = !{!168, !169, !171}
!168 = distinct !{!168, !165, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!169 = distinct !{!169, !170, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!170 = distinct !{!170, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!171 = distinct !{!171, !170, !"_RNvMNtCsgJjTu8wsiG2_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!172 = !{i64 7932637570642796256}
!173 = !{!174, !176}
!174 = distinct !{!174, !175, !"_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout10frame_info: %_0"}
!175 = distinct !{!175, !"_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout10frame_info"}
!176 = distinct !{!176, !175, !"_RNvNtCsgJjTu8wsiG2_9zstdoxide12frame_layout10frame_info: %input.0"}
!177 = !{!174}
!178 = !{i64 -1871720668002643045}
!179 = !{!"branch_weights", !"expected", i32 2424395, i32 2145059253}
!180 = !{i64 5493360461586176449}
!181 = !{i64 6993193869120145891}
!182 = !{!183, !185}
!183 = distinct !{!183, !184, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!184 = distinct !{!184, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!185 = distinct !{!185, !184, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!186 = !{!187}
!187 = distinct !{!187, !184, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!188 = !{!189, !191}
!189 = distinct !{!189, !190, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!190 = distinct !{!190, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!191 = distinct !{!191, !190, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!192 = !{!193}
!193 = distinct !{!193, !190, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!194 = !{!195, !197}
!195 = distinct !{!195, !196, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %dest.0"}
!196 = distinct !{!196, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide"}
!197 = distinct !{!197, !196, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: %src.0"}
!198 = !{!199}
!199 = distinct !{!199, !196, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsgJjTu8wsiG2_9zstdoxide: argument 2"}
!200 = !{i64 -3918737271500355704}
