from pathlib import Path
import hashlib,json,os,subprocess,tomllib,time
R=Path.cwd();O=Path('/tmp/zstdoxide-optimal-retained-matrix-1016');O.mkdir();features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'})
env=dict(os.environ,CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-retained-matrix-1016-target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in list((R/'src').rglob('*.rs'))+list((R/'tests').rglob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock']};commands=[]
def save(status,error=None):(O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,features=features,commands=commands),indent=2)+'\n')
def run(label,cmd):
 start=time.monotonic();print('START',label,flush=True)
 with(O/(label+'.log')).open('wb')as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 data=(O/(label+'.log')).read_bytes();commands.append(dict(label=label,argv=cmd,exit_code=p.returncode,seconds=time.monotonic()-start,log=label+'.log',sha256=hashlib.sha256(data).hexdigest()));save('running')
 if p.returncode:raise RuntimeError(label)
 print('END',label,flush=True)
try:
 for feature in features:
  run('test-'+feature,['cargo','test','--offline','--locked','--features',feature,'--lib','optimal_'])
  run('nostd-'+feature,['cargo','check','--offline','--locked','--no-default-features','--features',feature])
 for mode,flags in [('safe',[]),('all',['--all-features'])]:run('full-'+mode,['cargo','test','--offline','--locked',*flags])
 assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in source.items())
 save('passed')
except BaseException as e:save('failed',repr(e));raise
