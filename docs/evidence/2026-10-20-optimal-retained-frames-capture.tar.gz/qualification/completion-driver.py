"""Complete copied-evidence controls, predecessor checks and archive after capture."""
from pathlib import Path
import concurrent.futures,json,shutil,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');T=Path('/private/tmp');C=T/'optimal-retained-frames-capture'
for _ in range(360):
 try:e=json.loads((C/'evidence.json').read_text())
 except (OSError,json.JSONDecodeError):e={}
 if e.get('status')=='failed':raise ValueError('native capture failed')
 if e.get('status')=='passed':break
 time.sleep(5)
else:raise ValueError('capture completion deadline')
def run(mode):
 log=T/('optimal-retained-frames-controls-'+mode+'.log');flags=['-O']if mode=='optimized'else[]
 with log.open('xb')as stream:p=subprocess.run(['python3','-B',*flags,'scripts/check_optimal_retained_frames_capture_controls.py',str(C)],cwd=R,stdout=stream,stderr=subprocess.STDOUT,timeout=1200)
 print(mode,p.returncode,flush=True);p.check_returncode()
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,['normal','optimized']))
Q=C/'qualification';Q.mkdir()
for mode in ['normal','optimized']:
 log=T/('optimal-retained-frames-controls-'+mode+'.log');result=json.loads(log.read_text());(Q/('controls-'+mode+'.json')).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 shutil.copyfile(T/('optimal-retained-frames-preflight-'+mode+'.log'),Q/('preflight-'+mode+'.json'))
 with (Q/('predecessors-'+mode+'.json')).open('xb')as stream:
  flags=['-O']if mode=='optimized'else[]
  subprocess.run(['python3','-B',*flags,'scripts/check_optimal_retained_frames_predecessors.py',str(C)],cwd=R,stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=120)
for name in ['scripts/archive_optimal_retained_frames_capture.py','scripts/check_optimal_retained_frames_predecessors.py']:
 shutil.copyfile(R/name,Q/Path(name).name)
shutil.copyfile(Path(__file__),Q/'completion-driver.py');shutil.copyfile(T/'optimal-retained-frames-capture.log',Q/'capture-driver.log')
subprocess.run(['python3','-B','scripts/archive_optimal_retained_frames_capture.py',str(C)],cwd=R,check=True,timeout=300)
