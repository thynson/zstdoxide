from pathlib import Path
import sys,json,subprocess,hashlib,shutil
sys.path.insert(0,str(Path.cwd()/'scripts'))
from oracles.optimal_startup_instrumentation import instrument
from optimal_path_wide_capture_plan import reference_sources
r=Path.cwd();up=Path('/private/tmp/zstdoxide-reference-lazy-1.5.7');out=Path('/tmp/zstdoxide-optimal-startup-preflight-final');out.mkdir();g=out/'generated';g.mkdir()
original=(up/'lib/compress/zstd_opt.c').read_bytes();generated,manifest=instrument(original)
(g/'original_zstd_opt.c').write_bytes(original);(g/'observed_zstd_opt.c').write_bytes(generated);(g/'instrumentation.json').write_text(json.dumps(manifest,indent=2)+'\n')
sources,units=reference_sources(up);(out/'reference.json').write_text(json.dumps(dict(sources=sources,units=units),indent=2)+'\n')
commands=[]
for mode,flags in [('normal',['-O2']),('sanitized',['-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer'])]:
 cmd=['clang','-std=c11','-g','-DDEBUGLEVEL=2','-DZSTD_DISABLE_ASM','-DZSTD_LEGACY_SUPPORT=0','-UZSTD_MULTITHREAD','-DXXH_NAMESPACE=ZSTD_','-I',str(g),'-I',str(up/'lib'),'-I',str(up/'lib/common'),'-I',str(up/'lib/compress'),*flags,'-Wall','-Wextra','-Werror','-fsyntax-only',str(r/'scripts/oracles/optimal_startup.c')]
 with(out/(mode+'.log')).open('wb')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 commands.append(dict(label=mode,argv=cmd,exit_code=p.returncode));(out/'evidence.json').write_text(json.dumps(commands,indent=2));print(mode,p.returncode)
