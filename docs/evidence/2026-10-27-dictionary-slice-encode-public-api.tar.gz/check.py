from pathlib import Path
import json,hashlib,os,subprocess,time,re,tomllib,datetime,signal
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,28,9,38,0,tzinfo=datetime.timezone.utc).timestamp()
# No extra compiler process may overlap the already queued benchmark campaigns.
gates=[Path('/private/tmp/module32-33-continuation/continue3-evidence.json')]
for p in gates:assert json.loads(p.read_text())['status']=='passed',p
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};features=sorted(f for f in tomllib.loads((S/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'));assert len(features)==22
assert not (D/'evidence.json').exists()
e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=source,gates={str(p):sha(p) for p in gates},commands=[]);env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'4','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
plan=[]
for name,flags in [('safe',[]),('sink',['--features','unsafe-frame-sink']),('dictionary',['--features','unsafe-dictionary']),('all',['--features',','.join(features)])]:
 plan.extend([(name+'-unit',['cargo','test','--offline','--locked','--lib','dictionary_slice_engine_',*flags],4),(name+'-ordinary',['cargo','test','--offline','--locked','--lib','encode::tests::slice_engine_',*flags],6),(name+'-public',['cargo','test','--offline','--locked','--test','dictionary_slice_encode_output',*flags],5),(name+'-docs',['cargo','test','--offline','--locked','--doc','encode::compress_into_with_dictionary',*flags],2),(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*flags],None),(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'],None)])
plan.append(('format',['cargo','fmt','--all','--','--check'],None));assert len(plan)==25;save()
try:
 for label,args,count in plan:
  remaining=deadline-time.time()-30
  if remaining<30:raise TimeoutError('Work window reached before '+label)
  t=time.monotonic()
  with (D/(label+'.log')).open('xb') as f:
   p=subprocess.Popen(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=remaining)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise TimeoutError('Work window reached during '+label)
  row=dict(label=label,argv=args,exit_code=code,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log')));e['commands'].append(row);save();print(label,code,flush=True);assert code==0,label
  if count is not None:
   groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (D/(label+'.log')).read_text());assert sum(int(a) for a,_,_ in groups)==count and all(int(b)==int(c)==0 for _,b,c in groups),(label,groups);row['passed']=count;save()
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),qualification='Twenty-five focused commands: four dictionary engine and six ordinary units, five public contracts and two documentation examples under safe/sink/dictionary/all22 selections, true no_std, strict Clippy and format. Explicit post33 audited metadata was adopted before freezing. No native/platform/full-matrix/benchmark or module closure claim.');save()
except TimeoutError as ex:e.update(status='interrupted-at-user-deadline',error=repr(ex));save();raise
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
