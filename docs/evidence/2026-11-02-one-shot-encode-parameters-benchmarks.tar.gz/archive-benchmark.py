"""Archive the measured module36 parameterized dictionary benchmark campaign."""
from pathlib import Path
import hashlib, json, tarfile, importlib.util, datetime

D = Path('/private/tmp/module36-benchmark')
E = Path(__file__).parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('measure', D / 'measure.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, gates = m.validate()
r = json.loads((D / 'repeat/evidence.json').read_text())
q = json.loads((D / 'timed.json').read_text())
z = json.loads((D / 'repeat/timed.json').read_text())
s = json.loads((D / 'summary.json').read_text())
assert q['status'] == z['status'] == 'passed' and len(q['runs']) == 24 and len(z['runs']) == 2
assert q['gates'] == gates
common = {k: v for k, v in z['gates'].items() if k in q['gates']}
assert common == gates
assert z['gates']['primary_timing'] == sha(D / 'timed.json')
assert z['gates']['repeat_barrier'] == sha(D / 'repeat/cpu-barrier.json')
assert z['primary_timing_sha256'] == sha(D / 'timed.json') and z['build_evidence_sha256'] == sha(D / 'repeat/evidence.json')
for folder, build, timed in [(D, b, q), (D / 'repeat', r, z)]:
    for row in build['builds']:
        assert sha(folder / row['executable']) == row['sha256']
        assert (folder / (row['name'] + '-qualify.tsv')).read_bytes() == (D / 'safe-qualify.tsv').read_bytes()
    for row in timed['runs']:
        assert sha(folder / (row['name'] + '-timed.tsv')) == row['sha256']
fixtures = {'source/tests/upstream/data/golden-compression/http', 'source/tests/upstream/data/golden-compression/large-literal-and-match-lengths', 'source/tests/upstream/dictionaries/formatted.dict'}
files = {}
for p in D.rglob('*'):
    if not p.is_file():
        continue
    rel = p.relative_to(D)
    if any(x == 'target' or x.endswith('-target') or x == '__pycache__' for x in rel.parts):
        continue
    if 'source' in rel.parts and p.suffix not in {'.rs', '.toml', '.lock', '.json', '.py', '.md', '.sh', '.csv', '.tsv'} and str(rel) not in fixtures:
        continue
    files[str(rel)] = p
assert fixtures <= files.keys()
files['archive-benchmark.py'] = Path(__file__)
files['LICENSE.zstd'] = Path('/Users/lanxingcan/Workspace/zstdoxize/LICENSE.zstd')
name = '2026-11-02-one-shot-encode-parameters-benchmarks'
archive = E / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
result = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), build=b, repeat_build=r, primary_timing=q, repeat_timing=z, summary=s, members={n: dict(sha256=sha(p), bytes=p.stat().st_size) for n, p in files.items()}, archive=archive.name, archive_sha256=sha(archive), qualification='All 24 safe/isolated/all production feature selections and two independently rebuilt safe/all repeats retain 1455 timing samples and 576 qualification rows per executable: stateless and persistent coordinator configurations over 48 case/level pairs and three immutable dictionary kinds, plus setup-only coordinator construction/observation/drop batch observations whose loop and black-box overhead is included and not directly subtractable. Dictionary and scratch ledgers are outside timings; Global per-call scratch is inside. Both configurations resolve the same request, borrow the same immutable view, write the same caller destination, produce identical bytes and record identical ledgers. Actual process barriers precede campaigns. No universal profile benefit, absence of scratch allocation, C byte identity or complete codec replacement is claimed.')
(E / (name + '.json')).write_text(json.dumps(result, indent=2) + '\n')
print(name, archive.stat().st_size)
rows = [x for x in s['comparisons'] if x['campaign'] in ['primary', 'repeat'] and x['backend'] in ['safe', 'all']]
pick = lambda campaign, backend, scope: next(x['value'] for x in rows if x['campaign'] == campaign and x['backend'] == backend and x['scope'] == scope)
kind_rows = []
for campaign, backend in [('primary', 'safe'), ('primary', 'all'), ('repeat', 'safe'), ('repeat', 'all')]:
    kind_rows.append(f"| {campaign} | {backend} | {pick(campaign, backend, 'all-nonempty'):.4f} | {pick(campaign, backend, 'empty-dictionary'):.4f} | {pick(campaign, backend, 'raw-dictionary'):.4f} | {pick(campaign, backend, 'prepared-dictionary'):.4f} |")
strategy_rows = []
for campaign, backend in [('primary', 'safe'), ('primary', 'all'), ('repeat', 'safe'), ('repeat', 'all')]:
    strategy_rows.append(f"| {campaign} | {backend} | " + ' | '.join(f"{pick(campaign, backend, 'strategy:' + k):.4f}" for k in ['fast', 'double-fast', 'greedy', 'lazy', 'lazy2', 'binary-tree-lazy2']) + ' |')
report = f"""# Parameterized dictionary one-shot measurements

Forty-eight fixed case/level pairs combine three immutable dictionary kinds
(empty, raw and prepared) with seven inputs: empty and tiny data, 1.5 KiB text,
8 KiB deterministic noise, a 65,792-byte block boundary, a 131,073-byte RLE
block and a 393,233-byte multi-block source. Levels 1-6 and 9 cover all six
admitted combined-staging profiles; the largest input omits only level 9,
whose hash log exceeds the documented Lazy2 cap. Each pair resolves the same
request against the same source and borrowed `DictionaryView`, writes the same
caller destination prepared outside clocks and produces exactly the stateless
bytes in the persistent coordinator.

Twenty-four primary executables (safe, all 22 isolated features and all
features) and independently rebuilt safe/all repeats each retain 1455 samples:
144 pairs, two configurations and five samples, plus 15 setup-only batch
samples. Per-attempt compression clocks include all Global scratch
allocation/release. Dictionary construction, caller destination setup,
complete-byte/guard validation and allocation ledgers stay outside clocks. A
separate tracked dictionary domain must remain unchanged through every call
while the tracked scratch domain must be fully released; stateless and
coordinator configurations record identical 576-row ledgers per executable.
The setup-only observation clocks whole 4096-operation coordinator
construction/observation/drop batches; that batch includes loop and black-box
overhead and is not a directly subtractable estimate of per-attempt overhead.
Two fresh process observations gate each campaign without claiming desktop
idleness.

Coordinator/stateless ratios are equal-weight geometric means of per-pair
median latency ratios over 123 nonempty pairs (41 per dictionary kind).

| Campaign | Backend | All nonempty | Empty dictionary | Raw dictionary | Prepared dictionary |
| --- | --- | ---: | ---: | ---: | ---: |
{chr(10).join(kind_rows)}

| Campaign | Backend | Fast | DoubleFast | Greedy | Lazy | Lazy2 | BinaryTreeLazy2 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(strategy_rows)}

Values below one mean lower observed coordinator latency on this host. Fixed
order, five samples and one host do not establish statistical significance, a
universal profile benefit or elimination of per-call staging. The coordinator
adds only a selection claim and a dictionary-view borrow; ratios near one are
consistent with that machinery, not proof of zero cost. Setup-only batch
medians are retained separately in the evidence and are not subtracted from any
compression clock. All executables, source, raw samples and barriers are
retained. Evidence: `evidence/{name}.json`.
"""
(D / 'one-shot-encode-parameters-benchmarks.md').write_text(report)
print('report written')
