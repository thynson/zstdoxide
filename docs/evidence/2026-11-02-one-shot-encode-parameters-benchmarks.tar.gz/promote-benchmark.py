"""Promote the qualified module36 parameterized dictionary timing item."""
from pathlib import Path
import json, hashlib, subprocess, shutil

D = Path('/private/tmp/module36-benchmark')
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = Path('/private/tmp/module36-archives/promotion-state.json')
prev = json.loads(state.read_text())
assert prev['stage'] == 'matrix'
assert prev['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == prev['production_source']
name = '2026-11-02-one-shot-encode-parameters-benchmarks'
receipt = D / (name + '.json')
r = json.loads(receipt.read_text())
assert r['status'] == 'passed' and sha(D / r['archive']) == r['archive_sha256']
assert r['build']['production_source'] == prev['production_source']
assert r['repeat_build']['production_source'] == prev['production_source']
report = D / 'one-shot-encode-parameters-benchmarks.md'
assert report.exists()
for q in [receipt, D / r['archive']]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
assert not (R / 'docs/one-shot-encode-parameters-benchmarks.md').exists()
shutil.copyfile(report, R / 'docs/one-shot-encode-parameters-benchmarks.md')
p = R / 'TODO.md'
s = p.read_text()
task = '- [ ] Compare identical parameterized stateless/coordinator workloads with explicit setup, allocation domains and independent repeats after CPU barriers.'
assert s.count(task) == 1
s = s.replace(task, task.replace('[ ]', '[x]'))
p.write_text(s)
p = R / 'docs/one-shot-encode-parameters-validation.md'
s = p.read_text()
old = '''Corpus validation, measurements and reconciliation remain open.'''
assert s.count(old) == 1
s = s.replace(old, '''Corpus validation and reconciliation remain open.''')
old = '''Evidence: `evidence/{name}.json`.'''.format(name='2026-11-02-one-shot-encode-parameters-feature-matrix')
assert s.count(old) == 1
s = s.replace(old, old + '''

## Stateless and coordinator measurements

Forty-eight fixed case/level pairs combine the three immutable dictionary kinds
with seven inputs and cover all six admitted combined-staging profiles. Both
configurations resolve the same request against the same source and borrowed
view, write the same caller destination prepared outside clocks and produce
identical bytes; their tracked dictionary/scratch ledgers are identical across
every pair. Each of 24 primary executables and independently rebuilt safe/all
repeats retains 1455 samples, and each records 576 qualification rows. The
coordinator/stateless geometric-mean ratios and setup-only batch observations
are recorded in `one-shot-encode-parameters-benchmarks.md`; no universal
profile benefit or absence of scratch allocation is claimed.
Evidence: `evidence/{name}.json`.'''.format(name=name))
p.write_text(s)
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', 'TODO.md', 'docs/one-shot-encode-parameters-validation.md', 'docs/one-shot-encode-parameters-benchmarks.md', 'docs/evidence/' + receipt.name, 'docs/evidence/' + r['archive']], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Record parameterized dictionary timing results'], cwd=R, check=True)
prev.update(stage='benchmarks', head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(), production_source={str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')})
state.write_text(json.dumps(prev, indent=2) + '\n')
print('module36 benchmark item promoted at', prev['head'][:12])
