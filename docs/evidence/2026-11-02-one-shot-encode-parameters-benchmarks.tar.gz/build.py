"""Build and clock-free-qualify every module36 parameterized dictionary backend.

Harness checks (strict Clippy on the bench under safe/all features plus
formatting) run first, then 24 primary builds (safe, every isolated unsafe
feature, all features) and an independently rebuilt safe/all repeat. Every
executable's qualify ledger must be byte-identical: 576 rows separating the
dictionary and scratch allocation domains across the stateless and persistent
coordinator configurations. Timing starts only in measure.py after every gate
passes.
"""
from pathlib import Path
import os, subprocess, json, time, hashlib, shutil, tomllib, datetime, signal

D = Path(__file__).parent
S = D / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
deadline = datetime.datetime.fromisoformat('2026-11-02T09:00:00+00:00').timestamp()
features = sorted(n for n in tomllib.loads((S / 'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
assert len(features) == 22
source = {str(p.relative_to(S)): sha(p) for p in S.rglob('*') if p.is_file()}
production = {n: h for n, h in source.items() if n.startswith('src/')}
env = {**os.environ, 'CARGO_BUILD_JOBS': '4', 'CARGO_INCREMENTAL': '0', 'CARGO_TARGET_DIR': str(D / 'target')}


def command(args, cwd, environment, out, err=None):
    assert time.time() < deadline - 30, args
    p = subprocess.Popen(args, cwd=cwd, env=environment, stdout=out, stderr=err if err is not None else subprocess.STDOUT, start_new_session=True)
    try:
        return p.wait(timeout=max(1, deadline - time.time() - 30))
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGTERM)
        try:
            p.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGKILL)
            p.wait()
        raise TimeoutError('Work window reached during ' + str(args))


h = dict(status='running', source=source, source_sha256=sha(S / 'benches/one_shot_encode_parameters.rs'), commands=[])


def save_h():
    (D / 'harness-check.json').write_text(json.dumps(h, indent=2) + '\n')


save_h()
try:
    for label, args in [
        ('safe', ['cargo', 'clippy', '--offline', '--locked', '--bench', 'one_shot_encode_parameters', '--', '-D', 'warnings']),
        ('all', ['cargo', 'clippy', '--offline', '--locked', '--bench', 'one_shot_encode_parameters', '--all-features', '--', '-D', 'warnings']),
        ('format', ['cargo', 'fmt', '--all', '--', '--check']),
    ]:
        t = time.monotonic()
        with (D / ('harness-' + label + '.log')).open('xb') as f:
            code = command(args, S, {**env, 'CARGO_TARGET_DIR': str(D / 'harness-target')}, f)
        h['commands'].append(dict(label=label, argv=args, exit_code=code, seconds=time.monotonic() - t, log_sha256=sha(D / ('harness-' + label + '.log'))))
        save_h()
        assert code == 0, label
    h['status'] = 'passed'
    save_h()
except BaseException as ex:
    h.update(status='interrupted-at-user-deadline' if isinstance(ex, TimeoutError) else 'failed', error=repr(ex))
    save_h()
    raise
for repeat in [False, True]:
    Q = D / 'repeat' if repeat else D
    if repeat:
        Q.mkdir()
    e = dict(status='building', source=source, production_source=production, builds=[], qualification='Forty-eight fixed case/level pairs across seven inputs and three immutable dictionary kinds cover the six admitted combined-staging profiles. Clock-free ledgers separate the dictionary allocation domain (unchanged snapshots through every call) from the per-call scratch domain (complete release) for stateless and persistent coordinator configurations; both configurations produce the same frame bytes. Every backend build must reproduce the same 576-row ledger. No measured performance claim before complete qualified builds and the full matrix.')
    if repeat:
        e['source_evidence_sha256'] = sha(D / 'evidence.json')

    def save():
        (Q / 'evidence.json').write_text(json.dumps(e, indent=2) + '\n')

    save()
    try:
        schedule = [('safe', []), ('all', ['--all-features'])] if repeat else [('safe', []), *[(f, ['--features', f]) for f in features], ('all', ['--all-features'])]
        for name, flags in schedule:
            args = ['cargo', 'bench', '--offline', '--locked', '--bench', 'one_shot_encode_parameters', '--no-run', '--message-format=json', *flags]
            t = time.monotonic()
            with (Q / (name + '-build.jsonl')).open('xb') as out, (Q / (name + '-build.log')).open('xb') as err:
                code = command(args, S, {**env, 'CARGO_TARGET_DIR': str(Q / 'target')}, out, err)
            assert code == 0, (name, 'build')
            artifacts = [json.loads(line) for line in (Q / (name + '-build.jsonl')).read_text().splitlines() if line.startswith('{')]
            exes = [a['executable'] for a in artifacts if a.get('reason') == 'compiler-artifact' and a.get('target', {}).get('name') == 'one_shot_encode_parameters' and a.get('executable')]
            assert len(exes) == 1
            exe = Q / 'executables' / name
            exe.parent.mkdir(exist_ok=True)
            shutil.copyfile(exes[0], exe)
            exe.chmod(0o755)
            with (Q / (name + '-qualify.tsv')).open('xb') as out, (Q / (name + '-qualify.stderr')).open('xb') as err:
                code = command([str(exe), 'qualify'], S, env, out, err)
            payload = (Q / (name + '-qualify.tsv')).read_bytes()
            assert code == 0 and len(payload.decode().splitlines()) == 576, (name, 'qualification')
            if repeat or name != 'safe':
                assert payload == (D / 'safe-qualify.tsv').read_bytes(), (name, 'ledger parity')
            e['builds'].append(dict(name=name, argv=args, seconds=time.monotonic() - t, executable=str(exe.relative_to(Q)), sha256=sha(exe), qualification_sha256=sha(Q / (name + '-qualify.tsv'))))
            save()
            print('repeat' if repeat else 'primary', name, 'built and qualified', flush=True)
        for n, value in source.items():
            assert sha(S / n) == value, n
        e['status'] = 'qualified-not-timed'
        save()
    except BaseException as ex:
        e.update(status='interrupted-at-user-deadline' if isinstance(ex, TimeoutError) else 'failed', error=repr(ex))
        save()
        raise
