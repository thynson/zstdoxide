//! Fixed parameter/dictionary/input triples compare the stateless
//! caller-owned API with the persistent call-scoped coordinator.
//!
//! Dictionary construction and caller destination setup stay outside every
//! compression clock. Qualification uses an independent tracked dictionary
//! domain and an independent scratch domain: the dictionary snapshot must stay
//! unchanged through every call while all codec scratch allocations are
//! released. Timed calls use Global directly; the setup-only batch observation
//! constructs, observes and drops a coordinator and is not subtractable from a
//! per-attempt compression clock.
use std::{
    alloc::{Allocator, Global},
    hint::black_box,
    time::Instant,
};
use zstdoxide::{
    CompressionParameterRequest, DecodeOptions, Dictionary, DictionaryView, OneShotEncoder,
    ReferenceStrategy, SourceSize, compress_into_with_parameters_and_dictionary_in,
    compress_with_parameters_and_dictionary_in, decompress_with_dictionary_in,
};
use zstdoxide_test_allocator::{AllocationSnapshot, AllocatorConfig, TrackingAllocator};

const LEVELS: [i32; 7] = [1, 2, 3, 4, 5, 6, 9];
const LARGE_LEVELS: [i32; 6] = [1, 2, 3, 4, 5, 6];
const GUARD: usize = 16;
/// Whole coordinator construction/observation/drop pairs per clocked sample.
const SETUP_BATCH: u32 = 4096;

fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf2_9ce4_8422_2325, |h, &b| {
        (h ^ u64::from(b)).wrapping_mul(0x100_0000_01b3)
    })
}

fn noise(mut state: u32, length: usize) -> Vec<u8> {
    (0..length)
        .map(|_| {
            state ^= state.wrapping_shl(13);
            state ^= state >> 17;
            state ^= state.wrapping_shl(5);
            state as u8
        })
        .collect()
}

fn repeated(length: usize) -> Vec<u8> {
    b"parameterized dictionary coordinator caller-owned output preserves bytes"
        .iter()
        .cycle()
        .take(length)
        .copied()
        .collect()
}

fn inputs() -> Vec<(&'static str, Vec<u8>)> {
    vec![
        ("empty", Vec::new()),
        ("tiny", b"abcde".to_vec()),
        ("text-1536", repeated(1_536)),
        ("noise-8192", noise(0x9e37_79b9, 8_192)),
        ("block-boundary", repeated(65_792)),
        ("rle-block", vec![0x5a; 131_073]),
        ("multi-block", repeated(393_233)),
    ]
}

#[derive(Clone, Copy)]
enum DictionaryKind {
    Empty,
    Raw,
    Prepared,
}

impl DictionaryKind {
    fn name(self) -> &'static str {
        match self {
            Self::Empty => "empty-dictionary",
            Self::Raw => "raw-dictionary",
            Self::Prepared => "prepared-dictionary",
        }
    }

    fn content(self) -> &'static [u8] {
        match self {
            Self::Empty => b"",
            Self::Raw => b"parameterized dictionary content parameterized dictionary content",
            Self::Prepared => include_bytes!("../tests/upstream/dictionaries/formatted.dict"),
        }
    }

    fn build<A: Allocator + Clone>(self, owner: A) -> Dictionary<A> {
        match self {
            Self::Empty => Dictionary::raw_in(self.content(), owner).unwrap(),
            Self::Raw => Dictionary::raw_in(self.content(), owner).unwrap(),
            Self::Prepared => Dictionary::from_bytes_in(self.content(), owner).unwrap(),
        }
    }
}

fn levels_for(case: &str) -> &'static [i32] {
    // Level 9 on the largest multi-block input resolves to a Lazy2 profile
    // whose hash log exceeds the documented cap; the bounded schedule omits
    // only that rejected combination.
    if case == "multi-block" {
        &LARGE_LEVELS
    } else {
        &LEVELS
    }
}

fn strategy_name(strategy: ReferenceStrategy) -> &'static str {
    match strategy {
        ReferenceStrategy::Fast => "fast",
        ReferenceStrategy::DoubleFast => "double-fast",
        ReferenceStrategy::Greedy => "greedy",
        ReferenceStrategy::Lazy => "lazy",
        ReferenceStrategy::Lazy2 => "lazy2",
        ReferenceStrategy::BinaryTreeLazy2 => "binary-tree-lazy2",
        ReferenceStrategy::Optimal | ReferenceStrategy::Ultra | ReferenceStrategy::Ultra2 => {
            panic!("dictionary request resolved to an explicitly rejected profile")
        }
    }
}

fn resolved(
    request: &CompressionParameterRequest,
    input: &[u8],
    view: DictionaryView<'_>,
) -> &'static str {
    strategy_name(
        request
            .resolve(SourceSize::Known(input.len() as u64), view.content().len())
            .unwrap()
            .strategy(),
    )
}

fn check_output(output: &[u8], expected: &[u8]) {
    assert_eq!(&output[GUARD..GUARD + expected.len()], expected);
    assert!(
        output[..GUARD]
            .iter()
            .chain(&output[GUARD + expected.len()..])
            .all(|&b| b == 0xa5)
    );
}

fn validate_frame(input: &[u8], output: &[u8], dictionary: DictionaryView<'_>) {
    let decoded =
        decompress_with_dictionary_in(output, &dictionary, DecodeOptions::new(input.len()), Global)
            .unwrap();
    assert_eq!(decoded, input);
}

#[allow(clippy::too_many_arguments)]
fn row(
    name: &str,
    config: &str,
    role: &str,
    level: i32,
    strategy: &str,
    source: &[u8],
    frame: &[u8],
    s: AllocationSnapshot,
) {
    assert_eq!(s.live_blocks, 0);
    assert_eq!(s.identities_created, s.owners_dropped);
    assert!(!s.violations.any());
    println!(
        "{name}\t{config}\t{role}\t{level}\t{strategy}\t{}\t{:016x}\t{}\t{:016x}\t{}\t{}\t{}\t{}",
        source.len(),
        fingerprint(source),
        frame.len(),
        fingerprint(frame),
        s.attempts,
        s.requested_bytes,
        s.peak_bytes,
        s.deallocate_calls
    );
}

fn qualify_case(kind: DictionaryKind, case: &str, input: &[u8], level: i32, config: &str) {
    let dictionary_owner = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
    let dictionary_monitor = dictionary_owner.monitor();
    let dictionary = kind.build(dictionary_owner);
    let dictionary_before = dictionary_monitor.snapshot();
    let view = dictionary.view();
    let request = CompressionParameterRequest::with_level(level);
    let strategy = resolved(&request, input, view);
    let expected =
        compress_with_parameters_and_dictionary_in(input, &request, &view, Global).unwrap();
    validate_frame(input, &expected, view);
    let scratch = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
    let scratch_monitor = scratch.monitor();
    let mut output = vec![0xa5; expected.len() + 2 * GUARD];
    let written = match config {
        "stateless" => compress_into_with_parameters_and_dictionary_in(
            input,
            &mut output[GUARD..GUARD + expected.len()],
            &request,
            &view,
            scratch,
        ),
        "coordinator" => {
            let mut encoder = OneShotEncoder::with_dictionary(view);
            let written = encoder.compress_into_with_parameters_in(
                input,
                &request,
                &mut output[GUARD..GUARD + expected.len()],
                scratch,
            );
            assert!(!encoder.prefix_pending());
            assert_eq!(encoder.dictionary().unwrap().as_bytes(), kind.content());
            written
        }
        _ => unreachable!("fixed configuration names"),
    };
    assert_eq!(written, Ok(expected.len()));
    check_output(&output, &expected);
    scratch_monitor.assert_released();
    assert_eq!(dictionary_monitor.snapshot(), dictionary_before);
    assert_eq!(
        fingerprint(dictionary.as_bytes()),
        fingerprint(kind.content())
    );
    let name = format!("{}-L{level}-{case}", kind.name());
    row(
        &name,
        config,
        "scratch",
        level,
        strategy,
        input,
        &expected,
        scratch_monitor.snapshot(),
    );
    drop(dictionary);
    dictionary_monitor.assert_released();
    row(
        &name,
        config,
        "dictionary",
        level,
        strategy,
        input,
        &expected,
        dictionary_monitor.snapshot(),
    );
}

fn measure_setup(kind: DictionaryKind) {
    // The dictionary is built outside the clock; only coordinator
    // construction/observation/drop is timed as a whole batch.
    let dictionary = kind.build(Global);
    let view = dictionary.view();
    let dictionary_hash = fingerprint(dictionary.as_bytes());
    let name = format!("{}-coordinator-setup", kind.name());
    for sample in 0..5 {
        let start = Instant::now();
        for _ in 0..SETUP_BATCH {
            {
                let encoder = OneShotEncoder::with_dictionary(view);
                black_box(encoder.dictionary().map(|view| view.content()));
                black_box(encoder.prefix_pending());
            }
        }
        let elapsed = start.elapsed().as_nanos();
        assert_eq!(fingerprint(dictionary.as_bytes()), dictionary_hash);
        println!("{name}\tsetup\t{sample}\t{SETUP_BATCH}\t{elapsed}");
    }
}

fn measure_case(
    kind: DictionaryKind,
    case: &str,
    input: &[u8],
    level: i32,
    view: DictionaryView<'_>,
) {
    let request = CompressionParameterRequest::with_level(level);
    let expected =
        compress_with_parameters_and_dictionary_in(input, &request, &view, Global).unwrap();
    validate_frame(input, &expected, view);
    let dictionary = kind.build(Global);
    assert_eq!(dictionary.as_bytes(), view.as_bytes());
    let dictionary_hash = fingerprint(dictionary.as_bytes());
    let name = format!("{}-L{level}-{case}", kind.name());
    let mut output = vec![0xa5; expected.len() + 2 * GUARD];
    let iterations = (2 * 1024 * 1024 / (input.len() + 1)).clamp(8, 128);
    for sample in 0..5 {
        let mut elapsed = 0u128;
        for _ in 0..iterations {
            let start = Instant::now();
            let size = black_box(
                compress_into_with_parameters_and_dictionary_in(
                    black_box(input),
                    black_box(&mut output[GUARD..GUARD + expected.len()]),
                    black_box(&request),
                    black_box(&view),
                    Global,
                )
                .unwrap(),
            );
            black_box(size);
            elapsed += start.elapsed().as_nanos();
        }
        check_output(&output, &expected);
        assert_eq!(fingerprint(dictionary.as_bytes()), dictionary_hash);
        println!("{name}\tstateless\t{sample}\t{iterations}\t{elapsed}");
    }
    {
        let mut encoder = OneShotEncoder::with_dictionary(view);
        for sample in 0..5 {
            let mut elapsed = 0u128;
            for _ in 0..iterations {
                let start = Instant::now();
                let size = black_box(
                    encoder
                        .compress_into_with_parameters_in(
                            black_box(input),
                            black_box(&request),
                            black_box(&mut output[GUARD..GUARD + expected.len()]),
                            Global,
                        )
                        .unwrap(),
                );
                black_box(size);
                elapsed += start.elapsed().as_nanos();
            }
            check_output(&output, &expected);
            assert!(!encoder.prefix_pending());
            assert!(encoder.dictionary().is_some());
            assert_eq!(fingerprint(dictionary.as_bytes()), dictionary_hash);
            println!("{name}\tcoordinator\t{sample}\t{iterations}\t{elapsed}");
        }
    }
}

fn main() {
    let command = std::env::args().nth(1).expect("qualify or measure");
    assert!(command == "qualify" || command == "measure");
    for kind in [
        DictionaryKind::Empty,
        DictionaryKind::Raw,
        DictionaryKind::Prepared,
    ] {
        if command == "measure" {
            measure_setup(kind);
        }
        let dictionary = kind.build(Global);
        let view = dictionary.view();
        let dictionary_hash = fingerprint(dictionary.as_bytes());
        for (case, input) in inputs() {
            for &level in levels_for(case) {
                let request = CompressionParameterRequest::with_level(level);
                let _ = resolved(&request, &input, view);
                if command == "qualify" {
                    for config in ["stateless", "coordinator"] {
                        qualify_case(kind, case, &input, level, config);
                    }
                } else {
                    measure_case(kind, case, &input, level, view);
                }
            }
        }
        assert_eq!(fingerprint(dictionary.as_bytes()), dictionary_hash);
    }
}
