"""Observe actual compiler/test quiescence immediately before each timed campaign."""
from pathlib import Path
import datetime, hashlib, json, os, re, subprocess, time

D = Path(__file__).parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
deadline = datetime.datetime.fromisoformat('2026-11-02T09:00:00+00:00').timestamp()
pattern = re.compile('(?:/|\\s)(?:rustc|cargo(?:-miri)?|miri|cc|clang)(?:\\s|$)|/private/tmp/module\\d+-[^ ]*(?:target/|/(?:check[^ /]*|run[^ /]*|build[^ /]*|capture|generate|repeat-build|after-build|resume[^ /]*|prepare[^ /]*|archive[^ /]*|prune[^ /]*)\\.py)')


def barrier(folder, receipts):
    observations = []
    while len(observations) < 2:
        raw = subprocess.check_output(['ps', '-axo', 'pid,ppid,pcpu,etime,command'], text=True)
        matches = [line.strip() for line in raw.splitlines()[1:] if int(line.split()[0]) != os.getpid() and pattern.search(line)]
        if matches:
            observations = []
        else:
            observations.append(dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), active_task_or_compiler_processes=matches))
        if time.time() >= deadline - 30:
            raise TimeoutError('User deadline before measurement CPU barrier')
        time.sleep(5)
    p = folder / 'cpu-barrier.json'
    assert not p.exists()
    p.write_text(json.dumps(dict(status='passed', observer_sha256=sha(Path(__file__)), receipt_sha256={n: sha(Path(n)) for n in receipts}, process_observations=observations, qualification='Two fresh process inventories show no matched task compiler/test/build/archive processes. This is not a claim that the entire desktop is idle.'), indent=2) + '\n')


for repeat in [False, True]:
    folder = D / 'repeat' if repeat else D
    receipts = ['/private/tmp/module36-matrix/evidence.json', str(D / 'harness-check.json'), str(D / 'evidence.json')]
    if repeat:
        receipts.append(str(folder / 'evidence.json'))
        receipts.append(str(D / 'timed.json'))
    barrier(folder, receipts)
    subprocess.run(['python3', str(D / 'measure.py'), *(['--repeat'] if repeat else [])], check=True)
subprocess.run(['python3', str(D / 'summarize.py')], check=True)
