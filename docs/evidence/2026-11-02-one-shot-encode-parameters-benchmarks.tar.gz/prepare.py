"""Create the module36 parameterized dictionary benchmark campaign source.

Copies the qualified module36 HEAD source, adds the parameterized dictionary
benchmark target, formats the new file and installs the controllers. No build
or timing starts here.
"""
from pathlib import Path
import subprocess

P = Path(__file__).parent
D = Path('/private/tmp/module36-benchmark')
R = Path('/Users/lanxingcan/Workspace/zstdoxize')

assert not (D / 'source').exists(), 'campaign source already prepared'
subprocess.run(['mkdir', '-p', str(D)], check=True)
subprocess.run(['rsync', '-a', '--exclude', '.git', '--exclude', 'target', str(R) + '/', str(D / 'source') + '/'], check=True)
S = D / 'source'
subprocess.run(['cp', str(P / 'one_shot_encode_parameters.rs'), str(S / 'benches/one_shot_encode_parameters.rs')], check=True)
p = S / 'Cargo.toml'
p.write_text(p.read_text() + '\n[[bench]]\nname = "one_shot_encode_parameters"\nharness = false\nrequired-features = ["std"]\n')
subprocess.run(['cargo', 'fmt', '--all'], cwd=S, check=True)
for name in ['build.py', 'measure.py', 'summarize.py', 'observe-and-measure.py']:
    subprocess.run(['cp', str(P / name), str(D / name)], check=True)
print('campaign prepared at', D)
