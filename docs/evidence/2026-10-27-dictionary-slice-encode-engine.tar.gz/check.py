from pathlib import Path
import json,hashlib,os,subprocess,time,re,tomllib,datetime
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};features=sorted(f for f in tomllib.loads((S/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'));assert len(features)==22
e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=source,commands=[]);env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
plan=[]
for name,flags in [('safe',[]),('sink',['--features','unsafe-frame-sink']),('dictionary',['--features','unsafe-dictionary']),('all',['--features',','.join(features)])]:
 plan.extend([(name+'-unit',['cargo','test','--offline','--locked','--lib','dictionary_slice_engine_',*flags],4),(name+'-ordinary',['cargo','test','--offline','--locked','--lib','encode::tests::slice_engine_',*flags],6),(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*flags],None),(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'],None)])
plan.append(('format',['cargo','fmt','--all','--','--check'],None));save()
try:
 for label,args,count in plan:
  t=time.monotonic()
  with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  row=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log')));e['commands'].append(row);save();print(label,p.returncode,flush=True);assert p.returncode==0,label
  if count is not None:
   groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (D/(label+'.log')).read_text());assert sum(int(a) for a,_,_ in groups)==count and all(int(b)==int(c)==0 for _,b,c in groups),(label,groups);row['passed']=count;save()
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),qualification='Seventeen focused commands. Four dictionary-view engine units and six ordinary predecessor units execute under safe/sink/dictionary/all22 features with true no_std, strict Clippy and formatting. Exact existing dictionary compressor bytes, empty/raw/prepared/all-ID widths and multiblock input, bound sufficiency, short guards/recovery, immutable dictionaries and independent non-Clone owners plus every observed scratch failure are checked. No new public dictionary output API or native/platform/full-feature/timing milestone is claimed.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
