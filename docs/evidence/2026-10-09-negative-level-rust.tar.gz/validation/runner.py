import hashlib,json,os,pathlib,subprocess,time
ROOT=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize')
OUT=pathlib.Path('/tmp/zstdoxide-negative-level-rust-validation')
OUT.mkdir(exist_ok=False)
FEATURES=['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-dictionary','unsafe-training']
ENV=os.environ.copy();ENV['CARGO_TARGET_DIR']='/tmp/zstdoxide-negative-level-rust-target'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest():
 paths=[ROOT/'Cargo.toml',ROOT/'Cargo.lock',ROOT/'rust-toolchain.toml',ROOT/'tests/upstream_negative_level.rs']
 paths+=sorted((ROOT/'src').glob('*.rs'))
 paths+=sorted(p for p in (ROOT/'test-support/allocator').rglob('*') if p.is_file() and 'target' not in p.parts and p.suffix in ('.rs','.toml'))
 paths+=[ROOT/'tests/upstream/negative-level'/n for n in ['source.raw','simple.zst','advanced.zst','manifest.json']]
 return {str(p.relative_to(ROOT)):sha(p) for p in paths}
initial=manifest();records=[]
commands=[]
for name,args in [('safe',[]),('all',['--all-features']),('no-default',['--no-default-features']),('no-default-all-unsafe',['--no-default-features','--features',','.join(FEATURES)])]:
 commands.append((name,['cargo','test','--locked','--test','upstream_negative_level',*args],2))
for name,args in [('clippy-safe',[]),('clippy-all',['--all-features'])]:
 commands.append((name,['cargo','clippy','--locked','--test','upstream_negative_level',*args,'--','-D','warnings'],None))
commands.append(('format',['rustfmt','--check','--edition','2024','tests/upstream_negative_level.rs'],None))
result={'source_before':initial,'environment':{'CARGO_TARGET_DIR':ENV['CARGO_TARGET_DIR']},'commands':records,'status':'running'}
(OUT/'evidence.json').write_text(json.dumps(result,indent=2)+'\n')
for name,argv,count in commands:
 before=manifest();start=time.monotonic();log=OUT/(name+'.log')
 with log.open('wb') as handle:
  process=subprocess.run(argv,cwd=ROOT,env=ENV,stdout=handle,stderr=subprocess.STDOUT,timeout=600)
 after=manifest();text=log.read_text();record={'name':name,'argv':argv,'exit_code':process.returncode,'seconds':time.monotonic()-start,'log':str(log),'sha256':sha(log),'source_before':before,'source_after':after}
 if count is not None:
  record['required_summary']=f'test result: ok. {count} passed; 0 failed; 0 ignored;'
  record['summary_present']=record['required_summary'] in text
 records.append(record)
 result['status']='running';(OUT/'evidence.json').write_text(json.dumps(result,indent=2)+'\n')
 print(name,process.returncode,record.get('summary_present','lint'),flush=True)
 if process.returncode or before!=initial or after!=initial or (count is not None and not record['summary_present']):
  result['status']='failed';(OUT/'evidence.json').write_text(json.dumps(result,indent=2)+'\n');raise SystemExit(1)
result['source_after']=manifest();result['status']='passed';result['test_executions']=8
(OUT/'evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print('evidence',sha(OUT/'evidence.json'),flush=True)
