/* External structural-query oracle pinned to facebook/zstd v1.5.7. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void check(size_t result) { if (ZSTD_isError(result)) { fprintf(stderr,"%s\n",ZSTD_getErrorName(result));exit(10); } }
static void save(const char *root,const char *name,const void *data,size_t size) { char path[4096];FILE *f;snprintf(path,sizeof(path),"%s/%s",root,name);f=fopen(path,"wb");if (!f || fwrite(data,1,size,f)!=size || fclose(f)) exit(11); }
static unsigned char *load(const char *path,size_t *size) { FILE *f=fopen(path,"rb");long n;unsigned char *p;if(!f || fseek(f,0,SEEK_END) || (n=ftell(f))<0 || fseek(f,0,SEEK_SET))exit(12);*size=(size_t)n;p=malloc(*size?*size:1);if(!p || fread(p,1,*size,f)!=*size || fclose(f))exit(13);return p; }
static void generate(const char *root) {
    const char example[]="abcd";const char input[]="a";const size_t count=(1U<<15)+1;const size_t capacity=1U<<18;
    char *encoded=malloc(capacity),*source=malloc(count*sizeof(input));size_t size,i,bound;ZSTD_CCtx *ctx=ZSTD_createCCtx();ZSTD_outBuffer out={encoded,capacity,0};ZSTD_inBuffer in={NULL,0,0};
    if(!encoded || !source || !ctx)exit(14);
    size=ZSTD_compress(encoded,capacity,example,sizeof(example),0);check(size);
    if(ZSTD_decompressBound(encoded,size)!=sizeof(example))exit(15);
    save(root,"original-known.zst",encoded,size);save(root,"original-known.raw",example,sizeof(example));
    check(ZSTD_initCStream(ctx,0));check(ZSTD_compressStream(ctx,&out,&in));if(ZSTD_endStream(ctx,&out)!=0)exit(16);
    if(ZSTD_decompressBound(encoded,out.pos)!=ZSTD_BLOCKSIZE_MAX)exit(17);
    save(root,"original-empty-unknown.zst",encoded,out.pos);save(root,"original-empty-unknown.raw",source,0);
    check(ZSTD_initCStream(ctx,0));out.pos=0;
    for(i=0;i<count;++i) {
        ZSTD_inBuffer block={input,sizeof(input),0};check(ZSTD_compressStream(ctx,&out,&block));
        if(block.pos!=sizeof(input) || ZSTD_flushStream(ctx,&out)!=0)exit(18);
        memcpy(source+i*sizeof(input),input,sizeof(input));
    }
    if(ZSTD_endStream(ctx,&out)!=0)exit(19);
    bound=(size_t)ZSTD_decompressBound(encoded,out.pos);
    if(ZSTD_decompressBound(encoded,out.pos)<=0x100000000ULL)exit(20);
    save(root,"original-4g-bound.zst",encoded,out.pos);save(root,"original-4g-bound.raw",source,count*sizeof(input));
    printf("original-known\t%zu\noriginal-empty-unknown\t%u\noriginal-4g-bound\t%zu\n",sizeof(example),ZSTD_BLOCKSIZE_MAX,bound);
    ZSTD_freeCCtx(ctx);free(encoded);free(source);
}
int main(int argc,char **argv) {
    if(argc!=3 || ZSTD_versionNumber()!=10507)return 2;
    if(!strcmp(argv[1],"generate")){generate(argv[2]);return 0;}
    if(!strcmp(argv[1],"scan")) {
        FILE *f=fopen(argv[2],"r");char name[128],path[4096];int fields;if(!f)return 3;
        while((fields=fscanf(f,"%127s %4095s",name,path))==2) {
            size_t n,first,skip=0;unsigned variant=0;unsigned char *data=load(path,&n),*output=malloc(n?n:1);unsigned long long exact,bound;unsigned marker;
            if(!output)return 4;
            first=ZSTD_findFrameCompressedSize(data,n);exact=ZSTD_findDecompressedSize(data,n);bound=ZSTD_decompressBound(data,n);marker=ZSTD_isSkippableFrame(data,n);
            if(marker)skip=ZSTD_readSkippableFrame(output,n,&variant,data,n);
            printf("%s\t%s\t%zu\t%s\t%llu\t%s\t%llu\t%u\t%s\t%zu\t%u\n",name,ZSTD_isError(first)?"error":"ok",ZSTD_isError(first)?0:first,exact==ZSTD_CONTENTSIZE_ERROR?"error":exact==ZSTD_CONTENTSIZE_UNKNOWN?"unknown":"known",exact>=ZSTD_CONTENTSIZE_ERROR?0:exact,bound==ZSTD_CONTENTSIZE_ERROR?"error":"ok",bound==ZSTD_CONTENTSIZE_ERROR?0:bound,marker,!marker?"not-skip":ZSTD_isError(skip)?"error":"ok",!marker||ZSTD_isError(skip)?0:skip,variant);
            if(marker && !ZSTD_isError(skip) && (skip>n-8 || memcmp(output,data+8,skip)))return 5;
            free(data);free(output);
        }
        if(fields!=EOF || ferror(f) || fclose(f))return 6;
        return 0;
    }
    return 7;
}
