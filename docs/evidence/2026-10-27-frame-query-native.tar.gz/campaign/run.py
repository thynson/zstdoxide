from pathlib import Path
import subprocess,json,hashlib,time,os
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert json.loads((D/'build.json').read_text())['status']=='passed';cases=json.loads((D/'cases.json').read_text());e=dict(status='running',case_receipt_sha256=sha(D/'cases.json'),build_receipt_sha256=sha(D/'build.json'),commands=[])
def save():(D/'native.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name in ['normal','sanitized']:
  args=[str(D/('oracle-'+name)),'scan',str(D/'manifest.txt')];t=time.monotonic();p=subprocess.run(args,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'});(D/(name+'-queries.tsv')).write_bytes(p.stdout);(D/(name+'-queries.stderr')).write_bytes(p.stderr);e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(D/(name+'-queries.tsv')),stderr_sha256=sha(D/(name+'-queries.stderr'))));save();assert p.returncode==0,(name,p.stderr);assert len(p.stdout.decode().splitlines())==len(cases['cases'])
 assert (D/'normal-queries.tsv').read_bytes()==(D/'sanitized-queries.tsv').read_bytes();e.update(status='passed',qualification='All native structural query rows agree between normal and ASan/UBSan v1.5.7. Numeric error/unknown identities are separate; Rust differences still require review.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
