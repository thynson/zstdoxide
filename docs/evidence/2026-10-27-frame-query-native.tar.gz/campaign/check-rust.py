from pathlib import Path
import json,hashlib,subprocess,time,os
D=Path(__file__).parent;S=D/'rust-capture';C=Path('/private/tmp/module30-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native=json.loads((D/'native.json').read_text());assert native['status']=='passed';cases=json.loads((D/'cases.json').read_text())['cases'];e=dict(status='running',source={str(p.relative_to(C)):sha(p) for p in (C/'src').rglob('*.rs')},native_receipt_sha256=sha(D/'native.json'),commands=[])
def save():(D/'rust.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [('safe',[]),('cursor',['--features','unsafe-byte-cursor']),('all',['--all-features'])]:
  args=['cargo','run','--offline','--locked',*flags,'--',str(D/'manifest.txt')];t=time.monotonic();p=subprocess.run(args,cwd=S,capture_output=True,env={**os.environ,'CARGO_TARGET_DIR':str(D/'rust-target'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_DEV_OPT_LEVEL':'1'});(D/(name+'-rust.tsv')).write_bytes(p.stdout);(D/(name+'-rust.stderr')).write_bytes(p.stderr);e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t));save();assert p.returncode==0,(name,p.stderr.decode()[-3000:]);assert len(p.stdout.decode().splitlines())==len(cases)
 assert (D/'safe-rust.tsv').read_bytes()==(D/'cursor-rust.tsv').read_bytes()==(D/'all-rust.tsv').read_bytes()
 native_rows=(D/'normal-queries.tsv').read_text().splitlines();rust_rows=(D/'safe-rust.tsv').read_text().splitlines();differences=[]
 for c,a,b in zip(cases,native_rows,rust_rows):
  x=a.split('\t');y=b.split('\t');assert x[0]==y[0]==c['name'];assert len(x)==len(y)==11
  if x!=y:differences.append(dict(case=c,native=x[1:],rust=y[1:]))
 for n,h in e['source'].items():assert sha(C/n)==h,n
 e.update(status='captured',differences=differences,compared=len(cases),qualification='All safe/cursor/all query rows agree; three original decompression-bound constructions additionally decode to exact native source bytes. Native differences are retained for explicit classification before qualification.');save();print('captured',len(cases),'cases;',len(differences),'native differences')
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
