from pathlib import Path
import shutil,json,hashlib
D=Path(__file__).parent;I=D/'inputs';I.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cases=[];assert json.loads((D/'originals.json').read_text())['status']=='passed'
def add(name,data,origin):
 p=I/(name+'.bin');assert not p.exists();p.write_bytes(data);cases.append(dict(name=name,bytes=len(data),sha256=sha(p),origin=origin))
old=Path('/private/tmp/module28-margin');j=json.loads((old/'cases.json').read_text())
for row in j['cases']:
 p=Path(row['path']);assert sha(p)==row['sha256'];add('margin-'+row['name'],p.read_bytes(),dict(campaign='module28-margin',receipt_sha256=sha(old/'cases.json'),original_name=row['name'],original_provenance=row.get('origin')))
for p in (D/'normal-originals').glob('*.zst'):add(p.stem,p.read_bytes(),dict(campaign='pinned-test_decompressBound',receipt_sha256=sha(D/'originals.json')))
def known(n):return b'\x28\xb5\x2f\xfd\xe0'+n.to_bytes(8,'little')+b'\x01\x00\x00'
unknown=b'\x28\xb5\x2f\xfd\x00\x38\x01\x00\x00'
for size in [0,1,2,3,(1<<32)-1,1<<32,(1<<63),(1<<64)-3,(1<<64)-2,(1<<64)-1]:
 add('known-'+str(size),known(size),'supplemental full-u64 advertised size')
 for second in [0,1,3]:add(f'sum-{size}-{second}',known(size)+known(second),'supplemental aggregate checked versus native wrapping arithmetic')
 add('unknown-before-'+str(size),unknown+known(size),'supplemental unknown-size full traversal')
 add('known-before-unknown-'+str(size),known(size)+unknown,'supplemental unknown-size full traversal')
for name,tail in [('junk',b'x'),('partial-header',b'\x28\xb5\x2f\xfd'),('short-skip',b'\x50\x2a\x4d\x18\x01\x00\x00\x00'),('reserved-block',b'\x28\xb5\x2f\xfd\x20\x00\x07\x00\x00')]:add('unknown-tail-'+name,unknown+tail,'supplemental native early unknown versus full structural validation')
(D/'manifest.txt').write_text(''.join(f"{r['name']} {I/(r['name']+'.bin')}\n" for r in cases));(D/'cases.json').write_text(json.dumps(dict(status='prepared',cases=cases,qualification='Existing hash-bound structural margin corpus plus standalone original decompression-bound constructions and explicitly labelled u64/unknown-tail supplements. No original multi-frame fuzzer setup is inferred.'),indent=2)+'\n');print(len(cases),'query inputs')
