from pathlib import Path
import json,time,subprocess
D=Path(__file__).parent
while True:
 p=D/'build.json'
 if p.exists():
  try:j=json.loads(p.read_text())
  except json.JSONDecodeError:time.sleep(1);continue
  assert j['status']!='failed',j.get('error')
  if j['status']=='passed':break
 time.sleep(5)
for name in ['generate.py','prepare-cases.py','run.py']:subprocess.run(['python3',str(D/name)],check=True)
