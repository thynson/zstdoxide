from pathlib import Path
import json,hashlib,collections,shutil
D=Path(__file__).parent;MAX=(1<<64)-1;j=json.loads((D/'rust.json').read_text());assert j['status']=='captured';assert len(j['differences'])==550;classified=[]
def parse_synthetic(data):
 frames=[]
 while data:
  assert data[:4]==b'\x28\xb5\x2f\xfd'
  if data[4]==0xe0:frames.append(int.from_bytes(data[5:13],'little'));assert data[13:16]==b'\x01\x00\x00';data=data[16:]
  else:assert data[:9]==b'\x28\xb5\x2f\xfd\x00\x38\x01\x00\x00';frames.append(None);data=data[9:]
 return frames
def exact_native(frames):
 total=0
 for size in frames:
  if size is None or size==MAX:return ['unknown','0']
  if size==MAX-1 or total+size>MAX:return ['error','0']
  total+=size
 return ['error','0'] if total==MAX-1 else ['unknown','0'] if total==MAX else ['known',str(total)]
def bound_native(frames):
 total=0
 for size in frames:
  if size==MAX-1:return ['error','0']
  total=(total+(131072 if size is None or size==MAX else size))&MAX
 return ['error','0'] if total==MAX-1 else ['ok',str(total)]
for d in j['differences']:
 a=d['native'];b=d['rust'];data=(D/'inputs'/(d['case']['name']+'.bin')).read_bytes();assert a[6:]==b[6:]
 if a[2:4]==['unknown','0'] and b[2:4]==['error','0'] and a[:2]==b[:2] and a[4:6]==b[4:6]==['error','0']:
  category='full-validation-after-unknown';reason='Native content-size discovery returns unknown after a complete unknown-size header or frame; Rust continues structural scanning and rejects its incomplete body or malformed trailing input.'
  assert data[:4]==b'\x28\xb5\x2f\xfd' and data[4]>>6==0 and data[4]&32==0
 elif a[:6]==['error','0','error','0','error','0'] and b[0]=='ok':
  category='structural-window-cap';reason='The existing Rust header contract accepts the explicit structurally encoded window above native WINDOWLOG_MAX; actual decoding remains subject to caller resource limits.'
  assert data[:4]==b'\x28\xb5\x2f\xfd' and data[4]&32==0 and data[5]==255
 else:
  category='numeric-sentinel-or-checked-overflow';reason='Rust preserves all u64 advertised values and rejects aggregate overflow; native reserves the top two values and wraps decompression-bound addition.'
  frames=parse_synthetic(data);assert a[2:4]==exact_native(frames),(d['case']['name'],a,frames);assert a[4:6]==bound_native(frames),(d['case']['name'],a,frames)
  known=sum(x for x in frames if x is not None);bound=sum(131072 if x is None else x for x in frames)
  expected_exact=['error','0'] if known>MAX else ['unknown','0'] if None in frames else ['known',str(known)];expected_bound=['error','0'] if bound>MAX else ['ok',str(bound)];assert b[2:4]==expected_exact and b[4:6]==expected_bound,(d['case']['name'],b,frames)
 classified.append(dict(name=d['case']['name'],category=category,reason=reason))
counts=dict(collections.Counter(x['category'] for x in classified));assert counts=={'structural-window-cap':17,'full-validation-after-unknown':519,'numeric-sentinel-or-checked-overflow':14},counts
shutil.copyfile(D/'rust.json',D/'rust-before-review.json');(D/'differences.json').write_text(json.dumps(dict(status='reviewed',counts=counts,cases=classified,qualification='Each difference is checked against its actual encoded cause and independently observed native output; generated numeric examples additionally assert exact non-wrapping u64 arithmetic and native sentinel/wrapping interpretations. No unexplained query difference remains.'),indent=2)+'\n');j.update(status='passed',difference_counts=counts,difference_review_sha256=hashlib.sha256((D/'differences.json').read_bytes()).hexdigest(),qualification='10818 actual query inputs agree across safe/cursor/all Rust. Normal/sanitized native agree; 550 explicitly classified differences are 519 full validation after unknown, 17 native window caps and 14 numeric sentinel/checked-overflow cases. Remaining10268 complete query rows match native. Three original bound constructions decode to exact source bytes. No native early-return/sentinel/wrapping behavior is silently claimed identical.');(D/'rust.json').write_text(json.dumps(j,indent=2)+'\n');print(counts)
