from pathlib import Path
import subprocess,json,hashlib,os,time
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();build=json.loads((D/'build.json').read_text());assert build['status']=='passed';e=dict(status='running',build_sha256=sha(D/'build.json'),commands=[])
def save():(D/'originals.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for mode in ['normal','sanitized']:
  out=D/(mode+'-originals');out.mkdir();args=[str(D/('oracle-'+mode)),'generate',str(out)];t=time.monotonic();p=subprocess.run(args,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'});(D/(mode+'-originals.tsv')).write_bytes(p.stdout);(D/(mode+'-originals.stderr')).write_bytes(p.stderr);e['commands'].append(dict(label=mode,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t));save();assert p.returncode==0,(mode,p.stderr)
 for p in (D/'normal-originals').iterdir():assert sha(p)==sha(D/'sanitized-originals'/p.name),p.name
 assert (D/'normal-originals.tsv').read_bytes()==(D/'sanitized-originals.tsv').read_bytes();e.update(status='passed',files={p.name:sha(p) for p in (D/'normal-originals').iterdir()},qualification='Original v1.5.7 test_decompressBound constructions: five-byte abcd including NUL; initial empty streaming frame without advertised size; 32769 flushes of two-byte a including NUL plus endStream. Native assertions reproduce known size, one maximum block, and >4GiB bound. Normal/sanitized fixture bytes and assertions agree. No original concatenated fuzzer history is claimed by these standalone function cases.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
