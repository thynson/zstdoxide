from pathlib import Path
import difflib,json,hashlib
D=Path(__file__).parent;R=Path('/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99');p=R/'tests/fuzzer.c';old=p.read_text();s=old
# Observe state in place; preserve all original setup, mutations and assertions.
def capture(name,size,extra=''):
 return '''    {
        const char *root=getenv("ZSTDOXIDE_QUERY_CAPTURE_DIR");
        char path[4096];FILE *file;
        if(!root)exit(96);
        snprintf(path,sizeof(path),"%s/NAME.zst",root);file=fopen(path,"wb");
        if(!file || fwrite(compressedBuffer,1,cSize,file)!=cSize || fclose(file))exit(97);
        snprintf(path,sizeof(path),"%s/NAME.raw",root);file=fopen(path,"wb");
        if(!file || fwrite(CNBuffer,1,SIZE,file)!=SIZE || fclose(file))exit(98);
        fprintf(stderr,"query capture NAME encoded=%zu source=%zu\\n",cSize,(size_t)(SIZE));
        EXTRA
    }
'''.replace('NAME',name).replace('SIZE',size).replace('EXTRA',extra)
needle='    DISPLAYLEVEL(3, "test%3i : ZSTD_findDecompressedSize test : ", testNb++);';assert s.count(needle)==1;s=s.replace(needle,capture('single-original','CNBuffSize')+needle)
needle='        if (CNBuffSize > bound) goto _output_error;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n'+capture('unknown-original','CNBuffSize','fprintf(stderr,"original full-capacity unknown query input=%zu actual-frame=%zu bound=%llu error-sentinel=%d\\n",compressedBufferSize,cSize,bound,bound==ZSTD_CONTENTSIZE_ERROR);'))
needle='    DISPLAYLEVEL(3, "test%3i : get decompressed size of multiple frames : ", testNb++);';assert s.count(needle)==1;s=s.replace(needle,capture('multiple-original','CNBuffSize / 2')+needle)
needle='    DISPLAYLEVEL(3, "test%3i : decompress multiple frames : ", testNb++);';assert s.count(needle)==1;s=s.replace(needle,'    /* Original query assertions above have executed; stop this observation run. */\n    exit(0);\n'+needle)
(D/'fuzzer-capture.c').write_text(s);(D/'capture.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='tests/fuzzer.c',tofile='tests/fuzzer.c')));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(D/'preparation.json').write_text(json.dumps(dict(status='prepared',reference_revision='f8745da6ff1ad1e7bab384bd1f9d742439278e99',original_fuzzer_sha256=sha(p),instrumented_fuzzer_sha256=sha(D/'fuzzer-capture.c'),patch_sha256=sha(D/'capture.patch'),qualification='Read-only observation blocks capture actual original single/unknown/multiframe state; every preceding original statement and query assertion remains intact. Exit follows the original concatenated tight bound assertion. The unknown original query used compressedBufferSize rather than cSize; its numeric return/error-sentinel interpretation is logged explicitly, not silently rewritten.'),indent=2)+'\n')
s=Path('/private/tmp/module28-native-exact/capture.py').read_text();s=s.replace("run(name+'-capture',[str(D/('capture-'+name)),'-s0','-P50','-i0'],{**os.environ,'ZSTDOXIDE_CAPTURE_CNBUFFER':str(D/(name+'-cn-buffer.bin'))", "out=D/(name+'-fixtures');out.mkdir()\n  run(name+'-capture',[str(D/('capture-'+name)),'-s0','-P50','-i0'],{**os.environ,'ZSTDOXIDE_QUERY_CAPTURE_DIR':str(out)")
s=s.replace("  assert (D/(name+'-cn-buffer.bin')).stat().st_size==5*1024*1024", "  assert (out/'single-original.raw').stat().st_size==5*1024*1024\n  assert (out/'unknown-original.raw').stat().st_size==5*1024*1024\n  assert (out/'multiple-original.raw').stat().st_size==5*1024*1024//2")
start=s.index(" assert sha(D/'normal-cn-buffer.bin')");end=s.index('\nexcept BaseException',start)
s=s[:start]+''' for p in (D/'normal-fixtures').iterdir():assert sha(p)==sha(D/'sanitized-fixtures'/p.name),p.name
 e.update(status='passed',fixtures={p.name:sha(p) for p in (D/'normal-fixtures').iterdir()},qualification='Both full upstream basic-test executions use seed0/compressibility0.5 and preserve all history through the original multiple-frame size/bound assertions. Captured single, missing-size and four-frame/129KiB-skippable streams and expected original bytes agree. The original missing-size group queries full allocation capacity, and its logged error sentinel must not be confused with a useful successful bound.');save()
''' +s[end:];(D/'capture.py').write_text(s)
