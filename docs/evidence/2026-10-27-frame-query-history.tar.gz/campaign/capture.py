from pathlib import Path
import hashlib,json,subprocess,os,time
D=Path(__file__).parent;R=Path('/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[p for sub in ['common','compress','decompress','dictBuilder','legacy'] for p in sorted((R/'lib'/sub).glob('*.c'))]+[R/'programs'/n for n in ['datagen.c','util.c','timefn.c']]
e=dict(status='running',preparation=json.loads((D/'preparation.json').read_text()),library={str(p.relative_to(R)):sha(p) for p in (R/'lib').rglob('*') if p.is_file() and p.suffix in ['.c','.h','.S']},commands=[])
def save():(D/'capture.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,env=None):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log'))));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
save()
try:
 for name,flags in [('normal',['-O2']),('sanitized',['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'])]:
  args=['cc','-std=c99','-DZSTD_MULTITHREAD','-DZSTD_WINDOW_OVERFLOW_CORRECT_FREQUENTLY=1','-Wno-deprecated-declarations','-pthread',*[f'-I{R/"lib"/sub}' for sub in ['', 'common','compress','decompress','dictBuilder','deprecated','legacy']],'-I'+str(R/'programs'),*flags,str(D/'fuzzer-capture.c'),*[str(p) for p in sources],'-o',str(D/('capture-'+name))]
  run(name+'-build',args)
  out=D/(name+'-fixtures');out.mkdir()
  run(name+'-capture',[str(D/('capture-'+name)),'-s0','-P50','-i0'],{**os.environ,'ZSTDOXIDE_QUERY_CAPTURE_DIR':str(out),'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
  assert (out/'single-original.raw').stat().st_size==5*1024*1024
  assert (out/'unknown-original.raw').stat().st_size==5*1024*1024
  assert (out/'multiple-original.raw').stat().st_size==5*1024*1024//2
 for p in (D/'normal-fixtures').iterdir():assert sha(p)==sha(D/'sanitized-fixtures'/p.name),p.name
 e.update(status='passed',fixtures={p.name:sha(p) for p in (D/'normal-fixtures').iterdir()},qualification='Both full upstream basic-test executions use seed0/compressibility0.5 and preserve all history through the original multiple-frame size/bound assertions. Captured single, missing-size and four-frame/129KiB-skippable streams and expected original bytes agree. The original missing-size group queries full allocation capacity, and its logged error sentinel must not be confused with a useful successful bound.');save()

except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
