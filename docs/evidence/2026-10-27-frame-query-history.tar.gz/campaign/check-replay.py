from pathlib import Path
import subprocess,hashlib,json,time,os
D=Path(__file__).parent;S=D/'replay-source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**os.environ,'CARGO_TARGET_DIR':str(D/'replay-target'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0','ZSTDOXIDE_FRAME_QUERY_HISTORY':str(D)}
e=dict(status='running',source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()},native_receipt_sha256=sha(D/'capture.json'),reference_audit_sha256=sha(D/'reference-source-audit.json'),commands=[])
def save():(D/'replay.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [('safe',[]),('cursor',['--features','unsafe-byte-cursor']),('all',['--all-features'])]:
  args=['cargo','test','--offline','--locked','--test','frame_queries_history',*flags,'--','--ignored','--nocapture'];t=time.monotonic()
  with (D/(name+'-replay.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(name+'-replay.log'))));save();assert p.returncode==0,name
  assert '1 passed; 0 failed; 0 ignored' in (D/(name+'-replay.log')).read_text()
 for n,h in e['source'].items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='The final original-history adapter explicitly runs in safe/cursor/all. It uses captured original single and four-frame/skippable bytes and source histories, original known total/tight bound/truncated-size assertions, and full decoded-byte comparison. The captured unknown-size cSize bound is a separately labelled useful-length supplement; the actual upstream full-capacity call returned the reserved error sentinel and remains a documented partial mapping.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
