"""Archive the qualified module35 internal coordinator (core) campaign."""
from pathlib import Path
import json, hashlib, tarfile, re, datetime

D = Path(__file__).parent
C = Path('/private/tmp/module35-core')
S = C / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
j = json.loads((C / 'evidence.json').read_text())
assert j['status'] == 'passed' and len(j['commands']) == 17
for n, h in j['source'].items():
    assert sha(S / n) == h, n
for r in j['commands']:
    assert r['exit_code'] == 0 and sha(C / (r['label'] + '.log')) == r['log_sha256']
    suffix = r['label'].rsplit('-', 1)[-1]
    if suffix in ('unit', 'selection'):
        g = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (C / (r['label'] + '.log')).read_text())
        assert sum(int(a) for a, _, _ in g) == 4 and all(b == c == '0' for _, b, c in g), r['label']
files = {}
for p in C.rglob('*'):
    if not p.is_file():
        continue
    n = p.relative_to(C)
    if any(x == 'target' or x.endswith('-target') or x == '__pycache__' for x in n.parts):
        continue
    if p.suffix in {'.rs', '.toml', '.lock', '.json', '.py', '.log', '.md', '.tsv'}:
        files[str(n)] = p
files['archive-engine.py'] = Path(__file__)
name = '2026-10-28-one-shot-encode-engine'
archive = D / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
r = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source=j['source'], production_source={n: h for n, h in j['source'].items() if n.startswith('src/')}, commands=j['commands'], members={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()}, archive=archive.name, archive_sha256=sha(archive), qualification='Focused internal call-scoped selection coordinator only. The private coordinator reuses the existing plain selection records and borrowed dictionary-view frame emission without cloning handles or retaining workspace. No public coordinator API, native/platform qualification, full feature matrix, timing or major-module closure is claimed here. Selection/Claimed remain plain ownership records with one safe representation; performance-sensitive structures retain their existing independent unsafe features.')
(D / (name + '.json')).write_text(json.dumps(r, indent=2) + '\n')
print(name, archive.stat().st_size)
