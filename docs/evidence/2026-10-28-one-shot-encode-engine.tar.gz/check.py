from pathlib import Path
import os,subprocess,json,hashlib,time,datetime,tomllib,re,signal
D=Path(__file__).parent;S=D/'source';R=Path('/Users/lanxingcan/Workspace/zstdoxize');T=Path('/private/tmp');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,28,9,38,0,tzinfo=datetime.timezone.utc).timestamp()
prior=R/'docs/evidence/2026-10-27-dictionary-slice-encode-closure.json';j=json.loads(prior.read_text());assert j['status']=='passed';assert sha(prior.parent/j['archive'])==j['archive_sha256'];assert json.loads((T/'module35-design/applied.json').read_text())['status']=='passed'
pre=json.loads((D/'preimplementation.json').read_text());assert pre['base_source']==j['production_source']
for n,h in json.loads((D/'preparation.json').read_text())['source'].items():assert sha(S/n)==h,n
source={str(p.relative_to(S)):sha(p) for folder in ['src','tests','test-support'] for p in (S/folder).rglob('*') if p.is_file()};source.update({n:sha(S/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']});features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'));assert len(features)==22
plan=[]
for name,flags,no in [('safe',[],[]),('sink',['--features','unsafe-frame-sink'],['--features','unsafe-frame-sink']),('dictionary',['--features','unsafe-dictionary'],['--features','unsafe-dictionary']),('all',['--all-features'],['--features',','.join(features)])]:
 plan += [(name+'-unit',['cargo','test','--offline','--locked','--lib','one_shot_encode::tests',*flags]),(name+'-selection',['cargo','test','--offline','--locked','--lib','one_shot_selection::tests',*flags]),(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*no]),(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])]
plan += [('format',['cargo','fmt','--all','--','--check'])];assert len(plan)==17;assert not (D/'evidence.json').exists();e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=source,predecessor_closure_sha256=sha(prior),plan=plan,commands=[])
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module35-core-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for label,args in plan:
  remaining=deadline-time.time()-30
  if remaining<30:raise TimeoutError('Work window reached before '+label)
  e['active_command']=label;save();start=time.monotonic()
  with (D/(label+'.log')).open('xb') as f:
   p=subprocess.Popen(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=remaining)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise TimeoutError('Work window reached during '+label)
  row=dict(label=label,argv=args,exit_code=code,seconds=time.monotonic()-start,log_sha256=sha(D/(label+'.log')))
  if code==0 and label.endswith(('-unit','-selection')):
   groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (D/(label+'.log')).read_text());assert len(groups)==1 and groups[0]==('4','0','0'),(label,groups);row.update(passed=4,failed=0,ignored=0)
  e['commands'].append(row);e.pop('active_command',None);save();print(label,code,flush=True);assert code==0,label
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except TimeoutError as ex:e.update(status='interrupted-at-user-deadline',error=repr(ex));save();raise
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
