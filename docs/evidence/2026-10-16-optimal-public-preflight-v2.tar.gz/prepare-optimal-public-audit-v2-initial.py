from pathlib import Path
import sys,hashlib,json
sys.path.insert(0,'scripts')
import capture_optimal_interop as capture
checker,generator,protocol,manifest=capture.inputs();R=Path.cwd()
paths=set(R/n for n in capture.PINS);paths.update((R/'src').rglob('*.rs'));paths.update(p for p in (R/'test-support').rglob('*')if p.suffix in ('.rs','.toml'));paths.update((R/'scripts/oracles').glob('*.py'));paths.update(R/n for n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/upstream/manifest.json','scripts/capture_optimal_interop.py','scripts/check_reference_fast_interop.py','scripts/import_reference_fast_fuzz.py'));paths.update(R/n for n in generator.PINS);paths.add(checker.MANIFEST)
names=sorted(str(p.relative_to(R))for p in paths);digest=hashlib.sha256(json.dumps(names,sort_keys=True,separators=(',',':')).encode()).hexdigest()
previous=[n for n in names if n not in ('src/optimal_plan.rs','src/optimal_state.rs')]
assert hashlib.sha256(json.dumps(previous,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='7fb4e4bb665a3059058ec60e7852e5e1585da2a41dfb981f6ecaf87f89a0f947'
p=R/'scripts/check_optimal_interop_capture.py';s=p.read_text().replace('7fb4e4bb665a3059058ec60e7852e5e1585da2a41dfb981f6ecaf87f89a0f947',digest).replace('Independently replay bounded public-frame responses','Version 2: admit the completed plan/state source inventory and replay bounded public-frame responses');(R/'scripts/check_optimal_interop_capture_v2.py').write_text(s)
p=R/'scripts/check_optimal_interop_plan.py';s=p.read_text().replace('import check_optimal_interop_capture as audit','import check_optimal_interop_capture_v2 as audit')
at=s.index('    cases=generator.recipes()');s=s[:at]+f'''    paths=set(checker.ROOT/n for n in capture.PINS)
    paths.update((checker.ROOT/'src').rglob('*.rs'))
    paths.update(p for p in (checker.ROOT/'test-support').rglob('*') if p.suffix in ('.rs','.toml'))
    paths.update((checker.ROOT/'scripts/oracles').glob('*.py'))
    paths.update(checker.ROOT/n for n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/upstream/manifest.json','scripts/capture_optimal_interop.py','scripts/check_reference_fast_interop.py','scripts/import_reference_fast_fuzz.py'))
    paths.update(checker.ROOT/n for n in generator.PINS);paths.add(checker.MANIFEST)
    names=sorted(str(p.relative_to(checker.ROOT)) for p in paths)
    def closure(values):
        checker.require(hashlib.sha256(json.dumps(values,sort_keys=True,separators=(',',':')).encode()).hexdigest()=={digest!r},'complete implemented source inventory')
    closure(names)
''' +s[at:]
s=s.replace("    checker.require(not children and len(rejected)==8,'complete offline controls')", "    for bad in [names[:-1], names+[names[-1]], [n for n in names if n!='src/optimal_plan.rs']]:\n        reject('source-closure',lambda value=bad:closure(value))\n    checker.require(not children and len(rejected)==11,'complete offline controls')")
s=s.replace("status='passed',plan=expected,",f"status='passed',source_closure_sha256={digest!r},source_paths=names,plan=expected,")
(R/'scripts/check_optimal_interop_plan_v2.py').write_text(s)
(R/'docs/reference-optimal-interop-audit-v2.md').write_text(f'''# Optimal public interoperability audit successor

The original command preflight preceded the private plan/state implementation.
The completed source inventory adds exactly `src/optimal_plan.rs` and
`src/optimal_state.rs`. The unchanged controller already snapshots all Rust
modules dynamically. Before its first native execution, the additive v2 auditor
updates only the exact source-name closure digest to `{digest}`.
The original auditor/preflight, native adapter, transport, request hypotheses,
command counts and response/environment checks are preserved byte-for-byte.

The v2 preflight independently reconstructs the complete {len(names)}-path
inventory, proves its predecessor differs by exactly those two planned modules,
and rejects missing, repeated or incomplete source-name inventories. It retains
all existing pin, strict-JSON and command-order controls. This is a source
inventory correction before native execution, not a changed execution protocol.
''')
print(len(names),digest)
