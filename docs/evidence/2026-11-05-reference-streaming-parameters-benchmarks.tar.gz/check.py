from pathlib import Path
import json,hashlib,os,subprocess,datetime,time,statistics,math
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e={'status':'waiting-for-matrix','source':{str(p.relative_to(S)):sha(p) for p in (S/'src').glob('*.rs')},'harness_sha256':sha(D/'lifecycle_bench.rs'),'commands':[],'builds':{}}
for mode in ['safe','all']:
 rows=[json.loads(l) for l in (D/(mode+'-build.log')).read_text().splitlines() if l.startswith('{')]
 assert any(r.get('reason')=='build-finished' and r['success'] for r in rows)
 binary=Path(next(r['executable'] for r in rows if r.get('executable') and r['target']['name']=='lifecycle_bench'))
 e['builds'][mode]={'binary':str(binary),'sha256':sha(binary),'log_sha256':sha(D/(mode+'-build.log'))}
assert '1 passed; 0 failed' in (D/'smoke.log').read_text()
assert 'Finished' in (D/'clippy.log').read_text() and 'error:' not in (D/'clippy.log').read_text()
e['qualification']='15360 lifecycle samples: 12 cases x two alternating request variants x four lifecycle modes, two rounds of forty samples per case, two repeats per backend. Warmed output equality and decode outside timers. Includes configure/reset+whole frame; fresh includes construction/drop. Optimized test profile opt-level3/debug0, test assertions enabled. No native speed claim.'
def save(): (D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 while True:
  matrix=json.loads(Path('/private/tmp/module41-matrix/evidence.json').read_text())
  if matrix['status']=='complete':break
  if matrix['status']=='failed':raise RuntimeError('Matrix failed; timing withheld')
  if datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime(2026,11,5,10,11,tzinfo=datetime.timezone.utc):raise TimeoutError('Timing start deadline reached')
  time.sleep(10)
 e['status']='running';e['started_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 common=None;medians={};total=0
 for name in ['safe-1','all-1','all-2','safe-2']:
  mode=name.split('-')[0];start=time.monotonic();cmd=[e['builds'][mode]['binary'],'--exact','lifecycle_measurements']
  with (D/(name+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=S,env={**os.environ,'ZSTDOXIDE_LIFECYCLE_BENCH':str(D/name)},stdout=f,stderr=subprocess.STDOUT,timeout=90)
  assert p.returncode==0
  e['commands'].append({'label':name,'argv':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(D/(name+'.log'))});save()
  ledger=(D/name/'ledger.tsv').read_bytes()
  if common is None:common=ledger
  assert ledger==common
  groups={}
  for l in (D/name/'samples.tsv').read_text().splitlines()[1:]:
   case,round_,sample,method,variant,ns,size,digest=l.split('\t');groups.setdefault(case+'|'+variant+'|'+method,[]).append(int(ns));total+=1
  assert len(groups)==96 and all(len(v)==40 for v in groups.values())
  medians[name]={k:statistics.median(v) for k,v in groups.items()}
  if name!='safe-1':
   for f in (D/name).glob('*.zst'):assert f.read_bytes()==(D/'safe-1'/f.name).read_bytes()
  print(name,flush=True)
 assert total==15360
 ratios={}
 for name,values in medians.items():
  ratios[name]={str(mode):math.exp(statistics.mean(math.log(v/values[k.rsplit('|',1)[0]+'|3']) for k,v in values.items() if k.endswith('|'+str(mode)))) for mode in range(3)}
 e['summary']={'samples':total,'medians_nanoseconds':medians,'reused_over_fresh_geometric_means':ratios,'ledger_sha256':hashlib.sha256(common).hexdigest()}
 e['outputs']={str(p.relative_to(D)):sha(p) for name in ['safe-1','all-1','all-2','safe-2'] for p in (D/name).iterdir() if p.is_file()}
 for n,h in e['source'].items():assert sha(S/n)==h
 e['status']='complete';e['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
except BaseException as ex:
 e['status']='failed';e['error']=repr(ex);save();raise
