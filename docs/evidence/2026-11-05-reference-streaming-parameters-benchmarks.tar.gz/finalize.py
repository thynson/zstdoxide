from pathlib import Path
import json,hashlib,tarfile,math,statistics,subprocess,os
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((D/'evidence.json').read_text());assert e['status']=='complete' and e['summary']['samples']==15360
matrix=json.loads(Path('/private/tmp/module41-matrix/evidence.json').read_text())
for n,h in matrix['source'].items():
 if n.startswith('src/') or n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:
  assert sha(D/'source'/n)==h and sha(R/n)==h
  e['source'][n]=h
for n,h in e['source'].items():assert sha(R/n)==h
for n,h in e['outputs'].items():assert sha(D/n)==h
for mode,v in e['builds'].items():assert sha(Path(v['binary']))==v['sha256'] and sha(D/(mode+'-build.log'))==v['log_sha256']
e['environment']={'system':os.uname().sysname,'machine':os.uname().machine,'rustc':subprocess.check_output(['rustc','-Vv'],cwd=R,text=True),'cpu_affinity_frequency_lock':'none','build_environment':{'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'3','CARGO_PROFILE_TEST_DEBUG':'0'}}
e['validation']={'smoke_log_sha256':sha(D/'smoke.log'),'clippy_log_sha256':sha(D/'clippy.log'),'smoke_excluded':True}
med=e['summary']['medians_nanoseconds'];ratios=e['summary']['reused_over_fresh_geometric_means'];all_safe={}
for repeat in ['1','2']:
 all_safe[repeat]={str(mode):math.exp(statistics.mean(math.log(value/med['safe-'+repeat][key]) for key,value in med['all-'+repeat].items() if key.endswith('|'+str(mode)))) for mode in range(4)}
e['summary']['all_over_safe_geometric_means']=all_safe
archive=R/'docs/evidence/2026-11-05-reference-streaming-parameters-benchmarks.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n in ['lifecycle_bench.rs','check.py','finalize.py','evidence.json','driver.log','safe-build.log','all-build.log','clippy.log','smoke.log']:t.add(D/n,arcname=n)
 for name in ['safe-1','all-1','all-2','safe-2']:
  t.add(D/name,arcname=name);t.add(D/(name+'.log'),arcname=name+'.log')
e['archive']={'path':str(archive.relative_to(R)),'sha256':sha(archive)}
(R/'docs/evidence/2026-11-05-reference-streaming-parameters-benchmarks.json').write_text(json.dumps(e,indent=2)+'\n')
names=['Session reset + replace','Parameter reset + session reset + replace','Reset all + replace','Fresh construction/drop']
lines=['# Reference-stream parameter lifecycle measurements','','This bounded campaign measures complete frame work under four lifecycle','operations using identical requests, source, options and caller buffers. It','does not measure native zstd or isolate the nanosecond cost of a setter.','','## Protocol','','Twelve cases combine six starting reference families and two repeated-text','sizes (65 and 4,200 bytes). Successive samples alternate between the starting','and next family, with requested window logs 17 and 16, hash/chain logs 14,','an exact pledge and checksum. The resolved window can shrink for these small','sources. Each mode sees the same alternating requests and source.','','Three warmed contexts use session reset, parameter-plus-session reset, or','reset-all followed by options/request replacement. The comparator constructs','and drops a fresh context each sample. Timers include those operations plus','whole-frame pumping into preallocated output, including fresh destruction.','Construction of reused contexts, warm decoding, output equality and digests','are outside timers. Every output equals the fresh warmed frame for that','request; all variants decode to the source. Safe/all and both repeats have','byte-identical frames and ledgers.','','Two rounds of forty samples rotate four-mode order after a 250 ms CPU barrier','per case/round. Runs execute safe/all/all/safe after the regression matrix:','15,360 samples total. Each case/variant/mode median contains forty samples.','The optimized test profile uses opt-level 3, debug 0, incremental disabled','and test assertions. Host is Darwin arm64 with pinned nightly-2026-10-08.','No CPU affinity/frequency lock or background host isolation was applied.','Qualification smoke timing is excluded.','','## Observations','','Ratios are geometric means over 24 case/variant ratios of medians. Greater','than one means the numerator took longer. These are point estimates, without','confidence bounds or universal performance implications.','','| Reused/fresh mode | Safe 1 | Safe 2 | All 1 | All 2 |','| --- | ---: | ---: | ---: | ---: |']
for mode in range(3):lines.append('| '+names[mode]+' | '+' | '.join(f'{ratios[k][str(mode)]:.4f}' for k in ['safe-1','safe-2','all-1','all-2'])+' |')
lines+=['','| All/safe mode | Repeat 1 | Repeat 2 |','| --- | ---: | ---: |']
for mode in range(4):lines.append(f'| {names[mode]} | {all_safe["1"][str(mode)]:.4f} | {all_safe["2"][str(mode)]:.4f} |')
lines+=['','These measurements include parser and frame work and allocator reuse. They','cannot attribute an aggregate difference to a particular reset method or an','unsafe operation. No claim extends to prefixes, large/unknown input, other','allocators/platforms, LDM, workers or unsupported strategies.','','The matching JSON receipt retains every median and source/build/output hash.','The archive contains the harness, controllers, build/validation logs, raw','samples, frames and ledgers. Module 41 full isolated-feature suites remain','a separate open qualification gate.','']
(R/'docs/reference-streaming-parameters-benchmarks.md').write_text('\n'.join(lines))
p=R/'TODO.md';p.write_text(p.read_text().replace('- [ ] Compare parameter replacement/reset workloads on identical safe/all','- [x] Compare parameter replacement/reset workloads on identical safe/all'))
p=R/'docs/reference-streaming-parameters-validation.md';s=p.read_text();a=s.index('## Remaining module gates');s=s[:a]+'''## Lifecycle timing

The separate comparison records 15,360 samples across four lifecycle modes,
alternating admitted requests, two text sizes and safe/all independent repeats.
All outputs and ledgers match the fresh warmed reference exactly. See
`reference-streaming-parameters-benchmarks.md` for the complete-frame timing
protocol, measured ratios and limits; no universal unsafe speedup is inferred.

'''+s[a:];s=s.replace('and deterministic independent-repeat lifecycle timing must be reconciled\nbefore Module 41 closes.','must be reconciled before Module 41 closes.');p.write_text(s)
print(json.dumps({'reused_over_fresh':ratios,'all_over_safe':all_safe},indent=2))
