//! External deterministic lifecycle comparison, not a native speed benchmark.
use std::{
    hint::black_box,
    time::{Duration, Instant},
};
use zstdoxide::{
    CompiledStreamOptions, CompressionParameterRequest, EndDirective, ReferenceStrategy,
    ReferenceStreamEncoder, StreamStatus, decompress,
};
fn barrier() {
    let start = Instant::now();
    let mut n = 123_u64;
    while start.elapsed() < Duration::from_millis(250) {
        for _ in 0..10_000 {
            n = n.wrapping_mul(6364136223846793005).wrapping_add(1);
        }
        black_box(n);
    }
}
fn digest(b: &[u8]) -> u64 {
    b.iter().fold(0xcbf29ce484222325, |n, &b| {
        (n ^ u64::from(b)).wrapping_mul(0x100000001b3)
    })
}
fn pump(e: &mut ReferenceStreamEncoder<'_>, input: &[u8], frame: &mut Vec<u8>, output: &mut [u8]) {
    frame.clear();
    let mut pos = 0;
    loop {
        let end = (pos + 317).min(input.len());
        let d = if end == input.len() {
            EndDirective::Finish
        } else {
            EndDirective::Continue
        };
        let p = e.process(&input[pos..end], output, d).unwrap();
        pos += p.consumed;
        frame.extend_from_slice(&output[..p.produced]);
        if p.status == StreamStatus::FrameFinished {
            assert_eq!(pos, input.len());
            break;
        }
    }
}
fn configure(
    e: &mut ReferenceStreamEncoder<'_>,
    mode: usize,
    request: CompressionParameterRequest,
    opts: CompiledStreamOptions,
) {
    match mode {
        0 => e.reset(),
        1 => {
            e.reset_parameters().unwrap();
            e.reset();
        }
        2 => e.reset_all(),
        _ => unreachable!(),
    }
    e.set_options(opts).unwrap();
    e.set_request(request).unwrap();
}
#[test]
fn lifecycle_measurements() {
    let root = std::path::PathBuf::from(std::env::var_os("ZSTDOXIDE_LIFECYCLE_BENCH").unwrap());
    std::fs::create_dir_all(&root).unwrap();
    let families = [
        ReferenceStrategy::Fast,
        ReferenceStrategy::DoubleFast,
        ReferenceStrategy::Greedy,
        ReferenceStrategy::Lazy,
        ReferenceStrategy::Lazy2,
        ReferenceStrategy::BinaryTreeLazy2,
    ];
    let inputs = [
        b"small streaming lifecycle repeated text small streaming lifecycle".to_vec(),
        b"reconfigured frame repeated source data ".repeat(105),
    ];
    let mut ledger = String::new();
    let mut samples =
        String::from("case\tround\tsample\tmode\tvariant\tnanoseconds\tbytes\tdigest\n");
    for family in 0..6 {
        let requests = std::array::from_fn::<_, 2, _>(|variant| {
            let mut r = CompressionParameterRequest::with_level(3);
            r.set_strategy(Some(families[(family + variant) % 6]));
            r.set_window_log(17 - variant as u8).unwrap();
            r.set_hash_log(14).unwrap();
            r.set_chain_log(14).unwrap();
            r
        });
        for (kind, input) in inputs.iter().enumerate() {
            let name = format!("family{}-corpus{kind}", family + 1);
            let opts = CompiledStreamOptions {
                checksum: true,
                pledged_size: Some(input.len() as u64),
                ..Default::default()
            };
            let mut owners: Vec<_> = (0..3)
                .map(|_| ReferenceStreamEncoder::with_options(requests[0], opts).unwrap())
                .collect();
            let mut frame = Vec::with_capacity(input.len() * 2 + 1024);
            let mut output = vec![0; 8192];
            let mut expected = Vec::new();
            for (variant, &request) in requests.iter().enumerate() {
                let mut fresh = ReferenceStreamEncoder::with_options(request, opts).unwrap();
                pump(&mut fresh, input, &mut frame, &mut output);
                assert_eq!(decompress(&frame, input.len()).unwrap(), *input);
                expected.push(frame.clone());
                std::fs::write(root.join(format!("{name}-{variant}.zst")), &frame).unwrap();
                ledger.push_str(&format!(
                    "{name}\t{variant}\t{}\t{}\t{}\n",
                    input.len(),
                    frame.len(),
                    digest(&frame)
                ));
                for (mode, owner) in owners.iter_mut().enumerate() {
                    configure(owner, mode, request, opts);
                    pump(owner, input, &mut frame, &mut output);
                    assert_eq!(frame, expected[variant]);
                }
            }
            for round in 0..2 {
                barrier();
                for sample in 0..40 {
                    let variant = sample % 2;
                    for order in 0..4 {
                        let mode = (order + sample + round) % 4;
                        let start = Instant::now();
                        if mode < 3 {
                            configure(&mut owners[mode], mode, requests[variant], opts);
                            pump(&mut owners[mode], black_box(input), &mut frame, &mut output);
                        } else {
                            let mut fresh =
                                ReferenceStreamEncoder::with_options(requests[variant], opts)
                                    .unwrap();
                            pump(&mut fresh, black_box(input), &mut frame, &mut output);
                            drop(fresh);
                        }
                        let ns = start.elapsed().as_nanos();
                        assert_eq!(frame, expected[variant]);
                        samples.push_str(&format!(
                            "{name}\t{round}\t{sample}\t{mode}\t{variant}\t{ns}\t{}\t{}\n",
                            frame.len(),
                            digest(&frame)
                        ));
                    }
                }
            }
        }
    }
    std::fs::write(root.join("ledger.tsv"), ledger).unwrap();
    std::fs::write(root.join("samples.tsv"), samples).unwrap();
}
