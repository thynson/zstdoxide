"""Close the module36 milestone: reconcile, archive, document and commit."""
from pathlib import Path
import json, hashlib, subprocess, tarfile, datetime, shutil

D = Path(__file__).parent
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = Path('/private/tmp/module36-archives/promotion-state.json')
previous = json.loads(state.read_text())
assert previous['stage'] == 'next-design'
assert previous['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
production = {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')}
assert production == previous['production_source']
names = [
    '2026-10-29-one-shot-encode-parameters-engine',
    '2026-10-30-one-shot-encode-parameters-double-fast',
    '2026-10-30-one-shot-encode-parameters-family',
    '2026-10-30-one-shot-encode-parameters-tree',
    '2026-10-30-one-shot-encode-parameters-entropy',
    '2026-10-30-one-shot-encode-parameters-public-api',
    '2026-10-30-one-shot-encode-parameters-native',
    '2026-10-30-one-shot-encode-parameters-platform',
    '2026-11-02-one-shot-encode-parameters-feature-matrix',
    '2026-11-02-one-shot-encode-parameters-benchmarks',
]
final_source = set(names[5:])
records = {}
for n in names:
    p = E / (n + '.json')
    j = json.loads(p.read_text())
    assert j['status'] == 'passed' and sha(E / j['archive']) == j['archive_sha256'], n
    if n in final_source and n != '2026-11-02-one-shot-encode-parameters-benchmarks':
        assert j['production_source'] == production, n
    records[n] = dict(receipt_sha256=sha(p), archive_sha256=j['archive_sha256'])
matrix = json.loads((E / '2026-11-02-one-shot-encode-parameters-feature-matrix.json').read_text())
bench = json.loads((E / '2026-11-02-one-shot-encode-parameters-benchmarks.json').read_text())
assert bench['build']['production_source'] == production
assert bench['repeat_build']['production_source'] == production
counts = matrix['full_suite_counts']
pred = E / '2026-10-29-one-shot-encode-closure.json'
assert json.loads(pred.read_text())['status'] == 'passed'
next_design = R / 'docs/prepared-dictionary-design.md'
assert next_design.exists()
todo = (R / 'TODO.md').read_text()
start = todo.index('## Module 36:')
end = todo.index('\n## ', start + 1)
unchecked = [l for l in todo[start:end].splitlines() if l.startswith('- [ ]')]
assert len(unchecked) == 1 and unchecked[0].startswith('- [ ] Reconcile bounded parameterized-dictionary coverage'), unchecked
assert '## Module 37:' in todo
assert sha(next_design) == previous['next_design_sha256']
inventory = Path('/private/tmp/module24-preparation/zstd-git')
args = ['python3', 'scripts/audit_upstream_tests.py', '--upstream', str(inventory)]
with (D / 'inventory.log').open('xb') as f:
    p = subprocess.run(args, cwd=R, stdout=f, stderr=subprocess.STDOUT)
assert p.returncode == 0
receipt = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), production_source=production, final_matrix_source=matrix['source'], evidence=records, predecessor_closure_sha256=sha(pred), inventory_command=args, inventory_log_sha256=sha(D / 'inventory.log'), next_design_sha256=sha(next_design), full_suite_counts=counts, benchmark_sample_rows=sum(r['rows'] for r in bench['primary_timing']['runs']), qualification='Bounded combined parameterized dictionary-backed one-shot compression over the six admitted profiles. In-window dictionary staging, prepared entropy reuse, dictionary-ID headers, explicit optimal-family rejection, caller-owned and coordinator APIs, guarded native schedules, concrete atomic-free ARM code generation, full feature/release and independent measurements are retained. No native workspace reuse, CDict creation costs, LDM, workers, streaming, parameter lifecycle or complete upstream parity is claimed.')
(D / 'reconciliation.json').write_text(json.dumps(receipt, indent=2) + '\n')
name = '2026-11-02-one-shot-encode-parameters-closure'
archive = E / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(D / 'reconciliation.json', arcname='reconciliation.json')
    tar.add(D / 'inventory.log', arcname='inventory.log')
    tar.add(next_design, arcname='prepared-dictionary-design.md')
    tar.add(__file__, arcname='close-module.py')
receipt.update(archive=archive.name, archive_sha256=sha(archive))
(E / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
p = R / 'docs/one-shot-encode-parameters-validation.md'
s = p.read_text()
old = '''Module 36 is in progress. The internal combined-staging engine, its DoubleFast
extension, the Greedy chain-and-row family extension, the BinaryTreeLazy2
tree-family extension with the explicit optimal-family rejection, prepared
formatted-dictionary entropy reuse, and the public allocating, caller-owned and
coordinator parameterized dictionary calls are qualified and integrated.
Corpus validation and reconciliation remain open.'''
assert old in s, 'validation intro not found'
s = s.replace(old, '''Module 36 is complete within its combined parameterized dictionary-backed
one-shot scope. In-window dictionary staging, the Fast, DoubleFast, Greedy
chain-and-row and BinaryTreeLazy2 extensions, prepared formatted-dictionary
entropy reuse, explicit optimal-family rejection, and the public allocating,
caller-owned and coordinator calls have successful source-bound receipts.
Guarded native schedules, concrete atomic-free ARM emission, the complete
feature/release matrix and independent measurements are retained. No separate
broad corpus campaign was run; deterministic unit rows and guarded native
schedules cover the bounded subset.''')
s += '''
## Final reconciliation and remaining scope

Integrated production and matrix sources match the qualified public/native/
platform and measured snapshots; every stage archive is rehashed. Earlier
engine, DoubleFast, family, tree and entropy receipts retain their distinct
stage identities rather than being presented as final-source evidence.

The supported subset is exact: Fast, DoubleFast, Greedy, Lazy, Lazy2 and
BinaryTreeLazy2 use in-window combined staging with the resolved candidate
floor for dictionary expiry; every fresh or retained Optimal/Ultra/Ultra2
profile rejects nonzero dictionary content with `UnsupportedFeature`. Empty and
raw attachments preserve the dictionary-free parameterized bytes, prepared
entropy seeds only the first block, and the dictionary ID is serialized in the
frame header. No options record, workspace or live context survives a call.

Native workspace reuse, CDict creation costs, parameter lifecycle, dedicated
dictionary search, long-distance matching, workers, streaming and complete
upstream parity remain open. A reusable compiled-dictionary state is designed
and decomposed next; see `prepared-dictionary-design.md`.
Evidence: `evidence/{name}.json`.
'''.format(name=name)
p.write_text(s)
p = R / 'README.md'
s = p.read_text()
anchor = '''`with_prefix`/`set_prefix` arm exactly the next attempted call, including
empty input, short output and allocation failure. Its completed bounded
qualification and remaining scope are recorded in
[the selection validation report](docs/one-shot-encode-selection-validation.md).
'''
assert s.count(anchor) == 1, 'README selection anchor'
s = s.replace(anchor, anchor + '''
Parameterized dictionary-backed calls are available through
`compress_with_parameters_and_dictionary`, its caller-owned variants and
`OneShotEncoder::compress_into_with_parameters`. A resolved reference profile
and an immutable dictionary view combine in one call over Fast, DoubleFast,
Greedy, Lazy, Lazy2 or BinaryTreeLazy2; Optimal/Ultra/Ultra2 reject nonzero
dictionary content explicitly. In-window dictionary content, prepared entropy
and the dictionary ID follow the existing dictionary contract. See
[parameterized dictionary usage](docs/one-shot-encode-parameters-usage.md) and
[the validation report](docs/one-shot-encode-parameters-validation.md).
''')
old = '| Reference Fast, DoubleFast, Greedy, Lazy, Lazy2 and BinaryTreeLazy2 | Known-size, no-dictionary one-shot level/request execution;'
assert s.count(old) == 1, 'README table row'
s = s.replace(old, '| Reference Fast, DoubleFast, Greedy, Lazy, Lazy2 and BinaryTreeLazy2 | Known-size one-shot level/request execution, dictionary-free or with an in-window borrowed raw/formatted dictionary (Optimal/Ultra/Ultra2 reject nonzero dictionaries);')
p.write_text(s)
p = R / 'docs/progress.md'
ratios = [f"{x['campaign']} {x['backend']} {x['scope']} {x['value']:.4f}" for x in bench['summary']['comparisons'] if x['campaign'] == 'primary' and x['backend'] == 'safe' and x['scope'] in ['all-nonempty', 'empty-dictionary', 'raw-dictionary', 'prepared-dictionary']]
p.write_text(p.read_text() + '''
## Module 36: parameterized dictionary-backed one-shot compression complete (2026-11-02)

Resolved reference profiles combine with immutable dictionary views inside one
call. The in-window dictionary suffix is staged contiguously before the input,
the existing Fast/DoubleFast/Greedy-family/tree parsers run over the combined
borrow, and the existing candidate floor realizes dictionary window expiry.
Formatted-dictionary entropy seeds the first emitted block; the dictionary ID
is serialized between the optional window byte and the content size. Every
fresh and retained Optimal/Ultra/Ultra2 profile rejects nonzero dictionary
content with `UnsupportedFeature` instead of dropping it. Empty and raw
attachments preserve dictionary-free parameterized bytes. Allocating,
caller-owned and coordinator entry points retain their exact guards, prefix
consumption and allocator-failure release; no options record, workspace or live
context survives a call.

All 75 final commands pass: safe/all/22 isolated full suites, no_std and strict
Clippy, safe/all release and format. Every complete/release suite reports
{groups} result groups, {passed} passed and {ignored} ignored with zero
failures. Twenty typed native parameterized cases run against normal and
sanitized pinned builds with independent destination guards and bidirectional
decoding; five optimal-family profiles reject before writes. Concrete
thumbv6m-none-eabi library checks and release IR/object emission pass for safe
and all features; foreign Miri was not run because this module added or
modified no unsafe code, per the standing direction.

Forty-eight case/level pairs across seven inputs and three dictionary kinds
retain 576 identical qualification rows and 1455 samples per executable across
24 primary backends and independent safe/all rebuilds. Stateless and
coordinator rows produce identical bytes and ledgers; dictionary and scratch
domains stay separate. Primary safe coordinator/stateless geometric-mean
ratios: {ratios}. No universal profile benefit, absence of scratch allocation,
native byte identity or complete codec replacement is inferred.

Completed tasks are archived in Git history. A reusable compiled-dictionary
state is designed and decomposed next; see
`docs/prepared-dictionary-design.md`. Native workspace reuse, parameter
lifecycle, LDM, workers, streaming and complete upstream parity remain open.
'''.format(groups=counts['result_groups'], passed=counts['passed'], ignored=counts['ignored'], ratios='; '.join(ratios)))
replacement = '''Module 36 is complete within its bounded combined parameterized dictionary
one-shot scope. Completed items are archived in Git history and
`docs/progress.md`; contracts, measurements and limits are in
`docs/one-shot-encode-parameters-validation.md` and
`docs/one-shot-encode-parameters-benchmarks.md`. Final reconciliation is in
`docs/evidence/2026-11-02-one-shot-encode-parameters-closure.json`.
Complete upstream parity remains open.

'''
(R / 'TODO.md').write_text(todo[:start] + replacement + todo[end:])
paths = ['README.md', 'TODO.md', 'docs/progress.md', 'docs/one-shot-encode-parameters-validation.md', 'docs/evidence/' + name + '.json', 'docs/evidence/' + name + '.tar.gz']
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Close parameterized dictionary encode milestone'], cwd=R, check=True)
previous.update(stage='closed', head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip())
state.write_text(json.dumps(previous, indent=2) + '\n')
print('module36 closed at', previous['head'][:12])
