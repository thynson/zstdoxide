from pathlib import Path
import os,json,hashlib,subprocess,time,datetime,shutil,re
D=Path(__file__).parent;S=D/'replay-source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,27,8,32,32,tzinfo=datetime.timezone.utc).timestamp()
for gate in [Path('/private/tmp/module33-public/evidence.json'),D/'build.json']:
 while True:
  try:j=json.loads(gate.read_text())
  except (FileNotFoundError,json.JSONDecodeError):j={'status':'running'}
  assert j['status']!='failed',(gate,j.get('error'))
  if j['status']=='passed':break
  assert time.time()<deadline-120;time.sleep(5)
assert not S.exists();subprocess.run(['cp','-cR','/private/tmp/module33-public/source',str(S)],check=True);shutil.copyfile(D/'slice_encode_output_native.rs',S/'tests/slice_encode_output_native.rs');subprocess.run(['cargo','fmt','--all'],cwd=S,check=True);shutil.copyfile(S/'tests/slice_encode_output_native.rs',D/'slice_encode_output_native.rs')
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};e=dict(status='running',source=source,commands=[]);env={**os.environ,'CARGO_TARGET_DIR':str(D/'replay-target'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save(name,data):(D/name).write_text(json.dumps(data,indent=2)+'\n')
def run(label,args,extra):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT,timeout=max(1,deadline-time.time()-30))
 row=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log')));assert p.returncode==0,(label,(D/(label+'.log')).read_text()[-3000:]);print(label,'passed',flush=True);return row
save('export.json',e)
try:
 for name,flags,folder in [('safe',[],D/'inputs'),('all',['--all-features'],D/'all-inputs')]:
  args=['cargo','test','--offline','--locked','--test','slice_encode_output_native','export_slice_frames',*flags,'--','--ignored','--nocapture'];row=run(name+'-export',args,{'ZSTDOXIDE_SLICE_ENCODE_EXPORT':str(folder)});assert '1 passed; 0 failed; 0 ignored' in (D/(row['label']+'.log')).read_text();e['commands'].append(row);save('export.json',e)
 fixtures={p.name:sha(p) for p in (D/'inputs').iterdir()};assert len(fixtures)==73 and fixtures=={p.name:sha(p) for p in (D/'all-inputs').iterdir()};e.update(status='passed',inputs=fixtures);save('export.json',e)
 n=dict(status='running',build_receipt_sha256=sha(D/'build.json'),export_receipt_sha256=sha(D/'export.json'),commands=[]);save('native.json',n)
 for name in ['normal','sanitized']:
  outdir=D/(name+'-outputs');outdir.mkdir();args=[str(D/('oracle-'+name)),str(D/'inputs'),str(outdir)];t=time.monotonic();p=subprocess.run(args,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=max(1,deadline-time.time()-30));(D/(name+'.tsv')).write_bytes(p.stdout);(D/(name+'.stderr')).write_bytes(p.stderr);n['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(D/(name+'.tsv')),stderr_sha256=sha(D/(name+'.stderr'))));save('native.json',n);assert p.returncode==0,(name,p.stderr);assert len(p.stdout.decode().splitlines())==324;assert len(list(outdir.iterdir()))==36
 assert (D/'normal.tsv').read_bytes()==(D/'sanitized.tsv').read_bytes();outputs={p.name:sha(p) for p in (D/'normal-outputs').iterdir()};assert outputs=={p.name:sha(p) for p in (D/'sanitized-outputs').iterdir()};assert fixtures=={p.name:sha(p) for p in (D/'inputs').iterdir()}
 rows=[l.split('\t') for l in (D/'normal.tsv').read_text().splitlines()];n.update(status='passed',outputs=outputs,rows=324,successful_rows=sum(r[3]=='ok' for r in rows),success_rows_with_changed_unused_suffix=sum(int(r[6])>0 for r in rows),qualification='36 deterministic independently encoded Rust frames decoded by pinned normal/ASan+UBSan C. Each native encoder also attempts nine capacities relative to its own full output, checking real outer guards, immutable inputs, complete success decode and recording unused suffix writes. Native capacity-dependent byte/size choices are not assumed equal to Rust or to the native full-capacity encoding. macOS leak detection is unsupported and disabled. Supplemental workloads do not upgrade original upstream groups.');save('native.json',n)
 r=dict(status='running',source=source,native_receipt_sha256=sha(D/'native.json'),commands=[]);save('replay.json',r)
 for name,flags in [('safe',[]),('sink',['--features','unsafe-frame-sink']),('match',['--features','unsafe-match-table']),('all',['--all-features'])]:
  args=['cargo','test','--offline','--locked','--test','slice_encode_output_native','replay_slice_frames',*flags,'--','--ignored','--nocapture'];row=run(name+'-replay',args,{'ZSTDOXIDE_SLICE_ENCODE_CASES':str(D)});assert '1 passed; 0 failed; 0 ignored' in (D/(row['label']+'.log')).read_text();ledger='\n'.join(l for l in (D/(row['label']+'.log')).read_text().splitlines() if l.startswith('OBS\t'))+'\n';assert len(ledger.splitlines())>=250;(D/(name+'-observations.tsv')).write_text(ledger)
  if name!='safe':assert ledger==(D/'safe-observations.tsv').read_text()
  r['commands'].append(row);save('replay.json',r)
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  r['commands'].append(run(name+'-clippy',['cargo','clippy','--offline','--locked','--test','slice_encode_output_native',*flags,'--','-D','warnings'],{}));save('replay.json',r)
 for name,h in source.items():assert sha(S/name)==h,name
 r.update(status='passed',observations=len(ledger.splitlines()),qualification='Four Rust backends decode all36 native frames and reproduce exact caller-owned Rust output across each independent actual-size capacity sweep. All typed results, output prefixes and outer/unused-success guards agree; native error precedence and native compressed-byte equality are not claimed. Two export commands establish safe/all identical input/frame artifacts; two strict adapter Clippy checks also pass.');save('replay.json',r)
except BaseException as ex:
 for name in ['export.json','native.json','replay.json']:
  p=D/name
  if p.exists():j=json.loads(p.read_text());
  else:continue
  if j['status']=='running':j.update(status='failed',error=repr(ex));save(name,j)
 raise
