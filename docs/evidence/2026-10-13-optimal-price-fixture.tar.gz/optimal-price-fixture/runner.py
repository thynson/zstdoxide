from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-optimal-price-fixture-checks');O.mkdir();env=os.environ.copy();env.update(CARGO_TARGET_DIR='/tmp/zstdoxide-tree-baseline-target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',PYTHONDONTWRITEBYTECODE='1')
paths=['Cargo.toml','Cargo.lock','tests/reference_optimal_price_fixture.rs','tests/support/optimal_price_fixture.rs','scripts/pack_optimal_price_fixtures.py','scripts/oracles/optimal_prices_v2.py','scripts/oracles/optimal_price_recipes.py','scripts/oracles/optimal_price_validation.py']+[str(p.relative_to(R)) for p in (R/'tests/fixtures/reference-optimal-prices').iterdir()];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths};rows=[]
def run(label,args,tests=None):
 log=O/(label+'.log');start=time.monotonic();print('START',label,flush=True)
 with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest());rows.append(r);print('END',label,p.returncode,flush=True)
 if tests is not None:
  counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)];r['tests']=counts
  if counts!=[tests]:raise ValueError('test totals '+label)
 if p.returncode:raise ValueError(label)
for name,flags in [('safe',[]),('all',['--all-features']),('release-all',['--release','--all-features'])]:run('reader-'+name,['cargo','test','--offline','--locked',*flags,'--test','reference_optimal_price_fixture'],(4,0,0))
for name,flags in [('safe',[]),('all',['--all-features'])]:run('clippy-'+name,['cargo','clippy','--offline','--locked','--test','reference_optimal_price_fixture',*flags,'--','-D','warnings'])
run('format',['cargo','fmt','--all','--','--check'])
for name,flags in [('normal',[]),('optimized',['-O'])]:run('projection-'+name,['python3',*flags,'scripts/pack_optimal_price_fixtures.py'])
if source!={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}:raise ValueError('source changed')
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,tests=12,qualification='Additive test-only reader, outside the running immutable Module16 matrix. Full 147-case/2018-operation archived C projection; safe/all/release-all bounds checks and selected hand-calculated prices, strict safe/all Clippy and formatting. No production Optimal implementation.'),sort_keys=True,indent=2)+'\n')
