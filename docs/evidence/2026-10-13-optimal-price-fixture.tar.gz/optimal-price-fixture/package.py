from pathlib import Path
import hashlib,io,json,sys,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');stem=sys.argv[1];O=Path('/tmp/zstdoxide-'+stem+'-checks');E=R/'docs/evidence';e=json.loads((O/'evidence.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
if e['status']!='passed' or not all(r['exit_code']==0 for r in e['commands']):raise ValueError('passed checkpoint')
files={p.name:p.read_bytes() for p in O.iterdir() if p.is_file()}
for row in e['commands']:
 if sha((O/row['log']).read_bytes())!=row['sha256']:raise ValueError('log identity')
for n,h in e['source'].items():
 b=(R/n).read_bytes()
 if sha(b)!=h:raise ValueError('source '+n)
 files['source/'+n]=b
files['runner.py']=Path('/tmp/zstdoxide-'+stem+'-checks.py').read_bytes();files['package.py']=Path(__file__).read_bytes()
a=E/('2026-10-13-'+stem+'.tar.gz')
if a.exists():raise ValueError('fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo(stem+'/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:actual={m.name:t.extractfile(m).read() for m in t}
if actual!={stem+'/'+n:b for n,b in files.items()}:raise ValueError('archive bytes')
e.update(archive=a.name,archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files))
(E/('2026-10-13-'+stem+'.json')).write_text(json.dumps(e,sort_keys=True,indent=2)+'\n');print(stem,len(files),a.stat().st_size)
