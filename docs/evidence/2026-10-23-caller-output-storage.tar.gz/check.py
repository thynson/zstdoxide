from pathlib import Path
import os,subprocess,json,time,hashlib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path(__file__).parent
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module23-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
paths=['Cargo.toml','src/lib.rs','src/slice_history.rs','src/history.rs','src/error.rs'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths}
e={'status':'running','source':source,'commands':[],'prior_safe_test_log_sha256':hashlib.sha256((D/'safe.log').read_bytes()).hexdigest()}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append({'label':label,'argv':args,'exit_code':p.returncode,'seconds':time.monotonic()-t});save();print(label,p.returncode,flush=True)
 if p.returncode:raise ValueError(label)
try:
 for name,flags in [('unsafe',['--features','unsafe-slice-history']),('all',['--all-features'])]:run(name+'-tests',['cargo','test','--offline','--locked','--lib','slice_history::tests',*flags])
 for name,flags in [('safe',[]),('unsafe',['--features','unsafe-slice-history']),('all',['--features',','.join(__import__('tomllib').loads((R/'Cargo.toml').read_text())['features'].keys()-{'default','std'})])]:run(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*flags])
 for name,flags in [('safe',[]),('unsafe',['--features','unsafe-slice-history']),('all',['--all-features'])]:run(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])
 run('format',['cargo','fmt','--all','--','--check'])
 if source!={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths}:raise ValueError('changed source')
 e['status']='passed';save()
except BaseException as ex:e['status']='failed';e['error']=repr(ex);save();raise
