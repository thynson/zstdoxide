from pathlib import Path
import argparse, hashlib, json
p=argparse.ArgumentParser();p.add_argument('destination',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parent
if a.destination.exists() or a.destination.is_symlink():raise ValueError('fresh destination required')
files=json.loads((root/'file-map.json').read_text())
a.destination.mkdir(parents=True)
for name,item in files.items():
 relative=Path(name)
 if relative.is_absolute() or '..' in relative.parts:raise ValueError('relative file name required')
 destination=a.destination/relative;destination.parent.mkdir(parents=True,exist_ok=True)
 digest=hashlib.sha256();size=0
 with destination.open('xb') as out:
  for key in item['chunks']:
   if len(key)!=64 or any(c not in '0123456789abcdef' for c in key):raise ValueError('chunk key')
   data=(root/'chunks'/(key+'.bin')).read_bytes()
   if len(data)>4096 or hashlib.sha256(data).hexdigest()!=key:raise ValueError('chunk identity')
   out.write(data);digest.update(data);size+=len(data)
 if size!=item['bytes'] or digest.hexdigest()!=item['sha256']:raise ValueError('file identity')
 destination.chmod(item['mode'])
