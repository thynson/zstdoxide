from pathlib import Path
import hashlib,json,tarfile,importlib.util,datetime
D=Path('/private/tmp/module33-compression-benchmark');E=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();spec=importlib.util.spec_from_file_location('measure',D/'measure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b,gates=m.validate();r=json.loads((D/'repeat/evidence.json').read_text());q=json.loads((D/'timed.json').read_text());z=json.loads((D/'repeat/timed.json').read_text());s=json.loads((D/'summary.json').read_text())
assert q['status']==z['status']=='passed' and len(q['runs'])==24 and len(z['runs'])==2;assert q['gates']==z['gates']==gates;assert z['primary_timing_sha256']==sha(D/'timed.json') and z['build_evidence_sha256']==sha(D/'repeat/evidence.json')
for folder,build,timed in [(D,b,q),(D/'repeat',r,z)]:
 for row in build['builds']:
  assert sha(folder/row['executable'])==row['sha256'];assert (folder/(row['name']+'-qualify.tsv')).read_bytes()==(D/'safe-qualify.tsv').read_bytes()
 for row in timed['runs']:assert sha(folder/(row['name']+'-timed.tsv'))==row['sha256']
fixtures={'source/tests/upstream/data/golden-compression/http','source/tests/upstream/data/golden-compression/large-literal-and-match-lengths'};files={}
for p in D.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(D)
 if any(x=='target' or x.endswith('-target') or x=='__pycache__' or x.endswith('.dSYM') for x in rel.parts):continue
 if 'source' in rel.parts and p.suffix not in {'.rs','.toml','.lock','.json','.py','.md','.sh','.csv','.tsv'} and str(rel) not in fixtures:continue
 files[str(rel)]=p
assert fixtures<=files.keys();files['archive-compression-benchmark.py']=Path(__file__);files['LICENSE.zstd']=Path('/Users/lanxingcan/Workspace/zstdoxize/LICENSE.zstd');name='2026-10-27-slice-encode-benchmarks';archive=E/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
result=dict(status='passed',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),build=b,repeat_build=r,primary_timing=q,repeat_timing=z,summary=s,members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()},archive=archive.name,archive_sha256=sha(archive),qualification='All 24 safe/isolated/all production feature selections and two independently rebuilt repeats retain all110 samples and 44 role-specific qualification rows per executable. Destination/staging/workspace ledgers are outside timings; Global per-call scratch and allocated destination destruction are inside. Caller output setup is outside borrowed clocks. Actual process barriers precede campaigns. No universal speedup, desktop idleness, C byte identity or complete codec replacement is claimed.')
(E/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
report='''# Caller-owned compression measurements

Eleven fixed inputs cover empty/tiny data, content-size thresholds, a full raw
block, RLE across a block boundary, repeated multiblock data and two retained
upstream golden-compression fixtures. Every backend emits exact existing Rust
frame bytes; guards and unused success suffixes are checked outside timing.

Twenty-four primary backends (safe,22 isolated unsafe features,all) and separately
rebuilt safe/all repeats each retain 110 samples:11 cases x 2 modes x 5 samples.
Per-operation clocks include all scratch allocation and release. Allocated mode
also includes returned destination allocation/destruction. Borrowed mode uses an
already allocated caller buffer. Input/buffer construction, byte verification,
tracking ledgers and result formatting are outside clocks. Timer overhead remains
in both modes. Two fresh process observations gate each campaign; this does not
prove the whole desktop is idle.

Clock-free Roles allocator routing distinguishes the original allocator domain
(destination for allocated output, staging for borrowed output) from independent
workspace clones. All 44 rows per backend agree exactly; every owner releases through
its own allocation domain. Borrowed staging peaks at no more than one raw block
plus header. Caller-owned destination storage is excluded from allocator counts.
Timed calls use Global directly; the role-router is not part of codec production.

| Campaign | Backend | Compared operation | Reference | Nonempty median-latency ratio |
|---|---|---|---|---:|
'''
for x in s['comparisons']:
 if x['backend'] in ['safe','all'] and (x['numerator']!=x['denominator'] or x['backend']=='all'):
  report+=f"| {x['campaign']} | {x['backend']} | {x['numerator']} | {x['reference_backend']} {x['denominator']} | {x['nonempty_geomean']:.4f} |\n"
report+='''
Ratios are equal-weight geometric means of ten nonempty per-case median latency
ratios. Values below 1 mean the numerator took less time in this fixed campaign;
the empty case stays separate in the archive. Fixed order, limited repetitions
and host variation do not establish statistical significance or a general unsafe
benefit. Whole-frame exact byte compatibility does not imply native C byte
identity. Evidence: `evidence/2026-10-27-slice-encode-benchmarks.json`.
''';(E/'slice-encode-benchmarks.md').write_text(report)
