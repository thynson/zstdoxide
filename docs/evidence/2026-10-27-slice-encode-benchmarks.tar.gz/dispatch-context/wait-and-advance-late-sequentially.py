"""Advance qualified modules in order, preserving deferred matrix work."""
from pathlib import Path
import json,subprocess,time,datetime,hashlib,shutil
T=Path('/private/tmp');R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=T/'module31-34-promotion';D.mkdir(exist_ok=True);deadline=datetime.datetime(2026,10,27,8,32,32,tzinfo=datetime.timezone.utc).timestamp();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (D/'evidence.json').exists();reconciliation=T/'late-sequential-reconciliation/evidence.json';assert json.loads(reconciliation.read_text())['status']=='passed'
e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scheduling_reconciliation_sha256=sha(reconciliation),controller_sha256=sha(Path(__file__)),commands=[],qualification='Sequential module advancement preserves every original qualification gate. Module32/33 matrices are explicitly interrupted with completed rows and partial logs retained; no deferred matrix is counted as passed. Each timed campaign waits for actual global compiler/task quiescence.')
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,script,*args):
 if time.time()>deadline-120:raise TimeoutError('No new action in final two minutes: '+label)
 command=['python3',str(script),*args];t=time.monotonic();e['active_action']=dict(label=label,argv=command);save()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=command,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log'))));e.pop('active_action',None);save();print(label,p.returncode,flush=True)
 if p.returncode!=0 and time.time()>deadline-60:raise TimeoutError('User deadline during '+label)
 assert p.returncode==0,(label,(D/(label+'.log')).read_text()[-4000:])
def wait_matrix(m):
 e['waiting_for']=f'module{m}-matrix';save()
 while True:
  j=json.loads((T/f'module{m}-matrix/evidence.json').read_text())
  if j['status']=='passed':break
  if time.time()>deadline-120:raise TimeoutError('No completed matrix before action cutoff')
  assert j['status']=='running',(m,j['status'],j.get('error'));time.sleep(10)
 e.pop('waiting_for',None);save()
def ledger(m,folder,deferred):
 receipts={str(reconciliation):'passed'}
 for n in range(28,m+1):receipts[str(T/f'module{n}-matrix/evidence.json')]='passed'
 for n in range(28,m):
  for c in ['', 'repeat/']:receipts[str(T/(f'module{n}-benchmark'+('-v2' if n in [30,31] else ''))/(c+'timed.json'))]='passed'
 for c in ['', 'repeat/']:receipts[str(folder/(c+'evidence.json'))]='qualified-not-timed'
 receipts[str(folder/'harness-check.json')]='passed'
 for n in deferred:
  p=T/f'module{n}-matrix/evidence.json';assert json.loads(p.read_text())['status']=='interrupted-by-coordinator';snapshot=D/f'module{n}-deferred-before-{m}.json';assert not snapshot.exists();shutil.copyfile(p,snapshot);receipts[str(snapshot)]='interrupted-by-coordinator'
 for p,status in receipts.items():assert json.loads(Path(p).read_text())['status']==status,p
 path=folder/'timing-dispatch-gates.json';assert not path.exists();path.write_text(json.dumps(dict(status='ready',prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),receipts=receipts,receipt_sha256={p:sha(Path(p)) for p in receipts},controller_sha256=sha(Path(__file__)),qualification=f'Actual full matrices28..{m} passed. Later matrices {deferred} are explicitly deferred with immutable snapshots; they are not qualification prerequisites for this module. All benchmark builds and prior measurements passed. Two fresh global compiler/task process inventories remain mandatory immediately before each campaign.'),indent=2)+'\n')
def finish_bench(m,folder):
 A=T/f'module{m}-archives';run(f'{m}-timings',folder/'observe-and-measure.py');run(f'{m}-benchmark-archive',A/'archive-benchmark.py',str(m));run(f'{m}-benchmark-report',A/'render-benchmark-report.py');run(f'{m}-benchmark-promote',A/'promote-final.py','benchmarks');run(f'{m}-close',A/'close-module.py')
save()
try:
 early=T/'module31-focused-promotion/evidence.json';assert json.loads(early.read_text())['status']=='passed';e['earlier_module31_focused_receipt_sha256']=sha(early);save()
 wait_matrix(31);A=T/'module31-archives';state=json.loads((A/'promotion-state.json').read_text());assert state['stage']=='platform' and state['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 run('31-matrix-archive',A/'archive-matrix.py');run('31-matrix-promote',A/'promote-final.py','matrix');ledger(31,T/'module31-benchmark-v2',[32,33]);finish_bench(31,T/'module31-benchmark-v2')
 A=T/'module32-archives'
 for stage in ['core','public-api','native','platform']:run(f'32-{stage}-promote',A/'promote-focused.py',stage)
 run('32-matrix-resume',T/'module32-matrix/resume.py','32','--deadline-utc','2026-10-27T08:32:32+00:00');wait_matrix(32);run('32-matrix-archive',A/'archive-matrix.py');run('32-matrix-promote',A/'promote-final.py','matrix');ledger(32,T/'module32-benchmark',[33]);finish_bench(32,T/'module32-benchmark');run('32-inventory-reconciliation',T/'module32-inventory-plan/apply.py')
 A=T/'module33-archives';run('33-leaf-timings',T/'module33-benchmark/measure.py');run('33-leaf-benchmark-archive',A/'archive-benchmark.py');run('33-storage-promote',A/'promote-storage.py')
 for stage in ['engine','public-api','native','platform']:run(f'33-{stage}-promote',A/'promote-focused.py',stage)
 run('33-matrix-resume',T/'module33-matrix/resume.py','33','--deadline-utc','2026-10-27T08:32:32+00:00');wait_matrix(33);run('33-matrix-archive',A/'archive-matrix.py');run('33-matrix-promote',A/'promote-final.py','matrix');ledger(33,T/'module33-compression-benchmark',[]);run('33-compression-timings',T/'module33-compression-benchmark/observe-and-measure.py');run('33-compression-benchmark-archive',A/'archive-compression-benchmark.py');run('33-benchmark-promote',A/'promote-final.py','benchmarks');run('33-close',A/'close-module.py');run('33-inventory-reconciliation',T/'module33-inventory-plan/apply.py');run('34-engine-promote',T/'module34-archives/promote-engine.py')
 e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except TimeoutError as ex:e.update(status='interrupted-at-user-deadline',error=repr(ex));save();raise
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
