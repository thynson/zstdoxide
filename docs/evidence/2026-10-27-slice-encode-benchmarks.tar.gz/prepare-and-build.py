from pathlib import Path
import os,subprocess,json,time,hashlib,shutil
D=Path(__file__).parent;S=D/'source';R=Path('/private/tmp/module33-public/source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while True:
 try:j=json.loads(Path('/private/tmp/module33-public/evidence.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):j={'status':'running'}
 assert j['status']!='failed',j.get('error')
 if j['status']=='passed':break
 time.sleep(5)
assert not S.exists();subprocess.run(['cp','-cR',str(R),str(S)],check=True);shutil.copyfile(D/'slice_encode.rs',S/'benches/slice_encode.rs')
with (S/'Cargo.toml').open('a') as f:f.write('\n[[bench]]\nname="slice_encode"\nharness=false\nrequired-features=["std"]\n')
subprocess.run(['cargo','fmt','--all'],cwd=S,check=True);shutil.copyfile(S/'benches/slice_encode.rs',D/'slice_encode.rs')
e=dict(status='running',source_sha256=sha(S/'benches/slice_encode.rs'),commands=[]);env={**os.environ,'CARGO_TARGET_DIR':str(D/'harness-target'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'harness-check.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,args in [('safe',['cargo','clippy','--offline','--locked','--bench','slice_encode','--','-D','warnings']),('all',['cargo','clippy','--offline','--locked','--bench','slice_encode','--all-features','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check'])]:
  t=time.monotonic()
  with (D/('harness-'+name+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/('harness-'+name+'.log'))));save();assert p.returncode==0,name
 e['status']='passed';save();subprocess.run(['python3',str(D/'build.py')],check=True);subprocess.run(['python3',str(D/'repeat-build.py')],check=True)
except BaseException as ex:
 if e['status']=='running':e.update(status='failed',error=repr(ex));save()
 raise
