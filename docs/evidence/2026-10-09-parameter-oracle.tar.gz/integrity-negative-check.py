import copy
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile

root = Path('/Users/lanxingcan/Workspace/zstdoxize')
spec = importlib.util.spec_from_file_location('audit', root / 'scripts/check_upstream_fixtures.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
with tempfile.TemporaryDirectory(prefix='zstdoxide-parameter-integrity-') as name:
    temporary = Path(name)
    shutil.copytree(root / 'tests/upstream', temporary / 'tests/upstream')
    for collection in audit.REQUIRED_COLLECTIONS + audit.OPTIONAL_COLLECTIONS:
        base = temporary / 'tests/upstream' / collection
        manifest = base / ('provenance.json' if collection == 'entropy-lifetimes' else 'manifest.json')
        if not manifest.exists():
            continue
        record = json.loads(manifest.read_text())
        sources = [record[role] for role in ('generator', 'importer') if role in record]
        sources.extend(record.get('repository_input_sha256', {}))
        for source in sources:
            destination = temporary / source
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(root / source, destination)
    errors, collections, count = audit.audit_fixtures(temporary)
    assert not errors, errors
    assert (collections, count) == (9, 319), (collections, count)
    path = temporary / 'tests/upstream/parameters/manifest.json'
    original = json.loads(path.read_text())
    cases = []
    for label, mutate, expected in [
        ('importer_hash', lambda m: m.update(importer_sha256='0' * 64), 'local importer SHA-256 differs'),
        ('repository_input_hash', lambda m: m['repository_input_sha256'].update({'tests/upstream/dictionaries/formatted.dict': '0' * 64}), 'local repository input SHA-256 differs'),
        ('importer_traversal', lambda m: m.update(importer='../outside.py'), 'missing or invalid local importer'),
        ('repository_input_traversal', lambda m: m.update(repository_input_sha256={'../outside.dict': '0' * 64}), 'missing or invalid local repository input'),
    ]:
        changed = copy.deepcopy(original)
        mutate(changed)
        path.write_text(json.dumps(changed))
        errors, _, _ = audit.audit_fixtures(temporary)
        assert any(expected in error for error in errors), (label, errors)
        cases.append(label)
    path.write_text(json.dumps(original))
    payload = temporary / 'tests/upstream/parameters/bounds.tsv'
    payload.write_bytes(payload.read_bytes() + b'corruption\n')
    errors, _, _ = audit.audit_fixtures(temporary)
    assert any('parameters/bounds.tsv: SHA-256 differs' in error for error in errors), errors
    cases.append('fixture_corruption')
    print(json.dumps({'baseline': {'files': count, 'collections': collections}, 'rejected': cases}, sort_keys=True))
