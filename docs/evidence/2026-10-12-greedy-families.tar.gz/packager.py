from pathlib import Path
import gzip,hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');U=Path('/tmp/zstdoxize-upstream-1.5.7').resolve();root=Path('/tmp/zstdoxide-greedy-families-2026-10-12')
e=json.loads((root/'evidence.json').read_bytes());files={}
def sha(b):return hashlib.sha256(b).hexdigest()
def put(name,p):
 if name in files:raise ValueError('duplicate member')
 files[name]=p.read_bytes()
if e['status']!='passed' or len(e['commands'])!=444:raise ValueError('capture incomplete')
for p in sorted(root.rglob('*')):
 if p.is_file() and not p.relative_to(root).parts[0].startswith('c-'):put('capture/'+str(p.relative_to(root)),p)
for n,d in e['source_before'].items():
 if sha((R/n).read_bytes())!=d or e['source_after'][n]!=d:raise ValueError('source changed '+n)
 put('source/'+n,R/n)
reference=set()
for build in e['builds'].values():
 reference.update(build['compiled_codec_sources'])
 for n in build['dependencies']:
  p=Path(n)
  if p.is_relative_to(U):reference.add(str(p.relative_to(U)))
for n in sorted(reference):
 if sha((U/n).read_bytes())!=e['upstream_source_sha256'][n]:raise ValueError('reference changed')
 put('reference/'+n,U/n)
if len(reference)!=63:raise ValueError('reference closure')
for mode in ('normal','optimized'):
 p=Path('/tmp/zstdoxide-greedy-family-controls-'+mode+'.log');d=json.loads(p.read_bytes())
 if (d['positive'],d['rejected'],d['child_processes'])!=(2,30,0):raise ValueError('offline controls')
 put('controls/'+mode+'.json',p)
put('controls/run.py',Path('/tmp/zstdoxide-greedy-family-controls.py'))
put('coverage.json',Path('/tmp/zstdoxide-greedy-family-coverage.json'));put('coverage.py',Path('/tmp/zstdoxide-greedy-family-coverage.py'))
put('checker.py',R/'scripts/check_greedy_family_capture.py');put('packager.py',Path(__file__))
for n in ('recipes.json','capture.json','observations.ndjson'):put('fixture/'+n,R/'tests/fixtures/reference-greedy-families'/n)
files['members.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())},sort_keys=True,indent=2)+'\n').encode()
archive=R/'docs/evidence/2026-10-12-greedy-families.tar.gz'
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w|') as t:
   for n,b in sorted(files.items()):
    info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
 read={m.name:t.extractfile(m).read() for m in t if m.isfile()}
if read!=files:raise ValueError('archive bytes/member inventory')
report={'status':'passed','scope':e['scope'],'commands':444,'totals':e['totals'],'archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'members':len(files),'uncompressed_bytes':sum(map(len,files.values())),'reference_source_files':len(reference),'context_peak_guarded_bytes':e['context_peak_guarded_bytes'],'controls_per_python_mode':{'positive':2,'rejected':30,'child_processes':0},'checker_sha256':sha((R/'scripts/check_greedy_family_capture.py').read_bytes()),'observed_coverage':json.loads(files['coverage.json']),'qualification':'Constructed direct states, not ordinary frame trajectories, per-probe instrumentation, public Rust support or performance evidence. Every linked C unit instrumented; upstream per-function exclusions retained. Opaque fresh-context allocation peaks are mode-qualified. Binaries/objects omitted with their identities retained; all logs, packets, sources, controls and complete observations preserved.','fixture':{n:sha((R/'tests/fixtures/reference-greedy-families'/n).read_bytes()) for n in ('recipes.json','capture.json','observations.ndjson')}}
(R/'docs/evidence/2026-10-12-greedy-families.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('status','archive_bytes','archive_sha256','members','uncompressed_bytes','totals')},sort_keys=True))
