from pathlib import Path
import json,hashlib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');F=R/'tests/fixtures/reference-greedy-families'
p=(F/'observations.ndjson').read_bytes()
if hashlib.sha256(p).hexdigest()!='0366364cb7a1123cf0e9580770037a50df5c23bcba89a4c47fd1bed8bc3c0d27':raise ValueError('frozen pack')
e=json.loads((F/'capture.json').read_bytes());rows={}
for n,r in e['records'].items():
 if n.startswith('salt-'):continue
 rows[n]=json.loads(p[r['offset']:r['offset']+r['bytes']].splitlines()[1])
def check(x,msg):
 if not x:raise ValueError(msg)
out={}
for branch in ('chain','row'):
 def row(s):return rows[branch+'-'+s]
 distances=[]
 for d in (1023,1024,1025):distances.append([s['distance'] for s in row('moving-floor-'+str(d))['sequences']])
 check(distances==[[1023],[1024],[]],'moving floor')
 head=row('maximum-history-head')['sequences'];check(len(head)==1 and (head[0]['ll'],head[0]['ml'],head[0]['distance'])==(0,64,2097152),'old valid head')
 ml=[]
 for n in (65541,65542,65543,65544):
  r=row('long-match-'+str(n));s=r['sequences'];check(len(s)==1,'long ML sequence count');s=s[0]
  ml.append([n,r['long_length_type'],s['raw_ml_base'],s['ml']]);check(s['ll']==4 and s['ml']==n-4 and r['long_length_type']==(2 if n>=65543 else 0),'long ML boundary')
 literals=[]
 for n in (65500,65535,65536):
  r=row('long-literals-'+str(n));check(r['long_length_type']==1 and len(r['sequences'])==1,'long LL observed')
  literals.append([n,r['sequences'][0]['ll']])
 skip={str(n):row('skip-tail-'+str(n))['final_lazy_skipping'] for n in (2047,2048,2049,2055,2064,4096)}
 check(skip['4096']==1 and row('skip-then-period')['final_lazy_skipping']==0,'final skipping flags')
 out[branch]={'moving_floor_distances':distances,'maximum_history_head':head,'long_match_boundary':ml,'long_literal_splits':literals,'final_skipping':skip,'skip_then_period':row('skip-then-period')['sequences'],'pending_gap_changed_positions':{str(n):len(row('pending-gap-'+str(n))['first_table']['changes']) for n in (383,384,385,575,576,577)}}
check(not rows['chain-distinct-keys-c6']['sequences'] and rows['chain-distinct-keys-c7']['sequences'][0]['distance']==128,'ring cutoff difference')
out['chain']['distinct_collision_c6']=rows['chain-distinct-keys-c6']['sequences'];out['chain']['distinct_collision_c7']=rows['chain-distinct-keys-c7']['sequences']
out['row']['reserved_head_wrap']=[]
for w in (16,32,64):
 for n in (w-1,w,w+1):
  r=rows[f'row-width-{w}-insertions-{n}'];before=r['first_table']['before'];base=before[0][0]//w*w
  head=dict(r['second_table']['before'])[base];check(head==w-1-((n-1)%(w-1)),'initial reserved-head wrap')
  check(len(before)==w-1 and all(i%w!=0 for i,v in before),'reserved position and occupancy')
  check(r['sequences'][0]['distance']==20,'newest equal-length candidate')
  out['row']['reserved_head_wrap'].append({'width':w,'insertions':n,'initial_head':head,'occupied_positions':len(before),'first_sequence':r['sequences'][0]})
for s in (2,4,16,256):check(rows[f'chain-tie-budget-{s}']['sequences'][0]['distance']==20,'chain newest equal length')
check(out['row']['pending_gap_changed_positions']=={'383':384,'384':385,'385':129,'575':129,'576':129,'577':129},'direct long gap')
check(rows['row-entropy-wrap']['final_entropy']==(rows['row-skip-tail-4096']['final_entropy']-16)%2**32,'entropy wrapping addition')
out['row']['entropy_wrap']={'initial':rows['row-entropy-wrap']['initial_entropy'],'final':rows['row-entropy-wrap']['final_entropy'],'zero_initial_final':rows['row-skip-tail-4096']['final_entropy']}
out['qualification']='Observed final maps and sequences, not chronological per-probe traces. Long LL cases all exceed 65535, not an exact LL cutoff bracket. Pending-gap cases do not exercise the ordinary wrapper. Explicit branches do not establish public selection. Malformed cyclic/future table cells require separate Rust leaf controls; the C helper accepts only valid seed construction.'
print(json.dumps(out,sort_keys=True,indent=2))
