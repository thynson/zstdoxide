from pathlib import Path
import os,subprocess,json,time,hashlib,tomllib,re
D=Path(__file__).parent;S=Path('/private/tmp/module30-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'));env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module30-public-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
e=dict(status='running',source={str(p.relative_to(S)):sha(p) for p in (S/'src').rglob('*.rs')},test_source_sha256=sha(S/'tests/frame_queries.rs'),commands=[])
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,count=None):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
 row=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log')));e['commands'].append(row);save();assert p.returncode==0,label
 if count is not None:
  g=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (D/(label+'.log')).read_text());assert sum(int(x) for x,_,_ in g)==count and all(int(f)==int(i)==0 for _,f,i in g),(label,g)
 print(label,'passed',flush=True)
save()
try:
 for name,flags,no in [('safe',[],[]),('cursor',['--features','unsafe-byte-cursor'],['--features','unsafe-byte-cursor']),('all',['--all-features'],['--features',','.join(features)])]:
  run(name+'-unit',['cargo','test','--offline','--locked','--lib',*flags,'frame_layout::tests::'],9)
  run(name+'-public',['cargo','test','--offline','--locked','--test','frame_queries',*flags],7)
  run(name+'-docs',['cargo','test','--offline','--locked','--doc',*flags,'frame_layout::'],4)
  run(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*no])
  run(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])
 run('format',['cargo','fmt','--all','--','--check'])
 for n,h in e['source'].items():assert sha(S/n)==h,n
 assert sha(S/'tests/frame_queries.rs')==e['test_source_sha256'];e.update(status='passed',qualification='Safe/cursor/all public metadata/size/bound/borrowed skip queries, preserved margin tests, documentation lifetime rejection, true no_std and strict Clippy. Full regression, native/platform/original assertions and timing remain separate.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
