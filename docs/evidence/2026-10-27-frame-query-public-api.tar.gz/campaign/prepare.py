from pathlib import Path
import shutil
D=Path(__file__).parent;S=Path('/private/tmp/module30-candidate');C=Path('/private/tmp/module30-layout/source');S.mkdir()
for n in ['src','tests','test-support','benches']:shutil.copytree(C/n,S/n)
for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(C/n,S/n)
p=S/'src/frame_layout.rs';s=p.read_text().replace('    header: Option<FrameHeader>,','    header: Option<FrameHeader>,\n    skippable_variant: u8,').replace('                header: None,','                header: None,\n                skippable_variant: (magic & 15) as u8,').replace('            header: Some(header),','            header: Some(header),\n            skippable_variant: 0,').replace('            header: None,\n        };','            header: None,\n            skippable_variant: 0,\n        };')
api=Path('/private/tmp/module30-public/api.rs').read_text();s=s.replace('/// Compute a sufficient extra capacity',api+'\n/// Compute a sufficient extra capacity');p.write_text(s)
p=S/'src/lib.rs';s=p.read_text();needle='pub use frame_layout::decompression_margin;';assert needle in s;p.write_text(s.replace(needle,'pub use frame_layout::{FrameInfo, FrameKind, decompression_margin, frame_info, frame_compressed_size, decompressed_size, decompression_bound, is_skippable_frame, skippable_payload};'))
shutil.copyfile(D/'frame_queries.rs',S/'tests/frame_queries.rs')
