from pathlib import Path
import json,shutil
D=Path(__file__).parent;S=Path('/private/tmp/module30-candidate');j=json.loads((D/'evidence.json').read_text());assert j['status']=='failed' and j['error']=="AssertionError('safe-public')"
P=D/'initial-test-call-rejection';P.mkdir()
for p in list(D.iterdir()):
 if p.is_file() and (p.name in ['evidence.json','check.py'] or p.suffix=='.log'):shutil.copyfile(p,P/p.name)
for name in ['frame_queries.rs','dictionary_in_place_output_platform.rs']:shutil.copyfile(S/'tests'/name,P/name)
p=S/'tests/frame_queries.rs';s=p.read_text()
for n in ['frame','mismatched','invalid']:s=s.replace('decompress(&'+n+')','decompress(&'+n+', 16)')
p.write_text(s);shutil.copyfile('/private/tmp/module29-final/tests/dictionary_in_place_output_platform.rs',S/'tests/dictionary_in_place_output_platform.rs')
for p in list(D.iterdir()):
 if p.is_file() and (p.name=='evidence.json' or p.suffix=='.log'):p.unlink()
(D/'repair.json').write_text(json.dumps(dict(status='prepared',qualification='The initial public test helper omitted required output limits from three existing decompress calls. Corrected calls use limit16. The predecessor platform fixture type alias correction is also synchronized. Production source is unchanged; focused checks restart on the corrected tests and initial failure logs/source remain retained.'),indent=2)+'\n')
