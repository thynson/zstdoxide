from pathlib import Path
import hashlib,json,subprocess,sys,time,tomllib
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-reference-public-final-2026-10-12');OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'scripts'));import benchmark_search
ENV=benchmark_search.effective_environment()|{'CARGO_TARGET_DIR':'/tmp/zstdoxide-double-fast-plan-target','CARGO_NET_OFFLINE':'true','CARGO_TERM_COLOR':'never'}
changed=['src/fast_plan.rs','src/double_fast_plan.rs','src/reference_search.rs','src/reference_frame_encode.rs','src/reference_encode.rs','tests/reference_fast.rs','tests/reference_double_fast.rs','tests/upstream_reference_fast.rs']
paths=list((ROOT/'src').rglob('*.rs'))+[ROOT/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/reference_fast_defaults.rs','tests/match_search_defaults.rs',*changed,'scripts/check_reference_interop_v2.py','scripts/check_reference_admission_v2.py']]+list((ROOT/'tests/fixtures/reference-admission-v2').iterdir())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source():return {str(p.relative_to(ROOT)):sha(p) for p in sorted(set(paths))}
e={'date':'2026-10-12','status':'running','scope':'Public known-size Fast/DoubleFast admission, actual resolved caps, default0/3 equivalence, all four level4 tiers, public allocator failures, version2 official expectations, frozen Fast/named baselines. This run makes no C, Miri or timing claim.','source':source(),'environment':ENV,'commands':[]}
def save():(OUT/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
def run(label,args):
 start=time.monotonic();p=OUT/(label+'.log')
 with p.open('wb') as f:r=subprocess.run(args,cwd=ROOT,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 e['commands'].append({'label':label,'argv':args,'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':p.name,'log_sha256':sha(p)});save();print(label,r.returncode,flush=True)
 if r.returncode:raise RuntimeError(label)
cargo=['cargo','+nightly-2026-10-08'];flags=[x for x in tomllib.loads((ROOT/'Cargo.toml').read_text())['features'] if x not in ['default','std']]
try:
 run('rustc',['rustc','+nightly-2026-10-08','-vV'])
 for name,features in [('safe',[]),('table',['--features','unsafe-match-table']),('all',['--all-features']),('nostd',['--no-default-features']),('nostd-all',['--no-default-features','--features',','.join(flags)])]:
  run('public-'+name,cargo+['test','--offline','--locked','--test','reference_double_fast','--test','reference_fast','--test','upstream_reference_fast']+features)
 for name,features in [('safe',[]),('all',['--all-features'])]:
  run('plans-'+name,cargo+['test','--offline','--locked','--lib','fast_plan::tests::']+features)
  run('workspace-'+name,cargo+['test','--offline','--locked','--lib','reference_frame_encode::']+features)
  run('baselines-'+name,cargo+['test','--offline','--locked','--test','reference_fast_defaults','--test','match_search_defaults']+features)
  run('docs-'+name,cargo+['test','--offline','--locked','--doc','reference_encode::']+features)
  run('clippy-'+name,cargo+['clippy','--offline','--locked','--all-targets']+features+['--','-D','warnings'])
 for name,features in [('safe',[]),('all',['--features',','.join(flags)])]:
  run('nostd-'+name,cargo+['check','--offline','--locked','--no-default-features']+features)
 run('inventory',['python3','scripts/audit_upstream_tests.py'])
 run('format',['rustfmt','--edition','2024','--config','skip_children=true','--check',*changed])
 for optimized in [False,True]:
  run('policy-'+str(optimized),['python3']+(['-O'] if optimized else [])+['scripts/check_reference_admission_v2.py','--check'])
  run('interop-plan-'+str(optimized),['python3']+(['-O'] if optimized else [])+['scripts/check_reference_interop_v2.py','--check-plan'])
 e['source_unchanged']=source()==e['source'];assert e['source_unchanged'];e['status']='passed';save()
except BaseException as error:e['status']='failed';e['error']=repr(error);save();raise
