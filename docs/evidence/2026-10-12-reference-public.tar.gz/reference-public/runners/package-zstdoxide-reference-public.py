from pathlib import Path
import hashlib,io,json,re,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-reference-public-final-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
def require(v,m):
 if not v:raise ValueError(m)
e=json.loads((O/'evidence.json').read_bytes());require(e['status']=='passed' and e['source_unchanged'],'completed run')
for n,h in e['source'].items():require(sha((R/n).read_bytes())==h,'source '+n)
counts={}
for c in e['commands']:
 b=(O/c['log']).read_bytes();require(c['exit_code']==0 and sha(b)==c['log_sha256'],'command')
 results=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)
 require(all(f==b'0' and i==b'0' for _,f,i in results),'failure/ignored');counts[c['label']]=sum(int(n) for n,_,_ in results)
require(sum(counts.values())==229 and len(e['commands'])==24,'counts')
members={p.name:p.read_bytes() for p in O.iterdir() if p.is_file()}
for name in ['check-zstdoxide-reference-public.py','package-zstdoxide-reference-public.py']:members['runners/'+name]=(Path('/tmp')/name).read_bytes()
for n in e['source']:members['source/'+n]=(R/n).read_bytes()
for n in ['README.md','docs/reference-fast-usage.md','docs/parameter-usage.md','scripts/check.sh','scripts/check_upstream_oracles.sh','tests/upstream/manifest.json']:members['source/'+n]=(R/n).read_bytes()
for p in [Path('/tmp/zstdoxide-reference-public-bootstrap.log'),*[Path(f'/tmp/zstdoxide-reference-public-bootstrap{i}.log') for i in [2,3,4]]]:members['initial/'+p.name]=p.read_bytes()
for p in Path('/tmp/zstdoxide-reference-public-2026-10-12').iterdir():
 if p.is_file():members['initial/first-matrix/'+p.name]=p.read_bytes()
report={'date':'2026-10-12','status':'passed','commands':24,'tests':counts,'total_test_executions':229,'source':e['source'],'scope':e['scope'],'archive':'2026-10-12-reference-public.tar.gz','initial_diagnostics':['Incorrect Ultra2 enum spelling in a new test prevented compilation.','New level4 expectation omitted the >256KiB tier; corrected from pinned presets/design.','Existing frame inspection helper assumed Fast-only; expanded to both admitted strategies.','Pre-integration private plan test still asserted public level3 unsupported; obsolete assertion removed.'],'qualification':'Final matrix fully rerun after test corrections. C execution is archived separately; larger DoubleFast and platform/benchmark campaigns remain open.'}
def encoded(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
members['report.json']=encoded(report);members['manifest.json']=encoded({n:sha(b) for n,b in members.items()})
a=R/'docs/evidence'/report['archive'];require(not a.exists(),'fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('reference-public/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 found={m.name:t.extractfile(m).read() for m in t};require(found=={'reference-public/'+n:b for n,b in members.items()},'archive exact bytes')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(members))
(R/'docs/evidence/2026-10-12-reference-public.json').write_bytes(encoded(report));print(len(e['commands']),'commands',sum(counts.values()),'tests',len(members),'members')
