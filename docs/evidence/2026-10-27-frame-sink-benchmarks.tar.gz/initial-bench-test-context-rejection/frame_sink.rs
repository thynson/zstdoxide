//! Exact leaf-copy workloads; caller setup and validation are outside clocks.
#![cfg_attr(not(feature = "unsafe-frame-sink"), forbid(unsafe_code))]
#[allow(dead_code)]
#[path = "../src/error.rs"]
mod error;
#[path = "../src/frame_sink.rs"]
mod frame_sink;
use error::{Error, Result};
use frame_sink::FrameSink;
use std::{hint::black_box, time::Instant};
fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |h, &b| {
        (h ^ u64::from(b)).wrapping_mul(0x100000001b3)
    })
}
fn main() {
    let mode = std::env::args().nth(1).expect("qualify or measure");
    assert!(mode == "qualify" || mode == "measure");
    for (name, prefix_len, length, capacity) in [
        ("empty", 0, 0, 0),
        ("one", 0, 1, 1),
        ("header", 0, 18, 18),
        ("small", 0, 64, 64),
        ("page", 0, 4096, 4096),
        ("block", 0, 131075, 131075),
        ("short", 0, 32, 31),
        ("after-header", 18, 4096, 4114),
        ("after-block", 131075, 4, 131079),
        ("empty-after-full", 64, 0, 64),
        ("short-after-prefix", 32, 64, 95),
    ] {
        let payload: Vec<_> = (0..length).map(|i| (i * 17 + 23) as u8).collect();
        let prefix: Vec<_> = (0..prefix_len).map(|i| (i * 7 + 13) as u8).collect();
        let mut output = vec![0xa5; capacity + 32];
        let fits = length <= capacity - prefix_len;
        let expected = if fits {
            Ok(())
        } else {
            Err(Error::ResourceLimit)
        };
        let written = prefix_len + if fits { length } else { 0 };
        let iterations = if mode == "qualify" {
            1
        } else {
            (1024 * 1024 / length.max(1)).clamp(8, 1024)
        };
        let samples = if mode == "qualify" { 1 } else { 5 };
        for sample in 0..samples {
            let mut elapsed = 0;
            for _ in 0..iterations {
                output.fill(0xa5);
                {
                    let mut sink = FrameSink::new(&mut output[16..16 + capacity]);
                    sink.append(&prefix).unwrap();
                    if mode == "qualify" {
                        assert_eq!(sink.append(&payload), expected);
                    } else {
                        let start = Instant::now();
                        let result = black_box(&mut sink).append(black_box(&payload));
                        let _ = black_box(result.as_ref());
                        elapsed += start.elapsed().as_nanos();
                        assert_eq!(result, expected);
                    }
                    assert_eq!(sink.len(), written);
                    assert_eq!(&sink.written()[..prefix_len], prefix);
                    assert_eq!(
                        &sink.written()[prefix_len..],
                        if fits { payload.as_slice() } else { &[] }
                    );
                }
                assert!(
                    output[..16]
                        .iter()
                        .chain(&output[16 + written..])
                        .all(|&b| b == 0xa5)
                );
            }
            if mode == "qualify" {
                println!(
                    "{name}\t{prefix_len}\t{length}\t{capacity}\t{expected:?}\t{written}\t{:016x}",
                    fingerprint(&output)
                );
            } else {
                println!("{name}\tappend\t{sample}\t{iterations}\t{elapsed}");
            }
        }
    }
}
