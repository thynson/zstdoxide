from pathlib import Path
import json,subprocess,hashlib,os,shutil,time
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();component=json.loads(Path('/private/tmp/module33-storage/evidence.json').read_text());assert component['status']=='passed'
for n in ['src/frame_sink.rs','src/error.rs']:assert sha(S/n)==component['source'][n],n
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};e=dict(status='building',source=source,component_receipt_sha256=sha(Path('/private/tmp/module33-storage/evidence.json')),builds=[],commands=[])
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 env={**os.environ,'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(D/'target')}
 for name,flags in [('safe',[]),('unsafe',['--features','unsafe-frame-sink'])]:
  args=['cargo','clippy','--offline','--locked','--bench','frame_sink',*flags,'--','-D','warnings']
  with (D/(name+'-clippy.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=name+'-clippy',argv=args,exit_code=p.returncode,log_sha256=sha(D/(name+'-clippy.log'))));save();assert p.returncode==0,name
 with (D/'format.log').open('xb') as f:p=subprocess.run(['cargo','fmt','--all','--','--check'],cwd=S,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label='format',exit_code=p.returncode,log_sha256=sha(D/'format.log')));save();assert p.returncode==0
 for campaign in ['primary','repeat']:
  for name,flags in [('safe',[]),('unsafe',['--features','unsafe-frame-sink'])]:
   label=campaign+'-'+name;args=['cargo','bench','--offline','--locked','--bench','frame_sink','--no-run','--message-format=json',*flags];t=time.monotonic()
   with (D/(label+'-build.jsonl')).open('xb') as out,(D/(label+'-build.log')).open('xb') as err:p=subprocess.run(args,cwd=S,env={**env,'CARGO_TARGET_DIR':str(D/(campaign+'-target'))},stdout=out,stderr=err)
   assert p.returncode==0,label;artifacts=[json.loads(l) for l in (D/(label+'-build.jsonl')).read_text().splitlines() if l.startswith('{')];exes=[a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='frame_sink' and a.get('executable')];assert len(exes)==1
   exe=D/'executables'/label;exe.parent.mkdir(exist_ok=True);shutil.copyfile(exes[0],exe);exe.chmod(0o755);p=subprocess.run([str(exe),'qualify'],capture_output=True);(D/(label+'-qualify.tsv')).write_bytes(p.stdout);(D/(label+'-qualify.stderr')).write_bytes(p.stderr);assert p.returncode==0 and len(p.stdout.decode().splitlines())==11,(label,p.stderr)
   if label!='primary-safe':assert p.stdout==(D/'primary-safe-qualify.tsv').read_bytes()
   e['builds'].append(dict(campaign=campaign,name=name,argv=args,seconds=time.monotonic()-t,executable=str(exe.relative_to(D)),sha256=sha(exe),qualification_sha256=sha(D/(label+'-qualify.tsv'))));save();print(label,'qualified',flush=True)
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='qualified-not-timed',qualification='Exact isolated leaf only. Safe/unsafe each independently rebuilt in primary/repeat target directories;11 identical result/guard identities. Caller allocation, buffer fill and prefix setup are outside timing. No runtime allocator counters or whole-codec compression claim. Measurements remain unexecuted.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
