from pathlib import Path
import json,hashlib,subprocess,datetime,time,os,re,signal,statistics,math
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();b=json.loads((D/'evidence.json').read_text());assert b['status']=='qualified-not-timed' and len(b['builds'])==4 and len(b['commands'])==3
for n,h in b['source'].items():assert sha(D/'source'/n)==h,n
for r in b['builds']:assert sha(D/r['executable'])==r['sha256'];assert (D/(r['campaign']+'-'+r['name']+'-qualify.tsv')).read_bytes()==(D/'primary-safe-qualify.tsv').read_bytes()
gates={}
for n in ['module33-storage/evidence.json','module33-storage/integration.json',*[f'module{m}-matrix/evidence.json' for m in [28,29,30,31,32]],*[f'module{m}-benchmark'+('-v2' if m==31 else '')+f'/{c}timed.json' for m in [31,32] for c in ['', 'repeat/']]]:
 p=Path('/private/tmp')/n;assert json.loads(p.read_text())['status']=='passed',n;gates[n]=sha(p)
assert not (D/'timed.json').exists();deadline=datetime.datetime(2026,10,28,9,38,0,tzinfo=datetime.timezone.utc).timestamp();e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),gates=gates,build_evidence_sha256=sha(D/'evidence.json'),barriers={},runs=[])
def save():(D/'timed.json').write_text(json.dumps(e,indent=2)+'\n')
pattern=re.compile(r'(?:/|\s)(?:rustc|cargo|cc|clang)(?:\s|$)|/private/tmp/module(?:2[3-9]|3[0-4])-[^ ]*(?:target/|/(?:check[^ /]*|run[^ /]*|build[^ /]*|capture|generate|repeat-build|after-build|resume-arm|prepare[^ /]*|archive[^ /]*|prune[^ /]*)\.py)')
qual=[l.split('\t') for l in (D/'primary-safe-qualify.tsv').read_text().splitlines()];cases={r[0] for r in qual};assert len(cases)==11
save()
try:
 for campaign in ['primary','repeat']:
  observations=[]
  while len(observations)<2:
   raw=subprocess.check_output(['ps','-axo','pid,ppid,pcpu,etime,command'],text=True);active=[l.strip() for l in raw.splitlines()[1:] if int(l.split()[0])!=os.getpid() and pattern.search(l)]
   if active:observations=[]
   else:observations.append(dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),active_processes=active))
   if time.time()>deadline-30:raise TimeoutError('User deadline before component measurement')
   time.sleep(5)
  e['barriers'][campaign]=observations;save()
  for r in [x for x in b['builds'] if x['campaign']==campaign]:
   label=campaign+'-'+r['name'];remaining=deadline-time.time()-30;assert remaining>0
   p=subprocess.Popen([str(D/r['executable']),'measure'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
   try:out,err=p.communicate(timeout=remaining)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);p.communicate();raise TimeoutError('User deadline during '+label)
   (D/(label+'-timed.tsv')).write_bytes(out);(D/(label+'-timed.stderr')).write_bytes(err);assert p.returncode==0,(label,err)
   rows=[l.split('\t') for l in out.decode().splitlines()];assert len(rows)==55 and {(a,m,int(i)) for a,m,i,_,_ in rows}=={(c,'append',s) for c in cases for s in range(5)};assert all(8<=int(n)<=1024 and int(t)>0 for _,_,_,n,t in rows)
   e['runs'].append(dict(campaign=campaign,backend=r['name'],rows=55,sha256=sha(D/(label+'-timed.tsv')),executable_sha256=r['sha256']));save();print(label,'55 samples',flush=True)
 for n,h in b['source'].items():assert sha(D/'source'/n)==h,n
 index={}
 for r in e['runs']:
  groups={}
  for line in (D/(r['campaign']+'-'+r['backend']+'-timed.tsv')).read_text().splitlines():
   c,_,_,n,t=line.split('\t');groups.setdefault(c,[]).append(int(t)/int(n))
  for c,values in groups.items():assert len(values)==5;index[r['campaign'],r['backend'],c]=statistics.median(values)
 summaries=[]
 for campaign in ['primary','repeat']:
  ratios={c:index[campaign,'unsafe',c]/index[campaign,'safe',c] for c in sorted(cases)};nonempty=[ratios[q[0]] for q in qual if int(q[2])>0];assert len(nonempty)==9;summaries.append(dict(campaign=campaign,unsafe_over_safe=ratios,nonempty_request_geomean=math.exp(sum(map(math.log,nonempty))/len(nonempty))))
 e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),summary=summaries,qualification='Exact isolated sink only,11 deterministic cases/5 samples each. Fresh sink and optional prefix setup, allocation/fill and all assertions outside per-operation clocks; bounds/copy/position publication inside. All55 samples retained per executable. Nine nonempty requested-source cases include two capacity rejections; both zero-length append cases remain separate. Tiny/rejected operations include clock overhead. No global allocator counts, desktop idleness, statistical significance, whole-codec compression performance or universal unsafe benefit claimed.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
