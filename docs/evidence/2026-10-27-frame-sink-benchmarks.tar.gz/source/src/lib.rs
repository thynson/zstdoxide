#![no_std]
#![cfg_attr(not(feature = "unsafe-frame-sink"), forbid(unsafe_code))]
// This component validates the exact proposed leaf in isolation. Full codec
// integration and feature qualification are separate gates.
#[allow(dead_code)]
mod error;
#[allow(dead_code)]
mod frame_sink;
use error::{Error, Result};
#[cfg(test)]
extern crate alloc;
