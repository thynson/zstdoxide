from pathlib import Path
import json,hashlib,tarfile
E=Path(__file__).parent;D=Path('/private/tmp/module33-benchmark');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();b=json.loads((D/'evidence.json').read_text());t=json.loads((D/'timed.json').read_text());assert b['status']=='qualified-not-timed' and t['status']=='passed' and len(b['builds'])==len(t['runs'])==4;assert sha(D/'evidence.json')==t['build_evidence_sha256']
for n,h in b['source'].items():assert sha(D/'source'/n)==h,n
for r in b['builds']:assert sha(D/r['executable'])==r['sha256'];assert sha(D/(r['campaign']+'-'+r['name']+'-qualify.tsv'))==r['qualification_sha256']
for r in t['runs']:assert sha(D/(r['campaign']+'-'+r['backend']+'-timed.tsv'))==r['sha256']
for n,h in t['gates'].items():assert sha(Path('/private/tmp')/n)==h,n
files={str(p.relative_to(D)):p for p in D.rglob('*') if p.is_file() and not any(x=='target' or x.endswith('-target') or x=='__pycache__' for x in p.relative_to(D).parts)};files['archive-benchmark.py']=Path(__file__)
name='2026-10-27-frame-sink-benchmarks';archive=E/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for n,p in sorted(files.items()):tar.add(p,arcname=n)
j=dict(status='passed',scope='isolated-component-only',build=b,timing=t,members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()},archive=archive.name,archive_sha256=sha(archive),qualification=t['qualification']);(E/(name+'.json')).write_text(json.dumps(j,indent=2)+'\n')
s='''# Checked frame-sink measurements

This benchmark measures the isolated append leaf, not a complete compression API.
Both primary and independent repeat rebuilds retain safe/unsafe executables from
identical leaf bytes. Eleven deterministic cases include zero/one/header/page/
maximum-block copies, nonzero written prefixes, full-buffer empty append and two
short-destination rejections. Every executable has55 retained samples, five per
case, with deterministic8..1024 iterations.

Caller allocation/fill and prefix setup are outside clocks. Only checked append
is timed, including validation, copying when admitted and position publication.
Full bytes, guards and unchanged failed appends are checked outside clocks. Core-
only component proof establishes no allocator dependency; qualification rows are
result identities, not dynamic allocation counters. Two fresh process inventories
precede each sequential campaign after all recorded task CPU gates finish.
Whole-desktop idleness, statistical significance or general unsafe benefit is not
claimed. Tiny and rejected operations can be dominated by clock overhead.

| Case | Primary unsafe / safe | Repeat unsafe / safe |
| --- | ---: | ---: |
'''
a,c=t['summary'];assert a['campaign']=='primary' and c['campaign']=='repeat'
for case,v in a['unsafe_over_safe'].items():s+=f"| {case} | {v:.4f} | {c['unsafe_over_safe'][case]:.4f} |\n"
s+=f"\nEqual-weight geometric means across nine nonempty requested-source cases are {a['nonempty_request_geomean']:.4f} primary and {c['nonempty_request_geomean']:.4f} repeat. This aggregate includes two rejected appends; the two zero-length cases remain separate. Lower ratios mean lower observed median latency on this host.\n\nThe archive contains exact source, all four executables, eleven identical result/guard rows per build, all raw samples, process observations and the initial benchmark-only cfg(test) preparation rejection. Production leaf bytes never changed. Evidence: `evidence/{name}.json`.\n"
(E/'frame-sink-benchmarks.md').write_text(s);print(name,archive.stat().st_size)
