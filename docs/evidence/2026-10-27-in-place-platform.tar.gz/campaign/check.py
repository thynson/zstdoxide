from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,tomllib,concurrent.futures
R=Path('/private/tmp/module28-candidate');D=Path(__file__).parent;S=D/'source';S.mkdir()
for n in ['src','test-support','benches']:shutil.copytree(R/n,S/n)
for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/in_place_output_platform.rs']:
 p=S/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(D/'in_place_output_platform.rs' if n=='tests/in_place_output_platform.rs' else R/n,p)
shutil.copytree(R/'tests/upstream/decodecorpus',S/'tests/upstream/decodecorpus')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()}
env={**os.environ,'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
e={'status':'running','source':source,'commands':[]}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,cwd,extra):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=cwd,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT)
 row={'label':label,'argv':args,'environment':extra,'exit_code':p.returncode,'seconds':time.monotonic()-t};(D/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode:raise ValueError(label)
 return row
save()
def interpret(target,suffix):
 rows=[]
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  row=run(suffix+'-'+name,['cargo','miri','test','--offline','--locked','--target',target,'--test','in_place_output_platform',*flags,'overlapping_moves_disjoint_compressed_history_and_guards','--','--exact'],S,{'CARGO_TARGET_DIR':str(D/('miri-'+suffix)),'MIRI_SYSROOT':'/private/tmp/zstdoxide-ultra-miri-'+suffix,'MIRIFLAGS':'-Zmiri-strict-provenance'})
  assert '1 passed; 0 failed; 0 ignored' in (D/(row['label']+'.log')).read_text();rows.append(row)
 return rows
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(interpret,t,s) for t,s in [('i686-unknown-linux-gnu','i686'),('s390x-unknown-linux-gnu','s390x')]]
  for f in concurrent.futures.as_completed(futures):e['commands']+=f.result();save()
 probe=D/'probe';shutil.copytree(S,probe)
 with (probe/'src/lib.rs').open('a') as f:f.write('\n// Instantiate shared-buffer decoding, including real raw overlap, on ARM.\n#[inline(never)]\npub fn in_place_output_codegen_probe(bytes: &mut [u8], input_start: usize, limit: usize) -> Result<usize> {\n    decompress_in_place_with_options(bytes, input_start, DecodeOptions::new(limit))\n}\n')
 features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
 for name,flags in [('safe',[]),('all',['--features',','.join(features)])]:
  common=['--offline','--locked','-Zbuild-std=core,alloc','--target','thumbv6m-none-eabi','--no-default-features','--lib',*flags]
  e['commands'].append(run('thumb-'+name+'-check',['cargo','check',*common],S,{'CARGO_TARGET_DIR':str(D/'thumb-check')}));save()
  target=D/('thumb-'+name)
  e['commands'].append(run('thumb-'+name+'-objects',['cargo','rustc','--release',*common,'--','--emit=llvm-ir,obj'],probe,{'CARGO_TARGET_DIR':str(target)}));save()
  ir=[p for p in target.rglob('*.ll') if any(line.startswith(b'define ') and b'in_place_output_codegen_probe' in line for line in p.read_bytes().splitlines())];assert len(ir)==1
  assert b'llvm.memmove' in ir[0].read_bytes(), 'Actual overlap operation not instantiated'
  objects=list(ir[0].parent.glob('*.o'));assert objects
  artifacts=[]
  for p in [ir[0],*objects]:
   if p.suffix=='.o':
    h=p.read_bytes()[:20];assert h[:6]==b'\x7fELF\x01\x01' and int.from_bytes(h[18:20],'little')==40
   q=D/'artifacts'/(name+'-'+p.name);q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q);artifacts.append({'path':str(q.relative_to(D)),'sha256':sha(q)})
  e.setdefault('artifacts',{})[name]=artifacts;save()
 for n,h in source.items():
  assert sha(S/n)==h,n
  assert sha(D/'in_place_output_platform.rs' if n=='tests/in_place_output_platform.rs' else R/n)==h,n
 e.update(status='passed',qualification='Four strict-provenance foreign Miri test executions on i686/s390x and two actual thumbv6m core+alloc checks plus concrete LLVM IR/ARM object builds. Interpretation/code generation, not native execution on foreign hardware. Full regression and performance remain separate.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
