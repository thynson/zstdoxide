from pathlib import Path
import os,subprocess,json,hashlib,time
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();e=dict(status='running',source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()},commands=[]);env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for label,args in [(name,['cargo','test','--offline','--locked','--test','upstream_decodecorpus',*flags,'every_generated_frame_and_concatenation_has_checked_structural_metadata','--','--exact']) for name,flags in [('safe',[]),('cursor',['--features','unsafe-byte-cursor']),('all',['--all-features'])]]+ [('clippy',['cargo','clippy','--offline','--locked','--test','upstream_decodecorpus','--all-features','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check'])]:
  t=time.monotonic()
  with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log'))));save();assert p.returncode==0,label
  if label in ['safe','cursor','all']:assert '1 passed; 0 failed; 0 ignored' in (D/(label+'.log')).read_text()
 for n,h in e['source'].items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='Supplemental metadata/size/bound queries cover every unchanged official decodecorpus frame and their complete concatenation with interspersed borrowed skips, full-byte fixture identities, truncation and trailing-junk rejection. Safe/cursor/all plus focused strict Clippy/format pass. No new original generator assertion is claimed.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
