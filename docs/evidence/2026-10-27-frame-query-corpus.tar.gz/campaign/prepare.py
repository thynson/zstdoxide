from pathlib import Path
import shutil
D=Path(__file__).parent;S=D/'source';C=Path('/private/tmp/module30-candidate');S.mkdir()
for n in ['src','tests','test-support','benches']:shutil.copytree(C/n,S/n)
for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(C/n,S/n)
with (S/'tests/upstream_decodecorpus.rs').open('a') as f:f.write((D/'supplement.rs').read_text())
