from pathlib import Path
import hashlib,io,json,re,tarfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-double-fast-frame-encode-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
e=json.loads((OUT/'evidence.json').read_bytes());assert e['status']=='passed' and e['source_unchanged']
for n,h in e['source'].items():assert sha((ROOT/n).read_bytes())==h,n
ordinals={'empty':1,'first_uniform':25,'literal_tree':50,'mixed_fallback':56,'raw_then_copy':39,'table_l6_s18':50,'table_l18_s6':50}
for c in e['commands']:
 assert c['exit_code']==0;b=(OUT/c['log']).read_bytes();assert sha(b)==c['log_sha256']
 counts=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)
 if c['label'].startswith('frames-'):assert counts==[(b'6',b'0',b'0')]
 if c['label'].startswith('fast-workspace-'):assert counts==[(b'9',b'0',b'0')]
 if c['label'].startswith('baselines-'):assert counts==[(b'7',b'0',b'0'),(b'4',b'0',b'0')]
 if c['label'] in ('frames-safe','frames-table','frames-all'):
  observed={n.decode():int(v) for n,v in re.findall(rb'DoubleFast allocation failures: ([a-z0-9_]+) ordinals=1\.\.=([0-9]+)',b)}
  assert observed==ordinals,c['label']
  assert b'DoubleFast scheduled kinds=[88, 6, 66]; changed raw=13; changed RLE=3; complete Rust frames=101' in b
members={p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()}
members['runner.py']=Path('/tmp/check-zstdoxide-double-fast-frame-encode.py').read_bytes();members['package.py']=Path(__file__).read_bytes()
for n in ['src/reference_frame_encode.rs','tests/support/double_fast_frame_encode.rs','src/lib.rs']:
 members['source/'+n]=(ROOT/n).read_bytes()
members['bootstrap.log']=Path('/tmp/zstdoxide-double-fast-frame-encode-bootstrap.log').read_bytes()
report={'date':'2026-10-12','status':'passed','commands':len(e['commands']),'double_fast_frame_test_executions':30,'fast_workspace_test_executions':18,'baseline_test_executions':22,'total_test_executions':70,'ignored':0,'source':e['source'],'scope':e['scope'],'archive':'2026-10-12-double-fast-frame-encode.tar.gz','initial_diagnostics':0,'main_recipe_frames_per_configuration':101,'scheduled_blocks_per_configuration':160,'logged_std_block_kinds':{'raw':88,'rle':6,'compressed':66},'logged_std_discarded_repeat_witnesses':{'raw':13,'rle':3},'logged_std_failure_ordinals':ordinals,'logged_std_failures_per_configuration':sum(ordinals.values()),'count_qualification':'Detailed counters are emitted in safe/table/all std logs. Both no_std test configurations also inject every observed request ordinal, without std logging. These are seven bounded workloads, not all possible inputs; entropy bytes need not equal C.'}
members['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode()
members['bundle-manifest.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},sort_keys=True,indent=2)+'\n').encode()
a=ROOT/'docs/evidence'/report['archive'];assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('double-fast-frame-encode/'+n);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 assert set(t.getnames())=={'double-fast-frame-encode/'+n for n in members}
 for n,b in members.items():assert t.extractfile('double-fast-frame-encode/'+n).read()==b
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(members))
(ROOT/'docs/evidence/2026-10-12-double-fast-frame-encode.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(len(e['commands']),'commands;',len(members),'archive members')
