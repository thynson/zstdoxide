from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path('/tmp/zstdoxide-lazy-registration-2026-10-13');D.mkdir(exist_ok=False)
commands=[['python3','scripts/check_reference_greedy_baseline.py'],['python3','scripts/check_lazy_family_recipes.py','--check'],['python3','scripts/capture_lazy_families.py','--check-plan'],['python3','scripts/check_lazy_family_fixture.py','--check']]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():return {str(p.relative_to(R)):sha(p) for p in sorted([*R.glob('src/**/*.rs'),R/'Cargo.toml',R/'Cargo.lock',R/'rust-toolchain.toml'])}
before=sources();driver=(R/'scripts/check.sh').read_text()
for cmd in commands:
 if driver.splitlines().count(' '.join(cmd))!=1:raise ValueError('exact driver registration')
checks=[['sh','-n','scripts/check.sh'],['cargo','fmt','--check'],['git','diff','--check']]
def run(item):
 n,cmd=item;start=time.monotonic();r=subprocess.run(cmd,cwd=R,capture_output=True,timeout=600)
 out=D/(str(n)+'.stdout');err=D/(str(n)+'.stderr');out.write_bytes(r.stdout);err.write_bytes(r.stderr)
 return dict(argv=cmd,exit_code=r.returncode,seconds=time.monotonic()-start,stdout=out.name,stdout_sha256=sha(out),stderr=err.name,stderr_sha256=sha(err))
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,enumerate(commands)))
results += [run((len(commands)+i,cmd)) for i,cmd in enumerate(checks)]
after=sources()
report=dict(status='passed' if all(r['exit_code']==0 for r in results) and before==after else 'failed',date='2026-10-13',commands=results,driver_sha256=sha(R/'scripts/check.sh'),production_source_before=before,production_source_after=after,source_unchanged=before==after,qualification='Four newly registered offline commands and shell syntax/format/diff checks only. No full scripts/check.sh execution, Rust test/Clippy/no_std matrix, new C capture or timing run is claimed. Earlier Module14 matrix remains historical and does not include this driver revision.')
(D/'evidence.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps({'status':report['status'],'commands':len(results),'production_inputs':len(before)}))
if report['status']!='passed':raise SystemExit(1)
