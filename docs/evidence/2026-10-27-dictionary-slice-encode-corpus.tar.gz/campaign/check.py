from pathlib import Path
import json,hashlib,subprocess,os,time,shutil,datetime,signal
D=Path(__file__).parent;S=D/'source';R=Path('/private/tmp/module34-public/source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,28,9,38,0,tzinfo=datetime.timezone.utc).timestamp()
assert json.loads(Path('/private/tmp/module34-public/evidence.json').read_text())['status']=='passed'
assert not S.exists();subprocess.run(['cp','-cR',str(R),str(S)],check=True);p=S/'tests/upstream_trained_dictionary_fuzz.rs';s=p.read_text();needle='    let first = encode_bounded(source, dictionary.clone(), prefix, capacity);';assert s.count(needle)==1;s=s.replace(needle,'''    // Supplemental persistent dictionary caller-output checks on the same
    // trained/loaded selection. Prefix-once and the original reduced streaming
    // bound remain separate contracts; this uses actual one-shot output sizes.
    if !prefix {
        dictionary_caller_output_checked(source, &dictionary);
    }
'''+needle)
anchor='fn encode_bounded(';assert s.count(anchor)==1
helper='''fn dictionary_caller_output_checked(source: &[u8], dictionary: &SharedDictionary) {
    let before = dictionary.as_bytes().to_vec();
    let handles = SharedDictionary::strong_count(dictionary);
    let expected = zstdoxide::compress_with_dictionary(source, dictionary).unwrap();
    assert!(expected.len() <= zstdoxide::compression_bound(source.len()).unwrap());
    let mut output = vec![0xa5; expected.len() + 34];
    let size = zstdoxide::compress_into_with_dictionary(source, &mut output[16..18 + expected.len()], dictionary).unwrap();
    assert_eq!(size, expected.len());
    assert_eq!(&output[16..16 + size], expected);
    assert!(output[..16].iter().chain(&output[16 + size..]).all(|&b| b == 0xa5));
    assert_eq!(zstdoxide::decompress_with_dictionary(&expected, dictionary, DecodeOptions::new(source.len())).unwrap(), source);
    output.fill(0xa5);
    assert_eq!(zstdoxide::compress_into_with_dictionary(source, &mut output[16..15 + expected.len()], dictionary), Err(Error::ResourceLimit));
    assert!(output[..16].iter().chain(&output[15 + expected.len()..]).all(|&b| b == 0xa5));
    assert_eq!(dictionary.as_bytes(), before);
    assert_eq!(SharedDictionary::strong_count(dictionary), handles);
    let fingerprint = |bytes: &[u8]| bytes.iter().fold(0xcbf2_9ce4_8422_2325u64, |h, &b| (h ^ u64::from(b)).wrapping_mul(0x100_0000_01b3));
    println!("DICT_OUTPUT\\t{}\\t{}\\t{}\\t{:016x}\\t{:016x}\\t{:016x}", source.len(), dictionary.as_bytes().len(), dictionary.id(), fingerprint(source), fingerprint(dictionary.as_bytes()), fingerprint(&expected));
}

'''
s=s.replace(anchor,helper+anchor);p.write_text(s);subprocess.run(['cargo','fmt','--all'],cwd=S,check=True)
e=dict(status='running',source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()},commands=[]);env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
plan=[]
for name,flags in [('safe',[]),('dictionary',['--features','unsafe-dictionary']),('all',['--all-features'])]:
 for kind,test in [('controlled','trained_roundtrip_covers_modes_prefixes_reduced_bounds_and_training_fallback'),('noise','trained_dictionary_targets_accept_deterministic_noise_and_truncated_frames')]:
  plan.append((name+'-'+kind,['cargo','test','--offline','--locked','--test','upstream_trained_dictionary_fuzz',*flags,test,'--','--exact','--nocapture']))
plan.extend([('clippy',['cargo','clippy','--offline','--locked','--test','upstream_trained_dictionary_fuzz','--all-features','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check'])]);save()
try:
 for label,args in plan:
  t=time.monotonic()
  with (D/(label+'.log')).open('xb') as f:
   assert time.time()<deadline-30,label
   p=subprocess.Popen(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:p.wait(timeout=max(1,deadline-time.time()-30))
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise TimeoutError('Work window reached during '+label)
  e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log'))));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
  if label not in ['clippy','format']:
   text=(D/(label+'.log')).read_text();assert '1 passed; 0 failed; 0 ignored' in text
   rows=[x for x in text.splitlines() if x.startswith('DICT_OUTPUT\t')];kind=label.split('-')[1]
   if kind=='controlled':assert len(rows)==48,(label,len(rows))
   else:assert len(rows)>0,label
   payload='\n'.join(rows)+'\n';(D/(label+'.tsv')).write_text(payload)
   if not label.startswith('safe-'):assert payload==(D/('safe-'+kind+'.tsv')).read_text(),label
   e.setdefault('selected_cases',{})[label]=dict(count=len(rows),ledger_sha256=sha(D/(label+'.tsv')));save()
 for n,h in e['source'].items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='Two existing deterministic trained-dictionary tests execute under safe/isolated-dictionary/all22. All original sample selection, mode, prefix, reduced streaming bound and training-fallback assertions remain. Only persistent selections gain supplemental actual-size-plus-two/minus-one one-shot compression checks, full byte/decode/guard/dictionary identity comparison and identical ledgers. The controlled test has48 such selections; deterministic noise is recorded separately. This is not an external rolling corpus rerun, native fastCover equivalence, prefix-once compression API, or original random-capacity port. Strict adapter Clippy and format also pass.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
