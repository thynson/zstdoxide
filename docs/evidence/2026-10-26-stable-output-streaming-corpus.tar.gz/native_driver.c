/* Independent wrapper for the unmodified pinned stream_decompress fuzz target. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "fuzz_data_producer.h"
int LLVMFuzzerTestOneInput(const uint8_t*, size_t);
int main(int argc, char** argv) {
    if (argc != 2) return 2;
    FILE* list = fopen(argv[1], "r");
    if (!list) return 2;
    char path[4096];
    size_t index = 0;
    while (fgets(path, sizeof(path), list)) {
        size_t length = strlen(path);
        if (!length || path[length-1] != '\n') return 2;
        path[--length] = '\0';
        FILE* f = fopen(path, "rb");
        if (!f || fseek(f, 0, SEEK_END)) return 2;
        long n = ftell(f);
        if (n < 0 || n > 2 * 1024 * 1024 || fseek(f, 0, SEEK_SET)) return 2;
        size_t size = (size_t)n;
        uint8_t* data = malloc(size ? size : 1);
        if (!data || fread(data, 1, size, f) != size || fclose(f)) return 2;
        FUZZ_dataProducer_t* p = FUZZ_dataProducer_create(data, size);
        size_t const prefix = FUZZ_dataProducer_reserveDataPrefix(p);
        size_t const capacity = 10 * prefix > 128 * 1024 ? 10 * prefix : 128 * 1024;
        unsigned const stable = FUZZ_dataProducer_uint32Range(p, 0, 10) == 5;
        size_t const out_size = stable || FUZZ_dataProducer_empty(p) ? capacity : FUZZ_dataProducer_uint32Range(p, 0, (uint32_t)capacity);
        size_t const first_input = prefix == 0 ? 0 : (FUZZ_dataProducer_empty(p) ? prefix : FUZZ_dataProducer_uint32Range(p, 0, (uint32_t)prefix));
        FUZZ_dataProducer_free(p);
        if (LLVMFuzzerTestOneInput(data, size) != 0) return 3;
        printf("%zu\t%u\t%zu\t%zu\t%zu\t%zu\n", index++, stable, prefix, capacity, out_size, first_input);
        free(data);
    }
    if (ferror(list) || fclose(list)) return 2;
    return index == 12462 ? 0 : 3;
}
