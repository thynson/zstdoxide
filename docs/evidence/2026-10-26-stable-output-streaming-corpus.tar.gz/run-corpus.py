from pathlib import Path
import hashlib,json,os,subprocess,time,collections
D=Path(__file__).parent;R=D/'source';C=Path('/private/tmp/module24-external-corpora/extracted/stream_decompress');A=C.parents[1]/'archives/stream_decompress_seed_corpus.zip'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert A.stat().st_size==14873750 and sha(A)=='7434eba13e322a2a9b504ddb57217cf3568d360df309e3c9003956bd449e1de8'
f=json.loads((D/'focused.json').read_text());b=json.loads((D/'native-build.json').read_text());assert f['status']=='passed' and b['status']=='passed'
files=sorted(p for p in C.rglob('*') if p.is_file());assert len(files)==12462 and sum(p.stat().st_size for p in files)==80339212
for p in files:assert not p.is_symlink() and '\n' not in str(p) and p.stat().st_size<=2*1024*1024
members={str(p.relative_to(C)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files};(D/'members.json').write_text(json.dumps(members,indent=2)+'\n');(D/'paths.txt').write_text(''.join(str(p)+'\n' for p in files))
e=dict(status='running',source=f['source'],focused_sha256=sha(D/'focused.json'),native_build_sha256=sha(D/'native-build.json'),archive_sha256=sha(A),members_sha256=sha(D/'members.json'),files=len(files),bytes=80339212,commands=[])
def save():(D/'corpus.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,env,stdout):
 start=time.monotonic()
 with (D/stdout).open('xb') as out,(D/(label+'.stderr')).open('xb') as err:p=subprocess.run(args,cwd=R,env=env,stdout=out,stderr=err,timeout=900)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,stdout=stdout,stdout_sha256=sha(D/stdout)));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
assert not (D/'corpus.json').exists();save()
try:
 for name in ['normal','sanitized']:
  assert sha(D/('native-'+name))==b['executables'][name]
  run('native-'+name,[str(D/('native-'+name)),str(D/'paths.txt')],os.environ,'native-'+name+'.tsv')
 normal=(D/'native-normal.tsv').read_bytes();assert normal==(D/'native-sanitized.tsv').read_bytes()
 native=[list(map(int,line.split('\t'))) for line in normal.decode().splitlines()];assert len(native)==len(files)
 env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','ZSTDOXIDE_STABLE_STREAM_CORPUS':str(C)}
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  run('rust-'+name,['cargo','test','--offline','--locked','--release','--test','stable_stream_fuzz',*flags,'--','--ignored','--exact','external_exact_selector_streaming_corpus','--nocapture'],{**env,'ZSTDOXIDE_STABLE_STREAM_LEDGER':str(D/(name+'-ledger.tsv'))},name+'-corpus.log')
  rows=[line.split('\t') for line in (D/(name+'-ledger.tsv')).read_text().splitlines()];assert len(rows)==len(files)
  for index,(row,n,p) in enumerate(zip(rows,native,files)):
   assert len(row)==10 and row[0]==str(p.relative_to(C))
   assert n==[index,int(row[1]),int(row[2]),int(row[3]),int(row[8]),int(row[9])],(name,index,n,row)
  e.setdefault('backends',{})[name]=dict(ledger_sha256=sha(D/(name+'-ledger.tsv')),stable=sum(int(r[1]) for r in rows),buffered=sum(not int(r[1]) for r in rows),outcomes=dict(collections.Counter(r[6] for r in rows)));save()
 assert (D/'safe-ledger.tsv').read_bytes()==(D/'all-ledger.tsv').read_bytes(),'safe/all per-file outcomes'
 for n,h in f['source'].items():assert sha(R/n)==h,n
 for n,row in members.items():assert sha(C/n)==row['sha256'],n
 e.update(status='passed',qualification='Every pinned input ran through both unmodified native non-stateful fuzz targets (normal and ASan/UBSan) and both Rust release adapters, with zero skipped files. Native and Rust stable selector, reserved source prefix, buffer capacity, initial output size and first input size match for every file. Rust fixed destinations have real guard checks. Buffered aggregate output/window caps and non-stateful context lifetime remain explicit bounded adaptations; no complete target parity claim.');save()
 print(e['backends'],flush=True)
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
