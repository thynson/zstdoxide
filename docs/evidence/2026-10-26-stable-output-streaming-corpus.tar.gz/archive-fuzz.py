from pathlib import Path
import json,hashlib,tarfile
D=Path(__file__).parent;F=Path('/private/tmp/module24-fuzz');S=F/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((F/'focused.json').read_text());c=json.loads((F/'corpus.json').read_text());b=json.loads((F/'native-build.json').read_text());assert f['status']==c['status']==b['status']=='passed'
assert len(f['commands'])==24 and len(c['commands'])==4
for record in [f,c]:
 for command in record['commands']:assert command['exit_code']==0
for n,h in f['source'].items():assert sha(S/n)==h,n
assert c['focused_sha256']==sha(F/'focused.json') and c['native_build_sha256']==sha(F/'native-build.json')
assert (F/'safe-ledger.tsv').read_bytes()==(F/'all-ledger.tsv').read_bytes()
assert (F/'native-normal.tsv').read_bytes()==(F/'native-sanitized.tsv').read_bytes()
assert 'Upstream checkout hashes and case anchors verified.' in (F/'inventory-pinned.log').read_text()
base=json.loads((D/'2026-10-26-stable-output-public-api.json').read_text());omitted=base['fixture_provenance']['omitted_binary_files']
for n,h in omitted.items():assert sha(S/n)==h,n
name='2026-10-26-stable-output-streaming-corpus';archive=D/(name+'.tar.gz');assert not archive.exists()
files=[p for p in F.iterdir() if p.is_file()]
for folder in ['src','tests','test-support','benches','examples','scripts']:
 files += [p for p in (S/folder).rglob('*') if p.is_file() and p.suffix in {'.rs','.toml','.lock','.md','.json','.py','.sh','.tsv','.csv'}]
files += [S/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']]
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(set(files)):t.add(p,arcname=str(p.relative_to(F)))
 t.add(__file__,arcname='archive-fuzz.py')
result=dict(status='passed',focused=f,corpus=c,native_build=b,inventory_sha256=sha(S/'tests/upstream/manifest.json'),inventory_log_sha256=sha(F/'inventory-pinned.log'),archive=archive.name,archive_sha256=sha(archive),fixture_provenance=base['fixture_provenance'],qualification='Additive exact-selector adapter after the base full-suite freeze. All22 backend selections execute its seven normal tests; safe/all release execute every12462 pinned corpus input. Every input hash and all native/Rust ledgers are retained. The rolling corpus payload and downloaded pinned upstream source stay external; archive pin, member hashes, reference hashes and independent native executables are retained. Prefix/branch/capacity/first selector equality is verified, not equality of native and Rust malformed-input errors or call counts.')
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
