from pathlib import Path
import hashlib,io,json,re,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-lazy-baseline-checks')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,s):
 if not v:raise ValueError(s)
e=json.loads((O/'evidence.json').read_bytes());need(e['status']=='passed' and e['source_unchanged'] is True and len(e['commands'])==7,'complete focused checks')
for n,h in e['source'].items():need(sha((R/n).read_bytes())==h,'unchanged delivered input '+n)
for c in e['commands']:
 b=(O/c['log']).read_bytes();need(c['exit_code']==0 and sha(b)==c['log_sha256'],'command log')
 if c['label'].startswith('test-'):
  counts=[list(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',b)]
  need(counts==c['totals']==[[21,0,0,0,0]],'exact test counts')
controls={}
for mode in ['normal','optimized']:
 p=Path('/tmp/zstdoxide-lazy-baseline-controls-'+mode+'.json');d=json.loads(p.read_text());need(d['positive']==2 and d['rejected']==15 and d['child_processes']==0 and d['checker_sha256']==sha((R/'scripts/check_reference_lazy_baseline.py').read_bytes()),'offline controls');controls[mode]=d
provenance=json.loads((R/'tests/fixtures/reference-lazy-baseline/provenance.json').read_text())
report={'date':'2026-10-13','status':'passed','rows':80,'unique_frames':36,'pack_bytes':22819999,'native_test_executions':84,'native_configs':['safe','unsafe-reference-chain','unsafe-row-table','all'],'clock_free_capture_configs':provenance['configs'],'source':e['source'],'source_unchanged':True,'controls':controls,'qualification':'Module 16 preparation; preserves Module 15 outputs before refactoring. These twenty-one new tests are separate focused checks, not retroactively included in the still-running immutable Module 15 matrix. Their frames/owners already agree in all sixteen clock-free benchmark configurations. No new C execution or timing.','archive':'2026-10-13-lazy-baseline.tar.gz'}
files={p.name:p.read_bytes() for p in O.iterdir() if p.is_file()}
files.update({'controls-'+mode+'.json':enc(d) for mode,d in controls.items()})
for n in ['zstdoxide-lazy-baseline-checks.py','zstdoxide-lazy-baseline-controls.py','package-zstdoxide-lazy-baseline.py']:files['runners/'+n]=(Path('/tmp')/n).read_bytes()
for n in ['scripts/check_reference_lazy_baseline.py','tests/reference_lazy_defaults.rs','tests/fixtures/reference-lazy-baseline/README.md','tests/fixtures/reference-lazy-baseline/provenance.json','tests/fixtures/reference-lazy-baseline/expected.tsv']:files['source/'+n]=(R/n).read_bytes()
files['review.json']=enc(report);files['bundle-manifest.json']=enc({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())})
a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh archive');prefix='lazy-baseline/'
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo(prefix+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:found={v.name:t.extractfile(v).read() for v in t}
need(found=={prefix+n:b for n,b in files.items()},'archive byte identity')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files));(R/'docs/evidence/2026-10-13-lazy-baseline.json').write_bytes(enc(report));print(report['native_test_executions'],report['archive_members'],report['archive_bytes'])
