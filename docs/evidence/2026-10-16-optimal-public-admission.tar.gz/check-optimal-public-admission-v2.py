from pathlib import Path
import subprocess,json,hashlib,time,os
root=Path.cwd();out=Path('/tmp/zstdoxide-optimal-public-admission-checks-v2');out.mkdir(exist_ok=False)
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
paths=list((root/'src').glob('*.rs'))+list((root/'tests').glob('reference_*.rs'))+[root/'tests/upstream_reference_fast.rs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={str(p.relative_to(root)):sha(p) for p in paths};commands=[]
configs=[('safe',[]),('all',['--all-features']),('release-all',['--release','--all-features'])]
for label,args in configs:
 argv=['cargo','test','--offline','--locked',*args,'--test','reference_optimal','--test','reference_optimal_platform'];p=out/(label+'.log');start=time.monotonic()
 with p.open('wb') as f:r=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT)
 commands.append(dict(label=label,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)));print(label,r.returncode,flush=True)
 if r.returncode:break
else:
 for label,args in [('clippy',['clippy','--all-features','--tests','--','-D','warnings']),('nostd',['check','--no-default-features']),('fmt',['fmt','--all','--','--check'])]:
  argv=['cargo',*args];p=out/(label+'.log');start=time.monotonic()
  with p.open('wb') as f:r=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT)
  commands.append(dict(label=label,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)));print(label,r.returncode,flush=True)
  if r.returncode:break
unchanged=source=={str(p.relative_to(root)):sha(p) for p in paths}
(out/'evidence.json').write_text(json.dumps(dict(status='passed' if unchanged and len(commands)==6 and all(c['exit_code']==0 for c in commands) else 'failed',source=source,environment_overrides={k:env[k] for k in ['CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']},source_unchanged=unchanged,commands=commands),indent=2)+'\n')
