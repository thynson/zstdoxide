from pathlib import Path
import json,hashlib,tarfile,re,subprocess
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path(__file__).parent;E=R/'docs/evidence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((D/'evidence.json').read_text());new=json.loads((D/'resume-20261026.json').read_text())
assert new['status']=='passed' and new['prefix_sha256']==sha(D/'evidence.json') and new['pause_sha256']==sha(D/'pause.json')
assert len(old['commands'])==66 and len(new['commands'])==5
for n,h in new['source'].items():assert sha(R/n)==h,n
commands=[]
for prefix,rows in [('',old['commands']),('resume-20261026-',new['commands'])]:
 for c in rows:
  assert c['exit_code']==0
  p=D/(prefix+c['label']+'.log');s=p.read_text();results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',s)
  commands.append({**c,'log':p.name,'log_sha256':sha(p),'test_result_groups':[dict(passed=int(a),failed=int(b),ignored=int(i)) for a,b,i in results]})
name='2026-10-26-caller-output-feature-matrix';archive=E/(name+'.tar.gz');assert not archive.exists()
paths=[]
for root in ['src','tests','test-support','benches']:
 paths.extend(p for p in (R/root).rglob('*') if p.is_file() and 'target' not in p.relative_to(R).parts)
paths.extend(R/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml'])
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(D.iterdir()):
  if p.is_file():t.add(p,arcname='campaign/'+p.name)
 for p in sorted(paths):
  if p.suffix in ['.rs','.toml','.lock','.py','.md','.json','.sh','.tsv','.csv'] or p.name in ['Cargo.lock']:
   t.add(p,arcname='source/'+str(p.relative_to(R)))
e=dict(status='passed',qualification='Additive completion of the interrupted 2026-10-23 campaign. The original running record and paused incomplete safe-full log are preserved; only the new safe/all full and release runs count as completed. Twenty isolated features plus safe/all passed destination tests, true no_std and strict Clippy; safe/all full suites and release destination tests passed. Isolated whole suites and all-feature full release remain a separate gate.',source=new['source'],complete_source={str(p.relative_to(R)):sha(p) for p in sorted(paths)},fixture_provenance=dict(git_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),policy='Binary fixtures remain in the repository at this commit; complete_source records their SHA-256 identities. Archive contains code, text metadata and campaign logs, avoiding duplicate fixture payloads.'),original_evidence_sha256=sha(D/'evidence.json'),resume_evidence_sha256=sha(D/'resume-20261026.json'),commands=commands,archive=archive.name,archive_sha256=sha(archive))
(E/(name+'.json')).write_text(json.dumps(e,indent=2)+'\n')
print(name,len(commands),'commands',archive.stat().st_size,'archive bytes')
