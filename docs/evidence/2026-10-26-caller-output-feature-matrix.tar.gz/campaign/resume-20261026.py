from pathlib import Path
import os,subprocess,json,time,hashlib,datetime
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((D/'evidence.json').read_text());assert len(old['commands'])==66 and all(c['exit_code']==0 for c in old['commands'])
for n,h in old['source'].items():assert sha(R/n)==h,n
assert (D/'pause.json').exists()
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module23-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
e=dict(status='running',source=old['source'],prefix_sha256=sha(D/'evidence.json'),pause_sha256=sha(D/'pause.json'),prefix_commands=66,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commands=[])
output=D/'resume-20261026.json';assert not output.exists()
def save():output.write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 start=time.monotonic()
 with (D/('resume-20261026-'+label+'.log')).open('xb') as log:p=subprocess.run(args,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start));save();print(label,p.returncode,flush=True)
 assert p.returncode==0,label
save()
try:
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  run(name+'-full',['cargo','test','--offline','--locked',*flags])
  run(name+'-release-destinations',['cargo','test','--offline','--locked','--release','--test','caller_output','--test','caller_output_platform','--test','upstream_decodecorpus',*flags])
 run('format',['cargo','fmt','--all','--','--check'])
 for n,h in e['source'].items():assert sha(R/n)==h,n
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
