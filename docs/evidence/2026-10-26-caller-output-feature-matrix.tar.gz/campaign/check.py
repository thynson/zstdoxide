from pathlib import Path
import os,subprocess,json,time,hashlib,tomllib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path(__file__).parent
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module23-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
features=sorted(n for n in tomllib.loads((R/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
paths=list(R.glob('src/*.rs'))+[R/'Cargo.toml',R/'Cargo.lock']+list(R.glob('tests/*.rs'))
source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
e={'status':'running','source':source,'commands':[],'features':features}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append({'label':label,'argv':args,'exit_code':p.returncode,'seconds':time.monotonic()-t});save();print(label,p.returncode,flush=True)
 if p.returncode:raise ValueError(label)
try:
 for name,flags,no in [('safe',[],[]),*[(f,['--features',f],['--features',f]) for f in features],('all',['--all-features'],['--features',','.join(features)])]:
  run(name+'-destinations',['cargo','test','--offline','--locked','--test','caller_output','--test','caller_output_platform','--test','upstream_decodecorpus',*flags])
  run(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*no])
  run(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  run(name+'-full',['cargo','test','--offline','--locked',*flags])
  run(name+'-release-destinations',['cargo','test','--offline','--locked','--release','--test','caller_output','--test','caller_output_platform','--test','upstream_decodecorpus',*flags])
 run('format',['cargo','fmt','--all','--','--check'])
 assert source=={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 e['status']='passed';save()
except BaseException as ex:e['status']='failed';e['error']=repr(ex);save();raise
