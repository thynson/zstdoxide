"""Supplementary native candidate preflight, not a Module35 milestone gate."""
from pathlib import Path
import os,subprocess,json,hashlib,time,datetime,re,signal
D=Path(__file__).parent;S=D/'source';T=Path('/private/tmp');U=T/'module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,27,7,0,0,tzinfo=datetime.timezone.utc).timestamp()
assert os.getpriority(os.PRIO_PROCESS,0)==19
pre=T/'module35-public-preflight-v2/evidence.json';prior=json.loads(pre.read_text());assert prior['status']=='passed' and len(prior['commands'])==9
production={str(p.relative_to(S)):sha(p) for p in (S/'src').rglob('*.rs')};assert production=={n:h for n,h in prior['source'].items() if n.startswith('src/')}
old=T/'module33-native/build.json';reference=json.loads(old.read_text());assert reference['status']=='passed';library={str(p.relative_to(U)):sha(p) for p in (U/'lib').rglob('*') if p.is_file() and p.suffix in ['.c','.h','.S']};assert library==reference['library'];assert sha(U.parent/'reference-identity.json')==reference['reference_identity_sha256']
source={str(p.relative_to(S)):sha(p) for folder in ['src','tests','test-support'] for p in (S/folder).rglob('*') if p.is_file()};source.update({n:sha(S/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']});assert not (D/'evidence.json').exists();e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=source,production_source=production,public_preflight_sha256=sha(pre),reference_revision=reference['reference_revision'],pinned_build_receipt_sha256=sha(old),reference_identity_sha256=sha(U.parent/'reference-identity.json'),library=library,helper_sha256=sha(D/'one_shot_encode_oracle.c'),commands=[],qualification='Supplementary candidate preflight only; no original upstream group or Module35 milestone is promoted. Normal/sanitized typed persistent/prefix schedules use observable fresh native controls. Native byte/capacity/workspace identity is not required. ASan leak detection is disabled on this macOS runtime and is not credited.')
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module35-native-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,extra=None,cwd=S,expected=None):
 remaining=deadline-time.time()-15
 if remaining<15:raise TimeoutError('Native preflight cutoff before '+label)
 e['active_command']=label;save();start=time.monotonic();log=D/(label+'.log')
 with log.open('xb') as f:
  p=subprocess.Popen(args,cwd=cwd,env={**env,**(extra or {})},stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=remaining)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   raise TimeoutError('Native preflight cutoff during '+label)
 row=dict(label=label,argv=args,environment=extra or {},exit_code=code,seconds=time.monotonic()-start,log_sha256=sha(log))
 if code==0 and expected is not None:
  groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text());assert groups==[(str(expected),'0','0')],(label,groups);row.update(passed=expected,failed=0,ignored=0)
 e['commands'].append(row);e.pop('active_command',None);save();print(label,code,flush=True);assert code==0,(label,log.read_text()[-4000:])
def inventory(folder):return {str(p.relative_to(folder)):sha(p) for p in folder.rglob('*') if p.is_file()}
save()
try:
 for label,flags in [('safe',[]),('all',['--all-features'])]:
  folder=D/(label+'-export');folder.mkdir();run(label+'-export',['cargo','test','--offline','--locked','--test','one_shot_encode_native',*flags,'typed_context_schedules_preserve_attempt_ownership_and_complete_frames','--','--ignored','--exact','--nocapture'],dict(ZSTDOXIDE_ONE_SHOT_ENCODE_NATIVE=str(folder),ZSTDOXIDE_ONE_SHOT_ENCODE_EXPORT='1'),expected=1)
 a=inventory(D/'safe-export');assert len(a)==53 and inventory(D/'all-export')==a;e['inputs']=a;save()
 sources=sorted((U/'lib/common').glob('*.c'))+sorted((U/'lib/decompress').glob('*.c'))+sorted((U/'lib/compress').glob('*.c'))
 for label,flags in [('normal',['-O2']),('sanitized',['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'])]:
  exe=D/('oracle-'+label);run(label+'-build',['cc','-std=c99','-Wall','-Wextra','-Werror','-DZSTD_MULTITHREAD=0','-I'+str(U/'lib'),'-I'+str(U/'lib/common'),*flags,str(D/'one_shot_encode_oracle.c'),*[str(p) for p in sources],'-o',str(exe)]);e.setdefault('executables',{})[label]=sha(exe);save()
  output=D/(label+'-outputs');output.mkdir();run(label+'-capture',[str(exe),str(D/'safe-export'),str(output)],dict(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'),cwd=D)
  shutil_source=D/(label+'-capture.log');(D/(label+'.tsv')).write_bytes(shutil_source.read_bytes())
 normal=(D/'normal.tsv').read_text().splitlines();assert len(normal)==87 and (D/'normal.tsv').read_bytes()==(D/'sanitized.tsv').read_bytes();assert inventory(D/'normal-outputs')==inventory(D/'sanitized-outputs');outputs=inventory(D/'normal-outputs');assert len(outputs)==103
 rows=[line.split('\t') for line in normal];assert all(len(row)==8 for row in rows);assert sum(row[1]=='setup' for row in rows)==39;assert sum(row[1]=='ok' for row in rows)==42;assert sum(row[1]=='error' for row in rows)==6
 controls=(D/'normal-outputs/observability.tsv').read_text().splitlines();assert len(controls)==12 and all(line.split('\t')[-1]=='1' for line in controls)
 e.update(native_rows=87,scenarios=27,attempts=48,successes=42,capacity_errors=6,observable_controls=12,subsequent_control_differences=sum(row[1]=='ok' and row[5]!='1' for row in rows),native_suffix_mutations=sum(row[1]=='ok' and int(row[4])>0 for row in rows),outputs=outputs);save()
 replay=D/'replay';replay.mkdir();__import__('shutil').copytree(D/'safe-export/inputs',replay/'inputs');__import__('shutil').copyfile(D/'safe-export/steps.tsv',replay/'steps.tsv');__import__('shutil').copyfile(D/'normal.tsv',replay/'normal.tsv');__import__('shutil').copytree(D/'normal-outputs',replay/'normal-outputs')
 for label,flags in [('safe',[]),('sink',['--features','unsafe-frame-sink']),('dictionary',['--features','unsafe-dictionary']),('all',['--all-features'])]:
  run(label+'-replay',['cargo','test','--offline','--locked','--test','one_shot_encode_native',*flags,'typed_context_schedules_preserve_attempt_ownership_and_complete_frames','--','--ignored','--exact','--nocapture'],dict(ZSTDOXIDE_ONE_SHOT_ENCODE_NATIVE=str(replay)),expected=1)
  run(label+'-clippy',['cargo','clippy','--offline','--locked','--lib','--test','one_shot_encode_native',*flags,'--','-D','warnings'])
 run('format',['cargo','fmt','--all','--','--check']);assert len(e['commands'])==15
 assert inventory(D/'safe-export')==a and inventory(D/'all-export')==a
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except TimeoutError as ex:e.update(status='interrupted-at-preflight-cutoff',error=repr(ex));save();raise
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
