/* External supplementary oracle only, against pinned facebook/zstd v1.5.7. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "zstd_errors.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

static const char *names[6]={"raw-a","raw-b","prepared-a","prepared-b","rawmagic-a","rawmagic-b"};
static unsigned char *dicts[6];static size_t dict_sizes[6];static ZSTD_CDict *cdicts[6];static ZSTD_DDict *ddicts[6];
static const char *input_root,*output_root;
static void checked(size_t result) {if(ZSTD_isError(result)){fprintf(stderr,"native error: %s\n",ZSTD_getErrorName(result));exit(20);}}
static void path_of(char *path,size_t capacity,const char *root,const char *name,const char *suffix) {
    int n=snprintf(path,capacity,"%s/%s.%s",root,name,suffix);if(n<0 || (size_t)n>=capacity)exit(21);
}
static unsigned char *read_file(const char *root,const char *name,const char *suffix,size_t *size) {
    char path[4096];FILE *f;long n;unsigned char *p;path_of(path,sizeof(path),root,name,suffix);f=fopen(path,"rb");
    if(!f || fseek(f,0,SEEK_END) || (n=ftell(f))<0 || fseek(f,0,SEEK_SET))exit(22);
    *size=(size_t)n;p=malloc(*size?*size:1);if(!p || fread(p,1,*size,f)!=*size || fclose(f))exit(23);return p;
}
static void write_file(const char *name,const char *suffix,const void *bytes,size_t size) {
    char path[4096];FILE *f;path_of(path,sizeof(path),output_root,name,suffix);f=fopen(path,"wb");if(!f || fwrite(bytes,1,size,f)!=size || fclose(f))exit(24);
}
static void guards(const unsigned char *p,size_t capacity) {
    size_t i;for(i=0;i<16;i++)if(p[i]!=0xa5 || p[16+capacity+i]!=0xa5)exit(25);
}
static int dictionary_index(const char *name) {int i;if(!strcmp(name,"-"))return 0;for(i=0;i<6;i++)if(!strcmp(name,names[i]))return i+1;exit(26);}
static ZSTD_dictContentType_e content_type(int index) {return index==3 || index==4?ZSTD_dct_fullDict:ZSTD_dct_rawContent;}
static void configure(ZSTD_CCtx *cc) {checked(ZSTD_CCtx_setParameter(cc,ZSTD_c_compressionLevel,3));checked(ZSTD_CCtx_setParameter(cc,ZSTD_c_checksumFlag,1));checked(ZSTD_CCtx_setParameter(cc,ZSTD_c_contentSizeFlag,1));}
static void select_dictionary(ZSTD_CCtx *cc,const char *mode,int index) {
    if(!strcmp(mode,"none") || !strcmp(mode,"clear")){checked(ZSTD_CCtx_refCDict(cc,NULL));return;}
    if(index<1 || index>6)exit(27);
    if(!strcmp(mode,"persistent"))checked(ZSTD_CCtx_refCDict(cc,cdicts[index-1]));
    else if(!strcmp(mode,"prefix"))checked(ZSTD_CCtx_refPrefix_advanced(cc,dicts[index-1],dict_sizes[index-1],content_type(index)));
    else exit(28);
}
static unsigned char *control(const char *mode,int index,const unsigned char *input,size_t n,size_t *size) {
    size_t bound=ZSTD_compressBound(n);unsigned char *storage=malloc(bound+32),*out;ZSTD_CCtx *cc=ZSTD_createCCtx();if(!storage || !cc)exit(29);
    memset(storage,0xa5,bound+32);configure(cc);select_dictionary(cc,mode,index);*size=ZSTD_compress2(cc,storage+16,bound,input,n);checked(*size);if(*size>bound)exit(30);guards(storage,bound);
    out=malloc(*size?*size:1);if(!out)exit(31);memcpy(out,storage+16,*size);free(storage);ZSTD_freeCCtx(cc);return out;
}
static int decode_matches(ZSTD_DCtx *dc,int index,const unsigned char *frame,size_t frame_size,const unsigned char *input,size_t n) {
    unsigned char *out=malloc(n+32);size_t result;int equal;if(!out)exit(32);memset(out,0xa5,n+32);
    result=ZSTD_decompress_usingDDict(dc,out+16,n,frame,frame_size,index?ddicts[index-1]:NULL);guards(out,n);equal=!ZSTD_isError(result)&&result==n&&!memcmp(out+16,input,n);free(out);return equal;
}
int main(int argc,char **argv) {
    FILE *steps,*observability;char input_path[4096],path[4096],id[128],scenario[128],previous[128]="",op[32],dict[64],input_name[64],capacity_name[32],expected_mode[32],expected_dict[64];int fields,i;size_t rows=0,attempts=0,successes=0;ZSTD_CCtx *cc;ZSTD_DCtx *dc;
    if(argc!=3 || ZSTD_versionNumber()!=10507)return 2;
    if(snprintf(input_path,sizeof(input_path),"%s/inputs",argv[1])<0)return 3;input_root=input_path;output_root=argv[2];
    for(i=0;i<6;i++) {
        dicts[i]=read_file(input_root,names[i],"dict",&dict_sizes[i]);
        cdicts[i]=ZSTD_createCDict_advanced(dicts[i],dict_sizes[i],ZSTD_dlm_byRef,content_type(i+1),ZSTD_getCParams(3,0,dict_sizes[i]),ZSTD_defaultCMem);
        ddicts[i]=ZSTD_createDDict_advanced(dicts[i],dict_sizes[i],ZSTD_dlm_byRef,content_type(i+1),ZSTD_defaultCMem);if(!cdicts[i]||!ddicts[i])return 4;
    }
    path_of(path,sizeof(path),output_root,"observability","tsv");observability=fopen(path,"w");if(!observability)return 5;
    for(i=0;i<6;i++) {
        const char *kind=i<2?"raw":i<4?"prepared":"rawmagic";size_t n,plain_size;unsigned char *input=read_file(input_root,kind,"input",&n),*plain=control("none",0,input,n,&plain_size);int mode;
        if(!n)return 6;
        for(mode=0;mode<2;mode++) {
            const char *name=mode?"prefix":"persistent";size_t size;unsigned char *selected=control(name,i+1,input,n,&size);int differs=size!=plain_size || memcmp(selected,plain,size)!=0;char label[128];
            if(!differs){fprintf(stderr,"unobservable fixture: %s %s\n",names[i],name);return 7;}
            if(snprintf(label,sizeof(label),"control-%s-%s",names[i],name)<0)return 8;write_file(label,"zst",selected,size);fprintf(observability,"%s\t%s\t%zu\t%zu\t1\n",names[i],name,size,plain_size);free(selected);
        }
        free(input);free(plain);
    }
    if(fclose(observability))return 9;
    path_of(path,sizeof(path),argv[1],"steps","tsv");steps=fopen(path,"r");cc=ZSTD_createCCtx();dc=ZSTD_createDCtx();if(!steps||!cc||!dc)return 10;
    while((fields=fscanf(steps,"%127s %127s %31s %63s %63s %31s %31s %63s",id,scenario,op,dict,input_name,capacity_name,expected_mode,expected_dict))==8) {
        rows++;
        if(strcmp(previous,scenario)){checked(ZSTD_CCtx_reset(cc,ZSTD_reset_session_and_parameters));configure(cc);strcpy(previous,scenario);}
        if(strcmp(op,"encode")){select_dictionary(cc,op,dictionary_index(dict));printf("%s\tsetup\t0\t0\t0\t0\t0\t0\n",id);continue;}
        {
            size_t n,cap,result,changed=0,k,control_size,plain_size;int index=dictionary_index(expected_dict),decoder=0,expected_match=0,plain_match=0;unsigned char *input=read_file(input_root,input_name,"input",&n),*storage,*expected,*plain;
            attempts++;cap=!strcmp(capacity_name,"zero")?0:ZSTD_compressBound(n);storage=malloc(cap+32);if(!storage)return 11;memset(storage,0xa5,cap+32);
            result=ZSTD_compress2(cc,storage+16,cap,input,n);guards(storage,cap);write_file(id,"storage",storage,cap+32);
            expected=control(expected_mode,index,input,n,&control_size);plain=control("none",0,input,n,&plain_size);
            if(!ZSTD_isError(result)) {
                size_t rust_size;unsigned char *rust;successes++;if(result>cap)return 12;
                expected_match=result==control_size&&!memcmp(storage+16,expected,result);plain_match=result==plain_size&&!memcmp(storage+16,plain,result);
                if(decode_matches(dc,index,storage+16,result,input,n))decoder=index;
                else if(decode_matches(dc,0,storage+16,result,input,n))decoder=0;
                else {for(decoder=1;decoder<=6;decoder++)if(decode_matches(dc,decoder,storage+16,result,input,n))break;if(decoder>6)return 13;}
                for(k=result;k<cap;k++)if(storage[16+k]!=0xa5)changed++;
                write_file(id,"zst",storage+16,result);rust=read_file(input_root,id,"rust",&rust_size);if(!decode_matches(dc,index,rust,rust_size,input,n))return 14;free(rust);
            } else if(cap!=0)return 15;
            printf("%s\t%s\t%zu\t%u\t%zu\t%d\t%d\t%d\n",id,ZSTD_isError(result)?"error":"ok",ZSTD_isError(result)?0:result,(unsigned)ZSTD_getErrorCode(result),changed,expected_match,plain_match,decoder);
            {size_t size;unsigned char *again=read_file(input_root,input_name,"input",&size);if(size!=n||memcmp(again,input,n))return 16;free(again);}
            free(storage);free(input);free(expected);free(plain);
        }
    }
    if(fields!=EOF || ferror(steps) || fclose(steps) || rows!=87 || attempts!=48 || successes!=42)return 17;
    ZSTD_freeCCtx(cc);ZSTD_freeDCtx(dc);
    for(i=0;i<6;i++){size_t size;unsigned char *again=read_file(input_root,names[i],"dict",&size);if(size!=dict_sizes[i]||memcmp(again,dicts[i],size))return 18;free(again);ZSTD_freeCDict(cdicts[i]);ZSTD_freeDDict(ddicts[i]);free(dicts[i]);}
    return 0;
}
