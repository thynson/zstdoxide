import hashlib,io,json,os,pathlib,re,subprocess,tarfile,time
root=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize');snapshot=pathlib.Path('/tmp/zstdoxide-public-fast-doc-checkpoint');snapshot.mkdir()
revision='8cd3781';paths=['src','tests','test-support','scripts','benches','Cargo.toml','Cargo.lock','rust-toolchain.toml','AGENTS.md','README.md','docs/parameter-usage.md']
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',revision,*paths],cwd=root))) as tar:tar.extractall(snapshot,filter='data')
overlays=['src/lib.rs','src/reference_encode.rs','tests/reference_fast.rs','README.md','docs/parameter-usage.md','docs/reference-fast-usage.md','scripts/check_doc_examples.py']
for n in overlays:(snapshot/n).parent.mkdir(parents=True,exist_ok=True);(snapshot/n).write_bytes((root/n).read_bytes())
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def manifest():return {str(p.relative_to(snapshot)):sha(p) for p in sorted(snapshot.rglob('*')) if p.is_file()}
before=manifest();env=os.environ|{'CARGO_TARGET_DIR':'/tmp/zstdoxide-public-fast-doc-target'}
result={'base_revision':revision,'snapshot':str(snapshot),'overlays':{n:sha(snapshot/n) for n in overlays},'source_manifest':before,'commands':[]}
evidence=pathlib.Path('/tmp/zstdoxide-public-fast-doc-evidence.json');checks=[]
for name,flags in [('safe',[]),('all',['--all-features'])]:
 checks.extend([
 (name+'-public',['cargo','test','--test','reference_fast',*flags,'--','--nocapture'],13),
 (name+'-rustdoc',['cargo','test','--doc',*flags],5),
 (name+'-usage',['python3','scripts/check_doc_examples.py','docs/reference-fast-usage.md','README.md',*flags],4),
 (name+'-clippy',['cargo','clippy','--all-targets',*flags,'--','-D','warnings'],None)])
checks.append(('format',['rustfmt','--edition','2024','--config','skip_children=true','--check','src/lib.rs','src/reference_encode.rs','tests/reference_fast.rs'],None))
for name,cmd,count in checks:
 log=pathlib.Path('/tmp/zstdoxide-public-fast-doc-'+name+'.log');start=time.monotonic()
 with log.open('w') as f:p=subprocess.run(cmd,cwd=snapshot,env=env,stdout=f,stderr=subprocess.STDOUT)
 summaries=[{'passed':int(a),'failed':int(b),'ignored':int(c)} for a,b,c in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text())]
 result['commands'].append({'name':name,'command':cmd,'cwd':str(snapshot),'environment':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']},'exit_code':p.returncode,'seconds':time.monotonic()-start,'log':str(log),'sha256':sha(log),'summaries':summaries})
 evidence.write_text(json.dumps(result,indent=2)+'\n');print(name,p.returncode,summaries,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 if count is not None and sum(s['passed'] for s in summaries)!=count:raise SystemExit('unexpected test count')
result['snapshot_unchanged']=before==manifest();result['overlays_unchanged']=all(sha(root/n)==want for n,want in result['overlays'].items())
assert result['snapshot_unchanged'] and result['overlays_unchanged']
result['result']='passed';evidence.write_text(json.dumps(result,indent=2)+'\n')
