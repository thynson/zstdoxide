from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path('/tmp/zstdoxide-lazy-reader-checks');E=R/'docs/evidence'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,s):
 if not v:raise ValueError(s)
d=json.loads((D/'evidence.json').read_bytes());need(d['status']=='passed' and d['test_totals']==[48,0,0] and d['test_suites']==8 and len(d['commands'])==16,'focused checks')
for n,h in d['source_before'].items():need(sha((R/n).read_bytes())==h==d['source_after'][n],'unchanged tested input '+n)
files={'checks/'+p.name:p.read_bytes() for p in D.iterdir() if p.is_file()}
for c in d['commands']:
 for stream in ('stdout','stderr'):need(sha(files['checks/'+c[stream]])==c[stream+'_sha256'],'command log')
for n in d['source_before']:
 if not n.endswith('.bin'):files['source/'+n]=(R/n).read_bytes()
for n in ['check-zstdoxide-lazy-reader.py','package-zstdoxide-lazy-reader.py']:files['runners/'+n]=(Path('/tmp')/n).read_bytes()
projection=json.loads((E/'2026-10-13-lazy-projection.json').read_bytes())
need(sha((E/projection['archive']).read_bytes())==projection['archive_sha256'],'linked projection archive')
files['projection.json']=(E/'2026-10-13-lazy-projection.json').read_bytes()
report=dict(date='2026-10-13',status='passed',commands=16,test_suites=8,test_totals=[48,0,0],lazy_suites=4,lazy_tests_per_suite=5,legacy_greedy_reader_suites=2,legacy_greedy_reader_tests_per_suite=5,greedy_defaults_suites=2,greedy_defaults_tests_per_suite=9,no_std_configurations=4,strict_clippy_configurations=2,records=645,depth_counts=[215,215,215],row_records=342,source_bytes=18900771,initial_owner_maps=1290,exact_depth_zero_predecessors=173,source_unchanged=True,source_sha256=d['source_before'],projection_archive=projection['archive'],projection_archive_sha256=projection['archive_sha256'],qualification=d['qualification']+' Test-only common Greedy methods become crate-visible and derive complete value equality; their reading/semantic bodies and legacy fixture are unchanged. Source/name/literal spans borrow immutable bytes; metadata reservations are bounded and fallible. Binary fixture is retained in the separately verified projection archive.',archive='2026-10-13-lazy-reader.tar.gz')
files['report.json']=enc(report);files['manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())});a=E/report['archive'];need(not a.exists(),'fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('lazy-reader/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a,'r|gz') as t:actual={m.name:t.extractfile(m).read() for m in t}
need(actual=={'lazy-reader/'+n:b for n,b in files.items()},'archive readback')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files));(E/'2026-10-13-lazy-reader.json').write_bytes(enc(report));print(report['archive_bytes'],report['archive_members'])
