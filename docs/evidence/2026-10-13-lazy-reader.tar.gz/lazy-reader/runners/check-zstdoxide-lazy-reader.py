from pathlib import Path
import hashlib,json,subprocess,time,re
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path('/tmp/zstdoxide-lazy-reader-checks');D.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
paths=['src/lib.rs','tests/support/greedy_oracle.rs','tests/support/lazy_oracle.rs','tests/fixtures/reference-lazy/cases.bin','tests/fixtures/reference-lazy/provenance.json','Cargo.toml','Cargo.lock','rust-toolchain.toml']
def sources():return {p:sha((R/p).read_bytes()) for p in paths}
before=sources();results=[]
# Preserve the actual first focused safe execution instead of rerunning it.
cmd=['cargo','test','--lib','lazy_oracle_fixture::']
out=Path('/tmp/zstdoxide-lazy-reader-safe.stdout').read_bytes();err=Path('/tmp/zstdoxide-lazy-reader-safe.stderr').read_bytes()
if b'5 passed; 0 failed; 0 ignored' not in out:raise ValueError('initial focused test')
(D/'0.stdout').write_bytes(out);(D/'0.stderr').write_bytes(err)
results.append(dict(argv=cmd,exit_code=0,stdout='0.stdout',stdout_sha256=sha(out),stderr='0.stderr',stderr_sha256=sha(err),qualification='Actual initial safe execution retained from tool result; no rerun.'))
commands=[['cargo','test','--lib','lazy_oracle_fixture::',*flags] for flags in [['--features','unsafe-reference-chain'],['--features','unsafe-row-table'],['--all-features']]]
for flags in ([],['--all-features']):
 commands.extend([['cargo','test','--lib','greedy_oracle_fixture::',*flags],['cargo','test','--test','reference_greedy_defaults',*flags],['cargo','clippy','--all-targets',*flags,'--','-D','warnings']])
all_unsafe=','.join(['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-reference-chain','unsafe-row-table','unsafe-dictionary','unsafe-training'])
commands += [['cargo','check','--no-default-features',*flags] for flags in ([],['--features','unsafe-reference-chain'],['--features','unsafe-row-table'],['--features',all_unsafe])]
commands += [['cargo','fmt','--all','--','--check'],['git','diff','--check']]
for cmd in commands:
 n=len(results);start=time.monotonic();r=subprocess.run(cmd,cwd=R,capture_output=True,timeout=600)
 (D/f'{n}.stdout').write_bytes(r.stdout);(D/f'{n}.stderr').write_bytes(r.stderr)
 results.append(dict(argv=cmd,exit_code=r.returncode,seconds=time.monotonic()-start,stdout=f'{n}.stdout',stdout_sha256=sha(r.stdout),stderr=f'{n}.stderr',stderr_sha256=sha(r.stderr)))
 print(n,'passed' if r.returncode==0 else 'FAILED',' '.join(cmd),flush=True)
 if r.returncode:break
after=sources();passed=all(r['exit_code']==0 for r in results) and len(results)==len(commands)+1 and before==after
counts=[list(map(int,m)) for r in results for m in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', (D/r['stdout']).read_bytes())]
report=dict(status='passed' if passed else 'failed',commands=results,source_before=before,source_after=after,source_unchanged=before==after,test_totals=[sum(c[i] for c in counts) for i in range(3)],test_suites=len(counts),qualification='Focused Lazy reader suites on safe, isolated chain, isolated row and all; unchanged Greedy reader and permanent defaults on safe/all; strict safe/all Clippy; safe/isolated chain/isolated row/all-leaf no_std compilation. No Rust Lazy parser, complete feature matrix, new C run or timing claim.')
(D/'evidence.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
if not passed:raise SystemExit(1)
