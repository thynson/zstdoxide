from pathlib import Path
import json,time,datetime,subprocess
D=Path(__file__).parent;deadline=datetime.datetime(2026,10,27,8,32,32,tzinfo=datetime.timezone.utc).timestamp()
for path,status in [('module29-matrix/preparation.json','prepared'),('module29-engine/evidence.json','passed'),('module29-public/evidence.json','passed'),('module29-platform-final/evidence.json','passed'),('module29-native/replay.json','passed'),('module29-fuzz/corpus.json','passed')]:
 while True:
  p=Path('/private/tmp')/path
  if p.exists():
   try:j=json.loads(p.read_text())
   except json.JSONDecodeError:time.sleep(1);continue
   assert j['status']!='failed',(path,j.get('error'))
   if j['status']==status:break
  assert time.time()<deadline-60,'User deadline before full matrix dispatch'
  time.sleep(10)
subprocess.run(['python3',str(D/'check.py')],check=True)
