from pathlib import Path
import shutil,json,hashlib,datetime
D=Path(__file__).parent;S=Path('/private/tmp/module29-final');C=Path('/private/tmp/module29-candidate');S.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['src','tests','test-support','benches']:shutil.copytree(C/n,S/n)
for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(C/n,S/n)
for name,origin in [('dictionary_in_place_output_native.rs','module29-native/replay-source/tests'),('dictionary_in_place_output_platform.rs','module29-platform/source/tests'),('upstream_trained_dictionary_fuzz.rs','module29-fuzz/source/tests')]:shutil.copyfile(Path('/private/tmp')/origin/name,S/'tests'/name)
source={str(p.relative_to(S)):sha(p) for folder in ['src','tests','test-support'] for p in (S/folder).rglob('*') if p.is_file()};source.update({n:sha(S/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']})
(D/'preparation.json').write_text(json.dumps(dict(status='prepared',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=source,production_source={n:h for n,h in source.items() if n.startswith('src/')},qualification='Final independent Module29 test snapshot adds qualified native/platform adapters and the in-place persistent dictionary fuzz supplement. This is a pre-integration candidate; no promotion before Module28 closure. Focused gates must complete before full matrix dispatch.'),indent=2)+'\n')
