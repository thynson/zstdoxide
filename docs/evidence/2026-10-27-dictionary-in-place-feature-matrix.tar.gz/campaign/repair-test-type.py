from pathlib import Path
import json,shutil,hashlib,datetime
D=Path(__file__).parent;S=Path('/private/tmp/module29-final');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=json.loads((D/'evidence.json').read_text());assert j['status']=='failed' and j['error']=="AssertionError('safe-clippy')";assert len(j['commands'])==3
P=D/'initial-test-type-rejection';P.mkdir()
for p in list(D.iterdir()):
 if p.is_file() and (p.name in ['evidence.json','preparation.json','check.py'] or p.suffix=='.log'):shutil.copyfile(p,P/p.name)
name='tests/dictionary_in_place_output_platform.rs';shutil.copyfile(S/name,P/'original-platform-test.rs');p=S/name;s=p.read_text();old='    let cases: &[(&[u8], bool, &[u8], &[u8])] = &[';assert old in s;s=s.replace(old,"    type Case<'a> = (&'a [u8], bool, &'a [u8], &'a [u8]);\n    let cases: &[Case<'_>] = &[");p.write_text(s)
pre=json.loads((D/'preparation.json').read_text());pre['source'][name]=sha(p);pre.update(prior_rejection_sha256=sha(P/'evidence.json'),repair='Only a test fixture type alias changes. Failed strict Clippy receipt and original test are retained; final full matrix restarts from safe tests on the amended test snapshot. Production is unchanged.');(D/'preparation.json').write_text(json.dumps(pre,indent=2)+'\n')
for p in list(D.iterdir()):
 if p.is_file() and (p.name=='evidence.json' or p.suffix=='.log'):p.unlink()
P=Path('/private/tmp/module29-platform-final');P.mkdir();shutil.copyfile(S/name,P/'dictionary_in_place_output_platform.rs');s=Path('/private/tmp/module29-platform/check.py').read_text().replace("R=Path('/private/tmp/module29-candidate')","R=Path('/private/tmp/module29-final')").replace('dictionary, DecodeOptions::new(limit), alloc::alloc::Global)','&dictionary.view(), DecodeOptions::new(limit), alloc::alloc::Global)');(P/'check.py').write_text(s)
# The new full-matrix gate and source identities bind the amended platform test.
p=D/'check.py';p.write_text(p.read_text().replace('module29-platform/evidence.json','module29-platform-final/evidence.json'))
p=D/'after-focused.py';p.write_text(p.read_text().replace('module29-platform/evidence.json','module29-platform-final/evidence.json'))
