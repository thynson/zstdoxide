from pathlib import Path
import hashlib,json,os,re,subprocess,time,tomllib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-parser-checks');O.mkdir();env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/zstdoxide-tree-reader-target'
paths=sorted((R/'src').glob('*.rs'))+sorted((R/'tests/support').glob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock'];source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};rows=[]
def run(label,args):
 log=O/(label+'.log');start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest());rows.append(r);print(label,p.returncode,flush=True)
 if 'test' in args:
  counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)];r['tests']=counts
  if not counts or any(c[1] for c in counts):raise ValueError('test totals '+label)
 if p.returncode:raise ValueError(label)
for name,flags in [('safe',[]),('all',['--all-features'])]:
 run('full-'+name,['cargo','test','--offline','--locked',*flags])
 run('clippy-'+name,['cargo','clippy','--offline','--locked','--all-targets',*flags,'--','-D','warnings'])
features=[n for n in tomllib.loads((R/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-')]
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree']),('all',['--features',','.join(features)])]:
 run('nostd-'+name,['cargo','check','--offline','--locked','--no-default-features',*flags])
run('format',['cargo','fmt','--all','--','--check'])
assert source=={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,qualification='Private tree parser and retained owner integration with full safe/all predecessor regression suites. Public strategy 6 remains unsupported; tree roundtrips are not a C frame identity claim.'),sort_keys=True,indent=2)+'\n')
