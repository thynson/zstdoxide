"""Reconcile the Module38 streaming compiled-dictionary milestone."""
from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess, tarfile

C = Path('/private/tmp/module38-closure')
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
N = Path('/private/tmp/module38-native')
B = Path('/private/tmp/module38-benchmark')
M = Path('/private/tmp/module38-matrix')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
C.mkdir(exist_ok=True)
assert not (E / '2026-11-03-compiled-streaming-closure.json').exists()

receipts = {}
for name in ['native-platform', 'benchmarks', 'feature-matrix']:
    p = E / ('2026-11-03-compiled-streaming-' + name + '.json')
    receipts[name] = dict(file=p.name, sha256=sha(p), bytes=p.stat().st_size)
    archive = E / ('2026-11-03-compiled-streaming-' + name + '.tar.gz')
    receipts[name].update(archive=archive.name, archive_sha256=sha(archive))

source = {str(p.relative_to(R)): sha(p) for folder in ['src', 'tests', 'test-support']
          for p in (R / folder).rglob('*') if p.is_file()}
source.update({n: sha(R / n) for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']})
for path, key in [(N, 'native-platform'), (B, 'benchmarks'), (M, 'feature-matrix')]:
    e = json.loads(Path(str(path / 'evidence.json')).read_text())
    assert e['status'] == 'complete', key
    for n, h in e['source'].items():
        if n == 'tests/compiled_stream_bench.rs':
            continue
        assert source[n] == h, (key, n)
    receipts[key]['campaign_source_sha256'] = hashlib.sha256(
        json.dumps(e['source'], sort_keys=True).encode()).hexdigest()

m = json.loads((M / 'evidence.json').read_text())
assert len(m['commands']) == 75 and all(c['exit_code'] == 0 for c in m['commands'])
assert all((c.get('result_groups'), c.get('passed'), c.get('ignored')) == (125, 1848, 79)
           for c in m['commands'] if c['label'].endswith(('-full', '-release')))

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
log = subprocess.check_output(['git', 'log', '--format=%H%x09%s', '-20'], cwd=R, text=True)
required = [
    'Choose reference block engine for streaming compiled dictionaries',
    'Stream compiled dictionary frames over retained reference history',
    'Add guarded native streaming compiled-dictionary schedule',
    'Verify compiled streaming history binding against full prefix seeding',
    'Record streaming compiled-dictionary validation and timing reports',
]
for subject in required:
    assert subject in log, subject

audit = subprocess.run(['python3', 'scripts/audit_upstream_tests.py'], cwd=R,
                       capture_output=True, text=True, check=True)
inventory = {}
for line in audit.stdout.splitlines():
    matched = re.match(r'Inventory valid: (\d+) test-related sources, (\d+) explicit non-test exclusions, (\d+) named case groups', line)
    if matched:
        inventory['sources'] = int(matched.group(1))
        inventory['exclusions'] = int(matched.group(2))
        inventory['case_groups'] = int(matched.group(3))
    if line.startswith('Source migration status:'):
        inventory['source_status'] = json.loads(line.split(': ', 1)[1].replace("'", '"'))
    if line.startswith('Case migration status:'):
        inventory['case_status'] = json.loads(line.split(': ', 1)[1].replace("'", '"'))
assert inventory['sources'] == 418 and inventory['case_groups'] == 615
assert '--require-complete' not in audit.args

readme = (R / 'README.md').read_text()
todo = (R / 'TODO.md').read_text()
progress = (R / 'docs/progress.md').read_text()
assert 'Streaming compiled dictionaries' in readme
assert 'Module 38: compiled dictionary reuse in streaming frames (complete)' in todo
assert '## Module 38: compiled dictionary reuse in streaming frames complete' in progress

receipt = dict(
    status='passed',
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    head=head,
    source=source,
    production_source={n: h for n, h in source.items() if n.startswith('src/')},
    commits=[line.split('\t') for line in log.splitlines()],
    receipts=receipts,
    matrix=dict(commands=len(m['commands']), result_groups=125, passed=1848, ignored=79,
                features=m['features']),
    benchmark=json.loads((B / 'evidence.json').read_text())['summary'],
    native_rows=json.loads((N / 'evidence.json').read_text())['native_tsv'],
    upstream_inventory=inventory,
    qualification='Bounded Module38 streaming compiled-dictionary milestone complete: immutable borrowed selection, per-block reference parsing over compiled suffix plus contiguous retained history, cross-block repeats, fixed-profile admission, frame flags, session reset, guarded native streaming controls, atomic-free ARM emission, full feature/release matrix and caller-owned timing are source-bound and qualified. Native CCtx workspace reuse, prefix replacement, parameter resets that clear a selection, LDM, workers, shared compiled handles and complete upstream migration remain open.',
)
p = C / '2026-11-03-compiled-streaming-closure.json'
p.write_text(json.dumps(receipt, indent=2) + '\n')
archive = C / '2026-11-03-compiled-streaming-closure.tar.gz'
with tarfile.open(archive, 'w:gz') as t:
    t.add(p, arcname=p.name)
    t.add(Path(__file__), arcname='check.py')
assert not (E / archive.name).exists()
shutil.copyfile(p, E / p.name)
shutil.copyfile(archive, E / archive.name)
print('closure', head[:12], archive.stat().st_size)
