from pathlib import Path
import argparse,json,hashlib,tarfile,datetime,re
p=argparse.ArgumentParser();p.add_argument('stage',choices=['core','public-api','native','history','platform']);a=p.parse_args();D=Path(__file__).parent;T=Path('/private/tmp');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
config={'core':('module31-core','module31-core/source',['evidence.json'],10),'public-api':('module31-public','module31-candidate',['evidence.json'],16),'native':('module31-native','module31-native/replay-final',['build.json','native.json','replay.json'],3),'history':('module31-native-history','module31-native/replay-source',['capture.json','reference-source-audit.json','replay.json'],3),'platform':('module31-platform','module31-platform/source',['evidence.json'],13)};folder,source,receipts,count=config[a.stage];C=T/folder;S=T/source;records={n:json.loads((C/n).read_text()) for n in receipts}
for n,j in records.items():assert j['status']=='passed',(n,j['status']);assert all(r['exit_code']==0 for r in j.get('commands',[])),n
assert len(records[receipts[-1]].get('commands',[]))==count
complete={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};production=records['evidence.json']['production_source'] if a.stage=='platform' else {n:h for n,h in complete.items() if n.startswith('src/')}
for n,j in records.items():
 for path,h in j.get('source',{}).items():
  if path.startswith('src/'):assert production[path]==h,(n,path)
 for row in j.get('commands',[]):
  if 'log_sha256' in row:assert any(sha(p)==row['log_sha256'] for p in C.glob('*.log')),(n,row.get('label'))
if a.stage in ['core','public-api']:
 for row in records['evidence.json']['commands']:
  count={'unit':6,'public':5,'docs':3}.get(row['label'].rsplit('-',1)[-1])
  if count is not None:
   g=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (C/(row['label']+'.log')).read_text());assert sum(int(x) for x,_,_ in g)==count,(row['label'],g)
files={};payloads={};extensions={'.rs','.toml','.lock','.json','.py','.md','.log','.tsv','.stderr','.jsonl','.c','.txt','.ll','.o','.patch'};excluded={'target','rust-target','replay-target','miri-i686','miri-s390x','thumb-check','thumb-safe','thumb-all','host-check','source','replay-source','replay-final','probe','rust-capture','__pycache__'}
for p in C.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(C)
 if any(x in excluded or x.endswith('.dSYM') for x in rel.parts):continue
 if p.name=='fuzzer-capture.c':continue
 if any(x in ['normal-outputs','sanitized-outputs','normal-fixtures','sanitized-fixtures'] for x in rel.parts):
  h=sha(p);payloads[str(rel)]=h;files.setdefault('payloads/'+h,p);continue
 if p.suffix in extensions or p.name.startswith(('oracle-','capture-normal','capture-sanitized')):files['campaign/'+str(rel)]=p
for p in S.rglob('*'):
 if p.is_file() and p.suffix in {'.rs','.toml','.lock','.json','.py','.md','.sh','.csv','.tsv'}:files['source/'+str(p.relative_to(S))]=p
if a.stage=='platform':files['probe/lib.rs']=C/'probe/lib.rs'
files['LICENSE.zstd']=Path('/Users/lanxingcan/Workspace/zstdoxize/LICENSE.zstd');files['archive-focused.py']=Path(__file__);name='2026-10-27-frame-utility-'+a.stage;archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
result=dict(status='passed',stage=a.stage,recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,complete_source=complete,records=records,receipt_sha256={n:sha(C/n) for n in receipts},external_fixture_payloads=payloads,members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()},archive=archive.name,archive_sha256=sha(archive),qualification='Completed source-bound focused gate. Whole feature/release regression, timing and closure remain separate. Downloaded upstream source is excluded; pinned identities/patches/external executables reconstruct original captures. Preserved preparation/controller/native-sentinel rejections are not test passes. Core-only utility compilation proves no allocator dependency in this component, not whole-codec core-only support. No complete upstream parity is claimed.')
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
