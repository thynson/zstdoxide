from pathlib import Path
import json,time,subprocess
D=Path(__file__).parent
while True:
 j=json.loads((D/'capture.json').read_text())
 if j['status']=='passed':break
 assert j['status']=='running',j['status'];time.sleep(5)
subprocess.run(['python3',str(D/'check-replay.py')],check=True)
