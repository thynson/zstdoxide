from pathlib import Path
import json,difflib,hashlib
D=Path(__file__).parent;R=Path('/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99');p=R/'tests/fuzzer.c';old=p.read_text();s=old
needle='        CHECK_EQ(seed % 15, readMagic);';assert s.count(needle)==2
parts=s.split(needle);s=parts[0]
for index,(name,payload,size) in enumerate([('writer-original','skipBuff','skipLen'),('empty-original','CNBuffer','0')]):
 capture='''
        {
            const char *root=getenv("ZSTDOXIDE_UTILITY_CAPTURE_DIR");
            char path[4096];FILE *file;
            if(!root)exit(96);
            snprintf(path,sizeof(path),"%s/NAME.zst",root);file=fopen(path,"wb");
            if(!file || fwrite(compressedBuffer,1,skippableSize,file)!=skippableSize || fclose(file))exit(97);
            snprintf(path,sizeof(path),"%s/NAME.raw",root);file=fopen(path,"wb");
            if(!file || fwrite(PAYLOAD,1,LENGTH,file)!=(size_t)(LENGTH) || fclose(file))exit(98);
            snprintf(path,sizeof(path),"%s/NAME.seed",root);file=fopen(path,"w");
            if(!file || fprintf(file,"%u\\n",seed)<0 || fclose(file))exit(99);
            fprintf(stderr,"utility capture NAME seed=%u variant=%u encoded=%zu\\n",seed,seed%15,skippableSize);
        }
'''.replace('NAME',name).replace('PAYLOAD',payload).replace('LENGTH',size)
 s+=needle+capture+parts[index+1]
needle='    /* Dictionary and CCtx Duplication tests */';assert s.count(needle)==1;s=s.replace(needle,'    /* Original writer and reader assertions above completed unchanged. */\n    exit(0);\n'+needle)
(D/'fuzzer-capture.c').write_text(s);(D/'capture.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='tests/fuzzer.c',tofile='tests/fuzzer.c')));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(D/'preparation.json').write_text(json.dumps(dict(status='prepared',reference_revision='f8745da6ff1ad1e7bab384bd1f9d742439278e99',original_fuzzer_sha256=sha(p),instrumented_fuzzer_sha256=sha(D/'fuzzer-capture.c'),patch_sha256=sha(D/'capture.patch'),qualification='Read-only captures observe actual original 129KiB and empty skippable writer outputs, payloads and preceding RNG seed. Every prior original statement and assertion is preserved. Early exit follows both original write/recognize/read/variant/payload assertions; no original compression or memory lifetime behavior is replaced.'),indent=2)+'\n')
s=Path('/private/tmp/module30-native-history/capture.py').read_text().replace('ZSTDOXIDE_QUERY_CAPTURE_DIR','ZSTDOXIDE_UTILITY_CAPTURE_DIR')
a=s.index("  assert (out/'single-original.raw')");b=s.index('\n for p in',a);s=s[:a]+"  assert (out/'writer-original.raw').stat().st_size==129*1024\n  assert (out/'empty-original.raw').stat().st_size==0"+s[b:]
a=s.index("qualification='Both full");b=s.index("');save()",a)
s=s[:a]+"qualification='Normal/sanitized full original basic-test executions preserve the complete preceding history through both original skippable writer/reader assertions. Captured frames, payloads and actual seed agree. Early observation exit retains process-owned setup allocations, so ASan leak detection is intentionally disabled only for this original-history capture; bounds/undefined behavior checks remain active. Leak detection is unsupported by this macOS runtime and is also disabled for the standalone layout helper; no leak-check pass is claimed."+s[b:]
(D/'capture.py').write_text(s)
