from pathlib import Path
import subprocess,os,json,hashlib,time,re
D=Path(__file__).parent;S=Path('/private/tmp/module31-native/replay-source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native=json.loads((D/'capture.json').read_text());assert native['status']=='passed';source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()}
for p in (Path('/private/tmp/module31-candidate')/'src').glob('*.rs'):assert sha(S/'src'/p.name)==sha(p)
e=dict(status='running',source=source,native_receipt_sha256=sha(D/'capture.json'),commands=[]);env={**os.environ,'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_TARGET_DIR':str(D/'replay-target'),'ZSTDOXIDE_FRAME_UTILITY_HISTORY':str(D)}
def save():(D/'replay.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [('safe',[]),('cursor',['--features','unsafe-byte-cursor']),('all',['--all-features'])]:
  args=['cargo','test','--offline','--locked','--test','frame_utilities_history',*flags,'--','--ignored'];t=time.monotonic()
  with (D/(name+'-replay.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(name+'-replay.log'))));save();assert p.returncode==0 and '1 passed; 0 failed; 0 ignored' in (D/(name+'-replay.log')).read_text();print(name,'passed',flush=True)
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='Three Rust backends reproduce exact original 129KiB and empty skippable writes from captured preceding seed/payload state and compare every encoded byte with native. Original marker, read length, variant and payload assertions are preserved; guard/metadata/decode checks are supplemental. No C binding exists in production.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
