from pathlib import Path
import json,hashlib,tarfile,datetime
D=Path(__file__).parent;P=Path('/private/tmp/module24-preparation');R=P/'zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99';A=P/'zstd-f8745da6.tar.gz';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();expected='4b0bd1f0cfb25e61b9103c35f27395530ff5b4c0d2513a00fd745849e85ea52c';assert sha(A)==expected
paths=sorted(str(p.relative_to(R)) for folder in ['lib','programs','tests'] for p in (R/folder).rglob('*') if p.is_file() and p.suffix in ['.c','.h','.S']);records={}
with tarfile.open(A,'r:gz') as tar:
 members={m.name.split('/',1)[1]:m for m in tar.getmembers() if '/' in m.name and m.isfile()}
 for n in paths:
  assert n in members,n;raw=tar.extractfile(members[n]).read();digest=hashlib.sha256(raw).hexdigest();assert sha(R/n)==digest,n;records[n]=digest
p=D/'reference-source-audit.json';assert not p.exists();p.write_text(json.dumps(dict(status='passed',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reference_revision='f8745da6ff1ad1e7bab384bd1f9d742439278e99',archive_sha256=expected,compiled_source_and_header_inventory=records,qualification='Actual external lib/programs/tests C/header/assembly files match the pinned downloaded archive byte for byte. This explicit audit includes datagen/util/timefn and their headers outside lib. It is a current source identity observation, not invented historical pre-build hash evidence.'),indent=2)+'\n');print(len(records),'pinned reference C/header/assembly files matched')
