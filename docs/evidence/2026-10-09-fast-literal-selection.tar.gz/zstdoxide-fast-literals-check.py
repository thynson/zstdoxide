import hashlib,io,json,os,pathlib,re,subprocess,tarfile,time
root=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize')
revision='a5ec297cf3250c7a044ff7b0537121454b79ba64'
snapshot=pathlib.Path('/tmp/zstdoxide-fast-literals-snapshot-a5ec297')
snapshot.mkdir()
paths=['src','tests','test-support','scripts','benches','Cargo.toml','Cargo.lock','rust-toolchain.toml','AGENTS.md']
archive=subprocess.check_output(['git','archive',revision,*paths],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar: tar.extractall(snapshot,filter='data')
(snapshot/'src/literal_encode.rs').write_bytes((root/'src/literal_encode.rs').read_bytes())
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def manifest(): return {str(p.relative_to(snapshot)):sha(p) for p in sorted(snapshot.rglob('*')) if p.is_file()}
source_manifest=manifest()
features='unsafe-byte-cursor,unsafe-bitstream,unsafe-history,unsafe-ring-history,unsafe-fse,unsafe-fse-encoder,unsafe-huffman,unsafe-huffman-codebook,unsafe-match-table,unsafe-match-chain,unsafe-dictionary,unsafe-training'
checks=[]
for name,flags in [('safe',[]),('bitstream',['--features','unsafe-bitstream']),('huffman',['--features','unsafe-huffman']),('codebook',['--features','unsafe-huffman-codebook']),('fse',['--features','unsafe-fse']),('inverse-fse',['--features','unsafe-fse-encoder']),('all',['--all-features']),('no-std-safe',['--no-default-features']),('no-std-all',['--no-default-features','--features',features])]:
 checks.append(('literals-'+name,['cargo','+nightly-2026-10-08','test','--lib','literal_encode::tests',*flags,'--','--nocapture'],14,{}))
for name,flags in [('safe',[]),('all',['--all-features'])]:
 checks.append(('defaults-'+name,['cargo','+nightly-2026-10-08','test','--release','--test','match_search_defaults',*flags],7,{}))
 checks.append(('clippy-'+name,['cargo','+nightly-2026-10-08','clippy','--all-targets',*flags,'--','-D','warnings'],None,{}))
checks.extend([
 ('no-std-check-safe',['cargo','+nightly-2026-10-08','check','--no-default-features'],None,{}),
 ('no-std-check-all',['cargo','+nightly-2026-10-08','check','--no-default-features','--features',features],None,{}),
 ('format',['rustfmt','+nightly-2026-10-08','--edition','2024','--check','src/literal_encode.rs'],None,{}),
])
for name in ['fast_raw_only_uses_only_the_section_owner_and_ignores_previous_coverage','fast_raw_only_failure_recovers_with_borrowed_non_clone_allocator','fast_gain_equality_falls_back_but_the_literal_header_is_excluded']:
 checks.append(('miri-'+name,['python3','scripts/check_miri_filter.py','--all-features','--lib','literal_encode::tests::'+name,'--','--exact','--nocapture'],1,{'MIRIFLAGS':'-Zmiri-strict-provenance'}))
env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/zstdoxide-fast-literals-target'
result={'initial_compile_diagnostic':{'log':'/tmp/zstdoxide-fast-literals-initial.log','sha256':sha('/tmp/zstdoxide-fast-literals-initial.log'),'exit_code':101,'qualification':'Two test-only unavailable Clone calls replaced with immutable codeword snapshots.'},'initial_corrected_log':{'path':'/tmp/zstdoxide-fast-literals-initial-corrected.log','sha256':sha('/tmp/zstdoxide-fast-literals-initial-corrected.log'),'qualification':'14 passed; unrelated coordinator block_entropy work-in-progress dead-code warnings excluded from final immutable snapshot.'},'base_revision':revision,'snapshot':str(snapshot),'copied_override':'src/literal_encode.rs','source_sha256':sha(snapshot/'src/literal_encode.rs'),'source_manifest':source_manifest,'target_dir':env['CARGO_TARGET_DIR'],'commands':[],'miri_scope':'Host interpretation with strict provenance, not native foreign execution; three bounded exact selectors; no source edits during checks.'}
out=pathlib.Path('/tmp/zstdoxide-fast-literals-evidence.json')
def save():out.write_text(json.dumps(result,indent=2)+'\n')
save()
for name,command,count,extra in checks:
 log=pathlib.Path('/tmp/zstdoxide-fast-literals-'+name+'.log');start=time.monotonic()
 with log.open('w') as f: p=subprocess.run(command,cwd=snapshot,env=env|extra,stdout=f,stderr=subprocess.STDOUT)
 data=log.read_text();summaries=[{'passed':int(a),'failed':int(b),'ignored':int(c)} for a,b,c in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',data)]
 result['commands'].append({'name':name,'command':command,'cwd':str(snapshot),'environment':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']}|extra,'exit_code':p.returncode,'seconds':time.monotonic()-start,'log':str(log),'sha256':sha(log),'summaries':summaries})
 save();print(name,p.returncode,summaries,flush=True)
 if p.returncode: raise SystemExit(p.returncode)
 if count is not None and sum(v['passed'] for v in summaries)!=count: raise SystemExit('unexpected passing count')
result['source_unchanged']=manifest()==source_manifest
result['workspace_owned_source_unchanged']=sha(root/'src/literal_encode.rs')==result['source_sha256']
if not result['source_unchanged'] or not result['workspace_owned_source_unchanged']: raise SystemExit('source changed')
result['result']='passed';save()
