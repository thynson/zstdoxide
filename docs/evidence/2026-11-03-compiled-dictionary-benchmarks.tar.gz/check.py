"""Module37 compiled-state versus per-call staging timing qualification.

Builds the release harness under safe and all features, runs two independent
repeats per configuration after the in-test CPU barrier, checks byte/guard
ledgers and sample counts, and writes a geometric-mean summary.
"""
from pathlib import Path
import os, subprocess, json, hashlib, time, datetime, re, signal, shutil

D = Path(__file__).parent
S = D / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
deadline = datetime.datetime.fromisoformat('2026-11-03T07:30:00+00:00').timestamp()
assert deadline - time.time() >= 120
source = {str(p.relative_to(S)): sha(p) for folder in ['src', 'tests', 'test-support'] for p in (S / folder).rglob('*') if p.is_file()}
source.update({n: sha(S / n) for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']})
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), deadline_utc='2026-11-03T07:30:00+00:00', source=source, production_source={n: h for n, h in source.items() if n.startswith('src/')}, commands=[], qualification='Compiled-state and per-call-staging caller-owned workloads share the same inputs, dictionaries and output buffers; compiled construction and dictionary preparation are outside every clock. Each role runs two rounds of forty samples after an in-test CPU barrier, and each configuration is run twice. Scratch allocation is included in both roles; no universal benefit or native identity is claimed.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(D / 'target'), 'CARGO_BUILD_JOBS': '6', 'CARGO_INCREMENTAL': '0'}


def save():
    (D / 'evidence.json').write_text(json.dumps(e, indent=2) + '\n')


def run(label, args, extra=None, cwd=S):
    remaining = deadline - time.time() - 15
    if remaining < 15:
        raise TimeoutError('deadline before ' + label)
    e['active_command'] = dict(label=label, argv=args, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    start = time.monotonic()
    log = D / (label + '.log')
    with log.open('xb') as f:
        p = subprocess.Popen(args, cwd=cwd, env={**env, **(extra or {})}, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = p.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGTERM)
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                p.wait()
            raise TimeoutError('deadline during ' + label)
    row = dict(label=label, argv=args, environment=extra or {}, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
    if code == 0 and label.endswith('-harness'):
        rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text())
        assert rows == [('1', '0', '0')], (label, rows)
        row.update(passed=1)
    e['commands'].append(row)
    e.pop('active_command', None)
    save()
    print(label, code, flush=True)
    assert code == 0, (label, log.read_text()[-3000:])


def ledger_hash(folder):
    return sha(folder / 'ledger.tsv')


save()
try:
    for label, flags in [('safe', []), ('all', ['--all-features'])]:
        run(label + '-clippy', ['cargo', 'clippy', '--offline', '--locked', '--test', 'compiled_dictionary_bench', *flags, '--', '-D', 'warnings'])
        for repeat in [1, 2]:
            out = D / (label + '-repeat-' + str(repeat))
            out.mkdir()
            run(label + '-run-' + str(repeat), ['cargo', 'test', '--offline', '--locked', '--release', '--test', 'compiled_dictionary_bench', 'compiled_and_per_call_staging_caller_owned_workloads', '--', '--ignored', '--exact', '--nocapture'], dict(ZSTDOXIDE_COMPILED_BENCH=str(out)))
    run('format', ['cargo', 'fmt', '--all', '--', '--check'])
    ledgers = {}
    for label in ['safe', 'all']:
        ledgers[label] = []
        for repeat in [1, 2]:
            d = D / (label + '-repeat-' + str(repeat))
            samples = (d / 'samples.tsv').read_text().splitlines()
            ledger = (d / 'ledger.tsv').read_text().splitlines()
            assert len(samples) == 2881, (label, repeat, len(samples))
            assert len(ledger) == 19, (label, repeat, len(ledger))
            assert all(line.split('\t')[5] == '1' for line in ledger[1:])
            ledgers[label].append(ledger_hash(d))
    assert ledgers['safe'][0] == ledgers['safe'][1] == ledgers['all'][0] == ledgers['all'][1]
    e['input_sha256'] = ledgers['safe'][0]
    save()
    summary = subprocess.run(['python3', str(D / 'summarize.py'), str(D)], cwd=D, check=True, capture_output=True, text=True)
    print(summary.stdout)
    e.update(status='passed', summary=json.loads((D / 'summary.json').read_text()))
    save()
except TimeoutError as ex:
    e.update(status='interrupted-at-deadline', error=repr(ex)); save(); raise
except BaseException as ex:
    e.update(status='failed', error=repr(ex)); save(); raise

