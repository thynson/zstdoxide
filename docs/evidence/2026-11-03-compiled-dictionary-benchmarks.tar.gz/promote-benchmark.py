"""Promote the qualified Module37 timing campaign."""
from pathlib import Path
import json, hashlib, subprocess, shutil

D = Path(__file__).parent
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
name = '2026-11-03-compiled-dictionary-benchmarks'
p = D / (name + '.json')
r = json.loads(p.read_text())
assert r['status'] == 'passed' and sha(D / r['archive']) == r['archive_sha256']
s = r['summary']
changed = []
for q in [p, D / r['archive']]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
    changed.append('docs/evidence/' + q.name)
p = R / 'TODO.md'
text = p.read_text()
task = '- [ ] Compare compiled-state and per-call-staging workloads with independent repeats after CPU barriers.'
assert text.count(task) == 1
text = text.replace(task, task.replace('[ ]', '[x]'))
p.write_text(text)
changed.append('TODO.md')
p = R / 'docs/prepared-dictionary-benchmarks.md'
p.write_text(f'''# Compiled-state and per-call staging measurements

Eighteen deterministic case/level pairs cover Fast, DoubleFast, chain,
BinaryTreeLazy2 and formatted-dictionary inputs. Both roles write the same
caller-owned destination with the same input, dictionary, request and output
capacity; compiled construction and dictionary preparation are outside every
clock. Each role runs two rounds of forty samples after an in-test CPU barrier,
and the safe and all-feature configurations are each run twice. Scratch
allocation is included in both roles.

Qualification ledgers are byte-identical across all four runs: eighteen cases,
one decode check each, and 2,880 timed samples per run. Fast, DoubleFast, chain,
row and the formatted entropy seed produce equal frames; the tree cases record
their measured differences as in the frame comparison.

Safe overall compiled/staging geometric-mean time ratio is
{s['safe_overall_ratio']:.4f}. Per-configuration ratios:
{s['per_configuration']}. A ratio below one means the compiled path was faster
on this workload. No universal backend, tree-shape, allocation or native
workspace benefit is claimed; compiled tables were built before timing and the
per-call staging path rebuilds its seeds inside each clock. See
`evidence/{name}.json` and the campaign archive for raw samples.
''')
changed.append('docs/prepared-dictionary-benchmarks.md')
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *changed], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Record compiled dictionary timing results'], cwd=R, check=True)
print('module37 benchmarks promoted at', subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()[:12])
