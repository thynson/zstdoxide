//! Compiled-state versus per-call staging timing, caller-owned output.

use std::alloc::Global;
use std::hint::black_box;
use std::time::{Duration, Instant};
use zstdoxide::{
    CompiledDictionary, CompressionParameterRequest, DecodeOptions, Dictionary, SharedDictionary,
    compress_into_with_compiled, compress_into_with_parameters_and_dictionary,
    decompress_with_dictionary_in,
};

const FORMATTED: &[u8] = include_bytes!("upstream/dictionaries/formatted.dict");
const TEXT: &[u8] = include_bytes!("upstream/dictionaries/dictionary-treeless-literals.expected");

fn noise(mut state: u32, length: usize) -> Vec<u8> {
    (0..length)
        .map(|_| {
            state ^= state.wrapping_shl(13);
            state ^= state >> 17;
            state ^= state.wrapping_shl(5);
            state as u8
        })
        .collect()
}

struct Case {
    label: &'static str,
    level: i32,
    dictionary: SharedDictionary,
    input: Vec<u8>,
}

fn cases() -> Vec<Case> {
    let content = noise(0x51ce_5eed, 4096);
    let raw = Dictionary::raw(&content).unwrap().into_shared();
    let formatted = Dictionary::from_bytes(FORMATTED).unwrap().into_shared();
    let mut cases = Vec::new();
    let inputs = [
        content[..2048].to_vec(),
        [
            &content[..1024],
            &noise(0x1234_5678, 1024),
            &content[1024..2048],
        ]
        .concat(),
        noise(0x9abc_def0, 4096),
        [content.as_slice(), content.as_slice()].concat(),
    ];
    for level in [1, 3, 4, 9] {
        for (index, input) in inputs.iter().enumerate() {
            cases.push(Case {
                label: match (level, index) {
                    (1, 0) => "fast-prefix",
                    (1, 1) => "fast-interleaved",
                    (1, 2) => "fast-noise",
                    (1, 3) => "fast-repeat",
                    (3, 0) => "double-fast-prefix",
                    (3, 1) => "double-fast-interleaved",
                    (3, 2) => "double-fast-noise",
                    (3, 3) => "double-fast-repeat",
                    (4, 0) => "chain-prefix",
                    (4, 1) => "chain-interleaved",
                    (4, 2) => "chain-noise",
                    (4, 3) => "chain-repeat",
                    (9, 0) => "tree-prefix",
                    (9, 1) => "tree-interleaved",
                    (9, 2) => "tree-noise",
                    (9, 3) => "tree-repeat",
                    _ => unreachable!(),
                },
                level,
                dictionary: raw.clone(),
                input: input.clone(),
            });
        }
    }
    for (index, input) in [TEXT.to_vec(), [TEXT, TEXT].concat()].iter().enumerate() {
        cases.push(Case {
            label: if index == 0 {
                "prepared-json"
            } else {
                "prepared-json-repeat"
            },
            level: 1,
            dictionary: formatted.clone(),
            input: input.clone(),
        });
    }
    cases
}

fn request(level: i32, input: &[u8]) -> CompressionParameterRequest {
    let mut request = CompressionParameterRequest::with_level(level);
    request
        .set_source_hint(u32::try_from(input.len()).unwrap())
        .unwrap();
    request
}

fn barrier() {
    let start = Instant::now();
    let mut value = 0_u64;
    while start.elapsed() < Duration::from_millis(500) {
        for _ in 0..10_000 {
            value = value.wrapping_mul(6364136223846793005).wrapping_add(1);
        }
        black_box(value);
    }
}

#[test]
#[ignore = "requires ZSTDOXIDE_COMPILED_BENCH and release calibration"]
fn compiled_and_per_call_staging_caller_owned_workloads() {
    let output_root = std::env::var_os("ZSTDOXIDE_COMPILED_BENCH").unwrap();
    let root = std::path::PathBuf::from(output_root);
    std::fs::create_dir_all(&root).unwrap();
    let mut rows = String::from("case\trole\tround\tsample\tns\n");
    let mut ledger = String::from("case\tlevel\tstaging_bytes\tcompiled_bytes\tequal\tdecoded\n");
    for case in cases() {
        let request = request(case.level, &case.input);
        let compiled = CompiledDictionary::new(case.dictionary.view(), &request, Global).unwrap();
        let mut staging_output = vec![0xa5; case.input.len() + 128];
        let mut compiled_output = vec![0xa5; case.input.len() + 128];
        let staging_len = compress_into_with_parameters_and_dictionary(
            &case.input,
            &mut staging_output,
            &request,
            &case.dictionary,
        )
        .unwrap();
        let compiled_len =
            compress_into_with_compiled(&case.input, &mut compiled_output, &request, &compiled)
                .unwrap();
        let equal = staging_len == compiled_len
            && staging_output[..staging_len] == compiled_output[..compiled_len];
        assert_eq!(
            decompress_with_dictionary_in(
                &compiled_output[..compiled_len],
                &case.dictionary.view(),
                DecodeOptions::new(case.input.len()),
                Global,
            )
            .unwrap(),
            case.input,
            "{}",
            case.label
        );
        ledger.push_str(&format!(
            "{}\t{}\t{}\t{}\t{}\t1\n",
            case.label, case.level, staging_len, compiled_len, equal
        ));
        for round in 0..2 {
            barrier();
            for sample in 0..40 {
                let start = Instant::now();
                let written = compress_into_with_parameters_and_dictionary(
                    &case.input,
                    &mut staging_output,
                    &request,
                    &case.dictionary,
                )
                .unwrap();
                black_box(&staging_output[..written]);
                rows.push_str(&format!(
                    "{}\tstaging\t{}\t{}\t{}\n",
                    case.label,
                    round,
                    sample,
                    start.elapsed().as_nanos()
                ));
            }
            barrier();
            for sample in 0..40 {
                let start = Instant::now();
                let written = compress_into_with_compiled(
                    &case.input,
                    &mut compiled_output,
                    &request,
                    &compiled,
                )
                .unwrap();
                black_box(&compiled_output[..written]);
                rows.push_str(&format!(
                    "{}\tcompiled\t{}\t{}\t{}\n",
                    case.label,
                    round,
                    sample,
                    start.elapsed().as_nanos()
                ));
            }
        }
        drop(compiled);
    }
    std::fs::write(root.join("samples.tsv"), rows).unwrap();
    std::fs::write(root.join("ledger.tsv"), ledger).unwrap();
}
