"""Archive the qualified Module37 compiled/staging timing campaign."""
from pathlib import Path
import json, hashlib, tarfile, datetime

D = Path(__file__).parent
C = Path('/private/tmp/module37-benchmark')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
j = json.loads((C / 'evidence.json').read_text())
assert j['status'] == 'passed'
assert len(j["commands"]) == 7, len(j['commands'])
files = {}
for p in C.rglob('*'):
    if not p.is_file():
        continue
    n = p.relative_to(C)
    if any(x in {'target', '__pycache__', 'calib'} for x in n.parts):
        continue
    if n.name.startswith('oracle-'):
        continue
    if p.suffix in {'.rs', '.toml', '.lock', '.json', '.py', '.log', '.md', '.tsv'}:
        files[str(n)] = p
files['archive-benchmark.py'] = Path(__file__)
name = '2026-11-03-compiled-dictionary-benchmarks'
archive = D / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
r = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source=j['source'], production_source=j['production_source'], commands=j['commands'], summary=j['summary'], source_evidence_sha256=j.get('input_sha256'), members={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()}, archive=archive.name, archive_sha256=sha(archive), qualification='Compiled-state and per-call-staging caller-owned workloads share inputs, dictionaries and output buffers; compiled construction and dictionary preparation are outside every clock. Each role runs two rounds of forty samples after an in-test CPU barrier, and each configuration is run twice. Scratch allocation is included in both roles; no universal benefit or native identity is claimed.')
(D / (name + '.json')).write_text(json.dumps(r, indent=2) + '\n')
print(name, archive.stat().st_size)
