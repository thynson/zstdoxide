from pathlib import Path
import argparse,json,hashlib,datetime,subprocess,tarfile
p=argparse.ArgumentParser();p.add_argument('module',choices=['27']);a=p.parse_args();R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';T=Path('/private/tmp');D=T/('module'+a.module+'-reconciliation');D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
slugs={'23':'caller-output','24':'stable-output','25':'dictionary-output','26':'stable-dictionary-output','27':'stable-prefix-output'};slug=slugs[a.module]
patterns={'23':['2026-10-23-caller-output-*.json','2026-10-26-caller-output-*.json'],'24':['2026-10-26-stable-output-*.json'],'25':['2026-10-26-dictionary-output-*.json'],'26':['2026-10-26-stable-dictionary-output-*.json'],'27':['2026-10-26-stable-prefix-output-*.json','2026-10-26-stable-prefix-attachment-state.json']}[a.module]
records={}
for pattern in patterns:
 for path in sorted(E.glob(pattern)):
  if path.name.endswith('-closure.json'):continue
  j=json.loads(path.read_text());assert j['status']=='passed',path
  if 'archive' in j:assert sha(E/j['archive'])==j['archive_sha256'],path
  records[path.name]=dict(sha256=sha(path),archive=j.get('archive'),archive_sha256=j.get('archive_sha256'))
required=['feature-matrix','benchmarks','native','platform','public-api']+(['isolated-full'] if a.module=='23' else ['attachment-state' if a.module=='27' else 'storage','engine','streaming-corpus' if a.module=='24' else 'corpus'])
for label in required:assert any(n.endswith('-'+label+'.json') for n in records),(label,records)
assert '2026-10-26-stable-prefix-output-lifecycle.json' in records
production={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')}
bench=json.loads((E/('2026-10-26-'+slug+'-benchmarks.json')).read_text());assert bench['build']['production_source']==production
matrix=json.loads((E/('2026-10-26-'+slug+'-feature-matrix.json')).read_text())
for n,h in production.items():assert matrix['source'][n]==h,n
platform=json.loads(next(E.glob('*-'+slug+'-platform.json')).read_text())
for n,h in production.items():assert platform['source'][n]==h,('platform',n)
native=json.loads(next(E.glob('*-'+slug+'-native.json')).read_text())
if a.module in ['25','26','27']:
 for n,h in production.items():assert native['rust']['source'][n]==h,('native Rust replay',n)
elif a.module=='23':
 for n,h in production.items():assert native['source'][n]==h,('native Rust replay',n)
else:
 public=json.loads((E/'2026-10-26-stable-output-public-api.json').read_text())
 with tarfile.open(E/public['archive'],'r:gz') as tar:
  original=tar.extractfile('campaign/public.json').read()
 assert hashlib.sha256(original).hexdigest()==native['public_evidence_sha256']
 for n,h in production.items():assert json.loads(original)['source'][n]==h,('native public replay',n)
if a.module!='23':
 corpus=json.loads((E/('2026-10-26-'+slug+('-streaming-corpus' if a.module=='24' else '-corpus')+'.json')).read_text())
 for n,h in production.items():assert corpus['focused']['source'][n]==h,('corpus',n)

lifecycle=json.loads((E/'2026-10-26-stable-prefix-output-lifecycle.json').read_text())
for n,h in production.items():assert lifecycle['rust']['source'][n]==h,('prefix lifecycle',n)

# Final inventories may change only metadata after frozen full-suite checks.
for n,h in matrix['source'].items():
 if n!='tests/upstream/manifest.json':assert sha(R/n)==h,('final matrix',n)
if a.module=='24':
 fuzz=json.loads((E/'2026-10-26-stable-output-streaming-corpus.json').read_text())
 assert sha(R/'tests/stable_stream_fuzz.rs')==fuzz['focused']['source']['tests/stable_stream_fuzz.rs']
if a.module!='23':
 inv=json.loads((D/'evidence.json').read_text());assert inv['status']=='passed' and sha(R/'tests/upstream/manifest.json')==inv['final_manifest_sha256']
previous={'23':'2026-10-23-ultra2-retained-closure.json','24':'2026-10-26-caller-output-closure.json','25':'2026-10-26-stable-output-closure.json','26':'2026-10-26-dictionary-output-closure.json','27':'2026-10-26-stable-dictionary-output-closure.json'}[a.module]
if previous:assert json.loads((E/previous).read_text())['status']=='passed'
args=['python3','scripts/audit_upstream_tests.py','--upstream',str(T/'module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99')]
with (D/'integrated-inventory.log').open('xb') as f:q=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
assert q.returncode==0
out=E/('2026-10-26-'+slug+'-closure.json');assert not out.exists()
result=dict(status='passed',module=int(a.module),recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,verified_evidence=records,predecessor_closure=previous,predecessor_closure_sha256=sha(E/previous) if previous else None,integrated_manifest_sha256=sha(R/'tests/upstream/manifest.json'),inventory_log_sha256=sha(D/'integrated-inventory.log'),driver_sha256=sha(Path(__file__)),qualification='This bounded module has completed focused, full safe/isolated/all, no_std, Clippy, native/corpus/platform and measured primary/repeat gates. Every current-module archive/report pair above is rehashed; earlier historical implementation snapshots remain separate and are not relabelled as final-source runs. Current production matches final matrix, platform and timed executables. Inventory-only reconciliation leaves codec/test source unchanged except separately qualified Module24 additive fuzz. Complete upstream migration and unsupported contracts remain open; no universal unsafe speedup is claimed.')
archive=out.with_suffix('.tar.gz')
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 tar.add(__file__,arcname='reconcile-closure.py')
 for item in sorted(D.iterdir()):
  if item.is_file():tar.add(item,arcname='reconciliation/'+item.name)
result.update(archive=archive.name,archive_sha256=sha(archive),integration_commit_before_closure=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip())
out.write_text(json.dumps(result,indent=2)+'\n');print(out)
