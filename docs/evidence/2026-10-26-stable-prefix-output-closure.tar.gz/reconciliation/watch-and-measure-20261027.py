"""Start only after Module26 closure and Module27 final matrix dispatch."""
from pathlib import Path
import datetime,hashlib,json,subprocess,time,re,os,signal
T=Path('/private/tmp');D=Path(__file__).parent;B=T/'module27-benchmark';M=T/'module27-matrix/evidence.json';A=D/'2026-10-26-stable-prefix-output-feature-matrix.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,27,8,32,32,tzinfo=datetime.timezone.utc).timestamp()
assert json.loads(Path('/Users/lanxingcan/Workspace/zstdoxize/docs/evidence/2026-10-26-stable-dictionary-output-closure.json').read_text())['status']=='passed'
while True:
 if time.time()>=deadline-30:raise TimeoutError('User window reached before prefix timing')
 if M.exists():
  try:j=json.loads(M.read_text())
  except json.JSONDecodeError:time.sleep(1);continue
  assert j['status'] in ['running','passed'],j.get('error')
  if j['status']=='passed' and A.exists():break
 time.sleep(15)
j=json.loads(A.read_text());assert j['status']=='passed' and len(j['commands'])==69 and sha(D/j['archive'])==j['archive_sha256']
pattern=re.compile(r'(?:/|\s)(?:rustc|cargo)(?:\s|$)|/private/tmp/module(?:2[3-8])-[^ ]*target/|/private/tmp/module(?:2[3-8])-(?:matrix/check|isolated-full/check|preparation/prune-|margin-platform/check|margin/(?:check|build-native|compare|content-size)|archives/(?:archive-|after-)|(?:native|platform|fuzz|lifecycle-native)/[^ ]*(?:check|run|build))')
pattern = re.compile(pattern.pattern + r'|/private/tmp/module28-session-archives/archive-stage.py|/private/tmp/module28-(?:storage|engine|public|corpus)/check.py|/private/tmp/module28-native/check-replay.py|/private/tmp/module28-benchmark/(?:build|after-build|repeat-build).py')
# New-window work must finish all dispatched CPU stages before the barrier.
for receipt,expected in [
 ('module28-storage/evidence.json','passed'),
 ('module28-corpus/evidence.json','passed'),
 ('module28-engine/evidence.json','passed'),
 ('module28-public/evidence.json','passed'),
 ('module28-platform/evidence.json','passed'),
 ('module28-native/replay.json','passed'),
 ('module28-benchmark/evidence.json','qualified-not-timed'),
 ('module28-benchmark/harness-check.json','passed'),
 ('module28-benchmark/repeat/evidence.json','qualified-not-timed'),
]:
 while True:
  path=T/receipt
  if path.exists():
   try:status=json.loads(path.read_text())['status']
   except json.JSONDecodeError:time.sleep(1);continue
   assert status!='failed',(receipt,status)
   if status==expected:break
  if time.time()>=deadline-30:raise TimeoutError('User window reached before '+receipt)
  time.sleep(5)
observations=[]
while len(observations)<2:
 raw=subprocess.check_output(['ps','-axo','pid,ppid,pcpu,etime,command'],text=True);matches=[line.strip() for line in raw.splitlines()[1:] if pattern.search(line)]
 if matches:observations=[]
 else:observations.append(dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),active_task_or_compiler_processes=matches))
 if time.time()>=deadline-30:raise TimeoutError('User window reached before prefix CPU barrier')
 time.sleep(5)
p=B/'cpu-barrier.json';assert not p.exists();p.write_text(json.dumps(dict(status='passed',matrix_archive_sha256=j['archive_sha256'],matrix_receipt_sha256=sha(A),process_observations=observations,observer_sha256=sha(Path(__file__)),qualification='Two actual process inventories after full source/log archival show no matched task compiler/test/CPU campaign/cache-prune/archive processes. Whole desktop idleness is not claimed.'),indent=2)+'\n')
state=D/'timing-state.json';state.write_text(json.dumps({'status':'running'},indent=2)+'\n');print('Prefix CPU barrier passed; measuring primary and independent repeat.',flush=True)
for name in ['measure.py','measure-repeat.py']:
 remaining=deadline-time.time()-30
 if remaining<30:raise TimeoutError('User window reached before '+name)
 args=['python3',str(B/name)];process=subprocess.Popen(args,start_new_session=True)
 try:code=process.wait(timeout=remaining)
 except subprocess.TimeoutExpired:
  os.killpg(process.pid,signal.SIGTERM)
  try:process.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
  state.write_text(json.dumps({'status':'interrupted-at-user-deadline','argv':args},indent=2)+'\n');raise
 assert code==0,(name,code)
subprocess.run(['python3',str(B/'summarize.py')],check=True)
state.write_text(json.dumps({'status':'passed','qualification':'Both timed children ended before summary/archive generation.'},indent=2)+'\n')
subprocess.run(['python3',str(D/'archive-benchmark.py'),'27'],check=True);subprocess.run(['python3',str(D/'render-benchmark-report.py'),'27'],check=True)
(D/'measured-archives-complete.json').write_text(json.dumps({'status':'passed'},indent=2)+'\n');print('Prefix timings and archives complete.',flush=True)
