/* External test oracle only; compiled with pinned facebook/zstd v1.5.7. */
#include "zstd.h"
#include "zstd_errors.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
static unsigned char *read_file(const char *root,const char *name,const char *suffix,size_t *size) {
    char path[4096]; FILE *f; long n; unsigned char *p;
    if(snprintf(path,sizeof(path),"%s/%s.%s",root,name,suffix)<0)exit(10);
    f=fopen(path,"rb"); if(!f || fseek(f,0,SEEK_END) || (n=ftell(f))<0 || fseek(f,0,SEEK_SET))exit(11);
    *size=(size_t)n;p=malloc(*size?*size:1);if(!p || fread(p,1,*size,f)!=*size || fclose(f))exit(12);return p;
}
static void guards(const unsigned char *p,size_t n) {
    size_t i;for(i=0;i<16;i++)if(p[i]!=0xa5 || p[16+n+i]!=0xa5)exit(13);
}
int main(int argc,char **argv) {
    FILE *list;char path[4096],name[128];int fields;
    if(argc!=3 || ZSTD_versionNumber()!=10507)return 2;
    snprintf(path,sizeof(path),"%s/cases.txt",argv[1]);list=fopen(path,"r");if(!list)return 3;
    while((fields=fscanf(list,"%127s",name))==1) {
        size_t n,rust_size,dict_size,bound,native_size,i,j,capacities[9];unsigned char *input=read_file(argv[1],name,"input",&n),*rust=read_file(argv[1],name,"rust",&rust_size),*dictionary=read_file(argv[1],name,"dict",&dict_size),*decoded,*native;
        ZSTD_CCtx *cc=ZSTD_createCCtx(); ZSTD_DCtx *dc=ZSTD_createDCtx();
        ZSTD_CDict *cd=ZSTD_createCDict(dictionary,dict_size,3); ZSTD_DDict *dd=ZSTD_createDDict(dictionary,dict_size);
        if(!cc || !dc || !cd || !dd)return 17;
        decoded=malloc(n+32);bound=ZSTD_compressBound(n);native=malloc(bound?bound:1);if(!decoded || !native || ZSTD_isError(bound))return 4;
        memset(decoded,0xa5,n+32);i=ZSTD_decompress_usingDDict(dc,decoded+16,n,rust,rust_size,dd);if(ZSTD_isError(i)||i!=n||memcmp(decoded+16,input,n))return 5;guards(decoded,n);
        native_size=ZSTD_compress_usingCDict(cc,native,bound,input,n,cd);if(ZSTD_isError(native_size))return 6;
        snprintf(path,sizeof(path),"%s/%s.zst",argv[2],name);{FILE *f=fopen(path,"wb");if(!f || fwrite(native,1,native_size,f)!=native_size || fclose(f))return 7;}
        capacities[0]=0;capacities[1]=1;capacities[2]=5;capacities[3]=6;capacities[4]=9;capacities[5]=native_size-1;capacities[6]=native_size;capacities[7]=native_size+7;capacities[8]=bound;
        for(j=0;j<9;j++) {
            size_t cap=capacities[j],result,changed=0;unsigned char *storage=malloc(cap+32);if(!storage)return 8;
            memset(storage,0xa5,cap+32);result=ZSTD_compress_usingCDict(cc,storage+16,cap,input,n,cd);guards(storage,cap);
            if(!ZSTD_isError(result)) {
                size_t d;if(result>cap)return 9;memset(decoded,0xa5,n+32);d=ZSTD_decompress_usingDDict(dc,decoded+16,n,storage+16,result,dd);
                if(ZSTD_isError(d)||d!=n||memcmp(decoded+16,input,n))return 14;guards(decoded,n);
                for(i=result;i<cap;i++)if(storage[16+i]!=0xa5)changed++;
                snprintf(path,sizeof(path),"%s/%s-cap%zu.zst",argv[2],name,j);
                {FILE *f=fopen(path,"wb");if(!f || fwrite(storage+16,1,result,f)!=result || fclose(f))return 18;}
            }
            printf("%s\t%zu\t%zu\t%s\t%zu\t%u\t%zu\n",name,j,cap,ZSTD_isError(result)?"error":"ok",ZSTD_isError(result)?0:result,(unsigned)ZSTD_getErrorCode(result),changed);
            free(storage);
        }
        /* Check immutable inputs after all native operations against saved files. */
        {size_t a,b;unsigned char *x=read_file(argv[1],name,"input",&a),*y=read_file(argv[1],name,"rust",&b);if(a!=n||b!=rust_size||memcmp(x,input,n)||memcmp(y,rust,rust_size))return 15;free(x);free(y);}
        {size_t a;unsigned char *x=read_file(argv[1],name,"dict",&a);if(a!=dict_size||memcmp(x,dictionary,a))return 19;free(x);}
        ZSTD_freeCCtx(cc);ZSTD_freeDCtx(dc);ZSTD_freeCDict(cd);ZSTD_freeDDict(dd);
        free(input);free(rust);free(dictionary);free(decoded);free(native);
    }
    if(fields!=EOF || ferror(list) || fclose(list))return 16;
    return 0;
}
