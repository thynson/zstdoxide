from pathlib import Path
import sys,json,os,subprocess,time,hashlib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(R/'scripts'))
import ultra_path_capture_plan as plan
from capture_ultra_paths import prepare
U=Path('/private/tmp/zstdoxide-reference-lazy-1.5.7');O=Path('/private/tmp/zstdoxide-ultra-path-preflight-1016');need=plan.require;need(not O.exists(),'fresh preflight');O.mkdir();(O/'generated').mkdir();source=plan.source_manifest();upstream,output,compiler,_,_,rows=prepare(U,O/'planned-capture','clang');records=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,data in plan.generated(U).items():(O/'generated'/name).write_bytes(data)
for name in source:
 p=O/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/name).read_bytes())
commands=[]
for mode in ['normal','sanitized']:
 for kind in ['syntax','dependencies','predefines']:
  row=next(r for r in rows if r['label']==mode+'-'+('compile-25'if kind=='syntax'else kind));argv=[str(O/'generated')if str(a)==str(output/'generated')else a for a in row['argv']]
  if kind=='syntax':argv=argv[:-4]+['-fsyntax-only',str(R/plan.HELPER)]
  commands.append((mode+'-'+kind,argv))
env={k:v for k,v in os.environ.items()if k in ['PATH','HOME','TMPDIR','SDKROOT','DEVELOPER_DIR']}
def save(status,error=None):(O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,source_unchanged=plan.source_manifest()==source,commands=records,planned_commands=len(rows)),indent=2)+'\n')
save('running')
try:
 for label,argv in commands:
  start=time.monotonic();log=O/(label+'.log')
  with log.open('w')as f:r=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
  records.append(dict(label=label,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=log.name,sha256=sha(log)));save('running')
  need(r.returncode==0,label)
 save('passed')
except BaseException as error:save('failed',repr(error));raise
