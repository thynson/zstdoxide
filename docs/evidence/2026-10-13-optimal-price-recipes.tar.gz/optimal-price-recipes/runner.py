from pathlib import Path
import hashlib,json,subprocess
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-optimal-price-recipes-checks');O.mkdir()
paths=['docs/reference-optimal-price-protocol.md','scripts/oracles/optimal_prices.py','scripts/oracles/optimal_prices_v2.py','scripts/oracles/optimal_price_recipes.py','scripts/check_optimal_price_protocol.py','scripts/check_optimal_price_protocol_v2.py','scripts/check_optimal_price_recipes.py','tests/fixtures/reference-optimal-price-recipes/recipes.json','tests/fixtures/reference-optimal-price-recipes/README.md'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths};commands=[]
for name,flags in [('normal',[]),('optimized',['-O'])]:
 for script in ['check_optimal_price_protocol.py','check_optimal_price_protocol_v2.py','check_optimal_price_recipes.py']:
  argv=['python3',*flags,'scripts/'+script];log=O/(name+'-'+script+'.log');p=subprocess.run(argv,cwd=R,capture_output=True);log.write_bytes(p.stdout+p.stderr)
  if p.returncode or json.loads(p.stdout)['status']!='passed':raise ValueError(name+' '+script)
  commands.append(dict(argv=argv,exit_code=p.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
if source!={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths}:raise ValueError('source unchanged')
(O/'evidence.json').write_text(json.dumps(dict(status='passed',source=source,commands=commands,recipes=147,source_bytes=9835338,operations=2018,qualification='Source-only pre-execution hypotheses. Frozen v1 still passes; v2 adds bounded repeated updates to exercise all frequency-table rescaling. No C observations or Optimal support.'),sort_keys=True,indent=2)+'\n')
