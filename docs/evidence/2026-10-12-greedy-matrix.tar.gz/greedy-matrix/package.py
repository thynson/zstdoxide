from pathlib import Path
import hashlib,io,json,re,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-module14-final-matrix')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,m):
 if not v:raise ValueError(m)
e=json.loads((O/'evidence.json').read_bytes());before=json.loads((O/'source-before.json').read_bytes());after=json.loads((O/'source-after.json').read_bytes());snap=json.loads((O/'snapshot.json').read_bytes())
need(e['status']=='passed' and e['source_unchanged'] and before==after,'complete immutable run')
for n,k in [('snapshot.json','snapshot_sha256'),('source-before.json','source_before_sha256'),('source-after.json','source_after_sha256')]:need(sha((O/n).read_bytes())==e[k],n+' identity')
comparisons={};differences=[]
for n,h in before.items():
 need(sha((O/'source'/n).read_bytes())==h,'snapshot source '+n)
 p=R/n;same=p.is_file() and sha(p.read_bytes())==h
 if n.startswith(('src/','tests/','scripts/','examples/','benches/','test-support/')) or n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml'):comparisons[n]=same
 elif not same:differences.append(n)
need(all(comparisons.values()),'delivered tested source')
suites=[]
for c in e['commands']:
 need(c['exit_code']==c['expected_exit'] and c['exception'] is None,'command status '+c['label']);b=Path(c['log']).read_bytes();need(sha(b)==c['log_sha256'],'log '+c['label'])
 if c['kind'] in ('full-suite','allocator-suite','doc-examples'):
  counts=[list(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',b)];totals=[sum(x[i] for x in counts) for i in range(5)]
  need(counts==c['test_harnesses'] and totals==c['totals'],'parsed counts')
  if c['kind']=='full-suite':need(totals==[1098,0,54,0,0],'full suite totals');suites.append(c)
  elif c['kind']=='allocator-suite':need(totals==[13,0,0,0,0],'allocator suite')
  else:need(totals==[22,0,0,0,0],'doc examples')
need(len(suites)==17 and e['full_suite_totals']==[18666,0,918,0,0],'seventeen suites')
need(len([c for c in e['commands'] if c['label'].startswith('nostd-')])==16,'sixteen no_std configurations')
gate=next(c for c in e['commands'] if c['label']=='known-incomplete');need(gate['exit_code']==1 and gate['unfinished_source_units']==[188],'explicit incomplete migration')
report=dict(date='2026-10-12',status='passed',base=e['base'],commands=len(e['commands']),source_comparisons=comparisons,documentation_differences=differences,source_unchanged=True,full_suites=17,per_suite_totals=[1098,0,54,0,0],full_suite_totals=e['full_suite_totals'],totals_order=['passed','failed','ignored','measured','filtered'],no_std_configurations=16,allocator_tests=13,registered_examples_per_mode=22,known_unfinished_upstream_sources=188,qualification='All pre-existing codec/test/dependency inputs match the immutable snapshot. Later additive std-only Greedy benchmark files and Module15 source-review/oracle preparation were not retroactively included in this matrix. The nine newly added reference_greedy_defaults tests have separate focused safe/chain/row/all evidence; their frozen complete frames and owner records also passed all sixteen clock-free benchmark configurations. No ignored oracle campaigns, new C capture, Miri or timing runs are claimed here.',archive='2026-10-12-greedy-matrix.tar.gz')
files={p.name:p.read_bytes() for p in O.iterdir() if p.is_file()}
for r in snap['overlays']:files['overlays/'+r['path']]=(O/'source'/r['path']).read_bytes()
files['runner.py']=Path('/tmp/zstdoxide-module14-matrix-runner.py').read_bytes();files['package.py']=Path(__file__).read_bytes();files['review.json']=enc(report)
files['bundle-manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())})
a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh archive');prefix='greedy-matrix/'
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo(prefix+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:found={m.name:t.extractfile(m).read() for m in t}
need(found=={prefix+n:b for n,b in files.items()},'archive exact bytes')
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(files));(R/'docs/evidence/2026-10-12-greedy-matrix.json').write_bytes(enc(report));print(len(e['commands']),len(files),a.stat().st_size)
