"""Archive the qualified module35 public coordinator API campaign."""
from pathlib import Path
import json, hashlib, tarfile, re, datetime

D = Path(__file__).parent
C = Path('/private/tmp/module35-public')
S = C / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
j = json.loads((C / 'evidence.json').read_text())
assert j['status'] == 'passed' and len(j['commands']) == 21
for n, h in j['source'].items():
    assert sha(S / n) == h, n
expected = {'unit': (1, 4, 0), 'public': (1, 6, 0), 'docs': (2, 3, 0)}
for r in j['commands']:
    assert r['exit_code'] == 0 and sha(C / (r['label'] + '.log')) == r['log_sha256']
    suffix = r['label'].rsplit('-', 1)[-1]
    if suffix in expected:
        g = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (C / (r['label'] + '.log')).read_text())
        counts = (len(g), sum(int(a) for a, _, _ in g), sum(int(i) for _, _, i in g))
        assert counts == expected[suffix], (r['label'], counts)
files = {}
for p in C.rglob('*'):
    if not p.is_file():
        continue
    n = p.relative_to(C)
    if any(x == 'target' or x.endswith('-target') or x == '__pycache__' for x in n.parts):
        continue
    if p.suffix in {'.rs', '.toml', '.lock', '.json', '.py', '.log', '.md', '.tsv'}:
        files[str(n)] = p
files['archive-public.py'] = Path(__file__)
name = '2026-10-28-one-shot-encode-public-api'
archive = D / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
r = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source=j['source'], production_source={n: h for n, h in j['source'].items() if n.startswith('src/')}, commands=j['commands'], members={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()}, archive=archive.name, archive_sha256=sha(archive), qualification='Public caller-owned one-shot encode selection API. Documented constructor/replacement methods, attempt-exact prefix consumption, output/lifetime guards and independent allocator-failure qualification pass on the final production source identity. No native schedule, foreign platform, full feature matrix, timing or closure is claimed here.')
(D / (name + '.json')).write_text(json.dumps(r, indent=2) + '\n')
print(name, archive.stat().st_size)
