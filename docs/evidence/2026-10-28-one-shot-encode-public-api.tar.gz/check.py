from pathlib import Path
import os,subprocess,json,hashlib,time,datetime,tomllib,re,signal
D=Path(__file__).parent;S=D/'source';R=Path('/Users/lanxingcan/Workspace/zstdoxize');T=Path('/private/tmp');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,28,9,38,0,tzinfo=datetime.timezone.utc).timestamp()
prior=T/'module35-core/evidence.json';j=json.loads(prior.read_text());assert j['status']=='passed' and len(j['commands'])==17
pre=json.loads((D/'preparation.json').read_text())
for n,h in pre['core_source'].items():assert j['source'][n]==h,n
for n,h in pre['source'].items():assert sha(S/n)==h,n
assert sha(S/'tests/one_shot_encode.rs')==pre['public_test_sha256']
source={str(p.relative_to(S)):sha(p) for folder in ['src','tests','test-support'] for p in (S/folder).rglob('*') if p.is_file()};source.update({n:sha(S/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']});features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'));assert len(features)==22
plan=[]
for name,flags,no in [('safe',[],[]),('sink',['--features','unsafe-frame-sink'],['--features','unsafe-frame-sink']),('dictionary',['--features','unsafe-dictionary'],['--features','unsafe-dictionary']),('all',['--all-features'],['--features',','.join(features)])]:
 plan += [(name+'-unit',['cargo','test','--offline','--locked','--lib','one_shot_encode::tests',*flags]),(name+'-public',['cargo','test','--offline','--locked','--test','one_shot_encode',*flags]),(name+'-docs',['cargo','test','--offline','--locked','--doc','one_shot_encode::OneShotEncoder',*flags]),(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*no]),(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])]
plan += [('format',['cargo','fmt','--all','--','--check'])];assert len(plan)==21;assert not (D/'evidence.json').exists();e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=source,predecessor_closure_sha256=sha(prior),plan=plan,commands=[])
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module35-public-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for label,args in plan:
  remaining=deadline-time.time()-30
  if remaining<30:raise TimeoutError('Work window reached before '+label)
  e['active_command']=label;save();start=time.monotonic()
  with (D/(label+'.log')).open('xb') as f:
   p=subprocess.Popen(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=remaining)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise TimeoutError('Work window reached during '+label)
  row=dict(label=label,argv=args,exit_code=code,seconds=time.monotonic()-start,log_sha256=sha(D/(label+'.log')))
  if code==0 and label.endswith(('-unit','-public','-docs')):
   groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (D/(label+'.log')).read_text());count={'unit':4,'public':6,'docs':3}[label.rsplit('-',1)[-1]];assert sum(int(g[0]) for g in groups)==count and all(g[1:]==('0','0') for g in groups) and len(groups)==(2 if label.endswith('-docs') else 1),(label,groups);row.update(passed=count,failed=0,ignored=0,result_groups=len(groups))
  e['commands'].append(row);e.pop('active_command',None);save();print(label,code,flush=True);assert code==0,label
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except TimeoutError as ex:e.update(status='interrupted-at-user-deadline',error=repr(ex));save();raise
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
