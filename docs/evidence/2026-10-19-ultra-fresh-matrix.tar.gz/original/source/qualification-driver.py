import argparse,datetime,hashlib,json,os,subprocess,time,tomllib
from pathlib import Path
ROOT=Path('/private/tmp/zstdoxide-ultra-ordinary-matrix-source')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
p=argparse.ArgumentParser();p.add_argument('stage',choices=['reader','implementation','matrix']);a=p.parse_args()
out=Path('/private/tmp')/('ultra-fresh-'+a.stage+'-checks');out.mkdir()
(out/'logs').mkdir();(out/'source').mkdir()
features=[f for f in tomllib.loads((ROOT/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-')]
names=sorted({str(p.relative_to(ROOT)) for folder in ['src','tests','test-support'] for p in (ROOT/folder).rglob('*') if p.is_file() and (p.suffix in ['.rs','.bin','.json','.toml','.tsv'] or p.name in ['Cargo.lock','Cargo.toml'])}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml'})
source={name:sha(ROOT/name) for name in names}
for name in source:
 if name.endswith(('.rs','.toml')) or name in ['Cargo.lock']:
  target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/name).read_bytes())
(out/'source/qualification-driver.py').write_bytes(Path(__file__).read_bytes())
rows=[]
def add(label,args,timeout=900):rows.append(dict(label=label,argv=args,timeout_seconds=timeout))
add('rustc-version',['rustc','-vV']);add('cargo-version',['cargo','--version']);add('format',['cargo','fmt','--all','--','--check'])
if a.stage=='reader':
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  add(name+'-reader',['cargo','test',*flags,'--test','reference_ultra_fresh_fixture','--test','reference_optimal_fresh_wide_fixture','--test','reference_ultra_path_fixture'])
 add('release-reader',['cargo','test','--release','--all-features','--test','reference_ultra_fresh_fixture'])
elif a.stage=='implementation':
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  add(name+'-parser',['cargo','test',*flags,'--lib','optimal_parse::'])
  add(name+'-ordinary-search',['cargo','test',*flags,'--lib','optimal_search::ultra_fresh_tests'])
 add('release-parser',['cargo','test','--release','--all-features','--lib','ultra_fresh'])
else:
 for name,flags in [('safe',[]),*[(f,['--features',f])for f in features],('all',['--all-features'])]:
  add(name+'-focused',['cargo','test',*flags,'--lib','ultra_fresh'])
  add(name+'-reader',['cargo','test',*flags,'--test','reference_ultra_fresh_fixture'])
  no_std=[] if name=='safe' else ['--features',','.join(features) if name=='all' else name]
  add(name+'-no-std',['cargo','check','--lib','--no-default-features',*no_std])
 for name,flags in [('safe',[]),('all',['--all-features'])]:add(name+'-full',['cargo','test',*flags],1800)
 add('release-parser',['cargo','test','--release','--all-features','--lib','optimal_parse::'])
for name,flags in [('safe',[]),('all',['--all-features'])]:
 add(name+'-clippy',['cargo','clippy',*flags,'--all-targets','--','-D','warnings'],1200)
if a.stage!='matrix':
 for name,flags in [('safe',[]),('all',['--features',','.join(features)])]:
  add(name+'-no-std',['cargo','check','--lib','--no-default-features',*flags])
env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR','RUSTUP_HOME','CARGO_HOME','DEVELOPER_DIR','SDKROOT'] if k in os.environ}
env.update(CARGO_TARGET_DIR='/private/tmp/zstdoxide-ultra-matrix-target',CARGO_BUILD_JOBS='2',LANG='C',LC_ALL='C',TZ='UTC')
evidence=dict(status='running',stage=a.stage,started_at=now(),cwd=str(ROOT),environment=env,source=source,plan=rows,commands=[])
def save():(out/'evidence.json').write_text(json.dumps(evidence,sort_keys=True,indent=2)+'\n')
save()
try:
 for row in rows:
  label=row['label'];start=time.monotonic();log=out/'logs'/(label+'.log')
  with log.open('xb') as stream:
   done=subprocess.run(row['argv'],cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,timeout=row['timeout_seconds'])
  record=dict(row,exit_code=done.returncode,seconds=time.monotonic()-start,log=dict(path=str(log.relative_to(out)),bytes=log.stat().st_size,sha256=sha(log)))
  evidence['commands'].append(record);save();print(label,done.returncode,round(record['seconds'],2),flush=True)
  if done.returncode:raise ValueError('failed command '+label)
 if {name:sha(ROOT/name) for name in names}!=source:raise ValueError('source changed during qualification')
 evidence.update(status='passed',completed_at=now(),source_unchanged=True);save()
except BaseException as error:
 evidence.update(status='failed',error=repr(error),completed_at=now());save();raise
