"""Complete the private snapshot only if its all-feature command times out."""
import collections,hashlib,json,re,shutil,subprocess,time
from pathlib import Path
P=Path('/private/tmp/ultra-fresh-matrix-checks');O=Path('/private/tmp/ultra-fresh-matrix-resumed');e=json.loads((P/'evidence.json').read_text());R=Path(e['cwd'])
def need(v,m):
 if not v:raise ValueError(m)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def counts(s):
 a=[tuple(map(int,x))for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',s)]
 return {k:sum(v[i]for v in a)for i,k in enumerate(['passed','failed','ignored'])}
def heads(s):return list(re.finditer(r'^\s*(?:Running (?:unittests (src/lib\.rs)|tests/([a-zA-Z0-9_]+)\.rs) \(|Doc-tests (zstdoxide))',s,re.M))
def signature(s):return collections.Counter(re.findall(r'^test (.+?) \.\.\. (ok|ignored|FAILED)(?:,|$)',s,re.M))
need(e['status']=='failed' and 'TimeoutExpired' in e['error'],'only documented command timeout');need(e['commands'][-1]['label']=='safe-full','expected interrupted all-feature command')
need(all(sha(R/n)==h for n,h in e['source'].items()),'same private source snapshot')
partial=P/'logs/all-full.log';s=partial.read_text();h=heads(s);prefix=s[:h[-1].start()];baseline=(P/'logs/safe-full.log').read_text();all_heads=heads(baseline);need(len(h)<len(all_heads),'incomplete integration suffix')
remaining=[v[2]or'doc'for v in all_heads[len(h)-1:]];need(remaining[-1]=='doc'and all(x!='doc'for x in remaining[:-1]),'integration/doc suffix')
argv=['cargo','test','--all-features']
for name in remaining[:-1]:argv+=['--test',name]
plan=[dict(label='all-remaining-integration',argv=argv,timeout_seconds=1800),dict(label='all-remaining-doc',argv=['cargo','test','--all-features','--doc'],timeout_seconds=600)]+e['plan'][next(i for i,v in enumerate(e['plan'])if v['label']=='all-full')+1:]
O.mkdir();(O/'logs').mkdir();shutil.copytree(P,O/'original');(O/'resume-driver.py').write_bytes(Path(__file__).read_bytes());new=dict(status='running',source=e['source'],commands=[],resume=dict(original_status=e['status'],original_error=e['error'],partial_sha256=sha(partial),prefix_characters=h[-1].start(),remaining_groups=remaining))
for c in e['commands']:
 c=dict(c,log=dict(c['log'],path='original/'+c['log']['path']));new['commands'].append(c)
def save():(O/'evidence.json').write_text(json.dumps(new,sort_keys=True,indent=2)+'\n')
save()
for row in plan:
 p=O/'logs'/(row['label']+'.log');start=time.monotonic()
 with p.open('xb')as f:result=subprocess.run(row['argv'],cwd=R,env=e['environment'],stdout=f,stderr=subprocess.STDOUT,timeout=row['timeout_seconds'])
 c=dict(row,exit_code=result.returncode,seconds=time.monotonic()-start,log=dict(path=str(p.relative_to(O)),bytes=p.stat().st_size,sha256=sha(p)));new['commands'].append(c);save();print(row['label'],result.returncode,flush=True);need(result.returncode==0,'failed continuation')
a=signature(prefix)
for label in ['all-remaining-integration','all-remaining-doc']:a+=signature((O/'logs'/(label+'.log')).read_text())
need(a==signature(baseline),'complete exact all-feature individual outcomes');need(all(sha(R/n)==v for n,v in e['source'].items()),'source unchanged');need(sha(partial)==new['resume']['partial_sha256'],'stable interrupted log')
new.update(status='passed',source_unchanged=True,full_suite_totals=counts(baseline),qualification='The focused 21-configuration product and safe full suite passed in the original private snapshot. Its all-feature Cargo command timed out without assertion failure. Only complete groups followed by another Cargo group were retained; the final child and remaining integration/doc groups were rerun, reproducing every safe-suite individual outcome. Release parser, safe/all Clippy and source barriers pass. The original failed orchestration record and complete logs remain archived.');save()
