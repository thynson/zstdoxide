import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

root = Path('/Users/lanxingcan/Workspace/zstdoxize')
out = Path('/tmp/zstdoxide-match-search-fixture-validation')
records = []

def run(label, command, code, message=None):
    result = subprocess.run(command, cwd=root, capture_output=True)
    data = result.stdout + result.stderr
    (out / (label + '.log')).write_bytes(data)
    if result.returncode != code or (message and message.encode() not in data):
        raise RuntimeError((label, result.returncode, data.decode()))
    records.append(dict(label=label, command=command, expected_exit_code=code,
                        exit_code=result.returncode, log=label + '.log',
                        sha256=hashlib.sha256(data).hexdigest()))

run('root-offline-audit', ['python3', 'scripts/check_upstream_fixtures.py'], 0)
run('root-shell-syntax', ['sh', '-n', 'scripts/check_upstream_oracles.sh'], 0)
with tempfile.TemporaryDirectory(prefix='zstdoxide-fixture-audit-negative-') as name:
    temporary = Path(name)
    shutil.copytree(root / 'tests/upstream', temporary / 'tests/upstream')
    shutil.copytree(root / 'scripts', temporary / 'scripts', ignore=shutil.ignore_patterns('__pycache__'))
    command = ['python3', str(root / 'scripts/check_upstream_fixtures.py'), '--root', str(temporary)]
    run('root-copy-audit', command, 0)
    fixture = temporary / 'tests/upstream/match-search/vectors.tsv'
    original = fixture.read_bytes()
    fixture.write_bytes(original.replace(b'\t0\n', b'\t1\n', 1))
    run('root-reject-fixture-mutation', command, 1, 'match-search/vectors.tsv: SHA-256 differs')
    fixture.write_bytes(original)
    importer = temporary / 'scripts/import_match_search_fixtures.py'
    original_importer = importer.read_bytes()
    importer.write_bytes(original_importer + b'\n# altered copy\n')
    run('root-reject-importer-mutation', command, 1, 'match-search: local importer SHA-256 differs')
    importer.write_bytes(original_importer)
    shutil.rmtree(temporary / 'tests/upstream/match-search')
    run('root-reject-missing-collection', command, 1, 'match-search/manifest.json: cannot read manifest')

evidence = {'scope': 'Independent root review of required collection registration and generic offline rejection paths; isolated copies only',
            'commands': records,
            'audit_script_sha256': hashlib.sha256((root / 'scripts/check_upstream_fixtures.py').read_bytes()).hexdigest(),
            'oracle_runner_sha256': hashlib.sha256((root / 'scripts/check_upstream_oracles.sh').read_bytes()).hexdigest()}
(out / 'root-checks.json').write_text(json.dumps(evidence, indent=2) + '\n')
print(json.dumps({'checks': len(records), 'all_expected_results': True}))
