from pathlib import Path
import argparse,json,hashlib,tarfile,datetime,re
p=argparse.ArgumentParser();p.add_argument('stage',choices=['engine','public-api','native','platform','corpus']);a=p.parse_args();D=Path(__file__).parent;T=Path('/private/tmp');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
config={'engine':('module29-engine','source',['evidence.json']),'public-api':('module29-public',None,['evidence.json']),'native':('module29-native','replay-source',['build.json','native.json','rust.json','difference-probe.json','replay.json']),'platform':('module29-platform','source',['evidence.json']),'corpus':('module29-fuzz','source',['focused.json','corpus.json'])};name,sub,receipts=config[a.stage];C=T/name;S=C/sub if sub else T/'module29-candidate';records={n:json.loads((C/n).read_text()) for n in receipts}
for n,j in records.items():assert j['status']=='passed',(n,j['status']);assert all(row['exit_code']==0 for row in j.get('commands',[])),n
complete={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};production={n:h for n,h in complete.items() if n.startswith('src/')}
for n,j in records.items():
 for path,h in j.get('source',{}).items():
  if path.startswith('src/'):assert production[path]==h,(n,path)
 for row in j.get('commands',[]):
  if 'log_sha256' in row:assert any(sha(p)==row['log_sha256'] for p in C.glob('*.log')),(n,row['label'])
if a.stage in ['engine','public-api']:
 for row in records['evidence.json']['commands']:
  suffix=row['label'].split('-',1)[-1];expected={'slice_history::dictionary_resume_tests':2,'in_place_decode':8,'public':7,'engine':8}.get(suffix)
  if expected is not None:assert f'{expected} passed; 0 failed; 0 ignored' in (C/(row['label']+'.log')).read_text(),row['label']
  if suffix=='docs':
   groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (C/(row['label']+'.log')).read_text());assert sum(int(x) for x,_,_ in groups)==3
files={};fixtures={};text_extensions={'.rs','.toml','.lock','.json','.py','.md','.log','.tsv','.stderr','.jsonl','.c','.txt','.ll','.o'}
excluded={'target','rust-target','replay-target','miri-i686','miri-s390x','thumb-check','thumb-safe','thumb-all','corrected-thumb-safe','corrected-thumb-all','probe','corrected-probe','source','replay-source','rust-capture','__pycache__'}
for p in C.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(C)
 if any(x in excluded or x.endswith('.dSYM') for x in rel.parts):continue
 if a.stage=='native' and rel.parts[0] in ['inputs','normal-replay','sanitized-replay','rust-safe','rust-move','rust-history','rust-dictionary','rust-all']:continue
 if p.suffix in text_extensions or p.name.startswith('oracle-'):files['campaign/'+str(rel)]=p
for p in S.rglob('*'):
 if p.is_file() and p.suffix in {'.rs','.toml','.lock','.json','.py','.md','.sh','.csv','.tsv'}:files['source/'+str(p.relative_to(S))]=p
if a.stage=='native':
 for folder in ['inputs','normal-replay']:
  for p in (C/folder).iterdir():
   if p.is_file():h=sha(p);fixtures[str(p.relative_to(C))]=h;files.setdefault('payloads/'+h,p)
if a.stage=='platform':
 # The corrected probe changes only observation code; retain it explicitly.
 files['corrected-probe/src/lib.rs']=C/'corrected-probe/src/lib.rs'
files['LICENSE.zstd']=Path('/Users/lanxingcan/Workspace/zstdoxize/LICENSE.zstd')
name='2026-10-27-dictionary-in-place-'+a.stage;archive=D/(name+'.tar.gz');assert not archive.exists();files['archive-focused.py']=Path(__file__)
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
result=dict(status='passed',stage=a.stage,recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,complete_source=complete,records=records,receipt_sha256={n:sha(C/n) for n in receipts},external_fixture_payloads=fixtures,members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()},archive=archive.name,archive_sha256=sha(archive),qualification='Completed source-bound focused gate; full matrix and measurements remain separate. Recursive source inventory binds unchanged repository fixtures; native supplemental payloads are content-addressed. Prior observation-probe compile rejections remain distinct from corrected successful executions. Foreign evidence is interpretation/code generation, not hardware execution. No native implementation dependency or complete upstream parity is claimed.')
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
