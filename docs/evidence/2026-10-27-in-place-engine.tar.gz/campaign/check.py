from pathlib import Path
import os, subprocess, json, time, hashlib, datetime
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module28-engine-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
e=dict(status='running',source={str(p.relative_to(S)):sha(p) for p in (S/'src').rglob('*.rs')},config_sha256=sha(S/'Cargo.toml'),commands=[])
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 start=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log_sha256=sha(D/(label+'.log'))));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
save()
try:
 run('format',['cargo','fmt','--all','--','--check'])
 for name,flags in [('safe',[]),('move',['--features','unsafe-in-place-buffer']),('history',['--features','unsafe-slice-history']),('combined',['--features','unsafe-in-place-buffer,unsafe-slice-history'])]:
  for module in ['in_place_decode']:
   run(name+'-'+module,['cargo','test','--offline','--locked','--lib',*flags,module+'::tests::'])
  run(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*flags])
  run(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])
 for n,h in e['source'].items():assert sha(S/n)==h,n
 assert sha(S/'Cargo.toml')==e['config_sha256']
 e.update(status='passed',qualification='Focused private in-place coordinator checks; public API, full regression and independent native shared-buffer qualification remain pending.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
