"""Module35 final matrix: safe/all and every isolated feature, release, format.

Prepared against the assembled module35 final source. Expected per full-suite
counts are confirmed by actual full-suite executions recorded in
module35-matrix/confirmations.json before dispatch; every -full and -release
command must report exactly that many groups/passed/ignored with zero
failures. External ignored tests are never credited as passes.
"""
from pathlib import Path
import datetime, hashlib, json, os, re, signal, subprocess, time, tomllib

D = Path('/private/tmp/module35-matrix')
D.mkdir(exist_ok=True)
S = Path('/private/tmp/module35-final')
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
T = Path('/private/tmp')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
deadline = datetime.datetime.fromisoformat('2026-10-28T09:38:00+00:00').timestamp()
assert deadline - time.time() >= 120
CONFIRMED = json.loads((D / 'confirmations.json').read_text())
COUNTS = tuple(CONFIRMED['expected'])
assert all((c['groups'], c['passed'], c['ignored']) == COUNTS for c in CONFIRMED['runs'])
features = sorted(f for f in tomllib.loads((S / 'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'))
assert len(features) == 22
source = {str(p.relative_to(S)): sha(p) for folder in ['src', 'tests', 'test-support'] for p in (S / folder).rglob('*') if p.is_file()}
source.update({n: sha(S / n) for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']})
for n, h in json.loads((T / 'module35-final-plan' / 'assembly-receipt.json').read_text())['source'].items():
    assert source[n] == h, ('Final source changed before dispatch', n)
assembly = sha(T / 'module35-final-plan' / 'assembly-receipt.json')
corpus = sha(T / 'module35-final-corpus' / 'evidence.json')
formal = sha(T / 'module35-formal-phase' / 'evidence.json')
plan = []
for name, flags in [('safe', []), ('all', ['--all-features'])] + [(f, ['--features', f]) for f in features]:
    plan.append((name + '-full', ['cargo', 'test', '--offline', '--locked', *flags]))
    plan.append((name + '-no-std', ['cargo', 'check', '--offline', '--locked', '--lib', '--no-default-features', *flags]))
    plan.append((name + '-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--tests', *flags, '--', '-D', 'warnings']))
plan += [('safe-release', ['cargo', 'test', '--offline', '--locked', '--release']),
         ('all-release', ['cargo', 'test', '--offline', '--locked', '--release', '--all-features']),
         ('format', ['cargo', 'fmt', '--all', '--', '--check'])]
assert len(plan) == 75
assert not (D / 'evidence.json').exists()
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         deadline_utc='2026-10-28T09:38:00+00:00', features=features, source=source,
         expected_counts=list(COUNTS), confirmed_by=CONFIRMED['runs'],
         gates=dict(assembly_receipt=assembly, final_corpus=corpus, formal_phase=formal),
         commands=[], plan=plan,
         qualification='Full feature/release regression of the assembled module35 final source. Safe/all and all 22 isolated unsafe features each run complete tests, true no_std and strict Clippy; safe/all complete release and formatting also run. Every full/release suite must report the confirmed counts with zero failures; ignored tests are not credited. The merged trained-dictionary adapter executed its focused campaign before this matrix. No milestone completion, repository integration or performance claim.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(T / 'module35-final-target'), 'CARGO_BUILD_JOBS': '6',
       'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
       'CARGO_PROFILE_DEV_DEBUG': '0'}


def counts(text):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert all(int(f) == 0 for _, f, _ in rows), 'A test group failed'
    return len(rows), sum(int(p) for p, _, _ in rows), sum(int(i) for _, _, i in rows)


def save():
    p = D / 'evidence.pending.json'
    p.write_text(json.dumps(e, indent=2) + '\n')
    p.replace(D / 'evidence.json')


save()
try:
    for label, args in plan:
        remaining = deadline - time.time() - 30
        if remaining < 30:
            raise TimeoutError('User work window reached before ' + label)
        e['active_command'] = dict(label=label, argv=args)
        save()
        start = time.monotonic()
        log = D / (label + '.log')
        with log.open('xb') as f:
            proc = subprocess.Popen(args, cwd=S, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = proc.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                raise TimeoutError('User work window reached during ' + label)
        row = dict(label=label, argv=args, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
        if label.endswith(('-full', '-release')) and code == 0:
            result = counts(log.read_text())
            assert result == COUNTS, (label, result)
            row.update(result_groups=result[0], passed=result[1], ignored=result[2])
        e['commands'].append(row)
        e.pop('active_command', None)
        save()
        print(label, code, flush=True)
        assert code == 0, label
    for n, h in source.items():
        assert sha(S / n) == h, ('Final source changed during matrix', n)
    assert len(e['commands']) == 75
    e.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
except TimeoutError as ex:
    e.update(status='interrupted-at-user-deadline', error=repr(ex))
    save()
    raise
except BaseException as ex:
    e.update(status='failed', error=repr(ex))
    save()
    raise
