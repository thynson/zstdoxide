"""Resume the module35 final matrix after an authorized work-window interruption.

Only an interrupted-at-user-deadline campaign with a fully successful completed
prefix is resumable. The frozen source inventory, confirmation receipt, gates
and completed logs are verified exactly as the original check verified them;
the interrupted partial log is archived under resume-attempts; then only the
unfinished commands rerun with the original environment. A partial command is
never credited.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, os, re, shutil, signal, subprocess, time

COUNTS = (117, 1766, 76)
ROOT = Path('/private/tmp')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def counts(text):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert all(int(f) == 0 for _, f, _ in rows), 'A test group failed'
    return len(rows), sum(int(p) for p, _, _ in rows), sum(int(i) for _, _, i in rows)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--deadline-utc', required=True, help='Newly authorized UTC cutoff, ISO 8601 with timezone')
    ap = p.parse_args()
    deadline_dt = datetime.datetime.fromisoformat(ap.deadline_utc)
    assert deadline_dt.tzinfo is not None and deadline_dt.utcoffset() == datetime.timedelta(0)
    deadline = deadline_dt.timestamp()
    assert deadline - time.time() >= 120
    d = ROOT / 'module35-matrix'
    s = ROOT / 'module35-final'
    evidence = d / 'evidence.json'
    original = evidence.read_bytes()
    j = json.loads(original)
    assert j['status'] in ['interrupted-at-user-deadline'], 'Never resume an active, passed or failed campaign'
    done = j['commands']
    assert all(row['exit_code'] == 0 for row in done), 'A failed command cannot be reused'
    for name, digest in j['source'].items():
        assert sha(s / name) == digest, ('Source changed', name)
    for row, (label, argv) in zip(done, j['plan']):
        assert row['label'] == label and row['argv'] == argv, 'Completed rows must be the exact plan prefix'
        log = d / (label + '.log')
        assert sha(log) == row['log_sha256'], ('Log changed', label)
        if label.endswith(('-full', '-release')):
            assert counts(log.read_text()) == COUNTS, ('Unexpected or zero test counts', label)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    attempt = d / 'resume-attempts' / stamp
    attempt.mkdir(parents=True, exist_ok=False)
    (attempt / 'prior-evidence.json').write_bytes(original)
    shutil.copyfile(__file__, attempt / 'resume.py')
    interrupted = []
    active = j.get('active_command')
    if active:
        log = d / (active['label'] + '.log')
        if log.exists():
            interrupted.append(dict(name=log.name, sha256=sha(log), bytes=log.stat().st_size))
            log.rename(attempt / log.name)
    record = dict(prior_evidence_sha256=hashlib.sha256(original).hexdigest(),
                  controller_sha256=sha(Path(__file__)),
                  resumed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  deadline_utc=deadline_dt.isoformat(),
                  completed_reused=len(done), interrupted_logs=interrupted)
    (attempt / 'reconciliation.json').write_text(json.dumps(record, indent=2) + '\n')
    j.setdefault('resume_attempts', []).append(dict(path=str(attempt.relative_to(d)), **record))
    j.pop('active_command', None)
    j.pop('error', None)
    j.update(status='running', deadline_utc=deadline_dt.isoformat())
    env = {**os.environ, 'CARGO_TARGET_DIR': str(ROOT / 'module35-final-target'), 'CARGO_BUILD_JOBS': '6',
           'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
           'CARGO_PROFILE_DEV_DEBUG': '0'}

    def save():
        temp = evidence.with_suffix('.pending.json')
        temp.write_text(json.dumps(j, indent=2) + '\n')
        temp.replace(evidence)

    save()
    try:
        for label, argv in j['plan'][len(done):]:
            remaining = deadline - time.time() - 30
            if remaining < 30:
                raise TimeoutError('User work window reached before ' + label)
            j['active_command'] = dict(label=label, argv=argv, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
            save()
            start = time.monotonic()
            log = d / (label + '.log')
            with log.open('xb') as f:
                proc = subprocess.Popen(argv, cwd=s, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    code = proc.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid, signal.SIGKILL)
                        proc.wait()
                    raise TimeoutError('User work window reached during ' + label)
            row = dict(label=label, argv=argv, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
            if code == 0 and label.endswith(('-full', '-release')):
                result = counts(log.read_text())
                assert result == COUNTS, (label, result)
                row.update(result_groups=result[0], passed=result[1], ignored=result[2])
            j['commands'].append(row)
            j.pop('active_command', None)
            save()
            print(label, code, flush=True)
            assert code == 0, label
        verify_all = j['commands']
        assert len(verify_all) == len(j['plan'])
        for row, (label, argv) in zip(verify_all, j['plan']):
            assert row['label'] == label and row['argv'] == argv and row['exit_code'] == 0
            assert sha(d / (label + '.log')) == row['log_sha256']
            if label.endswith(('-full', '-release')):
                assert counts((d / (label + '.log')).read_text()) == COUNTS
        j.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
    except TimeoutError as ex:
        j.update(status='interrupted-at-user-deadline', error=repr(ex))
        save()
        raise
    except BaseException as ex:
        j.update(status='failed', error=repr(ex))
        save()
        raise


if __name__ == '__main__':
    main()
