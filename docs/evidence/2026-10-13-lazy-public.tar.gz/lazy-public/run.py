from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/zstdoxide-lazy-public')
source_files=['src/reference_search.rs','src/reference_encode.rs','src/reference_policy.rs','tests/reference_lazy.rs','tests/reference_lazy_platform.rs','tests/reference_fast.rs','tests/reference_double_fast.rs','tests/reference_greedy.rs','tests/upstream_reference_fast.rs']
def sources():return {f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in source_files}
original=sources()
commands=[['cargo','fmt','--check'],['cargo','clippy','--all-targets','--','-D','warnings'],['cargo','clippy','--all-targets','--all-features','--','-D','warnings']]
for features in [[],['--features','unsafe-reference-chain'],['--features','unsafe-row-table'],['--all-features']]:
 commands.append(['cargo','test',*features,'--test','reference_lazy','--test','reference_lazy_platform'])
for features in [[],['--all-features']]:
 commands.append(['cargo','test',*features,'--test','reference_fast','--test','reference_double_fast','--test','reference_greedy','--test','reference_greedy_defaults','--test','upstream_reference_fast'])
 commands.append(['cargo','test','--lib',*features,'reference_policy'])
commands += [['cargo','check','--no-default-features'],['cargo','check','--no-default-features','--features','unsafe-byte-cursor,unsafe-bitstream,unsafe-history,unsafe-ring-history,unsafe-fse,unsafe-fse-encoder,unsafe-huffman,unsafe-huffman-codebook,unsafe-match-table,unsafe-match-chain,unsafe-reference-chain,unsafe-row-table,unsafe-dictionary,unsafe-training'],['python3','scripts/check_doc_examples.py'],['git','diff','--check']]
results=[]
for i,cmd in enumerate(commands):
 if sources()!=original:raise ValueError('source changed during checks')
 with (root/f'{i:02}.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':cmd,'status':r.returncode,'log':f'{i:02}.log'})
 (root/'results.json').write_text(json.dumps({'sources':original,'commands':results},indent=2)+'\n')
 print(i,r.returncode,' '.join(cmd),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
if sources()!=original:raise ValueError('final source changed')
