from pathlib import Path
import subprocess,json,hashlib,time
out=Path('/tmp/zstdoxide-optimal-retained-wide-limits');out.mkdir(exist_ok=False);rows=[]
for label,args in [('safe',[]),('all',['--all-features']),('release-all',['--release','--all-features'])]:
 argv=['cargo','test','--offline','--locked',*args,'--lib','wide_schedule_and_source_limits'];p=out/(label+'.log');start=time.monotonic()
 with p.open('wb')as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
 rows.append(dict(argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));print(label,r.returncode,flush=True)
 if r.returncode:break
else:
 for label,args in [('clippy',['clippy','--all-features','--tests','--','-D','warnings']),('fmt',['fmt','--all','--','--check'])]:
  argv=['cargo',*args];p=out/(label+'.log');start=time.monotonic()
  with p.open('wb')as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
  rows.append(dict(argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));print(label,r.returncode,flush=True)
  if r.returncode:break
(out/'evidence.json').write_text(json.dumps(dict(status='passed'if len(rows)==5 and all(v['exit_code']==0 for v in rows)else'failed',commands=rows),indent=2)+'\n')
