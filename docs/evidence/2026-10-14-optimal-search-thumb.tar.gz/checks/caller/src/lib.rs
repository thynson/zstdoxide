#![no_std]
#![feature(allocator_api)]
#![deny(unsafe_op_in_unsafe_fn)]
#![allow(dead_code)]
extern crate alloc;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/error.rs"] mod error;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/greedy_key.rs"] mod greedy_key;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/tree_layout.rs"] mod tree_layout;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/reference_tree.rs"] mod reference_tree;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_search_layout.rs"] mod optimal_search_layout;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_short_key.rs"] mod optimal_short_key;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_matches.rs"] mod optimal_matches;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_search.rs"] mod optimal_search;
pub use error::{Error,Result};
pub fn exercise(input:&[u8])->Result<usize>{
 use alloc::alloc::Global;
 use optimal_search_layout::{OptimalSearchLayout,OptimalQuery};
 let layout=OptimalSearchLayout::new(10,6,6,2,3,4096,Some(10))?;
 let tree=reference_tree::ReferenceTree::new_in(layout.tree(),Global,Global)?;
 let short=optimal_short_key::OptimalShortKey::new_in(layout.short_log(),Global)?;
 let matches=optimal_matches::OptimalMatches::new_in(Global)?;
 let mut search=optimal_search::OptimalSearch::from_parts(input,layout,tree,short,matches)?;
 let result=search.query(OptimalQuery{position:0,repeats:[0;3],zero_literals:true,length_to_beat:3})?.len();
 search.reset();Ok(result)
}
