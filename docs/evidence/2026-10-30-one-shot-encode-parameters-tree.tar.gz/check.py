"""Focused module36 tree campaign: combined staging for BinaryTreeLazy2 and the
explicit optimal-family rejection under the supported-subset clause.

Runs the complete library test suite, true no_std compilation and strict
Clippy under safe, the two isolated features the combined path exercises
(match-table and dictionary backends) and all features, plus formatting, on a
frozen source. Every full suite must report identical counts. Timing waits for
nothing: this is the family item's focused qualification, not the milestone
matrix.
"""
from pathlib import Path
import datetime, hashlib, json, os, re, signal, subprocess, time

D = Path(__file__).parent
S = D / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
deadline = datetime.datetime.fromisoformat('2026-10-30T03:46:00+00:00').timestamp()
assert deadline - time.time() >= 120
selections = [('safe', []), ('match-table', ['--features', 'unsafe-match-table']), ('dictionary', ['--features', 'unsafe-dictionary']), ('all', ['--all-features'])]
plan = []
for name, flags in selections:
    plan.append((name + '-full', ['cargo', 'test', '--offline', '--locked', '--lib', *flags]))
    plan.append((name + '-no-std', ['cargo', 'check', '--offline', '--locked', '--lib', '--no-default-features', *flags]))
    plan.append((name + '-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--tests', *flags, '--', '-D', 'warnings']))
plan.append(('format', ['cargo', 'fmt', '--all', '--', '--check']))
source = {}
for folder in ['src', 'tests', 'test-support']:
    for p in (S / folder).rglob('*'):
        if p.is_file():
            source[str(p.relative_to(S))] = sha(p)
for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']:
    source[n] = sha(S / n)
counts = re.compile(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;')


def suite_counts(text):
    rows = counts.findall(text)
    assert rows and all(f == '0' for _, f, _ in rows), 'A test group failed'
    return len(rows), sum(int(p) for p, _, _ in rows), sum(int(i) for _, _, i in rows)


e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), deadline_utc='2026-10-30T03:46:00+00:00', source=source, production_source={n: h for n, h in source.items() if n.startswith('src/')}, plan=plan, commands=[], qualification='Focused tree item only: the tree family needs no seeding because its first query back-fills the whole staged region through the unsorted-insert frontier, and the admission now covers the complete Greedy family while every fresh and retained optimal-family profile is explicitly rejected under the supported-subset clause. Existing dictionary-free bytes are unchanged. No public parameterized dictionary API, native/platform schedule, full feature/release matrix, timing or milestone closure is claimed.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(D / 'target'), 'CARGO_BUILD_JOBS': '6', 'CARGO_INCREMENTAL': '0'}


def save():
    (D / 'evidence.json').write_text(json.dumps(e, indent=2) + '\n')


save()
try:
    expected = None
    for label, argv in plan:
        remaining = deadline - time.time() - 30
        if remaining < 30:
            raise TimeoutError('User work window reached before ' + label)
        e['active_command'] = dict(label=label, argv=argv, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
        start = time.monotonic()
        log = D / (label + '.log')
        with log.open('xb') as f:
            proc = subprocess.Popen(argv, cwd=S, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = proc.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                raise TimeoutError('User work window reached during ' + label)
        row = dict(label=label, argv=argv, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
        if code == 0 and label.endswith('-full'):
            result = suite_counts(log.read_text())
            if expected is None:
                expected = result
            assert result == expected, (label, result, expected)
            row.update(result_groups=result[0], passed=result[1], ignored=result[2])
        e['commands'].append(row)
        e.pop('active_command', None)
        save()
        print(label, code, flush=True)
        assert code == 0, label
    for n, h in source.items():
        assert sha(S / n) == h, ('Source changed during the campaign', n)
    e.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), full_suite_counts=dict(result_groups=expected[0], passed=expected[1], ignored=expected[2]))
    save()
except TimeoutError as ex:
    e.update(status='interrupted-at-user-deadline', error=repr(ex))
    save()
    raise
except BaseException as ex:
    e.update(status='failed', error=repr(ex))
    save()
    raise
