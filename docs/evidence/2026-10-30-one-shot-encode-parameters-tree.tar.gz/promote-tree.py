"""Promote the qualified module36 BinaryTreeLazy2 tree-family extension."""
from pathlib import Path
import json, hashlib, subprocess, shutil

D = Path(__file__).parent
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
S = Path('/private/tmp/module36-tree/source')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = Path('/private/tmp/module36-archives/promotion-state.json')
prev = json.loads(state.read_text())
assert prev['stage'] == 'family'
assert prev['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == prev['production_source']
name = '2026-10-30-one-shot-encode-parameters-tree'
p = D / (name + '.json')
r = json.loads(p.read_text())
assert r['status'] == 'passed' and sha(D / r['archive']) == r['archive_sha256']
changed = []
for n in ['src/greedy_state.rs', 'src/reference_search.rs', 'src/reference_frame_encode.rs']:
    assert sha(S / n) == r['source'][n], n
    shutil.copyfile(S / n, R / n)
    changed.append(n)
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == r['production_source']
for q in [p, D / r['archive']]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
    changed.append('docs/evidence/' + q.name)
p = R / 'TODO.md'
s = p.read_text()
task = '- [ ] Extend combined dictionary emission to BinaryTreeLazy2, and extend or explicitly reject it for retained Optimal/Ultra/Ultra2 under the supported-subset clause.'
assert s.count(task) == 1
s = s.replace(task, task.replace('[ ]', '[x]'))
p.write_text(s)
changed.append('TODO.md')
p = R / 'docs/one-shot-encode-parameters-validation.md'
s = p.read_text()
old = '''Module 36 is in progress. Only the internal combined-staging engine, its
DoubleFast extension and the Greedy chain-and-row family extension are
qualified and integrated. Public parameterized dictionary APIs, the remaining
profile families, native/corpus/platform validation, the complete
feature/release regression, measurements and reconciliation remain open.'''
assert s.count(old) == 1
s = s.replace(old, '''Module 36 is in progress. Only the internal combined-staging engine, its
DoubleFast extension, the Greedy chain-and-row family extension and the
BinaryTreeLazy2 tree-family extension with the explicit optimal-family
rejection are qualified and integrated. Public parameterized dictionary APIs,
prepared dictionary entropy reuse, native/corpus/platform validation, the
complete feature/release regression, measurements and reconciliation remain
open.''')
old = '''Evidence: `evidence/2026-10-30-one-shot-encode-parameters-family.json`.'''
assert s.count(old) == 1
s = s.replace(old, old + '''

## Combined staging extension to BinaryTreeLazy2 and explicit optimal rejection

The tree family needs no seeding pass: `GreedyMatchState::
from_parts_with_prefix` keeps its sampling frontier at the combined-buffer
start, so the first tree query back-fills the whole staged region through the
unsorted-insert frontier exactly as the plain path back-fills its bounded gap.
A nonzero prefix now admits the complete Greedy family (chain, row and tree)
beside Fast and DoubleFast. Under the design's supported-subset clause every
optimal-family profile - fresh and retained Optimal, Ultra and Ultra2 - is
explicitly rejected with `UnsupportedFeature` instead of silently dropping the
dictionary.

Thirteen focused commands pass: the complete library suite, true no_std
compilation and strict Clippy under safe, the isolated match-table and
dictionary backends the combined path exercises, and all features, plus
formatting. Every full suite reports {passed} passed
and {ignored} ignored across
{groups} result groups. Two new unit tests cover tree-family dictionary reach,
output shrink against the dictionary-free emission and roundtrip decoding at
level 9, and the explicit rejection of the retained Optimal/Ultra/Ultra2
plans on capped-table requests; the fresh optimal-family rejection test keeps
covering levels 12/14/17.
Evidence: `evidence/{name}.json`.'''.format(passed=r['full_suite_counts']['passed'], ignored=r['full_suite_counts']['ignored'], groups=r['full_suite_counts']['result_groups'], name=name))
p.write_text(s)
changed.append('docs/one-shot-encode-parameters-validation.md')
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *changed], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Extend combined dictionary staging to BinaryTreeLazy2 with explicit optimal-family rejection'], cwd=R, check=True)
prev.update(stage='tree', head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(), production_source={str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')})
state.write_text(json.dumps(prev, indent=2) + '\n')
print('module36 BinaryTreeLazy2 tree-family extension promoted at', prev['head'][:12])
