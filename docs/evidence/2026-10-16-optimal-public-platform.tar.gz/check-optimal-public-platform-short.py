from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path.cwd();O=Path('/tmp/zstdoxide-optimal-public-platform-short-1016');O.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items()if k in ['PATH','HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR']};env.update(RUSTUP_TOOLCHAIN='nightly-2026-10-08',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-public-miri-target',MIRIFLAGS='-Zmiri-strict-provenance')
paths=list((R/'src').rglob('*.rs'))+[R/'tests/reference_optimal_platform.rs',R/'Cargo.toml',R/'Cargo.lock']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source={str(p.relative_to(R)):sha(p)for p in paths};commands=[]
selectors=[(['--lib'],'reference_frame_encode::optimal_tests::short_periodic_three_byte_matches_reach_shared_entropy')]
def save(status,error=None):
 (O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,source_unchanged=all(sha(R/p)==h for p,h in source.items()),interpreted_test_executions=sum(c['exit_code']==0 for c in commands),processes_remaining=0 if status!='running' else 1,commands=commands,qualification='Selected strict-provenance interpreted tests on i686 and s390x, including complete public frames; no native foreign execution claim.'),indent=2)+'\n')
try:
 for target in ['i686-unknown-linux-gnu','s390x-unknown-linux-gnu']:
  env['MIRI_SYSROOT']='/tmp/zstdoxide-platform-sysroot-'+target.split('-')[0]
  for mode,flags in [('safe',[]),('optimal',['--features','unsafe-optimal-frequencies,unsafe-optimal-paths,unsafe-reference-tree,unsafe-optimal-short-key,unsafe-optimal-matches']),('all',['--all-features'])]:
   for i,(selection,test) in enumerate(selectors):
    label=f'{target}-{mode}-{i}';cmd=['cargo','miri','test','--offline','--locked','--target',target,*flags,*selection,'--','--exact',test];print('START',label,flush=True);start=time.monotonic()
    with(O/(label+'.log')).open('wb')as f:p=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
    data=(O/(label+'.log')).read_bytes();commands.append(dict(label=label,argv=cmd,exit_code=p.returncode,seconds=time.monotonic()-start,log=label+'.log',sha256=sha(O/(label+'.log'))));save('running')
    if p.returncode or b'test result: ok. 1 passed; 0 failed;'not in data:raise RuntimeError(label)
    print('END',label,flush=True)
 if not all(sha(R/p)==h for p,h in source.items()):raise ValueError('source changed')
 save('passed')
except BaseException as e:save('failed',repr(e));raise
