from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path.cwd();O=Path('/tmp/zstdoxide-optimal-public-platform-1016');O.mkdir(exist_ok=False)
env={k:v for k,v in os.environ.items()if k in ['PATH','HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR']};env.update(RUSTUP_TOOLCHAIN='nightly-2026-10-08',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-public-miri-target',MIRIFLAGS='-Zmiri-strict-provenance')
paths=list((R/'src').rglob('*.rs'))+[R/'tests/reference_optimal_platform.rs',R/'Cargo.toml',R/'Cargo.lock']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source={str(p.relative_to(R)):sha(p)for p in paths};commands=[]
selectors=[(['--lib'],'optimal_plan::tests::exact_boundaries_have_nine_checked_independent_owner_sizes'),(['--lib'],'optimal_plan::tests::out_of_scope_source_or_resolved_geometry_is_resource_limited'),(['--lib'],'optimal_plan::tests::known_size_resolution_is_used_once_and_defaults_have_precise_bounds'),(['--lib'],'optimal_state::tests::malformed_appends_do_not_publish_literals_sequences_or_repeats'),(['--lib'],'optimal_paths::tests::invalid_indices_and_corrupted_length_fail_before_access_or_mutation'),(['--lib'],'optimal_short_key::tests::shortened_storage_is_checked'),(['--test','reference_optimal_platform'],'complete_three_byte_key_frame_preserves_borrowed_owner_and_wire_bytes'),(['--test','reference_optimal_platform'],'rejected_source_never_clones_or_allocates_on_the_target')]
def save(status,error=None):
 (O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,source_unchanged=all(sha(R/p)==h for p,h in source.items()),interpreted_test_executions=sum(c['exit_code']==0 for c in commands),processes_remaining=0 if status!='running' else 1,commands=commands,qualification='Selected strict-provenance interpreted tests on i686 and s390x, including complete public frames; no native foreign execution claim.'),indent=2)+'\n')
try:
 for target in ['i686-unknown-linux-gnu','s390x-unknown-linux-gnu']:
  env['MIRI_SYSROOT']='/tmp/zstdoxide-platform-sysroot-'+target.split('-')[0]
  for mode,flags in [('safe',[]),('optimal',['--features','unsafe-optimal-frequencies,unsafe-optimal-paths,unsafe-reference-tree,unsafe-optimal-short-key,unsafe-optimal-matches']),('all',['--all-features'])]:
   for i,(selection,test) in enumerate(selectors):
    label=f'{target}-{mode}-{i}';cmd=['cargo','miri','test','--offline','--locked','--target',target,*flags,*selection,'--','--exact',test];print('START',label,flush=True);start=time.monotonic()
    with(O/(label+'.log')).open('wb')as f:p=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
    data=(O/(label+'.log')).read_bytes();commands.append(dict(label=label,argv=cmd,exit_code=p.returncode,seconds=time.monotonic()-start,log=label+'.log',sha256=sha(O/(label+'.log'))));save('running')
    if p.returncode or b'test result: ok. 1 passed; 0 failed;'not in data:raise RuntimeError(label)
    print('END',label,flush=True)
 if not all(sha(R/p)==h for p,h in source.items()):raise ValueError('source changed')
 save('passed')
except BaseException as e:save('failed',repr(e));raise
