//! Compile/codegen-only caller for the pinned allocator API on thumbv6m.
#![no_std]
#![forbid(unsafe_code)]
extern crate alloc;
use alloc::{alloc::Global, rc::Rc, vec::Vec};
use core::alloc::Allocator;
use zstdoxide::{
    CompressionParameterRequest, Dictionary, ReferenceStrategy, Result, SharedDictionary, compress_at_level_in,
    compress_with_parameters_in,
};
#[cfg(target_has_atomic = "ptr")]
compile_error!("This probe requires the no-pointer-atomics target.");
// Existing dictionary fallback is checked separately from the reference APIs.
pub fn shared_is_rc<A: Allocator>(dictionary: SharedDictionary<A>) -> Rc<Dictionary<A>> {
    dictionary
}
// The outer public function concretely specializes both generic codec calls;
// the allocator value is borrowed and need not itself implement Clone.
pub fn borrowed<'a>(input: &[u8], allocator: &'a Global) -> Result<Vec<u8, &'a Global>> {
    let first = compress_at_level_in(input, 11, allocator)?;
    let mut request = CompressionParameterRequest::with_level(11);
    request.set_strategy(Some(ReferenceStrategy::Optimal));
    request.set_window_log(14)?;
    request.set_hash_log(6)?;
    request.set_chain_log(6)?;
    request.set_search_log(1)?;
    request.set_min_match(3)?;
    request.set_target_length(4095)?;
    let second = compress_with_parameters_in(input, &request, allocator)?;
    drop(first);
    Ok(second)
}
