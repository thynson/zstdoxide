from pathlib import Path
import hashlib,json,os,subprocess,time,tomllib
R=Path.cwd();O=Path('/tmp/zstdoxide-optimal-public-thumb-1016');O.mkdir(exist_ok=False);caller=O/'caller';(caller/'src').mkdir(parents=True)
features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'})
(caller/'Cargo.toml').write_text('[package]\nname="optimal-public-thumb"\nversion="0.0.0"\nedition="2024"\n[dependencies]\nzstdoxide={path="'+str(R)+'",default-features=false}\n[features]\n'+''.join(f'{f}=["zstdoxide/{f}"]\n'for f in features)+'[lib]\npath="src/lib.rs"\n')
s=Path('/tmp/zstdoxide-module14-platform/thumb_probe.rs').read_text().replace('input, 4, allocator','input, 11, allocator').replace('with_level(4)','with_level(11)').replace('ReferenceStrategy::Greedy','ReferenceStrategy::Optimal').replace('    let second = compress_with_parameters_in', '''    request.set_window_log(14)?;
    request.set_hash_log(6)?;
    request.set_chain_log(6)?;
    request.set_search_log(1)?;
    request.set_min_match(3)?;
    request.set_target_length(4095)?;
    let second = compress_with_parameters_in''')
(caller/'src/lib.rs').write_text(s)
env={k:v for k,v in os.environ.items()if k in ['PATH','HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR']};env.update(RUSTUP_TOOLCHAIN='nightly-2026-10-08',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-public-thumb-1016-target')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source={str(p.relative_to(R)):sha(p)for p in list((R/'src').rglob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock']};commands=[]
def save(status,error=None):(O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,source_unchanged=all(sha(R/p)==h for p,h in source.items()),commands=commands,qualification='Actual thumbv6m no_std library checks and code generation of a concrete borrowed Global public Optimal caller; no firmware execution.'),indent=2)+'\n')
def run(label,argv,cwd):
 print('START',label,flush=True);start=time.monotonic()
 with(O/(label+'.log')).open('wb')as f:p=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 commands.append(dict(label=label,argv=argv,cwd=str(cwd),exit_code=p.returncode,seconds=time.monotonic()-start,log=label+'.log',sha256=sha(O/(label+'.log'))));save('running')
 if p.returncode:raise RuntimeError(label)
 print('END',label,flush=True)
try:
 modes=[('safe',[]),('frequencies',['--features','unsafe-optimal-frequencies']),('paths',['--features','unsafe-optimal-paths']),('search',['--features','unsafe-reference-tree,unsafe-optimal-short-key,unsafe-optimal-matches']),('all',['--features',','.join(features)])]
 for mode,flags in modes:run('library-'+mode,['cargo','check','--offline','--locked','--lib','--no-default-features','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc',*flags],R)
 for mode,flags in modes:run('caller-'+mode,['cargo','build','--offline','--lib','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc',*flags],caller)
 if not all(sha(R/p)==h for p,h in source.items()):raise ValueError('source changed')
 save('passed')
except BaseException as e:save('failed',repr(e));raise
