from pathlib import Path
import sys,subprocess,json,hashlib,shutil,time,os
sys.dont_write_bytecode=True;sys.path.insert(0,'scripts')
import optimal_fresh_wide_capture_plan as spec
r=Path.cwd();up=Path('/private/tmp/zstdoxide-reference-lazy-1.5.7');out=Path('/tmp/zstdoxide-optimal-fresh-wide-preflight');out.mkdir(exist_ok=False)
for name,data in spec.generated(up).items():(out/name).write_bytes(data)
cc=Path(shutil.which('clang')).resolve();commands=[]
base=[str(cc),'-std=c11','-g','-DDEBUGLEVEL=2','-DZSTD_DISABLE_ASM','-DZSTD_LEGACY_SUPPORT=0','-UZSTD_MULTITHREAD','-DXXH_NAMESPACE=ZSTD_','-I',str(out),'-I',str(up/'lib'),'-I',str(up/'lib/common'),'-I',str(up/'lib/compress')]
env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','TMPDIR','DEVELOPER_DIR','SDKROOT']};env.update(LANG='C',LC_ALL='C',TZ='UTC')
for mode,flags in [('normal',['-O2']),('sanitized',['-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer'])]:
 argv=base+flags+['-Wall','-Wextra','-Werror','-fsyntax-only',str(r/spec.HELPER)];log=out/(mode+'.log');start=time.monotonic()
 with log.open('wb') as f:result=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 commands.append(dict(label=mode,argv=argv,exit_code=result.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
 if result.returncode:raise RuntimeError(mode)
(out/'evidence.json').write_text(json.dumps(dict(status='passed',compiler_sha256=hashlib.sha256(cc.read_bytes()).hexdigest(),helper_sha256=hashlib.sha256((r/spec.HELPER).read_bytes()).hexdigest(),environment=env,commands=commands,qualification='Strict normal/sanitized syntax checks only; no native codec execution.'),indent=2)+'\n')
