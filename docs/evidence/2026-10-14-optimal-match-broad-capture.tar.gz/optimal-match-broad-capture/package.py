from pathlib import Path
import hashlib,io,json,sys,tarfile
R=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize');O=Path('/private/tmp/zstdoxide-optimal-matches-broad-2026-10-14');sys.path.insert(0,str(R/'scripts'));sys.dont_write_bytecode=True
import check_optimal_match_broad_capture as audit
report=audit.audit(O)
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
files={}
for p in O.rglob('*'):
 if p.is_file():
  if p.is_symlink():raise ValueError('symlink')
  files['capture/'+str(p.relative_to(O))]=p.read_bytes()
for mode in ['normal','optimized']:
 b=Path('/tmp/zstdoxide-optimal-match-broad-controls-'+mode+'.log').read_bytes();v=json.loads(b)
 if v['status']!='passed' or len(v['rejections'])!=33 or v['child_attempts']!=0 or v['positive_audits']!=2:raise ValueError('controls')
 files['checks/controls-'+mode+'.json']=b
files['scripts/check_optimal_match_broad_capture_controls.py']=(R/'scripts/check_optimal_match_broad_capture_controls.py').read_bytes()
files['checks/controller.log']=Path('/tmp/zstdoxide-optimal-matches-broad-capture.log').read_bytes();files['package.py']=Path(__file__).read_bytes()
report.update(date='2026-10-14',forged_rejections_per_mode=33,positive_audits_per_mode=2,child_attempts=0,raw_files=len(files),raw_bytes=sum(map(len,files.values())),archive='2026-10-14-optimal-match-broad-capture.tar.gz')
files['report.json']=enc(report);files['file-manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())})
a=R/'docs/evidence'/report['archive']
if a.exists():raise ValueError('fresh archive required')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('optimal-match-broad-capture/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 if {m.name:t.extractfile(m).read() for m in t}!={'optimal-match-broad-capture/'+n:b for n,b in files.items()}:raise ValueError('archive verification')
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(files));(R/'docs/evidence/2026-10-14-optimal-match-broad-capture.json').write_bytes(enc(report))
p=R/'TODO.md';s=p.read_text().replace('- [ ] Capture broader ordinary-geometry/distance/repeat operations before implementing the production sorted search.','- [x] Capture broader ordinary short-key geometry, distance and repeat operations before production sorted search.\n- [ ] Project broader complete maps into canonical sparse fixtures and verify an independent Rust reader.');p.write_text(s)
p=R/'docs/reference-optimal-validation.md';s=p.read_text();s+='''\n## Broader short-key geometry and distance capture\n\nAll 180 commands pass for 37 requests / 82 operations per C build, with two\npadding passes and all 26 used codec units instrumented. Complete maps, both\nfrontiers and candidate intents/lengths match the independent chunked model;\nnormal and instrumented transcripts are byte-identical. The model first matched\n333 scalar predecessor comparisons and rejected 14 synthetic forgeries per mode.\nEach C build rejects 22 malformed packets before output. Normal and optimized\nPython each reject 33 capture forgeries, accept two positives and spawn no child.\n\nThe requests distinguish distances 262143/262144/262145 under windows18/19,\nordinary short-key logs min(window,17), strict repeat thresholds and fresh1/4/8\nrepeat values at pointer-safe positions. Source/query maxima are524288/16;\nprimary/node logs remain bounded to12. Ordinary parser startup and larger\nproduction primary/node geometry remain separate gates.\n\n`evidence/2026-10-14-optimal-match-broad-capture.json` preserves every raw command,\nsource, request, object and executable, including149,995,548log bytes. No Rust\nsorted-search or public Optimal admission is implied by this observation gate.\n''';p.write_text(s)
print(a.name,a.stat().st_size,len(files),report['archive_sha256'],report['raw_bytes'])
