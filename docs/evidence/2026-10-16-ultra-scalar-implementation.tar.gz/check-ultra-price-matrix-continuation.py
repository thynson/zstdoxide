from pathlib import Path
import hashlib,json,os,subprocess,time,tomllib
R=Path.cwd();out=Path('/tmp/zstdoxide-ultra-price-matrix-continuation-1016');out.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def source():return {str(p.relative_to(R)):sha(p)for folder in ['src','tests','examples','test-support']for p in sorted((R/folder).rglob('*.rs'))}|{n:sha(R/n)for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','test-support/allocator/Cargo.toml']}
features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'});configs=[('safe',[]),*[(f,['--features',f])for f in features],('all',['--all-features'])];commands=[]
for label,flags in configs:
 commands += [(label+'-scalars',['cargo','test',*flags,'--test','reference_ultra_prices','--test','reference_optimal_prices','--test','reference_ultra_scalar_fixture','--test','reference_optimal']), (label+'-optimal',['cargo','test',*flags,'--lib','optimal_'])]
 nostd=[]if label=='safe'else['--features',','.join(features)if label=='all'else label]
 commands.append((label+'-nostd',['cargo','check','--no-default-features',*nostd]))
commands += [('release-all',['cargo','test','--release','--all-features','--test','reference_ultra_prices','--test','reference_optimal_prices','--test','reference_optimal','--test','reference_ultra_scalar_fixture']),('clippy-safe',['cargo','clippy','--all-targets','--','-D','warnings']),('clippy-all',['cargo','clippy','--all-targets','--all-features','--','-D','warnings']),('fmt',['cargo','fmt','--all','--check'])]
prior_path=Path('/tmp/zstdoxide-ultra-price-matrix-1016/evidence.json');prior=json.loads(prior_path.read_text())
if prior['status']!='failed' or prior['source']!=source():raise ValueError('same source failed predecessor required')
passed={r['label']for r in prior['commands']if r['exit_code']==0};commands=[r for r in commands if r[0]not in passed]
e=dict(status='running',features=features,source=source(),prior_evidence_sha256=sha(prior_path),skipped_completed_labels=sorted(passed),commands=[],environment_override={'CARGO_INCREMENTAL':'0'},qualification='Continue only unfinished commands after preserved disk-full compile failure; disable incremental cache to bound disk use. Same Rust/Cargo inputs and test commands.')
env=os.environ|{'CARGO_TARGET_DIR':'/tmp/zstdoxide-ultra-scalars-target','CARGO_INCREMENTAL':'0'}
def save():(out/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for label,argv in commands:
  print('START',label,flush=True);log=out/(label+'.log');start=time.monotonic()
  with log.open('w')as f:r=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
  e['commands'].append(dict(label=label,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=log.name,sha256=sha(log)));save()
  if r.returncode:raise ValueError('command failed '+label)
  print('END',label,flush=True)
 if source()!=e['source']:raise ValueError('tested source changed')
 e.update(status='passed',source_unchanged=True);save()
except BaseException as error:
 e.update(status='failed',error=repr(error));save();raise
