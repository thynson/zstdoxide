#![no_std]
#![forbid(unsafe_code)]
#[allow(dead_code)]
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/constants.rs"] mod constants;
#[allow(dead_code)]
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_price.rs"] mod price;
pub fn ultra_scalar_probe(stat: u32, frequency: u32, offset: u32, length: u32, literals: &[u8], counts: &[u32;256]) -> Option<(u32,u32,u32)> {
 let policy=price::PricePolicy::Ultra;
 let base=policy.weight(stat).ok()?;
 let symbol=price::SymbolPrice::new_with_policy(policy,base,frequency).ok()?;
 let ll=price::literal_length_price_with_policy(policy,length,Some(symbol)).ok()?;
 let matched=price::match_price_with_policy(policy,offset,length,Some((symbol,symbol))).ok()?;
 let raw=price::dynamic_literals_cost_with_policy(policy,literals,base,counts).ok()?;
 Some((ll,matched,raw))
}
