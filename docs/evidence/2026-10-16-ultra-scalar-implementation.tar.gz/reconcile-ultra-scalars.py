from pathlib import Path
import json,hashlib,re,tomllib
R=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=Path('/tmp/zstdoxide-ultra-price-matrix-1016');b=Path('/tmp/zstdoxide-ultra-price-matrix-continuation-1016');x=json.loads((a/'evidence.json').read_text());y=json.loads((b/'evidence.json').read_text())
if x['status']!='failed' or y['status']!='passed' or x['source']!=y['source'] or y['prior_evidence_sha256']!=sha(a/'evidence.json'):raise ValueError('chain')
for p,h in y['source'].items():
 if sha(R/p)!=h:raise ValueError(p)
records=[];failed=[]
for root,doc in [(a,x),(b,y)]:
 for r in doc['commands']:
  log=root/r['log']
  if sha(log)!=r['sha256']:raise ValueError(log)
  (records if r['exit_code']==0 else failed).append(dict(r,root=str(root)))
labels=[r['label']for r in records];features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'})
expected=[m+'-'+s for m in ['safe',*features,'all']for s in ['scalars','optimal','nostd']]+['release-all','clippy-safe','clippy-all','fmt']
if labels!=expected or len(failed)!=1 or 'No space left on device'not in (a/failed[0]['log']).read_text():raise ValueError('inventory/failure')
tests=0
for r in records:
 log=(Path(r['root'])/r['log']).read_text();counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
 n=sum(int(t[0])for t in counts)
 target=86 if r['label'].endswith('-optimal')else 15 if r['label'].endswith('-scalars')or r['label']=='release-all'else 0
 if n!=target or any(t[1:]!=('0','0')for t in counts):raise ValueError(r['label'])
 tests+=n
for p in ['ultra-scalar-platform','ultra-scalar-thumb']:
 root=Path('/tmp/zstdoxide-'+p+'-1016');doc=json.loads((root/'evidence.json').read_text())
 if doc['status']!='passed' or not doc['source_unchanged']:raise ValueError(p)
 for path,h in doc['source'].items():
  if sha(R/path)!=h:raise ValueError(path)
 for r in doc['commands']:
  if r['exit_code'] or sha(root/r['log'])!=r['sha256']:raise ValueError(r)
out=dict(status='passed',features=features,successful_commands=len(records),passing_test_executions=tests,source_unchanged=True,failed_attempts=failed,commands=records,qualification='Exact planned matrix completed across preserved predecessor and continuation; the single disk-full compiler failure is retained and not counted as a test result. Selected foreign Miri and thumb codegen have separate complete logs.')
Path('/tmp/ultra-scalar-reconciliation.json').write_text(json.dumps(out,indent=2)+'\n');print(len(records),tests)
