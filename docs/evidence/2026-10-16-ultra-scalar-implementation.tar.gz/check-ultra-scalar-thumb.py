from pathlib import Path
import hashlib,json,os,subprocess,time,tomllib
R=Path.cwd();O=Path('/tmp/zstdoxide-ultra-scalar-thumb-1016');(O/'probe/src').mkdir(parents=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={str(p.relative_to(R)):sha(p)for p in list((R/'src').rglob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock']}
(O/'probe/Cargo.toml').write_text('[package]\nname="ultra-scalar-no-atomics"\nversion="0.0.0"\nedition="2024"\n[lib]\npath="src/lib.rs"\n')
(O/'probe/src/lib.rs').write_text('''#![no_std]
#![forbid(unsafe_code)]
#[allow(dead_code)]
#[path="'''+str(R/'src/constants.rs')+'''"] mod constants;
#[allow(dead_code)]
#[path="'''+str(R/'src/optimal_price.rs')+'''"] mod price;
pub fn ultra_scalar_probe(stat: u32, frequency: u32, offset: u32, length: u32, literals: &[u8], counts: &[u32;256]) -> Option<(u32,u32,u32)> {
 let policy=price::PricePolicy::Ultra;
 let base=policy.weight(stat).ok()?;
 let symbol=price::SymbolPrice::new_with_policy(policy,base,frequency).ok()?;
 let ll=price::literal_length_price_with_policy(policy,length,Some(symbol)).ok()?;
 let matched=price::match_price_with_policy(policy,offset,length,Some((symbol,symbol))).ok()?;
 let raw=price::dynamic_literals_cost_with_policy(policy,literals,base,counts).ok()?;
 Some((ll,matched,raw))
}
''')
env={k:v for k,v in os.environ.items()if k in ['PATH','HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR']};env.update(RUSTUP_TOOLCHAIN='nightly-2026-10-08',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-ultra-scalar-thumb-target')
features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'});commands=[]
for label,argv,cwd in [('library-safe',['cargo','check','--offline','--locked','--lib','--no-default-features','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc'],R),('library-all',['cargo','check','--offline','--locked','--lib','--no-default-features','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc','--features',','.join(features)],R),('scalar-codegen',['cargo','build','--offline','--lib','--target','thumbv6m-none-eabi','-Zbuild-std=core'],O/'probe')]:
 print('START',label,flush=True);begin=time.monotonic();p=O/(label+'.log')
 with p.open('w')as f:r=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 commands.append(dict(label=label,argv=argv,cwd=str(cwd),exit_code=r.returncode,seconds=time.monotonic()-begin,log=p.name,sha256=sha(p)))
 if r.returncode:raise ValueError(label)
 print('END',label,flush=True)
if any(sha(R/p)!=h for p,h in source.items()):raise ValueError('changed source')
(O/'evidence.json').write_text(json.dumps(dict(status='passed',source_unchanged=True,source=source,commands=commands,qualification='Safe/all no_std thumbv6m library checks and concrete private Ultra scalar caller code generation; no firmware execution or Ultra frame admission.'),indent=2)+'\n')
