//! Deterministic utility timings; setup and assertions remain outside clocks.
use std::{hint::black_box, time::Instant};
use zstdoxide::{Error, compression_bound, write_skippable_frame};
fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |h,&b| (h^u64::from(b)).wrapping_mul(0x100000001b3))
}
struct Case { name: &'static str, source_size: usize, payload_len: usize, capacity: usize, variant: u8 }
fn cases() -> [Case;11] {
    let maximum=(usize::MAX/257)*256;
    [
        Case{name:"empty",source_size:0,payload_len:0,capacity:8,variant:0},
        Case{name:"one",source_size:1,payload_len:1,capacity:9,variant:1},
        Case{name:"margin-before",source_size:2047,payload_len:2047,capacity:2055,variant:2},
        Case{name:"margin-boundary",source_size:2048,payload_len:2048,capacity:2073,variant:7},
        Case{name:"block-before",source_size:131071,payload_len:131071,capacity:131079,variant:15},
        Case{name:"block-boundary",source_size:131072,payload_len:131072,capacity:131080,variant:0},
        Case{name:"block-after",source_size:131073,payload_len:131073,capacity:131098,variant:15},
        Case{name:"maximum-valid",source_size:maximum-1,payload_len:7,capacity:15,variant:1},
        Case{name:"maximum-rejected",source_size:maximum,payload_len:8,capacity:16,variant:2},
        Case{name:"invalid-variant",source_size:33,payload_len:33,capacity:41,variant:16},
        Case{name:"short-destination",source_size:257,payload_len:257,capacity:264,variant:15},
    ]
}
fn main() {
    let command=std::env::args().nth(1).expect("qualify or measure");assert!(command=="qualify"||command=="measure");
    for c in cases() {
        let payload:Vec<_>=(0..c.payload_len).map(|i|(i*37+11) as u8).collect();
        let mut output=vec![0xa5;c.capacity+32];
        let bound=compression_bound(c.source_size);
        let written=write_skippable_frame(&mut output[16..16+c.capacity],&payload,c.variant);
        let expected_result=if c.variant>15{Err(Error::InvalidParameter)}else if c.capacity<c.payload_len+8{Err(Error::ResourceLimit)}else{Ok(c.payload_len+8)};
        assert_eq!(written,expected_result);
        assert!(output[..16].iter().chain(&output[16+c.capacity..]).all(|&b|b==0xa5));
        if let Ok(n)=written {assert_eq!(&output[24..16+n],payload);assert!(output[16+n..].iter().all(|&b|b==0xa5));}
        else{assert!(output.iter().all(|&b|b==0xa5));}
        let expected=output.clone();let hash=fingerprint(&payload);let name=c.name;
        if command=="qualify" {
            println!("{name}\t{}\t{}\t{}\t{}\t{hash:016x}\t{bound:?}\t{written:?}\t{:016x}\tcore-only-utility-component",c.source_size,c.payload_len,c.capacity,c.variant,fingerprint(&output));continue;
        }
        let iterations=(1024*1024/c.payload_len.max(1)).clamp(8,1024);
        for mode in ["compression-bound","write-skippable"] {
            for sample in 0..5 {
                let mut elapsed=0;
                for _ in 0..iterations {
                    let start=Instant::now();
                    match mode {
                        "compression-bound"=>{black_box(compression_bound(black_box(c.source_size))).ok();}
                        "write-skippable"=>{black_box(write_skippable_frame(black_box(&mut output[16..16+c.capacity]),black_box(&payload),black_box(c.variant))).ok();}
                        _=>unreachable!(),
                    }
                    elapsed+=start.elapsed().as_nanos();
                }
                assert_eq!(compression_bound(c.source_size),bound);assert_eq!(output,expected);assert_eq!(fingerprint(&payload),hash);
                println!("{name}\t{mode}\t{sample}\t{iterations}\t{elapsed}");
            }
        }
    }
}
