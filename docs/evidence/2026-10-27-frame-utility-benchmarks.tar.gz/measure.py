from pathlib import Path
import json,hashlib,subprocess,time,datetime,argparse,os,signal
D=Path(__file__).parent;S=Path('/private/tmp/module31-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def validate():
 b=json.loads((D/'evidence.json').read_text());assert b['status']=='qualified-not-timed' and len(b['builds'])==23
 for n,h in b['source'].items():assert sha(D/'source'/n)==h,('benchmark snapshot',n)
 for n,h in b['production_source'].items():assert sha(S/n)==h,('production',n)
 for row in b['builds']:
  assert sha(D/row['executable'])==row['sha256'];assert (D/(row['name']+'-qualify.tsv')).read_bytes()==(D/'safe-qualify.tsv').read_bytes();assert sha(D/(row['name']+'-qualify.tsv'))==row['qualification_sha256']
 gates={}
 for label,path,count in [('matrix','module31-matrix/evidence.json',72),('public','module31-public/evidence.json',16),('platform','module31-platform/evidence.json',13),('native','module31-native/replay.json',3),('history','module31-native-history/replay.json',3)]:
  p=Path('/private/tmp')/path;j=json.loads(p.read_text());assert j['status']=='passed' and len(j['commands'])==count and all(c['exit_code']==0 for c in j['commands']),label
  for n,h in b['production_source'].items():assert j.get('production_source',j.get('source',{}))[n]==h,(label,n)
  gates[label]=sha(p)
 for label,path in [('native','module31-native/native.json'),('native-history','module31-native-history/capture.json')]:
  p=Path('/private/tmp')/path;assert json.loads(p.read_text())['status']=='passed';gates[label]=sha(p)
 p=D/'harness-check.json';j=json.loads(p.read_text());assert j['status']=='passed' and j['source_sha256']==sha(D/'source/benches/frame_utilities.rs');gates['harness']=sha(p)
 p=D/'cpu-barrier.json';assert json.loads(p.read_text())['status']=='passed';gates['cpu-barrier']=sha(p)
 return b,gates

def measure(repeat=False):
 b,gates=validate();folder=D/'repeat' if repeat else D;build=json.loads((folder/'evidence.json').read_text())
 if repeat:
  assert build['status']=='qualified-not-timed' and len(build['builds'])==2
  assert build['source_evidence_sha256']==sha(D/'evidence.json');assert json.loads((D/'timed.json').read_text())['status']=='passed'
  assert json.loads((folder/'cpu-barrier.json').read_text())['status']=='passed'
 assert not (folder/'timed.json').exists()
 e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),gates=gates,build_evidence_sha256=sha(folder/'evidence.json'),runs=[],qualification='Fixed-order batch clocks over128..1024 operations for every mode, including identical loop/dispatch/black-box overhead. Utility calls include checked arithmetic or all validation and payload copying. Input construction, assertions, hashes and result formatting occur outside timed calls. The separately qualified core-only utility component has no allocation dependency; the 11 qualification rows are deterministic result identities, not runtime allocation counters. No universal unsafe benefit or desktop idleness is claimed.')
 if repeat:e.update(primary_timing_sha256=sha(D/'timed.json'),repeat_barrier_sha256=sha(folder/'cpu-barrier.json'))
 def save():(folder/'timed.json').write_text(json.dumps(e,indent=2)+'\n')
 save();deadline=datetime.datetime(2026,10,27,8,32,32,tzinfo=datetime.timezone.utc).timestamp()
 try:
  cases={l.split('\t')[0] for l in (D/'safe-qualify.tsv').read_text().splitlines()};modes=['compression-bound','write-skippable'];expected={(c,m,i) for c in cases for m in modes for i in range(5)}
  for row in build['builds']:
   assert sha(folder/row['executable'])==row['sha256'];assert (folder/(row['name']+'-qualify.tsv')).read_bytes()==(D/'safe-qualify.tsv').read_bytes()
   remaining=deadline-time.time()-30
   if remaining<30:raise TimeoutError('User deadline before '+row['name'])
   start=time.monotonic();p=subprocess.Popen([str(folder/row['executable']),'measure'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
   try:out,err=p.communicate(timeout=remaining)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM);out,err=p.communicate();raise TimeoutError('User deadline during '+row['name'])
   name=row['name'];(folder/(name+'-timed.tsv')).write_bytes(out);(folder/(name+'-timed.stderr')).write_bytes(err);assert p.returncode==0,(name,err)
   lines=out.decode().splitlines();assert len(lines)==110;seen=set()
   for line in lines:
    case,mode,sample,iterations,elapsed=line.split('\t');sample=int(sample);iterations=int(iterations);elapsed=int(elapsed);assert 0<=sample<5 and 128<=iterations<=1024 and elapsed>0;key=(case,mode,sample);assert key not in seen;seen.add(key)
   assert seen==expected
   e['runs'].append(dict(name=name,rows=len(lines),seconds=time.monotonic()-start,sha256=sha(folder/(name+'-timed.tsv')),executable_sha256=row['sha256']));save();print(('repeat ' if repeat else '')+name,'110 samples',flush=True)
  validate();e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--repeat',action='store_true');p.add_argument('--validate-only',action='store_true');a=p.parse_args()
 if a.validate_only:validate();print('All source, executable, qualification and completed qualification gates verified')
 else:measure(a.repeat)
