use zstdoxide::{compress, compress_with_dictionary, Dictionary};
#[test]
fn capture_previous_whole_compression_bytes() {
 let raw=Dictionary::raw(b"abcaBc0123456789 -- repeated dictionary content -- abcaBc0123456789").unwrap().into_shared();
 let prepared=Dictionary::from_bytes(include_bytes!("upstream/dictionaries/formatted.dict")).unwrap().into_shared();
 let mut digest=0xcbf29ce484222325u64;let mut cases=0;
 for length in [0usize,1,7,255,256,257,65_791,65_792,65_793,131_071,131_072,131_073] {
  let source: Vec<u8>=(0..length).map(|i|b"abcaBc0123456789 -- repeated dictionary content --"[i%48]).collect();
  for dictionary in [None,Some(&raw),Some(&prepared)] {
   let frame=match dictionary {None=>compress(&source).unwrap(),Some(d)=>compress_with_dictionary(&source,d).unwrap()};
   for byte in (frame.len() as u64).to_le_bytes().iter().chain(&frame) {digest=(digest^u64::from(*byte)).wrapping_mul(0x100000001b3);}
   cases+=1;
  }
 }
 println!("cases={cases} fnv64={digest}");
}
