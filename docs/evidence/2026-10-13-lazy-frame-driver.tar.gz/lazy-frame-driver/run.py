import subprocess,json,time
from pathlib import Path
root=Path('/Users/lanxingcan/Workspace/zstdoxize')
out=Path('/tmp/zstdoxide-lazy-frame-driver')
commands=[['sh','-n','scripts/check.sh'],['python3','scripts/check_lazy_frame_recipes.py','--check','--controls'],['python3','scripts/check_lazy_frame_validator.py','--check'],['python3','scripts/capture_lazy_frames.py','--check-plan'],['python3','scripts/check_lazy_frames.py','--check'],['python3','scripts/pack_lazy_frame_trajectories.py','--check'],['git','diff','--check']]
results=[]
for i,cmd in enumerate(commands):
 start=time.time()
 with (out/f'{i:02}.log').open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(command=cmd,returncode=r.returncode,seconds=time.time()-start,log=f'{i:02}.log'))
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(i,r.returncode,cmd,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
