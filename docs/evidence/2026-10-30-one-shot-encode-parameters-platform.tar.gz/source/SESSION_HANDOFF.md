# Session handoff

Updated: 2026-10-30T03:25:00+00:00 (window closed at 11:52 local / 03:52Z; the
last qualified promotion landed at 11:21 local and the remaining time was spent
on window closure — no unqualified WIP remains in the tree or history)
Workspace: `/Users/lanxingcan/Workspace/zstdoxize`
Current HEAD: `ae54b4f` — a clean, qualified, promoted state. No reset needed on
resume; the working tree is clean except this untracked handoff file.
Promotion state: stage `tree` at `/private/tmp/module36-archives/promotion-state.json`.

## Standing user directives (recorded 2026-10-29)

- Validation-flow optimization, effective for future work items: run the
  relevant Miri verification only when a work item adds or modifies unsafe
  code. Items that touch only safe Rust skip Miri and keep their remaining
  qualification gates (focused unit/public checks, native/corpus where
  applicable, the full feature/release matrix, benchmarks). Concrete
  no-atomics ARM code-generation checks are outside this directive's stated
  scope unless the user extends it. Requested by the user during the
  2026-10-29 module35 completion window; apply from module36 onward. The
  module36 engine, DoubleFast, family and tree stages added no unsafe code,
  so no Miri ran.
- Preserve this directives section verbatim in every future handoff update.
- Boundary discipline recorded 2026-10-29 evening: advance until the stated
  local-time boundary, start no new tasks after it, and leave unqualified
  work only as clearly-labelled WIP commits that the next session resets.

## Window (authorized 2026-10-30, 2 hours from 09:52 local): three promotions

1. Reset the WIP commit `5ba1ae2` per the previous handoff; the DoubleFast
   extension was preserved verbatim in `/private/tmp/module36-engine/source`
   (verified 100/100 production digests before discarding the working-tree
   copy). Took option (a): the bundled TODO item was split into a completed
   DoubleFast half and the remaining Greedy-family half, and the retained
   PASSED campaign (1118/25) was archived and promoted as
   `57feb38` with receipt
   `docs/evidence/2026-10-30-one-shot-encode-parameters-double-fast.json`.
   Scripts: `/private/tmp/module36-double-fast/{archive,promote}-double-fast.py`.
2. Implemented and promoted the Greedy/Lazy/Lazy2 chain-and-row family item
   as `01900c7`: `GreedyTables::seed_prefix` seeds the chain (one insert per
   staged position, mirroring upstream dictionary loading) and the row owner
   (under `FRESH_ROW_SALT` so seeded tags match parser lookups);
   `GreedyMatchState::from_parts_with_prefix` binds prefix-relative geometry
   with the sampling frontier at the prefix boundary (upstream
   `nextToUpdate = iend`); `GreedyKeyLayout::key_bytes` became production
   (was test-only). New campaign `/private/tmp/module36-family` PASSED all 13
   commands (1120/25). Receipt:
   `docs/evidence/2026-10-30-one-shot-encode-parameters-family.json`.
3. Implemented and promoted the BinaryTreeLazy2 + explicit optimal-family
   rejection item as `ae54b4f`: the tree family needs no seeding pass — its
   first query back-fills the whole staged region through the
   unsorted-insert frontier, so `seed_prefix` returns frontier 0 for trees;
   admission now covers the complete Greedy family, and every fresh and
   retained Optimal/Ultra/Ultra2 profile is explicitly rejected under the
   design's supported-subset clause (retained plans need capped-table
   requests: level 11 + explicit strategy + window 16/hash 12/chain 12/
   search 6/min 3/target 1, source > 16384). New campaign
   `/private/tmp/module36-tree` PASSED all 13 commands (1122/25). Receipt:
   `docs/evidence/2026-10-30-one-shot-encode-parameters-tree.json`.
4. Level→strategy map for dictionary-tier inputs differs from plain presets;
   at source ~1.5KB with dict ~1KB: 4=Greedy, 5=Lazy, 6=Lazy2, 9=Btlazy2,
   11/12=Optimal; probe empirically before writing admission tests. Tree and
   optimal plans reject preset logs at retained sizes (hash/chain ≤ 12).

## Module 36 state and next steps

Completed items: analysis, plan resolution + staging + dict-ID headers, Fast,
DoubleFast, Greedy chain/row family, BinaryTreeLazy2 + explicit optimal-family
rejection. Combined dictionary staging now admits Fast, DoubleFast and the
complete Greedy family; all optimal-family profiles reject explicitly.

Next items in TODO order (none started):
1. Reuse prepared dictionary entropy for emitted blocks where the existing
   dictionary contract applies (formatted-dictionary HUF/FSE tables feeding
   block entropy decisions; intersects `src/dictionary.rs`, `entropy_output`,
   `reference_frame_encode`).
2. Public parameterized-dictionary API with exact output/lifetime guards and
   independent allocator-failure qualification.
3. Native/corpus qualification schedules, ARM codegen (Miri only if unsafe
   code changes, per the standing directive), full feature/release matrix,
   benchmarks, and the closure/reconciliation item.

## Reference and final records

Pinned upstream f8745da6ff1ad1e7bab384bd1f9d742439278e99 (v1.5.7), external
checkout /private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99.
Rust nightly-2026-10-08 (1.101). Reference code remains external and serves
only as test oracle. 867 commits at `ae54b4f`. Session controllers, journals,
campaigns and receipts are under /private/tmp as listed above; the promotion
state chain lives in /private/tmp/module36-archives/promotion-state.json
(stages: design → engine → double-fast → family → tree).
