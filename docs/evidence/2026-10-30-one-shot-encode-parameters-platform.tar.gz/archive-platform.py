"""Archive the qualified module36 concrete ARM platform campaign."""
from pathlib import Path
import json, hashlib, tarfile, datetime

D = Path(__file__).parent
C = Path('/private/tmp/module36-platform')
S = C / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
j = json.loads((C / 'evidence.json').read_text())
assert j['status'] == 'passed' and len(j['commands']) == 9
for n, h in j['source'].items():
    assert sha(S / n) == h, n
for r in j['commands']:
    assert r['exit_code'] == 0 and sha(C / (r['label'] + '.log')) == r['log_sha256']
files = {}
for p in C.rglob('*'):
    if not p.is_file():
        continue
    n = p.relative_to(C)
    if any(x in {'target', 'target-safe', 'target-all', '__pycache__'} for x in n.parts):
        continue
    if p.suffix in {'.rs', '.toml', '.lock', '.json', '.py', '.log', '.md', '.tsv', '.ll', '.o'}:
        files[str(n)] = p
files['archive-platform.py'] = Path(__file__)
name = '2026-10-30-one-shot-encode-parameters-platform'
archive = D / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
r = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source=j['source'], production_source=j['production_source'], commands=j['commands'], artifacts=j['artifacts'], members={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()}, archive=archive.name, archive_sha256=sha(archive), qualification='Focused module36 platform item only: parameterized dictionary allocating, caller-owned and coordinator paths run on the host under safe and all features, and safe/all library builds emit concrete thumbv6m-none-eabi LLVM IR and objects without atomics. No foreign Miri runs because no unsafe code was added or modified. No complete foreign-platform schedule, matrix, timing or milestone closure is claimed.')
(D / (name + '.json')).write_text(json.dumps(r, indent=2) + '\n')
print(name, archive.stat().st_size)
