"""Promote the qualified module36 concrete ARM platform item."""
from pathlib import Path
import json, hashlib, subprocess, shutil

D = Path(__file__).parent
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
S = Path('/private/tmp/module36-platform/source')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = Path('/private/tmp/module36-archives/promotion-state.json')
prev = json.loads(state.read_text())
assert prev['stage'] == 'native'
assert prev['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == prev['production_source']
name = '2026-10-30-one-shot-encode-parameters-platform'
p = D / (name + '.json')
r = json.loads(p.read_text())
assert r['status'] == 'passed' and sha(D / r['archive']) == r['archive_sha256']
changed = []
for n in ['tests/one_shot_encode_parameters_platform.rs']:
    assert sha(S / n) == r['source'][n], n
    shutil.copyfile(S / n, R / n)
    changed.append(n)
for q in [p, D / r['archive']]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
    changed.append('docs/evidence/' + q.name)
p = R / 'TODO.md'
s = p.read_text()
task = '- [ ] Qualify combined parameter and dictionary application under concrete no-atomics ARM code generation, running foreign Miri only if unsafe code is added or modified.'
assert s.count(task) == 1
s = s.replace(task, task.replace('[ ]', '[x]'))
p.write_text(s)
changed.append('TODO.md')
p = R / 'docs/one-shot-encode-parameters-validation.md'
s = p.read_text()
old = '''Corpus/platform validation, the complete feature/release regression,
measurements and reconciliation remain open.'''
assert s.count(old) == 1
s = s.replace(old, '''Corpus validation, the complete feature/release regression, measurements and
reconciliation remain open.''')
old = '''Evidence: `evidence/2026-10-30-one-shot-encode-parameters-native.json`.'''
assert s.count(old) == 1
s = s.replace(old, old + '''

## Concrete no-atomics ARM emission

The parameterized dictionary allocating, caller-owned and coordinator paths run
on the host under safe and all features with exact guards and prefix
consumption. Concrete `thumbv6m-none-eabi` library checks and release LLVM IR /
object emission pass for both safe and every opt-in storage backend together;
the retained artifacts include the emitted modules. Foreign Miri was not run
because this module added and modified no unsafe code, per the standing
direction. Native byte identity and complete foreign-platform behavior are not
claimed.

Nine focused commands pass: two host test suites, two strict Clippy checks,
two concrete atomic-free checks, two IR/object emissions and formatting.
Evidence: `evidence/{name}.json`.'''.format(name=name))
p.write_text(s)
changed.append('docs/one-shot-encode-parameters-validation.md')
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *changed], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Qualify parameterized dictionary calls on concrete atomic-free ARM'], cwd=R, check=True)
prev.update(stage='platform', head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(), production_source={str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')})
state.write_text(json.dumps(prev, indent=2) + '\n')
print('module36 ARM platform item promoted at', prev['head'][:12])
