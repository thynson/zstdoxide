"""Module36 concrete no-atomics ARM and hardened platform checks.

Runs the parameterized dictionary platform paths on the host and emits LLVM IR
and objects for the safe and all-feature library on thumbv6m-none-eabi. No
foreign Miri runs because this item adds no unsafe code. This is focused
platform evidence, not a full foreign-platform schedule.
"""
from pathlib import Path
import os, subprocess, json, hashlib, time, datetime, re, signal, shutil

D = Path(__file__).parent
S = D / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
deadline = datetime.datetime.fromisoformat('2026-10-30T07:10:00+00:00').timestamp()
assert deadline - time.time() >= 60
ALL = 'unsafe-bitstream,unsafe-byte-cursor,unsafe-dictionary,unsafe-frame-sink,unsafe-fse,unsafe-fse-encoder,unsafe-history,unsafe-huffman,unsafe-huffman-codebook,unsafe-in-place-buffer,unsafe-match-chain,unsafe-match-table,unsafe-optimal-frequencies,unsafe-optimal-matches,unsafe-optimal-paths,unsafe-optimal-short-key,unsafe-reference-chain,unsafe-reference-tree,unsafe-ring-history,unsafe-row-table,unsafe-slice-history,unsafe-training'
plan = [
    ('safe-host', ['cargo', 'test', '--offline', '--locked', '--test', 'one_shot_encode_parameters_platform']),
    ('all-host', ['cargo', 'test', '--offline', '--locked', '--test', 'one_shot_encode_parameters_platform', '--all-features']),
    ('safe-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--test', 'one_shot_encode_parameters_platform', '--', '-D', 'warnings']),
    ('all-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--test', 'one_shot_encode_parameters_platform', '--all-features', '--', '-D', 'warnings']),
    ('thumb-safe-check', ['cargo', 'check', '--offline', '--locked', '-Zbuild-std=core,alloc', '--target', 'thumbv6m-none-eabi', '--no-default-features', '--lib']),
    ('thumb-all-check', ['cargo', 'check', '--offline', '--locked', '-Zbuild-std=core,alloc', '--target', 'thumbv6m-none-eabi', '--no-default-features', '--lib', '--features', ALL]),
    ('thumb-safe-objects', ['cargo', 'rustc', '--release', '--offline', '--locked', '-Zbuild-std=core,alloc', '--target', 'thumbv6m-none-eabi', '--target-dir', str(D / 'target-safe'), '--no-default-features', '--lib', '--', '--emit=llvm-ir,obj']),
    ('thumb-all-objects', ['cargo', 'rustc', '--release', '--offline', '--locked', '-Zbuild-std=core,alloc', '--target', 'thumbv6m-none-eabi', '--target-dir', str(D / 'target-all'), '--no-default-features', '--lib', '--features', ALL, '--', '--emit=llvm-ir,obj']),
    ('format', ['cargo', 'fmt', '--all', '--', '--check']),
]
source = {}
for folder in ['src', 'tests', 'test-support']:
    for p in (S / folder).rglob('*'):
        if p.is_file():
            source[str(p.relative_to(S))] = sha(p)
for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']:
    source[n] = sha(S / n)
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), deadline_utc='2026-10-30T07:10:00+00:00', source=source, production_source={n: h for n, h in source.items() if n.startswith('src/')}, plan=plan, commands=[], qualification='Focused module36 platform item only: parameterized dictionary allocating, caller-owned and coordinator paths run on the host under safe and all features, and safe/all library builds emit concrete thumbv6m-none-eabi LLVM IR and objects without atomics. No foreign Miri runs because no unsafe code was added or modified. No complete foreign-platform, matrix, timing or milestone closure is claimed.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(D / 'target'), 'CARGO_BUILD_JOBS': '6', 'CARGO_INCREMENTAL': '0'}
artifacts = D / 'artifacts'
artifacts.mkdir(exist_ok=True)


def save():
    (D / 'evidence.json').write_text(json.dumps(e, indent=2) + '\n')


save()
try:
    for label, argv in plan:
        remaining = deadline - time.time() - 15
        if remaining < 15:
            raise TimeoutError('deadline before ' + label)
        e['active_command'] = dict(label=label, argv=argv, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
        start = time.monotonic()
        log = D / (label + '.log')
        with log.open('xb') as f:
            proc = subprocess.Popen(argv, cwd=S, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = proc.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                raise TimeoutError('deadline during ' + label)
        row = dict(label=label, argv=argv, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
        if code == 0 and label.endswith('-host'):
            rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text())
            assert rows == [('2', '0', '0')], (label, rows)
            row.update(passed=2, failed=0, ignored=0)
        e['commands'].append(row)
        e.pop('active_command', None)
        save()
        print(label, code, flush=True)
        assert code == 0, (label, log.read_text()[-3000:])
    e['artifacts'] = {}
    for label, want in [('safe', 'target-safe'), ('all', 'target-all')]:
        out = D / want
        files = {}
        for suffix in ['.ll', '.o']:
            candidates = sorted(out.rglob('*' + suffix), key=lambda p: p.stat().st_mtime)
            assert candidates, (want, suffix)
            p = candidates[-1]
            q = artifacts / (label + '-' + p.name)
            shutil.copyfile(p, q)
            files[suffix] = dict(path=str(q.relative_to(D)), bytes=q.stat().st_size, sha256=sha(q))
        e['artifacts'][label] = files
        save()
    for n, h in source.items():
        assert sha(S / n) == h, ('Source changed during the campaign', n)
    e.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
except TimeoutError as ex:
    e.update(status='interrupted-at-deadline', error=repr(ex)); save(); raise
except BaseException as ex:
    e.update(status='failed', error=repr(ex)); save(); raise
