from pathlib import Path
import os,subprocess,json,hashlib,time,tomllib
R=Path.cwd();O=Path('/tmp/zstdoxide-ultra-path-implementation-1016');O.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();paths=list((R/'src').rglob('*.rs'))+[R/'tests/support/ultra_path_fixture.rs',R/'tests/support/ultra_path_parse.rs',R/'tests/fixtures/reference-ultra-paths/cases.bin',R/'Cargo.toml',R/'Cargo.lock'];source={str(p.relative_to(R)):sha(p)for p in paths};records=[];env=os.environ|dict(CARGO_TARGET_DIR='/tmp/zstdoxide-ultra-frequencies-target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'})
commands=[('frequency',['cargo','test','--features','unsafe-optimal-frequencies','--lib','optimal_parse::ultra_tests']),('paths',['cargo','test','--features','unsafe-optimal-paths','--lib','optimal_parse::ultra_tests']),('matches',['cargo','test','--features','unsafe-optimal-matches','--lib','optimal_parse::ultra_tests']),('safe',['cargo','test','--lib','optimal_parse::']),('all',['cargo','test','--all-features','--lib','optimal_parse::']),('release-all',['cargo','test','--release','--all-features','--lib','optimal_parse::']),('nostd-safe',['cargo','check','--no-default-features']),('nostd-all',['cargo','check','--no-default-features','--features',','.join(features)]),('clippy-safe',['cargo','clippy','--all-targets','--','-D','warnings']),('clippy-all',['cargo','clippy','--all-targets','--all-features','--','-D','warnings']),('fmt',['cargo','fmt','--all','--check'])]
def save(status,error=None):(O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,source_unchanged=all(sha(R/p)==h for p,h in source.items()),commands=records),indent=2)+'\n')
save('running')
try:
 for label,argv in commands:
  print('START',label,flush=True);p=O/(label+'.log');start=time.monotonic()
  with p.open('w')as f:r=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  records.append(dict(label=label,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)));save('running')
  if r.returncode:raise ValueError(label)
  print('END',label,flush=True)
 if any(sha(R/p)!=h for p,h in source.items()):raise ValueError('source changed')
 save('passed')
except BaseException as error:save('failed',repr(error));raise
