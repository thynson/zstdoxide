from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-module16-final-matrix');sha=lambda b:hashlib.sha256(b).hexdigest();enc=lambda v:(json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
names=['check_tree_frame_recipes','check_tree_frame_validator','check_tree_frame_plan','pack_tree_frame_trajectories','check_reference_admission_v5','check_tree_interop_preflight']
e=json.loads((O/'evidence.json').read_bytes());before=json.loads((O/'source-before.json').read_bytes());rows=[];files={}
for name in names:
 row=next(c for c in e['commands'] if c['label']=='offline-'+name)
 if row['exit_code']!=0 or row['exception'] is not None:raise ValueError('passed offline command')
 b=Path(row['log']).read_bytes()
 if sha(b)!=row['log_sha256']:raise ValueError('log identity')
 files[name+'.log']=b;rows.append(row)
source={}
for n,h in before.items():
 if n.startswith('scripts/') and Path(n).suffix in ('.py','.c','.sh'):
  b=(R/n).read_bytes()
  if sha(b)!=h:raise ValueError('offline source changed '+n)
  source[n]=h;files['source/'+n]=b
# Recorded fixture identities bind the already committed immutable capture and projection inputs.
fixture_source={n:h for n,h in before.items() if n.startswith('tests/fixtures/')}
for n,h in fixture_source.items():
 if sha((R/n).read_bytes())!=h:raise ValueError('fixture changed '+n)
report=dict(status='passed',date='2026-10-13',commands=rows,source=source,fixture_source=fixture_source,qualification='Six newly registered ordinary-tree/admission offline commands have passed against immutable snapshot inputs. Full Rust feature matrix is still running and is not claimed complete by this driver checkpoint.',archive='2026-10-13-tree-driver-checks.tar.gz')
files['report.json']=enc(report);files['package.py']=Path(__file__).read_bytes();a=R/'docs/evidence'/report['archive']
if a.exists():raise ValueError('fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('tree-driver-checks/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:found={i.name:t.extractfile(i).read() for i in t}
if found!={'tree-driver-checks/'+n:b for n,b in files.items()}:raise ValueError('archive bytes')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files));(R/'docs/evidence/2026-10-13-tree-driver-checks.json').write_bytes(enc(report));print(len(rows),len(source),len(fixture_source),a.stat().st_size)
