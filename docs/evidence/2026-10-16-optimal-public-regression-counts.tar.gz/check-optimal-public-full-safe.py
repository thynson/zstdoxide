from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path.cwd();O=Path('/tmp/zstdoxide-optimal-public-full-safe-1016');O.mkdir(exist_ok=False)
env=dict(os.environ,CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
paths=list((R/'src').rglob('*.rs'))+list((R/'tests').rglob('*.rs'))+list((R/'test-support').rglob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock',R/'rust-toolchain.toml']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source={str(p.relative_to(R)):sha(p)for p in paths};argv=['cargo','test','--offline','--locked'];start=time.monotonic()
(O/'evidence.json').write_text(json.dumps(dict(status='running',source=source,argv=argv),indent=2)+'\n')
with(O/'full-safe.log').open('wb')as f:p=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
unchanged=all(sha(R/p)==h for p,h in source.items())
evidence=dict(status='passed'if p.returncode==0 and unchanged else'failed',source=source,source_unchanged=unchanged,argv=argv,exit_code=p.returncode,seconds=time.monotonic()-start,log='full-safe.log',sha256=sha(O/'full-safe.log'))
(O/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n');print(evidence['status'],p.returncode,evidence['seconds'],flush=True)
