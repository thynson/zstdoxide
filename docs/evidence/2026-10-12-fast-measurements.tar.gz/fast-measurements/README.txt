Original nine-case, 14-configuration Fast timing evidence.
All campaign output files except targets/ are preserved.
Identical full frames are stored once under frame-bytes/. frame-map.json
maps every original campaign frame path to its exact stored bytes.
Build artifacts and executables are omitted; original paths, hashes,
compiler/environment and build/run commands are in evidence.json.
Every measured source-manifest file is also retained under source/.
Frame bytes and raw sample/allocation records are included in full.
The original campaign remains on disk. Documentation is not benchmark input.
