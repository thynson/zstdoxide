#!/usr/bin/env python3
"""Preserve a completed campaign without build artifacts or executable copies."""
from pathlib import Path
import argparse, hashlib, io, json, tarfile

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('campaign', type=Path)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--barrier', type=Path, required=True)
    args = parser.parse_args()
    assert not args.archive.exists()
    evidence = json.loads((args.campaign / 'evidence.json').read_text())
    assert evidence['status'] == 'passed' and evidence['timed'] is True
    assert len(evidence['configs']) in (2, 14)
    members = {}
    frame_map = {}
    for path in sorted(args.campaign.rglob('*')):
        relative = path.relative_to(args.campaign)
        if relative.parts[0] == 'targets':
            continue
        assert not path.is_symlink(), path
        if path.is_file():
            data = path.read_bytes()
            name = 'campaign/' + relative.as_posix()
            if relative.parts[0] == 'frames':
                blob = 'frame-bytes/' + sha(data) + '.zst'
                if blob in members:
                    assert members[blob] == data
                members[blob] = data
                frame_map[name] = blob
            else:
                members[name] = data
    for name, expected in evidence['source'].items():
        data = (args.root / name).read_bytes()
        assert sha(data) == expected, name
        members['source/' + name] = data
    members['frame-map.json'] = (json.dumps(frame_map, sort_keys=True, indent=2) + '\n').encode()
    members['cpu-barrier.json'] = args.barrier.read_bytes()
    members['package.py'] = Path(__file__).read_bytes()
    members['README.txt'] = (
        f"Original nine-case, {len(evidence['configs'])}-configuration Fast timing evidence.\n"
        'All campaign output files except targets/ are preserved.\n'
        'Identical full frames are stored once under frame-bytes/. frame-map.json\n'
        'maps every original campaign frame path to its exact stored bytes.\n'
        'Build artifacts and executables are omitted; original paths, hashes,\n'
        'compiler/environment and build/run commands are in evidence.json.\n'
        'Every measured source-manifest file is also retained under source/.\n'
        'Frame bytes and raw sample/allocation records are included in full.\n'
        'The original campaign remains on disk. Documentation is not benchmark input.\n'
    ).encode()
    catalog = {name: {'bytes': len(data), 'sha256': sha(data)}
               for name, data in sorted(members.items())}
    members['bundle-manifest.json'] = (json.dumps(catalog, sort_keys=True, indent=2) + '\n').encode()
    with tarfile.open(args.archive, 'w:gz') as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo('fast-measurements/' + name)
            info.size, info.mtime, info.mode = len(data), 0, 0o644
            archive.addfile(info, io.BytesIO(data))
    with tarfile.open(args.archive) as archive:
        assert set(archive.getnames()) == {'fast-measurements/' + n for n in members}
        for name, data in members.items():
            assert archive.extractfile('fast-measurements/' + name).read() == data
    print(json.dumps({'archive': str(args.archive), 'bytes': args.archive.stat().st_size,
                      'sha256': sha(args.archive.read_bytes()), 'members': len(members)}))

if __name__ == '__main__':
    main()
