from pathlib import Path
import copy, importlib.util, tempfile, unittest
spec=importlib.util.spec_from_file_location('resume',Path(__file__).with_name('resume.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
class ResumeEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.source=self.root/'source';self.source.mkdir();self.campaign=self.root/'campaign';self.campaign.mkdir()
        (self.source/'lib.rs').write_text('pub fn safe() {}\n');self.log=self.campaign/'safe-full.log';self.log.write_text('test result: ok. 2 passed; 0 failed; 1 ignored;\n')
        self.j=dict(source={'lib.rs':module.sha(self.source/'lib.rs')},plan=[['safe-full',['cargo','test']],['all-full',['cargo','test','--all-features']]],commands=[dict(label='safe-full',argv=['cargo','test'],exit_code=0,log_sha256=module.sha(self.log))])
    def tearDown(self):self.temp.cleanup()
    def verify(self):return module.verify(self.j,self.source,self.campaign,(1,2,1))
    def test_reuses_only_completed_prefix(self):self.assertEqual(self.verify(),1)
    def test_changed_source_is_rejected(self):
        (self.source/'lib.rs').write_text('changed');self.assertRaises(AssertionError,self.verify)
    def test_changed_log_is_rejected(self):
        self.log.write_text('changed');self.assertRaises(AssertionError,self.verify)
    def test_zero_selected_tests_are_rejected_even_with_current_digest(self):
        self.log.write_text('test result: ok. 0 passed; 0 failed; 0 ignored;\n');self.j['commands'][0]['log_sha256']=module.sha(self.log);self.assertRaises(AssertionError,self.verify)
    def test_nonprefix_command_is_rejected(self):
        self.j['commands'][0]['label']='all-full';self.assertRaises(AssertionError,self.verify)
    def test_failed_command_is_never_reused(self):
        self.j['commands'][0]['exit_code']=101;self.assertRaises(AssertionError,self.verify)
    def test_changed_command_arguments_are_rejected(self):
        self.j['commands'][0]['argv']=['cargo','test','unrelated_filter'];self.assertRaises(AssertionError,self.verify)
if __name__=='__main__':unittest.main(verbosity=2)
