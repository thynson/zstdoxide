"""Resume an unchanged frozen matrix after an explicit work-window interruption."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, re, shutil, signal, subprocess, time

COUNTS = {31: (105, 1706, 70), 32: (108, 1723, 71), 33: (111, 1740, 73)}
TARGETS = {31: 'module31-public-target', 32: 'module32-public-target', 33: 'module33-matrix-target'}
ROOT = Path('/private/tmp')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def counts(text):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert all(int(f) == 0 for _, f, _ in rows), 'A test group failed'
    return len(rows), sum(int(p) for p, _, _ in rows), sum(int(i) for _, _, i in rows)
def verify(j, source, campaign, expected):
    for name, digest in j['source'].items():
        assert sha(source/name) == digest, ('Source changed', name)
    rows = j['commands']
    assert len(rows) <= len(j['plan'])
    for row, (label, argv) in zip(rows, j['plan']):
        assert row['label'] == label and row['argv'] == argv, 'Completed rows must be the exact plan prefix'
        assert row['exit_code'] == 0, ('Failed command cannot be reused', label)
        log = campaign/(label+'.log')
        assert sha(log) == row['log_sha256'], ('Log changed', label)
        if label.endswith(('-full', '-release')):
            assert counts(log.read_text()) == expected, ('Unexpected or zero test counts', label)
    return len(rows)
def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('module', type=int, choices=COUNTS)
    p.add_argument('--dry-run', action='store_true')
    p.add_argument('--deadline-utc', help='Explicit newly authorized UTC cutoff, ISO 8601 with timezone')
    a = p.parse_args(); d = ROOT/f'module{a.module}-matrix'; s = ROOT/f'module{a.module}-final'
    evidence = d/'evidence.json'; original = evidence.read_bytes(); j = json.loads(original)
    gate_paths = {
        31: dict(core='module31-core/evidence.json', public='module31-public/evidence.json', platform='module31-platform/evidence.json', native='module31-native/replay.json', history='module31-native-history/replay.json', preflight='module31-matrix/preflight.json'),
        32: dict(core='module32-selection/evidence.json', public='module32-public/evidence.json', platform='module32-platform/evidence.json', native='module32-native/replay.json', corpus='module32-fuzz/corpus.json', preflight='module32-matrix/preflight.json'),
        33: dict(public='module33-public/evidence.json', platform='module33-platform/evidence.json', native='module33-native/replay.json', corpus='module33-corpus/evidence.json', preflight='module33-matrix/preflight.json'),
    }[a.module]
    assert set(gate_paths)==set(j['focused_gate_receipts'])
    for name, digest in j['focused_gate_receipts'].items():
        receipt=ROOT/gate_paths[name];assert sha(receipt)==digest, ('Focused gate changed',name)
        assert json.loads(receipt.read_text())['status']=='passed'
    inventory={str(q.relative_to(s)) for folder in ['src','tests','test-support'] for q in (s/folder).rglob('*') if q.is_file()}|{'Cargo.toml','Cargo.lock','rust-toolchain.toml'}
    assert inventory==set(j['source']), 'Frozen source inventory changed'
    done = verify(j, s, d, COUNTS[a.module])
    if a.dry_run:
        print(json.dumps(dict(status='verified-read-only',module=a.module,campaign_status=j['status'],completed=done,remaining=len(j['plan'])-done,next_command=j['plan'][done] if done<len(j['plan']) else None)))
        return
    assert j['status'] in ['interrupted-at-user-deadline', 'interrupted-by-coordinator'], 'Never resume an active or failed campaign'
    assert a.deadline_utc, 'A new explicit user-authorized deadline is required'
    deadline_dt = datetime.datetime.fromisoformat(a.deadline_utc)
    assert deadline_dt.tzinfo is not None and deadline_dt.utcoffset() == datetime.timedelta(0)
    deadline = deadline_dt.timestamp(); assert deadline-time.time() >= 120
    assert evidence.read_bytes() == original, 'Evidence changed during verification'
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    attempt = d/'resume-attempts'/stamp; attempt.mkdir(parents=True, exist_ok=False)
    (attempt/'prior-evidence.json').write_bytes(original)
    shutil.copyfile(__file__, attempt/'resume.py')
    shutil.copyfile(d/'check.py', attempt/'original-check.py')
    interrupted = []
    for label, _ in j['plan'][done:]:
        log = d/(label+'.log')
        if log.exists():
            interrupted.append(dict(name=log.name,sha256=sha(log),bytes=log.stat().st_size))
            log.rename(attempt/log.name)
    record = dict(prior_evidence_sha256=hashlib.sha256(original).hexdigest(),controller_sha256=sha(Path(__file__)),resumed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),deadline_utc=deadline_dt.isoformat(),completed_reused=done,interrupted_logs=interrupted)
    (attempt/'reconciliation.json').write_text(json.dumps(record,indent=2)+'\n')
    j.setdefault('resume_attempts',[]).append(dict(path=str(attempt.relative_to(d)),**record))
    j.update(status='running',deadline_utc=deadline_dt.isoformat());j.pop('error',None);j.pop('finished_utc',None)
    env = {**os.environ,'CARGO_TARGET_DIR':str(ROOT/TARGETS[a.module]),'CARGO_BUILD_JOBS':'3' if a.module==33 else '4','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
    def save():
        temp = evidence.with_suffix('.pending.json');temp.write_text(json.dumps(j,indent=2)+'\n');temp.replace(evidence)
    save()
    try:
        for label, argv in j['plan'][done:]:
            remaining = deadline-time.time()-30
            if remaining < 30: raise TimeoutError('User work window reached before '+label)
            j['active_command']=dict(label=label,argv=argv,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
            start=time.monotonic();log=d/(label+'.log')
            with log.open('xb') as f:
                proc=subprocess.Popen(argv,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
                try:code=proc.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid,signal.SIGTERM)
                    try:proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
                    raise TimeoutError('User work window reached during '+label)
            row=dict(label=label,argv=argv,exit_code=code,seconds=time.monotonic()-start,log_sha256=sha(log))
            if code==0 and label.endswith(('-full','-release')):
                result=counts(log.read_text());assert result==COUNTS[a.module],(label,result)
                row.update(result_groups=result[0],passed=result[1],ignored=result[2])
            j['commands'].append(row);j.pop('active_command',None);save();print(label,code,flush=True);assert code==0,label
        verify(j,s,d,COUNTS[a.module]);j.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
    except TimeoutError as ex:j.update(status='interrupted-at-user-deadline',error=repr(ex));save();raise
    except BaseException as ex:j.update(status='failed',error=repr(ex));save();raise
if __name__=='__main__':main()
