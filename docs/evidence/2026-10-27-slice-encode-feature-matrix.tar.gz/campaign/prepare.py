from pathlib import Path
import json,subprocess,hashlib,time,shutil,os
D=Path(__file__).parent;S=Path('/private/tmp/module33-final');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();gates={}
for name,path,count in [('public','module33-public/evidence.json',21),('native','module33-native/replay.json',6),('platform','module33-platform/evidence.json',8),('corpus','module33-corpus/evidence.json',5)]:
 p=Path('/private/tmp')/path
 while True:
  try:j=json.loads(p.read_text())
  except (FileNotFoundError,json.JSONDecodeError):j={'status':'running'}
  assert j['status']!='failed',(name,j.get('error'))
  if j['status']=='passed':break
  time.sleep(5)
 assert len(j['commands'])==count;gates[name]=sha(p)
assert not S.exists();subprocess.run(['cp','-cR','/private/tmp/module33-public/source',str(S)],check=True)
for root,n in [('module33-native/replay-source','tests/slice_encode_output_native.rs'),('module33-platform/source','tests/slice_encode_output_platform.rs'),('module33-corpus/source','tests/upstream_fuzz_targets.rs')]:shutil.copyfile(Path('/private/tmp')/root/n,S/n)
# Explicitly prepare the next qualification snapshot with independently audited
# metadata scheduled for integration after Module32 closes. No earlier focused
# snapshot is changed or relabeled; production bytes remain exactly public33.
M=Path('/private/tmp/module32-inventory-plan/manifest.json');shutil.copyfile(M,S/'tests/upstream/manifest.json')
subprocess.run(['cargo','fmt','--all','--','--check'],cwd=S,check=True)
e=dict(status='prepared',source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()},focused_receipts=gates,inventory_candidate_sha256=sha(M),qualification='New explicit final snapshot combines unchanged public production and qualified native/platform/corpus adapters. The independently audited pending inventory candidate is copied deliberately; frozen earlier sources are untouched. Root metadata must match after its separate post-32 reconciliation before any33closure.');(D/'preparation.json').write_text(json.dumps(e,indent=2)+'\n')
args=['cargo','clippy','--offline','--locked','--lib','--tests','--all-features','--','-D','warnings'];env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module33-matrix-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
r=dict(status='running',source=e['source'],commands=[]);(D/'preflight.json').write_text(json.dumps(r,indent=2)+'\n')
for label,cmd in [('clippy',args),('format',['cargo','fmt','--all','--','--check'])]:
 t=time.monotonic()
 with (D/('preflight-'+label+'.log')).open('xb') as f:p=subprocess.run(cmd,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append(dict(label=label,argv=cmd,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/('preflight-'+label+'.log'))));r['status']='running' if p.returncode==0 else 'failed';(D/'preflight.json').write_text(json.dumps(r,indent=2)+'\n');assert p.returncode==0,label
r['status']='passed';(D/'preflight.json').write_text(json.dumps(r,indent=2)+'\n');print('Final33 source assembled and two preflight commands passed',flush=True)
