from pathlib import Path
import hashlib,json,tarfile,re,tomllib
D=Path(__file__).parent;S=Path('/private/tmp/module33-final');M=Path('/private/tmp/module33-matrix');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
j=json.loads((M/'evidence.json').read_text());assert j['status']=='passed' and len(j['commands'])==75
features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'));assert len(features)==22
assert {c['label'] for c in j['commands']}=={n+'-'+suffix for n in ['safe','all',*features] for suffix in ['full','no-std','clippy']}|{'safe-release','all-release','format'}
for n,h in j['source'].items():assert sha(S/n)==h,n
complete={str(p.relative_to(S)):sha(p) for folder in ['src','tests','test-support','benches','examples','scripts'] for p in (S/folder).rglob('*') if p.is_file()};complete.update({n:sha(S/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']})
commands=[]
for c in j['commands']:
 assert c['exit_code']==0
 p=M/(c['label']+'.log');assert sha(p)==c['log_sha256'];g=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.read_text());assert all(int(f)==0 for _,f,_ in g)
 counts=(len(g),sum(int(a) for a,_,_ in g),sum(int(i) for _,_,i in g))
 if c['label'].endswith(('-full','-release')):assert counts==(111,1740,73),(c['label'],counts)
 commands.append({**c,'result_groups':counts[0],'passed':counts[1],'ignored':counts[2]})
name='2026-10-27-slice-encode-feature-matrix';archive=D/(name+'.tar.gz');assert not archive.exists()
files={'campaign/'+str(p.relative_to(M)):p for p in M.rglob('*') if p.is_file()};files.update({'source/'+n:S/n for n in complete if Path(n).suffix in {'.rs','.toml','.lock','.md','.json','.py','.sh','.tsv','.csv'}});files['archive-matrix.py']=Path(__file__)
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
result=dict(status='passed',source=j['source'],production_source={n:h for n,h in complete.items() if n.startswith('src/')},complete_source=complete,commands=commands,members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()},archive=archive.name,archive_sha256=sha(archive),full_suite_counts=dict(result_groups=111,passed=1740,ignored=73),qualification='Final frozen candidate is independently qualified before integration. The rejected initial engine test API call is retained. Native capacities and byte choices are measured independently, with Rust success-tail guarantees explicit. Final preflight and native/history/platform gates precede this full matrix. Production source did not change. Safe/all/22 isolated full suites, true no_std and strict Clippy, safe/all release and formatting pass. Ignored external adapters have separate explicit execution receipts. No unexecuted check is credited.')
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
