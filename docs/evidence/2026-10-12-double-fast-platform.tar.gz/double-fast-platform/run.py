import datetime,hashlib,io,json,os,pathlib,re,shlex,subprocess,tarfile,time
ROOT=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize')
OUT=pathlib.Path('/tmp/zstdoxide-module13-platform')
SNAP=OUT/'snapshot';PROBE=OUT/'thumb-caller';TOOLCHAIN='nightly-2026-10-08'
FEATURES=['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-dictionary','unsafe-training']
LIB_TESTS=['double_fast_parse::tests::out_of_range_future_and_expired_candidates_are_rejected_before_reads','double_fast_parse::tests::either_output_reserve_failure_preserves_logical_state_and_exact_owners','double_fast_tables::tests::either_allocation_failure_releases_both_exact_nonclone_owners','reference_frame::tests::known_size_boundaries_use_reference_field_widths_and_no_checksum','reference_frame::tests::maximum_four_byte_size_promotes_before_the_format_requires_it','reference_frame::tests::raw_frame_bound_counts_actual_window_blocks_and_the_empty_final_block']
PUBLIC_TESTS=['tiny_frames_release_each_selected_owner_and_keep_borrowed_output_alive','unequal_tables_publish_a_complete_frame_for_each_effective_key_width']
sha=lambda b:hashlib.sha256(b).hexdigest()
def manifest(root):return {str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(root.rglob('*')) if p.is_file()}
if SNAP.exists() or PROBE.exists():raise RuntimeError('Snapshot already exists')
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
archive=subprocess.check_output(['git','archive',revision,'Cargo.toml','Cargo.lock','rust-toolchain.toml','src','tests','test-support','benches','scripts/check_miri_filter.py'],cwd=ROOT)
SNAP.mkdir()
with tarfile.open(fileobj=io.BytesIO(archive)) as tf:
 for member in tf.getmembers():
  p=pathlib.Path(member.name)
  if p.is_absolute() or '..' in p.parts or not(member.isfile() or member.isdir()):raise RuntimeError('Unsafe archive entry')
 tf.extractall(SNAP,filter='data')
tracked_before=manifest(SNAP)
for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']+[str(p.relative_to(ROOT)) for p in sorted((ROOT/'src').rglob('*.rs'))]:
 if (SNAP/p).read_bytes()!=(ROOT/p).read_bytes():raise RuntimeError('Working source differs '+p)
(SNAP/'tests/reference_double_fast_platform.rs').write_bytes((OUT/'public_probe.rs').read_bytes())
source=manifest(SNAP);(OUT/'source-manifest.json').write_text(json.dumps({'revision':revision,'git_archive_sha256':sha(archive),'snapshot':str(SNAP),'temporary_test':'tests/reference_double_fast_platform.rs','files':source},indent=2)+'\n')
(PROBE/'src').mkdir(parents=True)
(PROBE/'src/lib.rs').write_bytes((OUT/'thumb_probe.rs').read_bytes())
(PROBE/'Cargo.toml').write_text('[package]\nname="zstdoxide-module13-thumb-caller"\nversion="0.0.0"\nedition="2024"\n[dependencies]\nzstdoxide={path="'+str(SNAP)+'",default-features=false}\n')
e={'schema_version':1,'revision':revision,'snapshot':str(SNAP),'source_manifest_sha256':sha((OUT/'source-manifest.json').read_bytes()),'runner_sha256':sha(pathlib.Path(__file__).read_bytes()),'selected_repository_tests':LIB_TESTS,'selected_temporary_tests':PUBLIC_TESTS,'temporary_harness':{'public':(OUT/'public_probe.rs').read_text(),'public_sha256':sha((OUT/'public_probe.rs').read_bytes()),'thumb':(OUT/'thumb_probe.rs').read_text(),'thumb_sha256':sha((OUT/'thumb_probe.rs').read_bytes())},'features':FEATURES,'qualification':'i686 and s390x execute under strict-provenance Miri interpretation, not native/QEMU. Thumbv6m performs no_std library compilation and caller rlib code generation only, not runtime, linking firmware, hardware memory-fit or stable Allocator API support. Two new repository public tests are overlaid before the final matrix/platform commit. The Rc alias check exercises the existing no-pointer-atomics dictionary fallback, separately from Fast.','commands':[],'status':'running','started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
EVIDENCE=OUT/'evidence.json'
def save():EVIDENCE.write_text(json.dumps(e,indent=2)+'\n')
def unchanged():return manifest(SNAP)==source
def run(name,argv,cwd=SNAP,extra=None,expected=None,timeout=1200):
 if not unchanged():raise RuntimeError('Snapshot changed before '+name)
 env=os.environ.copy()
 # Do not inherit build or interpreter overrides into explicit target checks.
 for k in list(env):
  if k.startswith(('CARGO_TARGET_','CARGO_BUILD_','CARGO_PROFILE_')) or k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','RUSTDOCFLAGS','MIRI_SYSROOT','MIRIFLAGS']:
   env.pop(k)
 additions={'RUSTUP_TOOLCHAIN':TOOLCHAIN,'CARGO_TERM_COLOR':'never',**(extra or {})};env.update(additions)
 log=OUT/(name+'.log');start=time.monotonic();record={'name':name,'argv':argv,'command':shlex.join(argv),'cwd':str(cwd),'environment':additions,'log':str(log),'expected_tests':expected}
 print('START',name,flush=True)
 try:
  with log.open('wb') as f:p=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
  record['exit_code']=p.returncode
 except (subprocess.TimeoutExpired,OSError) as error:
  record['exit_code']=None;record['exception']=repr(error)
 raw=log.read_bytes();text=raw.decode(errors='replace')
 record.update({'seconds':time.monotonic()-start,'log_sha256':sha(raw),'log_bytes':len(raw),'source_unchanged':unchanged()})
 if expected is not None:
  passed=re.findall(r'^test (\S+) \.\.\. ok$',text,re.M)
  sums=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
  record.update({'actual_tests':passed,'summaries':sums,'count_and_names_valid':sorted(passed)==sorted(expected) and len(passed)==len(expected) and sums==[(str(len(expected)),'0','0')]})
 valid=record['exit_code']==0 and record['source_unchanged'] and record.get('count_and_names_valid',True)
 record['passed']=valid;e['commands'].append(record);save();print('END',name,valid,record['seconds'],flush=True)
 if not valid:raise RuntimeError('Validation failed: '+name)
 return text
save()
try:
 e['compiler']=run('compiler',['rustc','+'+TOOLCHAIN,'-vV'])
 e['miri_version']=run('miri-version',['cargo','+'+TOOLCHAIN,'miri','--version'])
 for target in ['i686-unknown-linux-gnu','s390x-unknown-linux-gnu','thumbv6m-none-eabi']:
  e.setdefault('target_cfg',{})[target]=run('cfg-'+target,['rustc','+'+TOOLCHAIN,'--print','cfg','--target',target])
 run('native-temporary-harness-smoke',['cargo','+'+TOOLCHAIN,'test','--offline','--locked','--test','reference_double_fast_platform','--','--exact',*PUBLIC_TESTS,'--test-threads=1'],extra={'CARGO_TARGET_DIR':'/tmp/zstdoxide-module13-platform-native-target'},expected=PUBLIC_TESTS)
 for short in ['i686','s390x']:
  target=short+'-unknown-linux-gnu';sysroot=pathlib.Path('/tmp/zstdoxide-platform-sysroot-'+short)
  if not (sysroot/'lib/rustlib'/target/'lib').is_dir():raise RuntimeError('Missing cached sysroot')
  e.setdefault('cached_sysroots',{})[short]={'path':str(sysroot),'files':manifest(sysroot)};save()
  for backend,flags in [('safe',[]),('all',['--all-features'])]:
   extra={'MIRI_SYSROOT':str(sysroot),'MIRIFLAGS':'-Zmiri-strict-provenance','CARGO_TARGET_DIR':'/tmp/zstdoxide-module13-platform-miri-'+short}
   for group,target_args,selectors in [('parser',['--lib'],LIB_TESTS),('public',['--test','reference_double_fast_platform'],PUBLIC_TESTS)]:
    run('miri-'+short+'-'+backend+'-'+group,['cargo','+'+TOOLCHAIN,'miri','test','--offline','--locked','--target',target,*target_args,*flags,'--','--exact',*selectors,'--test-threads=1'],extra=extra,expected=selectors)
 extra={'CARGO_TARGET_DIR':'/tmp/zstdoxide-module13-platform-thumb-target'}
 run('thumb-lock',['cargo','+'+TOOLCHAIN,'generate-lockfile','--offline'],cwd=PROBE,extra=extra)
 probe_before=manifest(PROBE);e['thumb_probe_files']=probe_before;save()
 for backend,flags in [('safe',[]),('all',['--features',','.join(FEATURES)])]:
  run('thumb-library-'+backend,['cargo','+'+TOOLCHAIN,'check','--offline','--locked','-Z','build-std=core,alloc','--target','thumbv6m-none-eabi','--no-default-features','--lib',*flags],extra=extra)
 for backend,flags in [('safe',[]),('all',['--features',','.join('zstdoxide/'+f for f in FEATURES)])]:
  run('thumb-caller-'+backend,['cargo','+'+TOOLCHAIN,'build','--offline','--locked','-Z','build-std=core,alloc','--target','thumbv6m-none-eabi','--lib',*flags],cwd=PROBE,extra=extra)
  artifact=pathlib.Path(extra['CARGO_TARGET_DIR'])/'thumbv6m-none-eabi/debug/libzstdoxide_module13_thumb_caller.rlib'
  if not artifact.is_file() or artifact.stat().st_size==0:raise RuntimeError('Missing caller artifact')
  e.setdefault('caller_artifacts',{})[backend]={'path':str(artifact),'bytes':artifact.stat().st_size,'sha256':sha(artifact.read_bytes())};save()
 if manifest(PROBE)!=probe_before:raise RuntimeError('Probe changed')
 e['status']='passed';e['interpreted_test_executions']=32;e['native_temporary_smoke_executions']=2;e['processes_remaining']=0;e['source_unchanged']=unchanged();save()
except Exception as error:
 e['status']='failed';e['exception']=repr(error);e['processes_remaining']=0;save();raise
print('FROZEN',EVIDENCE,sha(EVIDENCE.read_bytes()),flush=True)
