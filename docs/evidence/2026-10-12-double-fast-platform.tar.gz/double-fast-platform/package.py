from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-module13-platform')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,m):
 if not v:raise ValueError(m)
e=json.loads((O/'evidence.json').read_bytes());m=json.loads((O/'source-manifest.json').read_bytes())
need(e['status']=='passed' and e['source_unchanged'] and e['processes_remaining']==0 and len(e['commands'])==19,'complete run')
count=0
for c in e['commands']:
 b=Path(c['log']).read_bytes();need(c['passed'] and c['exit_code']==0 and c['source_unchanged'] and sha(b)==c['log_sha256'],'command '+c['name'])
 if c['name'].startswith('miri-') and c['name']!='miri-version':
  need(c['count_and_names_valid'],'exact nonempty selector count');count+=len(c['actual_tests'])
need(count==32,'interpreted counts')
critical=[n for n in m['files'] if n.startswith(('src/','test-support/allocator/')) or n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/reference_double_fast_platform.rs')]
for n in critical:need(sha((R/n).read_bytes())==m['files'][n]['sha256'],'delivered source '+n)
reconciled=json.loads((O/'caller-artifact-reconciliation.json').read_bytes())
for mode,r in e['caller_artifacts'].items():
 need(reconciled[mode] and all(sha(Path(p).read_bytes())==r['sha256'] for p in reconciled[mode]),'retained caller identity '+mode)
report=dict(date='2026-10-12',status='passed',base=e['revision'],overlay='tests/reference_double_fast_platform.rs from public_probe.rs',commands=19,interpreted_executions=32,native_smoke_executions=2,thumb_library_checks=2,thumb_caller_codegen=2,source_unchanged=True,source_comparisons=critical,qualification=e['qualification'],artifact_qualification='The initial packaging check rejected the overwritten canonical safe rlib path. Both exact originally recorded artifacts remain under distinct Cargo build output paths; their bytes were rehashed without rebuilding. See caller-artifact-reconciliation.json.',scope='Six selected repository parser/table/header bounds tests and two public ownership/wire tests per safe/all interpreted target; no whole foreign suite or native foreign execution.',archive='2026-10-12-double-fast-platform.tar.gz')
files={str(p.relative_to(O)):p.read_bytes() for p in O.iterdir() if p.is_file()}
files.update({str(p.relative_to(O)):p.read_bytes() for p in (O/'thumb-caller').rglob('*') if p.is_file()})
files['native-bootstrap.log']=Path('/tmp/zstdoxide-double-fast-platform-bootstrap.log').read_bytes();files['package.py']=Path(__file__).read_bytes();files['review.json']=enc(report)
files['bundle-manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())})
a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh archive');prefix='double-fast-platform/'
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo(prefix+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:found={m.name:t.extractfile(m).read() for m in t}
need(found=={prefix+n:b for n,b in files.items()},'archive exact bytes')
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(files));(R/'docs/evidence/2026-10-12-double-fast-platform.json').write_bytes(enc(report));print(count,len(files),a.stat().st_size)
