from pathlib import Path
import hashlib,io,json,re,tarfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-double-fast-layout-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
e=json.loads((OUT/'evidence.json').read_text());assert e['status']=='passed' and e['source_unchanged']
for n,h in e['source'].items():assert sha((ROOT/n).read_bytes())==h,n
for c in e['commands']:
 assert c['exit_code']==0
 b=(OUT/c['log']).read_bytes();assert sha(b)==c['log_sha256']
 if c['label'].startswith('layout-'):assert re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)==[(b'3',b'0',b'0')]
 if c['label'].startswith('baselines-'):assert re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)==[(b'7',b'0',b'0'),(b'4',b'0',b'0')]
members={p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()};members['runner.py']=Path('/tmp/check-zstdoxide-double-fast-layout.py').read_bytes();members['package.py']=Path(__file__).read_bytes()
for name in ['src/match_search.rs','src/match_key.rs','src/matchfinder.rs']:members['source/'+name]=(ROOT/name).read_bytes()
report={'date':'2026-10-12','status':'passed','commands':len(e['commands']),'focused_layout_executions':15,'baseline_executions':22,'existing_named_domain_executions':1,'ignored':0,'source':e['source'],'scope':'Private copied eight-byte layout and both existing match-table backends. 576 existing direct C hash values plus 256 high-bit-derived expectations per new hash test; direct low-log C captures remain future work. No new unsafe code, DoubleFast encoder, fresh C execution, Miri or measurement.','archive':'2026-10-12-double-fast-layout.tar.gz'}
members['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();members['bundle-manifest.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},sort_keys=True,indent=2)+'\n').encode()
a=ROOT/'docs/evidence'/report['archive'];assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('double-fast-layout/'+n);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 for n,b in members.items():assert t.extractfile('double-fast-layout/'+n).read()==b
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(members))
(ROOT/'docs/evidence/2026-10-12-double-fast-layout.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(report['commands'],'commands;',len(members),'archive members')
