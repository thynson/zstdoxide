from pathlib import Path
import hashlib,json,sys,subprocess,types
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(ROOT/'scripts'))
import check_reference_interop_v2 as driver
import check_reference_fast_interop as original
from tempfile import TemporaryDirectory
subprocess.Popen=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('child process forbidden'))
def require(v,m):
 if not v:raise ValueError(m)
_,rows,recipes=driver.plan()
require(len(recipes)==92 and sum(r['expected']=='success' for r in recipes)==85,'plan')
old_execute=original.execute;old=(original.recipes,original.OWNED,original.write_json)
checks=[]
with TemporaryDirectory(prefix='zstdoxide-v2-driver-') as d:
 p=Path(d)/'evidence.json'
 def fake(args):
  require(len(original.recipes())==92,'patched recipes')
  require('scripts/check_reference_interop_v2.py' in original.OWNED,'owned wrapper')
  r=original.recipes();r[0]['id']='changed';require(original.recipes()[0]['id']!='changed','fresh recipe copy')
  original.write_json(p,{'schema_version':1,'cases':[{'recipe':{'id':rows[0]['case']},'rust':{'safe':{'resolved':[int(v) for v in rows[0]['historical_resolved_tuple'].split(',')]}}}]})
 original.execute=fake;driver.execute(types.SimpleNamespace())
 require((original.recipes,original.OWNED,original.write_json)==old,'restore success')
 value=json.loads(p.read_text());require(value['admission_policy']['version']==2 and len(value['admission_policy']['newly_admitted'])==6,'evidence scope');checks.append('valid scoped evidence and restored driver')
 before=p.read_bytes()
 def bad(args):original.write_json(p,{'cases':[{'recipe':{'id':rows[0]['case']},'rust':{'safe':{'resolved':[0]*7}}}]})
 original.execute=bad
 try:driver.execute(types.SimpleNamespace())
 except ValueError as e:require('scalar resolution' in str(e),'exact rejection')
 else:raise RuntimeError('accepted changed tuple')
 require(p.read_bytes()==before,'reject before write');require((original.recipes,original.OWNED,original.write_json)==old,'restore rejection');checks.append('changed tuple rejected before persistence; restored driver')
original.execute=old_execute
print(json.dumps({'mode':'optimized' if not __debug__ else 'normal','checks':checks,'child_processes':0,'recipes':len(recipes),'source_bytes':sum(r['size'] for r in recipes),'driver_sha256':hashlib.sha256((ROOT/'scripts/check_reference_interop_v2.py').read_bytes()).hexdigest()},sort_keys=True))
