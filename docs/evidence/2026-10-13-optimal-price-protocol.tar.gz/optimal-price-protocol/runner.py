from pathlib import Path
import hashlib,json,subprocess
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-optimal-price-protocol-checks');O.mkdir()
paths=['docs/reference-optimal-price-protocol.md','scripts/oracles/optimal_prices.py','scripts/check_optimal_price_protocol.py'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths};commands=[]
for name,flags in [('normal',[]),('optimized',['-O'])]:
 argv=['python3',*flags,'scripts/check_optimal_price_protocol.py'];log=O/(name+'.log');p=subprocess.run(argv,cwd=R,capture_output=True);log.write_bytes(p.stdout+p.stderr)
 if p.returncode:raise ValueError(name)
 v=json.loads(p.stdout)
 if v['status']!='passed' or v['positive_round_trips']!=9 or len(v['rejections'])!=38 or v['child_attempts']!=0:raise ValueError('controls')
 commands.append(dict(argv=argv,exit_code=p.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
if source!={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths}:raise ValueError('source unchanged')
(O/'evidence.json').write_text(json.dumps(dict(status='passed',source=source,commands=commands,qualification='Source-only price transport and lifecycle gate; nine positive round trips and 38 malformed request rejections per Python mode, no codec or child execution. Independent observation replay is specified, not yet implemented; no C price results or Optimal support.'),sort_keys=True,indent=2)+'\n')
