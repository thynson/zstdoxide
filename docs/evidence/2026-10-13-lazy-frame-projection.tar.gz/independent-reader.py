"""Independent field-by-field projected binary comparison, without codec calls."""
from pathlib import Path
import hashlib,json,os,struct,subprocess,sys,tempfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(ROOT/'scripts'))
children=[]
def forbidden(*a,**k):children.append('blocked');raise RuntimeError('child execution forbidden')
subprocess.Popen=forbidden
for name in ['system','fork','forkpty','posix_spawn','posix_spawnp','spawnl','spawnle','spawnlp','spawnlpe','spawnv','spawnve','spawnvp','spawnvpe','execl','execle','execlp','execlpe','execv','execve','execvp','execvpe']:
 if hasattr(os,name):setattr(os,name,forbidden)
import check_lazy_frames as fixture
import check_lazy_frame_capture as capture
import pack_lazy_frame_trajectories as packer
manifest,artifacts=fixture.check();_,_,_,v,_,cases=capture.inputs()
def need(ok,label):
 if not ok:raise ValueError(label)
class Reader:
 def __init__(self,data):self.data=memoryview(data);self.at=0
 def take(self,n):
  need(type(n)is int and 0<=n<=len(self.data)-self.at,'bounded extent')
  data=self.data[self.at:self.at+n];self.at+=n;return data
 def numbers(self,fmt):return struct.unpack('<'+fmt,self.take(struct.calcsize('<'+fmt)))
 def one(self,fmt):return self.numbers(fmt)[0]
 def blob(self,cap):
  n=self.one('I');need(n<=cap,'blob cap');return self.take(n)
 def end(self):need(self.at==len(self.data),'exhausted extent')
def sampling(r,expected):
 values=r.numbers('4IQ8I')
 want=(expected['next_to_update'],expected['skipping'],expected['row_hash_log'],expected['salt_entropy'],int(expected['salt'],16),*expected['cache'])
 need(values==want,'complete sampling record')
def verify(data):
 need(len(data)<=256<<20,'collection cap');r=Reader(data)
 need(r.take(8)==b'ZLZFR01\0','version magic')
 need(r.numbers('II')==(510,1377),'complete counts')
 names=set();blocks=0
 for case in cases:
  c=Reader(r.blob(32<<20));depth=c.one('B');need(depth==case.depth and c.take(3)==bytes(3),'depth/reserved')
  n=c.one('H');need(1<=n<=63,'name bound');name=bytes(c.take(n)).decode('ascii')
  need(name==case.name and name not in names and name.startswith(f'd{depth}_'),'unique bound name');names.add(name)
  need(c.numbers('8BI')==(case.window_log,case.hash_log,case.chain_log,case.search_log,case.min_match,int(case.window_log>14),0,0,case.target),'complete parameters')
  rows=[v.parse_json(line) for line in artifacts[name+'.stdout'].splitlines()]
  begin=rows[0];end=next(x for x in rows if x['type']=='complete')
  need(c.blob(4<<20)==case.source,'source bytes');need(c.one('Q')==int(begin['source_fnv64'],16),'source hash')
  need(c.blob((4<<20)+256)==artifacts[name+'.zst'],'complete frame');need(c.one('Q')==int(end['frame_fnv64'],16),'frame hash')
  whole=next((x for x in rows if x['type']=='whole_compare'),None)
  need(c.one('B')==int(whole is not None),'whole presence')
  if whole:
   need(c.blob((4<<20)+256)==artifacts[name+'.whole.zst'],'complete whole frame');need(c.one('Q')==int(whole['frame_fnv64'],16),'whole hash')
  n=c.one('I');need(n==len(case.schedule)<=64,'schedule count');need(tuple(c.one('I') for _ in range(n))==case.schedule,'schedule values')
  observed=[x for x in rows if x['type']=='block'];n=c.one('I');need(n==len(observed)<=64,'block count');blocks+=n
  for expected in observed:
   b=Reader(c.blob(16<<20));candidate=expected['candidate']
   need(b.numbers('4IBBH')==(expected['call'],expected['source_start'],expected['source_bytes'],expected['window']['dict_limit']-2,expected['kind'],int(candidate['fresh']),0),'block coordinates')
   for want in [expected['semantic_before'],expected['semantic_after'],expected['before']['raw_repeats'],expected['after']['raw_repeats']]:need(b.numbers('3I')==tuple(want),'incoming/published repeats')
   sampling(b,expected['sampling_before']);sampling(b,expected['sampling_after'])
   for key in ['first_table','second_table']:
    table=expected[key];log,width,reserved,count=b.numbers('BBHI')
    need((log,width,reserved,count)==(table['log'],table['element_bytes'],0,len(table['changed'])) and count<=1<<log,'owner dimensions/count')
    for want in table['changed']:need(b.numbers('3I')==tuple(want),'complete sparse delta')
    need(b.numbers('2Q')==(int(table['before_fnv64'],16),int(table['after_fnv64'],16)),'owner fingerprints')
   if candidate['fresh']:
    need(b.numbers('3I')==tuple(expected['candidate_state']['raw_repeats']),'candidate raw repeats')
    need(b.numbers('3I')==tuple(candidate['semantic_repeats']),'candidate wire repeats')
    need(b.one('I')==candidate['trailing'] and b.one('B')==candidate['long_length_type'] and b.take(3)==bytes(3) and b.one('I')==candidate['long_length_position'],'long marker/trailing')
    need(b.blob(131072)==bytes.fromhex(candidate['literal_bytes']),'literal bytes')
    count=b.one('I');need(count==len(candidate['sequences'])<=32768,'sequence count')
    for ll,ml,off,distance,raw_ll,raw_ml in candidate['sequences']:
     need(b.numbers('6I')==(ll,ml,distance,off,raw_ll,raw_ml),'every sequence field')
   b.end()
  c.end()
 r.end();need(blocks==1377 and len(names)==510,'all records read')
files={name:(packer.DESTINATION/name).read_bytes() for name in ['cases.bin','provenance.json']};data=files['cases.bin'];verify(data)
rejected=[]
def reject(name,action):
 try:action()
 except (ValueError,UnicodeError,struct.error):rejected.append(name)
 else:raise ValueError('changed binary accepted: '+name)
for end in [0,7,8,15,16,19,20,len(data)-1]:reject('truncated_'+str(end),lambda end=end:verify(data[:end]))
for offset,raw,label in [(0,b'X','magic'),(8,struct.pack('<I',509),'case_count'),(12,struct.pack('<I',1378),'block_count'),(16,struct.pack('<I',0xffffffff),'extent'),(20,b'\3','depth'),(20,b'\1','name_depth'),(21,b'\1','reserved1'),(22,b'\1','reserved2'),(23,b'\1','reserved3'),(24,b'\0\0','name_length'),(26,b'X','name')]:
 forged=bytearray(data);forged[offset:offset+len(raw)]=raw;reject(label,lambda:verify(forged))
reject('trailing',lambda:verify(data+b'x'))
# Publication safety uses the already independently verified bytes.
with tempfile.TemporaryDirectory(prefix='zstdoxide-lazy-frame-projection-') as directory:
 root=Path(directory);target=root/'fresh';packer.publish(files,target)
 need(all((target/name).read_bytes()==raw for name,raw in files.items()),'fresh publish')
 for label,path,contents in [('existing',target,files),('bad_names',root/'bad',{'../outside':b'x'}),('symlink',root/'link',files)]:
  if label=='symlink':path.symlink_to(target,target_is_directory=True)
  reject(label,lambda:packer.publish(contents,path))
 need(not (root/'bad').exists() and not (root/'outside').exists(),'rejected publication unchanged')
need(len(rejected)==23 and not children,'complete control counts')
print(json.dumps({'status':'passed','optimization':sys.flags.optimize,'cases':510,'blocks':1377,'rejections':rejected,'child_attempts':len(children),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},sort_keys=True))
