# Ordinary Fast frame oracle results

The external unchanged v1.5.7 normal frame oracle passed 23 fixed source recipes,
4 additional aligned whole-buffer comparisons, and 11 separately labeled partial
header captures. The main source total is 1,222,674 bytes. Each capture performs
27 complete frame decodes totaling 2,275,346 decoded bytes, plus 11 unfinished
header observations. Normal regeneration and the full-used-C ASan/UBSan capture
produce identical deterministic artifacts. No source recipe changed after the
first capture.

Meaningful raw repeat rollback is observed in 10 of the 12 directed candidates;
the other two are retained as non-witness outcomes. Two RLE cases have pending
first-two repeats different from committed input, yet no publication. Uniform
first blocks are compressed rather than RLE. Tiny six/five-byte blocks remain
raw with stale sequence stores; the intervening seven-byte block has a fresh
store. Window17 A/B/A is raw/raw/raw, whereas window19 is raw/raw/compressed.

The sanitizer build instruments the helper and 26 unchanged upstream C files,
with assembly and leak sanitizer explicitly disabled. This is native arm64 macOS
evidence. Initial runner/strict-warning setup diagnostics and earlier runner
snapshots remain preserved. See evidence.json, each build's build.json and
command records, and each capture's capture.json for exact arguments, hashes,
compiler/target metadata, records, frames, source files and limitations.

No repository files were changed. No process remains running.
