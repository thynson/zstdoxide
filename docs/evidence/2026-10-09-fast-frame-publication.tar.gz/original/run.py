#!/usr/bin/env python3
"""External normal-frame oracle, explicit build/capture/check commands only.

No result is a sequence-collector observation. Generated recipe bytes are pinned
before invoking C. --check compares artifacts without replacing original capture.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
REVISION = "f8745da6ff1ad1e7bab384bd1f9d742439278e99"
REFERENCE = Path("/tmp/zstdoxize-upstream-1.5.7")
MASK = (1 << 32) - 1
ENV_KEYS = ("PATH", "HOME", "TMPDIR", "TMP", "TEMP", "SYSTEMROOT", "SDKROOT",
            "MACOSX_DEPLOYMENT_TARGET", "DEVELOPER_DIR")
INPUT_HASHES = None
HEADERS = [(n, 20) for n in (255, 256, 65791, 65792, (1 << 32)-2, (1 << 32)-1, 1 << 32)]
HEADERS += [(1024, 10), (1025, 10), (1048576, 20), (1048577, 20)]


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    return sha(Path(path).read_bytes())


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()


def write_json(path, value):
    Path(path).write_bytes(canonical(value))


def parse_json(data):
    def pairs(items):
        out = {}
        for key, value in items:
            need(key not in out, f"duplicate JSON key {key}")
            out[key] = value
        return out
    def reject(value):
        raise ValueError(f"non-JSON number {value}")
    return json.loads(data, object_pairs_hook=pairs, parse_constant=reject)


def env():
    selected = {key: os.environ[key] for key in ENV_KEYS if key in os.environ}
    selected.update(LC_ALL="C", LANG="C", TZ="UTC")
    return selected


def source_inputs():
    return {name: file_sha(HERE/name) for name in ('frame_oracle.c', 'run.py', 'DESIGN.md')}


def command(argv, directory, name, environment=None):
    need(INPUT_HASHES == source_inputs(), "helper/runner/design changed before command")
    directory.mkdir(parents=True, exist_ok=True)
    out, err = directory / (name + ".stdout"), directory / (name + ".stderr")
    need(not out.exists() and not err.exists(), f"refusing to overwrite command logs: {name}")
    effective = env() if environment is None else environment
    start = time.monotonic()
    with out.open("wb") as stdout, err.open("wb") as stderr:
        result = subprocess.run([str(x) for x in argv], stdout=stdout, stderr=stderr,
                                env=effective, cwd=HERE, check=False, timeout=120)
    record = dict(argv=[str(x) for x in argv], cwd=str(HERE), env=effective,
                  stdout=out.name, stderr=err.name, exit_code=result.returncode,
                  elapsed_seconds=time.monotonic()-start,
                  stdout_sha256=file_sha(out), stderr_sha256=file_sha(err))
    write_json(directory / (name + ".command.json"), record)
    need(INPUT_HASHES == source_inputs(), "helper/runner/design changed after command")
    need(result.returncode == 0, f"command failed ({result.returncode}): {argv}; logs {out}, {err}")
    return out


def git(reference, *arguments):
    return subprocess.check_output(["git", "-C", str(reference), *arguments], env=env())


def reference_proof(reference):
    need(git(reference, "rev-parse", "HEAD").decode().strip() == REVISION, "wrong pinned revision")
    need(not git(reference, "status", "--porcelain", "--untracked-files=no"), "modified tracked upstream files")
    paths = git(reference, "ls-files", "lib").decode().splitlines()
    hashes = {}
    for relative in paths:
        p = reference / relative
        if p.is_file() and (p.suffix in ('.c', '.h', '.S', '.mk') or p.name == 'Makefile'):
            data = p.read_bytes()
            need(data == git(reference, "show", f"{REVISION}:{relative}"), f"pinned source mismatch: {relative}")
            hashes[relative] = sha(data)
    required = {'lib/compress/zstd_fast.c', 'lib/compress/zstd_compress.c',
                'lib/compress/zstd_compress_internal.h', 'lib/common/zstd_internal.h',
                'lib/common/huf.h', 'lib/common/fse.h', 'lib/zstd.h', 'lib/libzstd.mk'}
    need(required <= set(hashes), "missing required pinned source inputs")
    return dict(revision=REVISION, tracked_clean=True, source_sha256=hashes,
                archive_sha256=file_sha(reference / "lib/libzstd.a"))


def noise(seed, count):
    out = bytearray()
    for _ in range(count):
        seed ^= (seed << 13) & MASK
        seed ^= seed >> 17
        seed ^= (seed << 5) & MASK
        seed &= MASK
        out.append(seed & 255)
    return bytes(out)


def repeated(seed, period, size):
    unit = noise(seed, period)
    return (unit * ((size + period - 1) // period))[:size]


def recipes():
    rows = []
    def add(name, source, schedule, w=19, h=14, m=4, t=0, whole=False):
        need(sum(schedule) == len(source) <= 2 << 20, "recipe size")
        rows.append(dict(id=name, source=source, schedule=schedule, window=w,
                         hash=h, min_match=m, target=t, whole_compare=whole))
    periodic = repeated(0x13579bdf, 257, 4096)
    a, b = noise(0x2468ace1, 131072), noise(0xfedcba91, 131072)
    literals = bytes(x & 7 for x in noise(0x55667789, 4096)) + noise(0x19283745, 1024)
    literals += bytes(x & 7 for x in noise(0x89abcdef, 4096))
    add("empty", b"", [])
    add("first_uniform", bytes([0x5a])*4096, [4096], whole=True)
    add("empty_then_first_uniform", bytes([0x5a])*4096, [0, 4096])
    add("compressed_uniform_repeat", periodic + bytes([0xa6])*4096 + periodic, [4096]*3)
    add("raw_then_copy", a+a, [131072]*2, h=18, whole=True)
    add("mixed_fallback", periodic + noise(0x7654321f,4096) + bytes([0x37])*4096 + periodic, [4096]*4)
    add("tiny_stale", periodic + bytes([0x99])*6 + noise(0x10203041,7) + bytes([0xee])*5 + periodic,
        [4096,6,7,5,4096])
    add("literal_tree", literals, [4096,1024,4096], m=7)
    add("negative_literal_policy", literals, [4096,1024,4096], m=7, t=4)
    add("window_expiry_17", a+b+a, [131072]*3, w=17, h=18, whole=True)
    add("window_retained_19", a+b+a, [131072]*3, w=19, h=18, whole=True)
    for length in (4,8,12):
        for distance in (128,192,256,320):
            middle = bytearray(noise(0xabcdef01,1024))
            middle[distance:distance+length] = middle[32:32+length]
            add(f"raw_candidate_k{length}_d{distance}", periodic+middle+periodic, [4096,1024,4096], h=18)
    need(len(rows) == 23 and len({x['id'] for x in rows}) == 23, "exact unique recipe count")
    return rows


def fingerprint(data):
    h = 0xcbf29ce484222325
    for value in data:
        h = ((h ^ value) * 0x100000001b3) & ((1 << 64)-1)
    return f"{h:016x}"


def key_bucket(source, position, width, log):
    # Independent exact-width integer form of the attributed upstream hash4..7
    # definitions, already frozen in the separate match-search C collection.
    word = int.from_bytes(source[position:position+width], 'little')
    if width == 4:
        return ((word * 2654435761) & MASK) >> (32-log)
    primes = {5: 889523592379, 6: 227718039650203, 7: 58295818150454627}
    return (((word << (8*(8-width))) * primes[width]) & ((1 << 64)-1)) >> (64-log)


def frame_blocks(data):
    need(len(data) >= 6 and data[:4] == bytes.fromhex("28b52ffd"), "frame magic")
    descriptor = data[4]
    single = (descriptor >> 5) & 1
    code = descriptor >> 6
    fcs = single if code == 0 else (2 if code == 1 else 4 if code == 2 else 8)
    need(descriptor & 31 == 0, "unexpected flags")
    cursor = 5 + (not single) + fcs
    out = []
    while True:
        need(cursor + 3 <= len(data), "block header extent")
        word = int.from_bytes(data[cursor:cursor+3], "little")
        kind, field, last = (word >> 1) & 3, word >> 3, word & 1
        need(kind != 3 and field <= 131072, "block kind/size")
        cursor += 3
        size = 1 if kind == 1 else field
        need(cursor + size <= len(data), "block payload extent")
        out.append(dict(kind=kind, field=field, last=last, payload=data[cursor:cursor+size]))
        cursor += size
        if last:
            break
    need(cursor == len(data), "single frame exhaustion")
    return out


def validate_case(row, records, frame):
    source = row['source']
    begins = [r for r in records if r['type'] == 'begin']
    completes = [r for r in records if r['type'] == 'complete']
    blocks = [r for r in records if r['type'] == 'block']
    headers = [r for r in records if r['type'] == 'header']
    zero_calls = [r for r in records if r['type'] == 'zero_continue']
    wholes = [r for r in records if r['type'] == 'whole_compare']
    need(len(begins)==len(completes)==len(headers)==1, "exact begin/header/complete counts")
    need(all(r.get('case')==row['id'] for r in records), "case identity")
    need(set(r['type'] for r in records) <= {'begin','complete','block','header','zero_continue','whole_compare'}, "record types")
    need(len(blocks)==sum(n>0 for n in row['schedule']) and len(zero_calls)==row['schedule'].count(0), "call counts")
    need(len(wholes)==int(row['whole_compare']), "whole comparison count")
    expected = [row['window'],12,row['hash'],1,row['min_match'],row['target'],1]
    need(begins[0]['applied']==expected and begins[0]['source_bytes']==len(source)
         and begins[0]['source_fnv64']==fingerprint(source), "source/applied metadata")
    need(completes[0]['calls']==len(row['schedule']) and completes[0]['decoded_bytes']==len(source)
         and completes[0]['blocks']==len(blocks) and completes[0]['frame_bytes']==len(frame)
         and completes[0]['frame_fnv64']==fingerprint(frame) and completes[0]['terminal_empty_raw'] is True, "completion metadata")
    wire_blocks = frame_blocks(frame)
    need(len(wire_blocks)==len(blocks)+1 and wire_blocks[-1]==dict(kind=0,field=0,last=1,payload=b''), "terminal empty block")
    semantic=[1,4,8]
    replay=bytearray()
    previous_table=[0]*(1 << row['hash'])
    cursor=0
    generation=0
    rollback=[]
    for r,actual in zip(blocks,wire_blocks):
        length=row['schedule'][r['call']]
        need(r['source_start']==cursor and r['source_bytes']==length and r['kind']==actual['kind'] and not actual['last'], "source/wire block mapping")
        need(r['payload_bytes']==len(actual['payload']) and r['payload_fnv64']==fingerprint(actual['payload']), "payload fingerprint")
        need(r['semantic_before']==semantic and r['before']['raw_repeats'][:2]==semantic[:2], "incoming semantic state")
        trial=semantic.copy()
        candidate=r['candidate']
        if length>=7:
            generation+=1
            need(candidate['fresh'] is True, "fresh generation")
            literals=bytes.fromhex(candidate['literal_bytes'])
            need(candidate['literal_count']==len(literals) and candidate['sequence_count']==len(candidate['sequences']), "candidate counts")
            lit_cursor=0
            for ll,ml,off,d in candidate['sequences']:
                need(ll>=0 and ml>=3 and off>0 and ll<=len(literals)-lit_cursor, "sequence fields")
                replay.extend(literals[lit_cursor:lit_cursor+ll]); lit_cursor+=ll
                if off>3:
                    distance=off-3
                    trial=[distance,trial[0],trial[1]]
                else:
                    selector=off-1+(ll==0)
                    if selector==0:
                        distance=trial[0]
                    elif selector==1:
                        distance=trial[1]; trial=[distance,trial[0],trial[2]]
                    else:
                        distance=trial[2] if selector==2 else trial[0]-1
                        trial=[distance,trial[0],trial[1]]
                need(r['window']['dict_limit']>=2, "prefix floor index")
                need(distance==d and 0<d<=len(replay) and d<=1<<row['window']
                     and len(replay)-d>=r['window']['dict_limit']-2
                     and len(replay)+ml<=cursor+length, "sequence distance/extent/window floor")
                for _ in range(ml):
                    replay.append(replay[-d])
            need(len(literals)-lit_cursor==candidate['trailing'], "trailing literal count")
            replay.extend(literals[lit_cursor:])
            need(candidate['semantic_repeats']==trial and r['candidate_state']['raw_repeats'][:2]==trial[:2], "candidate semantic replay")
        else:
            need(candidate=={'fresh':False,'previous_generation':generation} and r['candidate_state'] is None and r['kind']==0, "stale tiny candidate")
            replay.extend(source[cursor:cursor+length])
        need(len(replay)==cursor+length and replay[cursor:]==source[cursor:cursor+length], "exact incremental source reconstruction")
        swapped=r['prev_owner_before']!=r['prev_owner_after']
        need(swapped==(r['kind']==2), "normal publication owner")
        if r['kind']==2:
            semantic=trial
        else:
            need(r['after']['raw_repeats']==r['before']['raw_repeats'], "raw/RLE raw repeats unchanged")
            if r['changed_candidate_first_two']:
                rollback.append(dict(call=r['call'],kind=r['kind']))
        need(r['semantic_after']==semantic and r['after']['raw_repeats'][:2]==semantic[:2], "published semantic triple")
        h=r['hash']
        need(h['entries']==len(previous_table), "hash dimension")
        before_bytes=b''.join(v.to_bytes(4,'little') for v in previous_table)
        need(h['before_fnv64']==fingerprint(before_bytes), "hash before reconstruction")
        indices=[]
        for index,old,new in h['changed']:
            need(0<=index<len(previous_table) and previous_table[index]==old and old!=new, "hash change tuple")
            indices.append(index); previous_table[index]=new
        need(indices==sorted(set(indices)), "unique ordered table changes")
        need(h['after_fnv64']==fingerprint(b''.join(v.to_bytes(4,'little') for v in previous_table)), "hash after reconstruction")
        width=max(4,row['min_match'])
        for index,value in enumerate(previous_table):
            if value:
                need(value>=2 and value-2+width<=cursor+length, "stored logical key extent")
                need(key_bucket(source,value-2,width,row['hash'])==index, "independent stored key bucket")
        cursor+=length
    need(cursor==len(source) and replay==source and completes[0]['candidate_generations']==generation, "complete independent replay")
    return dict(id=row['id'],blocks=[r['kind'] for r in blocks],rollback_witnesses=rollback,
                decoded_bytes=len(source),candidate_generations=generation,whole_compare=row['whole_compare'])


def build(reference, destination, mode, compiler):
    need(not destination.exists(), "build destination must be fresh")
    destination.mkdir(parents=True)
    proof=reference_proof(reference)
    cc=shutil.which(compiler)
    need(cc is not None, "compiler unavailable")
    version=command([cc,'--version'],destination,'compiler-version').read_text()
    target=command([cc,'-dumpmachine'],destination,'compiler-target').read_text()
    command([cc,'-dM','-E','-x','c','/dev/null'],destination,'compiler-predefines')
    common=[cc,'-std=c11','-O2','-g','-I',str(reference/'lib'),'-I',str(reference/'lib/common'),'-I',str(reference/'lib/compress')]
    executable=destination/'frame_oracle'
    if mode=='normal':
        argv=common+['-Wall','-Wextra','-Werror','-Wno-deprecated-declarations',str(HERE/'frame_oracle.c'),str(reference/'lib/libzstd.a'),'-o',str(executable)]
        command(argv,destination,'compile-normal')
        instrumented=[]
    else:
        sources=sorted(p for folder in ('common','compress','decompress') for p in (reference/'lib'/folder).glob('*.c'))
        need(len(sources)>=25, "complete used sanitizer source list")
        flags=['-DZSTD_DISABLE_ASM','-DZSTD_LEGACY_SUPPORT=0','-DXXH_NAMESPACE=ZSTD_',
               '-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer']
        objects=[]
        for index,source in enumerate(sources):
            obj=destination/f'upstream-{index:02d}.o'
            command(common+flags+['-c',str(source),'-o',str(obj)],destination,f'compile-upstream-{index:02d}')
            objects.append(obj)
        command(common+flags+['-Wall','-Wextra','-Werror','-Wno-deprecated-declarations',str(HERE/'frame_oracle.c')]+objects+['-o',str(executable)],destination,'link-sanitized')
        instrumented=[str(p.relative_to(reference)) for p in sources]
    effective_flags = [] if mode=='normal' else flags
    dep=destination/'dependencies.d'
    command(common+effective_flags+['-MM','-MF',str(dep),str(HERE/'frame_oracle.c')],destination,'dependencies')
    command(common+effective_flags+['-dM','-E',str(HERE/'frame_oracle.c')],destination,'effective-predefines')
    dependency_hashes={}
    dependency_text=dep.read_text().replace('\\\n',' ')
    for name in dependency_text.split(':',1)[1].split():
        dependency=Path(name).resolve()
        if dependency==HERE/'frame_oracle.c':
            need(file_sha(dependency)==INPUT_HASHES['frame_oracle.c'], 'helper dependency changed')
        else:
            need(dependency.is_relative_to(reference), 'unexpected non-system dependency')
            relative=str(dependency.relative_to(reference))
            need(relative in proof['source_sha256'] and file_sha(dependency)==proof['source_sha256'][relative],
                 'untracked/changed included reference header')
        dependency_hashes[str(dependency)]=file_sha(dependency)
    need(proof==reference_proof(reference), "reference changed during build")
    evidence=dict(mode=mode,reference=proof,compiler=cc,compiler_sha256=file_sha(cc),compiler_version=version,target=target,
                  leak_sanitizer=False,source_inputs=INPUT_HASHES,
                  helper_sha256=file_sha(HERE/'frame_oracle.c'),runner_sha256=file_sha(__file__),
                  design_sha256=file_sha(HERE/'DESIGN.md'),executable_sha256=file_sha(executable),
                  instrumented_sources=instrumented,dependency_file_sha256=file_sha(dep),dependency_sha256=dependency_hashes,
                  scope='unchanged ordinary frame mode, not sequence collector')
    write_json(destination/'build.json',evidence)


def capture(reference, build_dir, destination):
    need(not destination.exists(), "capture destination must be fresh")
    build_info=parse_json((build_dir/'build.json').read_text())
    need(build_info['helper_sha256']==file_sha(HERE/'frame_oracle.c') and build_info['runner_sha256']==file_sha(__file__), "build source changed")
    need(build_info['reference']==reference_proof(reference), "build reference changed")
    executable=build_dir/'frame_oracle'
    need(build_info['executable_sha256']==file_sha(executable), "executable changed")
    destination.mkdir(parents=True)
    artifacts=destination/'artifacts'; artifacts.mkdir()
    logs=destination/'logs'
    rows=recipes(); envelope=[]
    for row in rows:
        data=row['source']; metadata={k:v for k,v in row.items() if k!='source'}
        metadata.update(source_size=len(data),source_sha256=sha(data))
        source_path=artifacts/(row['id']+'.source'); source_path.write_bytes(data)
        write_json(artifacts/(row['id']+'.recipe.json'),metadata); envelope.append(metadata)
    write_json(artifacts/'recipes.json',envelope)
    initial={p.name:file_sha(p) for p in artifacts.iterdir()}
    observations=[]
    run_env=env()
    if build_info['mode']=='sanitized':
        run_env.update(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for row in rows:
        name=row['id']; output=artifacts/(name+'.zst'); whole=artifacts/(name+'.whole.zst')
        schedule=','.join(str(n) for n in row['schedule']) or '-'
        argv=[executable,'frame',name,artifacts/(name+'.source'),schedule,output,
              whole if row['whole_compare'] else '-',row['window'],row['hash'],row['min_match'],row['target']]
        log=command(argv,logs,name,run_env)
        need(log.stat().st_size<=32<<20, "case record cap")
        records=[parse_json(line) for line in log.read_text().splitlines()]
        summary=validate_case(row,records,output.read_bytes())
        write_json(artifacts/(name+'.records.json'),records)
        observations.append(summary)
    for index,(pledge,window) in enumerate(HEADERS):
        log=command([executable,'header',pledge,window],logs,f'header-{index:02d}',run_env)
        records=[parse_json(line) for line in log.read_text().splitlines()]
        need(len(records)==2 and records[0]['type']=='header' and records[1]['type']=='partial', "partial header records")
        need(records[0]['pledge']==pledge and records[0]['window_log']==window and records[1]['completed_frame'] is False and records[1]['decoded'] is False, "partial header scope")
        need(records[1]['pointer_bits']==64 and records[1]['int_bits']==32, "capture host width scope")
        write_json(artifacts/f'header-{index:02d}.json',records)
    need(all(file_sha(artifacts/name)==value for name,value in initial.items()), "recipe inputs changed during run")
    need(build_info['reference']==reference_proof(reference), "reference changed during capture")
    need(len(observations)==23 and len(HEADERS)==11, "positive exact case count")
    summary=dict(full_frame_cases=len(observations),partial_header_cases=len(HEADERS),
                 decoded_bytes=sum(row['decoded_bytes'] for row in observations),
                 whole_buffer_decodes=sum(row['whole_compare'] for row in observations),cases=observations,
                 qualifications=['candidate outcomes observed; recipes not adapted after capture',
                                 'no FSE valid-tag branch claim without observed valid tag',
                                 'whole-buffer equality only explicitly aligned cases',
                                 'Fast raw repeat cell 2 differs from authoritative semantic triple'])
    write_json(artifacts/'summary.json',summary)
    evidence=dict(build=build_info,host=dict(system=platform.system(),machine=platform.machine()),
                  runner_sha256=file_sha(__file__),helper_sha256=file_sha(HERE/'frame_oracle.c'),
                  artifacts={p.name:dict(size=p.stat().st_size,sha256=file_sha(p)) for p in sorted(artifacts.iterdir())},
                  logs={p.name:dict(size=p.stat().st_size,sha256=file_sha(p)) for p in sorted(logs.iterdir())},summary=summary)
    write_json(destination/'capture.json',evidence)


def compare(original, regenerated):
    left=parse_json((original/'capture.json').read_text())
    right=parse_json((regenerated/'capture.json').read_text())
    for directory,evidence in ((original,left),(regenerated,right)):
        for group in ('artifacts','logs'):
            need(set(evidence[group])=={p.name for p in (directory/group).iterdir()}, "captured file inventory changed")
            for name,item in evidence[group].items():
                path=directory/group/name
                need(path.stat().st_size==item['size'] and file_sha(path)==item['sha256'], "captured artifact hash mismatch")
    need(left['artifacts']==right['artifacts'], "deterministic observations differ")
    need(left['summary']['full_frame_cases']==right['summary']['full_frame_cases']==23
         and left['summary']['partial_header_cases']==right['summary']['partial_header_cases']==11, "complete nonzero comparison")
    print(json.dumps(dict(equal=True,full_frame_cases=23,partial_header_cases=11,
                          original=str(original),regenerated=str(regenerated)),sort_keys=True))


def main():
    global INPUT_HASHES
    INPUT_HASHES = source_inputs()
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference',type=Path,default=REFERENCE)
    sub=parser.add_subparsers(dest='action',required=True)
    b=sub.add_parser('build'); b.add_argument('destination',type=Path); b.add_argument('--mode',choices=('normal','sanitized'),required=True); b.add_argument('--compiler',default='clang')
    c=sub.add_parser('capture'); c.add_argument('build',type=Path); c.add_argument('destination',type=Path)
    v=sub.add_parser('check'); v.add_argument('original',type=Path); v.add_argument('regenerated',type=Path)
    args=parser.parse_args()
    if args.action=='build': build(args.reference.resolve(),args.destination.resolve(),args.mode,args.compiler)
    elif args.action=='capture': capture(args.reference.resolve(),args.build.resolve(),args.destination.resolve())
    else: compare(args.original.resolve(),args.regenerated.resolve())


if __name__=='__main__':
    main()
