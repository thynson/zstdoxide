# Ordinary Fast frame publication oracle: proposed setup

Status: read-only source study and external design draft, 2026-10-09. No helper
has been compiled or executed. Recipe outcomes below are hypotheses until an
unchanged C capture establishes them. This is independent of the direct parser
and deprecated sequence-collector campaigns. No Rust codec is involved.

Reference: facebook/zstd v1.5.7, commit
`f8745da6ff1ad1e7bab384bd1f9d742439278e99`, checkout
`/tmp/zstdoxize-upstream-1.5.7`. The parent design is
`docs/reference-fast-oracle-design.md`; execution admission and entropy scope
are in `docs/reference-fast-design.md`.

## Scope and files

All preparation and eventual execution remain under
`/tmp/zstdoxide-fast-frame-oracle-work`. Proposed files are `frame_oracle.c`,
`run.py`, canonical case envelopes, per-case records, complete frame assets,
source bytes, build/run logs and a hash manifest. These are not a repository
fixture collection until separately approved. The helper links unchanged
pinned code and does not copy/instrument Fast or entropy implementation bodies.

The initial claim is actual normal frame-mode publication for explicit bounded
block schedules. Full whole-buffer comparison is added only for schedules whose
source block boundaries coincide with that API's observed boundaries. The
sequence collector is neither called nor used to infer these results.

## Context initialization

1. Construct a complete `ZSTD_parameters` with seven explicit compression fields
   in `(windowLog, chainLog, hashLog, searchLog, minMatch, targetLength, strategy)`
   order and frame fields `(contentSizeFlag=1, checksumFlag=0, noDictIDFlag=0)`.
   Main record is `(19,12,14,1,4,0,ZSTD_fast)`. Targeted cases explicitly change
   windowLog, hashLog, minMatch or targetLength. All fields pass
   `ZSTD_checkCParams`; fixture limits are window 10..20, hash 6..18, key/minMatch
   3..7 and target 0..131072. These are concrete applied records, not alleged
   unmodified numeric level presets.
2. Use a local `ZSTD_CCtx_params` and the public static API
   `ZSTD_CCtxParams_init_advanced(&params, scalar_and_frame_record)`, preserving
   upstream's resolved defaults (`zstd_compress.c:397–401`). Then use checked
   setters for workers 0, LDM disabled, target compressed block size 0, row
   matchfinder disabled, pre-split level 1, post-split disabled, and maximum
   block size 131072. Literal compression stays auto so a positive targetLength
   exercises the ordinary Fast raw-literal policy. Record every setter result.
   No external sequence producer, dictionary, prefix, CDict, stable-buffer mode,
   or worker configuration is installed.
3. Create a fresh normal CCtx and call the declared private initializer
   `ZSTD_compressBegin_advanced_internal(ctx, NULL, 0, ZSTD_dct_auto,
   ZSTD_dtlm_fast, NULL, &params, full_logical_source_size)`
   (`zstd_compress.c:5285–5300`, declaration in the pinned internal header).
   This unbuffered frame path retains the explicit controls; do not call a later
   public reset/begin that replaces them.
4. Check all seven `ctx->appliedParams.cParams` against the request and its
   match-state copy, all disabled controls, known pledge, dictionary absence,
   sequence collector disabled, first-block flag and stage. Check observed
   `blockSizeMax == min(131072, max(1,min(1<<windowLog, pledge)))`; the initializer
   uses the known pledge in its allocation/block calculation
   (`zstd_compress.c:2131–2138`). Reject an unexpected configuration.
5. Save the two distinct block-state pointers as opaque owner labels A/B. No
   native addresses enter records. Only previous state is initialized by the
   begin path (`:2208`, reset at `:1918–1927`); pending state is unavailable until
   a real candidate initializes it. Do not read initial pending reps, tags,
   CTable headers or array contents. No custom memory initializer or mutation of
   private compressor state is required.

## Source lifetime and pointer bounds

Every case owns one allocation with 64 leading initialized bytes, the complete
logical source (at most 2 MiB), and 262656 trailing initialized bytes
(`131072 + 131072 + 512`). Outer 64-byte source guards are separate from that
permitted prefix/suffix. Source, prefix and suffix stay byte-identical and live
until compression and decode comparisons finish. Logical blocks point directly
into this arena; later blocks use actual following source bytes, not fresh
per-block padding. The full suffix matches the direct oracle's approved cap.

The first nonempty `ZSTD_window_update` establishes base `source - 2`
(`zstd_compress_internal.h:1334–1390`). That pointer is inside our allocation.
Before the first input, upstream's window contains its own static sentinel;
record it as `not_bound`, and never subtract it from the arena or claim it is
source history. After binding, check base by equality with the expected in-arena
address, no dictionary mode, no overflow correction, contiguous nextSrc and
U32-representable indices before index normalization. Ignore the unrelated
initial dictBase sentinel as a source address. Do not form/subtract pointers to
unrelated objects in the helper.

The suffix covers Fast's initial `ip0+step`, adjacent paired probes and
`nextStep=ip0+128`, including an exhausted long-match restart
(`zstd_fast.c:192–265, 331–342, 407–423`). For a block at most 131072 bytes, the
step increases by fewer than 1025, so `target+block+512` exceeds the maximum
paired-probe formation after loop advancement. Prefetch formation adds at most
128 to an in-loop pointer. Leading space covers the `iend-8` expression for the
seven-byte boundary and the first-position/invalid-zero candidate checks.
These are pointer-formation limits, not permission to consume padding as input.

The library owns its ordinary sequence/literal workspace. The helper does not
replace its arrays or write canaries into internal slack. Confirm exposed
`maxNbSeq`, `maxNbLit`, sequence count and literal count before indexing. The
library reserves literals plus WILDCOPY_OVERLENGTH (`zstd_compress.c:2242–2248`)
and candidate capacity through its actual block-size/minMatch setup. Snapshot
only initialized rows and literal bytes, with long lengths decoded via
`ZSTD_getSequenceLength`, never raw 16-bit lengths alone.

## Capacity and output schedule

Use a separately allocated, initialized 2 MiB call-output scratch with 64-byte
outer guards, reused after each record is copied. This intentionally exceeds
raw output bound and avoids capacity-induced early returns during entropy
selection. A conservative candidate upper bound for B<=131072 is
`B + 5 + 4 + 3*FSE_NCOUNTBOUND + ceil((floor(B/3)*89 + 26 + 1)/8) + 32`,
less than 1 MiB: 89 accounts for LL/ML/OF extras 16/16/31 and FSE state bits
9/9/8 per sequence, with terminal states/marker/slack separately. The pinned
constants are in `common/zstd_internal.h:103–117` and `common/fse.h:235`.
Check this arithmetic and scratch capacity before each call. This is not a
benchmark or a tight output-bound claim.

Each positive scheduled input is <= observed blockSizeMax and is passed in one
`ZSTD_compressContinue` call (`zstd_compress.c:4790–4889`). Inspect the first
returned header via `ZSTD_getFrameHeader`, then independently parse the 3-byte
block headers. Require exactly one nonfinal block per positive call, correctly
bounded raw/RLE/compressed payload extent, full call-output exhaustion and
matching regenerated size for raw/RLE. There is no hidden input buffering in
this chosen API. Zero-size Continue is recorded separately and must not be
miscounted as a source block.

Append only produced bytes into a separately bounded full-frame buffer using
checked offsets. Capacity `source_size + 3*(positive_calls+1) +
ZSTD_FRAMEHEADERSIZE_MAX + ZSTD_FRAMECHECKSUMSIZE` is enough once each selected
payload is checked <= its regenerated input (RLE payload 1; raw input length;
compressed must meet the actual normal selection result). If this invariant
fails, fail before append rather than truncate or enlarge silently.

After all source calls, call `ZSTD_compressEnd` with a valid end-of-source pointer
and size zero. Require the explicit last empty raw block (and no checksum in
these cases), all source consumed, completed context and unchanged frame
content-size accounting (`:5338–5379`, `:5410–5428`). The empty-frame case may
instead finish directly from init and records its complete header + empty block.
Complete-frame validation is `ZSTD_findFrameCompressedSize == exact buffer len`,
known content size equals logical length, ordinary `ZSTD_decompress` returns
exact length, and a full byte comparison. A guarded decoded allocation of
`max(source_size,1)` is sufficient; no dictionary is supplied.

## Snapshots and independent semantics

Before a call, capture meaningful committed reps and tags. Pending records carry
per-owner validity flags; the uninitialized initial B owner is unavailable.
After a fresh >=7-byte candidate, the next-before-call owner contains the
candidate even if the compressor swaps it into previous. Capture by stable owner
label, not by assuming the post-call next pointer still denotes that candidate.

For a successful >=7-byte call with the generous capacity above, the normal
entropy path initializes HUF and FSE tags: HUF first copies its previous record
(`zstd_compress_literals.c:148–150`); zero sequences copy previous FSE
(`zstd_compress.c:2950–2953`); nonzero sequences assign each channel tag before
building it (`:2790–2866`). Any actual error terminates capture before reading
candidate entropy. The early successful raw paths after this initialization are
normal gain/compatibility fallback. Assert observed tags are legal enum values.
Do not hash entire native records or unused CTable capacity. Initially/table-none
CTable data is not meaningfully initialized. First version records owner identity
and per-channel repeat tags, plus HUF table log/max symbol and 256 bit widths only
when HUF repeat mode is not none. `HUF_readCTableHeader` unused bytes are excluded.
No claim of FSE table-content equality follows from tags/owners alone.

For every fresh candidate record normalized rows `(LL, ML, offBase, distance)`,
all literal bytes, trailing length, candidate raw parser cells and independent
full wire repeat replay. Use a separate harness semantic triple initially
[1,4,8]. Resolve each explicit offBase or LL-dependent repeat value using checked
scalar code, then compare the candidate sequence reconstruction byte-for-byte
against the actual source prefix/current block. Overlap copies are replayed in
forward order. Require positive distances into already initialized frame bytes,
complete block coverage, and exact stored literal bytes. Publication commits this
semantic triple only for an actual compressed block, and retains it for raw/RLE.

C Fast only updates raw repeat cells 0 and 1 (`zstd_fast.c:370–372`). Compare these
two with candidate semantic replay; record raw cell 2 separately and never equate
it with the full wire third repeat. This also avoids using stale C rep[2] as the
next candidate's semantic input. Record before/after committed and candidate
triples independently.

For positive lengths <7, record `candidate=fresh:false` with a link to the prior
candidate generation (or none), and no new sequence rows, literals or candidate
repeat claim. The source returns before resetting SeqStore/copying candidate
reps (`zstd_compress.c:3273–3281`). Optionally compare only previously known
initialized store counts/content to demonstrate staleness; never read initial
uninitialized `sequences`/`lit` pointers. Tiny post-first uniform input is still
raw because the normal RLE check is bypassed.

Record actual block type, isFirstBlock transition, source offsets, owner labels
before/after, raw repeats, semantic repeats, HUF/FSE tags, initialized HUF widths,
match-window limits/nextToUpdate and canonical hash changes. Hash values are
initialized by the ordinary reset; check/capture exactly `1<<hashLog` U32 entries
as little-endian scalars or digest+sorted changed entries that reconstruct the
final table. Entries 0/1 remain invalid, valid source coordinates are index-2.
Do not call final table changes a chronological probe/store trace. No table
rescaling is expected within these caps; reject any correction instead of
silently normalizing a different trajectory.

Assert previous-owner swaps iff the actual block is compressed; raw/RLE preserve
that owner and committed raw repeats while sampled hash updates may survive
(`zstd_compress.c:4385–4445`). A meaningful rollback witness additionally requires
at least one candidate first-two-repeat value to differ from committed input.
Without that observation it is only a no-swap witness. Always allow/record the
specific committed OF repeat valid->check demotion at :4444–4445 rather than
claiming every metadata byte is immutable. Source inspection indicates that the
no-dictionary Fast campaign cannot create FSE_repeat_valid: reset starts none,
ordinary channel construction chooses none/check, whereas dictionary loading
sets valid (:5044–5058). Therefore this branch remains source-qualified unless
an actual valid state is observed; do not inject a dictionary or fake tag solely
to manufacture it.

## Deterministic candidate recipes (outcomes not yet captured)

Define N(seed,n): U32 x starts at nonzero seed; before every byte perform
`x ^= x<<13; x ^= x>>17; x ^= x<<5` with U32 wrapping, emit x&255. Define
P(seed,period,n) by repeating the first `period` bytes of N(seed,period), with
index starting zero in each listed block. Define U(v,n) as n copies of v.
Concatenation is the exact logical source; no RNG continuation is implicit.
All schedule lengths are literal byte counts. Cases use the main concrete
record above unless an override is stated. Generate source bytes in Python and
save them before C execution; the C helper consumes them rather than inventing
alternate recipes.

| ID | Exact source and Continue schedule | Required or sought observation |
| --- | --- | --- |
| empty | empty, no Continue | complete empty raw frame, no candidate |
| first_uniform | U(0x5a,4096), [4096] | first block is not RLE; observe compressed vs raw |
| empty_then_first_uniform | same source; calls [0,4096] | header-only call does not remove first-block RLE exception |
| compressed_uniform_repeat | P(0x13579bdf,257,4096) + U(0xa6,4096) + same P, [4096,4096,4096] | seek compressed/RLE/compressed and differing candidate rep on the middle block |
| raw_then_copy | A=N(0x2468ace1,131072), source A+A, [131072,131072], hash18 | seek raw then compressed from sampled retained source |
| mixed_fallback | P above + N(0x7654321f,4096) + U(0x37,4096) + P above, [4096]*4 | separate raw/RLE transitions and subsequent compression |
| tiny_stale | P above + U(0x99,6) + N(0x10203041,7) + U(0xee,5) + P above, [4096,6,7,5,4096] | stale after real candidate, seven-byte fresh reset, stale again; tiny raw despite non-first uniform input |
| literal_tree | low3(N(0x55667789,4096)) + N(0x19283745,1024) + low3(N(0x89abcdef,4096)), [4096,1024,4096], minMatch7 | observe enabled HUF tree/tags around fallback; no table reuse claim until captured |
| negative_literal_policy | same as literal_tree, target4 | raw-only literal policy paired with same source; block types are observed, not assumed |
| window_expiry_17 / window_retained_19 | A=N(0x2468ace1,131072), B=N(0xfedcba91,131072), A+B+A, [131072]*3, hash18, window17/19 | record concrete lower-bound/history distinctions; source replay remains exact |

Add a bounded raw-candidate rollback search: prefix P above, then a 1024-byte
N(0xabcdef01,1024) block with a copied range from its own [32,32+k) into [d,d+k),
then P again. Enumerate k in [4,8,12] and d in [128,192,256,320], hash18,
[4096,1024,4096]. These twelve exact candidates seek raw output with a changed
first-two candidate repeat. Keep all outcomes, including non-witness cases; do
not reduce input or alter expected state after Rust exists. If none qualifies,
report that gap and propose one bounded follow-up before freezing observations.

This is initially 23 full-frame recipes (11 listed IDs including two window
variants, plus 12 search recipes). Actual counts and case IDs must be validated
by the runner; never succeed with zero cases. The fixed recipes are candidates,
not an assertion that every desired branch is already covered.

## Whole-buffer and header-only observations

For raw_then_copy and both A/B/A cases, observed block schedules should be full
128 KiB chunks. A fresh context with identical actual params calls
`ZSTD_compress_advanced_internal` on the whole source (`:5459–5473`). Independently
parse/decode it and compare each nonempty block's type/regenerated range/payload
with the scheduled frame, ignoring the last-bit difference and the scheduled
frame's final empty block. Record whether equivalence was established; fail the
comparison witness if boundaries differ instead of claiming generic API parity.
Short-flush recipes explicitly have different whole-buffer boundaries and make
no whole-buffer equivalence claim. A single short-block recipe may also compare
as one nonempty whole-buffer block.

Separate header-only witnesses require no huge source allocation: begin with a
known pledge, then call `ZSTD_compressContinue` with a valid pointer and zero
length to write its public-path frame header (`:4799–4811`). Capture and parse the
complete header, abandon/free the unfinished context, and label it
`header_only:true, completed_frame:false, decoded:false`. Use pledges
[255,256,65791,65792,UINT32_MAX-1,UINT32_MAX,UINT32_MAX+1] with window20, plus
[1024,1025] with window10 and [1048576,1048577] with window20. Check actual
single-segment/window/content-size fields. The C static writer at :4695–4738
switches to eight-byte content size at >=UINT32_MAX, which is intentionally a
separate boundary from the current named Rust header. No whole compress.c
inclusion, static-function copying or completed-frame validity claim is needed.

## Proposed execution and provenance, after setup approval

Compile the external helper with the pinned private headers and original static
library, plus exact macros required to match its build. Capture preprocessor
configuration/header dependencies, compiler version/target, pointer/int widths,
endianness, actual compile argv/env, helper/source/runner/data hashes, library
hash and clean tracked revision before/after. Use the direct-oracle environment
allowlist (PATH/HOME/TMPDIR/TMP/TEMP/SYSTEMROOT/SDKROOT/
MACOSX_DEPLOYMENT_TARGET/DEVELOPER_DIR), LC_ALL=C, LANG=C, TZ=UTC; record every
present value and reject ambient compiler flags rather than inherit them.

Normal oracle first, then an independently built ASan/UBSan helper/library in
this work directory from unchanged source (full used compression/decompression
objects, not merely an instrumented wrapper linked to uninstrumented entropy).
Exact sanitizer scope, assembly choices and diagnostics must be recorded. Build
lists/macros are to be reviewed before running; no sanitizer cleanliness is
claimed now. A source-verified external copy/output directory must leave the
pinned archive and checkout unchanged. Native execution scope is this host only.

Record each recipe's actual case/block/sequence counts, decoded byte count,
source/frame/canonical-record hashes and complete exit status. Preserve all
initial setup/compile/sanitizer diagnostics. A runner rejects missing IDs,
duplicates, malformed counts, unexpected bytes, absent final empty blocks,
partial decodes, source mutation and unexplained tag/owner changes. Subsequent
regeneration compares deterministic records and source/frame bytes separately
from host/compiler evidence; capture is never silently rewritten by --check.
