#!/usr/bin/env python3
"""Bounded adverse-input checks for portable ordinary Fast fixture inspection."""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import runpy
import shutil
import sys
import tempfile
import time

ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize')
PATH=ROOT/'scripts/import_fast_frame_publication.py'
SPEC=importlib.util.spec_from_file_location('frame_importer',PATH)
mod=importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(mod)
s=mod.inspect
collection=mod.COLLECTION
results=[]

def audit(event,args):
    if event in ('subprocess.Popen','os.system','os.posix_spawn','os.posix_spawnp','socket.__new__'):
        raise RuntimeError('offline execution attempted '+event)
sys.addaudithook(audit)

def case(name, callback, rejection=True):
    start=time.monotonic()
    try:
        callback()
    except (ValueError, TypeError, KeyError, IndexError, UnicodeError, json.JSONDecodeError, SystemExit, RuntimeError) as error:
        if not rejection: raise
        if isinstance(error,RuntimeError) and 'offline execution attempted' in str(error): raise
        results.append(dict(name=name,result='rejected',reason=str(error),seconds=time.monotonic()-start))
    else:
        if rejection: raise RuntimeError('negative accepted: '+name)
        results.append(dict(name=name,result='passed',seconds=time.monotonic()-start))

def cli(*args):
    before=sys.argv
    try:
        sys.argv=[str(PATH),*args]
        mod.main()
    finally: sys.argv=before

case('complete_offline_manifest_and_semantic_validation_without_process',lambda:mod.check(collection),False)
raw,packed=s.unpack((collection/'observations.json.gz').read_bytes())
frames=(collection/'frames.bin').read_bytes()
full=s.materialize(packed,frames)
case('deterministic_generated_rust_index',lambda:s.need((collection/'cases.rs').read_bytes()==s.rust_index(packed),'index'),False)
for name,args in [
    ('check_upstream',('--check','--upstream','/missing')),
    ('check_output',('--check','--output','/missing')),
    ('check_sanitize',('--check','--sanitize')),
    ('check_compiler',('--check','--compiler','nonexistent-compiler')),
    ('orphan_output',('--output','/missing')),
    ('orphan_sanitize',('--sanitize',)),
    ('orphan_compiler',('--compiler','nonexistent-compiler')),
    ('upstream_missing_output',('--upstream','/missing'))]:
    case('cli_'+name,lambda args=args:cli(*args))
for name,data in [
    ('empty',b''),('truncated',(collection/'observations.json.gz').read_bytes()[:-1]),
    ('trailing_byte',(collection/'observations.json.gz').read_bytes()+b'0'),
    ('extra_member',(collection/'observations.json.gz').read_bytes()+gzip.compress(b'{}',mtime=0)),
    ('compressed_cap',bytes(s.MAX_COMPRESSED_BYTES+1)),
    ('expanded_cap',gzip.compress(b'0'*(s.MAX_JSON_BYTES+1),mtime=0)),
    ('duplicate_json',gzip.compress(b'{"a":1,"a":2}',mtime=0)),
    ('non_json_nan',gzip.compress(b'{"a":NaN}',mtime=0)),
    ('non_utf8',gzip.compress(b'\xff',mtime=0))]:
    case('gzip_'+name,lambda data=data:s.unpack(data))
for name,value in [('bool_numeric',{'size':True}),('int_boolean',{'fresh':1}),
                   ('float',{'size':1.0}),('negative',{'size':-1}),('uint64_overflow',{'size':1<<64}),
                   ('oversize_array',[0]*300001)]:
    case('scalar_'+name,lambda value=value:s.scalar_types(value))
deep=0
for _ in range(42): deep=[deep]
case('scalar_nesting_depth',lambda:s.scalar_types(deep))

def packed_mutation(change):
    value=copy.deepcopy(packed); change(value); s.materialize(value,frames)
for name,change in [
    ('overlap',lambda v:v['cases'][1]['frame'].update(offset=0)),
    ('gap',lambda v:v['cases'][0]['frame'].update(offset=1)),
    ('negative_size',lambda v:v['cases'][0]['frame'].update(size=-1)),
    ('zero_size',lambda v:v['cases'][0]['frame'].update(size=0)),
    ('oversize',lambda v:v['cases'][0]['frame'].update(size=len(frames)+1)),
    ('bool_offset',lambda v:v['cases'][0]['frame'].update(offset=False)),
    ('bool_size',lambda v:v['cases'][0]['frame'].update(size=True)),
    ('wrong_sha',lambda v:v['cases'][0]['frame'].update(sha256='0'*64)),
    ('missing_frame',lambda v:v['cases'][0].update(frame=None)),
    ('extent_extra_key',lambda v:v['cases'][0]['frame'].update(extra=0))]:
    case('pack_'+name,lambda change=change:packed_mutation(change))
case('pack_trailing',lambda:s.materialize(packed,frames+b'x'))
case('pack_truncated',lambda:s.materialize(packed,frames[:-1]))
case('pack_cap',lambda:s.materialize(packed,bytes((3<<20)+1)))

# Direct semantic mutations reach the inspector independently of the fixed hashes.
row=s.recipes()[1]; original=full['cases'][1]; frame=bytes.fromhex(original['frame_hex'])
def record_mutation(change):
    records=copy.deepcopy(original['records']); change(records)
    s.scalar_types(records); s.validate_record_shapes(records); s.validate_case(row,records,frame)
def block(records): return next(r for r in records if r['type']=='block')
for name,change in [
    ('initial_repeat',lambda r:r[0]['initial_state']['raw_repeats'].__setitem__(0,2)),
    ('initial_pending',lambda r:r[0].update(pending_initialized=True)),
    ('block_limit',lambda r:r[0].update(block_limit=1)),
    ('owner_before',lambda r:block(r).update(prev_owner_before=1)),
    ('pending_validity',lambda r:block(r).update(pending_was_initialized=True)),
    ('first_flag',lambda r:block(r).update(first=0)),
    ('candidate_difference',lambda r:block(r).update(changed_candidate_first_two=not block(r)['changed_candidate_first_two'])),
    ('incoming_repeat',lambda r:block(r)['semantic_before'].__setitem__(1,1)),
    ('candidate_distance',lambda r:block(r)['candidate']['sequences'][0].__setitem__(3,1<<20)),
    ('candidate_trailing',lambda r:block(r)['candidate'].update(trailing=99999)),
    ('candidate_literal',lambda r:block(r)['candidate'].update(literal_bytes='00')),
    ('hash_bucket',lambda r:block(r)['hash']['changed'][0].__setitem__(0,1<<14)),
    ('hash_future_value',lambda r:block(r)['hash']['changed'][0].__setitem__(2,1<<20)),
    ('publication_swap',lambda r:block(r).update(prev_owner_after=block(r)['prev_owner_before'])),
    ('record_extra_key',lambda r:r[0].update(extra=0)),
    ('record_bool_numeric',lambda r:block(r).update(source_bytes=True)),
    ('missing_complete',lambda r:r.pop(-2))]:
    case('semantic_'+name,lambda change=change:record_mutation(change))

with tempfile.TemporaryDirectory(prefix='zstdoxide-fast-frame-negative-',dir='/tmp') as tmp:
    tmp=Path(tmp)
    copied=tmp/'collection'; shutil.copytree(collection,copied)
    original_manifest=(copied/'manifest.json').read_bytes()
    def manifest_mutation(change):
        value=s.parse_json(original_manifest); change(value)
        (copied/'manifest.json').write_bytes(s.canonical(value))
        try: mod.check(copied)
        finally: (copied/'manifest.json').write_bytes(original_manifest)
    for name,change in [
        ('schema_bool',lambda m:m.update(schema_version=True)),
        ('extra_key',lambda m:m.update(extra=0)),
        ('generator_hash',lambda m:m.update(generator_sha256='0'*64)),
        ('importer_hash',lambda m:m.update(importer_sha256='0'*64)),
        ('source_map',lambda m:m['source_sha256'].update({'lib/zstd.h':'0'*64})),
        ('capture',lambda m:m['capture'].update(extra=0)),
        ('support_hash',lambda m:m['repository_input_sha256'].update({'scripts/oracles/fast_frame_publication_support.py':'0'*64})),
        ('fixture_escape',lambda m:m['fixtures'][0].update(path='../outside')),
        ('bool_size',lambda m:m['fixtures'][0].update(size=True))]:
        case('manifest_'+name,lambda change=change:manifest_mutation(change))
    case('duplicate_manifest_json',lambda:s.parse_json(b'{"schema_version":1,"schema_version":1}'))
    case('path_parent_escape',lambda:mod.checked_path(copied,'../../etc/passwd'))
    case('path_absolute',lambda:mod.checked_path(copied,'/etc/passwd'))
    link=copied/'link'; link.symlink_to(copied/'frames.bin')
    case('path_symlink',lambda:mod.checked_path(copied,'link'))
    for name,out in [('repository',ROOT/'uncreated-frame-output'),('reference',Path('/tmp/zstdoxize-upstream-1.5.7')/'uncreated-output'),('collection',copied/'uncreated-output'),('existing',tmp),('ancestor',Path('/tmp'))]:
        case('output_'+name,lambda out=out:mod.regenerate(copied,Path('/tmp/zstdoxize-upstream-1.5.7'),out,False,'nonexistent-compiler',full))
        if name!='existing':
            s.need(not out.exists() or name=='ancestor','protected output created')

summary=dict(result='passed',optimized=not __debug__,cases=len(results),positive=sum(r['result']=='passed' for r in results),rejections=sum(r['result']=='rejected' for r in results),records=results,
             source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [PATH,ROOT/'scripts/oracles/fast_frame_publication_support.py',ROOT/'scripts/oracles/fast_frame_publication_live.py']})
output=Path(sys.argv[1]); output.write_bytes(s.canonical(summary))
print(json.dumps({k:v for k,v in summary.items() if k not in ('records','source_sha256')},sort_keys=True))
