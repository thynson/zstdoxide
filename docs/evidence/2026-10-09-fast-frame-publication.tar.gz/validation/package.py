from pathlib import Path
import gzip,hashlib,io,json,sys,tarfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize'); RUN=Path('/tmp/zstdoxide-fast-frame-portable-replay'); OLD=Path('/tmp/zstdoxide-fast-frame-oracle-work')
OUT=Path('/tmp/zstdoxide-fast-frame-portable-evidence.json'); ARCHIVE=Path('/tmp/zstdoxide-fast-frame-portable-evidence.tar.gz')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_bytes())
owned=[ROOT/'scripts/import_fast_frame_publication.py', ROOT/'scripts/oracles/fast_frame_publication_support.py',ROOT/'scripts/oracles/fast_frame_publication_live.py',*sorted((ROOT/'tests/upstream/fast-frame-publication').iterdir())]
owned=[p for p in owned if p.is_file()]
report=load(RUN/'regeneration.json')
assert report['result']=='passed' and report['saved_fixture_before']==report['saved_fixture_after']
negative=[load(Path('/tmp/zstdoxide-fast-frame-portable-negative-'+mode+'.json')) for mode in ('normal','optimized')]
assert all(x['cases']==74 and x['positive']==2 and x['rejections']==72 and x['result']=='passed' for x in negative)
files={}
def add(p,name):
    assert p.is_file() and not p.is_symlink()
    assert name not in files
    files[name]=p
for p in owned: add(p,'repository/'+str(p.relative_to(ROOT)))
for p in sorted(RUN.rglob('*')):
    rel=p.relative_to(RUN)
    if not p.is_file() or 'artifacts' in rel.parts or 'objects' in rel.parts or any(s.endswith('.dSYM') for s in rel.parts): continue
    if p.suffix not in ('.json','.stdout','.stderr','.d'): continue
    add(p,'portable-run/'+str(rel))
for name in ('DESIGN.md','run.py','evidence.json','RESULTS.md'):
    add(OLD/name,'original/'+name)
for p in sorted((OLD/'initial-diagnostics').iterdir()):
    if p.is_file(): add(p,'original/initial-diagnostics/'+p.name)
for mode in ('normal','optimized'):
    for ext in ('json','log'): add(Path('/tmp/zstdoxide-fast-frame-portable-negative-'+mode+'.'+ext),'validation/negative-'+mode+'.'+ext)
for name in ('portable-offline-first.log','portable-offline-final.log','portable-offline-optimized.log','portable-regeneration.log'):
    add(OLD/name,'validation/'+name)
add(Path('/tmp/zstdoxide-fast-frame-portable-negative.py'),'validation/negative.py')
add(Path(__file__),'validation/package.py')
commands=[]
for p in sorted(RUN.rglob('*.command.json')):
    row=load(p); commands.append({'path':str(p.relative_to(RUN)),'sha256':sha(p),'exit':row.get('exit_code',row.get('exit'))})
summary={
 'result':'passed','scope':'Portable unchanged ordinary Fast fixture collection; no production implementation changes',
 'python':sys.version,'owned_source_sha256':{str(p.relative_to(ROOT)):sha(p) for p in owned},
 'commands':[
 {'argv':['python3','scripts/import_fast_frame_publication.py','--check'],'exit':0,'log':'validation/portable-offline-final.log'},
 {'argv':['python3','-O','scripts/import_fast_frame_publication.py','--check'],'exit':0,'log':'validation/portable-offline-optimized.log'},
 {'argv':['python3','scripts/import_fast_frame_publication.py','--upstream','/tmp/zstdoxize-upstream-1.5.7','--output','/tmp/zstdoxide-fast-frame-portable-replay','--sanitize'],'exit':0,'log':'validation/portable-regeneration.log'},
 *[{'argv':['python3',*(['-O'] if mode=='optimized' else []),'/tmp/zstdoxide-fast-frame-portable-negative.py','/tmp/zstdoxide-fast-frame-portable-negative-'+mode+'.json'],'exit':0,'log':'validation/negative-'+mode+'.log'} for mode in ('normal','optimized')]],
 'C_command_records':commands,'regeneration_sha256':sha(RUN/'regeneration.json'),'comparisons':report['comparisons'],
 'negative_checks':{'per_mode':74,'positive_per_mode':2,'rejected_per_mode':72,'total':148,'optimization_modes':[False,True],'offline_process_attempts':0},
 'saved_fixtures_unchanged':True,'original_initial_setup_diagnostics_preserved':True,
 'qualifications':['27 complete frames and 11 abandoned partial headers per capture; no completed huge-input frame claim.',
 'Python checks candidates, tables, raw/RLE payloads and frame structure; saved compressed-block bytes are bound to actual C decoding, not independently decoded in Python.',
 'Sanitizer instruments unchanged helper plus 26 used upstream C translation units; assembly and LeakSanitizer are disabled.',
 'Native arm64 macOS capture, pointer64/int32; no native32 execution claim. Only pointer-width observation is excluded from cross-host record equality.',
 'Executables, debug bundles, object files and duplicate regenerable artifact/source buffers are excluded from this archive; their build/capture hashes remain recorded.',
 'Rust Cargo decoding of the binary frame pack is a separate next work item; not yet run.'],
 'archive_files':{name:{'size':p.stat().st_size,'sha256':sha(p)} for name,p in files.items()}}
OUT.write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
with ARCHIVE.open('wb') as dest, gzip.GzipFile(fileobj=dest,mode='wb',mtime=0,filename='') as compressed, tarfile.open(fileobj=compressed,mode='w|') as tar:
    for name,p in sorted({**files,'evidence.json':OUT}.items()):
        data=p.read_bytes(); info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0
        tar.addfile(info,io.BytesIO(data))
print(json.dumps({'evidence':str(OUT),'evidence_sha256':sha(OUT),'archive':str(ARCHIVE),'archive_sha256':sha(ARCHIVE),'archive_bytes':ARCHIVE.stat().st_size,'files':len(files)+1,'C_commands':len(commands)},sort_keys=True))
