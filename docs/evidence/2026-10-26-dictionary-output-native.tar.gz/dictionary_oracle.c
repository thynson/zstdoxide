/* Test-only pinned facebook/zstd v1.5.7 fixed dictionary destination oracle. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "zstd_errors.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char* read_file(char const* path, size_t* size) {
    FILE* f = fopen(path, "rb");
    if (!f || fseek(f, 0, SEEK_END)) exit(2);
    long n = ftell(f);
    if (n < 0 || n > 4 * 1024 * 1024 || fseek(f, 0, SEEK_SET)) exit(2);
    *size = (size_t)n;
    unsigned char* data = malloc(*size ? *size : 1);
    if (!data || fread(data, 1, *size, f) != *size || fclose(f)) exit(2);
    return data;
}
int main(int argc, char** argv) {
    if (argc != 6) return 2;
    char* end = NULL; errno = 0;
    unsigned long long n = strtoull(argv[3], &end, 10);
    if (errno || !end || end == argv[3] || *end || n > 16 * 1024 * 1024) return 2;
    size_t capacity = (size_t)n, source_size, dictionary_size;
    unsigned char* source = read_file(argv[1], &source_size);
    unsigned char* dictionary = read_file(argv[2], &dictionary_size);
    unsigned char* storage = malloc(capacity + 64);
    if (!storage) return 2;
    memset(storage, 0xa5, capacity + 64);
    ZSTD_DCtx* ctx = ZSTD_createDCtx();
    if (!ctx) return 2;
    size_t result;
    if (!strcmp(argv[5], "prepared")) {
        ZSTD_DDict* ddict = ZSTD_createDDict(dictionary, dictionary_size);
        if (!ddict) return 2;
        result = ZSTD_decompress_usingDDict(ctx, storage + 32, capacity, source, source_size, ddict);
        ZSTD_freeDDict(ddict);
    } else if (!strcmp(argv[5], "using-dict")) {
        result = ZSTD_decompress_usingDict(ctx, storage + 32, capacity, source, source_size, dictionary, dictionary_size);
    } else return 2;
    unsigned error = ZSTD_isError(result), guards = 1, suffix = 1;
    for (size_t i = 0; i < 32; ++i) {
        if (storage[i] != 0xa5 || storage[32 + capacity + i] != 0xa5) guards = 0;
    }
    if (!error) {
        if (result > capacity) return 3;
        for (size_t i = result; i < capacity; ++i) if (storage[32+i] != 0xa5) suffix = 0;
    }
    FILE* f = fopen(argv[4], "wb");
    if (!f || (!error && fwrite(storage + 32, 1, result, f) != result) || fclose(f)) return 2;
    printf("{\"version\":%u,\"error\":%u,\"error_code\":%u,\"written\":%zu,\"guards\":%u,\"suffix\":%u}\n", ZSTD_versionNumber(), error, (unsigned)ZSTD_getErrorCode(result), error ? 0 : result, guards, suffix);
    ZSTD_freeDCtx(ctx);free(source);free(dictionary);free(storage);
    return guards && suffix ? 0 : 3;
}
