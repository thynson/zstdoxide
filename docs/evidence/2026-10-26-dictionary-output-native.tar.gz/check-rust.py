from pathlib import Path
import hashlib,json,shutil,subprocess,time,os
D=Path(__file__).parent;R=Path('/private/tmp/module25-candidate');S=D/'rust-source';S.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
n=json.loads((D/'native.json').read_text());assert n['status']=='passed' and len(n['results'])==476
for folder in ['src','test-support','benches']:shutil.copytree(R/folder,S/folder)
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(R/name,S/name)
(S/'tests').mkdir();shutil.copyfile(D/'rust/dictionary_output_native.rs',S/'tests/dictionary_output_native.rs')
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()}
e=dict(status='running',source=source,native_sha256=sha(D/'native.json'),common_cases=119,calls_per_backend=238,commands=[])
def save():(D/'rust.json').write_text(json.dumps(e,indent=2)+'\n')
env={**os.environ,'CARGO_TARGET_DIR':str(D/'rust-target'),'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','ZSTDOXIDE_DICTIONARY_NATIVE_STAGE':str(D)}
save()
try:
 for name,flags in [('safe',[]),('slice',['--features','unsafe-slice-history']),('dictionary',['--features','unsafe-dictionary']),('both',['--features','unsafe-slice-history,unsafe-dictionary']),('all',['--all-features'])]:
  args=['cargo','test','--offline','--locked','--release','--test','dictionary_output_native',*flags,'--','--ignored','--exact','pinned_native_dictionary_destinations_and_guarded_errors','--nocapture'];t=time.monotonic()
  with (D/('rust-'+name+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t));save();print(name,p.returncode,flush=True);assert p.returncode==0,name
  assert '238 dictionary destination calls' in (D/('rust-'+name+'.log')).read_text()
 for name,h in source.items():assert sha(S/name)==h,name
 for name,h in source.items():
  if name.startswith('src/'):assert sha(R/name)==h,name
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
