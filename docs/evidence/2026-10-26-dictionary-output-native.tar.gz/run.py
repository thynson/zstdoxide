from pathlib import Path
import json,hashlib,shutil,subprocess
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');F=R/'tests/upstream/dictionaries';I=D/'inputs';I.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
j=json.loads((F/'manifest.json').read_text());b=json.loads((D/'build.json').read_text());assert b['status']=='passed'
for row in j['fixtures']:assert sha(F/row['path'])==row['sha256'],row['path']
valid=[]
for row in j['fixtures']:
 if row.get('dictionary') and row.get('expected_output') and row['path'].endswith('.zst'):
  name=row['path'][:-4]
  boundary=next((q for q in j['boundary_cases'] if q['name']==name),None)
  if boundary and boundary['rust_expectation']!='accept':continue
  valid.append((name,(F/row['path']).read_bytes(),(F/row['dictionary']).read_bytes(),(F/row['expected_output']).read_bytes()))
valid += [('http-dictionary',(R/'tests/upstream/data/generated/http-dictionary.zst').read_bytes(),(R/'tests/upstream/data/golden-dictionaries/http-dict-missing-symbols').read_bytes(),(R/'tests/upstream/data/golden-compression/http').read_bytes()),('empty',bytes.fromhex('28b52ffd2000010000'),(F/'formatted.dict').read_bytes(),b''),('skip',bytes.fromhex('5f2a4d1803000000010203'),(F/'formatted.dict').read_bytes(),b'')]
assert len({n for n,_,_,_ in valid})==len(valid)
cases=[]
def add(name,frame,dictionary,expected,capacity,native,rust):
 for suffix,data in [('zst',frame),('dict',dictionary),('raw',expected)]:
  p=I/(name+'.'+suffix)
  if p.exists():assert p.read_bytes()==data
  else:p.write_bytes(data)
 cases.append(dict(name=name,capacity=capacity,native=native,rust=rust))
for name,frame,dictionary,expected in valid:
 for capacity in sorted({0,max(0,len(expected)-1),len(expected),len(expected)+17}):add(name,frame,dictionary,expected,capacity,'ok' if capacity>=len(expected) else 'small','ok' if capacity>=len(expected) else 'limit')
 if len(expected):add(name+'-truncated',frame[:-1],dictionary,b'',len(expected)+17,'error','error')
 if frame[4]&4:
  changed=bytearray(frame);changed[-1]^=128;add(name+'-checksum',changed,dictionary,b'',len(expected)+17,'checksum','checksum')
for name,rust,native in [('p-window-plus-one','corrupt','ok'),('dictionary-out-of-bounds','corrupt','error')]:add(name,(F/(name+'.zst')).read_bytes(),(F/'boundary-dictionary.raw').read_bytes(),(F/(name+'.expected')).read_bytes(),8192,native,rust)
add('wrong-id',(F/'formatted-id.zst').read_bytes(),(F/'boundary-dictionary.raw').read_bytes(),b'',8192,'dictionary','dictionary')
(D/'cases.json').write_text(json.dumps(cases,indent=2)+'\n');(D/'rust-cases.tsv').write_text(''.join(f"{r['name']}\t{r['capacity']}\t{r['rust']}\n" for r in cases))
e=dict(status='running',build_sha256=sha(D/'build.json'),cases_sha256=sha(D/'cases.json'),inputs={p.name:sha(p) for p in I.iterdir()},valid_frames=len(valid),common_cases=len(cases),results=[])
def save():(D/'native.json').write_text(json.dumps(e,indent=2)+'\n')
assert not (D/'native.json').exists();save()
try:
 for backend in ['normal','sanitized']:
  assert sha(D/('oracle-'+backend))==b['executables'][backend]
  for mode in ['prepared','using-dict']:
   O=D/(backend+'-'+mode);O.mkdir()
   for index,case in enumerate(cases):
    name=case['name'];args=[str(D/('oracle-'+backend)),str(I/(name+'.zst')),str(I/(name+'.dict')),str(case['capacity']),str(O/(str(index)+'.bin')),mode]
    p=subprocess.run(args,capture_output=True,timeout=30);(O/(str(index)+'.stdout')).write_bytes(p.stdout);(O/(str(index)+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(backend,mode,index,p.stderr)
    result=json.loads(p.stdout);assert result['version']==10507 and result['guards']==result['suffix']==1
    expect=case['native']
    if expect=='ok':assert not result['error'] and (O/(str(index)+'.bin')).read_bytes()==(I/(name+'.raw')).read_bytes(),(backend,mode,index,result)
    else:
     assert result['error'],(backend,mode,index,result)
     if expect in ['small','checksum','dictionary']:assert result['error_code']=={'small':70,'checksum':22,'dictionary':32}[expect],(backend,mode,index,result)
    e['results'].append(dict(backend=backend,mode=mode,index=index,case=case,result=result,output_sha256=sha(O/(str(index)+'.bin'))));save()
   print(backend,mode,len(cases),'cases passed',flush=True)
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
