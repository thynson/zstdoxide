from pathlib import Path
import sys,json,subprocess,datetime,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from benchmark_ultra_frequencies import environment
P=Path('/private/tmp/zstdoxide-ultra-frequency-benchmark-prepared-1016');prior=json.loads((P/'evidence.json').read_text());env=environment()
if env!=prior['environment']:raise ValueError('measurement environment differs from preparation')
barriers=[Path('/tmp/zstdoxide-ultra-frequency-'+name+'-1016/evidence.json')for name in ['matrix','platform','thumb']]
for p in barriers:
 d=json.loads(p.read_text())
 if d['status']!='passed' or not d['source_unchanged']:raise ValueError('incomplete worker '+str(p))
O=Path('/private/tmp/zstdoxide-ultra-frequency-timing-wrapper-1016');O.mkdir();records=[]
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
report=dict(status='running',started_at=utc(),environment=env,barriers=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in barriers],commands=records,qualification='Both campaigns run sequentially after all known correctness workers complete. No concurrent task-owned native/model/archive job is launched during this wrapper. General host idle state is not claimed.')
def save():(O/'evidence.json').write_text(json.dumps(report,indent=2)+'\n')
save()
try:
 for name,extra in [('timed',[]),('repeat',['--repeat'])]:
  output=Path('/private/tmp/zstdoxide-ultra-frequency-benchmark-'+name+'-1016');argv=['python3','-B','scripts/benchmark_ultra_frequencies.py','measure',str(output),'--prepared',str(P),*extra]
  for p in barriers:argv+=['--barrier',str(p)]
  log=O/(name+'.log');record=dict(argv=argv,started_at=utc(),log=log.name);print('START',name,flush=True)
  with log.open('w')as f:r=subprocess.run(argv,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=600)
  record.update(exit_code=r.returncode,completed_at=utc(),sha256=hashlib.sha256(log.read_bytes()).hexdigest());records.append(record);save()
  if r.returncode:raise ValueError(name)
  print('END',name,flush=True)
 report.update(status='passed',completed_at=utc());save()
except BaseException as error:report.update(status='failed',error=repr(error),completed_at=utc());save();raise
