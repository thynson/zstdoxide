from pathlib import Path
import sys,json,hashlib,statistics,math
R=Path.cwd();sys.path.insert(0,str(R/'scripts'))
from check_ultra_frequency_benchmark import expectations,parse,check
expected=expectations();summary={};campaigns={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P=Path('/private/tmp/zstdoxide-ultra-frequency-benchmark-prepared-1016');prior=json.loads((P/'evidence.json').read_text())
for path,digest in prior['source'].items():
 if sha(R/path)!=digest:raise ValueError('measured source modified '+path)
for b in prior['binaries']:
 if sha(P/b['path'])!=b['sha256']:raise ValueError('binary modified')
for campaign,labels in [('timed',['safe','frequencies','all']),('repeat',['all','safe'])]:
 root=Path('/private/tmp/zstdoxide-ultra-frequency-benchmark-'+campaign+'-1016');doc=json.loads((root/'evidence.json').read_text())
 if doc['status']!='passed' or not doc['source_unchanged'] or doc['source']!=prior['source'] or doc['prepared_evidence_sha256']!=sha(P/'evidence.json'):raise ValueError('campaign source chain')
 if [r['label']for r in doc['commands']]!=labels:raise ValueError('backend order')
 result={}
 for row in doc['commands']:
  if row['exit_code']or any(sha(root/row[k])!=row[k+'_sha256']for k in ['stdout','stderr'])or(root/row['stderr']).read_bytes():raise ValueError('raw logs')
  samples=check(parse((root/row['stdout']).read_bytes()),expected,row['label']!='safe',True)
  result[row['label']]={case['name']:statistics.median(r['nanoseconds']/r['iterations']for r in samples if r['name']==case['name'])for case in expected}
 campaigns[campaign]=result
rows=[]
for case in expected:
 name=case['name'];a=campaigns['timed'];b=campaigns['repeat'];rows.append(dict(name=name,policy=case['policy'],safe_ns=a['safe'][name],frequency_over_safe=a['frequencies'][name]/a['safe'][name],all_over_safe=a['all'][name]/a['safe'][name],repeat_all_over_safe=b['all'][name]/b['safe'][name]))
ratios={key:math.exp(statistics.mean(math.log(r[key])for r in rows))for key in ['frequency_over_safe','all_over_safe','repeat_all_over_safe']}
report=dict(status='passed',case_backend_runs=60,samples=540,rows=rows,geometric_mean_ratios=ratios,qualification='Equal-case geometric mean of ratios of median whole-lifecycle latency. Samples include allocation, final-state copies and drop. These local results do not establish general compression throughput or a universal unsafe speedup.')
Path('/tmp/ultra-frequency-timing-analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(ratios)
