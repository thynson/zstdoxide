from pathlib import Path
import sys,json
sys.path.insert(0,str(Path.cwd()/'scripts'))
from check_ultra_frequency_benchmark import expectations,parse,check
expected=expectations();records=[]
for campaign,names in [('timed',['safe','frequencies','all']),('repeat',['all','safe'])]:
 for name in names:
  p=Path('/private/tmp/zstdoxide-ultra-frequency-benchmark-'+campaign+'-1016')/(name+'.stdout');samples=check(parse(p.read_bytes()),expected,name!='safe',True);records.append(dict(campaign=campaign,backend=name,samples=len(samples)))
print(json.dumps(dict(status='passed',optimized=not __debug__,records=records),indent=2))
