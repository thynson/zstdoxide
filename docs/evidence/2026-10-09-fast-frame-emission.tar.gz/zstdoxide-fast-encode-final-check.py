import hashlib,io,json,os,pathlib,re,subprocess,tarfile,time
root=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize')
revision=os.environ['FAST_BASE_REVISION']
snapshot=pathlib.Path('/tmp/zstdoxide-fast-encode-final-snapshot-v2')
snapshot.mkdir()
paths=['src','tests','test-support','scripts','benches','Cargo.toml','Cargo.lock','rust-toolchain.toml','AGENTS.md']
archive=subprocess.check_output(['git','archive',revision,*paths],cwd=root)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(snapshot,filter='data')
overlays=json.loads(os.environ['FAST_OVERLAYS'])
for name in overlays:
 target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/name).read_bytes())
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def manifest():return {str(p.relative_to(snapshot)):sha(p) for p in sorted(snapshot.rglob('*')) if p.is_file()}
source_manifest=manifest()
features='unsafe-byte-cursor,unsafe-bitstream,unsafe-history,unsafe-ring-history,unsafe-fse,unsafe-fse-encoder,unsafe-huffman,unsafe-huffman-codebook,unsafe-match-table,unsafe-match-chain,unsafe-dictionary,unsafe-training'
checks=[]
for name,flags in [('safe',[]),('match-table',['--features','unsafe-match-table']),('bitstream',['--features','unsafe-bitstream']),('fse-encoder',['--features','unsafe-fse-encoder']),('codebook',['--features','unsafe-huffman-codebook']),('all',['--all-features']),('no-std-safe',['--no-default-features']),('no-std-all',['--no-default-features','--features',features])]:
 checks.append(('wrapper-'+name,['cargo','+nightly-2026-10-08','test','--lib','fast_encode::tests',*flags,'--','--nocapture'],9,{}))
for name,flags in [('safe',[]),('all',['--all-features'])]:
 checks.append(('defaults-'+name,['cargo','+nightly-2026-10-08','test','--release','--test','match_search_defaults',*flags],7,{}))
 checks.append(('clippy-'+name,['cargo','+nightly-2026-10-08','clippy','--all-targets',*flags,'--','-D','warnings'],None,{}))
checks.extend([
 ('no-std-check-safe',['cargo','+nightly-2026-10-08','check','--no-default-features'],None,{}),
 ('no-std-check-all',['cargo','+nightly-2026-10-08','check','--no-default-features','--features',features],None,{}),
 ('format',['rustfmt','+nightly-2026-10-08','--edition','2024','--check','src/fast_encode.rs'],None,{})])
for name in ['invalid_admission_and_schedules_preserve_armed_allocators','failed_output_reservation_preserves_bytes_and_committed_repeats_then_poisoned','exact_workspace_owners_and_borrowed_nonclone_result_release_independently']:
 checks.append(('miri-'+name,['python3','scripts/check_miri_filter.py','--all-features','--lib','fast_encode::tests::'+name,'--','--exact','--nocapture'],1,{'MIRIFLAGS':'-Zmiri-strict-provenance'}))
env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/zstdoxide-fast-encode-final-target'
result={'base_revision':revision,'snapshot':str(snapshot),'copied_overrides':overlays,'source_sha256':sha(snapshot/'src/fast_encode.rs'),'overlay_sha256':{name:sha(snapshot/name) for name in overlays},'source_manifest':source_manifest,'target_dir':env['CARGO_TARGET_DIR'],'compiler':subprocess.check_output(['rustc','+nightly-2026-10-08','-vV'],cwd=snapshot,text=True),'commands':[],'miri_scope':'Host strict-provenance interpretation of three bounded exact selectors; no large-window or allocation-ordinal campaign under Miri; no native foreign execution.'}
out=pathlib.Path('/tmp/zstdoxide-fast-encode-final-evidence.json')
def save():out.write_text(json.dumps(result,indent=2)+'\n')
save()
for name,command,count,extra in checks:
 log=pathlib.Path('/tmp/zstdoxide-fast-encode-final-'+name+'.log');start=time.monotonic()
 with log.open('w') as f:p=subprocess.run(command,cwd=snapshot,env=env|extra,stdout=f,stderr=subprocess.STDOUT)
 summaries=[{'passed':int(a),'failed':int(b),'ignored':int(c)} for a,b,c in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text())]
 result['commands'].append({'name':name,'command':command,'cwd':str(snapshot),'environment':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']}|extra,'exit_code':p.returncode,'seconds':time.monotonic()-start,'log':str(log),'sha256':sha(log),'summaries':summaries})
 save();print(name,p.returncode,summaries,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 if count is not None and sum(v['passed'] for v in summaries)!=count:raise SystemExit('unexpected passing count')
result['source_unchanged']=manifest()==source_manifest
result['workspace_owned_source_unchanged']=sha(root/'src/fast_encode.rs')==result['source_sha256']
if not result['source_unchanged'] or not result['workspace_owned_source_unchanged']:raise SystemExit('source changed')
result['result']='passed';save()
