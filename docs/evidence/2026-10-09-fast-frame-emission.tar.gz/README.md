# Private whole-buffer Fast emission validation

The final original evidence, runner and all eighteen logs are preserved without
rewriting command paths, source hashes or results. The full source manifest is
included separately. This archive contains evidence text only: no compiled
binaries, build artifacts, fixture payloads, codec or C source copies.

Eight configurations each ran nine focused tests (72 passes), two release
default-regression runs add fourteen, and three exact strict-provenance host
Miri selectors add three: 89 passes, zero failures, zero ignored. The remaining
commands check strict Clippy, no_std compilation and owned-file formatting.
The private wrapper is cfg(test) until public admission APIs are integrated.
Its no_std unit runs cover the new path; cargo check covers the production
crate at this checkpoint. No C execution, entropy byte identity, public Fast
API availability or performance claim is made here. Miri is interpretation
on the host, not native foreign execution.

All nine test bodies include real Rust round trips. They exercise empty/tiny,
uniform-first/subsequent RLE, raw then copy, mixed compressed/raw/RLE blocks,
128KiB versus larger windows, unchanged-output failed reservation, invalid
schedules, exact owners and borrowed non-Clone allocator lifetimes. The bounded
complete-frame ordinal sweep is a native test, not part of Miri. Broader later
workspace-growth and independent C decode campaigns belong to the public API
checkpoint.

Initial diagnostics are not part of the final aggregate. The first native run
had eight successes and one incorrect assertion that distance-one Repeat1 must
change the initial triple; only the assertion was fixed. A preliminary frozen
run then passed all eight configurations and safe defaults but strict Clippy
found the coordinator's state test module preceding its implementation. That
module was moved without changing production or test bodies. Its complete
partial evidence/logs/runner are preserved. The final fresh snapshot reran all
checks against the corrected dependency.

Historical runners use absolute temporary paths and create new snapshots. For
reproduction choose fresh paths, materialize the recorded base plus listed
overlays from their implementation commits, and verify all recorded hashes
before running the commands. The source/request borrow never escapes the
returned output, whose allocator is the original caller-supplied value.
