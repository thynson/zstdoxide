"""Promote the qualified Module37 full feature/release matrix."""
from pathlib import Path
import json, hashlib, subprocess, shutil, re

D = Path(__file__).parent
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
name = '2026-11-03-compiled-dictionary-feature-matrix'
p = D / (name + '.json')
r = json.loads(p.read_text())
assert r['status'] == 'passed' and sha(D / r['archive']) == r['archive_sha256']
changed = []
for q in [p, D / r['archive']]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
    changed.append('docs/evidence/' + q.name)
p = R / 'TODO.md'
s = p.read_text()
task = '- [ ] Qualify safe, every isolated feature/all features, release, no_std and strict Clippy.'
assert s.count(task) == 1
s = s.replace(task, task.replace('[ ]', '[x]'))
p.write_text(s)
changed.append('TODO.md')
p = R / 'docs/prepared-dictionary-validation.md'
s = p.read_text()
old = '''Remaining Module 37 items are the full feature and release matrix, timing with
CPU barriers, and final reconciliation.'''
assert s.count(old) == 1
s = s.replace(old, '''## Complete feature and release regression

All 75 commands pass on the frozen Module37 source: safe/all and every one of
the 22 isolated unsafe features run the complete test suite, true no_std
compilation and strict Clippy; safe/all release and formatting also pass. Each
complete/release suite reports 123 result groups, 1832 passed and 78 ignored
with zero failures; ignored tests are not credited. The benchmark harness is
retained only in its own campaign archive and is not part of this matrix.
Evidence: `evidence/{name}.json`.

Remaining Module 37 items are timing with CPU barriers and final
reconciliation.'''.format(name=name))
p.write_text(s)
changed.append('docs/prepared-dictionary-validation.md')
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *changed], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Qualify compiled dictionary feature and release matrix'], cwd=R, check=True)
print('module37 matrix promoted at', subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()[:12])
