"""Archive the qualified Module37 full feature/release matrix."""
from pathlib import Path
import json, hashlib, tarfile, re, datetime

D = Path(__file__).parent
C = Path('/private/tmp/module37-matrix')
S = C / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
j = json.loads((C / 'evidence.json').read_text())
assert j['status'] == 'passed' and len(j['commands']) == 75
for n, h in j['source'].items():
    assert sha(S / n) == h, n
counts = tuple(j['expected_counts'])
for r in j['commands']:
    assert r['exit_code'] == 0 and sha(C / (r['label'] + '.log')) == r['log_sha256']
    if r['label'].endswith(('-full', '-release')):
        assert (r['result_groups'], r['passed'], r['ignored']) == counts, r['label']
files = {}
for p in C.rglob('*'):
    if not p.is_file():
        continue
    n = p.relative_to(C)
    if any(x in {'target', '__pycache__', 'source'} for x in n.parts):
        continue
    if p.suffix in {'.rs', '.toml', '.lock', '.json', '.py', '.log', '.md', '.tsv'}:
        files[str(n)] = p
files['archive-matrix.py'] = Path(__file__)
name = '2026-11-03-compiled-dictionary-feature-matrix'
archive = D / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
r = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source=j['source'], production_source=j.get('production_source', {n: h for n, h in j['source'].items() if n.startswith('src/')}), features=j['features'], expected_counts=j['expected_counts'], commands=j['commands'], members={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()}, archive=archive.name, archive_sha256=sha(archive), qualification='Full feature/release regression of the Module37 final source. Safe/all and all 22 isolated unsafe features run complete tests, true no_std and strict Clippy; safe/all release and formatting also run. Every full/release suite reports 123 result groups, 1832 passed and 78 ignored with zero failures; ignored tests are not credited. No milestone completion, repository integration or performance claim.')
(D / (name + '.json')).write_text(json.dumps(r, indent=2) + '\n')
print(name, archive.stat().st_size)
