"""Module37 final matrix: safe/all and every isolated feature, release, format."""
from pathlib import Path
import datetime, hashlib, json, os, re, signal, subprocess, time, tomllib

D = Path('/private/tmp/module37-matrix')
S = D / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
deadline = datetime.datetime.fromisoformat('2026-11-03T06:40:00+00:00').timestamp()
assert deadline - time.time() >= 120
COUNTS = (123, 1832, 78)
features = sorted(f for f in tomllib.loads((S / 'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'))
assert len(features) == 22, features
source = {str(p.relative_to(S)): sha(p) for folder in ['src', 'tests', 'test-support'] for p in (S / folder).rglob('*') if p.is_file()}
source.update({n: sha(S / n) for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']})
plan = []
for name, flags in [('safe', []), ('all', ['--all-features'])] + [(f, ['--features', f]) for f in features]:
    plan.append((name + '-full', ['cargo', 'test', '--offline', '--locked', *flags]))
    plan.append((name + '-no-std', ['cargo', 'check', '--offline', '--locked', '--lib', '--no-default-features', *flags]))
    plan.append((name + '-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--tests', *flags, '--', '-D', 'warnings']))
plan += [('safe-release', ['cargo', 'test', '--offline', '--locked', '--release']),
         ('all-release', ['cargo', 'test', '--offline', '--locked', '--release', '--all-features']),
         ('format', ['cargo', 'fmt', '--all', '--', '--check'])]
assert len(plan) == 75
assert not (D / 'evidence.json').exists()
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         deadline_utc='2026-11-03T06:40:00+00:00', features=features, source=source,
         expected_counts=list(COUNTS), commands=[], plan=plan,
         qualification='Full feature/release regression of the Module37 final source. Safe/all and all 22 isolated unsafe features run complete tests, true no_std and strict Clippy; safe/all release and formatting also run. Every full/release suite must report 123 groups, 1832 passed and 78 ignored with zero failures; ignored tests are not credited. No milestone completion, repository integration or performance claim.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(D / 'target'), 'CARGO_BUILD_JOBS': '6',
       'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
       'CARGO_PROFILE_DEV_DEBUG': '0'}


def counts(text):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert rows and all(int(f) == 0 for _, f, _ in rows), 'A test group failed'
    return len(rows), sum(int(p) for p, _, _ in rows), sum(int(i) for _, _, i in rows)


def save():
    p = D / 'evidence.pending.json'
    p.write_text(json.dumps(e, indent=2) + '\n')
    p.replace(D / 'evidence.json')


save()
try:
    for label, args in plan:
        remaining = deadline - time.time() - 30
        if remaining < 30:
            raise TimeoutError('User work window reached before ' + label)
        e['active_command'] = dict(label=label, argv=args, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
        start = time.monotonic()
        log = D / (label + '.log')
        with log.open('xb') as f:
            proc = subprocess.Popen(args, cwd=S, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = proc.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                raise TimeoutError('User work window reached during ' + label)
        row = dict(label=label, argv=args, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
        if label.endswith(('-full', '-release')) and code == 0:
            result = counts(log.read_text())
            assert result == COUNTS, (label, result)
            row.update(result_groups=result[0], passed=result[1], ignored=result[2])
        e['commands'].append(row)
        e.pop('active_command', None)
        save()
        print(label, code, flush=True)
        assert code == 0, label
    for n, h in source.items():
        assert sha(S / n) == h, ('Final source changed during matrix', n)
    assert len(e['commands']) == 75
    e.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
except TimeoutError as ex:
    e.update(status='interrupted-at-user-deadline', error=repr(ex)); save(); raise
except BaseException as ex:
    e.update(status='failed', error=repr(ex)); save(); raise
