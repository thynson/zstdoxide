from pathlib import Path
import hashlib,json,tarfile,re,tomllib
D=Path(__file__).parent;S=Path('/private/tmp/module24-candidate');M=Path('/private/tmp/module24-matrix')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
j=json.loads((M/'evidence.json').read_text());assert j['status']=='passed' and len(j['commands'])==69
features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
expected={n+'-'+suffix for n in ['safe','all',*features] for suffix in ['full','no-std','clippy']}|{'safe-release','all-release','format'}
assert {c['label'] for c in j['commands']}==expected
for n,h in j['source'].items():assert sha(S/n)==h,n
b=json.loads((D/'2026-10-26-stable-output-public-api.json').read_text())
for n,h in b['complete_source'].items():assert sha(S/n)==h,n
commands=[]
for c in j['commands']:
 assert c['exit_code']==0
 p=M/(c['label']+'.log');g=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.read_text());assert all(int(f)==0 for _,f,_ in g)
 if c['label'].endswith(('-full','-release')):assert len(g)==80 and sum(int(a) for a,_,_ in g)==1580 and sum(int(i) for _,_,i in g)==57,c['label']
 commands.append({**c,'log_sha256':sha(p),'result_groups':len(g),'passed':sum(int(a) for a,_,_ in g),'ignored':sum(int(i) for _,_,i in g)})
name='2026-10-26-stable-output-feature-matrix';archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(M.iterdir()):
  if p.is_file():t.add(p,arcname='campaign/'+p.name)
 for n in b['complete_source']:
  if Path(n).suffix in {'.rs','.toml','.lock','.md','.json','.py','.sh','.tsv','.csv'}:t.add(S/n,arcname='source/'+n)
 t.add(__file__,arcname='archive-matrix.py')
result=dict(status='passed',source=j['source'],complete_source=b['complete_source'],fixture_provenance=b['fixture_provenance'],commands=commands,archive=archive.name,archive_sha256=sha(archive),qualification='Frozen public candidate before the additive exact-selector fuzz adapter. Safe/all/each of twenty isolated features run complete regression, true no_std and strict Clippy; safe/all complete release and formatting also pass. Each complete suite reports 1580 passed and57 ignored across80 result groups. The separately archived additive adapter runs its seven new normal tests on all22 backend selections, with its external corpus explicitly executed under safe/all release. Ignored entries are not counted as passed.')
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
