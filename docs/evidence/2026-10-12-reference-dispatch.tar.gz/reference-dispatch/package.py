from pathlib import Path
import hashlib,io,json,re,tarfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-reference-dispatch-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
e=json.loads((OUT/'evidence.json').read_text());assert e['status']=='passed' and e['source_unchanged']
for n,h in e['source'].items():assert sha((ROOT/n).read_bytes())==h,n
for c in e['commands']:
 assert c['exit_code']==0;b=(OUT/c['log']).read_bytes();assert sha(b)==c['log_sha256']
 counts=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)
 if c['label'].startswith('dispatch-'):assert counts==[(b'3',b'0',b'0')]
 if c['label'].startswith('workspace-'):assert counts==[(b'9',b'0',b'0')]
 if c['label'].startswith('baselines-'):assert counts==[(b'7',b'0',b'0'),(b'4',b'0',b'0')]
members={p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()};members['runner.py']=Path('/tmp/check-zstdoxide-reference-dispatch.py').read_bytes();members['package.py']=Path(__file__).read_bytes()
for n in ['src/reference_search.rs','src/reference_frame_encode.rs','src/reference_encode.rs','src/lib.rs','tests/upstream/parameters/queries.tsv']:members['source/'+n]=(ROOT/n).read_bytes()
report={'date':'2026-10-12','status':'passed','commands':len(e['commands']),'dispatch_test_executions':15,'workspace_test_executions':45,'baseline_test_executions':22,'ignored':0,'source':e['source'],'parameter_fixture_sha256':sha((ROOT/'tests/upstream/parameters/queries.tsv').read_bytes()),'scope':'Static selected search plan/state and shared frame workspace with one entropy owner. No inactive table allocation; unchanged complete Fast/named frame bytes and exact allocator counts. Private DoubleFast candidate dispatch; complete DoubleFast frame qualification and public admission remain open. No new C capture, Miri or timing.','archive':'2026-10-12-reference-dispatch.tar.gz'}
report['bootstrap_note']='The first workspace bootstrap passed all9 tests with a dead-code warning for the not-yet-tested DoubleFast plan variant. Adding the planned dispatch tests exercises that variant; all final checks pass without diagnostics.'
members['bootstrap.log']=Path('/tmp/zstdoxide-reference-dispatch-bootstrap.log').read_bytes()
members['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();members['bundle-manifest.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},sort_keys=True,indent=2)+'\n').encode()
a=ROOT/'docs/evidence'/report['archive'];assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('reference-dispatch/'+n);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 assert set(t.getnames())=={'reference-dispatch/'+n for n in members}
 for n,b in members.items():assert t.extractfile('reference-dispatch/'+n).read()==b
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(members));(ROOT/'docs/evidence/2026-10-12-reference-dispatch.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(len(e['commands']),'commands;',len(members),'archive members')
