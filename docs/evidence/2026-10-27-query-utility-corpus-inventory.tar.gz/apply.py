from pathlib import Path
import json,hashlib,subprocess,tarfile,datetime,shutil,collections
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=json.loads((D/'planned-case-updates.json').read_text());assert plan['status']=='validated-candidate-not-applied'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip();closures={}
for name in ['frame-query','frame-utility','one-shot-selection']:
 p=E/('2026-10-27-'+name+'-closure.json');j=json.loads(p.read_text());assert j['status']=='passed' and sha(E/j['archive'])==j['archive_sha256'];closures[name]=sha(p)
production={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')};assert production==plan['audited_candidate_source'];assert sha(R/'tests/upstream/manifest.json')==plan['baseline_manifest_sha256'];assert sha(D/'manifest.json')==plan['candidate_manifest_sha256']
required=['frame-query-native','frame-query-history','frame-query-platform','frame-utility-native','frame-utility-history','frame-utility-platform','dictionary-in-place-corpus','one-shot-selection-corpus'];evidence={}
for name in required:
 p=E/('2026-10-27-'+name+'.json');j=json.loads(p.read_text());assert j['status']=='passed' and sha(E/j['archive'])==j['archive_sha256'];evidence[name]=dict(receipt_sha256=sha(p),archive_sha256=j['archive_sha256'])
shutil.copyfile(R/'tests/upstream/manifest.json',D/'integrated-before-manifest.json');shutil.copyfile(D/'manifest.json',R/'tests/upstream/manifest.json')
brief={497:'Original powers 0..29 and too-large input preserved by typed bound and native function/macro checks; see frame-utility-native evidence.',519:'All three original constructions preserve exact known/empty/32769-flush bounds and decoded bytes; see frame-query-native evidence.',750:'Exact original five-MiB frame and preceding history; aggregate size and complete output verified by frame_queries_history.',756:'Exact original five-MiB frame and preceding history; tight decoded bound verified by frame_queries_history.',763:'Exact original frame with last byte removed is rejected; preceding history and valid counterpart retained in frame-query-history evidence.',948:'Original call used buffer capacity5263360 rather than frame length1692054 and compared native error sentinel18446744073709551614 as a bound. Keep partial; useful exact-frame query is supplemental.',2376:'Exact original four-frame/129-KiB-skip concatenation, preceding history and complete2.5-MiB output; exact aggregate size preserved.',2381:'Exact original four-frame/129-KiB-skip concatenation and preceding history; tight aggregate bound preserved.',2396:'Exact original seed-derived129-KiB payload/variant; byte-identical writing and borrowed payload/extent/variant assertions, with guards. See frame-utility-history evidence.',2420:'Exact original seed%15 empty variant; eight-byte frame, marker, empty borrowed payload and variant assertions preserved. C NULL ABI is represented by safe empty slices.',4117:'Query is available; this original late-fuzzer skippable fixture remains unmapped. Generic query tests are supplemental.',4121:'Query is available; this original late-fuzzer skippable fixture remains unmapped. Generic query tests are supplemental.',4125:'Metadata is available; this original late-fuzzer fixture and complete header/capacity assertions remain unmapped.'}
p=R/'tests/upstream/FUZZER.md';lines=p.read_text().splitlines();seen=set()
for i,line in enumerate(lines):
 parts=line.split('|')
 if len(parts)==6 and parts[1].strip().isdigit() and int(parts[1].strip()) in brief:
  n=int(parts[1].strip());assert n not in seen;seen.add(n);parts[3]=' '+plan['updates']['tests/fuzzer.c:'+str(n)]['status']+' ';parts[4]=' '+brief[n]+' ';lines[i]='|'.join(parts)
assert seen==set(brief);p.write_text('\n'.join(lines)+'\n')
p=R/'docs/upstream-test-inventory.md';s=p.read_text();needle='Remaining `planned` examples are ordinary file-based sample-program ports.';assert needle in s;s=s.replace(needle,'Remaining `planned` units include file-based sample-program ports and exact\nlate-fuzzer skippable fixtures whose query APIs now exist.');anchor='## External corpus snapshots';assert s.count(anchor)==1;s=s.replace(anchor,'''## Query, utility and call-scoped corpus reconciliation (2026-10-27)

Eleven named function/diagnostic anchors now have complete bounded Rust
adaptations for original compression/decompression bounds, known-size single and
multiple-frame queries, and exact original skippable writes/reads. Native history
captures preserve preceding generator state and complete payload bytes; standalone
bound construction records its helper allocation-lifetime difference. These
anchors are navigation groups, not independent assertion or execution counts.

The unknown-size bound group at fuzzer.c:948 remains partial: native queried full
buffer capacity rather than encoded frame length, returned an error sentinel and
then compared it numerically as an upper bound. Rust's useful exact-frame query
is explicitly supplemental. Late skippable metadata groups4117/4121/4125 remain
planned, because API availability does not reproduce their original fixtures.

All12,063 dictionary_decompress inputs additionally exercise call-scoped direct
and in-place selection, with exact Rust Result/output/guard/state comparisons.
The original selectors and historical ledger remain intact. Call-scoped prefixes
serve all frames in one call and are not equated to incremental frame prefixes.
Independent Rust training and native context/workspace differences keep that
source partial. Safe/all corpus receipts are separate from ignored ordinary runs.

After all source-bound Module30–32 closures, the integrated audit retains639 files,
418 test-related sources,221 exclusions and615 named groups. Case statuses are
66 ported,120 partial,411 blocked,3 planned and15 non-applicable. Complete upstream
migration remains open. See `evidence/2026-10-27-query-utility-corpus-inventory.json`
for exact before/after metadata, source identities and executed audit.

'''+anchor);p.write_text(s)
p=R/'TODO.md';s=p.read_text();needle='- [x] Analyze the existing frame/block encoder and bounded output ownership before implementation.';assert s.count(needle)==1;s=s.replace(needle,needle+'\n- [x] Reconcile inherited original query/utility assertions and dictionary corpus metadata after Module 32 source closure.');p.write_text(s)
p=R/'docs/progress.md';p.write_text(p.read_text()+'''\n## Original-test inventory reconciliation (2026-10-27)

After Module32 closure, eleven original function/diagnostic anchors for bounded
queries and exact skippable histories advance to ported. Group948 stays partial
for its original native error-sentinel-as-bound comparison. Three late skippable
metadata groups become planned because APIs exist but exact fixtures remain
unmapped. Dictionary_decompress source/case reasons now record persistent in-place
and all12063 call-scoped direct/in-place supplements while preserving partial
native-training/context coverage. The machine manifest and FUZZER table agree.
The complete pinned audit verifies639 files and615 groups; counts are navigation
units, not a complete upstream assertion tally. All frozen milestone manifests
retain their earlier identities; this is a separate metadata-only reconciliation.
Evidence: `evidence/2026-10-27-query-utility-corpus-inventory.json`.
''')
args=['python3','scripts/audit_upstream_tests.py','--upstream','/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99']
with (D/'integrated-audit.log').open('xb') as f:r=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0,(D/'integrated-audit.log').read_text();j=json.loads((R/'tests/upstream/manifest.json').read_text());counts=collections.Counter(c['status'] for s in j['sources'] for c in s.get('cases',[]));assert dict(counts)==dict(ported=66,partial=120,blocked=411,planned=3,non_applicable=15)
name='2026-10-27-query-utility-corpus-inventory';archive=E/(name+'.tar.gz');assert not archive.exists();files={p.name:p for p in D.iterdir() if p.is_file() and p.suffix in ['.json','.py','.log']};files['integrated-FUZZER.md']=R/'tests/upstream/FUZZER.md';files['integrated-inventory.md']=R/'docs/upstream-test-inventory.md'
with tarfile.open(archive,'w:gz') as tar:
 for n,p in sorted(files.items()):tar.add(p,arcname=n)
receipt=dict(status='passed',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,previous_manifest_sha256=plan['baseline_manifest_sha256'],integrated_manifest_sha256=sha(R/'tests/upstream/manifest.json'),closures=closures,source_bound_evidence=evidence,audit_command=args,audit_log_sha256=sha(D/'integrated-audit.log'),case_status_counts=dict(counts),members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()},archive=archive.name,archive_sha256=sha(archive),qualification='Metadata-only update after every frozen source closure; no earlier matrix manifest is changed or relabeled. Eleven anchors upgraded using executed original assertions/history; one sentinel-miscomparison remains partial and three late fixtures remain planned. Dictionary corpus source stays partial. Inventory validity does not imply complete migration.')
(E/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');paths=['tests/upstream/manifest.json','tests/upstream/FUZZER.md','docs/upstream-test-inventory.md','TODO.md','docs/progress.md','docs/evidence/'+name+'.json','docs/evidence/'+name+'.tar.gz'];subprocess.run(['git','diff','--check'],cwd=R,check=True);subprocess.run(['git','add','--',*paths],cwd=R,check=True);subprocess.run(['git','commit','-m','Reconcile original frame queries utilities and dictionary corpus coverage'],cwd=R,check=True)
