from pathlib import Path
import json,subprocess,hashlib,shutil,datetime
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');S=D/'source';S.mkdir();F=Path('/private/tmp/module32-final');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['src','tests','test-support','benches','docs','scripts']:
 p=(F if n in ['src','tests','test-support','benches'] else R)/n
 if p.exists():subprocess.run(['cp','-cR',str(p),str(S/n)],check=True)
plan=json.loads((D/'planned-case-updates.json').read_text());assert sha(R/'tests/upstream/manifest.json')==plan['baseline_manifest_sha256'];j=json.loads((R/'tests/upstream/manifest.json').read_text())
for source in j['sources']:
 for case in source.get('cases',[]):
  if case['id'] in plan['updates']:
   assert {k:case[k] for k in ['status','reason','rust_tests']}==plan['before'][case['id']];case.update(plan['updates'][case['id']])
 if source['path']=='tests/fuzz/dictionary_decompress.c':
  reason='All 12,063 pinned rolling dictionary_decompress inputs run under safe/all release without skips. Original source/training/attachment/capacity selectors remain intact: 11,768 Rust-trained dictionaries, 295 empty training fallbacks and 20 successful legacy-adapter decodes. The 10,930 persistent prepared/loaded branches compare guarded direct, in-place, buffered and seven-byte stable output; all 1,133 prefix branches compare buffered and seven-byte frame-scoped stable prefixes. A separate call-scoped supplement runs both direct and in-place coordinators for all 12,063 selected inputs, comparing exact Result, complete successful bytes, guards and selection retention/consumption against a stateless persistent dictionary view. Its prefix covers all frames in one call and is deliberately not equated to frame-scoped prefixes. The historical outcome ledger does not separately count coordinated successes. Rust training is not byte-identical native fastCover, and opaque C context/workspace/loading/parameter contracts remain partial. Fixed fragmentation and suffix layouts are supplemental schedules, not new original selectors. Evidence: docs/evidence/2026-10-27-dictionary-in-place-corpus.json and 2026-10-27-one-shot-selection-corpus.json.'
  test='tests/upstream_trained_dictionary_fuzz.rs#call_scoped_prefix_supplement_reuses_one_selection_across_concatenated_frames'
  plan['dictionary_before']=dict(reason=source['reason'],rust_tests=source['rust_tests'],cases=source['cases'])
  for record in [source,*source['cases']]:record['reason']=reason;record['rust_tests']=[*record['rust_tests'],test]
  plan['dictionary_after']=dict(reason=source['reason'],rust_tests=source['rust_tests'],cases=source['cases'])
# Independent clone only. Frozen snapshots and integrated manifest stay unchanged.
p=S/'tests/upstream/manifest.json';p.write_text(json.dumps(j,indent=2)+'\n');shutil.copyfile(p,D/'manifest.json')
args=['python3','scripts/audit_upstream_tests.py','--upstream','/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99']
with (D/'inventory.log').open('xb') as f:r=subprocess.run(args,cwd=S,stdout=f,stderr=subprocess.STDOUT)
plan.update(status='validated-candidate-not-applied' if r.returncode==0 else 'rejected-candidate',audit_command=args,audit_exit_code=r.returncode,audit_log_sha256=sha(D/'inventory.log'),candidate_manifest_sha256=sha(p),audited_candidate_source={str(p.relative_to(F)):sha(p) for p in (F/'src').rglob('*.rs')},recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(D/'planned-case-updates.json').write_text(json.dumps(plan,indent=2)+'\n');assert r.returncode==0,(D/'inventory.log').read_text();print((D/'inventory.log').read_text())
