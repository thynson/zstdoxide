from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');C=Path('/private/tmp/zstdoxide-lazy-families-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,s):
 if not v:raise ValueError(s)
e=json.loads((C/'evidence.json').read_bytes());need(e['status']=='passed' and len(e['commands'])==1468 and e['source_before']==e['source_after'],'completed capture')
for n,h in e['source_before'].items():need(sha((R/n).read_bytes())==h,'unchanged source '+n)
files={'capture/'+str(p.relative_to(C)):p.read_bytes() for p in sorted(C.rglob('*')) if p.is_file()}
for mode in ['normal','optimized']:
 p=Path('/tmp/zstdoxide-lazy-family-audit-'+mode+'.json');v=json.loads(p.read_bytes());need(v['commands']==1468 and v['exact_tiny_controls']==138 and len(v['predecessor_controls'])==173 and all(x['exact_owner_layout_qualified'] for x in v['predecessor_controls']),'independent audit')
 need(not Path('/tmp/zstdoxide-lazy-family-audit-'+mode+'.stderr').read_bytes(),'no audit diagnostic');files['audit-'+mode+'.json']=p.read_bytes()
need(files['audit-normal.json']==files['audit-optimized.json'],'same audits')
report={'schema_version':1,'status':'paused','date':'2026-10-12','capture_status':'passed','independent_audits':['normal Python','optimized Python'],'commands':1468,'totals':e['totals'],'exact_tiny_controls':138,'predecessor_controls':173,'exact_predecessor_owner_layouts':173,'source_unchanged':True,'capture_evidence_sha256':sha((C/'evidence.json').read_bytes()),'qualification':'Pause preservation only. Broader capture passed and both offline audits passed. Broad-capture forgery controls, detailed score-hit reconciliation, permanent fixture freezing, projection and Rust Lazy implementation remain unfinished. This is not Module15 completion. Downloaded C source remains outside the repository; every actual capture file, including all used objects/executables, is retained.','archive':'2026-10-12-lazy-family-wip.tar.gz','resume_capture_directory':str(C),'raw_capture_files':len([n for n in files if n.startswith('capture/')])}
files['pause-report.json']=enc(report);files['pause-packager.py']=Path(__file__).read_bytes();files['bundle-manifest.json']=enc({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())})
a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh pause archive');prefix='lazy-family-wip/'
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo(prefix+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:found={v.name:t.extractfile(v).read() for v in t}
need(found=={prefix+n:b for n,b in files.items()},'archive verified')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files),archive_uncompressed_bytes=sum(map(len,files.values())));(R/'docs/evidence/2026-10-12-lazy-family-wip.json').write_bytes(enc(report));print(json.dumps({k:report[k] for k in ['raw_capture_files','archive_bytes','archive_members','archive_sha256']}))
