from pathlib import Path
import hashlib,json,os,re,subprocess,tarfile,time,io
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize'); BASE='189f37a'; OUT=Path('/tmp/zstdoxide-fast-frames-checkpoint'); SNAP=OUT/'source'
OUT.mkdir(exist_ok=False); SNAP.mkdir()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
commit=subprocess.check_output(['git','rev-parse',BASE],cwd=ROOT,text=True).strip()
archive=subprocess.check_output(['git','archive',commit],cwd=ROOT)
with tarfile.open(fileobj=io.BytesIO(archive)) as t: t.extractall(SNAP,filter='data')
path='tests/upstream_fast_frames.rs'; (SNAP/path).write_bytes((ROOT/path).read_bytes())
tracked=[p for p in SNAP.rglob('*') if p.is_file()]
before={str(p.relative_to(SNAP)):sha(p) for p in tracked}
unsafe=['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-dictionary','unsafe-training']
commands=[]
configs=[('safe',[]),*[(flag,['--features',flag]) for flag in ('unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-fse','unsafe-huffman')],('all',['--all-features']),('no-std', ['--no-default-features']),('no-std-all',['--no-default-features','--features',','.join(unsafe)])]
for name,flags in configs: commands.append(('test-'+name,['cargo','test','--offline','--locked','--test','upstream_fast_frames',*flags],4))
for name,flags in [('safe',[]),('all',['--all-features'])]: commands.append(('clippy-'+name,['cargo','clippy','--offline','--locked','--test','upstream_fast_frames',*flags,'--','-D','warnings'],None))
for name,flags in [('safe',[]),('all',['--features',','.join(unsafe)])]: commands.append(('no-std-check-'+name,['cargo','check','--offline','--locked','--lib','--no-default-features',*flags],None))
commands.append(('format',['rustfmt','--edition','2024','--config','skip_children=true','--check',path],None))
env=os.environ.copy(); env.update(CARGO_TARGET_DIR=str(OUT/'target'),CARGO_TERM_COLOR='never')
result={'base_commit':commit,'snapshot':str(SNAP),'overlay_sha256':sha(ROOT/path),'snapshot_before_sha256':before,'commands':[],'status':'running','qualifications':['No native C invocation in Cargo tests; saved completed C frames only.','Five individual flags cover actual one-shot decode access families; other flags participate in all-feature builds without claiming every backend path is active.','Eleven partial headers remain excluded from the 27 completed-frame count.']}
(OUT/'rustc.txt').write_bytes(subprocess.check_output(['rustc','-Vv'],cwd=SNAP,env=env)); (OUT/'cargo.txt').write_bytes(subprocess.check_output(['cargo','-V'],cwd=SNAP,env=env))
def save(): (OUT/'evidence.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
save()
for name,argv,expected in commands:
 start=time.monotonic(); log=OUT/(name+'.log')
 with log.open('wb') as f: completed=subprocess.run(argv,cwd=SNAP,env=env,stdout=f,stderr=subprocess.STDOUT)
 record={'name':name,'argv':argv,'cwd':str(SNAP),'environment':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR'],'CARGO_TERM_COLOR':'never'},'exit_code':completed.returncode,'elapsed_seconds':time.monotonic()-start,'log':log.name,'log_sha256':sha(log)}
 if expected is not None:
  matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',log.read_text())
  record['test_summaries']=[dict(zip(('passed','failed','ignored','measured','filtered'),map(int,m))) for m in matches]
  record['expected_count_satisfied']=len(matches)==1 and tuple(map(int,matches[0]))==(expected,0,0,0,0)
  record['complete_C_frames_Rust_decoded']=27; record['decoded_bytes']=2275346
 result['commands'].append(record);save(); print(name,record['exit_code'],record.get('test_summaries',''),flush=True)
 if completed.returncode or expected is not None and not record['expected_count_satisfied']:
  result['status']='failed';save();raise SystemExit(1)
after={str(p.relative_to(SNAP)):sha(p) for p in tracked}
result['snapshot_after_sha256']=after;result['snapshot_unchanged']=before==after;result['owned_source_unchanged']=sha(ROOT/path)==result['overlay_sha256'];result['status']='passed' if before==after and result['owned_source_unchanged'] else 'failed';save()
print(json.dumps({'status':result['status'],'commands':len(commands),'test_runs':len(configs),'test_passes':len(configs)*4,'ignored':0,'frames_per_run':27,'decoded_bytes_per_run':2275346,'evidence':str(OUT/'evidence.json'),'sha256':sha(OUT/'evidence.json')}))
