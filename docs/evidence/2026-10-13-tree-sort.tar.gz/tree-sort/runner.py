from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-sort-checks');O.mkdir();env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/zstdoxide-tree-reader-target'
paths=sorted((R/'src').glob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock'];source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};rows=[]
def run(label,args,tests=None):
 log=O/(label+'.log');start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
 b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest());rows.append(r);print(label,p.returncode,flush=True)
 if tests is not None:
  counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)];r['tests']=counts
  if counts!=[tests]:raise ValueError('test totals '+label)
 if p.returncode:raise ValueError(label)
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree']),('all',['--all-features']),('release-all',['--release','--all-features'])]:
 run('sort-'+name,['cargo','test','--offline','--locked',*flags,'--lib','tree_sort::tests'],(5,0,0))
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree'])]:
 run('nostd-'+name,['cargo','check','--offline','--locked','--no-default-features',*flags])
for name,flags in [('safe',[]),('all',['--all-features'])]:
 run('clippy-'+name,['cargo','clippy','--offline','--locked','--all-targets',*flags,'--','-D','warnings'])
run('format',['cargo','fmt','--all','--','--check'])
assert source=={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,tests=20,qualification='Synthetic bounded reversal/sorting and malformed-state controls; exact C full-operation conformance is the next work item.'),sort_keys=True,indent=2)+'\n')
