from pathlib import Path
import hashlib,json,tarfile
D=Path(__file__).parent;T=Path('/private/tmp');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
N=T/'module26-native';j=json.loads((N/'native.json').read_text());b=json.loads((N/'build.json').read_text());r=json.loads((N/'rust.json').read_text());assert j['status']==b['status']==r['status']=='passed' and len(j['results'])==1428 and len(r['commands'])==5
assert all(c['exit_code']==0 for c in r['commands'])
for name,h in b['executables'].items():assert sha(N/('oracle-'+name))==h
for name,h in j['inputs'].items():assert sha(N/'inputs'/name)==h
for name,h in r['source'].items():assert sha(N/'rust-source'/name)==h
assert r['native_sha256']==sha(N/'native.json')
for row in j['results']:assert row['result']['guards']==1
name='2026-10-26-stable-dictionary-output-native';archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(N.rglob('*')):
  if p.is_file() and not {'rust-target','__pycache__'}.intersection(p.relative_to(N).parts) and '.dSYM' not in str(p):t.add(p,arcname=str(p.relative_to(N)))
 t.add(T/'module24-preparation/reference-identity.json',arcname='reference-identity.json');t.add(__file__,arcname='archive-native-platform.py')
result=dict(status='passed',native=j,build=b,rust=r,archive=archive.name,archive_sha256=sha(archive),qualification='119 descriptors at whole/one/seven-byte input schedules execute through native persistent loaded/prepared DDict stable-output sessions under normal/ASan/UBSan builds (1428 calls). Both shared and borrowed Rust handles execute all357 cases under safe, isolated slice, isolated dictionary, both and all (3570 calls). The p>window descriptor explicitly expects native success and Rust CorruptData under the established format-based policy. Native and Rust actual outer guards and Rust successful unused suffixes are checked. Downloaded reference source stays external; full hashes, helper/source and retained native executables are archived.')
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size,flush=True)
S=T/'module26-platform';j=json.loads((S/'evidence.json').read_text());assert j['status']=='passed' and len(j['commands'])==8 and all(c['exit_code']==0 for c in j['commands'])
for n,h in j['source'].items():assert sha(S/'source'/n)==h,n
for rows in j['artifacts'].values():
 for row in rows:assert sha(S/row['path'])==row['sha256']
name='2026-10-26-stable-dictionary-output-platform';archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(S.iterdir()):
  if p.is_file():t.add(p,arcname='campaign/'+p.name)
 for folder in ['source','probe','artifacts']:
  for p in sorted((S/folder).rglob('*')):
   if p.is_file() and 'target' not in p.relative_to(S/folder).parts:t.add(p,arcname=folder+'/'+str(p.relative_to(S/folder)))
 t.add(__file__,arcname='archive-native-platform.py')
(D/(name+'.json')).write_text(json.dumps({**j,'archive':archive.name,'archive_sha256':sha(archive)},indent=2)+'\n');print(name,archive.stat().st_size,flush=True)
