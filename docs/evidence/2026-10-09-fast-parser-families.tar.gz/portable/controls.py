from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
root=Path('/Users/lanxingcan/Workspace/zstdoxize');original=root/'tests/upstream/fast-parser-families';script=root/'scripts/import_fast_parser_families.py';work=Path('/tmp/zstdoxide-fast-family-portable-controls');work.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[];env=os.environ.copy();env['PATH']='/nonexistent';env['PYTHONDONTWRITEBYTECODE']='1'
def execute(label,args,expected,optimized=False):
 command=[sys.executable]+(['-O'] if optimized else [])+[str(script),*map(str,args)]
 start=time.monotonic();p=subprocess.run(command,cwd=root,env=env,capture_output=True,timeout=60)
 (work/(label+'.stdout')).write_bytes(p.stdout);(work/(label+'.stderr')).write_bytes(p.stderr)
 records.append({'label':label,'command':command,'exit':p.returncode,'expected_success':expected,'seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
 (work/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 if (p.returncode==0)!=expected:raise RuntimeError(label+' '+p.stdout.decode()+p.stderr.decode())
 print(label,p.returncode,flush=True)
def altered(label,mutate):
 path=work/label;shutil.copytree(original,path);mutate(path);return path

def edit_manifest(path,fn):
 p=path/'manifest.json';j=json.loads(p.read_text());fn(j);p.write_text(json.dumps(j)+'\n')

def reseal(path):
 def update(j):
  for f in j['fixtures']:
   p=path/f['path'];f['size']=p.stat().st_size;f['sha256']=sha(p)
  j['fixture_catalog_sha256']=hashlib.sha256(json.dumps(j['fixtures'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
 edit_manifest(path,update)

cases=[]
cases.append(('missing-record',lambda p:(p/'normal-tail-7-t0.stdout').unlink()))
cases.append(('extra-file',lambda p:(p/'unlisted').write_text('extra')))
cases.append(('changed-record',lambda p:(p/'normal-tail-7-t0.stdout').write_text('{}\n')))
def forged(p):
 target=p/'normal-tail-7-t0.stdout';rows=[json.loads(x) for x in target.read_text().splitlines()];rows[1]['trailing_literals']=6;target.write_text('\n'.join(json.dumps(x) for x in rows)+'\n');reseal(p)
cases.append(('forged-record-and-manifest',forged))
cases.append(('changed-recipes',lambda p:(p/'recipes.json').write_text('{}\n')))
for label,key,value in [('wrong-revision','upstream_revision','0'*40),('bool-version','schema_version',True),('wrong-helper','generator_sha256','0'*64),('wrong-importer','importer_sha256','0'*64),('wrong-catalog','fixture_catalog_sha256','0'*64),('missing-driver','repository_input_sha256',{}),('missing-fixture','fixtures',[]),('missing-sources','source_sha256',{})]:
 cases.append((label,lambda p,k=key,v=value:edit_manifest(p,lambda j:j.__setitem__(k,v))))
cases.append(('coverage-promotion',lambda p:edit_manifest(p,lambda j:j['coverage'].__setitem__('ordinary_frames',True))))
cases.append(('detached-host',lambda p:edit_manifest(p,lambda j:j['capture']['metadata'].__setitem__('pointer_bits',32))))
cases.append(('wrong-witness',lambda p:edit_manifest(p,lambda j:j['capture'].__setitem__('family_review',{}))))
cases.append(('instrumentation-promotion',lambda p:edit_manifest(p,lambda j:j['capture']['instrumentation'].__setitem__('remaining_archive_instrumented',True))))
cases.append(('wrong-count',lambda p:edit_manifest(p,lambda j:j['capture'].__setitem__('final_c_case_executions',567))))
cases.append(('duplicate-manifest-key',lambda p:(p/'manifest.json').write_text('{"schema_version":1,"schema_version":1}')))
def escaping(p):
 target=p/'normal-tail-7-t0.stdout';target.unlink();target.symlink_to(original/target.name)
cases.append(('escaping-symlink',escaping))
paths=[(label,altered(label,fn)) for label,fn in cases]
for optimized in (False,True):
 mode='optimized' if optimized else 'normal'
 execute(mode+'-positive',['--check'],True,optimized)
 for label,path in paths:execute(mode+'-'+label,['--check','--collection',path],False,optimized)
 for label,args in [('mixed-options',['--check','--upstream','/tmp/reference']),('missing-regeneration-args',[]),('repository-output',['--upstream','/tmp/zstdoxize-upstream-1.5.7','--output',root/'uncreated-fast-oracle-output']),('reference-output',['--upstream','/tmp/zstdoxize-upstream-1.5.7','--output','/tmp/zstdoxize-upstream-1.5.7/uncreated-fast-output']),('ancestor-output',['--upstream','/tmp/zstdoxize-upstream-1.5.7','--output','/tmp']),('existing-output',['--upstream','/tmp/zstdoxize-upstream-1.5.7','--output',work])]:
  execute(mode+'-'+label,args,False,optimized)
summary={'commands':len(records),'positive':sum(r['expected_success'] for r in records),'expected_rejections':sum(not r['expected_success'] for r in records),'compiler_search_path':'/nonexistent','importer_sha256':sha(script),'status':'passed'}
(work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary,flush=True)
