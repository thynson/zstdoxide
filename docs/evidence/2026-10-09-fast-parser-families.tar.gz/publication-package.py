from pathlib import Path
import json,hashlib,tarfile,io,subprocess
root=Path('/Users/lanxingcan/Workspace/zstdoxize');artifact=root/'docs/evidence/2026-10-09-fast-parser-families.tar.gz';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
original=Path('/tmp/zstdoxide-fast-direct-family-evidence.json');original_tar=Path('/tmp/zstdoxide-fast-direct-family-evidence.tar.gz');capture=Path('/tmp/zstdoxide-fast-family-portable-regeneration');controls=Path('/tmp/zstdoxide-fast-family-portable-controls')
j=json.loads(original.read_text());p=json.loads((capture/'evidence.json').read_text());c=json.loads((controls/'summary.json').read_text())
assert p['status']=='passed' and len(p['commands'])==289 and all(v['exit_code']==0 for v in p['commands'])
assert len(p['frozen_fixture_comparison'])==2 and all(v['observations']==284 and v['all_case_records_equal'] for v in p['frozen_fixture_comparison'])
assert c['status']=='passed' and c['commands']==54
checks=[]
for command in [['python3','scripts/check_upstream_fixtures.py'],['python3','scripts/audit_upstream_tests.py'],['sh','-n','scripts/check.sh'],['sh','-n','scripts/check_upstream_oracles.sh'],['git','diff','--check']]:
 r=subprocess.run(command,cwd=root,capture_output=True,text=True);checks.append({'command':command,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,checks[-1]
files={original:'original/evidence.json',original_tar:'original/capture-and-controls.tar.gz',Path('/tmp/zstdoxide-fast-family-portable-controls.py'):'portable/controls.py',Path(__file__):'publication-package.py'}
for name in ['scripts/import_fast_parser_families.py','scripts/oracles/fast_direct_families.py','scripts/oracles/fast_direct_families.c','scripts/check_upstream_fixtures.py','scripts/check.sh','scripts/check_upstream_oracles.sh']:
 files[root/name]='repository/'+name
omitted=[]
for path in sorted(capture.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(capture).as_posix()
 if '.dSYM/' in rel or path.name in {'fast-families-normal','fast-families-sanitized'}:
  omitted.append({'path':rel,'size':path.stat().st_size,'sha256':sha(path)});continue
 files[path]='portable/regeneration/'+rel
for path in sorted(controls.iterdir()):
 if path.is_file():files[path]='portable/controls/'+path.name
manifest=[{'path':target,'size':path.stat().st_size,'sha256':sha(path)} for path,target in files.items()]
with tarfile.open(artifact,'w:gz') as tar:
 for path,target in files.items():tar.add(path,arcname=target,recursive=False)
 for name,value in [('archive-manifest.json',manifest),('omitted-binaries.json',omitted),('registration-checks.json',checks)]:
  b=(json.dumps(value,indent=2)+'\n').encode();info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b))
report={'scope':'Frozen direct no-dictionary Fast candidate sequence/state families; no Rust parser, collector or ordinary-frame publication claim','original_capture':j,'portable_regeneration':{'evidence_archive_path':'portable/regeneration/evidence.json','sha256':sha(capture/'evidence.json'),'commands_passed':289,'recipes':142,'observations_per_build':284,'successful_c_case_executions':568,'frozen_fixture_comparison':p['frozen_fixture_comparison'],'source_before_equals_after':p['source_before']==p['source_after'],'compiler':(capture/'compiler-version.stdout').read_text(),'instrumentation':p['instrumentation'],'repository_source_sha256':p['repository_source_sha256']},'portable_offline_controls':c|{'commands_archive_path':'portable/controls/commands.json','commands_sha256':sha(controls/'commands.json')},'registration_checks':checks,'review':{'reviewer':'independent golden_tests agent','importer_sha256':sha(root/'scripts/import_fast_parser_families.py'),'finding':'No blocker in offline purity, frozen identity binding, disjoint output paths, or complete record regeneration comparisons.'},'archive':{'path':artifact.name,'bytes':artifact.stat().st_size,'sha256':sha(artifact),'regular_members':len(files)+3,'omitted_portable_binary_debug_files':len(omitted)},'qualifications':['Final table state is not chronological tracing.','Scoped sanitizer instruments helper, unchanged Fast and inline helpers; remaining archive is uninstrumented; LeakSanitizer disabled.','Normal and sanitized native execution on arm64 macOS only.','Repeated captures increase validation executions, not distinct recipe coverage.','Original nine-recipe smoke fixtures remain unchanged.']}
(root/'docs/evidence/2026-10-09-fast-parser-families.json').write_text(json.dumps(report,indent=2)+'\n');print(report['archive']);print('Registration checks:',len(checks),'passed')
