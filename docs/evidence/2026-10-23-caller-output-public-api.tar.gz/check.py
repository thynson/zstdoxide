from pathlib import Path
import os,subprocess,json,time,hashlib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path(__file__).parent
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module23-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
paths=['Cargo.toml','src/lib.rs','src/slice_history.rs','src/history.rs','src/decode.rs','src/error.rs','tests/caller_output.rs'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths}
e={'status':'running','source':source,'commands':[]}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append({'label':label,'argv':args,'exit_code':p.returncode,'seconds':time.monotonic()-t});save();print(label,p.returncode,flush=True)
 if p.returncode:raise ValueError(label)
try:
 for name,flags in [('safe',[]),('unsafe',['--features','unsafe-slice-history']),('all',['--all-features'])]:
  run(name+'-public',['cargo','test','--offline','--locked','--test','caller_output',*flags])
  run(name+'-docs',['cargo','test','--offline','--locked','--doc',*flags])
  run(name+'-owned-unit',['cargo','test','--offline','--locked','--lib','decode::',*flags])
  run(name+'-integration',['cargo','test','--offline','--locked','--test','malformed','--test','upstream_fuzzer','--test','upstream_decodecorpus',*flags])
  no=[] if name=='safe' else ['--features','unsafe-slice-history'] if name=='unsafe' else ['--features',','.join(sorted(__import__('tomllib').loads((R/'Cargo.toml').read_text())['features'].keys()-{'default','std'}))]
  run(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*no])
  run(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])
 run('format',['cargo','fmt','--all','--','--check'])
 if source!={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths}:raise ValueError('changed source')
 e['status']='passed';save()
except BaseException as ex:e['status']='failed';e['error']=repr(ex);save();raise
