import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/private/tmp/zstdoxide-ultra-public-candidate');out=Path('/private/tmp/ultra-public-support-checks');out.mkdir();(out/'logs').mkdir();(out/'source').mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
names=['scripts/audit_upstream_tests.py','tests/upstream/manifest.json','test-support/allocator/Cargo.toml','test-support/allocator/Cargo.lock','test-support/allocator/src/lib.rs']
source={n:sha(root/n) for n in names}
for n in names:
 p=out/'source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/n).read_bytes())
(out/'source/driver.py').write_bytes(Path(__file__).read_bytes())
rows=[('allocator-tests',['cargo','test','--manifest-path','test-support/allocator/Cargo.toml'],0),('allocator-clippy',['cargo','clippy','--manifest-path','test-support/allocator/Cargo.toml','--all-targets','--','-D','warnings'],0),('allocator-format',['cargo','fmt','--manifest-path','test-support/allocator/Cargo.toml','--','--check'],0),('upstream-inventory',['python3','-B','scripts/audit_upstream_tests.py','--upstream','/private/tmp/zstdoxide-reference-lazy-1.5.7'],0),('migration-incomplete',['python3','-B','scripts/audit_upstream_tests.py','--require-complete'],1)]
e=dict(status='running',source=source,commands=[]);path=out/'evidence.json';env=dict(os.environ,CARGO_TARGET_DIR='/private/tmp/zstdoxide-ultra-support-target',CARGO_BUILD_JOBS='2')
for label,argv,expected in rows:
 log=out/'logs'/(label+'.log');t=time.monotonic()
 with log.open('xb') as f:p=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 e['commands'].append(dict(label=label,argv=argv,expected_exit=expected,exit_code=p.returncode,seconds=time.monotonic()-t,log={'path':str(log.relative_to(out)),'bytes':log.stat().st_size,'sha256':sha(log)}));path.write_text(json.dumps(e,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode!=expected:raise ValueError('unexpected support outcome')
if {n:sha(root/n) for n in names}!=source:raise ValueError('source changed')
e.update(status='passed',source_unchanged=True,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),qualification='Inventory and allocator checks passed; the deliberately nonzero require-complete result preserves the unfinished official migration obligation.');path.write_text(json.dumps(e,indent=2)+'\n')
