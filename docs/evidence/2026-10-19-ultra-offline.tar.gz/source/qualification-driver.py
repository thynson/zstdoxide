import datetime,hashlib,json,subprocess,time
from pathlib import Path
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/private/tmp/ultra-offline-checks');O.mkdir();(O/'logs').mkdir();(O/'source').mkdir()
names=['scripts/check_reference_admission_v7.py','scripts/check_ultra_interop_recipes.py','scripts/check_ultra_scalar_fixture.py','scripts/check_ultra_frequency_fixture.py','scripts/check_ultra_path_offline.py','scripts/check_ultra_frame_baseline.py']
source={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for base in ['scripts','tests/fixtures/reference-ultra-frame-baseline']:
 for p in (R/base).rglob('*'):
  if p.is_file() and (p.suffix in ['.py','.sh','.bin','.json']):
   n=str(p.relative_to(R));source[n]=sha(p);d=O/'source'/n;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(p.read_bytes())
(O/'source/qualification-driver.py').write_bytes(Path(__file__).read_bytes())
e=dict(status='running',source=source,commands=[])
def save():(O/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
save()
plan=[('shell-syntax',['sh','-n','scripts/check.sh'])]
for mode,flags in [('normal',[]),('optimized',['-O'])]:
 for n in names:plan.append((mode+'-'+Path(n).stem,['python3','-B',*flags,n,*(['--check'] if n in names[:2] else [])]))
for label,argv in plan:
 p=O/'logs'/(label+'.log');t=time.monotonic()
 with p.open('xb') as f:r=subprocess.run(argv,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 e['commands'].append(dict(label=label,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-t,log=dict(path=str(p.relative_to(O)),bytes=p.stat().st_size,sha256=sha(p))));save();print(label,r.returncode,flush=True)
 if r.returncode:raise ValueError(label)
if any(sha(R/n)!=h for n,h in source.items()):raise ValueError('source changed')
e.update(status='passed',source_unchanged=True,qualification='Six added read-only offline checks pass in normal and optimized Python, plus shell syntax. This is not a fresh execution of the entire historical check.sh matrix.');save()
