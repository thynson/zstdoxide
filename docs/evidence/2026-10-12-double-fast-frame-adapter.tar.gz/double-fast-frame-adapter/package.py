from pathlib import Path
import hashlib,io,json,re,tarfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-double-fast-frame-adapter-final-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
e=json.loads((OUT/'evidence.json').read_text());assert e['status']=='passed' and e['source_unchanged']
for n,h in e['source'].items():assert sha((ROOT/n).read_bytes())==h,n
for c in e['commands']:
 assert c['exit_code']==0;b=(OUT/c['log']).read_bytes();assert sha(b)==c['log_sha256']
 counts=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)
 if c['label'].startswith('adapter-'):assert counts==[(b'5',b'0',b'0')]
 if c['label'].startswith('baselines-'):assert counts==[(b'7',b'0',b'0'),(b'4',b'0',b'0')]
members={p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()};members['runner.py']=Path('/tmp/check-zstdoxide-double-fast-frame-adapter.py').read_bytes();members['package.py']=Path(__file__).read_bytes()
for n in ['tests/support/double_fast_frame_oracle.rs','src/lib.rs','scripts/pack_double_fast_frame_trajectories.py','tests/fixtures/reference-double-fast-frames/cases.bin','tests/fixtures/reference-double-fast-frames/provenance.json','tests/fixtures/reference-double-fast-frames/README.md','tests/fixtures/reference-double-fast-frames/frames.rs']:members['source/'+n]=(ROOT/n).read_bytes()
report={'date':'2026-10-12','status':'passed','commands':len(e['commands']),'adapter_test_executions':25,'ordinary_recipes_per_configuration':51,'complete_table_transitions_per_configuration':320,'complete_c_frames_decoded_per_configuration':58,'decoded_source_bytes_per_configuration':12382352,'baseline_test_executions':22,'ignored':0,'source':e['source'],'parameter_fixture_sha256':sha((ROOT/'tests/upstream/parameters/queries.tsv').read_bytes()),'scope':'Dependency-free ordinary DoubleFast source/trajectory projection and checked reader, both complete table maps, selected repeat publication and 58 original C frames decoded by the existing Rust decoder. Normal and optimized projection/registry checks. No new C capture, production parser, Miri or timing.','archive':'2026-10-12-double-fast-frame-adapter.tar.gz'}
report['bootstrap_correction']='All initial Rust tests passed. Strict Clippy rejected the generated tuple-array type complexity; a named FrameFiles alias corrected it without changing any oracle bytes. The initial diagnostics and complete final checks are retained.'
for p in Path('/tmp/zstdoxide-double-fast-frame-adapter-2026-10-12').iterdir():
 if p.is_file():members['initial/'+p.name]=p.read_bytes()
members['bootstrap.log']=Path('/tmp/zstdoxide-double-fast-frame-adapter-bootstrap.log').read_bytes()
members['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();members['bundle-manifest.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},sort_keys=True,indent=2)+'\n').encode()
a=ROOT/'docs/evidence'/report['archive'];assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('double-fast-frame-adapter/'+n);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 assert set(t.getnames())=={'double-fast-frame-adapter/'+n for n in members}
 for n,b in members.items():assert t.extractfile('double-fast-frame-adapter/'+n).read()==b
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(members));(ROOT/'docs/evidence/2026-10-12-double-fast-frame-adapter.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(len(e['commands']),'commands;',len(members),'archive members')
