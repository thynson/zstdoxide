from pathlib import Path
import json,hashlib,subprocess,os,time,shutil,concurrent.futures
D=Path(__file__).parent;S=D/'component';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();subprocess.run(['cargo','generate-lockfile','--offline'],cwd=S,check=True)
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};e=dict(status='running',source=source,commands=[]);env={**os.environ,'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,cwd=S,extra=None):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=cwd,env={**env,'CARGO_TARGET_DIR':str(D/'host-target'),**(extra or {})},stdout=f,stderr=subprocess.STDOUT)
 row=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log')));assert p.returncode==0,(label,(D/(label+'.log')).read_text());print(label,'passed',flush=True)
 if label.endswith('-test') or label.startswith('miri-'):assert '4 passed; 0 failed; 0 ignored' in (D/(label+'.log')).read_text(),label
 return row
save()
try:
 for name,flags in [('safe',[]),('unsafe',['--features','unsafe-frame-sink'])]:
  for kind,args in [('test',['cargo','test','--lib']),('core',['cargo','check','--lib']),('clippy',['cargo','clippy','--lib','--tests'])]:
   e['commands'].append(run(name+'-'+kind,[*args,'--offline','--locked',*flags,*(['--','-D','warnings'] if kind=='clippy' else [])]));save()
 def interpret(target,suffix):
  rows=[]
  for name,flags in [('safe',[]),('unsafe',['--features','unsafe-frame-sink'])]:
   rows.append(run('miri-'+suffix+'-'+name,['cargo','miri','test','--offline','--locked','--lib','--target',target,*flags],extra={'CARGO_TARGET_DIR':str(D/('miri-'+suffix)),'MIRI_SYSROOT':'/private/tmp/zstdoxide-ultra-miri-'+suffix,'MIRIFLAGS':'-Zmiri-strict-provenance'}))
  return rows
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  fs=[pool.submit(interpret,t,s) for t,s in [('i686-unknown-linux-gnu','i686'),('s390x-unknown-linux-gnu','s390x')]]
  for f in concurrent.futures.as_completed(fs):e['commands']+=f.result();save()
 P=D/'probe';shutil.copytree(S,P)
 with (P/'src/lib.rs').open('a') as f:f.write('\n#[inline(never)]\npub fn frame_sink_codegen_probe(output: &mut [u8], source: &[u8]) -> core::result::Result<usize,error::Error> { let mut sink = frame_sink::FrameSink::new(output);sink.append(source)?;Ok(sink.len()) }\n')
 e['probe_sha256']=sha(P/'src/lib.rs')
 for name,flags in [('safe',[]),('unsafe',['--features','unsafe-frame-sink'])]:
  args=['--offline','--locked','-Zbuild-std=core','--target','thumbv6m-none-eabi','--no-default-features','--lib',*flags];e['commands'].append(run('thumb-'+name+'-check',['cargo','check',*args],extra={'CARGO_TARGET_DIR':str(D/'thumb-check')}));save();target=D/('thumb-'+name);e['commands'].append(run('thumb-'+name+'-objects',['cargo','rustc','--release',*args,'--','--emit=llvm-ir,obj'],P,{'CARGO_TARGET_DIR':str(target)}));save()
  ir=[p for p in target.rglob('*.ll') if any(line.startswith(b'define ') and b'frame_sink_codegen_probe' in line for line in p.read_bytes().splitlines())];assert len(ir)==1 and b'llvm.memcpy' in ir[0].read_bytes() and b'__rust_alloc' not in ir[0].read_bytes();objects=list(ir[0].parent.glob('*.o'));assert objects
  for p in [ir[0],*objects]:
   if p.suffix=='.o':
    h=p.read_bytes()[:20];assert h[:6]==b'\x7fELF\x01\x01' and int.from_bytes(h[18:20],'little')==40
   q=D/'artifacts'/(name+'-'+p.name);q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q)
 e['commands'].append(run('format',['cargo','fmt','--all','--','--check']));save()
 for n,h in source.items():assert sha(S/n)==h,n
 assert len(e['commands'])==15;e.update(status='passed',qualification='Isolated proposed frame-sink leaf only: safe/unsafe host tests, core-only compilation, strict Clippy, four exact4-test i686/s390x strict-provenance Miri runs, concrete core-only ARM copies and formatting. Source-independent checked numeric helper covers overflow without fabricated huge slices. No complete codec integration, feature matrix, compression framing or benchmark claim. Source module is frozen for subsequent integration.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
