from pathlib import Path
import json,hashlib,tarfile,datetime
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=json.loads((D/'evidence.json').read_text());assert j['status']=='passed' and len(j['commands'])==15
for n,h in j['source'].items():assert sha(D/'component'/n)==h,n
for c in j['commands']:assert c['exit_code']==0 and sha(D/(c['label']+'.log'))==c['log_sha256']
files={str(p.relative_to(D)):p for p in D.rglob('*') if p.is_file() and not any(part in ['host-target','miri-i686','miri-s390x','thumb-check','thumb-safe','thumb-unsafe','__pycache__'] for part in p.relative_to(D).parts)}
A=Path('/private/tmp/module33-archives');A.mkdir();name='2026-10-27-frame-sink-component';archive=A/(name+'.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
e=dict(status='passed',scope='isolated-component-only',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),evidence=j,source=j['source'],members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()},archive=archive.name,archive_sha256=sha(archive),qualification='Proposed checked frame-sink leaf only. Full codec integration, framing, API, allocation/interoperability/corpus gates, every-feature full/release matrix and safe/unsafe measurements remain unexecuted. Do not mark Module33 complete or promote production before Module32 closure.')
(A/(name+'.json')).write_text(json.dumps(e,indent=2)+'\n');print(name,archive.stat().st_size)
