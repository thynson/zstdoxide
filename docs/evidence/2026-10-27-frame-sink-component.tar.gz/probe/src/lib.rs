#![no_std]
#![cfg_attr(not(feature = "unsafe-frame-sink"), forbid(unsafe_code))]
// This component validates the exact proposed leaf in isolation. Full codec
// integration and feature qualification are separate gates.
#[allow(dead_code)]
mod error;
#[allow(dead_code)]
mod frame_sink;
use error::{Error, Result};
#[cfg(test)]
extern crate alloc;

#[inline(never)]
pub fn frame_sink_codegen_probe(output: &mut [u8], source: &[u8]) -> core::result::Result<usize,error::Error> { let mut sink = frame_sink::FrameSink::new(output);sink.append(source)?;Ok(sink.len()) }
