; ModuleID = 'zstdoxide_frame_sink_check.3962bbbc1e81f9d0-cgu.0'
source_filename = "zstdoxide_frame_sink_check.3962bbbc1e81f9d0-cgu.0"
target datalayout = "e-m:e-p:32:32-Fi8-i64:64-v128:64:128-a:0:32-n32-S64"
target triple = "thumbv6m-unknown-none-eabi"

@alloc_bdac395b1457309b01119d6ee7241f45 = private unnamed_addr constant [23 x i8] c"invalid codec parameter", align 1, !guid !0
@alloc_a831c82912810798379f6d40f5aa0bba = private unnamed_addr constant [27 x i8] c"invalid codec context state", align 1, !guid !1
@alloc_7b392dc8ea31c8e6782cf57e8779c179 = private unnamed_addr constant [23 x i8] c"unexpected end of input", align 1, !guid !2
@alloc_ac0217ade07e90bc94cc456679817822 = private unnamed_addr constant [19 x i8] c"invalid frame magic", align 1, !guid !3
@alloc_7ff98b587660cdced76113da7cb03293 = private unnamed_addr constant [22 x i8] c"corrupt Zstandard data", align 1, !guid !4
@alloc_d54e75b67645a5578e757e031fa62642 = private unnamed_addr constant [24 x i8] c"a dictionary is required", align 1, !guid !5
@alloc_235b61828294feeeb2172ca04092afbd = private unnamed_addr constant [28 x i8] c"invalid Zstandard dictionary", align 1, !guid !6
@alloc_43353d327e5fe4ba2f2a23fb232c29f0 = private unnamed_addr constant [22 x i8] c"dictionary ID mismatch", align 1, !guid !7
@alloc_358d882c88585a0b91bdd46f073d6817 = private unnamed_addr constant [40 x i8] c"insufficient dictionary training samples", align 1, !guid !8
@alloc_46538b36b8c48fbfe6a4f94227e7fbd0 = private unnamed_addr constant [29 x i8] c"unsupported Zstandard feature", align 1, !guid !9
@alloc_d1b0c6bc606a538edf406f6115094080 = private unnamed_addr constant [23 x i8] c"resource limit exceeded", align 1, !guid !10
@alloc_afc2a81fe13a0b3a87a4890cf54edc49 = private unnamed_addr constant [17 x i8] c"allocation failed", align 1, !guid !11
@alloc_959af6a03cd01ca999bfcd6a252429f4 = private unnamed_addr constant [27 x i8] c"frame content size mismatch", align 1, !guid !12
@alloc_d644fd8040ac32617306136b0f3eecf4 = private unnamed_addr constant [23 x i8] c"frame checksum mismatch", align 1, !guid !13
@switch.table._RNvXNtCs4VsGhyqbhKu_26zstdoxide_frame_sink_check5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt = private unnamed_addr constant [14 x i8] c"\17\1B\17\13\16\18\1C\16(\1D\17\11\1B\17", align 4, !guid !14
@switch.table._RNvXNtCs4VsGhyqbhKu_26zstdoxide_frame_sink_check5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt.1 = private unnamed_addr constant [14 x ptr] [ptr @alloc_bdac395b1457309b01119d6ee7241f45, ptr @alloc_a831c82912810798379f6d40f5aa0bba, ptr @alloc_7b392dc8ea31c8e6782cf57e8779c179, ptr @alloc_ac0217ade07e90bc94cc456679817822, ptr @alloc_7ff98b587660cdced76113da7cb03293, ptr @alloc_d54e75b67645a5578e757e031fa62642, ptr @alloc_235b61828294feeeb2172ca04092afbd, ptr @alloc_43353d327e5fe4ba2f2a23fb232c29f0, ptr @alloc_358d882c88585a0b91bdd46f073d6817, ptr @alloc_46538b36b8c48fbfe6a4f94227e7fbd0, ptr @alloc_d1b0c6bc606a538edf406f6115094080, ptr @alloc_afc2a81fe13a0b3a87a4890cf54edc49, ptr @alloc_959af6a03cd01ca999bfcd6a252429f4, ptr @alloc_d644fd8040ac32617306136b0f3eecf4], align 4, !guid !15

; zstdoxide_frame_sink_check::frame_sink_codegen_probe
; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite)
define dso_local void @_RNvCs4VsGhyqbhKu_26zstdoxide_frame_sink_check24frame_sink_codegen_probe(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([8 x i8]) align 4 captures(none) dereferenceable(8) initializes((0, 1)) %_0, ptr noalias nofree noundef nonnull writeonly captures(none) %output.0, i32 noundef range(i32 0, -2147483648) %output.1, ptr noalias nofree noundef nonnull readonly captures(none) %source.0, i32 noundef range(i32 0, -2147483648) %source.1) unnamed_addr #0 !guid !18 {
bb2.i.i:
  %_10.i.i = icmp samesign ugt i32 %source.1, %output.1
  br i1 %_10.i.i, label %bb4, label %bb7.i, !prof !19

bb7.i:                                            ; preds = %bb2.i.i
  %0 = icmp eq i32 %source.1, 0
  br i1 %0, label %bb5, label %bb3.i

bb3.i:                                            ; preds = %bb7.i
  tail call void @llvm.memcpy.p0.p0.i32(ptr nonnull align 1 %output.0, ptr nonnull readonly align 1 %source.0, i32 range(i32 0, -2147483648) %source.1, i1 false), !noalias !20
  br label %bb5

bb4:                                              ; preds = %bb2.i.i
  %1 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %1, align 1
  br label %bb3

bb5:                                              ; preds = %bb3.i, %bb7.i
  %2 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %source.1, ptr %2, align 4
  br label %bb3

bb3:                                              ; preds = %bb4, %bb5
  %storemerge = phi i8 [ 0, %bb5 ], [ 1, %bb4 ]
  store i8 %storemerge, ptr %_0, align 4
  ret void
}

; <zstdoxide_frame_sink_check::error::Error as core::fmt::Display>::fmt
; Function Attrs: nounwind
define dso_local noundef zeroext i1 @_RNvXNtCs4VsGhyqbhKu_26zstdoxide_frame_sink_check5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt(ptr noalias nofree noundef readonly captures(none) dereferenceable(1) %self, ptr noalias nofree noundef align 4 dereferenceable(16) %f) unnamed_addr #1 !guid !23 {
start:
  %0 = load i8, ptr %self, align 1, !range !24, !noundef !25
  %1 = zext nneg i8 %0 to i32
  %switch.gep = getelementptr inbounds nuw i8, ptr @switch.table._RNvXNtCs4VsGhyqbhKu_26zstdoxide_frame_sink_check5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt, i32 %1
  %switch.load = load i8, ptr %switch.gep, align 1
  %switch.ext = zext i8 %switch.load to i32
  %2 = zext nneg i8 %0 to i32
  %switch.gep2 = getelementptr inbounds nuw [4 x i8], ptr @switch.table._RNvXNtCs4VsGhyqbhKu_26zstdoxide_frame_sink_check5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt.1, i32 %2
  %switch.load3 = load ptr, ptr %switch.gep2, align 4
; call <core::fmt::Formatter>::write_str
  %_0 = tail call noundef zeroext i1 @_RNvMsa_NtCsavDHSl9k1eG_4core3fmtNtB5_9Formatter9write_str(ptr noalias nofree noundef nonnull align 4 dereferenceable(16) %f, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %switch.load3, i32 noundef %switch.ext) #3
  ret i1 %_0
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i32, i1 immarg) #2

; <core::fmt::Formatter>::write_str
; Function Attrs: nounwind
declare dso_local noundef zeroext i1 @_RNvMsa_NtCsavDHSl9k1eG_4core3fmtNtB5_9Formatter9write_str(ptr noalias nofree noundef align 4 dereferenceable(16), ptr noalias nofree noundef nonnull readonly captures(address, read_provenance), i32 noundef) unnamed_addr #1

attributes #0 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #1 = { nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nounwind }

!llvm.module.flags = !{!16}
!llvm.ident = !{!17}

!0 = !{i64 8911475142346841042}
!1 = !{i64 524581327071361669}
!2 = !{i64 1733228200632682613}
!3 = !{i64 1814633999438172692}
!4 = !{i64 -2955587119118774756}
!5 = !{i64 4780753528470964461}
!6 = !{i64 6644015054982791458}
!7 = !{i64 7628345870535188910}
!8 = !{i64 1366286477095834874}
!9 = !{i64 506633221692048999}
!10 = !{i64 4731559416077410287}
!11 = !{i64 5311478713390580358}
!12 = !{i64 -1201172796749531053}
!13 = !{i64 1626583506135574139}
!14 = !{i64 5351778676646549854}
!15 = !{i64 4770552231324956201}
!16 = !{i32 7, !"frame-pointer", i32 2}
!17 = !{!"rustc version 1.101.0-nightly (1d81eb4ad 2026-10-07)"}
!18 = !{i64 -523767651082779446}
!19 = !{!"branch_weights", i32 2002, i32 2000}
!20 = !{!21}
!21 = distinct !{!21, !22, !"_RNvMNtCs4VsGhyqbhKu_26zstdoxide_frame_sink_check10frame_sinkNtB2_9FrameSink6append: %self"}
!22 = distinct !{!22, !"_RNvMNtCs4VsGhyqbhKu_26zstdoxide_frame_sink_check10frame_sinkNtB2_9FrameSink6append"}
!23 = !{i64 -8933804592239854911}
!24 = !{i8 0, i8 14}
!25 = !{}
