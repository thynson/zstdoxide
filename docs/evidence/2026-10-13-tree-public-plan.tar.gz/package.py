from pathlib import Path
import hashlib,json,io,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda b:hashlib.sha256(b).hexdigest();files={}
for stem in ['tree-admission-check','tree-public-recipes','tree-public-preflight-final']:
 for mode in ['normal','optimized']:
  p=Path('/tmp/zstdoxide-'+stem+'-'+mode+'.log');b=p.read_bytes();assert b and b'Traceback (most recent call last)' not in b;files['logs/'+p.name]=b
  if stem.endswith('final'):r=json.loads(b.splitlines()[-1]);assert r==dict(status='passed',recipes=1197,planned_commands=13606,rejected=18,malformed_packets=39,child_attempts=0)
for mode in ['normal','optimized']:
 p=Path('/tmp/zstdoxide-tree-public-preflight-'+mode+'.log');b=p.read_bytes();assert b'complete no-child rejection coverage' in b;files['logs/'+p.name]=b
names=['scripts/check_reference_admission_v5.py','scripts/oracles/tree_interop.py','scripts/check_tree_interop_recipes.py','scripts/capture_tree_interop.py','scripts/check_tree_interop_capture.py','scripts/check_tree_interop_preflight.py','docs/reference-tree-interop-protocol.md','docs/reference-tree-interop-adapter-review.md']
names += [str(p.relative_to(R)) for d in ['reference-admission-v5','reference-tree-interop-recipes'] for p in sorted((R/'tests/fixtures'/d).iterdir())]
for n in names:files['source/'+n]=(R/n).read_bytes()
report=dict(status='passed',recipes=1197,source_bytes=145529306,classifications=dict(success=1099,resource=49,unsupported=49),historical_requests=886,new_independently_resolved_requests=311,planned_commands=13606,python_modes=['normal','optimized'],preflight_rejections_per_mode=18,malformed_packet_inventory=39,admission_scalar_rejections_per_mode=11,codec_executions=0,child_attempts=0,source_sha256={n:sha((R/n).read_bytes()) for n in names},qualification='Source-only independent tuples, status and frame-equivalence hypotheses; public dispatch and capture remain separate. Initial preflight count expected 18 with only 17 controls; added the missing-manifest control and retained both failed logs. No guard was weakened.')
files['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();files['package.py']=Path(__file__).read_bytes();a=R/'docs/evidence/2026-10-13-tree-public-plan.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:assert {m.name:t.extractfile(m).read() for m in t}==files
report.update(archive=a.name,archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()));(R/'docs/evidence/2026-10-13-tree-public-plan.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(a.name,a.stat().st_size)
