"""Archive the qualified Module38 feature/release matrix."""
from pathlib import Path
import json, hashlib, tarfile, datetime, shutil

C = Path('/private/tmp/module38-matrix')
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
j = json.loads((C / 'evidence.json').read_text())
assert j['status'] == 'complete' and len(j['commands']) == 75
for r in j['commands']:
    assert r['exit_code'] == 0 and sha(C / (r['label'] + '.log')) == r['log_sha256']
for n, h in j['source'].items():
    assert sha(R / n) == h, n
files = {}
for p in C.rglob('*'):
    if not p.is_file():
        continue
    n = p.relative_to(C)
    if 'source' in n.parts or 'target' in n.parts or '__pycache__' in n.parts:
        continue
    if p.suffix in {'.json', '.py', '.log'}:
        files[str(n)] = p
files['archive-matrix.py'] = Path(__file__)
name = '2026-11-03-compiled-streaming-feature-matrix'
archive = C / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
receipt = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               source=j['source'], features=j['features'], expected_counts=j['expected_counts'],
               commands=j['commands'], members={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()},
               archive=archive.name, archive_sha256=sha(archive), qualification=j['qualification'])
p = C / (name + '.json')
p.write_text(json.dumps(receipt, indent=2) + '\n')
for q in [p, archive]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
print(name, archive.stat().st_size)
