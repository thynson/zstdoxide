"""Module38 final matrix: safe/all and every isolated feature, release, format."""
from pathlib import Path
import datetime, hashlib, json, os, re, shutil, signal, subprocess, time, tomllib

D = Path('/private/tmp/module38-matrix')
S = D / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not S.exists()
shutil.copytree('/Users/lanxingcan/Workspace/zstdoxize', S,
                ignore=shutil.ignore_patterns('.git', 'target', 'SESSION_HANDOFF.md'))
deadline = datetime.datetime.now(datetime.timezone.utc).timestamp() + 8 * 3600
assert not (D / 'evidence.json').exists()
COUNTS = (125, 1848, 79)
features = sorted(f for f in tomllib.loads((S / 'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'))
assert len(features) == 22, features
source = {str(p.relative_to(S)): sha(p) for folder in ['src', 'tests', 'test-support'] for p in (S / folder).rglob('*') if p.is_file()}
source.update({n: sha(S / n) for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']})
plan = []
for name, flags in [('safe', []), ('all', ['--all-features'])] + [(f, ['--features', f]) for f in features]:
    plan.append((name + '-full', ['cargo', 'test', '--offline', '--locked', *flags]))
    plan.append((name + '-no-std', ['cargo', 'check', '--offline', '--locked', '--lib', '--no-default-features', *flags]))
    plan.append((name + '-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--tests', *flags, '--', '-D', 'warnings']))
plan += [('safe-release', ['cargo', 'test', '--offline', '--locked', '--release']),
         ('all-release', ['cargo', 'test', '--offline', '--locked', '--release', '--all-features']),
         ('format', ['cargo', 'fmt', '--all', '--', '--check'])]
assert len(plan) == 75
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         deadline_utc=datetime.datetime.fromtimestamp(deadline, datetime.timezone.utc).isoformat(),
         features=features, source=source, expected_counts=list(COUNTS), commands=[], plan=plan,
         qualification='Full feature/release regression of the Module38 final source. Safe/all and all 22 isolated unsafe features run complete tests, true no_std and strict Clippy; safe/all release and formatting also run. Every full/release suite must report the predeclared group/passed/ignored counts with zero failures; ignored tests are not credited. No milestone completion, repository integration or performance claim.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(D / 'target'), 'CARGO_BUILD_JOBS': '6',
       'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
       'CARGO_PROFILE_DEV_DEBUG': '0'}


def counts(text):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert rows and all(int(f) == 0 for _, f, _ in rows), 'A test group failed'
    return len(rows), sum(int(p) for p, _, _ in rows), sum(int(i) for _, _, i in rows)


def save():
    p = D / 'evidence.pending.json'
    p.write_text(json.dumps(e, indent=2) + '\n')
    p.replace(D / 'evidence.json')


save()
try:
    for label, args in plan:
        remaining = deadline - time.time() - 30
        if remaining < 30:
            raise TimeoutError('User work window reached before ' + label)
        e['active_command'] = dict(label=label, argv=args, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
        start = time.monotonic()
        log = D / (label + '.log')
        with log.open('xb') as f:
            proc = subprocess.Popen(args, cwd=S, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = proc.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                raise TimeoutError('User work window reached during ' + label)
        row = dict(label=label, argv=args, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
        if label.endswith(('-full', '-release')) and code == 0:
            result = counts(log.read_text())
            assert result == COUNTS, (label, result)
            row.update(result_groups=result[0], passed=result[1], ignored=result[2])
        e['commands'].append(row)
        e.pop('active_command', None)
        save()
        print(label, code, flush=True)
        assert code == 0, label
    for n, h in source.items():
        assert sha(S / n) == h, ('Final source changed during matrix', n)
    assert len(e['commands']) == 75
    e['status'] = 'complete'
    e['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print('complete', flush=True)
except BaseException as error:
    e['status'] = 'failed'
    e['error'] = repr(error)
    save()
    raise
