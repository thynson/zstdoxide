from pathlib import Path
import hashlib,json,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-frame-recipes-checks');O.mkdir();paths=['scripts/oracles/tree_frames.py','scripts/check_tree_frame_recipes.py','tests/fixtures/reference-tree-frame-recipes/recipes.json','docs/reference-tree-frame-oracle.md'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths};rows=[]
for label,flags in [('normal',[]),('optimized',['-O'])]:
 args=['python3',*flags,'scripts/check_tree_frame_recipes.py'];start=time.monotonic();p=subprocess.run(args,cwd=R,capture_output=True,timeout=60);log=O/(label+'.log');b=p.stdout+p.stderr;log.write_bytes(b);rows.append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest()))
 if p.returncode or b'Tree ordinary recipes: 245 sources, 22 malformed controls rejected' not in b:raise ValueError(label)
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,recipes=245,malformed_rejections=44,qualification='Source-only protocol/recipe freeze before C execution; hypotheses are not observed parser behavior.'),sort_keys=True,indent=2)+'\n')
