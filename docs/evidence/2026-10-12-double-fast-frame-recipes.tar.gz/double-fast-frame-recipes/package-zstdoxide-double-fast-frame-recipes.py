from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize')
def sha(b):return hashlib.sha256(b).hexdigest()
members={}
for mode in ['normal','optimized']:
 folder=Path('/tmp/zstdoxide-double-fast-frame-recipes-'+mode+'-2026-10-12')
 report=json.loads((folder/'report.json').read_bytes());assert report['status']=='passed' and report['positive']==2 and report['rejected']==39
 for p in folder.iterdir():
  if p.is_file():members[mode+'/'+p.name]=p.read_bytes()
 members[mode+'/runner.log']=Path('/tmp/zstdoxide-double-fast-frame-recipes-'+mode+'.log').read_bytes()
for name in ['docs/reference-double-fast-frame-oracle.md','scripts/oracles/double_fast_frames.py','scripts/check_double_fast_frame_recipes.py','tests/fixtures/reference-double-fast-frame-recipes/recipes.json','tests/fixtures/reference-double-fast-frame-recipes/README.md']:
 members['source/'+name]=(R/name).read_bytes()
for name in ['check-zstdoxide-double-fast-frame-recipe-controls.py','package-zstdoxide-double-fast-frame-recipes.py']:
 members[name]=(Path('/tmp')/name).read_bytes()
report={'date':'2026-10-12','status':'passed','scope':'Ordinary DoubleFast protocol and source-only input hypotheses before C execution. No frame outcomes, parser changes, fresh codec tests or timing.',
 'recipes':51,'source_bytes':6348944,'scheduled_calls':164,'positive_calls':160,'aligned_whole_comparisons_requested':7,'incomplete_header_probes':13,
 'controls_per_mode':{'positive':2,'rejected':39},'modes':['normal','optimized'],
 'manifest_sha256':sha((R/'tests/fixtures/reference-double-fast-frame-recipes/recipes.json').read_bytes()),
 'generator_sha256':sha((R/'scripts/oracles/double_fast_frames.py').read_bytes()),'archive':'2026-10-12-double-fast-frame-recipes.tar.gz'}
members['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode()
members['bundle-manifest.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},sort_keys=True,indent=2)+'\n').encode()
a=R/'docs/evidence'/report['archive'];assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('double-fast-frame-recipes/'+n);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 assert set(t.getnames())=={'double-fast-frame-recipes/'+n for n in members}
 for n,b in members.items():assert t.extractfile('double-fast-frame-recipes/'+n).read()==b
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(members))
(R/'docs/evidence/2026-10-12-double-fast-frame-recipes.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(len(members),'archive members')
