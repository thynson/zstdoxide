from pathlib import Path
Path('/tmp/zstdoxide-double-fast-frame-recipes-optimized-2026-10-12/executed').write_text("bad")
