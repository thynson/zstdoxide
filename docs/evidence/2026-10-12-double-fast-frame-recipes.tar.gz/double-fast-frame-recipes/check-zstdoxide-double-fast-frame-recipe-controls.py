from pathlib import Path
from dataclasses import replace
import hashlib,json,sys
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(ROOT/'scripts'))
import check_double_fast_frame_recipes as check
OUT=Path(sys.argv[1]);OUT.mkdir(exist_ok=False)
checks=[]
def run(name,operation,rejected=True):
 try:operation()
 except (ValueError,TypeError) as e:
  if not rejected:raise
  checks.append({'name':name,'rejected':True,'reason':str(e)})
 else:
  if rejected:raise RuntimeError('accepted '+name)
  checks.append({'name':name,'rejected':False})
run('original-manifest',lambda:check.check(check.MANIFEST),False)
f=check.load_generator();base=f.Recipe('valid',b'a'*32,(32,),'Bounded positive source.')
run('valid-recipe',base.metadata,False)
for name,updates in [
 ('empty-name',{'name':''}),('name-alphabet',{'name':'a/b'}),('name-cap',{'name':'a'*64}),
 ('source-type',{'source':bytearray(b'a'*32)}),('source-cap',{'source':b'a'*((4<<20)+1)}),
 ('empty-hypothesis',{'hypothesis':''}),('hypothesis-cap',{'hypothesis':'a'*257}),
 ('schedule-type',{'schedule':[32]}),('schedule-count',{'schedule':(0,)*65+(32,)}),
 ('negative-call',{'schedule':(-1,33)}),('boolean-call',{'source':b'a','schedule':(True,)}),
 ('uncovered-source',{'schedule':(31,)}),('call-beyond-extent',{'schedule':(33,)}),
 ('whole-flag-type',{'whole_compare':1}),('unaligned-whole',{'schedule':(1,31),'whole_compare':True}),
 ('window-block-cap',{'source':b'a'*2048,'schedule':(2048,),'window_log':10}),
]:run(name,lambda u=updates:replace(base,**u).metadata())
for name,low,high in [('window_log',10,21),('long_log',6,18),('short_log',6,18),('search_log',1,29),('min_match',3,7),('target',0,131072)]:
 for suffix,value in [('low',low-1),('high',high+1),('boolean',True)]:
  run(name+'-'+suffix,lambda n=name,v=value:replace(base,**{n:v}).metadata())
for name,data in [('duplicate',b'{"x":1,"x":2}'),('nan',b'{"x":NaN}'),('infinity',b'{"x":Infinity}')]:
 run(name,lambda d=data:check.decode(d))
value=json.loads(check.MANIFEST.read_bytes());value['recipes'][0]['source_bytes']=1
forged=OUT/'forged.json';forged.write_text(json.dumps(value))
run('changed-manifest',lambda:check.check(forged))
generator=OUT/'generator.py';marker=OUT/'executed';generator.write_text('from pathlib import Path\nPath('+repr(str(marker))+').write_text("bad")\n')
original=check.GENERATOR;check.GENERATOR=generator
try:run('generator-before-import',check.load_generator)
finally:check.GENERATOR=original
if marker.exists():raise RuntimeError('forged generator executed')
report={'status':'passed','optimized':not __debug__,'positive':sum(not c['rejected'] for c in checks),'rejected':sum(c['rejected'] for c in checks),'controls':checks,'generator_sha256':check.GENERATOR_SHA256,'manifest_sha256':check.MANIFEST_SHA256}
(OUT/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(report['positive'],'positive;',report['rejected'],'rejected')
