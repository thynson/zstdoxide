from pathlib import Path
import hashlib,json,subprocess,sys,time,tomllib
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-double-fast-parse-miri-i686-2026-10-12');OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'scripts'));import benchmark_search
ENV=benchmark_search.effective_environment()|{'CARGO_TARGET_DIR':'/tmp/zstdoxide-double-fast-miri-target','CARGO_NET_OFFLINE':'true','CARGO_TERM_COLOR':'never','MIRIFLAGS':'-Zmiri-strict-provenance','MIRI_SYSROOT':'/tmp/zstdoxide-platform-sysroot-i686'}
paths=list((ROOT/'src').rglob('*.rs'))+[ROOT/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/reference_fast_defaults.rs','tests/match_search_defaults.rs','tests/support/double_fast_oracle.rs','tests/fixtures/reference-double-fast/cases.bin','tests/fixtures/reference-double-fast/provenance.json']]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source():return {str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}
e={'date':'2026-10-12','status':'running','interpretation':'i686 strict-provenance Miri interpretation with an existing external sysroot; not native execution or a full suite.', 'scope':'Private no-dictionary DoubleFast single-block parsing against 184 frozen direct cases with exact and extended source slices, both complete tables, full sequences/literals/repeats, invalid candidates and allocation failure preservation. No public encoding, ordinary publication, new C capture, timing or Miri execution.','source':source(),'environment':ENV,'commands':[]}
def save():(OUT/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
def run(label,args):
 start=time.monotonic();p=OUT/(label+'.log')
 with p.open('wb') as f:r=subprocess.run(args,cwd=ROOT,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 e['commands'].append({'label':label,'argv':args,'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':p.name,'log_sha256':sha(p)});save();print(label,r.returncode,flush=True)
 if r.returncode:raise RuntimeError(label)
cargo=['cargo','+nightly-2026-10-08'];flags=[x for x in tomllib.loads((ROOT/'Cargo.toml').read_text())['features'] if x not in ['default','std']]
try:
 run('version',['cargo','+nightly-2026-10-08','miri','--version'])
 for name,features in [('safe',[]),('table',['--features','unsafe-match-table'])]:
  for test in ['out_of_range_future_and_expired_candidates_are_rejected_before_reads','either_output_reserve_failure_preserves_logical_state_and_exact_owners']:
   run(name+'-'+test,cargo+['miri','test','--target','i686-unknown-linux-gnu','--offline','--locked','--lib','double_fast_parse::tests::'+test]+features+['--','--exact'])
 e['source_unchanged']=source()==e['source'];assert e['source_unchanged'];e['status']='passed';save()
except BaseException as error:e['status']='failed';e['error']=repr(error);save();raise
