from pathlib import Path
import hashlib,io,json,re,tarfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize')
NATIVE=Path('/tmp/zstdoxide-double-fast-parse-2026-10-12')
MIRI=Path('/tmp/zstdoxide-double-fast-parse-miri-i686-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
native=json.loads((NATIVE/'evidence.json').read_bytes());miri=json.loads((MIRI/'evidence.json').read_bytes())
assert native['source']==miri['source']
members={}
for kind,folder,e in [('native',NATIVE,native),('miri-i686',MIRI,miri)]:
 assert e['status']=='passed' and e['source_unchanged']
 for name,digest in e['source'].items():assert sha((ROOT/name).read_bytes())==digest,name
 for c in e['commands']:
  assert c['exit_code']==0
  b=(folder/c['log']).read_bytes();assert sha(b)==c['log_sha256']
  counts=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)
  if c['label'].startswith('parse-'):assert counts==[(b'5',b'0',b'0')]
  if c['label'].startswith('baselines-'):assert counts==[(b'7',b'0',b'0'),(b'4',b'0',b'0')]
  if kind=='miri-i686' and c['label']!='version':assert counts==[(b'1',b'0',b'0')]
 for p in folder.iterdir():
  if p.is_file():members[kind+'/'+p.name]=p.read_bytes()
# Preserve initial diagnostics instead of replacing them with successful logs.
for p in Path('/tmp/zstdoxide-double-fast-parse-miri-2026-10-12').iterdir():
 if p.is_file():members['initial-native-miri/'+p.name]=p.read_bytes()
members['initial-parser.log']=Path('/tmp/zstdoxide-double-fast-parse-bootstrap.log').read_bytes()
for name in ['check-zstdoxide-double-fast-parse.py','check-zstdoxide-double-fast-parse-miri.py','package-zstdoxide-double-fast-parse.py']:
 members['runners/'+name]=(Path('/tmp')/name).read_bytes()
for name in ['src/double_fast_parse.rs','src/double_fast_block.rs','src/double_fast_tables.rs','src/lib.rs','tests/support/double_fast_oracle.rs','tests/fixtures/reference-double-fast/cases.bin','tests/fixtures/reference-double-fast/provenance.json']:
 members['source/'+name]=(ROOT/name).read_bytes()
report={'date':'2026-10-12','status':'passed','native_commands':13,'native_parser_test_executions':25,'baseline_test_executions':22,'miri_commands':5,'miri_test_executions':4,'ignored':0,'source':native['source'],
 'direct_cases':184,'source_views_per_case':2,'parser_calls_per_configuration':368,'complete_table_comparisons_per_configuration':736,
 'miri_scope':'Two bounded parser tests interpreted on i686 under strict provenance, safe and unsafe-match-table. Uses the previously prepared external sysroot. Not native i686 or complete algorithm/platform coverage.',
 'scope':'Private no-dictionary single-block DoubleFast. Complete sequences, literal bytes, intent/repeats and both final tables agree with frozen C observations. Both reservation failures preserve logical outputs and tables. No ordinary frame publication, public encoding, fresh C capture or timing.',
 'initial_diagnostics':['An unused test import and an overstrong positive-leading-literal assertion were corrected. A valid subsequent match may extend backward to the block anchor. All184 frozen C cases already passed in that first bootstrap; their inputs/expected values were unchanged.','Native-host Miri sysroot preparation was denied access to its default user cache before any test ran. Reused the existing external i686 sysroot for the four successful interpreted tests.','The archived Miri runner/evidence inherited a native runner scope sentence saying no Miri execution; its separate interpretation field and exact commands identify the actual i686 execution. This report corrects that stale prose without changing logs, results or source identities.'],
 'archive':'2026-10-12-double-fast-parse.tar.gz'}
members['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode()
members['bundle-manifest.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},sort_keys=True,indent=2)+'\n').encode()
a=ROOT/'docs/evidence'/report['archive'];assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('double-fast-parse/'+n);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 assert set(t.getnames())=={'double-fast-parse/'+n for n in members}
 for n,b in members.items():assert t.extractfile('double-fast-parse/'+n).read()==b
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(members))
(ROOT/'docs/evidence/2026-10-12-double-fast-parse.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print('18 final commands;51 passing test executions;',len(members),'archive members')
