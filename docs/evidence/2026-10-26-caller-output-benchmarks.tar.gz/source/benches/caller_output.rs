//! Direct/owned output comparison. Setup and full-byte checks stay outside clocks.
//! Caller destination allocation is excluded; owned-result allocation/drop is timed.
//! TrackingAllocator is used only for clock-free accounting, never timed samples.
use std::{hint::black_box, time::Instant};
use zstdoxide::{decompress, decompress_in, decompress_into, decompress_into_in};
use zstdoxide_test_allocator::{AllocatorConfig, TrackingAllocator};

fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |hash, byte| {
        (hash ^ u64::from(*byte)).wrapping_mul(0x100000001b3)
    })
}
fn cases() -> Vec<(&'static str, Vec<u8>, Vec<u8>)> {
    let mut cases = Vec::new();
    macro_rules! generated {
        ($name:literal) => {
            cases.push((
                $name,
                include_bytes!(concat!("../tests/upstream/decodecorpus/", $name, ".zst")).to_vec(),
                include_bytes!(concat!("../tests/upstream/decodecorpus/", $name, ".raw")).to_vec(),
            ));
        };
    }
    generated!("mixed-04");
    generated!("raw-07");
    generated!("rle-03");
    generated!("compressed-05");
    generated!("small-blocks-07");
    generated!("large-content-04");
    cases.push((
        "http",
        include_bytes!("../tests/upstream/data/generated/http.zst").to_vec(),
        include_bytes!("../tests/upstream/data/golden-compression/http").to_vec(),
    ));
    cases.push((
        "larger",
        include_bytes!("../tests/upstream/data/generated/huffman-compressed-larger.zst").to_vec(),
        include_bytes!("../tests/upstream/data/golden-compression/huffman-compressed-larger")
            .to_vec(),
    ));
    cases.push((
        "empty",
        vec![0x28, 0xb5, 0x2f, 0xfd, 0x20, 0, 1, 0, 0],
        Vec::new(),
    ));
    let mut frame = cases[0].1.clone();
    frame.extend_from_slice(&cases[3].1);
    let mut original = cases[0].2.clone();
    original.extend_from_slice(&cases[3].2);
    cases.push(("concatenated", frame, original));
    cases
}
fn main() {
    let command = std::env::args().nth(1).expect("qualify or measure");
    assert!(command == "qualify" || command == "measure");
    for (name, frame, source) in cases() {
        let mut output = vec![0xa5; source.len() + 16];
        assert_eq!(decompress_into(&frame, &mut output).unwrap(), source.len());
        assert_eq!(&output[..source.len()], source);
        assert_eq!(&output[source.len()..], &[0xa5; 16]);
        assert_eq!(decompress(&frame, source.len()).unwrap(), source);
        for mode in ["direct", "owned"] {
            if command == "qualify" {
                let allocator = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                let monitor = allocator.monitor();
                if mode == "direct" {
                    assert_eq!(
                        decompress_into_in(&frame, &mut output, allocator).unwrap(),
                        source.len()
                    );
                    assert_eq!(&output[..source.len()], source);
                } else {
                    let decoded = decompress_in(&frame, source.len(), allocator).unwrap();
                    assert_eq!(&decoded[..], source);
                    drop(decoded);
                }
                monitor.assert_released();
                let s = monitor.snapshot();
                assert_eq!(s.identities_created, s.owners_dropped);
                println!(
                    "{name}\t{mode}\t{}\t{:016x}\t{}\t{}\t{}\t{}",
                    source.len(),
                    fingerprint(&source),
                    s.attempts,
                    s.requested_bytes,
                    s.peak_bytes,
                    s.deallocate_calls
                );
            } else {
                let iterations = (1024 * 1024 / source.len().max(1)).clamp(8, 4096);
                for sample in 0..5 {
                    let start = Instant::now();
                    for _ in 0..iterations {
                        if mode == "direct" {
                            black_box(
                                decompress_into(black_box(&frame), black_box(&mut output)).unwrap(),
                            );
                        } else {
                            black_box(
                                decompress(black_box(&frame), black_box(source.len())).unwrap(),
                            );
                        }
                    }
                    let elapsed = start.elapsed().as_nanos();
                    assert_eq!(&output[..source.len()], source);
                    assert_eq!(&output[source.len()..], &[0xa5; 16]);
                    println!("{name}\t{mode}\t{sample}\t{iterations}\t{elapsed}");
                }
            }
        }
    }
}
