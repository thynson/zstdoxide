from pathlib import Path
import argparse,hashlib,json,subprocess,time,datetime
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def validate():
 b=json.loads((D/'evidence.json').read_text())
 assert b['status']=='qualified-not-timed'
 assert len(b['builds'])==22
 for n,h in b['production_source'].items():assert sha(R/n)==h,('production',n)
 for n,h in b['source'].items():assert sha(D/'source'/n)==h,('snapshot',n)
 for row in b['builds']:
  assert sha(D/row['executable'])==row['sha256'],('executable',row['name'])
  assert sha(D/(row['name']+'-qualify.tsv'))==row['qualification_sha256']
  assert (D/(row['name']+'-qualify.tsv')).read_bytes()==(D/'safe-qualify.tsv').read_bytes()
 gates={}
 for label in ['feature-matrix','platform']:
  p=Path('/private/tmp')/('module23-'+label)/'evidence.json';j=json.loads(p.read_text());assert j['status']=='passed',label
  for n,h in b['production_source'].items():assert j['source'][n]==h,(label,n)
  gates[label]=sha(p)
 return b,gates
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--validate-only',action='store_true');args=p.parse_args()
 b,gates=validate()
 if args.validate_only:print('all source, executable, qualification and completed check gates passed');raise SystemExit(0)
 assert not (D/'timed.json').exists(),'fresh timing output'
 e=dict(status='running',gates=gates,build_evidence_sha256=sha(D/'evidence.json'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),runs=[],qualification='Sequential fixed-order timing after task-owned builds/checks completed; this does not assert desktop idleness. Five samples per mode/case; direct caller allocation excluded, owned result allocation and destruction included. Global allocator timed; tracking ledger excluded.')
 def save():(D/'timed.json').write_text(json.dumps(e,indent=2)+'\n')
 save()
 try:
  for row in b['builds']:
   name=row['name'];t=time.monotonic();p=subprocess.run([str(D/row['executable']),'measure'],capture_output=True)
   (D/(name+'-timed.tsv')).write_bytes(p.stdout);(D/(name+'-timed.stderr')).write_bytes(p.stderr)
   assert p.returncode==0,(name,p.stderr)
   lines=p.stdout.decode().splitlines();assert len(lines)==100
   seen=set()
   for line in lines:
    case,mode,sample,iterations,elapsed=line.split('\t');sample=int(sample);iterations=int(iterations);elapsed=int(elapsed)
    assert mode in ['direct','owned'] and 0<=sample<5 and 8<=iterations<=4096 and elapsed>0
    key=(case,mode,sample);assert key not in seen;seen.add(key)
   e['runs'].append(dict(name=name,rows=len(lines),seconds=time.monotonic()-t,sha256=sha(D/(name+'-timed.tsv')),executable_sha256=row['sha256']));save();print(name,'100 samples',flush=True)
  validate();e['status']='passed';save()
 except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
