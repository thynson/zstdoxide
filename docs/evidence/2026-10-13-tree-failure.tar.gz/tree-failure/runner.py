from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-failure-checks');O.mkdir();env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/zstdoxide-tree-reader-target'
paths=sorted((R/'src').glob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock',R/'tests/support/tree_frame_encode.rs'];source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};rows=[]
def run(label,args,tests=None):
 log=O/(label+'.log');start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
 b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest());rows.append(r);print(label,p.returncode,flush=True)
 if tests is not None:
  counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)];r['tests']=counts
  if counts!=[tests]:raise ValueError('test totals '+label)
 if p.returncode:raise ValueError(label)
selectors=['reference_frame_encode::tree_tests::every_tree_frame_allocation_failure_releases_exact_owners','reference_frame_encode::tree_tests::late_tree_output_failure_preserves_committed_state_and_poisoned_context','reference_frame_encode::tree_tests::platform_tree_frames_keep_nonclone_owners_and_transactional_boundaries','greedy_state::tests::tree_search_corruption_after_pending_insert_poisons_retained_state']
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree']),('all',['--all-features']),('release-all',['--release','--all-features'])]:
 run('failures-'+name,['cargo','test','--offline','--locked',*flags,'--lib','--','--exact',*selectors,'--test-threads=1'],(4,0,0))
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree'])]:
 run('nostd-'+name,['cargo','check','--offline','--locked','--no-default-features',*flags])
for name,flags in [('safe',[]),('all',['--all-features'])]:
 run('clippy-'+name,['cargo','clippy','--offline','--locked','--all-targets',*flags,'--','-D','warnings'])
run('format',['cargo','fmt','--all','--','--check'])
assert source=={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,tests=16,qualification='Every observed frame allocation ordinal across five input sizes; late output rollback and corrupted retained search poisoning. Includes borrowed non-clone owners. No C frame equality claim.'),sort_keys=True,indent=2)+'\n')
