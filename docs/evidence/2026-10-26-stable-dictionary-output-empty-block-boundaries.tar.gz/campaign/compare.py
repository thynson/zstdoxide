from pathlib import Path
import json,hashlib,subprocess
D=Path(__file__).parent;N=Path('/private/tmp/module25-native');B=Path('/private/tmp/module26-benchmark');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((D/'evidence.json').read_text());build=json.loads((N/'build.json').read_text());records=[]
for backend in ['normal','sanitized']:
 exe=N/('oracle-'+backend);assert sha(exe)==build['executables'][backend]
 for case in base['cases']:
  p=D/(case['name']+'.zst');out=D/('oneshot-'+backend+'-'+case['name']+'.raw');args=[str(exe),str(p),str(D/'empty.dict'),'16',str(out),'using-dict'];r=subprocess.run(args,capture_output=True);assert r.returncode==0;result=json.loads(r.stdout);assert result['guards']==result['suffix']==1;records.append(dict(backend=backend,name=case['name'],argv=args,result=result))
rust=[]
for backend in ['safe','all']:
 rows=[json.loads(line) for line in (B/(backend+'-build.jsonl')).read_text().splitlines() if line.startswith('{')]
 lib=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='zstdoxide' and 'lib' in r['target']['kind']];assert len(lib)==1
 paths=[Path(n) for n in lib[0]['filenames'] if n.endswith(('.rlib','.rmeta'))];assert len(paths)==2,paths
 exe=D/('rust-'+backend);args=['rustc','--edition=2024',str(D/'probe.rs'),'-Dwarnings','-L','dependency='+str(paths[0].parent),*[arg for path in paths for arg in ['--extern','zstdoxide='+str(path)]],'-o',str(exe)]
 p=subprocess.run(args,capture_output=True);(D/(backend+'-build-v2.log')).write_bytes(p.stdout+p.stderr);assert p.returncode==0,p.stderr
 p=subprocess.run([str(exe),*[str(D/(c['name']+'.zst')) for c in base['cases']]],capture_output=True);(D/(backend+'-rust.tsv')).write_bytes(p.stdout);(D/(backend+'-rust.stderr')).write_bytes(p.stderr);assert p.returncode==0,p.stderr
 rust.append(dict(backend=backend,argv=args,libraries={str(p):sha(p) for p in paths},executable_sha256=sha(exe),result_sha256=sha(D/(backend+'-rust.tsv'))))
assert (D/'safe-rust.tsv').read_bytes()==(D/'all-rust.tsv').read_bytes()
(D/'comparison.json').write_text(json.dumps(dict(status='passed',stream_native_evidence_sha256=sha(D/'evidence.json'),oneshot_native_build_sha256=sha(N/'build.json'),oneshot_native=records,rust=rust,probe_sha256=sha(D/'probe.rs'),production_source=json.loads((B/'evidence.json').read_text())['production_source'],qualification='Five hand-encoded empty-block boundaries, native one-shot normal/sanitized with empty raw dictionary, previously hash-bound native stable stream, and source-bound Rust safe/all direct/stable at three fragment widths. This targeted supplemental observation does not alter frozen source or substitute for a full matrix. The unsuccessful rlib-only probe attempt is preserved separately.'),indent=2)+'\n')
for r in records:print(r['backend'],r['name'],r['result']['error_code'])
print((D/'safe-rust.tsv').read_text())
