use zstdoxide::{DecodeOptions, SliceDecoder, decompress_into_with_options};
fn main() {
    for file in std::env::args().skip(1) {
        let input = std::fs::read(&file).unwrap();
        let mut output = [0xa5; 80];
        let direct =
            decompress_into_with_options(&input, &mut output[32..48], DecodeOptions::new(16));
        assert!(output[..32].iter().chain(&output[48..]).all(|&b| b == 0xa5));
        if let Ok(size) = direct {
            assert_eq!(size, 0);
            assert_eq!(output, [0xa5; 80]);
        }
        for chunk in [1, 7, usize::MAX] {
            output.fill(0xa5);
            let mut decoder = SliceDecoder::new(&mut output[32..48], DecodeOptions::new(16));
            let result = (|| {
                for fragment in input.chunks(chunk) {
                    let mut offset = 0;
                    while offset < fragment.len() {
                        let p = decoder.process(&fragment[offset..])?;
                        assert!(p.consumed > 0 || p.produced > 0);
                        offset += p.consumed;
                    }
                }
                decoder.finish()?;
                Ok::<usize, zstdoxide::Error>(decoder.output()?.len())
            })();
            assert_eq!(result.is_ok(), direct.is_ok());
            if let Ok(size) = result {
                assert_eq!(size, 0);
            }
            drop(decoder);
            assert!(output[..32].iter().chain(&output[48..]).all(|&b| b == 0xa5));
            if result.is_ok() {
                assert_eq!(output, [0xa5; 80]);
            }
            println!(
                "{}\t{chunk}\t{direct:?}\t{result:?}",
                std::path::Path::new(&file)
                    .file_name()
                    .unwrap()
                    .to_str()
                    .unwrap()
            );
        }
    }
}
