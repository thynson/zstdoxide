from pathlib import Path
import json,hashlib,tarfile,datetime
D=Path(__file__).parent;A=Path('/private/tmp/module26-archives');M=Path('/private/tmp/module26-matrix');R=Path('/private/tmp/module26-candidate')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((D/'regression.json').read_text());assert e['status']=='passed' and len(e['commands'])==47
c=json.loads((D/'comparison.json').read_text());assert c['status']=='passed'
for n,h in e['production_source'].items():assert sha(R/n)==h
assert sha(R/'tests/empty_block_boundaries.rs')==e['source_sha256']
name='2026-10-26-stable-dictionary-output-empty-block-boundaries';arc=A/(name+'.tar.gz');assert not arc.exists()
files={str(p.relative_to(D)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in D.rglob('*') if p.is_file()}
omitted={n:v for n,v in files.items() if '/' not in n and (n.startswith('regression-') and '.' not in n)}
with tarfile.open(arc,'w:gz') as t:
 for n in files:
  if n not in omitted:t.add(D/n,arcname='campaign/'+n)
result=dict(status='passed',regression=e,comparison=c,files=files,omitted_unit_executables=omitted,archive=arc.name,archive_sha256=sha(arc),qualification='Five hand-encoded empty-block boundaries, with real destination guards, direct and stable output, absent/persistent empty dictionary and whole/one/seven-byte input. All22 retained feature libraries pass the new regression, then safe/all Clippy and full formatting pass. Native stable streaming skips a zero-length compressed block body whereas native one-shot and Rust reject mandatory missing sections. This is a separately qualified supplement and does not inflate the earlier native campaign counts. Initial compiler-selection failure is retained; no production source change.')
(A/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
extra=dict(status='passed',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_preparation_sha256=sha(M/'preparation.json'),test='tests/empty_block_boundaries.rs',test_sha256=e['source_sha256'],regression_sha256=sha(D/'regression.json'),archive_receipt_sha256=sha(A/(name+'.json')),qualification='Test-only addition before the full matrix starts. Prior public/focused receipts remain unchanged.')
assert not (M/'evidence.json').exists();(M/'additional-preparation.json').write_text(json.dumps(extra,indent=2)+'\n')
p=A/'archive-matrix.py';s=p.read_text().replace('(87,1611,60)','(88,1612,60)');p.write_text(s)
p=A/'stable-dictionary-output-validation.md';s=p.read_text();s+='''\n## Empty-block boundary supplement\n\n`evidence/2026-10-26-stable-dictionary-output-empty-block-boundaries.json`\nrecords five hand-encoded boundaries independently from the 1,428-call native\ncampaign above. Empty raw/RLE blocks and a complete empty compressed block with\nunknown content size succeed. A compressed body larger than a known zero window\nand a compressed body missing its mandatory literals/sequence sections fail.\nPinned native streaming skips a zero-byte compressed body; native one-shot and\nRust reject it. This permissive native shortcut is an explicit interoperability\ndifference, not a claim of malformed-input parity.\n\nThe regression passes all 22 retained backend libraries, with absent/persistent\nempty dictionaries, actual guards and direct/whole/one/seven-byte stable paths.\nSafe/all strict Clippy and formatting also pass. It is added before the complete\nfeature matrix; production source is unchanged. The initial standalone compiler\nselection failure and corrected invocation are both preserved.\n''';p.write_text(s)
p=Path('/private/tmp/zstdoxide-20261026-session.json');s=json.loads(p.read_text());s['stages']['module26-empty-blocks']=str(A/(name+'.json'))+' passed47 regressioncommands +nativeobservations; test addedbeforefullmatrix; expected88groups1612passed60ignored. No productionchange. initialtoolchainselectionfailure preserved.';s['stages']['module26-matrix']='Finalcandidate ready; full NOT started. Includes extra empty-block test qualified22 libraries+Clippy/fmt. Start after23-25 all sequentialtimings, then promotepredecessors while26matrixruns. jobs3.';p.write_text(json.dumps(s,indent=2)+'\n')
print(arc,arc.stat().st_size)
