from pathlib import Path
import json,hashlib,subprocess,time,os,shutil
D=Path(__file__).parent;B=Path('/private/tmp/module26-benchmark');R=Path('/private/tmp/module26-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((B/'evidence.json').read_text());assert b['status']=='qualified-not-timed' and len(b['builds'])==22
for n,h in b['production_source'].items():assert sha(R/n)==h,n
source=D/'empty_block_boundaries.rs';e=dict(status='running',source_sha256=sha(source),production_source=b['production_source'],benchmark_build_sha256=sha(B/'evidence.json'),commands=[])
def save():(D/'regression.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,cwd=D,env=None):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t));save();assert p.returncode==0,label
save()
try:
 for row in b['builds']:
  name=row['name'];entries=[json.loads(line) for line in (B/(name+'-build.jsonl')).read_text().splitlines() if line.startswith('{')]
  lib=[r for r in entries if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='zstdoxide' and 'lib' in r['target']['kind']];assert len(lib)==1
  paths=[Path(n) for n in lib[0]['filenames'] if n.endswith(('.rlib','.rmeta'))];assert len(paths)==2
  exe=D/('regression-'+name)
  args=['rustc','--edition=2024','--test',str(source),'-Dwarnings','-L','dependency='+str(paths[0].parent),*[arg for path in paths for arg in ['--extern','zstdoxide='+str(path)]],'-o',str(exe)]
  run(name+'-regression-build',args);run(name+'-regression-test',[str(exe)])
  assert '1 passed; 0 failed; 0 ignored' in (D/(name+'-regression-test.log')).read_text()
  e.setdefault('libraries',{})[name]={str(p):sha(p) for p in paths};save()
 target=R/'tests/empty_block_boundaries.rs';assert not target.exists();shutil.copyfile(source,target)
 env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module26-candidate-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
 for name,flags in [('safe',[]),('all',['--all-features'])]:run(name+'-regression-clippy',['cargo','clippy','--offline','--locked','--test','empty_block_boundaries',*flags,'--','-D','warnings'],R,env)
 run('regression-format',['cargo','fmt','--all','--','--check'],R,env)
 assert sha(target)==sha(source)==e['source_sha256'];e['status']='passed';save();print('Empty-block regression passed22 feature libraries plus Clippy/format')
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
