/* External test oracle only: pinned facebook/zstd v1.5.7. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "datagen.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

static void save(const char *path, const void *data, size_t size) {
    FILE *f = fopen(path, "wb");
    if (!f || fwrite(data, 1, size, f) != size || fclose(f)) exit(11);
}
static unsigned char *load(const char *path, size_t *size) {
    FILE *f = fopen(path, "rb");
    long n;
    unsigned char *data;
    if (!f || fseek(f, 0, SEEK_END) || (n = ftell(f)) < 0 || fseek(f, 0, SEEK_SET)) exit(12);
    *size = (size_t)n;
    data = malloc(*size ? *size : 1);
    if (!data || fread(data, 1, *size, f) != *size || fclose(f)) exit(13);
    return data;
}

/* Preserve tests/fuzzer.c:1344 and :1369 input construction and assertions.
 * The harness fixes the original configurable seed/compressibility to 0/0.5.
 * The two-frame case intentionally retains CNBuffSize + margin capacity. */
static void originals(const char *directory) {
    size_t const size = 5 * 1024 * 1024;
    size_t const bound = ZSTD_compressBound(size);
    unsigned char *source = malloc(size), *compressed = malloc(bound);
    char path[4096];
    unsigned frames;
    if (!source || !compressed) exit(14);
    RDG_genBuffer(source, size, 0.5, 0., 0);
    for (frames = 1; frames <= 2; ++frames) {
        size_t encoded = ZSTD_compress(compressed, bound, source, frames == 1 ? size : size / 3, -ZSTD_BLOCKSIZE_MAX);
        size_t margin, capacity, decoded, expected = frames == 1 ? size : (size / 3) * 2;
        unsigned char *storage, *output, *input;
        if (ZSTD_isError(encoded) || (frames == 1 && !(size < encoded))) exit(15);
        if (frames == 2) {
            size_t second = ZSTD_compress(compressed + encoded, bound - encoded, source + size / 3, size / 3, -ZSTD_BLOCKSIZE_MAX);
            if (ZSTD_isError(second)) exit(16);
            encoded += second;
        }
        margin = ZSTD_decompressionMargin(compressed, encoded);
        if (ZSTD_isError(margin) || !(encoded < size + margin)) exit(17);
        if (frames == 1 && margin > ZSTD_DECOMPRESSION_MARGIN(size, ZSTD_BLOCKSIZE_MAX)) exit(18);
        capacity = size + margin;
        storage = malloc(capacity + 64);
        if (!storage) exit(19);
        memset(storage, 0xa5, capacity + 64);
        output = storage + 32; input = output + capacity - encoded;
        memcpy(input, compressed, encoded);
        decoded = ZSTD_decompress(output, capacity, input, encoded);
        if (ZSTD_isError(decoded) || decoded != expected || memcmp(output, source, expected)) exit(20);
        { size_t i; for (i = 0; i < 32; ++i) if (storage[i] != 0xa5 || storage[32 + capacity + i] != 0xa5) exit(21); }
        snprintf(path, sizeof(path), "%s/original-%u.zst", directory, frames); save(path, compressed, encoded);
        snprintf(path, sizeof(path), "%s/original-%u.raw", directory, frames); save(path, source, expected);
        printf("original-%u\t%zu\t%zu\t%zu\t%zu\t%zu\n", frames, size, encoded, margin, capacity, decoded);
        free(storage);
    }
    free(compressed); free(source);
}

/* Each row names frame, allocation size, and actual writable output allowance.
 * The source points inside that same allocation, ending at its final byte.
 * Capture output and real outer guards; don't infer overlap from two buffers. */
static void replay(const char *manifest_path, const char *output_directory) {
    FILE *manifest = fopen(manifest_path, "r");
    char name[128], input_path[4096], output_path[4096];
    size_t capacity, limit;
    int fields;
    if (!manifest) exit(22);
    while ((fields = fscanf(manifest, "%127s %4095s %zu %zu", name, input_path, &capacity, &limit)) == 4) {
        size_t encoded, result, margin, i;
        unsigned char *frame = load(input_path, &encoded), *storage, *before, *output;
        int guards = 1, tail = 1, allowance = 1;
        if (capacity > 32 * 1024 * 1024 || encoded > capacity || limit > capacity) exit(23);
        storage = malloc(capacity + 64); before = malloc(capacity ? capacity : 1);
        if (!storage || !before) exit(24);
        memset(storage, 0xa5, capacity + 64); output = storage + 32;
        memcpy(output + capacity - encoded, frame, encoded); memcpy(before, output, capacity);
        margin = ZSTD_decompressionMargin(frame, encoded);
        result = ZSTD_decompress(output, limit, output + capacity - encoded, encoded);
        for (i = 0; i < 32; ++i) if (storage[i] != 0xa5 || storage[32 + capacity + i] != 0xa5) guards = 0;
        for (i = ZSTD_isError(result) ? limit : result; i < capacity; ++i) if (output[i] != before[i]) tail = 0;
        printf("%s\t%s\t%zu\t%zu\t%zu\t%zu\t%d\t%d\t%s\t%zu\n", name,
               ZSTD_isError(result) ? "error" : "ok", ZSTD_isError(result) ? 0 : result,
               capacity, limit, capacity - encoded, guards, tail,
               ZSTD_isError(margin) ? "error" : "ok", ZSTD_isError(margin) ? 0 : margin);
        for (i = limit; i < capacity; ++i) if (output[i] != before[i]) allowance = 0;
        if (!guards || !allowance) exit(25);
        if (!ZSTD_isError(result)) {
            snprintf(output_path, sizeof(output_path), "%s/%s.raw", output_directory, name);
            save(output_path, output, result);
        }
        free(before); free(storage); free(frame);
    }
    if (fields != EOF || ferror(manifest) || fclose(manifest)) exit(26);
}

int main(int argc, char **argv) {
    if (ZSTD_versionNumber() != 10507) return 2;
    if (argc == 3 && !strcmp(argv[1], "originals")) originals(argv[2]);
    else if (argc == 4 && !strcmp(argv[1], "replay")) replay(argv[2], argv[3]);
    else return 3;
    return 0;
}
