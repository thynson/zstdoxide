from pathlib import Path
import subprocess,hashlib,json,time,os
D=Path(__file__).parent;S=D/'replay-source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**os.environ,'CARGO_TARGET_DIR':str(D/'replay-target'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0','ZSTDOXIDE_IN_PLACE_CASES':str(D)}
e=dict(status='running',source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()},native_receipt_sha256=sha(D/'native.json'),capture_receipt_sha256=sha(D/'rust.json'),commands=[])
def save():(D/'replay.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [('safe',[]),('move',['--features','unsafe-in-place-buffer']),('history',['--features','unsafe-slice-history']),('combined',['--features','unsafe-in-place-buffer,unsafe-slice-history']),('all',['--all-features'])]:
  args=['cargo','test','--offline','--locked','--test','in_place_output_native',*flags,'--','--ignored','--nocapture'];t=time.monotonic()
  with (D/(name+'-replay.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(name+'-replay.log'))));save();assert p.returncode==0,name
  assert '2 passed; 0 failed; 0 ignored' in (D/(name+'-replay.log')).read_text()
 for n,h in e['source'].items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='The final two ignored native adapter tests were explicitly executed in five configurations. 1300 layouts plus the original expanded 5 MiB single-frame and two-frame assertions pass. Native empty-input acceptance remains an explicitly labelled difference.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
