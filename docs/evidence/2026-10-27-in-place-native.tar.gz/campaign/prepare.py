from pathlib import Path
import hashlib,json,subprocess,shutil
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');I=D/'inputs';I.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frames={}
def add(name,frame,expected=None,kind='supplement'):
 assert name not in frames
 (I/(name+'.zst')).write_bytes(frame)
 if expected is not None:(I/(name+'.raw')).write_bytes(expected)
 frames[name]=dict(name=name,input_size=len(frame),expected_size=len(expected) if expected is not None else None,kind=kind)
def raw(data,known=True,rle=False):
 f=bytearray(b'\x28\xb5\x2f\xfd'+bytes([0x20 if known else 0,len(data) if known else 0]));f+=((len(data)<<3)|1|(2 if rle else 0)).to_bytes(3,'little');f+=bytes([data[0] if data else 77]) if rle else data;return bytes(f)
for size in [0,1,8,9,10,31,127,255]:
 for known in [False,True]:
  for rle in [False,True]:
   data=bytes([77])*size if rle else bytes((i*7+13)%256 for i in range(size));add(f'{"rle" if rle else "raw"}-{size}-{int(known)}',raw(data,known,rle),data)
for n in ['http','huffman-compressed-larger']:
 add(n,(R/f'tests/upstream/data/generated/{n}.zst').read_bytes(),(R/f'tests/upstream/data/golden-compression/{n}').read_bytes(),'existing-pinned-fixture')
for n in [1,2]:add(f'original-{n}',(D/f'normal/original-{n}.zst').read_bytes(),(D/f'normal/original-{n}.raw').read_bytes(),'original-upstream-assertions')
block=bytes([24,97,98,99,1,0x54,3,2,0,6]);compressed=b'\x28\xb5\x2f\xfd\0\0'+((len(block)<<3)|5).to_bytes(3,'little')+block
add('small-compressed',compressed,b'abcabc')
for n in range(16):add(f'skip-{n}',(0x184d2a50+n).to_bytes(4,'little')+bytes([3,0,0,0])+b'tag',b'')
skip=(I/'skip-0.zst').read_bytes();first=(I/'raw-31-1.zst').read_bytes();rle=(I/'rle-127-1.zst').read_bytes()
for prefix in [b'',skip]:
 for suffix in [b'',skip]:
  add(f'concat-{bool(prefix)}-{bool(suffix)}',prefix+first+skip+compressed+rle+suffix,(I/'raw-31-1.raw').read_bytes()+b'abcabc'+b'M'*127)
for name in ['raw-31-1','rle-31-0','small-compressed']:
 f=(I/(name+'.zst')).read_bytes()
 for end in range(len(f)):add(f'truncated-{name}-{end}',f[:end])
 for index in [0,4,5,6,7,8,len(f)-1]:
  for bit in [0,3,7]:
   changed=bytearray(f);changed[index]^=1<<bit;add(f'mutated-{name}-{index}-{bit}',bytes(changed))
margin_manifest=D/'margin-inputs.txt';margin_manifest.write_text(''.join(str(I/(n+'.zst'))+'\n' for n in frames))
p=subprocess.run(['/private/tmp/module28-margin/oracle-normal',str(margin_manifest)],capture_output=True);assert p.returncode==0
(D/'margins.tsv').write_bytes(p.stdout);(D/'margins.stderr').write_bytes(p.stderr)
for line in p.stdout.decode().splitlines():
 path,status,value=line.split('\t');n=Path(path).stem;frames[n]['native_margin']=int(value) if status=='ok' else None
cases=[]
for n,row in frames.items():
 fsize=row['input_size'];size=row['expected_size'];margin=row['native_margin']
 if row['kind']=='original-upstream-assertions':
  fields=next(l for l in (D/'normal-originals.tsv').read_text().splitlines() if l.startswith(n+'\t')).split('\t');capacities=[int(fields[4])]
 elif size is not None:
  sufficient=max(fsize,size+margin);capacities=sorted({fsize,fsize+1,fsize+8,sufficient,max(fsize,sufficient-1),sufficient+17})
 else:capacities=sorted({fsize,fsize+16,fsize+2048})
 for capacity in capacities:
  limits=sorted({capacity,0,max(0,size-1),size}) if size is not None else [capacity]
  for limit in limits:
   if limit>capacity:continue
   name=f'case-{len(cases):05}'
   cases.append(dict(name=name,frame=n,capacity=capacity,limit=limit,input_start=capacity-fsize))
(D/'manifest.txt').write_text(''.join(f"{c['name']} {I/(c['frame']+'.zst')} {c['capacity']} {c['limit']}\n" for c in cases))
(D/'cases.json').write_text(json.dumps(dict(status='prepared',frames=frames,cases=cases,files={p.name:sha(p) for p in I.iterdir()},driver_sha256=sha(Path(__file__)),qualification='Original full-size fixtures plus separately labelled valid and malformed supplements. Native result and Rust replay will independently qualify every same-allocation layout; no pre-assumed success for smaller layouts.'),indent=2)+'\n')
print(len(frames),'frames',len(cases),'layouts')
