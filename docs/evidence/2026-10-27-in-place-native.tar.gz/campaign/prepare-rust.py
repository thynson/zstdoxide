from pathlib import Path
import tomllib,json
D=Path(__file__).parent;S=D/'rust-capture';S.mkdir();(S/'src').mkdir();features=sorted(n for n in tomllib.loads(Path('/private/tmp/module28-candidate/Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
(S/'Cargo.toml').write_text('[package]\nname = "in-place-capture"\nversion = "0.0.0"\nedition = "2024"\n[dependencies]\nzstdoxide = { path = "/private/tmp/module28-candidate" }\n[features]\n'+''.join(f'{f} = ["zstdoxide/{f}"]\n' for f in features))
(S/'rust-toolchain.toml').write_bytes(Path('/private/tmp/module28-candidate/rust-toolchain.toml').read_bytes())
(S/'src/main.rs').write_text('''#![forbid(unsafe_code)]
use std::{env, fs, path::PathBuf};
use zstdoxide::{decompress_in_place_with_options, DecodeOptions};
fn main() {
    let args: Vec<_> = env::args().collect();
    let manifest = fs::read_to_string(&args[1]).unwrap();
    let directory = PathBuf::from(&args[2]);
    for line in manifest.lines() {
        let fields: Vec<_> = line.split_whitespace().collect();
        assert_eq!(fields.len(), 4);
        let frame = fs::read(fields[1]).unwrap();
        let capacity: usize = fields[2].parse().unwrap();
        let limit: usize = fields[3].parse().unwrap();
        let start = capacity - frame.len();
        let mut bytes = vec![0xa5; capacity + 64];
        bytes[32 + start..32 + capacity].copy_from_slice(&frame);
        let before = bytes.clone();
        let result = decompress_in_place_with_options(&mut bytes[32..32 + capacity], start, DecodeOptions::new(limit));
        assert_eq!(&bytes[..32], &before[..32]);
        assert_eq!(&bytes[32 + limit..], &before[32 + limit..]);
        match result {
            Ok(size) => {
                assert_eq!(&bytes[32 + size..], &before[32 + size..]);
                fs::write(directory.join(format!("{}.raw", fields[0])), &bytes[32..32 + size]).unwrap();
                println!("{}\\tok\\t{}", fields[0], size);
            }
            Err(error) => println!("{}\\terror\\t{:?}", fields[0], error),
        }
    }
}
''')
