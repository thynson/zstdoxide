from pathlib import Path
import argparse,hashlib,json,tarfile,datetime
p=argparse.ArgumentParser();p.add_argument('stage',choices=['storage','engine','public-api','native','platform']);a=p.parse_args();T=Path('/private/tmp');D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
config={
 'storage':('module28-storage','source',['evidence.json']),
 'engine':('module28-engine','source',['evidence.json']),
 'public-api':('module28-public',None,['evidence.json']),
 'native':('module28-native','replay-source',['build.json','originals.json','native.json','rust.json','replay.json']),
 'platform':('module28-platform','source',['evidence.json'])}
folder,sub,receipts=config[a.stage];C=T/folder;S=C/sub if sub else T/'module28-candidate'
records={n:json.loads((C/n).read_text()) for n in receipts}
for n,j in records.items():assert j['status']=='passed',(n,j['status'])
source={str(q.relative_to(S)):sha(q) for q in S.rglob('*') if q.is_file()}
production={n:h for n,h in source.items() if n.startswith('src/')}
for n,j in records.items():
 if 'source' in j:
  for name,digest in j['source'].items():
   if name.startswith('src/'):assert production[name]==digest,(n,name)
 for row in j.get('commands',[]):assert row['exit_code']==0,(n,row)
# Check focused test execution counts rather than accepting a no-match filter.
if a.stage in ['storage','engine','public-api']:
 expected={'storage':{'slice_history':9,'in_place_buffer':6},'engine':{'in_place_decode':6},'public-api':{'public':7,'engine':6,'docs':1}}[a.stage]
 for row in records['evidence.json']['commands']:
  for suffix,count in expected.items():
   if row['label'].endswith('-'+suffix):
    assert f'{count} passed; 0 failed; 0 ignored' in (C/(row['label']+'.log')).read_text(),row['label']
# Every qualification log referenced by current receipts must still exist and hash.
for n,j in records.items():
 for row in j.get('commands',[]):
  if 'log_sha256' in row:
   candidates=[q for q in C.glob('*.log') if sha(q)==row['log_sha256']];assert candidates,(n,row['label'])
files={}
text_ext={'.rs','.toml','.lock','.json','.py','.md','.log','.tsv','.stderr','.jsonl','.c','.txt','.ll','.o'}
# Preserve controller/source/logs and platform artifacts, excluding compiler caches.
for q in C.rglob('*'):
 if not q.is_file():continue
 rel=q.relative_to(C)
 if any(x in {'target','rust-target','replay-target','miri-i686','miri-s390x','thumb-check','thumb-safe','thumb-all','probe','source','replay-source','rust-capture','__pycache__'} or x.endswith('.dSYM') for x in rel.parts):continue
 if a.stage=='native' and rel.parts[0] in ['inputs','normal','sanitized','normal-replay','sanitized-replay','rust-safe','rust-move','rust-history','rust-combined','rust-all']:continue
 if q.suffix in text_ext or q.name.startswith('oracle-'):files['campaign/'+str(rel)]=q
for q in S.rglob('*'):
 if q.is_file() and q.suffix in {'.rs','.toml','.lock','.json','.py','.md','.sh','.csv','.tsv'}:files['source/'+str(q.relative_to(S))]=q
# Native payloads are external retained fixtures, not upstream source imports.
# Store each unique encoded/raw payload once, with a complete content-address map.
fixtures={}
if a.stage=='native':
 for folder in ['inputs','normal','normal-replay']:
  for q in (C/folder).iterdir():
   if q.is_file():
    digest=sha(q);fixtures[str(q.relative_to(C))]=digest;files.setdefault('payloads/'+digest,q)
name='2026-10-27-in-place-'+a.stage;archive=D/(name+'.tar.gz');assert not archive.exists()
files['archive-stage.py']=Path(__file__)
with tarfile.open(archive,'w:gz') as tar:
 for label,q in sorted(files.items()):tar.add(q,arcname=label)
result=dict(status='passed',stage=a.stage,recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,complete_source=source,records=records,receipt_sha256={n:sha(C/n) for n in receipts},external_fixture_payloads=fixtures,members={label:dict(sha256=sha(q),bytes=q.stat().st_size) for label,q in sorted(files.items())},archive=archive.name,archive_sha256=sha(archive),qualification='Hash-bound completed focused stage, not full-feature/timing closure. The source inventory is recursive. Text source is archived; unchanged repository binary fixtures are identified by full hashes and the existing pinned fixture provenance. Native payloads have a content-addressed archive map. Foreign evidence is interpretation/code generation, not foreign native hardware execution.')
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size,flush=True)
