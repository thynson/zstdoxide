from pathlib import Path
import gzip,hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');U=Path('/tmp/zstdoxize-upstream-1.5.7').resolve()
first=Path('/tmp/zstdoxide-greedy-tiny-2026-10-12');qualified=Path('/tmp/zstdoxide-greedy-tiny-qualified-2026-10-12')
files={}
def sha(b):return hashlib.sha256(b).hexdigest()
def put(name,p):
 if name in files:raise ValueError('duplicate member')
 files[name]=p.read_bytes()
reports={}
for label,root in [('first-failed',first),('qualified',qualified)]:
 e=json.loads((root/'evidence.json').read_text());reports[label]=e
 for p in sorted(root.rglob('*')):
  if p.is_file() and not p.relative_to(root).parts[0].startswith('c-'):put(label+'/'+str(p.relative_to(root)),p)
 for name,digest in e['source_before'].items():
  p=Path('/tmp/zstdoxide-greedy-tiny-first-driver.py') if label=='first-failed' and name=='scripts/capture_greedy_tiny.py' else R/name
  if sha(p.read_bytes())!=digest:raise ValueError('source changed '+label+' '+name)
  put('source/'+label+'/'+name,p)
for name in ('normal','optimized'):
 p=Path('/tmp/zstdoxide-greedy-controls-'+name+'.log');d=json.loads(p.read_text())
 if (d['positive'],d['rejected'],d['child_processes'])!=(2,30,0):raise ValueError('controls')
 put('controls/'+name+'.json',p)
put('controls/run.py',Path('/tmp/zstdoxide-greedy-capture-controls.py'))
put('first-failure-review.json',Path('/tmp/zstdoxide-greedy-tiny-first-failure-review.json'))
put('packager.py',Path(__file__))
put('checker.py',R/'scripts/check_greedy_tiny_capture.py')
for name in ('recipes.json','capture.json','observations.ndjson'):
 put('fixture/'+name,R/'tests/fixtures/reference-greedy-tiny'/name)
reference=set()
for build in reports['qualified']['builds'].values():
 reference.update(build['compiled_codec_sources'])
 for n,digest in build['dependencies'].items():
  p=Path(n)
  if p.is_relative_to(U):reference.add(str(p.relative_to(U)))
for name in sorted(reference):
 if sha((U/name).read_bytes())!=reports['qualified']['upstream_source_sha256'][name]:raise ValueError('reference changed')
 put('reference/'+name,U/name)
if reports['first-failed']['status']!='failed' or reports['qualified']['status']!='passed':raise ValueError('campaign status')
if len(reports['first-failed']['commands'])!=210 or len(reports['qualified']['commands'])!=210:raise ValueError('command counts')
manifest={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())}
files['members.json']=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
archive=R/'docs/evidence/2026-10-12-greedy-tiny.tar.gz'
with archive.open('wb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w|') as t:
   for n,b in sorted(files.items()):
    info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
 read={m.name:t.extractfile(m).read() for m in t if m.isfile()}
if read!=files:raise ValueError('archive exact member/byte comparison failed')
report={'status':'passed','scope':'First direct Greedy chain/row C capture and fresh-context salt; no Rust Greedy implementation or ordinary-frame claim. All linked C units instrumented, retaining upstream per-function sanitizer exclusions.','archive':archive.name,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'members':len(files),'uncompressed_bytes':sum(map(len,files.values())),'reference_source_files':len(reference),'qualified_commands':210,'qualified_totals':reports['qualified']['totals'],'context_peak_guarded_bytes':reports['qualified']['context_peak_guarded_bytes'],'fresh_context_salt':'835892b4bb2cae74','first_attempt':{'status':'failed','commands':210,'error':reports['first-failed']['error'],'preserved':True},'qualification':'Only opaque CCtx peak_guarded_bytes is excluded from cross-build salt equality because upstream adds ASan redzones. All direct observations and all other fresh-context fields match. Both memory peaks are frozen and verified.','controls_per_python_mode':{'positive':2,'rejected':30,'child_processes':0},'compiled_binary_retention':'Binaries/objects omitted; exact identities and compile/link argv retained. All logs, packets, source closure, first failure, controls and immutable complete observations retained.','checker_sha256':sha((R/'scripts/check_greedy_tiny_capture.py').read_bytes()),'fixture':{n:sha((R/'tests/fixtures/reference-greedy-tiny'/n).read_bytes()) for n in ('recipes.json','capture.json','observations.ndjson')}}
(R/'docs/evidence/2026-10-12-greedy-tiny.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(report,sort_keys=True))
