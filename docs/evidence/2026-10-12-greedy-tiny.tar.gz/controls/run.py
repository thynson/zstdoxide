from pathlib import Path
from unittest.mock import patch
import contextlib,copy,hashlib,json,os,shutil,subprocess,sys,tempfile
repo=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(repo/'scripts'))
import check_greedy_tiny_capture as checker
source=Path('/tmp/zstdoxide-greedy-tiny-qualified-2026-10-12')
root=Path(tempfile.mkdtemp(prefix='zstdoxide-greedy-controls-',dir='/tmp')).resolve()
for name in ('evidence.json','recipes.json'):shutil.copyfile(source/name,root/name)
for name in ('logs','requests'):shutil.copytree(source/name,root/name)
original=(root/'evidence.json').read_bytes();base=json.loads(original)
results=[];calls=[]
def denied(*a,**kw):calls.append('process');raise RuntimeError('child process forbidden')
def reject(name,edit,undo=lambda:None):
 try:
  edit()
  try:checker.audit(root)
  except (ValueError,KeyError,TypeError,OSError):results.append(name)
  else:raise RuntimeError('accepted mutation: '+name)
 finally:
  undo();(root/'evidence.json').write_bytes(original)
def evidence(name,edit):
 def change():
  data=copy.deepcopy(base);edit(data);(root/'evidence.json').write_text(json.dumps(data))
 reject(name,change)
def log_change(name,label,edit):
 p=root/'logs'/(label+'.stdout');saved=p.read_bytes()
 def change():
  data=copy.deepcopy(base);rows=[json.loads(x) for x in saved.splitlines()];edit(rows)
  raw=b''.join((json.dumps(r,separators=(',',':'))+'\n').encode() for r in rows);p.write_bytes(raw)
  command=next(c for c in data['commands'] if c['label']==label)
  command['stdout'].update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
  (root/'evidence.json').write_text(json.dumps(data))
 reject(name,change,lambda:p.write_bytes(saved))
with contextlib.ExitStack() as stack:
 for module,name in [(subprocess,'Popen'),(os,'system'),(os,'posix_spawn'),(os,'posix_spawnp')]:
  if hasattr(module,name):stack.enter_context(patch.object(module,name,denied))
 if checker.audit(root)['direct_observations']!=144:raise RuntimeError('positive count')
 evidence('incomplete-status',lambda e:e.update(status='failed'))
 evidence('boolean-schema',lambda e:e.update(schema_version=True))
 evidence('support-archive',lambda e:e.update(support_archive_used=True))
 evidence('hidden-sanitizer-exclusions',lambda e:e.update(upstream_sanitizer_annotations_retained=False))
 evidence('changed-source',lambda e:e['source_after'].update({'scripts/oracles/greedy_direct.c':'0'*64}))
 evidence('missing-instrumented-unit',lambda e:e['builds']['sanitized']['instrumented_codec_sources'].pop())
 evidence('disabled-helper-instrumentation',lambda e:e['builds']['sanitized'].update(helper_instrumented=False))
 evidence('missing-object',lambda e:e['builds']['normal']['objects'].pop('c-normal/unit-0.o'))
 evidence('missing-dependency',lambda e:e['builds']['normal']['dependencies'].pop(next(iter(e['builds']['normal']['dependencies']))))
 evidence('bool-total',lambda e:e['totals'].update(fresh_contexts=True))
 evidence('changed-context-peak',lambda e:e['context_peak_guarded_bytes'].update(normal=[1,1]))
 evidence('missing-command',lambda e:e['commands'].pop())
 def argv(e):next(c for c in e['commands'] if c['label']=='sanitized-compile-0')['argv'].remove('-fsanitize=address,undefined')
 evidence('uninstrumented-compile',argv)
 def link(e):next(c for c in e['commands'] if c['label']=='normal-link')['argv'].insert(-2,'libzstd.a')
 evidence('archive-link',link)
 def escape(e):next(c for c in e['commands'] if c['label']=='normal-fresh-salt')['stdout']['path']='../escape'
 evidence('escaping-log',escape)
 log_change('changed-case-id','normal-case-chain-fresh-7',lambda r:r[1].update(id='forged'))
 log_change('bool-frontier','normal-case-chain-fresh-7',lambda r:r[1].update(final_next_to_update=True))
 log_change('huge-frontier','normal-case-row-fresh-7',lambda r:r[1].update(final_next_to_update=2**63))
 log_change('changed-trailing','normal-case-chain-fresh-7',lambda r:r[1].update(trailing_literals=6))
 log_change('changed-entropy','normal-case-row-period-four',lambda r:r[1].update(final_entropy=(r[1]['final_entropy']+1)&0xffffffff))
 log_change('changed-table-fingerprint','normal-case-row-period-four',lambda r:r[1]['first_table'].update(after_fnv1a64='0'*16))
 log_change('unknown-case-field','normal-case-chain-fresh-7',lambda r:r[1].update(unknown=0))
 log_change('bad-cache','normal-case-row-fresh-7',lambda r:r[1].update(hash_cache=[2**32]*8))
 log_change('bad-initial-map','normal-case-chain-prefix-17',lambda r:r[1]['first_table'].update(before=[]))
 log_change('bad-raw-repeat','normal-case-chain-period-four',lambda r:r[1].update(parser_repeats=[0,0,0]))
 log_change('bad-salt','normal-fresh-salt',lambda r:r[1].update(final_salt='0'*16))
 log_change('mode-qualified-peak-tamper','normal-fresh-salt',lambda r:[x.update(peak_guarded_bytes=x['peak_guarded_bytes']+1) for x in r[1:3]])
 log_change('bad-completion','normal-case-chain-fresh-7',lambda r:r[3].update(success=False))
 extra=root/'logs/unexpected'
 reject('extra-log',lambda:extra.write_text('x'),lambda:extra.unlink())
 p=root/'requests/chain-fresh-7.bin';saved=p.read_bytes()
 reject('changed-packet',lambda:p.write_bytes(saved[:-1]+bytes([saved[-1]^1])),lambda:p.write_bytes(saved))
 if checker.audit(root)['direct_observations']!=144:raise RuntimeError('restored positive')
if calls:raise RuntimeError('child creation attempted')
if len(results)!=30:raise RuntimeError('control inventory')
print(json.dumps({'positive':2,'rejected':len(results),'child_processes':len(calls),'optimized':not __debug__,'cases':results,'checker_sha256':hashlib.sha256((repo/'scripts/check_greedy_tiny_capture.py').read_bytes()).hexdigest()},sort_keys=True))
shutil.rmtree(root)
