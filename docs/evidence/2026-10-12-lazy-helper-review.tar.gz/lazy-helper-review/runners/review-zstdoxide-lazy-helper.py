from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');U=Path('/private/tmp/zstdoxize-upstream-1.5.7');O=Path('/tmp/zstdoxide-lazy-helper-review');O.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
h=R/'scripts/oracles/lazy_direct.c';old=R/'scripts/oracles/greedy_direct.c';doc=R/'docs/reference-lazy-oracle.md'
manifest=json.loads((R/'tests/upstream/manifest.json').read_text());pins={v['path']:v['sha256'] for v in manifest['sources']+manifest['excluded_sources'] if v['path'].startswith('lib/') and Path(v['path']).suffix in ('.c','.h')}
if not all(sha(U/n)==v for n,v in pins.items()):raise RuntimeError('upstream pin')
units=sorted(p for d in ['common','compress','decompress'] for p in (U/'lib'/d).glob('*.c'))
if len(units)!=26:raise RuntimeError('used unit inventory')
cc=Path(shutil.which('cc')).resolve();env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','TMPDIR','DEVELOPER_DIR','SDKROOT']};env.update(LANG='C',LC_ALL='C',TZ='UTC')
e={'status':'running','scope':'Source review and syntax checking only; no linked helper, oracle run or new codec output.','upstream_revision':manifest['upstream']['revision'],'helper_sha256':sha(h),'predecessor_sha256':sha(old),'protocol_sha256':sha(doc),'compiler':str(cc),'compiler_sha256':sha(cc),'environment':env,'upstream_inputs':pins,'commands':[]}
def save():(O/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
common=[str(cc),'-std=c11','-g','-I',str(U/'lib'),'-I',str(U/'lib/common'),'-I',str(U/'lib/compress'),'-DZSTD_DISABLE_ASM','-DZSTD_LEGACY_SUPPORT=0','-UZSTD_MULTITHREAD','-DXXH_NAMESPACE=ZSTD_']
commands=[('compiler-version',[str(cc),'--version']),('compiler-target',[str(cc),'-dumpmachine'])]
for mode,flags in [('normal',['-O2']),('sanitized',['-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer'])]:
 commands.append((mode+'-helper',common+flags+['-Wall','-Wextra','-Werror','-fsyntax-only',str(h)]))
 commands.append((mode+'-codec-units',common+flags+['-fsyntax-only',*map(str,units)]))
try:
 for label,argv in commands:
  start=time.monotonic();p=O/(label+'.log')
  with p.open('wb') as f:r=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
  e['commands'].append({'label':label,'argv':argv,'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':p.name,'log_sha256':sha(p)});save()
  if r.returncode:raise RuntimeError(label)
 if sha(h)!=e['helper_sha256'] or sha(old)!=e['predecessor_sha256'] or not all(sha(U/n)==v for n,v in pins.items()):raise RuntimeError('source changed')
 e.update(status='passed',source_unchanged=True,syntax_units_per_mode=27,executed_helper_commands=0);save();print('Reviewed helper and 26 unchanged C units in both syntax modes.',flush=True)
except BaseException as error:
 e.update(status='failed',error=repr(error));save();raise
