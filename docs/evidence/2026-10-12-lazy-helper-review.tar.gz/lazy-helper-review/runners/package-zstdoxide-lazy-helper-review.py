from pathlib import Path
import hashlib,io,json,tarfile,sys
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-lazy-helper-review')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,s):
 if not v:raise ValueError(s)
e=json.loads((O/'evidence.json').read_bytes());same=json.loads((O/'unchanged-functions.json').read_bytes())
need(e['status']=='passed' and e['source_unchanged'] is True and len(e['commands'])==6 and e['executed_helper_commands']==0,'syntax run')
need(e['helper_sha256']==same['helper_sha256']==sha((R/'scripts/oracles/lazy_direct.c').read_bytes()) and same['status']=='passed' and len(same['unchanged_functions'])==24,'source comparison')
for c in e['commands']:need(c['exit_code']==0 and sha((O/c['log']).read_bytes())==c['log_sha256'],'successful syntax command')
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'scripts'));import benchmark_greedy as b
need(b.source_manifest()==json.loads(Path('/tmp/zstdoxide-greedy-benchmark-clock-free/evidence.json').read_text())['source'],'Module 14 measured source unchanged')
report={'date':'2026-10-12','status':'passed','scope':e['scope'],'helper_sha256':e['helper_sha256'],'predecessor_sha256':e['predecessor_sha256'],'protocol_before_review_sha256':e['protocol_sha256'],'commands':6,'syntax_units_per_mode':27,'unchanged_functions':same['unchanged_functions'],'executed_helper_commands':0,'module14_measured_source_unchanged':True,'qualification':'Source review and compiler syntax only. No linked helper, C oracle output, Rust Lazy/Lazy2 implementation or timing. The protocol document was appended with the completed review after syntax checking.','archive':'2026-10-12-lazy-helper-review.tar.gz'}
files={p.name:p.read_bytes() for p in O.iterdir() if p.is_file()}
for n in ['review-zstdoxide-lazy-helper.py','compare-zstdoxide-lazy-helper.py','package-zstdoxide-lazy-helper-review.py']:files['runners/'+n]=(Path('/tmp')/n).read_bytes()
for n in ['scripts/oracles/lazy_direct.c','docs/reference-lazy-oracle.md']:files['source/'+n]=(R/n).read_bytes()
files['review.json']=enc(report);files['bundle-manifest.json']=enc({n:{'bytes':len(v),'sha256':sha(v)} for n,v in files.items()})
a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh archive');prefix='lazy-helper-review/'
with tarfile.open(a,'w:gz') as t:
 for n,v in sorted(files.items()):
  i=tarfile.TarInfo(prefix+n);i.size=len(v);i.mode=0o644;t.addfile(i,io.BytesIO(v))
with tarfile.open(a) as t:found={v.name:t.extractfile(v).read() for v in t}
need(found=={prefix+n:v for n,v in files.items()},'all archive members')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files));(R/'docs/evidence/2026-10-12-lazy-helper-review.json').write_bytes(enc(report));print(report['commands'],report['archive_members'],report['archive_bytes'])
