from pathlib import Path
import ast,hashlib,json,re
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-lazy-helper-review')
def tokens(text):
 raw=re.findall(r'/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|\w+|[^\s]',text,re.S)
 result=[]
 for token in raw:
  if token.startswith(('/*','//')):continue
  if token.startswith('"'):
   value=ast.literal_eval(token)
   if result and isinstance(result[-1],tuple):result[-1]=('string',result[-1][1]+value)
   else:result.append(('string',value))
  else:result.append(token)
 return result
def functions(t):
 result={}
 for i,value in enumerate(t[:-1]):
  if not isinstance(value,str) or not re.fullmatch(r'\w+',value) or t[i+1]!='(':continue
  j=i+2;depth=1
  while j<len(t) and depth:
   if t[j]=='(':depth+=1
   if t[j]==')':depth-=1
   j+=1
  if j>=len(t) or t[j]!='{':continue
  start=j;j+=1;depth=1
  while j<len(t) and depth:
   if t[j]=='{':depth+=1
   if t[j]=='}':depth-=1
   j+=1
  if value in result:continue
  result[value]=t[start:j]
 return result
old=functions(tokens((R/'scripts/oracles/greedy_direct.c').read_text()));new=functions(tokens((R/'scripts/oracles/lazy_direct.c').read_text()))
names=['add','multiply','guarded_cost','guarded_new','guarded_check','guarded_drop','fingerprint','print_hex','print_repeats','print_seeds','resolve_repeat','width','row_log','table_new','cell','seed_tables','table_check','print_table_hash','print_table','table_drop','read_u32','context_allocate','context_free','checked']
for name in names:
 if name not in old or old[name]!=new.get(name):raise RuntimeError('unchanged owner/replay helper differs: '+name)
e={'status':'passed','scope':'Token-equivalent bodies after whitespace/comment removal and adjacent C string concatenation normalization; no C execution. Selection/setup/schema differences are reviewed separately.','unchanged_functions':names,'helper_sha256':hashlib.sha256((R/'scripts/oracles/lazy_direct.c').read_bytes()).hexdigest(),'predecessor_sha256':hashlib.sha256((R/'scripts/oracles/greedy_direct.c').read_bytes()).hexdigest(),'reviewer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(O/'unchanged-functions.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n');print(len(names),'unchanged ownership/hash/replay function bodies')
