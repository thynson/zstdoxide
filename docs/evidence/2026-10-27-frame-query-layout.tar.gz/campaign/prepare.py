from pathlib import Path
import shutil,json,hashlib
D=Path(__file__).parent;S=D/'source';C=Path('/private/tmp/module29-final');S.mkdir();design=json.loads(Path('/private/tmp/module30-preparation/design-commit.json').read_text());assert design['status']=='committed'
for n in ['src','tests','test-support','benches']:shutil.copytree(C/n,S/n)
for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(C/n,S/n)
p=S/'src/frame_layout.rs';s=p.read_text();s=s.replace('    maximum_block_size: usize,','    header: Option<FrameHeader>,').replace('                maximum_block_size: 0,','                header: None,').replace('            maximum_block_size: header.window_size.min(MAX_BLOCK_SIZE as u64) as usize,','            header: Some(header),').replace('    fn add_overhead(self, previous: usize) -> Result<usize> {','''    fn maximum_block_size(self) -> usize {
        self.header.map_or(0, |header| header.window_size.min(MAX_BLOCK_SIZE as u64) as usize)
    }

    fn add_overhead(self, previous: usize) -> Result<usize> {''').replace('frame.maximum_block_size);','frame.maximum_block_size());').replace('layout.maximum_block_size, 4','layout.maximum_block_size(), 4').replace('            maximum_block_size: 0,','            header: None,')
insert='''
    #[test]
    fn complete_layout_retains_standard_header_and_distinguishes_skips() {
        for descriptor in [0x20, 0x24] {
            let bytes = frame(descriptor, &[3], &[(0, 3, b"abc")]);
            let (header, _) = FrameHeader::parse(&bytes).unwrap();
            let layout = FrameLayout::read(&bytes).unwrap();
            assert_eq!(layout.header, Some(header));
            assert_eq!(layout.maximum_block_size(), 3);
            assert_eq!(layout.encoded_size, bytes.len());
        }
        for variant in 0..16 {
            let bytes = [0x50 + variant, 0x2a, 0x4d, 0x18, 3, 0, 0, 0, 7, 8, 9];
            let layout = FrameLayout::read(&bytes).unwrap();
            assert_eq!(layout.header, None);
            assert_eq!(layout.block_count, 0);
            assert_eq!(layout.maximum_block_size(), 0);
            assert_eq!(layout.encoded_size, bytes.len());
        }
    }
'''
s=s[:-2]+insert+'}\n' if s.endswith('}\n') else s; p.write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(D/'preparation.json').write_text(json.dumps(dict(status='prepared',design=design,predecessor_source={str(p.relative_to(C)):sha(p) for p in (C/'src').rglob('*.rs')}),indent=2)+'\n')
