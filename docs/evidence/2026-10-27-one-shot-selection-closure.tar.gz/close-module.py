"""Close only after integrated focused, native, full-matrix and measured gates."""
from pathlib import Path
import json,hashlib,subprocess,tarfile,datetime
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();state=D/'promotion-state.json';previous=json.loads(state.read_text());assert previous['stage']=='benchmarks'
assert previous['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
production={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')};assert production==previous['production_source']
names=['2026-10-27-one-shot-selection-'+stage for stage in ['core','public-api','native','platform','corpus','feature-matrix','benchmarks']];records={}
for n in names:
 p=E/(n+'.json');j=json.loads(p.read_text());assert j['status']=='passed',n;assert sha(E/j['archive'])==j['archive_sha256'],n;records[n]=dict(receipt_sha256=sha(p),archive_sha256=j['archive_sha256'])
for stage in ['public-api','native','platform','corpus','feature-matrix']:
 j=json.loads((E/('2026-10-27-one-shot-selection-'+stage+'.json')).read_text());assert j['production_source']==production,stage
matrix=json.loads((E/'2026-10-27-one-shot-selection-feature-matrix.json').read_text())
for n,h in matrix['source'].items():assert sha(R/n)==h,n
bench=json.loads((E/'2026-10-27-one-shot-selection-benchmarks.json').read_text());assert bench['build']['production_source']==production
pred=E/'2026-10-27-frame-utility-closure.json';assert json.loads(pred.read_text())['status']=='passed';assert sha(E/json.loads(pred.read_text())['archive'])==json.loads(pred.read_text())['archive_sha256']
todo=(R/'TODO.md').read_text();start=todo.index('## Module 32:');end=todo.index('\n## ',start+1);unchecked=[l for l in todo[start:end].splitlines() if l.startswith('- [ ]')];assert len(unchecked)==1 and unchecked[0].startswith('- [ ] Reconcile');assert '## Module 33:' in todo and (R/'docs/slice-encode-design.md').exists()
C=Path('/private/tmp/module32-reconciliation');C.mkdir()
args=['python3','scripts/audit_upstream_tests.py','--upstream','/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99']
with (C/'inventory.log').open('xb') as f:p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
receipt=dict(status='passed',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,integrated_manifest_sha256=sha(R/'tests/upstream/manifest.json'),final_matrix_source=matrix['source'],evidence=records,predecessor_closure_sha256=sha(pred),inventory_command=args,inventory_log_sha256=sha(C/'inventory.log'),next_design_sha256=sha(R/'docs/slice-encode-design.md'),qualification='Bounded reusable dictionary/prefix selection milestone. Integrated production/tests match final source identities. Private selection records impose no Clone bound; public DictionaryHandle retains its existing Clone supertrait, but transitions never invoke it. Prefix selection covers every frame of exactly one attempted call; incremental frame prefixes remain separate. Native empty-input differences and supplemental lifecycle schedules remain explicit. All frozen gates and measured executables are independently retained. Native workspace/reset/parameter parity and complete upstream migration remain open.')
(C/'reconciliation.json').write_text(json.dumps(receipt,indent=2)+'\n');name='2026-10-27-one-shot-selection-closure';archive=E/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in C.iterdir():t.add(p,arcname=p.name)
 t.add(__file__,arcname='close-module.py')
receipt.update(archive=archive.name,archive_sha256=sha(archive));(E/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
p=R/'docs/one-shot-selection-validation.md';text=p.read_text();old='Module 32 is in progress. Focused gates below are complete; full feature/release\nregression, measurements and final reconciliation remain separate gates.';assert old in text;text=text.replace(old,'Module 32 is complete within its bounded call-scoped selection contract.\nFocused/native/corpus/platform, full feature/release, measurement and final\nsource gates have independently retained successful receipts.');text+='\n## Final reconciliation and remaining scope\n\nIntegrated production and final tests match the frozen matrix source; each stage\narchive is rehashed. A prefix is consumed before each attempt and serves all frames\nin that call; persistent selection survives errors. Native empty-input acceptance\nremains explicitly different. Scratch is fresh per call. This does not promise\nnative context workspace/reset/parameter equivalence or complete upstream parity.\nEvidence: `evidence/2026-10-27-one-shot-selection-closure.json`.\n';p.write_text(text)
p=R/'README.md';text=p.read_text();old='Module 32 final qualification remains in progress in `TODO.md`.';assert old in text;p.write_text(text.replace(old,'Bounded qualification and native differences are recorded in\n[the one-shot selection report](docs/one-shot-selection-validation.md).'))
ratios=[f"{x['campaign']} {x['numerator']} {x['nonempty_geomean']:.4f}" for x in bench['summary']['comparisons'] if x['backend']=='all' and x['reference_backend']=='safe' and x['numerator'] in ['persistent-direct','prefix-direct','persistent-in-place','prefix-in-place']]
p=R/'docs/progress.md';p.write_text(p.read_text()+"""\n## Module 32: reusable one-shot selection complete (2026-10-27)

OneShotDecoder owns copied options and persistent or next-call dictionary
selection. Next-call ownership is removed before preflight/decoding/allocation,
retained through every frame in that call, then dropped on return or unwinding.
Persistent selection survives calls/errors. Input/output/scratch are never retained;
no native workspace/reset/parameter equivalence is claimed. Existing sealed
DictionaryHandle includes Clone, but transitions never invoke it. Private records
support non-Clone values; public borrowed views support independent non-Clone
allocator owners through references.

All 72 final commands pass: safe/all and 21 isolated full/no_std/Clippy selections,
safe/all release and formatting. Each full/release suite has 1,723 passes and
71 ignored across 108 groups. Normal/sanitized native contexts execute 24 lifecycle
scenarios with 81 setup/decode steps per output mode and 106 actual attempts.
Five Rust backends agree on results/selection state and full successful bytes.
Four empty-input attempts retain native zero success versus Rust UnexpectedEof,
with prefix consumption on both. These schedules are supplemental, not upgraded
original assertion groups.

All 12,063 dictionary_decompress corpus members additionally exercise call-scoped
direct/in-place selection in safe/all release with exact Result, output and guard
comparisons. Incremental prefix semantics and its historical success ledger remain
separate. Eight platform commands cover i686/s390x Miri and concrete no-atomics
core+alloc ARM emission; no foreign-hardware execution is claimed.

Twenty-three primary and independent safe/all repeat executables have identical
132-row dictionary/scratch ownership ledgers and complete 495-row timing samples.
Nine modes expose stateless/persistent/prefix paths and setup/restoration costs.
All use borrowed views. All/safe nonempty median-latency geometric means: """+'; '.join(ratios)+""".
Fixed-order host observations do not establish universal unsafe benefit or native
workspace reuse. Initial borrowed-baseline compile and strict harness lint
rejections remain preserved; repaired source was fully rebuilt and qualified.

Closure verifies integrated source/test identities and every stage archive. The
completed checklist is cleared; Module 33 retains caller-owned ordinary compression
output decomposition. See `one-shot-selection-validation.md`,
`one-shot-selection-benchmarks.md` and the source-bound closure receipt.
""")
replacement='''Module 32 is complete within its bounded call-scoped selection contract.
Completed work items are archived in Git history and `docs/progress.md`.
Qualification and measurements are in `docs/one-shot-selection-validation.md`
and `docs/one-shot-selection-benchmarks.md`. The final receipt is
`docs/evidence/2026-10-27-one-shot-selection-closure.json`.
Complete upstream migration remains open.
''';(R/'TODO.md').write_text(todo[:start]+replacement+todo[end:])
paths=['TODO.md','README.md','docs/progress.md','docs/one-shot-selection-validation.md','docs/evidence/'+name+'.json','docs/evidence/'+name+'.tar.gz'];subprocess.run(['cargo','fmt','--all','--','--check'],cwd=R,check=True);subprocess.run(['git','diff','--check'],cwd=R,check=True);subprocess.run(['git','add','--',*paths],cwd=R,check=True);subprocess.run(['git','commit','-m','Close reusable one-shot selection milestone'],cwd=R,check=True);previous.update(stage='closed',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip());state.write_text(json.dumps(previous,indent=2)+'\n')
