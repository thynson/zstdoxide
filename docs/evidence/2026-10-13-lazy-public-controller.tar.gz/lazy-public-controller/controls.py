from pathlib import Path
from types import SimpleNamespace
import sys,json,tempfile,hashlib
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(ROOT/'scripts'))
import capture_lazy_interop as driver
attempts=[]
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec','os.spawn'):
  attempts.append(event);raise RuntimeError('child execution blocked')
sys.addaudithook(audit)
_,gen,_,manifest=driver.inputs()
controls=[]
def reject(label,action):
 try:action()
 except (ValueError,OSError):controls.append(label)
 else:raise ValueError('accepted '+label)
ref=Path('/private/tmp/zstdoxide-reference-lazy-1.5.7')
with tempfile.TemporaryDirectory(prefix='zstdoxide-greedy-controller-') as directory:
 root=Path(directory);fresh=root/'fresh'
 def call(upstream=ref,output=fresh,cc='cc'):
  driver.execute(SimpleNamespace(upstream=upstream,output=output,cc=cc))
 for label,upstream,output in [
  ('workspace-reference',ROOT,fresh),('reference-file',ref/'lib/zstd.h',fresh),
  ('missing-reference',root/'missing',fresh),('workspace-output',ref,ROOT/'uncreated-greedy-capture'),
  ('reference-output',ref,ref/'uncreated-greedy-capture'),('existing-output',ref,root),
  ('same-reference',ref,ref),('ancestor-output',ref,Path('/private/tmp'))]:
  reject(label,lambda:call(upstream,output))
 link=root/'link';link.symlink_to(fresh)
 reject('linked-output',lambda:call(output=link))
 reject('missing-compiler',lambda:call(cc='zstdoxide-absent-compiler-0042'))
 old=driver.PINS.copy()
 try:
  driver.PINS['scripts/oracles/reference_greedy_frames.c']='0'*64
  reject('changed-reviewed-input',driver.inputs)
 finally:driver.PINS=old
 driver.require(not fresh.exists(),'preflight leaves output absent')
paths=set(ROOT/name for name in driver.PINS)
paths.update((ROOT/'src').rglob('*.rs'))
paths.update(p for p in (ROOT/'test-support').rglob('*') if p.suffix in ('.rs','.toml'))
paths.update((ROOT/'scripts/oracles').glob('*.py'))
paths.update(ROOT/name for name in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/upstream/manifest.json','scripts/capture_lazy_interop.py','scripts/check_reference_fast_interop.py','scripts/import_reference_fast_fuzz.py'))
paths.update(ROOT/name for name in gen.PINS)
paths.add(ROOT/'tests/fixtures/reference-lazy-interop-recipes/recipes.json')
keys=sorted(str(p.relative_to(ROOT)) for p in paths)
closure=hashlib.sha256(json.dumps(keys,sort_keys=True,separators=(',',':')).encode()).hexdigest()
import check_lazy_interop_capture as independent
with tempfile.TemporaryDirectory(prefix='lazy-audit-preflight-') as directory:
 path=Path(directory)
 reject('missing-capture-report',lambda:independent.check(path))
 (path/'evidence.json').write_text('{}')
 try:independent.check(path)
 except (ValueError,KeyError):controls.append('incomplete-capture-report')
 else:raise ValueError('accepted incomplete capture')
 link=path/'linked';link.mkdir();(link/'evidence.json').symlink_to(path/'evidence.json')
 reject('linked-capture-report',lambda:independent.check(link))
driver.require(closure=='9a250d61cbbd6f093a3fb78f66c75a21fd856ac495854b4670844f62f3bce0b0','reviewed source closure')
driver.require(not attempts,'no children')
print(json.dumps({'optimized':not __debug__,'coverage':{k:manifest[k] for k in ('recipe_count','source_bytes','classifications')},'controls':controls,'child_attempts':len(attempts),'source_closure_keys_sha256':closure,'source_closure_keys':keys},sort_keys=True,indent=2))
