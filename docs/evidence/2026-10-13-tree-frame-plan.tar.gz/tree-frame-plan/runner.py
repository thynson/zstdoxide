from pathlib import Path
import hashlib,json,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-frame-plan-checks');O.mkdir();names=['scripts/capture_tree_frames.py','scripts/check_tree_frame_capture.py','scripts/check_tree_frame_plan.py'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in names};rows=[]
for label,flags in [('normal',[]),('optimized',['-O'])]:
 args=['python3',*flags,'scripts/check_tree_frame_plan.py'];start=time.monotonic();p=subprocess.run(args,cwd=R,capture_output=True,timeout=120);b=p.stdout+p.stderr;log=O/(label+'.log');log.write_bytes(b);rows.append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest()))
 if p.returncode:raise ValueError(label)
 value=json.loads(p.stdout.splitlines()[-1]);assert value['forged_rejections']==10 and value['child_attempts']==0 and value['plan']['expected_commands']==1162
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,preflight=value,qualification='Offline capture preflight before C execution; exact per-command audit is separately implemented in the pinned auditor.'),sort_keys=True,indent=2)+'\n')
