from pathlib import Path
import copy,hashlib,json,os,subprocess,sys
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize')
CAPTURE=Path('/private/tmp/zstdoxide-lazy-frames-2026-10-13')
sys.path.insert(0,str(ROOT/'scripts'))
children=[]
def forbidden(*args,**kwargs):
 children.append('blocked');raise RuntimeError('child execution forbidden in offline audit')
subprocess.Popen=forbidden
for name in ['system','fork','forkpty','posix_spawn','posix_spawnp','spawnl','spawnle','spawnlp','spawnlpe','spawnv','spawnve','spawnvp','spawnvpe','execl','execle','execlp','execlpe','execv','execve','execvp','execvpe']:
 if hasattr(os,name):setattr(os,name,forbidden)
import check_lazy_frame_capture as m
loaded=m.inputs();m.inputs=lambda:loaded
capture,_,_,v,_,cases=loaded
# Memoize only immutable source inputs, never altered evidence or observations.
predecessors=capture.predecessor_artifacts();capture.predecessor_artifacts=lambda:predecessors
coverage,artifacts,summaries=m.audit(CAPTURE)
print('positive complete audit passed',file=sys.stderr,flush=True)
read=m.read;original=json.loads(read(CAPTURE,'evidence.json'));rejected=[]
def evidence_control(name,change,extra=None):
 value=copy.deepcopy(original);change(value)
 altered={'evidence.json':json.dumps(value,sort_keys=True).encode()} | (extra or {})
 m.read=lambda r,n,cap=64<<20:altered[n] if r==CAPTURE and n in altered else read(r,n,cap)
 try:m.audit(CAPTURE)
 except (ValueError,KeyError,TypeError):rejected.append(name)
 else:raise ValueError('forged capture accepted: '+name)
 finally:m.read=read
 print('rejected '+name,file=sys.stderr,flush=True)
for key,value in [('status','running'),('schema_version',True),('reference_revision','0'*40),('support_archive_used',True),('normal_sanitized_equal',False)]:
 evidence_control('scope_'+key,lambda e,k=key,v=value:e.__setitem__(k,v))
evidence_control('source_after',lambda e:e['source_after'][0].__setitem__('sha256','0'*64))
evidence_control('missing_command',lambda e:e['commands'].pop())
evidence_control('duplicate_command',lambda e:e['commands'].__setitem__(-1,e['commands'][0]))
evidence_control('upstream_hash',lambda e:e['reference_source_sha256'].__setitem__('lib/compress/zstd_lazy.c','0'*64))
evidence_control('coherent_local_hash',lambda e:(e['source_before'][0].__setitem__('sha256','0'*64),e['source_after'][0].__setitem__('sha256','0'*64)))
evidence_control('missing_input',lambda e:(e['source_before'].pop(),e['source_after'].pop()))
for key,value in [('exit_code',True),('exit_code',1),('timeout_seconds',181),('per_stream_cap',1<<30),('cwd','/wrong')]:
 evidence_control('command_'+key+'_'+str(value),lambda e,k=key,v=value:e['commands'][0].__setitem__(k,v))
evidence_control('command_error',lambda e:e['commands'][0].__setitem__('error','ignored timeout'))
evidence_control('unexpected_environment',lambda e:e['commands'][0]['environment'].__setitem__('LD_PRELOAD','bad'))
evidence_control('missing_sanitizer_environment',lambda e:next(c for c in e['commands'] if c['label']=='sanitized-metadata')['environment'].pop('ASAN_OPTIONS'))
evidence_control('log_hash',lambda e:e['commands'][0]['stdout'].__setitem__('sha256','0'*64))
evidence_control('log_size_bool',lambda e:e['commands'][0]['stdout'].__setitem__('bytes',True))
evidence_control('log_path',lambda e:e['commands'][0]['stdout'].__setitem__('path','../evidence.json'))
evidence_control('wrong_revision_command',lambda e:e['commands'][0]['argv'].__setitem__(-1,'main'))
evidence_control('compiled_units',lambda e:e['results']['normal']['compiled_codec_sources'].pop())
evidence_control('instrumented_units',lambda e:e['results']['normal']['instrumented_codec_sources'].append('lib/compress/zstd_lazy.c'))
evidence_control('binary_hash',lambda e:e['results']['normal'].__setitem__('executable_sha256','0'*64))
# Coherently rewrite both build logs, command hashes and summary stdout hashes.
# This deliberately bypasses mere cross-build equality and local log hashing.
def paired(name,case_name,change,semantically_valid=False):
 case=next(c for c in cases if c.name==case_name)
 rows=[v.parse_json(line) for line in artifacts[case_name+'.stdout'].splitlines()]
 change(rows)
 if semantically_valid:
  v.validate_case(case,rows,artifacts[case_name+'.zst'],artifacts.get(case_name+'.whole.zst'))
 raw=b''.join((json.dumps(r,separators=(',',':'))+'\n').encode() for r in rows)
 digest=hashlib.sha256(raw).hexdigest();extra={}
 for mode in ['normal','sanitized']:extra[mode+'-'+case_name+'.stdout']=raw
 def changes(e):
  for mode in ['normal','sanitized']:
   label=mode+'-'+case_name
   cmd=next(c for c in e['commands'] if c['label']==label)
   cmd['stdout']={'path':label+'.stdout','bytes':len(raw),'sha256':digest}
   next(c for c in e['results'][mode]['cases'] if c['id']==case_name)['stdout_sha256']=digest
 evidence_control(name,changes,extra)
paired('coherent_depth_strategy','d0_chain_empty',lambda r:r[0]['applied'].__setitem__(6,4))
def change_cache(rows):
 block=next(r for r in rows if r['type']=='block')
 block['sampling_after']['cache'][0]^=1
paired('coherent_valid_predecessor_cache','d0_row_first_uniform',change_cache,True)
# Focused semantic controls at each real depth avoid reusing an expected parser.
by_name={c.name:c for c in cases}
def semantic(name,case_name,change,frame_change=None):
 case=by_name[case_name];rows=[v.parse_json(line) for line in artifacts[case_name+'.stdout'].splitlines()]
 change(rows);frame=artifacts[case_name+'.zst']
 if frame_change:frame=frame_change(frame)
 try:v.validate_case(case,rows,frame,artifacts.get(case_name+'.whole.zst'))
 except (ValueError,KeyError,TypeError):rejected.append(name)
 else:raise ValueError('forged actual observation accepted: '+name)
for depth in range(3):
 for branch in ['chain','row']:
  name=f'd{depth}_{branch}_first_uniform'
  def block(rows):return next(r for r in rows if r['type']=='block')
  semantic(name+'_strategy',name,lambda r:r[0]['applied'].__setitem__(6,2))
  semantic(name+'_repeat',name,lambda r:block(r)['candidate']['semantic_repeats'].__setitem__(0,999))
  semantic(name+'_delta',name,lambda r:block(r)['first_table']['changed'].append([0,0,1]))
  semantic(name+'_frame',name,lambda r:None,lambda b:b+b'\0')
  tiny=f'd{depth}_{branch}_window_floor_tiny1'
  semantic(tiny+'_floor',tiny,lambda r:[x for x in r if x['type']=='block'][2]['sampling_after'].__setitem__('next_to_update',2))
if children or len(rejected)!=58:raise ValueError(('control count',len(rejected),children))
if '--export' in sys.argv:
 target=Path('/private/tmp/zstdoxide-lazy-frame-audited')
 if target.exists():raise ValueError('fresh audited export required')
 pack=bytearray();catalog={}
 for name,data in sorted(artifacts.items()):
  if len(pack)+len(data)>256<<20:raise ValueError('audited pack cap')
  catalog[name]={'offset':len(pack),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};pack.extend(data)
 metadata={'coverage':coverage,'cases':summaries,'artifacts':catalog,'pack_bytes':len(pack),
           'pack_sha256':hashlib.sha256(pack).hexdigest(),'capture_evidence_sha256':hashlib.sha256(read(CAPTURE,'evidence.json')).hexdigest(),
           'checker_sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest(),'controller_sha256':m.CONTROLLER_SHA}
 target.mkdir();(target/'artifacts.bin').write_bytes(pack)
 (target/'audit.json').write_text(json.dumps(metadata,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'passed','optimization':sys.flags.optimize,'child_attempts':len(children),
 'coverage':coverage,'rejected_controls':rejected,'positive_audits':1,
 'coherent_pair_controls':2,'semantically_valid_predecessor_cache_control':True,
 'auditor_sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()},sort_keys=True))
