//! Batch clocks with at least128 operations avoid per-call clock-resolution zeros.
//! Deterministic structural queries; allocation-free production module is separately core-qualified.
#![forbid(unsafe_code)]
use std::{hint::black_box, time::Instant};
use zstdoxide::{decompressed_size, decompression_bound, decompression_margin, frame_info};
struct Case {
    name: &'static str,
    bytes: Vec<u8>,
}
fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |h, &b| {
        (h ^ u64::from(b)).wrapping_mul(0x100000001b3)
    })
}
fn cases() -> Vec<Case> {
    let mut cases = vec![
        Case {
            name: "known-small",
            bytes: vec![0x28, 0xb5, 0x2f, 0xfd, 0x20, 3, 25, 0, 0, b'a', b'b', b'c'],
        },
        Case {
            name: "unknown-small",
            bytes: vec![0x28, 0xb5, 0x2f, 0xfd, 0, 56, 25, 0, 0, b'a', b'b', b'c'],
        },
        Case {
            name: "empty-frame",
            bytes: vec![0x28, 0xb5, 0x2f, 0xfd, 0x20, 0, 1, 0, 0],
        },
    ];
    let mut skip = vec![0x5f, 0x2a, 0x4d, 0x18];
    skip.extend_from_slice(&(129_u32 * 1024).to_le_bytes());
    skip.resize(8 + 129 * 1024, 0xa5);
    cases.push(Case {
        name: "skip-large",
        bytes: skip,
    });
    macro_rules! fixture {
        ($name:literal) => {
            cases.push(Case {
                name: $name,
                bytes: include_bytes!(concat!("../tests/upstream/decodecorpus/", $name, ".zst"))
                    .to_vec(),
            });
        };
    }
    fixture!("compressed-05");
    fixture!("small-blocks-07");
    fixture!("large-content-04");
    let mut joined = cases[0].bytes.clone();
    joined.extend_from_slice(&cases[3].bytes);
    joined.extend_from_slice(&cases[4].bytes);
    cases.push(Case {
        name: "concatenated",
        bytes: joined,
    });
    let count = (1 << 15) + 1;
    let mut many = vec![0x28, 0xb5, 0x2f, 0xfd, 0, 56];
    for _ in 1..count {
        many.extend_from_slice(&[0, 0, 0]);
    }
    many.extend_from_slice(&[1, 0, 0]);
    cases.push(Case {
        name: "many-blocks",
        bytes: many,
    });
    let mut truncated = cases[5].bytes.clone();
    truncated.pop();
    cases.push(Case {
        name: "truncated",
        bytes: truncated,
    });
    cases.push(Case {
        name: "empty",
        bytes: Vec::new(),
    });
    cases
}
fn main() {
    let command = std::env::args().nth(1).expect("qualify or measure");
    assert!(command == "qualify" || command == "measure");
    for Case { name, bytes } in cases() {
        let first = frame_info(&bytes);
        let exact = decompressed_size(&bytes);
        let bound = decompression_bound(&bytes);
        let margin = decompression_margin(&bytes);
        let hash = fingerprint(&bytes);
        if name == "many-blocks" {
            assert!(bound.unwrap() > 0x1_0000_0000);
        }
        if name == "truncated" {
            assert!(first.is_err() && exact.is_err() && bound.is_err() && margin.is_err());
        }
        if name == "empty" {
            assert!(first.is_err());
            assert_eq!(exact, Ok(Some(0)));
            assert_eq!(bound, Ok(0));
            assert_eq!(margin, Ok(0));
        }
        if command == "qualify" {
            println!(
                "{name}\t{}\t{hash:016x}\t{first:?}\t{exact:?}\t{bound:?}\t{margin:?}\tcore-only-query-component",
                bytes.len()
            );
            continue;
        }
        let iterations = (1024 * 1024 / bytes.len().max(1)).clamp(128, 1024);
        for mode in [
            "first-frame",
            "total-size",
            "total-bound",
            "in-place-margin",
        ] {
            for sample in 0..5 {
                let start = Instant::now();
                for _ in 0..iterations {
                    match mode {
                        "first-frame" => {
                            black_box(frame_info(black_box(&bytes))).ok();
                        }
                        "total-size" => {
                            black_box(decompressed_size(black_box(&bytes))).ok();
                        }
                        "total-bound" => {
                            black_box(decompression_bound(black_box(&bytes))).ok();
                        }
                        "in-place-margin" => {
                            black_box(decompression_margin(black_box(&bytes))).ok();
                        }
                        _ => unreachable!(),
                    }
                }
                let elapsed = start.elapsed().as_nanos();
                assert_eq!(frame_info(&bytes), first);
                assert_eq!(decompressed_size(&bytes), exact);
                assert_eq!(decompression_bound(&bytes), bound);
                assert_eq!(decompression_margin(&bytes), margin);
                assert_eq!(fingerprint(&bytes), hash);
                println!("{name}\t{mode}\t{sample}\t{iterations}\t{elapsed}");
            }
        }
    }
}
