from pathlib import Path
import shutil
T=Path('/private/tmp');D=T/'clock-resolution-reconciliation';B=D/'original-controllers';B.mkdir(exist_ok=True)
paths=[T/'wait-prior-timings-then-matrix.py',T/'wait-prior-timings-then-module33-matrix.py',*[T/f'module{m}-matrix/check.py' for m in [31,32,33]],T/'wait-and-measure-module31-33.py',T/'wait-and-promote-module28-30.py',T/'wait-and-promote-module31-34.py',T/'module33-benchmark/measure.py']
for p in paths:
 shutil.copyfile(p,B/(str(p.relative_to(T)).replace('/','__')))
 s=p.read_text()
 if p.name in ['wait-prior-timings-then-matrix.py','wait-prior-timings-then-module33-matrix.py']:
  s=s.replace("Path(f'/private/tmp/module{prior}-benchmark')","Path(f'/private/tmp/module{prior}-benchmark'+('-v2' if prior==30 else ''))")
 elif p.name=='check.py':s=s.replace("Path(f'/private/tmp/module{prior}-benchmark')","Path(f'/private/tmp/module{prior}-benchmark'+('-v2' if prior==30 else ''))")
 elif p.name=='wait-and-measure-module31-33.py':
  s=s.replace("T/f'module{m}-benchmark'/(c+'timed.json')","T/(f'module{m}-benchmark'+('-v2' if m==30 else ''))/(c+'timed.json')")
  s=s.replace("T/f'module{m}-benchmark'/(c+'evidence.json')","T/(f'module{m}-benchmark'+('-v2' if m==31 else ''))/(c+'evidence.json')")
  s=s.replace("T/f'module{m}-benchmark/harness-check.json'","T/(f'module{m}-benchmark'+('-v2' if m==31 else ''))/'harness-check.json'")
  s=s.replace("'module31-benchmark'","'module31-benchmark-v2'")
 elif p.name=='wait-and-promote-module28-30.py':
  s=s.replace('D.mkdir();','D.mkdir(exist_ok=True);').replace("T/f'module{m}-benchmark'/(c+'timed.json')","T/(f'module{m}-benchmark'+('-v2' if m==30 else ''))/(c+'timed.json')")
 elif p.name=='wait-and-promote-module31-34.py':
  s=s.replace('D.mkdir();','D.mkdir(exist_ok=True);').replace("T/f'module{m}-benchmark'/(c+'timed.json')","T/(f'module{m}-benchmark'+('-v2' if m==31 else ''))/(c+'timed.json')").replace("'module31-benchmark'","'module31-benchmark-v2'")
 elif p.parent.name=='module33-benchmark':s=s.replace("f'module{m}-benchmark/{c}timed.json'","f'module{m}-benchmark'+('-v2' if m==31 else '')+f'/{c}timed.json'")
 p.write_text(s)
for m in [30,31]:
 for name in ['archive-benchmark.py','render-benchmark-report.py','promote-final.py','close-module.py']:
  p=T/f'module{m}-archives'/name;shutil.copyfile(p,B/(f'module{m}-archives__'+name));s=p.read_text();s=s.replace("('module'+a.module+'-benchmark')","('module'+a.module+'-benchmark-v2')").replace(f"module{m}-benchmark'",f"module{m}-benchmark-v2'")
  s=s.replace('equal per-operation clock overhead','equal batch-loop, dispatch and black-box overhead')
  s=s.replace('equal timer overhead','equal batch-loop overhead').replace('equal timer\noverhead','equal batch-loop\noverhead').replace('Tiny scalar work is dominated by clock overhead','Tiny scalar work includes loop/dispatch overhead')
  if m==30:s=s.replace('deterministic 8..1,024 iterations per sample. Every operation takes its own clock\nreading; timer overhead is retained.','deterministic 128..1,024 iterations per sample. One clock brackets the complete\nbatch, retaining loop/dispatch/black-box overhead.')
  else:s=s.replace('8..1,024 iterations. Every operation has its own clock reading; timer overhead is\nretained.','128..1,024 iterations. One clock brackets the complete batch; loop/dispatch/\nblack-box overhead is retained.')
  if name=='render-benchmark-report.py':
   needle="text='''";assert needle in s;s=s.replace(needle,"text='''",1)
   # Append explicit repair history before writing the final report.
   anchor="(D/'";position=s.rfind(anchor);assert position>=0
   note=('The initial query campaign retained two zero-duration samples from eight per-call timings of skip-large/first-frame. Its failed receipt, all raw samples and original23+2 executables remain archived. No zero was discarded or clamped; every new batch-clock backend and independent repeat was rebuilt, requalified and timed from fresh barriers.' if m==30 else 'The analogous per-call scalar-clock preparation was replaced before any utility timings after the query campaign exposed clock-resolution zeros. Original qualified23+2 builds remain retained. Every new batch-clock backend and independent repeat was rebuilt, requalified and timed from fresh barriers.')
   s=s[:position]+"text += '''\\n## Clock-resolution repair\\n\\n"+note+"\\n'''\n"+s[position:]
  p.write_text(s)
