from pathlib import Path
import json,subprocess,time,datetime,sys
m=int(sys.argv[1]);assert m in [31,32];D=Path(f'/private/tmp/module{m}-matrix');deadline=datetime.datetime(2026,10,27,8,32,32,tzinfo=datetime.timezone.utc).timestamp()
while True:
 ready=True
 for prior in [28,29,30]:
  for c in ['', 'repeat/']:
   p=Path(f'/private/tmp/module{prior}-benchmark')/(c+'timed.json')
   if not p.exists():ready=False;continue
   try:j=json.loads(p.read_text())
   except json.JSONDecodeError:ready=False;continue
   assert j['status'] in ['running','passed'],(p,j.get('error'))
   if j['status']!='passed':ready=False
 if ready:break
 if time.time()>deadline-60:raise TimeoutError('No matrix dispatched after work-window cutoff')
 time.sleep(10)
print('All preceding actual primary/repeat timing gates passed; dispatching Module',m,flush=True)
subprocess.run(['python3',str(D/'check.py')],check=True)
