from pathlib import Path
import argparse,json,hashlib,shutil,subprocess
p=argparse.ArgumentParser();p.add_argument('stage',choices=['matrix','benchmarks']);a=p.parse_args();D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
state=D/'promotion-state.json';prev=json.loads(state.read_text());assert prev['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();production={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')};assert production==prev['production_source']
assert (a.stage=='matrix' and prev['stage']=='platform') or (a.stage=='benchmarks' and prev['stage']=='matrix')
name='2026-10-27-frame-query-'+('feature-matrix' if a.stage=='matrix' else 'benchmarks');record=D/(name+'.json');j=json.loads(record.read_text());assert j['status']=='passed';assert sha(D/j['archive'])==j['archive_sha256'];assert not (E/record.name).exists()
if a.stage=='matrix':
 assert j['production_source']==production
 for n,h in j['source'].items():assert sha(R/n)==h,n
else:assert j['build']['production_source']==production
changed=[]
for p in [record,D/j['archive']]:shutil.copyfile(p,E/p.name);changed.append('docs/evidence/'+p.name)
task='Qualify safe, every isolated feature' if a.stage=='matrix' else 'Compare frozen structural workloads';p=R/'TODO.md';s=p.read_text();start=s.index('## Module 30:');end=s.index('\n## ',start+1);part=s[start:end];lines=part.splitlines();matches=[i for i,l in enumerate(lines) if l.startswith('- [ ] '+task)];assert len(matches)==1;lines[matches[0]]=lines[matches[0]].replace('[ ]','[x]',1);p.write_text(s[:start]+'\n'.join(lines)+'\n'+s[end:]);changed.append('TODO.md')
p=R/'docs/frame-query-validation.md'
if a.stage=='matrix':
 p.write_text(p.read_text()+'''\n## Complete feature and release regression\n\nThe final frozen candidate passed all 72 commands: safe/all and 21 isolated\nunsafe features each have complete tests, true no_std and strict Clippy; safe/all\ncomplete release and formatting also pass. Every full/release suite reports\n1,690 passed / 67 ignored across 101 result groups. External adapters retain their\nseparate explicit execution receipts; ignored tests are not credited as passes.\nPreflight strict Clippy rejected a native adapter chunk operation. Checked\nas_chunks with an explicit empty remainder fixed that test-only warning; all\nthree native replays and preflight passed before the final full matrix.\nEvidence: `evidence/2026-10-27-frame-query-feature-matrix.json`.\n''')
else:
 p.write_text(p.read_text()+'''\n## Measured deterministic comparisons\n\nAll 23 retained primary backends and independently rebuilt safe/all repeats have\nidentical clock-free structural-result qualification and complete raw timing\nrecords. Each query mode is timed separately with equal per-operation clock overhead.\nFresh primary/repeat CPU barriers precede sequential measurements. See\n`frame-query-benchmarks.md`; the host results do not establish a universal\nunsafe speedup. Evidence: `evidence/2026-10-27-frame-query-benchmarks.json`.\n''');shutil.copyfile(D/'frame-query-benchmarks.md',R/'docs/frame-query-benchmarks.md');changed.append('docs/frame-query-benchmarks.md')
changed.append('docs/frame-query-validation.md');subprocess.run(['cargo','fmt','--all','--','--check'],cwd=R,check=True);subprocess.run(['git','diff','--check'],cwd=R,check=True);subprocess.run(['git','add','--',*changed],cwd=R,check=True);subprocess.run(['git','commit','-m','Complete frame-query full feature qualification' if a.stage=='matrix' else 'Measure checked structural query latency'],cwd=R,check=True)
prev.update(stage=a.stage,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip());state.write_text(json.dumps(prev,indent=2)+'\n')
