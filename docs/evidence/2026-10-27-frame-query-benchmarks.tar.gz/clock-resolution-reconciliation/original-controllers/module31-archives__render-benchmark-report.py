from pathlib import Path
import json
D=Path(__file__).parent;j=json.loads((D/'2026-10-27-frame-utility-benchmarks.json').read_text());assert j['status']=='passed';s=j['summary'];modes=['compression-bound','write-skippable']
text='''# Compression-bound and skippable-write measurements

Eleven deterministic cases cover empty/one-byte payloads, small-margin and block
boundaries, scalar width limits, invalid variants and short destinations. Scalar
source_size and writer payload/capacity/variant are separate recorded fields:
width-limit arithmetic uses small genuine payloads, never gigantic allocations.

## Method and limits

Twenty-three primary executables cover safe, all and 21 isolated unsafe features.
Independent safe/all rebuilds provide a separate repeat. Each executable yields
110 raw samples: eleven cases, two operations and five samples with deterministic
8..1,024 iterations. Every operation has its own clock reading; timer overhead is
retained. Tiny scalar work can be dominated by this overhead, so do not interpret
small latency differences as a general arithmetic or unsafe performance benefit.
The utility implementations share the same safe scalar/slice-copy representation
in every configuration; other codec features are still compiled independently.

Caller storage, payload construction, hashes and guard/result assertions occur
outside timed calls. Writing includes variant/size/capacity validation, header
serialization and payload copying; repeated writes are idempotent in the same
caller buffer. No source restoration is necessary or excluded from a changing
state. Bounds and writes have different contracts and are not interchangeable.
All/safe ratios compare identical operations and cases. Geometric means weight
the ten nonempty-payload cases equally; empty payload remains in raw data.

Two fresh process observations precede primary and repeat after the recorded
task CPU jobs complete. Whole-desktop idleness, statistical significance and
architecture-independent performance are not claimed. Lower ratios mean lower
observed median latency on this host.

## Observed latency relative to the safe backend

| Campaign | Backend | Compression bound | Skippable writing |
| --- | --- | ---: | ---: |
'''
for campaign in ['primary','repeat']:
 for name in ([b['name'] for b in j['build']['builds']] if campaign=='primary' else ['safe','all']):
  values=[]
  for mode in modes:
   rows=[r for r in s['comparisons'] if (r['campaign'],r['backend'],r['mode'])==(campaign,name,mode)];assert len(rows)==1;values.append(rows[0]['nonempty_geomean'])
  text+='| '+campaign+' | '+name+' | '+' | '.join(f'{v:.4f}' for v in values)+' |\n'
text+='''
## Qualification and retained evidence

All eleven clock-free rows agree across every retained build. Rows include each
scalar input, real payload/capacity/variant, input/output identity and typed result.
Successful payloads/unused suffixes and rejected destinations retain their guards.
These are result/guard qualification records, not dynamic allocator counters.
Separate exact-production core-only component checks establish no allocator
dependency; the full codec remains no_std plus alloc.

The archive retains exact source/harness, generated-workload recipe, all retained
executables, qualification rows, raw samples, summaries and actual CPU barriers.
No external native implementation executes inside measured operations. Evidence:
`evidence/2026-10-27-frame-utility-benchmarks.json`.
'''
(D/'frame-utility-benchmarks.md').write_text(text)
