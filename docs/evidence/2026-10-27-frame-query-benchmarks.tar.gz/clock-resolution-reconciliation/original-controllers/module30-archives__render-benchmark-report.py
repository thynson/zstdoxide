from pathlib import Path
import json
D=Path(__file__).parent;j=json.loads((D/'2026-10-27-frame-query-benchmarks.json').read_text());assert j['status']=='passed';s=j['summary'];modes=['first-frame','total-size','total-bound','in-place-margin']
text='''# Checked structural frame-query measurements

Eleven frozen cases cover known/unknown small frames, an empty-output frame,
a 129 KiB skippable payload, three pinned compressed corpus inputs, concatenated
frames, 32,769 blocks, truncation and empty input. These queries scan framing;
they do not decode entropy or validate checksum values.

## Method and limits

Twenty-three retained primary executables cover safe, all and 21 isolated unsafe
features. Independent safe/all rebuilds provide a separate repeat. Each executable
has 220 raw samples: eleven cases, four query modes and five samples, with a
deterministic 8..1,024 iterations per sample. Every operation takes its own clock
reading; timer overhead is retained. Input construction, hashing, assertions and
result formatting occur outside the measured call.

First-frame, total advertised size, total bound and in-place margin have distinct
contracts. Their absolute latencies are retained independently; a faster mode is
not claimed a substitute for another. The all/safe ratios below compare the same
operation on the same input. Equal-weight geometric means cover the ten cases
with nonempty encoded input, including the empty-output frame. Empty input remains
in raw data, outside the aggregate. Lower ratios indicate lower observed latency.

Two fresh process observations precede each primary/repeat campaign after the
recorded task CPU jobs complete. This does not claim whole-desktop idleness.
Fixed backend order and five samples do not establish statistical significance,
architecture independence or a universal unsafe speedup.

## Observed latency relative to the safe backend

| Campaign | Backend | First frame | Total size | Total bound | In-place margin |
| --- | --- | ---: | ---: | ---: | ---: |
'''
for campaign in ['primary','repeat']:
 for name in ([b['name'] for b in j['build']['builds']] if campaign=='primary' else ['safe','all']):
  values=[]
  for mode in modes:
   rows=[r for r in s['comparisons'] if (r['campaign'],r['backend'],r['mode'])==(campaign,name,mode)];assert len(rows)==1;values.append(rows[0]['nonempty_geomean'])
  text+='| '+campaign+' | '+name+' | '+' | '.join(f'{v:.4f}' for v in values)+' |\n'
text+='''
## Qualification and retained evidence

All eleven clock-free rows match across all primary and repeat builds. Each row
records deterministic input identity and all four query outcomes. These rows are
not runtime allocation counters. Separately qualified core-only builds of the
exact production query component establish that it has no allocator dependency;
the full codec remains no_std plus alloc, and benchmark fixture construction uses
ordinary host allocation outside measured calls.

The archive retains the exact harness and production snapshot, measured fixture
payloads, all retained executables, qualification rows, raw samples, summaries,
process-observer source and actual CPU barriers. No native codec runs inside the
timed operations. Unused historical binary fixtures retain inventory hashes.
Evidence: `evidence/2026-10-27-frame-query-benchmarks.json`.
'''
(D/'frame-query-benchmarks.md').write_text(text)
