"""Close only after integrated focused, native, full-matrix and measured gates."""
from pathlib import Path
import json,hashlib,subprocess,tarfile,datetime
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();state=D/'promotion-state.json';previous=json.loads(state.read_text());assert previous['stage']=='benchmarks'
assert previous['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
production={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')};assert production==previous['production_source']
names=['2026-10-27-frame-utility-'+stage for stage in ['core','public-api','native','history','platform','feature-matrix','benchmarks']];records={}
for n in names:
 p=E/(n+'.json');j=json.loads(p.read_text());assert j['status']=='passed',n;assert sha(E/j['archive'])==j['archive_sha256'],n;records[n]=dict(receipt_sha256=sha(p),archive_sha256=j['archive_sha256'])
for stage in ['public-api','native','history','platform','feature-matrix']:
 j=json.loads((E/('2026-10-27-frame-utility-'+stage+'.json')).read_text());assert j['production_source']==production,stage
matrix=json.loads((E/'2026-10-27-frame-utility-feature-matrix.json').read_text())
for n,h in matrix['source'].items():assert sha(R/n)==h,n
bench=json.loads((E/'2026-10-27-frame-utility-benchmarks.json').read_text());assert bench['build']['production_source']==production
pred=E/'2026-10-27-frame-query-closure.json';assert json.loads(pred.read_text())['status']=='passed';assert sha(E/json.loads(pred.read_text())['archive'])==json.loads(pred.read_text())['archive_sha256']
todo=(R/'TODO.md').read_text();start=todo.index('## Module 31:');end=todo.index('\n## ',start+1);unchecked=[l for l in todo[start:end].splitlines() if l.startswith('- [ ]')];assert len(unchecked)==1 and unchecked[0].startswith('- [ ] Reconcile');assert '## Module 32:' in todo and (R/'docs/one-shot-selection-design.md').exists()
C=Path('/private/tmp/module31-reconciliation');C.mkdir()
args=['python3','scripts/audit_upstream_tests.py','--upstream','/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99']
with (C/'inventory.log').open('xb') as f:p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
receipt=dict(status='passed',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,integrated_manifest_sha256=sha(R/'tests/upstream/manifest.json'),final_matrix_source=matrix['source'],evidence=records,predecessor_closure_sha256=sha(pred),inventory_command=args,inventory_log_sha256=sha(C/'inventory.log'),next_design_sha256=sha(R/'docs/one-shot-selection-design.md'),qualification='Bounded scalar-bound and borrowed skippable serialization milestone. Final public/native/platform/corpus/full-matrix and measured production sources match integrated bytes. Earlier component snapshots and rejected observation/test attempts retain their identities. Native helpers are external v1.5.7 oracles; generated layout cases do not upgrade unrelated original assertions. Call-scoped prefix lifecycle, workspaces and complete upstream parity remain open.')
(C/'reconciliation.json').write_text(json.dumps(receipt,indent=2)+'\n');name='2026-10-27-frame-utility-closure';archive=E/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in C.iterdir():t.add(p,arcname=p.name)
 t.add(__file__,arcname='close-module.py')
receipt.update(archive=archive.name,archive_sha256=sha(archive));(E/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
p=R/'docs/frame-utility-validation.md';s=p.read_text();old='Module 31 is in progress. Focused gates below are complete; full feature/release\nregression, measurements and final reconciliation remain separate gates.';assert old in s;s=s.replace(old,'Module 31 is complete within its bounded scalar-bound and borrowed skippable\nserialization scope. Focused, full feature/release, native/platform, measurements\nand final source gates have independently retained successful receipts.');s+='\n## Final reconciliation and remaining scope\n\nIntegrated production and final tests match the frozen full-matrix source. Every\nstage archive is rehashed. Initial preparation/controller rejections and the\nnative sentinel/error-precedence differences retain their identities. The bound\ncovers documented one-pass framing, not arbitrary streaming flushes or workspace\nrequirements. Call-scoped prefix ownership, native context/workspace contracts\nand complete upstream library/CLI parity remain separate work.\nEvidence: `evidence/2026-10-27-frame-utility-closure.json`.\n';p.write_text(s)
p=R/'README.md';s=p.read_text();old='Module 31 final qualification\nremains in progress in `TODO.md`.';assert old in s;p.write_text(s.replace(old,'Bounded qualification and native differences\nare recorded in [the frame utility report](docs/frame-utility-validation.md).'))
ratios=[f"{x['campaign']} {x['mode']} {x['nonempty_geomean']:.4f}" for x in bench['summary']['comparisons'] if x['backend']=='all'];p=R/'docs/progress.md';p.write_text(p.read_text()+'''\n## Module 31: compression bounds and skippable writing complete (2026-10-27)

Typed checked compression bounds use the pinned one-pass formula and explicit
pointer-width limits. Borrowed skippable writing validates every fallible argument
before mutation, writes exact little-endian header/payload bytes and preserves
unused suffixes. Both utilities allocate nothing; their component builds with
core only. The full codec remains no_std plus alloc. Ordinary/dictionary/admitted
reference one-shot encoder bounds are qualified; arbitrary streaming flushes and
workspace sizing remain excluded.

All 72 final commands pass: safe/all and 21 isolated full/no_std/Clippy selections,
safe/all release and formatting. Each full/release suite has 1,706 passes and
70 ignored across 105 groups. Normal/sanitized native helpers cover 280 scalar
inputs and 343 guarded writer layouts. One maximal numeric bound overlaps native
error sentinels; 58 doubly-invalid writer cases differ in documented error
precedence. These differences remain explicit. Exact original 129 KiB/empty
writer history captures preserve preceding seeds and all encoded/read assertions.
Eight foreign Miri executions plus host/core-only ARM checks yield 13 platform
commands. No unsupported macOS leak-detection result is claimed.

Twenty-three primary and independent safe/all repeat executables qualify identical
utility outcomes and guards. Two separately timed modes retain equal timer
overhead. All/safe nonempty-payload median-latency geometric means: '''+ '; '.join(ratios)+'''.
Tiny scalar work is dominated by clock overhead; these host measurements establish
no broad performance or unsafe-speedup guarantee. Underlying utility operations
share the same safe representation across feature selections.

Closure matches all integrated source/test identities and rehashes stage archives.
Completed checklist items are cleared; Module 32 retains call-scoped prefix and
persistent-selection ownership decomposition. Native workspace/reset parity and
complete upstream migration remain open. See `frame-utility-validation.md`,
`frame-utility-benchmarks.md` and `evidence/2026-10-27-frame-utility-closure.json`.
''')
replacement='''Module 31 is complete within its bounded scalar-bound and skippable-write scope.
Completed work items are archived in Git history and `docs/progress.md`.
Qualification and measurements are in `docs/frame-utility-validation.md`
and `docs/frame-utility-benchmarks.md`. The final receipt is
`docs/evidence/2026-10-27-frame-utility-closure.json`.
Complete upstream migration remains open.
''';(R/'TODO.md').write_text(todo[:start]+replacement+todo[end:])
paths=['TODO.md','README.md','docs/progress.md','docs/frame-utility-validation.md','docs/evidence/'+name+'.json','docs/evidence/'+name+'.tar.gz'];subprocess.run(['cargo','fmt','--all','--','--check'],cwd=R,check=True);subprocess.run(['git','diff','--check'],cwd=R,check=True);subprocess.run(['git','add','--',*paths],cwd=R,check=True);subprocess.run(['git','commit','-m','Close checked frame utility milestone'],cwd=R,check=True);previous.update(stage='closed',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip());state.write_text(json.dumps(previous,indent=2)+'\n')
