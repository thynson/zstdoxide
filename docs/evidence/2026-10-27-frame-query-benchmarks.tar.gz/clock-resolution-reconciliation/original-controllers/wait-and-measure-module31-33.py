from pathlib import Path
import json,subprocess,time,datetime,hashlib
T=Path('/private/tmp');deadline=datetime.datetime(2026,10,27,8,32,32,tzinfo=datetime.timezone.utc).timestamp();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();receipts={}
for m in [28,29,30,31,32,33]:receipts[str(T/f'module{m}-matrix/evidence.json')]='passed'
for m in [28,29,30]:
 for c in ['', 'repeat/']:receipts[str(T/f'module{m}-benchmark'/(c+'timed.json'))]='passed'
for m in [31,32]:
 for c in ['', 'repeat/']:receipts[str(T/f'module{m}-benchmark'/(c+'evidence.json'))]='qualified-not-timed'
 receipts[str(T/f'module{m}-benchmark/harness-check.json')]='passed'
for c in ['', 'repeat/']:receipts[str(T/'module33-compression-benchmark'/(c+'evidence.json'))]='qualified-not-timed'
receipts[str(T/'module33-compression-benchmark/harness-check.json')]='passed'
receipts[str(T/'module33-benchmark/evidence.json')]='qualified-not-timed'
for path in ['module33-engine/evidence.json','module33-public/evidence.json','module33-native/replay.json','module33-platform/evidence.json','module33-corpus/evidence.json']:receipts[str(T/path)]='passed'
while True:
 ready=True
 for p,status in receipts.items():
  try:j=json.loads(Path(p).read_text())
  except (FileNotFoundError,json.JSONDecodeError):ready=False;continue
  assert j['status'] not in ['failed','interrupted-at-user-deadline'],(p,j.get('error'))
  if j['status']!=status:ready=False
 if ready:break
 if time.time()>deadline-60:raise TimeoutError('No late timing dispatched after work-window cutoff')
 time.sleep(10)
for folder in ['module31-benchmark','module32-benchmark','module33-compression-benchmark']:
 p=T/folder/'timing-dispatch-gates.json';assert not p.exists();p.write_text(json.dumps(dict(status='ready',prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),receipts=receipts,receipt_sha256={n:sha(Path(n)) for n in receipts},qualification='All six actual full matrices and all focused/component/benchmark compilations completed. All earlier28–30 clocks completed. Fresh process observations remain mandatory before each sequential campaign; no desktop-idleness claim.'),indent=2)+'\n')
for folder in ['module31-benchmark','module32-benchmark']:
 print('Starting sequential',folder,'primary/repeat observation and measurement',flush=True);subprocess.run(['python3',str(T/folder/'observe-and-measure.py')],check=True)
print('Starting isolated33leaf measurements with fresh barriers',flush=True);subprocess.run(['python3',str(T/'module33-benchmark/measure.py')],check=True)
print('Starting full33compression primary/repeat measurements',flush=True);subprocess.run(['python3',str(T/'module33-compression-benchmark/observe-and-measure.py')],check=True)
print('All late sequential primary/repeat campaigns completed',flush=True)
