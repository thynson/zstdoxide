from pathlib import Path
import json,subprocess,time,datetime,hashlib
T=Path('/private/tmp');D=T/'module28-30-promotion';D.mkdir();deadline=datetime.datetime(2026,10,27,8,32,32,tzinfo=datetime.timezone.utc).timestamp();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while True:
 ready=True
 for m in [28,29,30]:
  for c in ['', 'repeat/']:
   p=T/f'module{m}-benchmark'/(c+'timed.json')
   try:j=json.loads(p.read_text())
   except (FileNotFoundError,json.JSONDecodeError):ready=False;continue
   assert j['status'] in ['running','passed'],(p,j.get('error'))
   if j['status']!='passed':ready=False
 p=T/'module29-cache-maintenance/removal.json'
 if not p.exists() or json.loads(p.read_text())['status']!='removed':ready=False
 if ready:break
 if time.time()>deadline-120:raise TimeoutError('No ordered promotion started after cutoff')
 time.sleep(10)
e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commands=[])
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,script,*args):
 assert time.time()<deadline-30,label;command=['python3',str(script),*args];t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=command,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log'))));save();print(label,p.returncode,flush=True);assert p.returncode==0,(label,(D/(label+'.log')).read_text()[-4000:])
save()
try:
 run('30-matrix-archive',T/'module30-archives/archive-matrix.py');run('30-cache-prune',T/'module30-cache-maintenance/prune.py')
 for m,folder,stages in [(28,'module28-session-archives',[]),(29,'module29-archives',['engine','public-api','native','platform']),(30,'module30-archives',['layout','public-api','native','platform'])]:
  A=T/folder
  for stage in stages:run(f'{m}-{stage}-promote',A/'promote-focused.py',stage)
  if m!=28:run(f'{m}-matrix-promote',A/'promote-final.py','matrix')
  run(f'{m}-benchmark-archive',A/'archive-benchmark.py',str(m));run(f'{m}-benchmark-report',A/'render-benchmark-report.py');run(f'{m}-benchmark-promote',A/'promote-final.py','benchmarks');run(f'{m}-close',A/'close-module.py')
 e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print('Ordered28–30 source closures committed',flush=True)
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
