from pathlib import Path
import json,subprocess,time,datetime,hashlib
T=Path('/private/tmp');R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=T/'module31-34-promotion';D.mkdir();deadline=datetime.datetime(2026,10,27,8,32,32,tzinfo=datetime.timezone.utc).timestamp();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while True:
 ready=True
 checks=[T/'module28-30-promotion/evidence.json',T/'module34-engine/evidence.json',T/'module33-benchmark/timed.json',*[T/f'module{m}-benchmark'/(c+'timed.json') for m in [31,32] for c in ['', 'repeat/']],*[T/'module33-compression-benchmark'/(c+'timed.json') for c in ['', 'repeat/']]]
 for p in checks:
  try:j=json.loads(p.read_text())
  except (FileNotFoundError,json.JSONDecodeError):ready=False;continue
  assert j['status'] in ['running','passed'],(p,j.get('error'))
  if j['status']!='passed':ready=False
 for folder in ['module31-benchmark','module32-benchmark','module33-compression-benchmark']:
  if not (T/folder/'summary.json').exists():ready=False
 if ready:break
 if time.time()>deadline-120:raise TimeoutError('No ordered late promotion started after cutoff')
 time.sleep(10)
e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commands=[])
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,script,*args):
 assert time.time()<deadline-30,label;command=['python3',str(script),*args];t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=command,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log'))));save();print(label,p.returncode,flush=True);assert p.returncode==0,(label,(D/(label+'.log')).read_text()[-4000:])
save()
try:
 for m in [31,32]:
  A=T/f'module{m}-archives'
  run(f'{m}-matrix-archive',A/'archive-matrix.py')
  for stage in ['core','public-api','native','platform']:run(f'{m}-{stage}-promote',A/'promote-focused.py',stage)
  run(f'{m}-matrix-promote',A/'promote-final.py','matrix');run(f'{m}-benchmark-archive',A/'archive-benchmark.py',str(m));run(f'{m}-benchmark-report',A/'render-benchmark-report.py');run(f'{m}-benchmark-promote',A/'promote-final.py','benchmarks');run(f'{m}-close',A/'close-module.py')
 run('32-inventory-reconciliation',T/'module32-inventory-plan/apply.py')
 A=T/'module33-archives';run('33-matrix-archive',A/'archive-matrix.py');run('33-leaf-benchmark-archive',A/'archive-benchmark.py');run('33-compression-benchmark-archive',A/'archive-compression-benchmark.py');run('33-storage-promote',A/'promote-storage.py')
 for stage in ['engine','public-api','native','platform']:run(f'33-{stage}-promote',A/'promote-focused.py',stage)
 for stage in ['matrix','benchmarks']:run(f'33-{stage}-promote',A/'promote-final.py',stage)
 run('33-close',A/'close-module.py');run('33-inventory-reconciliation',T/'module33-inventory-plan/apply.py');run('34-engine-promote',T/'module34-archives/promote-engine.py')
 e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print('Ordered31–33 closures, metadata reconciliations and focused34engine committed',flush=True)
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
