"""Close only after integrated focused, native, full-matrix and measured gates."""
from pathlib import Path
import json,hashlib,subprocess,tarfile,datetime
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();state=D/'promotion-state.json';previous=json.loads(state.read_text());assert previous['stage']=='benchmarks'
assert previous['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
production={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')};assert production==previous['production_source']
names=['2026-10-27-frame-query-'+stage for stage in ['layout','public-api','native','history','platform','corpus','feature-matrix','benchmarks']];records={}
for n in names:
 p=E/(n+'.json');j=json.loads(p.read_text());assert j['status']=='passed',n;assert sha(E/j['archive'])==j['archive_sha256'],n;records[n]=dict(receipt_sha256=sha(p),archive_sha256=j['archive_sha256'])
for stage in ['public-api','native','history','platform','corpus','feature-matrix']:
 j=json.loads((E/('2026-10-27-frame-query-'+stage+'.json')).read_text());assert j['production_source']==production,stage
matrix=json.loads((E/'2026-10-27-frame-query-feature-matrix.json').read_text())
for n,h in matrix['source'].items():assert sha(R/n)==h,n
bench=json.loads((E/'2026-10-27-frame-query-benchmarks.json').read_text());assert bench['build']['production_source']==production
pred=E/'2026-10-27-dictionary-in-place-closure.json';assert json.loads(pred.read_text())['status']=='passed';assert sha(E/json.loads(pred.read_text())['archive'])==json.loads(pred.read_text())['archive_sha256']
todo=(R/'TODO.md').read_text();start=todo.index('## Module 30:');end=todo.index('\n## ',start+1);unchecked=[l for l in todo[start:end].splitlines() if l.startswith('- [ ]')];assert len(unchecked)==1 and unchecked[0].startswith('- [ ] Reconcile');assert '## Module 31:' in todo and (R/'docs/frame-utilities-design.md').exists()
C=Path('/private/tmp/module30-reconciliation');C.mkdir()
args=['python3','scripts/audit_upstream_tests.py','--upstream','/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99']
with (C/'inventory.log').open('xb') as f:p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
receipt=dict(status='passed',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,integrated_manifest_sha256=sha(R/'tests/upstream/manifest.json'),final_matrix_source=matrix['source'],evidence=records,predecessor_closure_sha256=sha(pred),inventory_command=args,inventory_log_sha256=sha(C/'inventory.log'),next_design_sha256=sha(R/'docs/frame-utilities-design.md'),qualification='Bounded structural metadata and size-query milestone. Final public/native/platform/corpus/full-matrix and measured production sources match integrated bytes. Earlier component snapshots and rejected observation/test attempts retain their identities. Native helpers are external v1.5.7 oracles; generated layout cases do not upgrade unrelated original assertions. Compression-bound/write-skippable utilities, prefix lifecycle, workspaces and complete upstream parity remain open.')
(C/'reconciliation.json').write_text(json.dumps(receipt,indent=2)+'\n');name='2026-10-27-frame-query-closure';archive=E/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in C.iterdir():t.add(p,arcname=p.name)
 t.add(__file__,arcname='close-module.py')
receipt.update(archive=archive.name,archive_sha256=sha(archive));(E/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
p=R/'docs/frame-query-validation.md';s=p.read_text();old='Module 30 is in progress. Focused gates below are complete; full feature/release\nregression, measurements and final reconciliation remain separate gates.';assert old in s;s=s.replace(old,'Module 30 is complete within its bounded structural metadata and size-query\nscope. Focused, full feature/release, native/platform, measured and final source\ngates have independently retained successful receipts.');s+='\n## Final reconciliation and remaining scope\n\nIntegrated production and final tests match the frozen full-matrix source. All\nfocused and timing archives are rehashed. Earlier staging and rejected helper/test\nattempts retain their identities. Structural success does not validate entropy,\nchecksums or size truth. Compression-bound/write-skippable utilities, prefix\nlifecycle, external workspaces, legacy/magicless frames and full upstream parity\nremain outside this milestone. Original group 948 retains its partial status\nfor the explicit native error-sentinel comparison described above.\nEvidence: `evidence/2026-10-27-frame-query-closure.json`.\n';p.write_text(s)
p=R/'README.md';s=p.read_text();old='Module 30 final qualification remains in\nprogress in `TODO.md`.';assert old in s;p.write_text(s.replace(old,'Bounded qualification and explicit native differences are recorded in\n[the frame query report](docs/frame-query-validation.md).'))
ratios=[f"{x['campaign']} {x['mode']} {x['nonempty_geomean']:.4f}" for x in bench['summary']['comparisons'] if x['backend']=='all'];p=R/'docs/progress.md';p.write_text(p.read_text()+'''\n## Module 30: checked structural frame queries complete (2026-10-27)

Copied first-frame metadata, encoded extent, exact/unknown concatenated size,
checked decompression bounds and borrowed skippable payloads share one structural
traversal. Complete concatenations validate every tail, even after unknown size;
u64 sizes have no reserved sentinels and arithmetic overflow is explicit. The
query component builds with core only; the complete codec remains no_std + alloc.
Structural success does not prove entropy, checksum or advertised-size truth.

All 72 final commands pass: safe/all and 21 isolated full/no_std/Clippy selections,
safe/all release and formatting. Each full/release suite has 1,690 passes and
67 ignored across 101 groups. External adapters run explicitly in separate gates.
Normal/sanitized native helpers query 10,818 inputs; 550 early-unknown, window-cap
and numeric-sentinel/overflow differences are retained. Exact preceding original
fuzzer histories back single/multi-frame assertions. Original group 948 retains
its partial status: its full-capacity query yields an error sentinel, so its
unsigned comparison does not establish a meaningful upper bound. Useful exact-
frame-length checks are explicitly supplemental. Foreign width/endian Miri and
actual core-only ARM artifacts include the small-input above-4-GiB-bound case.

Twenty-three primary backends and independent safe/all repeats have identical
clock-free query results. Four distinct query modes retain equal timer overhead.
All/safe nonempty-input median-latency geometric means: '''+ '; '.join(ratios)+'''.
These fixed-order host measurements establish no universal unsafe speedup.

Closure rehashes every stage archive and matches integrated production/tests.
The completed checklist is cleared; Module 31 retains its utilities design.
Compression-bound/write-skippable utilities, reusable prefix lifecycle, workspaces
and full upstream library/CLI parity remain open. See `frame-query-validation.md`,
`frame-query-benchmarks.md` and `evidence/2026-10-27-frame-query-closure.json`.
''')
replacement='''Module 30 is complete within its bounded structural frame-query scope.
Completed work items are archived in Git history and `docs/progress.md`.
Qualification and measurements are in `docs/frame-query-validation.md`
and `docs/frame-query-benchmarks.md`. The final receipt is
`docs/evidence/2026-10-27-frame-query-closure.json`.
Complete upstream migration remains open.
''';(R/'TODO.md').write_text(todo[:start]+replacement+todo[end:])
paths=['TODO.md','README.md','docs/progress.md','docs/frame-query-validation.md','docs/evidence/'+name+'.json','docs/evidence/'+name+'.tar.gz'];subprocess.run(['cargo','fmt','--all','--','--check'],cwd=R,check=True);subprocess.run(['git','diff','--check'],cwd=R,check=True);subprocess.run(['git','add','--',*paths],cwd=R,check=True);subprocess.run(['git','commit','-m','Close checked structural frame query milestone'],cwd=R,check=True);previous.update(stage='closed',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip());state.write_text(json.dumps(previous,indent=2)+'\n')
