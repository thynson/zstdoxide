from pathlib import Path
import sys,json,hashlib,subprocess,os,time
m=int(sys.argv[1]);assert m in [30,31];D=Path(f'/private/tmp/module{m}-benchmark-v2');S=D/'source';bench={30:'frame_queries',31:'frame_utilities'}[m];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();e=dict(status='running',source_sha256=sha(S/'benches'/f'{bench}.rs'),commands=[]);env={**os.environ,'CARGO_TARGET_DIR':str(D/'harness-target'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'harness-check.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for label,args in [('safe',['cargo','clippy','--offline','--locked','--bench',bench,'--','-D','warnings']),('all',['cargo','clippy','--offline','--locked','--bench',bench,'--all-features','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check'])]:
  t=time.monotonic()
  with (D/('harness-'+label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/('harness-'+label+'.log'))));save();assert p.returncode==0,label
 e['status']='passed';save();subprocess.run(['python3',str(D/'build.py')],check=True);subprocess.run(['python3',str(D/'repeat-build.py')],check=True)
 assert (D/'safe-qualify.tsv').read_bytes()==Path(f'/private/tmp/module{m}-benchmark/safe-qualify.tsv').read_bytes()
 (D/'clock-repair-qualification.json').write_text(json.dumps(dict(status='passed',original_qualification_sha256=sha(Path(f'/private/tmp/module{m}-benchmark/safe-qualify.tsv')),replacement_qualification_sha256=sha(D/'safe-qualify.tsv'),primary_build_sha256=sha(D/'evidence.json'),repeat_build_sha256=sha(D/'repeat/evidence.json'),qualification='Batch-clock-only harness repair; all11 qualification rows identical to original. All23+2 newly compiled executables and three strict harness commands pass. Not yet timed.'),indent=2)+'\n');print(m,'all repaired builds qualified',flush=True)
except BaseException as ex:
 if e['status']=='running':e.update(status='failed',error=repr(ex));save()
 raise
