from pathlib import Path
import json,time,subprocess,hashlib,datetime
T=Path('/private/tmp');D=T/'module30-benchmark-v2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,27,8,32,32,tzinfo=datetime.timezone.utc).timestamp()
while True:
 ready=True
 for m in [30,31]:
  p=T/f'module{m}-benchmark-v2/clock-repair-qualification.json'
  if not p.exists():ready=False;continue
  assert json.loads(p.read_text())['status']=='passed'
 if ready:break
 assert time.time()<deadline-60;time.sleep(5)
old=json.loads((T/'module30-benchmark/timing-dispatch-gates.json').read_text());receipts={}
for p,status in old['receipts'].items():
 for m in [30,31]:p=p.replace(f'/module{m}-benchmark/',f'/module{m}-benchmark-v2/')
 receipts[p]=status
for m in [30,31]:receipts[str(T/f'module{m}-benchmark-v2/clock-repair-qualification.json')]='passed'
for p,status in receipts.items():assert json.loads(Path(p).read_text())['status']==status,p
j=dict(status='ready',prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),receipts=receipts,receipt_sha256={p:sha(Path(p)) for p in receipts},original_dispatch_sha256=sha(T/'module30-benchmark/timing-dispatch-gates.json'),repair_sha256=sha(T/'clock-resolution-reconciliation/repair.json'),qualification='All original codec matrices and focused gates remain passed. Rebuilt30/31 batch-clock source and all23+2 executables separately qualified. Original30 zero samples and failed campaign remain untouched; completed28/29 campaigns are not rerun. Fresh process barriers precede both replacement30 campaigns.');assert not (D/'timing-dispatch-gates.json').exists();(D/'timing-dispatch-gates.json').write_text(json.dumps(j,indent=2)+'\n');subprocess.run(['python3',str(D/'observe-and-measure.py')],check=True)
