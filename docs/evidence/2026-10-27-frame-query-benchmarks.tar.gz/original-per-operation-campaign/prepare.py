from pathlib import Path
import shutil
D=Path(__file__).parent;S=D/'source';C=Path('/private/tmp/module30-candidate');S.mkdir()
for n in ['src','tests','test-support','benches']:shutil.copytree(C/n,S/n)
for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(C/n,S/n)
shutil.copyfile(D/'frame_queries.rs',S/'benches/frame_queries.rs')
with (S/'Cargo.toml').open('a') as f:f.write('\n[[bench]]\nname="frame_queries"\nharness=false\n')
for n in ['build.py','after-build.py','repeat-build.py']:
 s=(Path('/private/tmp/module28-benchmark')/n).read_text().replace('module28-candidate','module30-candidate').replace('in_place_output','frame_queries').replace('len(rows)==22','len(rows)==11');(D/n).write_text(s)
