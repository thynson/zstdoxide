from pathlib import Path
import json,statistics,math,csv
D=Path(__file__).parent;records=[];index={};comparisons=[];builds=json.loads((D/'evidence.json').read_text())['builds']
for campaign,folder,names in [('primary',D,[r['name'] for r in builds]),('repeat',D/'repeat',['safe','all'])]:
 assert json.loads((folder/'timed.json').read_text())['status']=='passed'
 for name in names:
  groups={}
  for line in (folder/(name+'-timed.tsv')).read_text().splitlines():
   case,mode,sample,iterations,elapsed=line.split('\t');groups.setdefault((case,mode),[]).append(int(elapsed)/int(iterations))
  for (case,mode),samples in groups.items():
   assert len(samples)==5;row=dict(campaign=campaign,backend=name,case=case,mode=mode,median_ns=statistics.median(samples),minimum_ns=min(samples),maximum_ns=max(samples));records.append(row);index[campaign,name,case,mode]=row['median_ns']
with (D/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
cases=sorted({line.split('\t')[0] for line in (D/'safe-qualify.tsv').read_text().splitlines()});gm=lambda v:math.exp(sum(math.log(x) for x in v)/len(v))
for campaign in ['primary','repeat']:
 for backend in (['safe','all'] if campaign=='repeat' else [r['name'] for r in builds]):
  for mode in ['first-frame','total-size','total-bound','in-place-margin']:
   ratios={case:index[campaign,backend,case,mode]/index[campaign,'safe',case,mode] for case in cases};comparisons.append(dict(campaign=campaign,backend=backend,mode=mode,reference_backend='safe',ratios=ratios,nonempty_geomean=gm([v for k,v in ratios.items() if k!='empty'])))
(D/'summary.json').write_text(json.dumps(dict(samples_per_row=5,unit='nanoseconds per operation',aggregation='Equal-weight geometric mean of per-case median latency ratios over ten cases with nonempty encoded input, including the empty-output frame. Empty input remains separate. Query modes have different contracts and are not compared as interchangeable operations. Equal batch-loop/dispatch overhead retained, no confidence intervals or general speedup claim.',rows=records,comparisons=comparisons),indent=2)+'\n')
for a in comparisons:
 if a['backend']=='all':print(a['campaign'],a['mode'],round(a['nonempty_geomean'],4))
