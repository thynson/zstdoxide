# Fast benchmark harness review and clock-free smoke

The coordinator performed five bounded safe/all smoke campaigns. None enabled
clocks. Smoke1 stopped on an incorrect manually written small-source reference
parameter expectation; the pinned source correction changed that expectation,
not the corpus or codec. Smoke2 passed before saved frame files were added.
Smoke3/4 passed with saved complete frames. Smoke5 validates strict command
exit types and string environments as well as all prior integrity checks.

The independent reviewer inspected Rust timing/ownership, Python input and
parameter derivation, process provenance and offline validation. Initial
normal and optimized controls each passed31/32: JSON false was accepted as an
exit code0. The exact initial evidence, logs, control runner and reviewed
smoke4 harness source remain here. The final source rejects that mutation.
Final normal/-O controls each pass35/35: one authentic copied-evidence positive
and34 intentional rejected mutations. They invoke no child programs.

Original command evidence, all stdout/stderr bytes, and every saved complete
frame are retained. Equal logs/frames are stored once by SHA256; log-map.json
and frame-map.json recover original relative paths. Native executables and
codec sources are omitted, with their recorded hashes preserved. To reproduce
controls, materialize the corresponding smoke files through those maps and
invoke the archived runner against its matching harness snapshot; copied test
roots are created fresh outside the repository. Original absolute paths in
commands describe the original run, as required by the validator.

No performance result or complete14-configuration claim follows from this
checkpoint. Its purpose is readiness for the separately authorized, isolated
timed campaign after the final correctness matrix.
