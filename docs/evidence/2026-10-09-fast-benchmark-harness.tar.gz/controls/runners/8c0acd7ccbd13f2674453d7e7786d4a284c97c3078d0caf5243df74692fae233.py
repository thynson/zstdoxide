#!/usr/bin/env python3
"""Offline independent validator controls; never invokes Cargo/C/bench executables."""
import copy,hashlib,importlib.util,json,pathlib,shutil,sys
sys.dont_write_bytecode=True
ROOT=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize')
sys.path.insert(0,str(ROOT/'scripts'))
import benchmark_fast as m
original=pathlib.Path(sys.argv[1]).resolve()
out=pathlib.Path(sys.argv[2]).resolve()
if out.exists():raise SystemExit('fresh controls output required')
out.mkdir()
baseline=m.shared.load_json(original/'evidence.json')
records=[]

def command(e,label):return next(c for c in e['commands'] if c['label']==label)
def changed_log(p,e,label,rows):
 name=label+'.stdout';(p/name).write_text('\n'.join(json.dumps(r,sort_keys=True) for r in rows)+'\n')
 command(e,label)['stdout_sha256']=m.sha(p/name)
def modify_rows(p,e,fn,configs=None):
 for config in configs or e['configs']:
  label='run-'+config; rows=[m.shared.parse_json(x) for x in (p/(label+'.stdout')).read_text().splitlines()]
  fn(rows);changed_log(p,e,label,rows)
 # Keep summary current to isolate structural/semantic row validation.
 values={c:[m.shared.parse_json(x) for x in (p/('run-'+c+'.stdout')).read_text().splitlines()][1:] for c in e['configs']}
 e['summary']=m.summarize(values,e['timed'])
def test(name,mutate,accept=False):
 p=out/name;p.mkdir()
 for file in original.iterdir():
  if file.is_file():shutil.copyfile(file,p/file.name)
 shutil.copytree(original/'frames',p/'frames')
 e=copy.deepcopy(baseline)
 mutate(p,e)
 try:m.validate(p,e)
 except (ValueError,KeyError,TypeError,IndexError,FileNotFoundError,ZeroDivisionError) as ex:
  passed=not accept;result='rejected';detail=str(ex)
 else:passed=accept;result='accepted';detail=None
 records.append(dict(name=name,expected='accepted' if accept else 'rejected',actual=result,passed=passed,diagnostic=detail))
 # Evidence is the exact mutated input. Preserve all small files/frames for reproducibility.
 (p/'evidence.json').write_text(json.dumps(e,indent=2,allow_nan=False)+'\n')
 print(name,result,'PASS' if passed else 'FAIL',flush=True)

test('positive',lambda p,e:None,True)
test('cargo-configs-empty',lambda p,e:e.update(cargo_configs=[]))
test('cargo-config-hash',lambda p,e:e['cargo_configs'][0].update(sha256='0'*64))
test('source-hash',lambda p,e:e['source'].update({'src/fast_encode.rs':'0'*64}))
test('config-duplicate',lambda p,e:e['configs'].append('safe'))
test('config-order',lambda p,e:e['configs'].reverse())
test('command-order',lambda p,e:e['commands'].__setitem__(slice(5,7),e['commands'][5:7][::-1]))
test('command-exit',lambda p,e:command(e,'run-safe').update(exit_code=1))
test('command-exit-bool',lambda p,e:command(e,'run-safe').update(exit_code=False))
test('command-exception',lambda p,e:command(e,'run-safe').update(exception='TimeoutExpired'))

def bool_environment(p,e):
 e['base_environment']['USER']=False
 for c in e['commands']:c['environment']['USER']=False
test('coherent-environment-bool',bool_environment)

def typed_environment(name):
 def mutate(p,e):
  e['base_environment'][name]=False
  for c in e['commands']:c['environment'][name]=False
 return mutate
test('coherent-home-bool',typed_environment('HOME'))
test('coherent-path-bool',typed_environment('PATH'))
test('build-target-argv',lambda p,e:command(e,'build-safe')['argv'].__setitem__(-1,'i686-unknown-linux-gnu'))
test('run-timing-env',lambda p,e:command(e,'run-safe')['environment'].update(ZSTDOXIDE_FAST_BENCH_TIMED='1'))
test('run-frame-dir-env',lambda p,e:command(e,'run-safe')['environment'].update(ZSTDOXIDE_FAST_BENCH_FRAMES='/tmp/wrong'))
test('compiler-hash',lambda p,e:e.update(compiler_sha256='0'*64))
test('executable-hash',lambda p,e:e['executables']['safe'].update(sha256='0'*64))
test('log-hash',lambda p,e:command(e,'run-safe').update(stdout_sha256='0'*64))
test('missing-log',lambda p,e:(p/'run-safe.stdout').unlink())
test('source-size',lambda p,e:modify_rows(p,e,lambda r:r[1].update(source_bytes=32769)))
test('source-fnv',lambda p,e:modify_rows(p,e,lambda r:r[1].update(source_fnv1a64='0'*16)))
test('resolved-tuple',lambda p,e:modify_rows(p,e,lambda r:r[1]['resolved'].__setitem__(0,19)))
test('row-bool',lambda p,e:modify_rows(p,e,lambda r:r[1].update(source_bytes=True)))
test('allocation-attempts',lambda p,e:modify_rows(p,e,lambda r:r[1]['allocation'].update(attempts=1)))
test('allocation-leak',lambda p,e:modify_rows(p,e,lambda r:r[1]['allocation'].update(final_live_bytes=1)))
test('allocation-owner',lambda p,e:modify_rows(p,e,lambda r:r[1]['allocation'].update(owners_dropped=0)))
test('allocation-float',lambda p,e:modify_rows(p,e,lambda r:r[1]['allocation'].update(peak_bytes=602041.0)))
test('smoke-samples',lambda p,e:modify_rows(p,e,lambda r:r[1]['samples'].append({'iterations':1,'elapsed_ns':100000000})))
test('summary-ratio',lambda p,e:e['summary']['safe'][0].update(compressed_size_ratio=1))
frame='skewed-level-1.zst'
test('frame-missing',lambda p,e:(p/'frames/safe'/frame).unlink())
test('frame-extra',lambda p,e:(p/'frames/safe/extra.zst').write_bytes(b'x'))
test('frame-hash',lambda p,e:e['frames']['safe'][frame].update(sha256='0'*64))
test('frame-mutated',lambda p,e:(p/'frames/safe'/frame).write_bytes(b'x'))

def coherent_one_backend(p,e):
 fp=p/'frames/all'/frame;data=bytearray(fp.read_bytes());data[-1]^=1;fp.write_bytes(data)
 e['frames']['all'][frame]={'bytes':len(data),'sha256':m.sha(fp)}
 modify_rows(p,e,lambda r:r[1].update(frame_fnv1a64=m.shared.fnv(data)),['all'])
test('coherent-all-frame-only',coherent_one_backend)
summary=dict(scope='Offline copied-evidence tamper controls only; no subprocess, build, or timing',python_optimized=not __debug__,original=str(original),source_sha256={name:m.sha(ROOT/name) for name in ['scripts/benchmark_fast.py','examples/fast_benchmark.rs','scripts/benchmark_search.py']},runner_sha256=m.sha(__file__),checks=len(records),passed=sum(r['passed'] for r in records),records=records)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'checks':summary['checks'],'passed':summary['passed']}))
if summary['passed']!=summary['checks']:raise SystemExit(1)
