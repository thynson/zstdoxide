from pathlib import Path
import hashlib,json,os,re,subprocess
R=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize');O=Path('/tmp/zstdoxide-optimal-match-fixture-v2-checks');O.mkdir()
env=dict(os.environ,CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-match-fixture-target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',PYTHONDONTWRITEBYTECODE='1')
rows=[];commands=[('format',['cargo','fmt','--all','--','--check'])]
for label,flags in [('safe',[]),('all',['--all-features']),('release-all',['--release','--all-features'])]:
 commands.append(('tests-'+label,['cargo','test','--offline','--locked','--test','reference_optimal_match_fixture',*flags]))
for label,flags in [('safe',[]),('all',['--all-features'])]:
 commands.append(('clippy-'+label,['cargo','clippy','--offline','--locked','--test','reference_optimal_match_fixture',*flags,'--','-D','warnings']))
commands.append(('nostd',['cargo','check','--offline','--locked','--no-default-features']))
for label,argv in commands:
 log=O/(label+'.log')
 with log.open('xb') as f:r=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 data=log.read_bytes();row=dict(label=label,argv=argv,exit_code=r.returncode,log=log.name,sha256=hashlib.sha256(data).hexdigest());rows.append(row)
 (O/'evidence.json').write_text(json.dumps(rows,indent=2)+'\n')
 if r.returncode or label.startswith('tests-') and b'test result: ok. 5 passed; 0 failed;' not in data:raise RuntimeError(label)
 print('PASS',label,flush=True)
