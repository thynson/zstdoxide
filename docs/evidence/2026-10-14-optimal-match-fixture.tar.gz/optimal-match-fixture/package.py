from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize');O=Path('/tmp/zstdoxide-optimal-match-fixture-v2-checks')
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
rows=json.loads((O/'evidence.json').read_text())
if len(rows)!=7:raise ValueError('check inventory')
for row in rows:
 if row['exit_code']!=0 or sha((O/row['log']).read_bytes())!=row['sha256']:raise ValueError('checks')
files={n:(R/n).read_bytes() for n in ['scripts/pack_optimal_match_fixtures.py','tests/support/optimal_match_fixture.rs','tests/reference_optimal_match_fixture.rs','tests/fixtures/reference-optimal-matches/cases.bin','tests/fixtures/reference-optimal-matches/provenance.json']}
for phase,root in [('initial',Path('/tmp/zstdoxide-optimal-match-fixture-checks')),('final',O)]:
 for p in root.iterdir():
  if p.is_file():files['checks/'+phase+'/'+p.name]=p.read_bytes()
for mode in ['normal','optimized']:
 b=Path('/tmp/zstdoxide-optimal-match-project-'+mode+'.log').read_bytes();v=json.loads(b)
 if v['status']!='passed' or v['pack_bytes']!=7152786:raise ValueError('projection')
 files['checks/project-'+mode+'.json']=b
for name in ['zstdoxide-optimal-match-fixture-checks.py','zstdoxide-optimal-match-fixture-v2-checks.py']:
 files['runners/'+name]=(Path('/tmp')/name).read_bytes()
files['package.py']=Path(__file__).read_bytes()
report=dict(status='passed',cases=29,queries=273,pack_bytes=7152786,focused_tests=15,modes=['safe','all','release-all'],strict_clippy=['safe','all'],format=True,no_std=True,qualification='Independent bounded Rust fixture reader checks primary/short hash distinction, full state continuity, repeat intent, every match source span, skipped state and malformed fields. Initial Clippy rejected chunks_exact with a constant width; final as_chunks correction passes. No production sorted search or public Optimal admission.')
files['report.json']=enc(report);files['file-manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())})
a=R/'docs/evidence/2026-10-14-optimal-match-fixture.tar.gz'
if a.exists():raise ValueError('fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('optimal-match-fixture/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 if {m.name:t.extractfile(m).read() for m in t}!={'optimal-match-fixture/'+n:b for n,b in files.items()}:raise ValueError('archive verification')
report.update(archive=a.name,archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(files));(R/'docs/evidence/2026-10-14-optimal-match-fixture.json').write_bytes(enc(report))
p=R/'TODO.md';p.write_text(p.read_text().replace('- [ ] Project audited tiny match observations','- [x] Project audited tiny match observations'))
p=R/'docs/reference-optimal-validation.md';s=p.read_text();s+='''\n## Bounded Rust match fixture reader\n\nThe audited C maps project into a 7,152,786-byte pack retaining every before/after\nowner, both frontiers and ordered candidate. Normal and optimized Python exactly\nreconstruct all 29 cases / 273 queries from the immutable capture archive.\nThe independent Rust reader passes five tests in safe/all/release-all (15 total),\nstrict safe/all Clippy, formatting and no_std compilation. It validates complete\nstate continuity, source/window bounds, repeat intent and every match byte.\nCaptured regression checks separate primary hash4 from short hash3 and preserve\nskipped query state and clamped hash widths. Malformed extents, counts, geometry,\nqueries, cells, frontiers and candidate capacities are rejected.\n\n`evidence/2026-10-14-optimal-match-fixture.json` retains source, pack, exact logs\nand the initial corrected Clippy diagnostic. These additive fixture tests are\noutside the Module 16 immutable matrix; no production search is enabled.\n''';p.write_text(s)
(R/'tests/fixtures/reference-optimal-matches/README.md').write_text('''# Captured tiny Optimal search maps\n\nReconstruct with `python3 scripts/pack_optimal_match_fixtures.py`. The projector\nverifies the immutable capture archive and independently replays every observation\nbefore emitting exact C values. The 29 cases contain 273 queries. Both C builds\nand both arena padding passes agree; one copy is stored after comparison.\n\nThe binary starts with ZOMFX01 followed by a zero byte and a u32 case count. Each\ncase has ten little-endian u32 words: name/source/query lengths followed by seven\ngeometry words (window, primary hash, chain, search, minimum, target, short hash).\nASCII name and source bytes follow. Each query has six request words, complete\nbefore and after snapshots (two frontiers, all primary/edge/short-key cells),\nthen candidate count and offBase/length pairs. Cell extents derive from checked\ngeometry. The independent Rust reader bounds allocations and replays source bytes.\n\nThe original model comparison failed because primary minMatch3 hashing uses\nhash4, not hash3. The archive preserves that failure; an additive v2 model passes\nall complete observations. See docs/reference-optimal-validation.md.\n''')
print(a.name,a.stat().st_size)
