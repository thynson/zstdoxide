from pathlib import Path
import hashlib,json,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-layout-checks');O.mkdir();env=__import__('os').environ.copy();env['CARGO_TARGET_DIR']='/tmp/zstdoxide-tree-reader-target'
commands=[['cargo','test','--offline','--locked','--lib','tree_layout'],['cargo','test','--offline','--locked','--all-features','--lib','tree_layout'],['cargo','test','--offline','--locked','--release','--all-features','--lib','tree_layout'],['cargo','clippy','--offline','--locked','--lib','--','-D','warnings'],['cargo','clippy','--offline','--locked','--all-features','--lib','--','-D','warnings'],['cargo','check','--offline','--locked','--no-default-features'],['cargo','check','--offline','--locked','--no-default-features','--features',','.join(__import__('tomllib').loads((R/'Cargo.toml').read_text())['features'].keys()-{'default','std'})],['cargo','fmt','--all','--','--check']]
source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['src/tree_layout.rs','src/lib.rs','docs/data-structures.md']};rows=[]
for i,cmd in enumerate(commands):
 p=O/(str(i)+'.log');start=time.monotonic()
 with p.open('wb') as f:r=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 rows.append(dict(argv=cmd,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));print(i,r.returncode,flush=True)
 if r.returncode:raise ValueError('focused check')
assert source=={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,tests=15,no_std_configurations=2),sort_keys=True,indent=2)+'\n')
