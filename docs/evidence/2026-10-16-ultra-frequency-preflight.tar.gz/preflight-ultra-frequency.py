from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
sys.dont_write_bytecode=True;sys.path.insert(0,str(Path.cwd()/'scripts'))
import ultra_frequency_capture_plan as p
from oracles import ultra_scalar as m
out=Path('/tmp/zstdoxide-ultra-frequency-preflight-1016');m.need(not out.exists(),'fresh preflight');out.mkdir()
up=Path('/private/tmp/zstdoxide-reference-lazy-1.5.7');dest=Path('/private/tmp/zstdoxide-ultra-frequency-2026-10-16');cc=Path(shutil.which('clang')).resolve();source=p.source_manifest();_,units=p.reference_sources(up);plan=p.plan(up,dest,cc,units);commands=[]
for row in plan:
 if row['label'].endswith(('-dependencies','-predefines')):commands.append((row['label'],row['argv']))
 if row['label'].endswith('-compile-25'):
  argv=row['argv'][:-2];argv[argv.index('-c')]='-fsyntax-only';commands.append((row['label']+'-syntax',argv))
records=[]
for label,argv in commands:
 begin=time.monotonic();result=subprocess.run(argv,capture_output=True,timeout=120);m.need(len(result.stdout)<2<<20 and len(result.stderr)<1<<20,'bounded preflight output')
 for name,data in [('stdout',result.stdout),('stderr',result.stderr)]: (out/(label+'.'+name)).write_bytes(data)
 records.append(dict(label=label,argv=argv,exit_code=result.returncode,seconds=time.monotonic()-begin,stdout_sha256=m.sha(result.stdout),stderr_sha256=m.sha(result.stderr)))
 m.need(result.returncode==0 and not result.stderr,'successful syntax/dependencies '+label)
m.need(source==p.source_manifest(),'unchanged source');(out/'evidence.json').write_text(json.dumps(dict(status='passed',source=source,source_unchanged=True,commands=records),indent=2)+'\n');print(len(records),'preflight commands passed')
