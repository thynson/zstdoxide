import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent
for name,row in json.loads((r/'file-map.json').read_bytes()).items():
 p=r/'bundle'/name
 if not p.resolve().is_relative_to((r/'bundle').resolve()):raise ValueError('path')
 b=b''.join((r/'chunks'/h).read_bytes()for h in row['chunks'])
 if len(b)!=row['bytes']or hashlib.sha256(b).hexdigest()!=row['sha256']:raise ValueError('content')
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
print('Reconstructed and verified all archived files; inspect captured source before execution.')
