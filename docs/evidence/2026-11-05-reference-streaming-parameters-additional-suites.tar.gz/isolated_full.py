from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time,re
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e={'status':'waiting-for-release','commands':[],'scope':'Remaining full isolated-feature suites, opportunistic within the original work window. Only recorded successful commands count. Never a complete gate unless all 22 pass.'}
deadline=datetime.datetime(2026,11,5,10,13,tzinfo=datetime.timezone.utc).timestamp()
def save(): (D/'isolated-full-evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 while True:
  prior=json.loads((D/'release-full-evidence.json').read_text())
  if prior['status']=='complete':break
  if prior['status']=='incomplete':raise RuntimeError('Full release remains incomplete')
  if time.time()>deadline-120:raise TimeoutError('Insufficient remaining time to start isolated full suites')
  time.sleep(10)
 matrix=json.loads((D/'evidence.json').read_text());e['source']=matrix['source'];e['status']='running'
 # The two reference search owners are most directly exercised by the new API.
 features=['unsafe-reference-chain','unsafe-reference-tree']+[f for f in matrix['features'] if f not in ['unsafe-reference-chain','unsafe-reference-tree']]
 e['features']=features;save()
 env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'4','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
 for feature in features:
  if deadline-time.time()<90:raise TimeoutError('Insufficient time for '+feature)
  label=feature+'-full';cmd=['cargo','test','--offline','--locked','--features',feature]
  e['active']=label;save();start=time.monotonic();log=D/(label+'.log')
  with log.open('w') as f:
   p=subprocess.Popen(cmd,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=deadline-time.time())
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise TimeoutError('Stopped at work-window deadline: '+label)
  row={'label':label,'argv':cmd,'exit_code':code,'seconds':time.monotonic()-start,'log_sha256':sha(log)}
  e['commands'].append(row);save();assert code==0
  results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text())
  assert (len(results),sum(int(r[0]) for r in results),sum(int(r[1]) for r in results),sum(int(r[2]) for r in results))==(130,1884,0,82)
  row.update(result_groups=130,passed=1884,ignored=82);save();print(label,flush=True)
 for n,h in e['source'].items():assert sha(S/n)==h
 e['status']='complete';e.pop('active',None);save()
except BaseException as ex:
 e['status']='incomplete';e['error']=repr(ex);save();raise
