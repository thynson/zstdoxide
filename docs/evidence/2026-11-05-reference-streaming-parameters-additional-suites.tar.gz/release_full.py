from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time,re
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e={'status':'waiting-for-timing','commands':[],'scope':'Supplementary full safe/all release suites for the frozen Module 41 source. Full isolated-feature suites remain pending.'}
deadline=datetime.datetime(2026,11,5,10,13,tzinfo=datetime.timezone.utc).timestamp()
def save(): (D/'release-full-evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 while True:
  b=json.loads(Path('/private/tmp/module41-benchmark/evidence.json').read_text())
  if b['status']=='complete':break
  if b['status']=='failed':raise RuntimeError('Timing failed; supplemental release not started')
  if time.time()>deadline-120:raise TimeoutError('Not enough work-window time to start full release')
  time.sleep(10)
 matrix=json.loads((D/'evidence.json').read_text());assert matrix['status']=='complete'
 e['source']=matrix['source'];e['status']='running';save()
 env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'4','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
 for label,flags in [('safe-full-release',[]),('all-full-release',['--all-features'])]:
  cmd=['cargo','test','--offline','--locked','--release',*flags];e['active']=label;save();start=time.monotonic()
  remaining=deadline-time.time()
  if remaining<60:raise TimeoutError('Not enough remaining time for '+label)
  log=D/(label+'.log')
  with log.open('w') as f:
   p=subprocess.Popen(cmd,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=remaining)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise TimeoutError('Stopped at work-window deadline: '+label)
  row={'label':label,'argv':cmd,'exit_code':code,'seconds':time.monotonic()-start,'log_sha256':sha(log)}
  e['commands'].append(row);save();assert code==0
  results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text())
  assert (len(results),sum(int(r[0]) for r in results),sum(int(r[1]) for r in results),sum(int(r[2]) for r in results))==(130,1884,0,82)
  row.update(result_groups=130,passed=1884,ignored=82);save();print(label,flush=True)
 for n,h in e['source'].items():assert sha(S/n)==h
 e['status']='complete';e.pop('active',None);e['environment']={k:v for k,v in env.items() if k.startswith('CARGO_')};save()
except BaseException as ex:
 e['status']='incomplete';e['error']=repr(ex);save();raise
