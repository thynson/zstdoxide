from pathlib import Path
import json,hashlib,tarfile
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipts={n:json.loads((D/(n+'-evidence.json')).read_text()) for n in ['release-full','isolated-full']}
assert all(e['status'] in ['complete','incomplete'] for e in receipts.values())
for e in receipts.values():
 for n,h in e.get('source',{}).items():assert sha(R/n)==h
 for row in e['commands']:
  assert sha(D/(row['label']+'.log'))==row['log_sha256']
  assert row['exit_code']==0 and row.get('passed')==1884
matrix=json.loads((D/'evidence.json').read_text());done=[r['label'].removesuffix('-full') for r in receipts['isolated-full']['commands']]
remaining=[f for f in matrix['features'] if f not in done]
e={'status':'complete' if not remaining and receipts['release-full']['status']=='complete' else 'incomplete','scope':'Additional full release/isolated-feature suites within the original three-hour work window. Only successful complete suites are credited.','source':matrix['source'],'release':receipts['release-full'],'isolated':receipts['isolated-full'],'remaining_full_isolated_features':remaining}
archive=R/'docs/evidence/2026-11-05-reference-streaming-parameters-additional-suites.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n in ['release_full.py','isolated_full.py','finalize_additional.py','release-full-evidence.json','isolated-full-evidence.json','release-full-driver.log','isolated-full-driver.log']:t.add(D/n,arcname=n)
 names={row['label']+'.log' for receipt in receipts.values() for row in receipt['commands']}
 for receipt in receipts.values():
  if receipt.get('active') and (D/(receipt['active']+'.log')).exists():names.add(receipt['active']+'.log')
 for n in sorted(names):t.add(D/n,arcname=n)
e['archive']={'path':str(archive.relative_to(R)),'sha256':sha(archive)}
(R/'docs/evidence/2026-11-05-reference-streaming-parameters-additional-suites.json').write_text(json.dumps(e,indent=2)+'\n')
p=R/'docs/reference-streaming-parameters-validation.md';s=p.read_text();a=s.index('## Remaining module gates')
lines=['## Additional full suites','']
release_labels=[r['label'] for r in receipts['release-full']['commands']]
lines+=['Completed full release suites: '+(', '.join('`'+n+'`' for n in release_labels) or 'none')+'.','Completed full isolated-feature suites: '+(', '.join('`'+n+'`' for n in done) or 'none')+'.','Every credited suite reports 130 groups, 1,884 passed, 82 ignored and zero','failures. The additional-suites receipt records any incomplete attempt and','the remaining feature list. Time-bound termination is not counted as a pass.','','## Remaining module gates','',f'{len(remaining)} full isolated-feature suites remain.']
if receipts['release-full']['status']!='complete':lines+=['The full safe/all release gate is also incomplete.']
lines+=['The module remains open until every required suite has passed on the same','source and the receipts are reconciled. Completed focused/platform/native/','timing checks do not substitute for an unrun full suite. No implementation','milestone or full upstream replacement is claimed.','']
p.write_text(s[:a]+'\n'.join(lines))
print(json.dumps({'release_completed':release_labels,'isolated_completed':done,'remaining':remaining},indent=2))
