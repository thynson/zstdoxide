from pathlib import Path
import hashlib,json,os,subprocess,time,tomllib
R=Path.cwd();O=Path('/tmp/zstdoxide-ultra-frequency-thumb-1016');(O/'probe/src').mkdir(parents=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source={str(p.relative_to(R)):sha(p)for p in list((R/'src').rglob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock']}
(O/'probe/Cargo.toml').write_text('[package]\nname="ultra-frequency-no-atomics"\nversion="0.0.0"\nedition="2024"\n[features]\nunsafe-optimal-frequencies=[]\n[lib]\npath="src/lib.rs"\n')
s='''#![no_std]
#![deny(unsafe_op_in_unsafe_fn)]
#![deny(clippy::undocumented_unsafe_blocks)]
extern crate alloc;
#[allow(dead_code)]
#[path="ROOT/src/constants.rs"] mod constants;
#[allow(dead_code)]
#[path="ROOT/src/optimal_price.rs"] mod optimal_price;
#[path="ROOT/src/optimal_frequencies.rs"] mod optimal_frequencies;
#[allow(unexpected_cfgs)]
#[path="ROOT/src/error.rs"] mod error;
pub use error::Error;
pub type Result<T> = core::result::Result<T,Error>;
pub fn ultra_frequency_probe(source: &[u8], literals: &[u8]) -> Result<([u32;4],[u32;3])> {
 let mut state=optimal_frequencies::OptimalFrequencies::new_with_policy_in(optimal_price::PricePolicy::Ultra,false,alloc::alloc::Global)?;
 state.begin_block(source)?;
 state.update(literals,1,3)?;
 state.refresh()?;
 let prices=state.prices(literals,0,1,3)?;
 let sums=state.snapshot()?.sums;
 state.reset()?;
 Ok((sums,prices))
}
'''.replace('ROOT',str(R));(O/'probe/src/lib.rs').write_text(s)
env={k:v for k,v in os.environ.items()if k in ['PATH','HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR']};env.update(RUSTUP_TOOLCHAIN='nightly-2026-10-08',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-ultra-frequency-thumb-target');features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'});records=[]
commands=[('library-safe',['cargo','check','--offline','--locked','--lib','--no-default-features','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc'],R),('library-all',['cargo','check','--offline','--locked','--lib','--no-default-features','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc','--features',','.join(features)],R),('codegen-safe',['cargo','build','--offline','--lib','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc'],O/'probe'),('codegen-unsafe',['cargo','build','--offline','--lib','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc','--features','unsafe-optimal-frequencies'],O/'probe')]
def save(status,error=None):(O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,source_unchanged=all(sha(R/p)==h for p,h in source.items()),commands=records,qualification='Safe/all no_std thumbv6m library checks plus concrete safe/frequency-unsafe private owner construction/update/query/reset/drop code generation. No firmware execution or Ultra frame admission.'),indent=2)+'\n')
try:
 for label,argv,cwd in commands:
  print('START',label,flush=True);start=time.monotonic();p=O/(label+'.log')
  with p.open('w')as f:r=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  records.append(dict(label=label,argv=argv,cwd=str(cwd),exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)));save('running')
  if r.returncode:raise ValueError(label)
  print('END',label,flush=True)
 if any(sha(R/p)!=h for p,h in source.items()):raise ValueError('source changed')
 save('passed')
except BaseException as error:save('failed',repr(error));raise
