#![no_std]
#![deny(unsafe_op_in_unsafe_fn)]
#![deny(clippy::undocumented_unsafe_blocks)]
extern crate alloc;
#[allow(dead_code)]
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/constants.rs"] mod constants;
#[allow(dead_code)]
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_price.rs"] mod optimal_price;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_frequencies.rs"] mod optimal_frequencies;
#[allow(unexpected_cfgs)]
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/error.rs"] mod error;
pub use error::Error;
pub type Result<T> = core::result::Result<T,Error>;
pub fn ultra_frequency_probe(source: &[u8], literals: &[u8]) -> Result<([u32;4],[u32;3])> {
 let mut state=optimal_frequencies::OptimalFrequencies::new_with_policy_in(optimal_price::PricePolicy::Ultra,false,alloc::alloc::Global)?;
 state.begin_block(source)?;
 state.update(literals,1,3)?;
 state.refresh()?;
 let prices=state.prices(literals,0,1,3)?;
 let sums=state.snapshot()?.sums;
 state.reset()?;
 Ok((sums,prices))
}
