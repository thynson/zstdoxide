from pathlib import Path
import shutil
D=Path(__file__).parent;R=Path('/private/tmp/module27-candidate');S=D/'source';assert not S.exists();S.mkdir()
for folder in ['src','tests','test-support','benches','examples','scripts']:
 if (R/folder).exists():shutil.copytree(R/folder,S/folder)
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(R/name,S/name)
p=S/'tests/upstream_trained_dictionary_fuzz.rs';s=p.read_text().replace('// upstream one-shot dictionary_decompress target. Prefix remains buffered.','// upstream one-shot dictionary_decompress target. The separate prefix branch\n    // receives its own prefix-once stable supplement below.')
start=s.index('    let mut stable_storage = vec![0xa5; capacity + 64];');end=s.index('    let buffered = decode_checked',start);block=s[start:end]
block=block.replace('SliceDecoder::with_dictionary','SliceDecoder::with_prefix').replace('assert_eq!(stable.is_ok(), direct.is_ok());','assert_eq!(stable.is_ok(), buffered.is_ok());').replace('assert_eq!(direct, Ok(written));','assert_eq!(buffered.as_ref().unwrap().len(), written);').replace('&storage[32..written + 32]','buffered.as_ref().unwrap().as_slice()')
helper='''/// Prefix-once fixed-fragment supplement; no upstream selector is added.
fn decode_prefix_checked(source: &[u8], dictionary: SharedDictionary, capacity: usize) -> bool {
    let buffered = decode_checked(source, dictionary.clone(), true, capacity);
'''+block+'''    stable.is_ok()
}

#[test]
fn fixed_prefix_supplement_preserves_skips_and_rejects_reused_prepared_prefixes() {
    let dictionary = Dictionary::from_bytes(include_bytes!("upstream/dictionaries/formatted.dict")).unwrap().into_shared();
    let frame = include_bytes!("upstream/dictionaries/formatted-id.zst");
    let expected = include_bytes!("upstream/dictionaries/formatted-id.expected");
    assert!(decode_prefix_checked(frame, dictionary.clone(), expected.len()));
    assert!(!decode_prefix_checked(frame, dictionary.clone(), expected.len() - 1));
    let skip = [0x50, 0x2a, 0x4d, 0x18, 1, 0, 0, 0, 42];
    let combined = [skip.as_slice(), frame].concat();
    assert!(decode_prefix_checked(&combined, dictionary.clone(), expected.len()));
    let repeated = [frame.as_slice(), frame.as_slice()].concat();
    assert!(!decode_prefix_checked(&repeated, dictionary, expected.len() * 2));
}

'''
pos=s.index('/// `dictionary_decompress.c::LLVMFuzzerTestOneInput`');s=s[:pos]+helper+s[pos:];s=s.replace('decode_checked(source, dictionary, true, capacity).is_ok()','decode_prefix_checked(source, dictionary, capacity)');p.write_text(s)
