from pathlib import Path
import hashlib,json,os,subprocess,time,tomllib
D=Path(__file__).parent;R=D/'source';C=Path('/private/tmp/module27-candidate')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')}
for n,h in source.items():assert sha(C/n)==h,n
source.update({n:sha(R/n) for n in ['tests/upstream_trained_dictionary_fuzz.rs','tests/upstream/fuzz_support.rs','Cargo.toml','Cargo.lock','rust-toolchain.toml']})
features=sorted(f for f in tomllib.loads((R/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'))
e=dict(status='running',source=source,qualification='Additive test-only adapter on exactly the frozen Module27 production source. The final full matrix will include this seven-byte persistent and prefix-once streaming supplement; these focused runs qualify independent dictionary/slice backends and their combination. External corpus runs are separate.',commands=[])
env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'focused.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 start=time.monotonic()
 with (D/('focused-'+label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
save()
try:
 for name,flags in [('safe',[]),('slice',['--features','unsafe-slice-history']),('dictionary',['--features','unsafe-dictionary']),('both',['--features','unsafe-slice-history,unsafe-dictionary']),('all',['--all-features'])]:
  run(name,['cargo','test','--offline','--locked','--test','upstream_trained_dictionary_fuzz',*flags])
 run('clippy',['cargo','clippy','--offline','--locked','--test','upstream_trained_dictionary_fuzz','--all-features','--','-D','warnings'])
 run('format',['cargo','fmt','--all','--','--check'])
 for n,h in source.items():assert sha(R/n)==h,n
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
