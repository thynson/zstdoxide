from pathlib import Path
import subprocess,os,hashlib,json,time
R=Path.cwd();O=Path('/tmp/zstdoxide-ultra-frequency-reader-1016');O.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[R/'tests/reference_ultra_frequency_fixture.rs',R/'tests/support/ultra_frequency_fixture.rs'];source={str(p.relative_to(R)):sha(p)for p in paths};records=[]
env=os.environ|dict(CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-ultra-frequencies-target')
for name,argv in [('safe',['cargo','test','--test','reference_ultra_frequency_fixture']),('release-all',['cargo','test','--release','--all-features','--test','reference_ultra_frequency_fixture']),('clippy',['cargo','clippy','--all-features','--test','reference_ultra_frequency_fixture','--','-D','warnings']),('fmt',['cargo','fmt','--all','--check'])]:
 p=O/(name+'.log');start=time.monotonic()
 with p.open('w')as f:r=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(label=name,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)))
 (O/'evidence.json').write_text(json.dumps(dict(status='failed'if r.returncode else 'running',source=source,commands=records),indent=2)+'\n')
 if r.returncode:raise ValueError(name)
if any(sha(R/p)!=h for p,h in source.items()):raise ValueError('changed source')
(O/'evidence.json').write_text(json.dumps(dict(status='passed',source_unchanged=True,source=source,commands=records),indent=2)+'\n')
