"""Summarize Module38 compiled versus per-frame-staging streaming samples."""
from pathlib import Path
import json, math, statistics, sys, hashlib

D = Path(sys.argv[1])
ledger = (D / 'safe-repeat-1' / 'ledger.tsv').read_text().splitlines()[1:]
meta = {row.split('\t')[0]: row.split('\t') for row in ledger}
cases = {}
for label in ['safe', 'all']:
    for repeat in [1, 2]:
        samples = (D / f'{label}-repeat-{repeat}' / 'samples.tsv').read_text().splitlines()[1:]
        for row in samples:
            case, role, round_, sample, ns = row.split('\t')
            assert round_ in {'0', '1'}
            key = (label, repeat)
            cases.setdefault(case, {}).setdefault(key, {}).setdefault(role, []).append(int(ns))

summary = dict(cases=[], per_configuration={}, samples=0,
               evidence_sha256=hashlib.sha256((D / 'safe-repeat-1' / 'samples.tsv').read_bytes()).hexdigest())
ratios = []
for case, configurations in sorted(cases.items()):
    rows = []
    for (label, repeat), roles in sorted(configurations.items()):
        staging = roles['staging']
        compiled = roles['compiled']
        assert len(staging) == 80 and len(compiled) == 80
        sg = statistics.geometric_mean(staging)
        cg = statistics.geometric_mean(compiled)
        rows.append(dict(configuration=f'{label}-{repeat}', staging_ns=sg, compiled_ns=cg,
                         ratio=sg / cg))
        summary['samples'] += len(staging) + len(compiled)
        if label == 'safe' and repeat == 1:
            ratios.append(sg / cg)
    fields = meta[case]
    assert fields[5] == 'true' and fields[6] == '1', (case, fields)
    summary['cases'].append(dict(case=case, level=int(fields[1]), input_bytes=int(fields[2]),
                                 compiled_bytes=int(fields[3]), staging_bytes=int(fields[4]),
                                 configurations=rows))
summary['per_configuration'] = {
    f'{label}-{repeat}': statistics.geometric_mean(
        [row['ratio'] for case in summary['cases'] for row in case['configurations']
         if row['configuration'] == f'{label}-{repeat}'])
    for label in ['safe', 'all'] for repeat in [1, 2]}
summary['safe_overall_ratio'] = statistics.geometric_mean(ratios)
(D / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({k: summary[k] for k in ['samples', 'safe_overall_ratio', 'per_configuration']}, indent=2))
