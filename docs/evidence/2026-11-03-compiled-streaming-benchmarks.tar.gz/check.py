"""Module38 streaming compiled-state versus per-frame table-staging timing.

Builds the release harness under safe and all features, runs two independent
repeats per configuration after the in-test CPU barrier, checks byte/guard
ledgers and sample counts, and writes a geometric-mean summary.
"""
from pathlib import Path
import os, subprocess, json, hashlib, time, datetime, re, signal, shutil

D = Path(__file__).parent
S = D / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not S.exists()
shutil.copytree('/Users/lanxingcan/Workspace/zstdoxize', S,
                ignore=shutil.ignore_patterns('.git', 'target', 'SESSION_HANDOFF.md'))
shutil.copyfile(D / 'compiled_stream_bench.rs', S / 'tests/compiled_stream_bench.rs')
deadline = datetime.datetime.now(datetime.timezone.utc).timestamp() + 3 * 3600
source = {str(p.relative_to(S)): sha(p) for folder in ['src', 'tests', 'test-support']
          for p in (S / folder).rglob('*') if p.is_file()}
source.update({n: sha(S / n) for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']})
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         deadline_utc=datetime.datetime.fromtimestamp(deadline, datetime.timezone.utc).isoformat(),
         source=source, production_source={n: h for n, h in source.items() if n.startswith('src/')},
         commands=[], qualification='Compiled and per-frame-staged streaming workloads share inputs, dictionaries and output buffers. Compiled construction and dictionary preparation are outside the compiled role clock and inside the staging role clock; both include per-block parser owners and stream workspace allocation. Each role runs two rounds of forty samples after an in-test CPU barrier, and each configuration is run twice. No universal benefit or native identity is claimed.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(D / 'target'), 'CARGO_BUILD_JOBS': '6', 'CARGO_INCREMENTAL': '0'}


def save():
    (D / 'evidence.json').write_text(json.dumps(e, indent=2) + '\n')


def run(label, args, extra=None, cwd=S):
    remaining = deadline - time.time() - 15
    if remaining < 15:
        raise TimeoutError('deadline before ' + label)
    e['active_command'] = dict(label=label, argv=args,
                               started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    start = time.monotonic()
    log = D / (label + '.log')
    with log.open('xb') as f:
        p = subprocess.Popen(args, cwd=cwd, env={**env, **(extra or {})}, stdout=f,
                             stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = p.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGTERM)
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                p.wait()
            raise TimeoutError('deadline during ' + label)
    row = dict(label=label, argv=args, environment=extra or {}, exit_code=code,
               seconds=time.monotonic() - start, log_sha256=sha(log))
    if code == 0 and label.endswith('-harness'):
        rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text())
        assert rows == [('1', '0', '0')], (label, rows)
        row.update(passed=1)
    e['commands'].append(row)
    e.pop('active_command', None)
    save()
    print(label, code, flush=True)
    assert code == 0, (label, log.read_text()[-3000:])


save()
try:
    for label, flags in [('safe', []), ('all', ['--all-features'])]:
        run(label + '-clippy', ['cargo', 'clippy', '--offline', '--locked', '--test',
                                'compiled_stream_bench', *flags, '--', '-D', 'warnings'])
        for repeat in [1, 2]:
            out = D / (label + '-repeat-' + str(repeat))
            out.mkdir()
            run(label + '-harness-' + str(repeat),
                ['cargo', 'test', '--offline', '--locked', '--release', '--test',
                 'compiled_stream_bench', 'compiled_and_per_frame_staging_streaming_workloads',
                 '--', '--ignored', '--exact', '--nocapture'],
                dict(ZSTDOXIDE_COMPILED_STREAM_BENCH=str(out)))
    run('format', ['cargo', 'fmt', '--all', '--', '--check'])
    ledgers = {}
    for label in ['safe', 'all']:
        for repeat in [1, 2]:
            ledgers[f'{label}-{repeat}'] = sha(D / f'{label}-repeat-{repeat}' / 'ledger.tsv')
    assert len(set(ledgers.values())) == 1, ledgers
    e['ledgers'] = ledgers
    save()
    summary = subprocess.run(['python3', str(D / 'summarize.py'), str(D)], cwd=D,
                             capture_output=True, text=True, check=True)
    e['summary'] = json.loads((D / 'summary.json').read_text())
    e['summary_stdout'] = summary.stdout
    e['status'] = 'complete'
    e['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print('complete', flush=True)
except BaseException as error:
    e['status'] = 'failed'
    e['error'] = repr(error)
    save()
    raise
