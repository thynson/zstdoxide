//! Streaming compiled-state versus per-frame table-staging timing.

use std::alloc::Global;
use std::hint::black_box;
use std::time::{Duration, Instant};
use zstdoxide::{
    CompiledDictionary, CompiledStreamEncoder, CompiledStreamOptions, CompressionParameterRequest,
    DecodeOptions, Dictionary, EndDirective, Progress, SharedDictionary, StreamStatus,
    decompress_with_dictionary_in,
};

const FORMATTED: &[u8] = include_bytes!("upstream/dictionaries/formatted.dict");
const TEXT: &[u8] = include_bytes!("upstream/dictionaries/dictionary-treeless-literals.expected");

fn noise(mut state: u32, length: usize) -> Vec<u8> {
    (0..length)
        .map(|_| {
            state ^= state.wrapping_shl(13);
            state ^= state >> 17;
            state ^= state.wrapping_shl(5);
            state as u8
        })
        .collect()
}

struct Case {
    label: &'static str,
    level: i32,
    dictionary: SharedDictionary,
    input: Vec<u8>,
}

fn cases() -> Vec<Case> {
    let content = noise(0x51ce_5eed, 4096);
    let raw = Dictionary::raw(&content).unwrap().into_shared();
    let formatted = Dictionary::from_bytes(FORMATTED).unwrap().into_shared();
    let mut cases = Vec::new();
    let inputs = [
        content[..2048].to_vec(),
        [
            &content[..1024],
            &noise(0x1234_5678, 1024),
            &content[1024..2048],
        ]
        .concat(),
        noise(0x9abc_def0, 4096),
        content.repeat(20),
    ];
    for level in [1, 3, 4, 9] {
        for (index, input) in inputs.iter().enumerate() {
            cases.push(Case {
                label: match (level, index) {
                    (1, 0) => "fast-prefix",
                    (1, 1) => "fast-interleaved",
                    (1, 2) => "fast-noise",
                    (1, 3) => "fast-multiblock",
                    (3, 0) => "double-fast-prefix",
                    (3, 1) => "double-fast-interleaved",
                    (3, 2) => "double-fast-noise",
                    (3, 3) => "double-fast-multiblock",
                    (4, 0) => "chain-prefix",
                    (4, 1) => "chain-interleaved",
                    (4, 2) => "chain-noise",
                    (4, 3) => "chain-multiblock",
                    (9, 0) => "tree-prefix",
                    (9, 1) => "tree-interleaved",
                    (9, 2) => "tree-noise",
                    (9, 3) => "tree-multiblock",
                    _ => unreachable!(),
                },
                level,
                dictionary: raw.clone(),
                input: input.clone(),
            });
        }
    }
    for (index, input) in [TEXT.to_vec(), [TEXT, TEXT].concat()].iter().enumerate() {
        cases.push(Case {
            label: if index == 0 {
                "prepared-json"
            } else {
                "prepared-json-repeat"
            },
            level: 1,
            dictionary: formatted.clone(),
            input: input.clone(),
        });
    }
    cases
}

fn request(level: i32, input: &[u8]) -> CompressionParameterRequest {
    let mut request = CompressionParameterRequest::with_level(level);
    request
        .set_source_hint(u32::try_from(input.len()).unwrap())
        .unwrap();
    request
}

fn barrier() {
    let start = Instant::now();
    let mut value = 0_u64;
    while start.elapsed() < Duration::from_millis(500) {
        for _ in 0..10_000 {
            value = value.wrapping_mul(6364136223846793005).wrapping_add(1);
        }
        black_box(value);
    }
}

fn pump(
    encoder: &mut CompiledStreamEncoder<'_, Global>,
    input: &[u8],
    output: &mut [u8],
    chunk: usize,
    frame: &mut Vec<u8>,
) -> usize {
    let mut position = 0;
    loop {
        let end = (position + chunk).min(input.len());
        let directive = if end == input.len() {
            EndDirective::Finish
        } else {
            EndDirective::Continue
        };
        let mut consumed = 0;
        loop {
            let progress: Progress = encoder
                .process(&input[position + consumed..end], output, directive)
                .unwrap();
            frame.extend_from_slice(&output[..progress.produced]);
            consumed += progress.consumed;
            match progress.status {
                StreamStatus::NeedInput => break,
                StreamStatus::NeedOutput => continue,
                StreamStatus::FrameFinished => return frame.len(),
                StreamStatus::Flushed => unreachable!(),
            }
        }
        position = end;
    }
}

#[test]
#[ignore = "requires ZSTDOXIDE_COMPILED_STREAM_BENCH and release calibration"]
fn compiled_and_per_frame_staging_streaming_workloads() {
    let output_root = std::env::var_os("ZSTDOXIDE_COMPILED_STREAM_BENCH").unwrap();
    let root = std::path::PathBuf::from(output_root);
    std::fs::create_dir_all(&root).unwrap();
    let mut rows = String::from("case\trole\tround\tsample\tns\n");
    let mut ledger =
        String::from("case\tlevel\tinput\tcompiled_bytes\tstaging_bytes\tequal\tdecoded\n");
    for case in cases() {
        let request = request(case.level, &case.input);
        let options = CompiledStreamOptions {
            pledged_size: Some(case.input.len() as u64),
            ..CompiledStreamOptions::default()
        };
        let mut output = vec![0xa5_u8; case.input.len() + 128];
        let mut frame = Vec::with_capacity(case.input.len() + 128);
        let chunk = 4096;
        let compiled = CompiledDictionary::new(case.dictionary.view(), &request, Global).unwrap();
        let mut encoder =
            CompiledStreamEncoder::with_options_in(compiled, options, Global).unwrap();
        let compiled_len = pump(&mut encoder, &case.input, &mut output, chunk, &mut frame);
        assert_eq!(
            decompress_with_dictionary_in(
                &frame,
                &case.dictionary.view(),
                DecodeOptions::new(case.input.len()),
                Global,
            )
            .unwrap(),
            case.input,
            "{}",
            case.label
        );
        // Per-frame staging constructs the same compiled state inside the
        // timed region and then streams one frame with it.
        let probe = CompiledDictionary::new(case.dictionary.view(), &request, Global).unwrap();
        let mut probe_encoder =
            CompiledStreamEncoder::with_options_in(probe, options, Global).unwrap();
        let mut staged = Vec::with_capacity(case.input.len() + 128);
        let staging_len = pump(
            &mut probe_encoder,
            &case.input,
            &mut output,
            chunk,
            &mut staged,
        );
        let equal = staging_len == compiled_len && staged[..] == frame[..];
        ledger.push_str(&format!(
            "{}\t{}\t{}\t{}\t{}\t{}\t1\n",
            case.label,
            case.level,
            case.input.len(),
            compiled_len,
            staging_len,
            equal
        ));
        for round in 0..2 {
            barrier();
            for sample in 0..40 {
                let start = Instant::now();
                encoder.reset();
                frame.clear();
                let written = pump(&mut encoder, &case.input, &mut output, chunk, &mut frame);
                black_box(&frame[..written]);
                rows.push_str(&format!(
                    "{}\tcompiled\t{}\t{}\t{}\n",
                    case.label,
                    round,
                    sample,
                    start.elapsed().as_nanos()
                ));
            }
            barrier();
            for sample in 0..40 {
                let start = Instant::now();
                // Construction is the staged work this role repeats.
                let fresh =
                    CompiledDictionary::new(case.dictionary.view(), &request, Global).unwrap();
                let mut fresh_encoder =
                    CompiledStreamEncoder::with_options_in(fresh, options, Global).unwrap();
                staged.clear();
                let written = pump(
                    &mut fresh_encoder,
                    &case.input,
                    &mut output,
                    chunk,
                    &mut staged,
                );
                black_box(&staged[..written]);
                rows.push_str(&format!(
                    "{}\tstaging\t{}\t{}\t{}\n",
                    case.label,
                    round,
                    sample,
                    start.elapsed().as_nanos()
                ));
            }
        }
        drop(encoder);
    }
    std::fs::write(root.join("samples.tsv"), rows).unwrap();
    std::fs::write(root.join("ledger.tsv"), ledger).unwrap();
}
