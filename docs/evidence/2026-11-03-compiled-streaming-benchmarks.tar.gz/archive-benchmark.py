"""Archive the qualified Module38 streaming timing campaign."""
from pathlib import Path
import json, hashlib, tarfile, datetime

D = Path(__file__).parent
S = D / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
j = json.loads((D / 'evidence.json').read_text())
assert j['status'] == 'complete' and len(j['commands']) == 7
for n, h in j['source'].items():
    assert sha(S / n) == h, n
for r in j['commands']:
    assert r['exit_code'] == 0 and sha(D / (r['label'] + '.log')) == r['log_sha256']
files = {}
for p in D.rglob('*'):
    if not p.is_file():
        continue
    n = p.relative_to(D)
    if any(x in {'target', 'source'} for x in n.parts):
        continue
    if p.suffix in {'.rs', '.toml', '.lock', '.json', '.py', '.log', '.md', '.tsv'}:
        files[str(n)] = p
files['archive-benchmark.py'] = Path(__file__)
name = '2026-11-03-compiled-streaming-benchmarks'
archive = D / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
r = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         source=j['source'], production_source=j['production_source'], commands=j['commands'],
         ledgers=j['ledgers'], summary=j['summary'],
         members={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()},
         archive=archive.name, archive_sha256=sha(archive), qualification=j['qualification'])
(D / (name + '.json')).write_text(json.dumps(r, indent=2) + '\n')
print(name, archive.stat().st_size)
