from pathlib import Path
import shutil
D=Path(__file__).parent;S=D/'source';C=Path('/private/tmp/module29-candidate');S.mkdir()
for n in ['src','tests','test-support','benches']:shutil.copytree(C/n,S/n)
for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(C/n,S/n)
p=S/'tests/upstream_trained_dictionary_fuzz.rs';s=p.read_text();needle='    let buffered = decode_checked(source, dictionary, false, capacity);';assert s.count(needle)==1
addition='''    // Supplemental suffix-input layout: source length plus one maximum block
    // bounds structural overhead without trusting malformed framing metadata.
    // Prefix-once branches keep their separate established adapters.
    let in_place_capacity = capacity + source.len() + 128 * 1024;
    let start = in_place_capacity - source.len();
    let mut in_place = vec![0xa5; in_place_capacity + 64];
    in_place[32 + start..32 + in_place_capacity].copy_from_slice(source);
    let before = in_place.clone();
    let result = zstdoxide::decompress_in_place_with_dictionary(
        &mut in_place[32..32 + in_place_capacity],
        start,
        &dictionary,
        DecodeOptions::new(capacity),
    );
    assert_eq!(result.is_ok(), direct.is_ok());
    assert_eq!(&in_place[..32], &before[..32]);
    assert_eq!(&in_place[32 + capacity..], &before[32 + capacity..]);
    if let Ok(written) = result {
        assert_eq!(direct, Ok(written));
        assert_eq!(&in_place[32..32 + written], &storage[32..32 + written]);
        assert_eq!(&in_place[32 + written..], &before[32 + written..]);
    } else if let Err(error) = result {
        assert_ne!(error, Error::AllocationFailed);
        assert_ne!(error, Error::InvalidState);
    }
'''
p.write_text(s.replace(needle,addition+needle))
s=Path('/private/tmp/module27-fuzz/check-focused.py').read_text().replace('module27-candidate','module29-candidate').replace('Module27','Module29').replace("('both',['--features','unsafe-slice-history,unsafe-dictionary'])","('move',['--features','unsafe-in-place-buffer'])").replace('this seven-byte persistent and prefix-once streaming supplement','this suffix-input dictionary supplement').replace('independent dictionary/slice backends and their combination','independent dictionary/slice/movement backends');(D/'check-focused.py').write_text(s)
s=Path('/private/tmp/module27-fuzz/run-corpus.py').read_text().replace('stable=12063,','in_place=sum(row[1]!=\'prefix\' for row in rows),stable=12063,').replace('and buffered output with actual guards.','and buffered output with actual guards, plus suffix-input in-place dictionary decoding with separately guarded unread storage.').replace('This is not an assertion','The existing prefix branches remain outside the in-place dictionary supplement. This is not an assertion');(D/'run-corpus.py').write_text(s)
