from pathlib import Path
import hashlib,io,json,re,tarfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-double-fast-state-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
e=json.loads((OUT/'evidence.json').read_text());assert e['status']=='passed' and e['source_unchanged']
for n,h in e['source'].items():assert sha((ROOT/n).read_bytes())==h,n
for c in e['commands']:
 assert c['exit_code']==0;b=(OUT/c['log']).read_bytes();assert sha(b)==c['log_sha256']
 counts=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)
 if c['label'].startswith('state-'):assert counts==[(b'8',b'0',b'0')]
 if c['label'].startswith('baselines-'):assert counts==[(b'7',b'0',b'0'),(b'4',b'0',b'0')]
members={p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()};members['runner.py']=Path('/tmp/check-zstdoxide-double-fast-state.py').read_bytes();members['package.py']=Path(__file__).read_bytes()
for n in ['src/double_fast_state.rs','src/double_fast_plan.rs','src/lib.rs','tests/upstream/parameters/queries.tsv']:members['source/'+n]=(ROOT/n).read_bytes()
report={'date':'2026-10-12','status':'passed','commands':len(e['commands']),'persistent_state_test_executions':40,'ordinary_blocks_per_configuration':160,'fresh_candidates_per_configuration':148,'complete_table_comparisons_per_configuration':320,'raw_repeat_discard_witnesses':13,'rle_repeat_discard_witnesses':3,'baseline_test_executions':22,'ignored':0,'source':e['source'],'parameter_fixture_sha256':sha((ROOT/'tests/upstream/parameters/queries.tsv').read_bytes()),'scope':'Persistent DoubleFast matching against 51 frozen ordinary trajectories with committed incoming repeats and both complete sampled maps. Checked binding, tiny/empty scratch, expiry, exact allocator failure poisoning and allocation-free borrowed non-clone source reuse. No public frame encoding, new C capture, Miri or timing.','archive':'2026-10-12-double-fast-state.tar.gz'}
members['bootstrap.log']=Path('/tmp/zstdoxide-double-fast-state-bootstrap.log').read_bytes()
members['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();members['bundle-manifest.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},sort_keys=True,indent=2)+'\n').encode()
a=ROOT/'docs/evidence'/report['archive'];assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('double-fast-state/'+n);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 assert set(t.getnames())=={'double-fast-state/'+n for n in members}
 for n,b in members.items():assert t.extractfile('double-fast-state/'+n).read()==b
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(members));(ROOT/'docs/evidence/2026-10-12-double-fast-state.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(len(e['commands']),'commands;',len(members),'archive members')
