#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char **argv) {
    FILE *manifest;
    char path[4096];
    if (argc != 2 || ZSTD_versionNumber() != 10507) return 2;
    manifest = fopen(argv[1], "r");
    if (!manifest) return 3;
    while (fgets(path, sizeof(path), manifest)) {
        FILE *input;
        long length;
        unsigned char *bytes;
        size_t result;
        path[strcspn(path, "\r\n")] = 0;
        input = fopen(path, "rb");
        if (!input || fseek(input, 0, SEEK_END) != 0) return 4;
        length = ftell(input);
        if (length < 0 || fseek(input, 0, SEEK_SET) != 0) return 5;
        bytes = (unsigned char *)malloc(length ? (size_t)length : 1);
        if (!bytes || fread(bytes, 1, (size_t)length, input) != (size_t)length) return 6;
        fclose(input);
        result = ZSTD_decompressionMargin(bytes, (size_t)length);
        printf("%s\t%s\t%zu\n", path, ZSTD_isError(result) ? "error" : "ok", result);
        free(bytes);
    }
    if (ferror(manifest)) return 7;
    fclose(manifest);
    return 0;
}
