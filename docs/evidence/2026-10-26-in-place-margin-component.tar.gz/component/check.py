from pathlib import Path
import hashlib,json,os,subprocess,time,tomllib
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();features=sorted(x for x in tomllib.loads((R/'Cargo.toml').read_text())['features'] if x.startswith('unsafe-'));out=D/'builds';out.mkdir(exist_ok=True)
e=dict(status='running',design_commit='b579aea',source={p.name:sha(p) for p in D.glob('*.rs')},predecessor_modules={n:sha(R/'src'/n) for n in ['cursor.rs','frame.rs','error.rs']},features=features,commands=[],qualification='Standalone scanner component with exact existing cursor/frame/error source, not a whole-codec or public in-place decoder qualification.')
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 start=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
save()
try:
 for name,selected in [('safe',[]),('all',features),*[(f,[f]) for f in features]]:
  flags=[arg for f in selected for arg in ['--cfg',f'feature="{f}"']]
  run(name+'-build',['rustc','--edition=2024','--test',str(D/'lib.rs'),*flags,'-D','warnings','-o',str(out/name)])
  run(name+'-test',[str(out/name)])
  if name in ['safe','all','unsafe-byte-cursor']:
   folder=out/name;folder=out/(name+'-library');folder.mkdir(exist_ok=True)
   run(name+'-no-std',['rustc','--edition=2024','--crate-name','zstdoxide','--crate-type','rlib','--emit=link,metadata',str(D/'lib.rs'),*flags,'-D','warnings','--out-dir',str(folder)])
   run(name+'-clippy',['clippy-driver','--edition=2024','--test',str(D/'lib.rs'),*flags,'--emit=metadata','-o',str(folder/'test.rmeta'),'-D','warnings'])
   run(name+'-probe-build',['rustc','--edition=2024',str(D/'probe.rs'),'--extern','zstdoxide='+str(folder/'libzstdoxide.rlib'),'--extern','zstdoxide='+str(folder/'libzstdoxide.rmeta'),'-D','warnings','-o',str(out/(name+'-probe'))])
   run(name+'-probe',[str(out/(name+'-probe')),str(D/'manifest.txt')])
   if name in ['safe','all']:run(name+'-rustdoc',['rustdoc','--edition=2024','--test',str(D/'lib.rs'),'--extern','zstdoxide='+str(folder/'libzstdoxide.rlib'),'--extern','zstdoxide='+str(folder/'libzstdoxide.rmeta')])
 run('format',['rustfmt','--check','--edition','2024',str(D/'frame_layout.rs'),str(D/'lib.rs'),str(D/'probe.rs')])
 for n,h in e['source'].items():assert sha(D/n)==h,n
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
