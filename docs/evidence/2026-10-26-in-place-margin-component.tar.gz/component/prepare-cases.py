from pathlib import Path
import json,hashlib,struct
D=Path(__file__).parent;I=D/'inputs';I.mkdir(exist_ok=True);R=Path('/Users/lanxingcan/Workspace/zstdoxize');cases=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def add(name,data,expected=None,origin=None):
 p=I/(name+'.bin');assert not p.exists();p.write_bytes(data);cases.append(dict(name=name,path=str(p),bytes=len(data),sha256=sha(data),expected=expected,origin=origin));return data
def frame(descriptor,tail,blocks):
 b=b'\x28\xb5\x2f\xfd'+bytes([descriptor])+tail
 for i,(kind,size,payload) in enumerate(blocks):b+=struct.pack('<I',(size<<3)|(kind<<1)|int(i+1==len(blocks)))[:3]+payload
 if descriptor&4:b+=b'\xde\xad\xbe\xef'
 return b
small=[]
add('empty',b'',0)
for single in [False,True]:
 for sf in range(4):
  for df in range(4):
   tail=(b'' if single else b'\0')+bytes([0,1,2,4][df])+bytes([int(single),2,4,8][sf]);maximum=(256 if sf==1 else 0) if single else 1024
   name=f'header-{int(single)}-{sf}-{df}';data=add(name,frame((sf<<6)|(32 if single else 0)|df,tail,[(0,0,b'')]),5+len(tail)+3+maximum);small.append((name,data))
for checksum in [False,True]:
 for kind,payload in [(0,b'test'),(1,b'x'),(2,b'bad!')]:
  name=f'body-{kind}-{int(checksum)}';data=add(name,frame(32|(4 if checksum else 0),b'\4',[(kind,4,payload)]),13+(4 if checksum else 0));small.append((name,data))
for k in [0,1,2]:
 name=f'empty-block-{k}';data=add(name,frame(32,b'\0',[(k,0,b'x' if k==1 else b'')]),9);small.append((name,data))
add('oversized-raw-structure',frame(32,b'\0',[(0,2097151,bytes(2097151))]),9)
add('unknown-huge-window',frame(0,b'\xff',[(0,0,b'')]),131081)
add('two-blocks-unknown',frame(0,b'\0',[(0,1,b'a'),(1,4096,b'b')]),1036)
for magic in range(0x184d2a50,0x184d2a60):
 for size in [0,1,127]:
  name=f'skip-{magic:x}-{size}';data=add(name,struct.pack('<II',magic,size)+bytes([0xa5])*size,8+size);small.append((name,data))
  empty=frame(32,b'\0',[(0,0,b'')]);add(name+'-concat',data+empty+data,2*(8+size)+9)
for name,data in small:
 for end in range(1,len(data)):add(name+f'-truncated-{end}',data[:end])
 for pos in range(min(len(data),24)):
  for mask in [1,8,128,255]:
   changed=bytearray(data);changed[pos]^=mask;add(name+f'-mutation-{pos}-{mask}',changed)
for p in sorted((R/'tests/upstream/decodecorpus').glob('*.zst')):
 data=p.read_bytes();name='official-'+p.stem;origin={'path':str(p.relative_to(R)),'sha256':sha(data)};add(name,data,origin=origin)
 for end in sorted(set([*range(min(len(data),20)),*range(max(0,len(data)-8),len(data))])):add(name+f'-truncated-{end}',data[:end],origin=origin)
(D/'cases.json').write_text(json.dumps(dict(cases=cases,qualification='Synthetic framing boundaries/mutations and all96 existing official generated decodecorpus frames. Structural success is not a decoded-content claim; unknown native malformed outcomes are compared only after actual execution.'),indent=2)+'\n')
(D/'manifest.txt').write_text(''.join(c['path']+'\n' for c in cases));print(len(cases),'cases',sum(c['bytes'] for c in cases),'bytes')
