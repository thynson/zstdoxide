from pathlib import Path
import json,hashlib,subprocess,time
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();build=json.loads((D/'build.json').read_text());focused=json.loads((D/'evidence.json').read_text());assert build['status']==focused['status']=='passed';cases=json.loads((D/'cases.json').read_text())['cases'];expected={c['path']:c for c in cases};results={}
def parse(path):
 rows={}
 for line in path.read_text().splitlines():
  name,status,value=line.split('\t');assert name in expected and name not in rows;assert status in ['ok','error'];rows[name]=(status,int(value) if status=='ok' else None)
 assert rows.keys()==expected.keys();return rows
for name in ['normal','sanitized']:
 exe=D/('oracle-'+name);assert sha(exe)==build['executables'][name]
 with (D/(name+'-cases.tsv')).open('xb') as out, (D/(name+'-cases.stderr')).open('xb') as err:p=subprocess.run([str(exe),str(D/'manifest.txt')],stdout=out,stderr=err)
 assert p.returncode==0;results[name]=parse(D/(name+'-cases.tsv'))
assert results['normal']==results['sanitized']
for name in ['safe','all','unsafe-byte-cursor']:
 results[name]=parse(D/(name+'-probe.log'))
 assert results[name]==results['safe']
differences=[]
for name,c in expected.items():
 if results['safe'][name]!=results['normal'][name]:
  data=Path(name).read_bytes()
  assert data[:4]==bytes([0x28,0xb5,0x2f,0xfd]) and data[4]&32==0 and (data[5]>>3)+10>31
  assert results['normal'][name]==('error',None) and results['safe'][name][0]=='ok'
  differences.append(dict(name=c['name'],native=results['normal'][name],rust=results['safe'][name],reason='Native64-bit non-single window-log cap31; Rust existing structural header parser accepts the field.'))
assert len(differences)==17
for name,c in expected.items():
 assert sha(Path(name))==c['sha256']
 if c['expected'] is not None:assert results['safe'][name]==('ok',c['expected']),(name,results['safe'][name],c['expected'])
counts={k:sum(v[0]==k for v in results['normal'].values()) for k in ['ok','error']}
(D/'native-comparison.json').write_text(json.dumps(dict(status='passed',cases=len(cases),native_calls=len(cases)*2,rust_calls=len(cases)*3,native_outcomes_per_backend=counts,matching_cases=len(cases)-len(differences),documented_differences=differences,build_sha256=sha(D/'build.json'),focused_sha256=sha(D/'evidence.json'),cases_sha256=sha(D/'cases.json'),ledgers={name:sha(D/(name+'-cases.tsv' if name in ['normal','sanitized'] else name+'-probe.log')) for name in results},qualification='All exact common success margins agree across pinned v1.5.7 normal/sanitized native scanning and safe/cursor/all Rust component probes. Seventeen native window-cap rejections differ from the existing Rust structural header policy and are explicitly enumerated; no full parity claim. Error numeric codes and semantic decode validity are not equated. Includes all96 already-attributed generated decodecorpus frames; this is not an in-place decode or complete upstream-fuzzer assertion.'),indent=2)+'\n');print(len(cases),counts,'compared; 17 explicit native-window-cap differences')
