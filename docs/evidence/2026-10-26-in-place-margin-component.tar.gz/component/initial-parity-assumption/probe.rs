use std::{env, fs};
fn main() {
    let manifest = fs::read_to_string(env::args().nth(1).expect("manifest")).unwrap();
    for path in manifest.lines() {
        let bytes = fs::read(path).unwrap();
        match zstdoxide::decompression_margin(&bytes) {
            Ok(margin) => println!("{path}\tok\t{margin}"),
            Err(error) => println!("{path}\terror\t{error:?}"),
        }
    }
}
