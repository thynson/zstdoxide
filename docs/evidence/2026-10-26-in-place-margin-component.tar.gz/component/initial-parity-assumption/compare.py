from pathlib import Path
import json,hashlib,subprocess,time
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();build=json.loads((D/'build.json').read_text());focused=json.loads((D/'evidence.json').read_text());assert build['status']==focused['status']=='passed';cases=json.loads((D/'cases.json').read_text())['cases'];expected={c['path']:c for c in cases};results={}
def parse(path):
 rows={}
 for line in path.read_text().splitlines():
  name,status,value=line.split('\t');assert name in expected and name not in rows;assert status in ['ok','error'];rows[name]=(status,int(value) if status=='ok' else None)
 assert rows.keys()==expected.keys();return rows
for name in ['normal','sanitized']:
 exe=D/('oracle-'+name);assert sha(exe)==build['executables'][name]
 with (D/(name+'-cases.tsv')).open('xb') as out, (D/(name+'-cases.stderr')).open('xb') as err:p=subprocess.run([str(exe),str(D/'manifest.txt')],stdout=out,stderr=err)
 assert p.returncode==0;results[name]=parse(D/(name+'-cases.tsv'))
assert results['normal']==results['sanitized']
for name in ['safe','all','unsafe-byte-cursor']:
 results[name]=parse(D/(name+'-probe.log'))
 assert results[name]==results['normal'],[(p,results[name][p],results['normal'][p]) for p in expected if results[name][p]!=results['normal'][p]][:30]
for name,c in expected.items():
 assert sha(Path(name))==c['sha256']
 if c['expected'] is not None:assert results['normal'][name]==('ok',c['expected']),(name,results['normal'][name],c['expected'])
counts={k:sum(v[0]==k for v in results['normal'].values()) for k in ['ok','error']}
(D/'native-comparison.json').write_text(json.dumps(dict(status='passed',cases=len(cases),native_calls=len(cases)*2,rust_calls=len(cases)*3,outcomes_per_backend=counts,build_sha256=sha(D/'build.json'),focused_sha256=sha(D/'evidence.json'),cases_sha256=sha(D/'cases.json'),ledgers={name:sha(D/(name+'-cases.tsv' if name in ['normal','sanitized'] else name+'-probe.log')) for name in results},qualification='All exact success margins and success/error outcomes agree across pinned v1.5.7 normal/sanitized native scanning and safe/cursor/all Rust component probes. Error numeric codes and semantic decode validity are not equated. Includes all96 already-attributed generated decodecorpus frames; this is not an in-place decode or complete upstream-fuzzer assertion.'),indent=2)+'\n');print(len(cases),counts,'matched across all five runs')
