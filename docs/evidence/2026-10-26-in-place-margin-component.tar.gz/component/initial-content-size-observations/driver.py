from pathlib import Path
import json,struct,subprocess,hashlib
D=Path(__file__).parent;S=D/'content-size-extremes';S.mkdir(exist_ok=True);cases=[]
for size in [0,1,255,256,2**32-1,2**32,2**63-1,2**63,2**64-2,2**64-1]:
 for single in [False,True]:
  for checksum in [False,True]:
   data=b'\x28\xb5\x2f\xfd'+bytes([192|(32 if single else 0)|(4 if checksum else 0)])+(b'' if single else b'\0')+struct.pack('<Q',size)+b'\1\0\0'+(b'abcd' if checksum else b'')
   p=S/f'{size}-{int(single)}-{int(checksum)}.bin';assert not p.exists();p.write_bytes(data);cases.append(dict(path=str(p),size=size,single=single,checksum=checksum,sha256=hashlib.sha256(data).hexdigest()))
manifest=S/'manifest.txt';manifest.write_text(''.join(c['path']+'\n' for c in cases));results={}
for name,exe in [('normal',D/'oracle-normal'),('sanitized',D/'oracle-sanitized'),('safe',D/'builds/safe-probe'),('all',D/'builds/all-probe'),('cursor',D/'builds/unsafe-byte-cursor-probe')]:
 with (S/(name+'.tsv')).open('xb') as out, (S/(name+'.stderr')).open('xb') as err:p=subprocess.run([str(exe),str(manifest)],stdout=out,stderr=err)
 assert p.returncode==0;results[name]={}
 for line in (S/(name+'.tsv')).read_text().splitlines():
  path,status,value=line.split('\t');results[name][path]=(status,int(value) if status=='ok' else None)
 assert len(results[name])==len(cases)
assert results['normal']==results['sanitized'];assert results['safe']==results['all']==results['cursor']
differences=[dict(case=c,native=results['normal'][c['path']],rust=results['safe'][c['path']]) for c in cases if results['normal'][c['path']]!=results['safe'][c['path']]]
(S/'observations.json').write_text(json.dumps(dict(status='observed',cases=cases,results=results,differences=differences,qualification='Additional actual 64-bit content-size boundary observations; differing results require explicit interpretation before any parity claim.'),indent=2)+'\n');print('Observed',len(cases),'cases;',len(differences),'differences');print(json.dumps(differences,indent=2))
