from pathlib import Path
import json,hashlib,tarfile,shutil
D=Path(__file__).parent;P=Path('/private/tmp/module28-margin-platform');A=Path('/private/tmp/module28-archives');A.mkdir(exist_ok=True);R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((D/'evidence.json').read_text());native=json.loads((D/'native-comparison.json').read_text());extremes=json.loads((D/'content-size-extremes/observations.json').read_text());platform=json.loads((P/'evidence.json').read_text());assert e['status']==native['status']==platform['status']=='passed';assert extremes['status']=='passed-with-explicit-differences';assert len(e['commands'])==59 and len(platform['commands'])==8
for n,h in e['source'].items():assert sha(D/n)==h,n
for n in ['cursor.rs','frame.rs','error.rs']:assert sha(D/n)==sha(R/'src'/n)
for n,h in platform['source'].items():assert sha(P/'source'/n)==h,n
assert sha(P/'source/frame_layout.rs')==sha(D/'frame_layout.rs')
name='2026-10-26-in-place-margin-component';archive=A/(name+'.tar.gz');assert not archive.exists()
files=[p for p in D.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
# The component's tiny standalone binaries and synthetic/attributed inputs are
# retained. Only foreign compiler caches and sysroots are excluded below.
platform_files=[p for p in P.iterdir() if p.is_file()]+[p for folder in ['source','probe','artifacts'] for p in (P/folder).rglob('*') if p.is_file()]
members={}
with tarfile.open(archive,'w:gz') as tar:
 for prefix,items,root in [('component',files,D),('platform',platform_files,P)]:
  for p in sorted(items):
   n=prefix+'/'+str(p.relative_to(root));assert n not in members;members[n]={'bytes':p.stat().st_size,'sha256':sha(p)};tar.add(p,arcname=n)
 p=R/'tests/upstream/decodecorpus/README.md';tar.add(p,arcname='provenance/decodecorpus-README.md');members['provenance/decodecorpus-README.md']={'bytes':p.stat().st_size,'sha256':sha(p)}
result=dict(status='passed',component=e,native=native,content_size_extremes=extremes,platform=platform,members=members,archive=archive.name,archive_sha256=sha(archive),qualification='Standalone allocation-free framing/margin component, exact reused frame/cursor/error source, twelve unit tests across22 feature selections and59 focused commands. Native common success margins agree, with17 explicit native window-cap rejections and4 separate content-size sentinel differences; initial universal-parity assumption failure is preserved. Four foreign Miri runs and concrete ARM checks/code generation are component-only. No integrated public API, in-place decoding, whole-codec full matrix or performance milestone is claimed.')
(A/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size,'bytes')
