from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,tomllib
D=Path(__file__).parent;S=D/'source';S.mkdir();R=Path('/private/tmp/module28-margin');ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['lib.rs','cursor.rs','frame.rs','error.rs','frame_layout.rs']:shutil.copyfile(R/name,S/name)
features=sorted(n for n in tomllib.loads((ROOT/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
(S/'Cargo.toml').write_text('[package]\nname = "zstdoxide-margin-component"\nversion = "0.0.0"\nedition = "2024"\n[lib]\npath = "lib.rs"\n[features]\ndefault = []\n'+''.join(f'{n} = []\n' for n in features))
shutil.copyfile(ROOT/'rust-toolchain.toml',S/'rust-toolchain.toml')
subprocess.run(['cargo','generate-lockfile','--offline'],cwd=S,check=True)
source={p.name:sha(p) for p in S.iterdir() if p.is_file()};e=dict(status='running',source=source,component_sha256=sha(R/'evidence.json'),commands=[]);env={**os.environ,'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,cwd,extra):
 start=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=cwd,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=args,environment=extra,exit_code=p.returncode,seconds=time.monotonic()-start));save();print(label,p.returncode,flush=True);assert p.returncode==0
save()
try:
 for target,suffix in [('i686-unknown-linux-gnu','i686'),('s390x-unknown-linux-gnu','s390x')]:
  for name,flags in [('safe',[]),('all',['--all-features'])]:
   label=suffix+'-'+name;run(label,['cargo','miri','test','--offline','--locked','--target',target,'--lib',*flags],S,{'CARGO_TARGET_DIR':str(D/('miri-'+suffix)),'MIRI_SYSROOT':'/private/tmp/zstdoxide-ultra-miri-'+suffix,'MIRIFLAGS':'-Zmiri-strict-provenance'});assert '12 passed; 0 failed; 0 ignored' in (D/(label+'.log')).read_text()
 probe=D/'probe';shutil.copytree(S,probe)
 with (probe/'lib.rs').open('a') as f:f.write('\n#[inline(never)]\npub fn margin_codegen_probe(input: &[u8]) -> Result<usize> { decompression_margin(input) }\n')
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  common=['--offline','--locked','-Zbuild-std=core,alloc','--target','thumbv6m-none-eabi','--no-default-features','--lib',*flags]
  run('thumb-'+name+'-check',['cargo','check',*common],S,{'CARGO_TARGET_DIR':str(D/'thumb-check')})
  target=D/('thumb-'+name);run('thumb-'+name+'-objects',['cargo','rustc','--release',*common,'--','--emit=llvm-ir,obj'],probe,{'CARGO_TARGET_DIR':str(target)})
  ir=[p for p in target.rglob('*.ll') if any(line.startswith(b'define ') and b'margin_codegen_probe' in line for line in p.read_bytes().splitlines())];assert len(ir)==1;objects=list(ir[0].parent.glob('*.o'));assert objects;artifacts=[]
  for p in [ir[0],*objects]:
   if p.suffix=='.o':
    h=p.read_bytes()[:20];assert h[:6]==b'\x7fELF\x01\x01' and int.from_bytes(h[18:20],'little')==40
   q=D/'artifacts'/(name+'-'+p.name);q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q);artifacts.append(dict(path=str(q.relative_to(D)),sha256=sha(q)))
  e.setdefault('artifacts',{})[name]=artifacts;save()
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='Standalone margin component: four actual strict-provenance Miri runs of12tests on i686/s390x safe/all, two thumbv6m core+alloc checks and two concrete LLVM IR/ARM object builds. Interpretation and code generation, not native foreign hardware execution or an integrated in-place decoder.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
