#![no_std]
#![deny(unsafe_op_in_unsafe_fn)]
#![deny(clippy::undocumented_unsafe_blocks, clippy::missing_safety_doc)]
extern crate alloc;
#[allow(dead_code)]
mod cursor;
mod error;
#[allow(dead_code)]
mod frame;
mod frame_layout;
pub use error::{Error, Result};
pub use frame_layout::decompression_margin;

#[inline(never)]
pub fn margin_codegen_probe(input: &[u8]) -> Result<usize> { decompression_margin(input) }
