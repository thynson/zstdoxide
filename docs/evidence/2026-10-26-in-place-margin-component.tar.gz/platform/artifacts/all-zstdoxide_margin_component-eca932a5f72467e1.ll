; ModuleID = 'zstdoxide_margin_component.8ad981d606848348-cgu.0'
source_filename = "zstdoxide_margin_component.8ad981d606848348-cgu.0"
target datalayout = "e-m:e-p:32:32-Fi8-i64:64-v128:64:128-a:0:32-n32-S64"
target triple = "thumbv6m-unknown-none-eabi"

@alloc_49187a1a9102f6fabfbd4ff8645930a8 = private unnamed_addr constant [16 x i8] c"frame_layout.rs\00", align 1, !guid !0
@alloc_0b5be9b8ae129437adc2039ef774f149 = private unnamed_addr constant <{ ptr, [12 x i8] }> <{ ptr @alloc_49187a1a9102f6fabfbd4ff8645930a8, [12 x i8] c"\0F\00\00\00r\00\00\00\17\00\00\00" }>, align 4, !guid !1
@alloc_bdac395b1457309b01119d6ee7241f45 = private unnamed_addr constant [23 x i8] c"invalid codec parameter", align 1, !guid !2
@alloc_a831c82912810798379f6d40f5aa0bba = private unnamed_addr constant [27 x i8] c"invalid codec context state", align 1, !guid !3
@alloc_7b392dc8ea31c8e6782cf57e8779c179 = private unnamed_addr constant [23 x i8] c"unexpected end of input", align 1, !guid !4
@alloc_ac0217ade07e90bc94cc456679817822 = private unnamed_addr constant [19 x i8] c"invalid frame magic", align 1, !guid !5
@alloc_7ff98b587660cdced76113da7cb03293 = private unnamed_addr constant [22 x i8] c"corrupt Zstandard data", align 1, !guid !6
@alloc_d54e75b67645a5578e757e031fa62642 = private unnamed_addr constant [24 x i8] c"a dictionary is required", align 1, !guid !7
@alloc_235b61828294feeeb2172ca04092afbd = private unnamed_addr constant [28 x i8] c"invalid Zstandard dictionary", align 1, !guid !8
@alloc_43353d327e5fe4ba2f2a23fb232c29f0 = private unnamed_addr constant [22 x i8] c"dictionary ID mismatch", align 1, !guid !9
@alloc_358d882c88585a0b91bdd46f073d6817 = private unnamed_addr constant [40 x i8] c"insufficient dictionary training samples", align 1, !guid !10
@alloc_46538b36b8c48fbfe6a4f94227e7fbd0 = private unnamed_addr constant [29 x i8] c"unsupported Zstandard feature", align 1, !guid !11
@alloc_d1b0c6bc606a538edf406f6115094080 = private unnamed_addr constant [23 x i8] c"resource limit exceeded", align 1, !guid !12
@alloc_afc2a81fe13a0b3a87a4890cf54edc49 = private unnamed_addr constant [17 x i8] c"allocation failed", align 1, !guid !13
@alloc_959af6a03cd01ca999bfcd6a252429f4 = private unnamed_addr constant [27 x i8] c"frame content size mismatch", align 1, !guid !14
@alloc_d644fd8040ac32617306136b0f3eecf4 = private unnamed_addr constant [23 x i8] c"frame checksum mismatch", align 1, !guid !15
@switch.table._RNvXNtCsbV5MSIbEJ4G_26zstdoxide_margin_component5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt = private unnamed_addr constant [14 x i8] c"\17\1B\17\13\16\18\1C\16(\1D\17\11\1B\17", align 4, !guid !16
@switch.table._RNvXNtCsbV5MSIbEJ4G_26zstdoxide_margin_component5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt.3 = private unnamed_addr constant [14 x ptr] [ptr @alloc_bdac395b1457309b01119d6ee7241f45, ptr @alloc_a831c82912810798379f6d40f5aa0bba, ptr @alloc_7b392dc8ea31c8e6782cf57e8779c179, ptr @alloc_ac0217ade07e90bc94cc456679817822, ptr @alloc_7ff98b587660cdced76113da7cb03293, ptr @alloc_d54e75b67645a5578e757e031fa62642, ptr @alloc_235b61828294feeeb2172ca04092afbd, ptr @alloc_43353d327e5fe4ba2f2a23fb232c29f0, ptr @alloc_358d882c88585a0b91bdd46f073d6817, ptr @alloc_46538b36b8c48fbfe6a4f94227e7fbd0, ptr @alloc_d1b0c6bc606a538edf406f6115094080, ptr @alloc_afc2a81fe13a0b3a87a4890cf54edc49, ptr @alloc_959af6a03cd01ca999bfcd6a252429f4, ptr @alloc_d644fd8040ac32617306136b0f3eecf4], align 4, !guid !17

; zstdoxide_margin_component::margin_codegen_probe
; Function Attrs: noinline nounwind
define dso_local void @_RNvCsbV5MSIbEJ4G_26zstdoxide_margin_component20margin_codegen_probe(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([8 x i8]) align 4 captures(none) dereferenceable(8) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #0 !guid !20 {
start:
; call zstdoxide_margin_component::frame_layout::decompression_margin
  tail call void @_RNvNtCsbV5MSIbEJ4G_26zstdoxide_margin_component12frame_layout20decompression_margin(ptr noalias nofree noundef nonnull sret([8 x i8]) align 4 captures(none) dereferenceable(8) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef %input.1) #6
  ret void
}

; zstdoxide_margin_component::frame_layout::decompression_margin
; Function Attrs: nounwind
define dso_local void @_RNvNtCsbV5MSIbEJ4G_26zstdoxide_margin_component12frame_layout20decompression_margin(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([8 x i8]) align 4 captures(none) dereferenceable(8) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %0, i32 noundef range(i32 0, -2147483648) %1) unnamed_addr #1 !guid !21 {
start:
  %word.sroa.0.i46.i.i = alloca i64, align 8
  %_29.i.i = alloca [16 x i8], align 4
  %_364 = icmp eq i32 %1, 0
  br i1 %_364, label %bb11, label %bb3.lr.ph

bb3.lr.ph:                                        ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %_29.i.i, i32 4
  %3 = getelementptr inbounds nuw i8, ptr %_29.i.i, i32 8
  %4 = getelementptr inbounds nuw i8, ptr %_29.i.i, i32 12
  br label %bb3

bb3:                                              ; preds = %bb3.lr.ph, %bb18
  %input.sroa.0.068 = phi ptr [ %0, %bb3.lr.ph ], [ %_44, %bb18 ]
  %input.sroa.6.067 = phi i32 [ %1, %bb3.lr.ph ], [ %_40, %bb18 ]
  %maximum_block.sroa.0.066 = phi i32 [ 0, %bb3.lr.ph ], [ %_6.sroa.24.1, %bb18 ]
  %overhead.sroa.0.065 = phi i32 [ 0, %bb3.lr.ph ], [ %_31.0.i, %bb18 ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !22)
  %_21.i.i = icmp samesign ult i32 %input.sroa.6.067, 4
  br i1 %_21.i.i, label %bb12, label %bb29.i

bb29.i:                                           ; preds = %bb3
  %word.sroa.0.i.0.copyload.i = load i32, ptr %input.sroa.0.068, align 1, !alias.scope !25, !noalias !29
  %5 = and i32 %word.sroa.0.i.0.copyload.i, -16
  %6 = icmp eq i32 %5, 407710288
  br i1 %6, label %bb3.i, label %bb32.i.i

bb3.i:                                            ; preds = %bb29.i
  %_21.i52.i = icmp samesign ult i32 %input.sroa.6.067, 8
  br i1 %_21.i52.i, label %bb12, label %bb31.i

bb32.i.i:                                         ; preds = %bb29.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !34)
  %7 = icmp eq i32 %word.sroa.0.i.0.copyload.i, -47205080
  br i1 %7, label %bb4.i.i, label %bb12

bb4.i.i:                                          ; preds = %bb32.i.i
  %_9.i.i.i = icmp eq i32 %input.sroa.6.067, 4
  br i1 %_9.i.i.i, label %bb12, label %bb34.i.i

bb34.i.i:                                         ; preds = %bb4.i.i
  %_23.i.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.068, i32 4
  %_2.i.i.i = load i8, ptr %_23.i.i.i, align 1, !alias.scope !37, !noalias !38, !noundef !42
  %_13.i.i = and i8 %_2.i.i.i, 8
  %8 = icmp eq i8 %_13.i.i, 0
  br i1 %8, label %bb7.i.i, label %bb12

bb7.i.i:                                          ; preds = %bb34.i.i
  %_15.i.i = and i8 %_2.i.i.i, 32
  %single_segment.not.i.i = icmp eq i8 %_15.i.i, 0
  br i1 %single_segment.not.i.i, label %bb8.i60.i, label %bb10.i.i

bb8.i60.i:                                        ; preds = %bb7.i.i
  %_9.i26.i.i = icmp eq i32 %input.sroa.6.067, 5
  br i1 %_9.i26.i.i, label %bb12, label %bb36.i.i

bb10.i.i:                                         ; preds = %bb36.i.i, %bb7.i.i
  %cursor.sroa.15.0.i.i = phi i32 [ 6, %bb36.i.i ], [ 5, %bb7.i.i ]
  %window_size.sroa.0.0.i.i = phi i64 [ %11, %bb36.i.i ], [ 0, %bb7.i.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_29.i.i), !noalias !43
  store i32 0, ptr %_29.i.i, align 4, !noalias !43
  store i32 1, ptr %2, align 4, !noalias !43
  store i32 2, ptr %3, align 4, !noalias !43
  store i32 4, ptr %4, align 4, !noalias !43
  %_31.i.i = and i8 %_2.i.i.i, 3
  %_30.i.i = zext nneg i8 %_31.i.i to i32
  %9 = getelementptr inbounds nuw [4 x i8], ptr %_29.i.i, i32 %_30.i.i
  %dictionary_bytes.i.i = load i32, ptr %9, align 4, !noalias !43, !noundef !42
  call void @llvm.lifetime.end.p0(ptr nonnull %_29.i.i), !noalias !43
  %_3.i.i.i = icmp ugt i32 %dictionary_bytes.i.i, 8
  br i1 %_3.i.i.i, label %bb12, label %bb2.i.i.i

bb2.i.i.i:                                        ; preds = %bb10.i.i
  %_22.i37.i.i = sub nsw i32 %input.sroa.6.067, %cursor.sroa.15.0.i.i
  %_21.i38.i.i = icmp ugt i32 %dictionary_bytes.i.i, %_22.i37.i.i
  br i1 %_21.i38.i.i, label %bb12, label %bb38.i.i

bb36.i.i:                                         ; preds = %bb8.i60.i
  %_23.i30.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.068, i32 5
  %_2.i31.i.i = load i8, ptr %_23.i30.i.i, align 1, !alias.scope !37, !noalias !44, !noundef !42
  %_23.i.i = lshr i8 %_2.i31.i.i, 3
  %_22.i61.i = add nuw nsw i8 %_23.i.i, 10
  %10 = zext nneg i8 %_22.i61.i to i64
  %base.i.i = shl nuw nsw i64 1, %10
  %_2523.i.i = lshr i64 %base.i.i, 3
  %_27.i.i = and i8 %_2.i31.i.i, 7
  %_26.i.i = zext nneg i8 %_27.i.i to i64
  %_24.i62.i = mul nuw nsw i64 %_2523.i.i, %_26.i.i
  %11 = add nuw nsw i64 %_24.i62.i, %base.i.i
  br label %bb10.i.i

bb38.i.i:                                         ; preds = %bb2.i.i.i
  %_25.i40.i.i = add nuw nsw i32 %dictionary_bytes.i.i, %cursor.sroa.15.0.i.i
  %_40.i.i = lshr i8 %_2.i.i.i, 6
  switch i8 %_40.i.i, label %default.unreachable [
    i8 0, label %bb16.i.i
    i8 1, label %bb15.i.i
    i8 2, label %bb14.i.i
    i8 3, label %bb18.i.i
  ]

default.unreachable:                              ; preds = %bb38.i.i
  unreachable

bb16.i.i:                                         ; preds = %bb38.i.i
  br i1 %single_segment.not.i.i, label %bb37.i, label %bb18.i.i

bb15.i.i:                                         ; preds = %bb38.i.i
  br label %bb18.i.i

bb14.i.i:                                         ; preds = %bb38.i.i
  br label %bb18.i.i

bb18.i.i:                                         ; preds = %bb14.i.i, %bb15.i.i, %bb16.i.i, %bb38.i.i
  %12 = phi i1 [ false, %bb16.i.i ], [ true, %bb15.i.i ], [ false, %bb14.i.i ], [ false, %bb38.i.i ]
  %size_bytes.sroa.0.0.i.i = phi i32 [ 1, %bb16.i.i ], [ 2, %bb15.i.i ], [ 4, %bb14.i.i ], [ 8, %bb38.i.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %word.sroa.0.i46.i.i)
  store i64 0, ptr %word.sroa.0.i46.i.i, align 8, !noalias !47
  %_22.i51.i.i = sub nsw i32 %input.sroa.6.067, %_25.i40.i.i
  %_21.i52.i.i = icmp ugt i32 %size_bytes.sroa.0.0.i.i, %_22.i51.i.i
  br i1 %_21.i52.i.i, label %bb39.i.i, label %bb40.i.i

bb39.i.i:                                         ; preds = %bb18.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i46.i.i)
  br label %bb12

bb40.i.i:                                         ; preds = %bb18.i.i
  %_25.i54.i.i = add nuw nsw i32 %size_bytes.sroa.0.0.i.i, %_25.i40.i.i
  %_35.i56.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.068, i32 %_25.i40.i.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(1) %word.sroa.0.i46.i.i, ptr noundef nonnull readonly align 1 dereferenceable(1) %_35.i56.i.i, i32 range(i32 0, 9) %size_bytes.sroa.0.0.i.i, i1 false), !alias.scope !51, !noalias !55
  %word.sroa.0.i46.i.i.0.word.sroa.0.i46.i.i.0.word.sroa.0.i46.i.i.0.word.sroa.0.i46.i.0.word.sroa.0.i46.i.0.word.sroa.0.i46.0.word.sroa.0.i46.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i57.i.i = load i64, ptr %word.sroa.0.i46.i.i, align 8, !noalias !47
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i46.i.i)
  %13 = add i64 %word.sroa.0.i46.i.i.0.word.sroa.0.i46.i.i.0.word.sroa.0.i46.i.i.0.word.sroa.0.i46.i.0.word.sroa.0.i46.i.0.word.sroa.0.i46.0.word.sroa.0.i46.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i57.i.i, 256
  %_50.sroa.0.0.i.i = select i1 %12, i64 %13, i64 %word.sroa.0.i46.i.i.0.word.sroa.0.i46.i.i.0.word.sroa.0.i46.i.i.0.word.sroa.0.i46.i.0.word.sroa.0.i46.i.0.word.sroa.0.i46.0.word.sroa.0.i46.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i57.i.i
  %spec.select.i.i = select i1 %single_segment.not.i.i, i64 %window_size.sroa.0.0.i.i, i64 %_50.sroa.0.0.i.i
  br label %bb37.i

bb31.i:                                           ; preds = %bb3.i
  %_35.i56.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.068, i32 4
  %word.sroa.0.i48.0.copyload.i = load i32, ptr %_35.i56.i, align 1, !alias.scope !56, !noalias !60
  %_93.i = add nsw i32 %input.sroa.6.067, -8
  %_92.i = icmp ult i32 %_93.i, %word.sroa.0.i48.0.copyload.i
  br i1 %_92.i, label %bb12, label %bb35.i

bb35.i:                                           ; preds = %bb31.i
  %_96.i = add nuw nsw i32 %word.sroa.0.i48.0.copyload.i, 8
  br label %bb13

bb37.i:                                           ; preds = %bb40.i.i, %bb16.i.i
  %cursor.sroa.15.1.i.i = phi i32 [ %_25.i40.i.i, %bb16.i.i ], [ %_25.i54.i.i, %bb40.i.i ]
  %window_size.sroa.0.1.i.i = phi i64 [ %window_size.sroa.0.0.i.i, %bb16.i.i ], [ %spec.select.i.i, %bb40.i.i ]
  %14 = and i8 %_2.i.i.i, 4
  %_123.i = icmp samesign ugt i32 %cursor.sroa.15.1.i.i, %input.sroa.6.067
  br i1 %_123.i, label %bb12, label %bb7.i

bb7.i:                                            ; preds = %bb37.i, %bb48.i
  %cursor.sroa.16.0.i = phi i32 [ %_164.i, %bb48.i ], [ %cursor.sroa.15.1.i.i, %bb37.i ]
  %block_count.sroa.0.0.i = phi i32 [ %_179.0.i, %bb48.i ], [ 0, %bb37.i ]
  %_22.i66.i = sub i32 %input.sroa.6.067, %cursor.sroa.16.0.i
  %_21.i67.i = icmp ult i32 %_22.i66.i, 3
  br i1 %_21.i67.i, label %bb12, label %bb41.i

bb41.i:                                           ; preds = %bb7.i
  %_25.i69.i = add i32 %cursor.sroa.16.0.i, 3
  %_35.i71.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.068, i32 %cursor.sroa.16.0.i
  %word.sroa.0.i63.0.copyload.i = load i24, ptr %_35.i71.i, align 1, !alias.scope !64, !noalias !68
  %word.sroa.0.i63.0.insert.ext.i = zext i24 %word.sroa.0.i63.0.copyload.i to i64
  %_40.i = lshr i64 %word.sroa.0.i63.0.insert.ext.i, 1
  %trunc.i = trunc i64 %_40.i to i2
  switch i2 %trunc.i, label %bb41.unreachabledefault.i [
    i2 0, label %bb43.i
    i2 -2, label %bb43.i
    i2 1, label %bb12.i
    i2 -1, label %bb12
  ]

bb41.unreachabledefault.i:                        ; preds = %bb41.i
  unreachable

bb43.i:                                           ; preds = %bb41.i, %bb41.i
  %_44.i = lshr i64 %word.sroa.0.i63.0.insert.ext.i, 3
  %_152.i = trunc nuw nsw i64 %_44.i to i32
  br label %bb12.i

bb12.i:                                           ; preds = %bb43.i, %bb41.i
  %payload_size.sroa.0.0.i = phi i32 [ %_152.i, %bb43.i ], [ 1, %bb41.i ]
  %_161.i = sub i32 %input.sroa.6.067, %_25.i69.i
  %_160.i = icmp ugt i32 %payload_size.sroa.0.0.i, %_161.i
  br i1 %_160.i, label %bb12, label %bb45.i

bb45.i:                                           ; preds = %bb12.i
  %_179.1.i = icmp eq i32 %block_count.sroa.0.0.i, -1
  br i1 %_179.1.i, label %bb12, label %bb48.i, !prof !72

bb48.i:                                           ; preds = %bb45.i
  %_179.0.i = add nuw i32 %block_count.sroa.0.0.i, 1
  %_164.i = add i32 %payload_size.sroa.0.0.i, %_25.i69.i
  %_56.i = and i64 %word.sroa.0.i63.0.insert.ext.i, 1
  %15 = icmp eq i64 %_56.i, 0
  br i1 %15, label %bb7.i, label %bb13.i

bb13.i:                                           ; preds = %bb48.i
  %..i = zext nneg i8 %14 to i32
  %_193.i = sub i32 %input.sroa.6.067, %_164.i
  %_192.i = icmp ult i32 %_193.i, %..i
  br i1 %_192.i, label %bb12, label %bb53.i

bb53.i:                                           ; preds = %bb13.i
  %_214.0.i = add nuw nsw i32 %cursor.sroa.15.1.i.i, %..i
  %_196.i = add i32 %_164.i, %..i
  %_71.i = tail call i64 @llvm.umin.i64(i64 %window_size.sroa.0.1.i.i, i64 131072)
  %_70.i = trunc nuw nsw i64 %_71.i to i32
  %16 = tail call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %_179.0.i, i32 3)
  %17 = tail call i32 @llvm.umax.i32(i32 %maximum_block.sroa.0.066, i32 %_70.i)
  br label %bb13

bb2:                                              ; preds = %bb18
  %_20.0 = add i32 %_6.sroa.24.1, %_31.0.i
  %_20.1 = icmp ult i32 %_20.0, %_31.0.i
  br i1 %_20.1, label %bb9, label %bb11, !prof !73

bb12:                                             ; preds = %bb31.i, %bb3, %bb3.i, %bb37.i, %bb32.i.i, %bb2.i.i.i, %bb10.i.i, %bb8.i60.i, %bb34.i.i, %bb4.i.i, %bb13.i, %bb7.i, %bb41.i, %bb12.i, %bb45.i, %bb39.i.i
  %_6.sroa.5.1.ph = phi i8 [ 10, %bb45.i ], [ 2, %bb39.i.i ], [ 2, %bb7.i ], [ 4, %bb41.i ], [ 2, %bb12.i ], [ 2, %bb2.i.i.i ], [ 2, %bb37.i ], [ 2, %bb3 ], [ 2, %bb3.i ], [ 2, %bb31.i ], [ 2, %bb8.i60.i ], [ 2, %bb4.i.i ], [ 4, %bb34.i.i ], [ 3, %bb32.i.i ], [ 4, %bb10.i.i ], [ 2, %bb13.i ]
  %18 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 %_6.sroa.5.1.ph, ptr %18, align 1
  br label %bb8

bb13:                                             ; preds = %bb53.i, %bb35.i
  %_6.sroa.24.1 = phi i32 [ %17, %bb53.i ], [ %maximum_block.sroa.0.066, %bb35.i ]
  %_6.sroa.19.1.off0 = phi i32 [ %_214.0.i, %bb53.i ], [ %_96.i, %bb35.i ]
  %_6.sroa.19.1.off32 = phi { i32, i1 } [ %16, %bb53.i ], [ zeroinitializer, %bb35.i ]
  %_6.sroa.1617.1 = phi i32 [ %_196.i, %bb53.i ], [ %_96.i, %bb35.i ]
  %_14.0.i = extractvalue { i32, i1 } %_6.sroa.19.1.off32, 0
  %_14.1.i = extractvalue { i32, i1 } %_6.sroa.19.1.off32, 1
  br i1 %_14.1.i, label %bb14, label %bb4.i, !prof !72

bb4.i:                                            ; preds = %bb13
  %_23.0.i = add i32 %_6.sroa.19.1.off0, %overhead.sroa.0.065
  %_23.1.i = icmp ult i32 %_23.0.i, %overhead.sroa.0.065
  br i1 %_23.1.i, label %bb14, label %bb7.i15, !prof !72

bb7.i15:                                          ; preds = %bb4.i
  %_31.0.i = add i32 %_14.0.i, %_23.0.i
  %_31.1.i = icmp ult i32 %_31.0.i, %_23.0.i
  br i1 %_31.1.i, label %bb14, label %bb15, !prof !72

bb14:                                             ; preds = %bb4.i, %bb7.i15, %bb13
  %19 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %19, align 1
  br label %bb8

bb15:                                             ; preds = %bb7.i15
  %_37 = icmp ugt i32 %_6.sroa.1617.1, %input.sroa.6.067
  br i1 %_37, label %bb17, label %bb18, !prof !72

bb18:                                             ; preds = %bb15
  %_40 = sub nuw nsw i32 %input.sroa.6.067, %_6.sroa.1617.1
  %_44 = getelementptr inbounds nuw i8, ptr %input.sroa.0.068, i32 %_6.sroa.1617.1
  %_3 = icmp eq i32 %_40, 0
  br i1 %_3, label %bb2, label %bb3

bb17:                                             ; preds = %bb15
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_6.sroa.1617.1, i32 noundef %input.sroa.6.067, i32 noundef %input.sroa.6.067, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_0b5be9b8ae129437adc2039ef774f149) #7
  unreachable

bb8:                                              ; preds = %bb11, %bb9, %bb14, %bb12
  %.sink = phi i8 [ 1, %bb14 ], [ 1, %bb12 ], [ 0, %bb11 ], [ 1, %bb9 ]
  store i8 %.sink, ptr %_0, align 4
  ret void

bb11:                                             ; preds = %start, %bb2
  %_20.088 = phi i32 [ %_20.0, %bb2 ], [ 0, %start ]
  %20 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %_20.088, ptr %20, align 4
  br label %bb8

bb9:                                              ; preds = %bb2
  %21 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %21, align 1
  br label %bb8
}

; <zstdoxide_margin_component::error::Error as core::fmt::Display>::fmt
; Function Attrs: nounwind
define dso_local noundef zeroext i1 @_RNvXNtCsbV5MSIbEJ4G_26zstdoxide_margin_component5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt(ptr noalias nofree noundef readonly captures(none) dereferenceable(1) %self, ptr noalias nofree noundef align 4 dereferenceable(16) %f) unnamed_addr #1 !guid !74 {
start:
  %0 = load i8, ptr %self, align 1, !range !75, !noundef !42
  %1 = zext nneg i8 %0 to i32
  %switch.gep = getelementptr inbounds nuw i8, ptr @switch.table._RNvXNtCsbV5MSIbEJ4G_26zstdoxide_margin_component5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt, i32 %1
  %switch.load = load i8, ptr %switch.gep, align 1
  %switch.ext = zext i8 %switch.load to i32
  %2 = zext nneg i8 %0 to i32
  %switch.gep2 = getelementptr inbounds nuw [4 x i8], ptr @switch.table._RNvXNtCsbV5MSIbEJ4G_26zstdoxide_margin_component5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt.3, i32 %2
  %switch.load3 = load ptr, ptr %switch.gep2, align 4
; call <core::fmt::Formatter>::write_str
  %_0 = tail call noundef zeroext i1 @_RNvMsa_NtCsavDHSl9k1eG_4core3fmtNtB5_9Formatter9write_str(ptr noalias nofree noundef nonnull align 4 dereferenceable(16) %f, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %switch.load3, i32 noundef %switch.ext) #6
  ret i1 %_0
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i32, i1 immarg) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #3

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nounwind
declare dso_local void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef, i32 noundef, i32 noundef, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16)) unnamed_addr #4

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #3

; <core::fmt::Formatter>::write_str
; Function Attrs: nounwind
declare dso_local noundef zeroext i1 @_RNvMsa_NtCsavDHSl9k1eG_4core3fmtNtB5_9Formatter9write_str(ptr noalias nofree noundef align 4 dereferenceable(16), ptr noalias nofree noundef nonnull readonly captures(address, read_provenance), i32 noundef) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #5

attributes #0 = { noinline nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #1 = { nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { cold noinline noreturn nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.module.flags = !{!18}
!llvm.ident = !{!19}

!0 = !{i64 -367877596103968337}
!1 = !{i64 1934629478717624251}
!2 = !{i64 -6926249820316477275}
!3 = !{i64 4277751675174570715}
!4 = !{i64 -1601686038010824233}
!5 = !{i64 -2109049030431909198}
!6 = !{i64 12590237396327774}
!7 = !{i64 5329574824179489498}
!8 = !{i64 3469520257201457032}
!9 = !{i64 -2390423366743096873}
!10 = !{i64 -3930068196325940058}
!11 = !{i64 -7058183479700166654}
!12 = !{i64 890125349122936189}
!13 = !{i64 -864196405077595660}
!14 = !{i64 7879203017614835619}
!15 = !{i64 -2766032729999300687}
!16 = !{i64 4021150898967436556}
!17 = !{i64 1849390675095015055}
!18 = !{i32 7, !"frame-pointer", i32 2}
!19 = !{!"rustc version 1.101.0-nightly (1d81eb4ad 2026-10-07)"}
!20 = !{i64 -7878756126498535313}
!21 = !{i64 -441632154799206362}
!22 = !{!23}
!23 = distinct !{!23, !24, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component12frame_layoutNtB2_11FrameLayout4read: %input.0"}
!24 = distinct !{!24, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component12frame_layoutNtB2_11FrameLayout4read"}
!25 = !{!26, !28, !23}
!26 = distinct !{!26, !27, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component: %dest.0"}
!27 = distinct !{!27, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component"}
!28 = distinct !{!28, !27, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component: %src.0"}
!29 = !{!30, !32, !33}
!30 = distinct !{!30, !31, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %_0"}
!31 = distinct !{!31, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian"}
!32 = distinct !{!32, !31, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %self"}
!33 = distinct !{!33, !24, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component12frame_layoutNtB2_11FrameLayout4read: %_0"}
!34 = !{!35}
!35 = distinct !{!35, !36, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component5frameNtB2_11FrameHeader5parse: %input.0"}
!36 = distinct !{!36, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component5frameNtB2_11FrameHeader5parse"}
!37 = !{!35, !23}
!38 = !{!39, !41, !33}
!39 = distinct !{!39, !40, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4byte: %self"}
!40 = distinct !{!40, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4byte"}
!41 = distinct !{!41, !36, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component5frameNtB2_11FrameHeader5parse: %_0"}
!42 = !{}
!43 = !{!41, !35, !33, !23}
!44 = !{!45, !41, !33}
!45 = distinct !{!45, !46, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4byte: %self"}
!46 = distinct !{!46, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4byte"}
!47 = !{!48, !50, !41, !35, !33, !23}
!48 = distinct !{!48, !49, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %_0"}
!49 = distinct !{!49, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian"}
!50 = distinct !{!50, !49, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %self"}
!51 = !{!52, !54}
!52 = distinct !{!52, !53, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component: %dest.0"}
!53 = distinct !{!53, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component"}
!54 = distinct !{!54, !53, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component: %src.0"}
!55 = !{!48, !50, !41, !33}
!56 = !{!57, !59, !23}
!57 = distinct !{!57, !58, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component: %dest.0"}
!58 = distinct !{!58, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component"}
!59 = distinct !{!59, !58, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component: %src.0"}
!60 = !{!61, !63, !33}
!61 = distinct !{!61, !62, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %_0"}
!62 = distinct !{!62, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian"}
!63 = distinct !{!63, !62, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %self"}
!64 = !{!65, !67, !23}
!65 = distinct !{!65, !66, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component: %dest.0"}
!66 = distinct !{!66, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component"}
!67 = distinct !{!67, !66, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECsbV5MSIbEJ4G_26zstdoxide_margin_component: %src.0"}
!68 = !{!69, !71, !33}
!69 = distinct !{!69, !70, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %_0"}
!70 = distinct !{!70, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian"}
!71 = distinct !{!71, !70, !"_RNvMNtCsbV5MSIbEJ4G_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %self"}
!72 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!73 = !{!"branch_weights", !"expected", i32 17899863, i32 2129583785}
!74 = !{i64 -219094226091793781}
!75 = !{i8 0, i8 14}
