; ModuleID = 'zstdoxide_margin_component.25cd0740e66d0f3a-cgu.0'
source_filename = "zstdoxide_margin_component.25cd0740e66d0f3a-cgu.0"
target datalayout = "e-m:e-p:32:32-Fi8-i64:64-v128:64:128-a:0:32-n32-S64"
target triple = "thumbv6m-unknown-none-eabi"

@alloc_c21f614fcb860badb88d0f8b8ac2b1e9 = private unnamed_addr constant [10 x i8] c"cursor.rs\00", align 1, !guid !0
@alloc_f98695e4aa1fd53eef7097a70735602a = private unnamed_addr constant <{ ptr, [12 x i8] }> <{ ptr @alloc_c21f614fcb860badb88d0f8b8ac2b1e9, [12 x i8] c"\09\00\00\00\1D\00\00\00 \00\00\00" }>, align 4, !guid !1
@alloc_49187a1a9102f6fabfbd4ff8645930a8 = private unnamed_addr constant [16 x i8] c"frame_layout.rs\00", align 1, !guid !2
@alloc_0b5be9b8ae129437adc2039ef774f149 = private unnamed_addr constant <{ ptr, [12 x i8] }> <{ ptr @alloc_49187a1a9102f6fabfbd4ff8645930a8, [12 x i8] c"\0F\00\00\00r\00\00\00\17\00\00\00" }>, align 4, !guid !3
@alloc_bdac395b1457309b01119d6ee7241f45 = private unnamed_addr constant [23 x i8] c"invalid codec parameter", align 1, !guid !4
@alloc_a831c82912810798379f6d40f5aa0bba = private unnamed_addr constant [27 x i8] c"invalid codec context state", align 1, !guid !5
@alloc_7b392dc8ea31c8e6782cf57e8779c179 = private unnamed_addr constant [23 x i8] c"unexpected end of input", align 1, !guid !6
@alloc_ac0217ade07e90bc94cc456679817822 = private unnamed_addr constant [19 x i8] c"invalid frame magic", align 1, !guid !7
@alloc_7ff98b587660cdced76113da7cb03293 = private unnamed_addr constant [22 x i8] c"corrupt Zstandard data", align 1, !guid !8
@alloc_d54e75b67645a5578e757e031fa62642 = private unnamed_addr constant [24 x i8] c"a dictionary is required", align 1, !guid !9
@alloc_235b61828294feeeb2172ca04092afbd = private unnamed_addr constant [28 x i8] c"invalid Zstandard dictionary", align 1, !guid !10
@alloc_43353d327e5fe4ba2f2a23fb232c29f0 = private unnamed_addr constant [22 x i8] c"dictionary ID mismatch", align 1, !guid !11
@alloc_358d882c88585a0b91bdd46f073d6817 = private unnamed_addr constant [40 x i8] c"insufficient dictionary training samples", align 1, !guid !12
@alloc_46538b36b8c48fbfe6a4f94227e7fbd0 = private unnamed_addr constant [29 x i8] c"unsupported Zstandard feature", align 1, !guid !13
@alloc_d1b0c6bc606a538edf406f6115094080 = private unnamed_addr constant [23 x i8] c"resource limit exceeded", align 1, !guid !14
@alloc_afc2a81fe13a0b3a87a4890cf54edc49 = private unnamed_addr constant [17 x i8] c"allocation failed", align 1, !guid !15
@alloc_959af6a03cd01ca999bfcd6a252429f4 = private unnamed_addr constant [27 x i8] c"frame content size mismatch", align 1, !guid !16
@alloc_d644fd8040ac32617306136b0f3eecf4 = private unnamed_addr constant [23 x i8] c"frame checksum mismatch", align 1, !guid !17
@switch.table._RNvXNtCs3fddM0pOzd6_26zstdoxide_margin_component5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt = private unnamed_addr constant [14 x i8] c"\17\1B\17\13\16\18\1C\16(\1D\17\11\1B\17", align 4, !guid !18
@switch.table._RNvXNtCs3fddM0pOzd6_26zstdoxide_margin_component5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt.3 = private unnamed_addr constant [14 x ptr] [ptr @alloc_bdac395b1457309b01119d6ee7241f45, ptr @alloc_a831c82912810798379f6d40f5aa0bba, ptr @alloc_7b392dc8ea31c8e6782cf57e8779c179, ptr @alloc_ac0217ade07e90bc94cc456679817822, ptr @alloc_7ff98b587660cdced76113da7cb03293, ptr @alloc_d54e75b67645a5578e757e031fa62642, ptr @alloc_235b61828294feeeb2172ca04092afbd, ptr @alloc_43353d327e5fe4ba2f2a23fb232c29f0, ptr @alloc_358d882c88585a0b91bdd46f073d6817, ptr @alloc_46538b36b8c48fbfe6a4f94227e7fbd0, ptr @alloc_d1b0c6bc606a538edf406f6115094080, ptr @alloc_afc2a81fe13a0b3a87a4890cf54edc49, ptr @alloc_959af6a03cd01ca999bfcd6a252429f4, ptr @alloc_d644fd8040ac32617306136b0f3eecf4], align 4, !guid !19

; zstdoxide_margin_component::margin_codegen_probe
; Function Attrs: noinline nounwind
define dso_local void @_RNvCs3fddM0pOzd6_26zstdoxide_margin_component20margin_codegen_probe(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([8 x i8]) align 4 captures(none) dereferenceable(8) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #0 !guid !22 {
start:
; call zstdoxide_margin_component::frame_layout::decompression_margin
  tail call void @_RNvNtCs3fddM0pOzd6_26zstdoxide_margin_component12frame_layout20decompression_margin(ptr noalias nofree noundef nonnull sret([8 x i8]) align 4 captures(none) dereferenceable(8) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef %input.1) #6
  ret void
}

; <zstdoxide_margin_component::cursor::ByteCursor>::take
; Function Attrs: nounwind
define internal fastcc void @_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly align 4 captures(none) dereferenceable(8) %_0, ptr noalias nofree noundef nonnull align 4 captures(none) dereferenceable(12) %self, i32 noundef %count) unnamed_addr #1 !guid !23 {
start:
  %0 = getelementptr inbounds nuw i8, ptr %self, i32 4
  %_11.1 = load i32, ptr %0, align 4, !noundef !24
  %1 = getelementptr inbounds nuw i8, ptr %self, i32 8
  %_6 = load i32, ptr %1, align 4, !noundef !24
  %_4 = sub i32 %_11.1, %_6
  %_3 = icmp ugt i32 %count, %_4
  br i1 %_3, label %bb1, label %bb2

bb2:                                              ; preds = %start
  %end = add i32 %_6, %count
  %_19 = icmp ult i32 %end, %_6
  %_13.not = icmp ugt i32 %end, %_11.1
  %or.cond = or i1 %_19, %_13.not
  br i1 %or.cond, label %bb6, label %bb4, !prof !25

bb1:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i8 2, ptr %2, align 4
  store ptr null, ptr %_0, align 4
  br label %bb3

bb4:                                              ; preds = %bb2
  %_12.0 = load ptr, ptr %self, align 4, !nonnull !24, !noundef !24
  %_22 = getelementptr inbounds nuw i8, ptr %_12.0, i32 %_6
  store i32 %end, ptr %1, align 4
  store ptr %_22, ptr %_0, align 4
  %3 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %count, ptr %3, align 4
  br label %bb3

bb6:                                              ; preds = %bb2
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_6, i32 noundef %end, i32 noundef %_11.1, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_f98695e4aa1fd53eef7097a70735602a) #7
  unreachable

bb3:                                              ; preds = %bb1, %bb4
  ret void
}

; zstdoxide_margin_component::frame_layout::decompression_margin
; Function Attrs: nounwind
define dso_local void @_RNvNtCs3fddM0pOzd6_26zstdoxide_margin_component12frame_layout20decompression_margin(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([8 x i8]) align 4 captures(none) dereferenceable(8) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %0, i32 noundef range(i32 0, -2147483648) %1) unnamed_addr #1 !guid !26 {
start:
  %word.sroa.0.i62.i.i = alloca i64, align 8
  %_29.i.i = alloca [16 x i8], align 4
  %_62.i = alloca [8 x i8], align 4
  %cursor.i = alloca [12 x i8], align 4
  %_399 = icmp eq i32 %1, 0
  br i1 %_399, label %bb11, label %bb3.lr.ph

bb3.lr.ph:                                        ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %cursor.i, i32 4
  %3 = getelementptr inbounds nuw i8, ptr %cursor.i, i32 8
  %4 = getelementptr inbounds nuw i8, ptr %_29.i.i, i32 4
  %5 = getelementptr inbounds nuw i8, ptr %_29.i.i, i32 8
  %6 = getelementptr inbounds nuw i8, ptr %_29.i.i, i32 12
  br label %bb3

bb3:                                              ; preds = %bb3.lr.ph, %bb18
  %input.sroa.0.0103 = phi ptr [ %0, %bb3.lr.ph ], [ %_44, %bb18 ]
  %input.sroa.6.0102 = phi i32 [ %1, %bb3.lr.ph ], [ %_40, %bb18 ]
  %maximum_block.sroa.0.0101 = phi i32 [ 0, %bb3.lr.ph ], [ %_6.sroa.24.1, %bb18 ]
  %overhead.sroa.0.0100 = phi i32 [ 0, %bb3.lr.ph ], [ %_31.0.i, %bb18 ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !27)
  call void @llvm.lifetime.start.p0(ptr nonnull %cursor.i), !noalias !30
  %_3.i.i.i = icmp samesign ult i32 %input.sroa.6.0102, 4
  br i1 %_3.i.i.i, label %bb12, label %bb33.i

bb33.i:                                           ; preds = %bb3
  %word.sroa.0.i.0.copyload.i = load i32, ptr %input.sroa.0.0103, align 1, !alias.scope !32, !noalias !36
  %7 = and i32 %word.sroa.0.i.0.copyload.i, -16
  %8 = icmp eq i32 %7, 407710288
  br i1 %8, label %bb3.i, label %bb32.i.i

bb3.i:                                            ; preds = %bb33.i
  %9 = and i32 %input.sroa.6.0102, 2147483644
  %_3.i.i47.i = icmp eq i32 %9, 4
  br i1 %_3.i.i47.i, label %bb12, label %bb35.i

bb32.i.i:                                         ; preds = %bb33.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !40)
  %10 = icmp eq i32 %word.sroa.0.i.0.copyload.i, -47205080
  br i1 %10, label %bb4.i.i, label %bb12

bb4.i.i:                                          ; preds = %bb32.i.i
  %_3.i.i26.i.i = icmp eq i32 %input.sroa.6.0102, 4
  br i1 %_3.i.i26.i.i, label %bb12, label %bb2.i.i27.i.i

bb2.i.i27.i.i:                                    ; preds = %bb4.i.i
  %_22.i.i31.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.0103, i32 4
  %_2.i.i.i = load i8, ptr %_22.i.i31.i.i, align 1, !alias.scope !43, !noalias !44, !noundef !24
  %_13.i.i = and i8 %_2.i.i.i, 8
  %11 = icmp eq i8 %_13.i.i, 0
  br i1 %11, label %bb7.i.i, label %bb12

bb7.i.i:                                          ; preds = %bb2.i.i27.i.i
  %_15.i.i = and i8 %_2.i.i.i, 32
  %single_segment.not.i.i = icmp eq i8 %_15.i.i, 0
  br i1 %single_segment.not.i.i, label %bb8.i.i, label %bb10.i60.i

bb8.i.i:                                          ; preds = %bb7.i.i
  %_3.i.i34.i.i = icmp eq i32 %input.sroa.6.0102, 5
  br i1 %_3.i.i34.i.i, label %bb12, label %bb2.i.i35.i.i

bb2.i.i35.i.i:                                    ; preds = %bb8.i.i
  %_22.i.i41.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.0103, i32 5
  %_2.i42.i.i = load i8, ptr %_22.i.i41.i.i, align 1, !alias.scope !43, !noalias !48, !noundef !24
  %_23.i.i = lshr i8 %_2.i42.i.i, 3
  %_22.i.i = add nuw nsw i8 %_23.i.i, 10
  %12 = zext nneg i8 %_22.i.i to i64
  %base.i.i = shl nuw nsw i64 1, %12
  %_2523.i.i = lshr i64 %base.i.i, 3
  %_27.i.i = and i8 %_2.i42.i.i, 7
  %_26.i.i = zext nneg i8 %_27.i.i to i64
  %_24.i.i = mul nuw nsw i64 %_2523.i.i, %_26.i.i
  %13 = add nuw nsw i64 %_24.i.i, %base.i.i
  br label %bb10.i60.i

bb10.i60.i:                                       ; preds = %bb2.i.i35.i.i, %bb7.i.i
  %cursor.sroa.15.0.i.i = phi i32 [ 6, %bb2.i.i35.i.i ], [ 5, %bb7.i.i ]
  %window_size.sroa.0.0.i.i = phi i64 [ %13, %bb2.i.i35.i.i ], [ 0, %bb7.i.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_29.i.i), !noalias !51
  store i32 0, ptr %_29.i.i, align 4, !noalias !51
  store i32 1, ptr %4, align 4, !noalias !51
  store i32 2, ptr %5, align 4, !noalias !51
  store i32 4, ptr %6, align 4, !noalias !51
  %_31.i.i = and i8 %_2.i.i.i, 3
  %_30.i.i = zext nneg i8 %_31.i.i to i32
  %14 = getelementptr inbounds nuw [4 x i8], ptr %_29.i.i, i32 %_30.i.i
  %dictionary_bytes.i.i = load i32, ptr %14, align 4, !noalias !51, !noundef !24
  call void @llvm.lifetime.end.p0(ptr nonnull %_29.i.i), !noalias !51
  %_3.i.i61.i = icmp ugt i32 %dictionary_bytes.i.i, 8
  br i1 %_3.i.i61.i, label %bb12, label %bb2.i.i62.i

bb2.i.i62.i:                                      ; preds = %bb10.i60.i
  %_4.i.i48.i.i = sub nsw i32 %input.sroa.6.0102, %cursor.sroa.15.0.i.i
  %_3.i.i49.i.i = icmp ugt i32 %dictionary_bytes.i.i, %_4.i.i48.i.i
  br i1 %_3.i.i49.i.i, label %bb12, label %bb2.i.i50.i.i

bb2.i.i50.i.i:                                    ; preds = %bb2.i.i62.i
  %end.i.i51.i.i = add nuw nsw i32 %dictionary_bytes.i.i, %cursor.sroa.15.0.i.i
  %_13.not.i.i53.i.i = icmp samesign ugt i32 %end.i.i51.i.i, %input.sroa.6.0102
  br i1 %_13.not.i.i53.i.i, label %bb6.i.i59.i.i, label %bb38.i.i, !prof !25

bb6.i.i59.i.i:                                    ; preds = %bb2.i.i50.i.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %cursor.sroa.15.0.i.i, i32 noundef %end.i.i51.i.i, i32 noundef range(i32 1, -2147483648) %input.sroa.6.0102, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_f98695e4aa1fd53eef7097a70735602a) #7, !noalias !52
  unreachable

bb38.i.i:                                         ; preds = %bb2.i.i50.i.i
  %_40.i.i = lshr i8 %_2.i.i.i, 6
  switch i8 %_40.i.i, label %default.unreachable [
    i8 0, label %bb16.i.i
    i8 1, label %bb15.i.i
    i8 2, label %bb14.i.i
    i8 3, label %bb18.i.i
  ]

default.unreachable:                              ; preds = %bb38.i.i
  unreachable

bb16.i.i:                                         ; preds = %bb38.i.i
  br i1 %single_segment.not.i.i, label %bb41.i, label %bb18.i.i

bb15.i.i:                                         ; preds = %bb38.i.i
  br label %bb18.i.i

bb14.i.i:                                         ; preds = %bb38.i.i
  br label %bb18.i.i

bb18.i.i:                                         ; preds = %bb14.i.i, %bb15.i.i, %bb16.i.i, %bb38.i.i
  %15 = phi i1 [ false, %bb16.i.i ], [ true, %bb15.i.i ], [ false, %bb14.i.i ], [ false, %bb38.i.i ]
  %size_bytes.sroa.0.0.i.i = phi i32 [ 1, %bb16.i.i ], [ 2, %bb15.i.i ], [ 4, %bb14.i.i ], [ 8, %bb38.i.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %word.sroa.0.i62.i.i)
  store i64 0, ptr %word.sroa.0.i62.i.i, align 8, !noalias !59
  %_4.i.i67.i.i = sub nsw i32 %input.sroa.6.0102, %end.i.i51.i.i
  %_3.i.i68.i.i = icmp ugt i32 %size_bytes.sroa.0.0.i.i, %_4.i.i67.i.i
  br i1 %_3.i.i68.i.i, label %bb39.i.i, label %bb2.i.i69.i.i

bb2.i.i69.i.i:                                    ; preds = %bb18.i.i
  %end.i.i70.i.i = add nuw nsw i32 %size_bytes.sroa.0.0.i.i, %end.i.i51.i.i
  %_22.i.i76.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.0103, i32 %end.i.i51.i.i
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(1) %word.sroa.0.i62.i.i, ptr noundef nonnull readonly align 1 dereferenceable(1) %_22.i.i76.i.i, i32 range(i32 0, 9) %size_bytes.sroa.0.0.i.i, i1 false), !alias.scope !63, !noalias !67
  %word.sroa.0.i62.i.i.0.word.sroa.0.i62.i.i.0.word.sroa.0.i62.i.i.0.word.sroa.0.i62.i.0.word.sroa.0.i62.i.0.word.sroa.0.i62.0.word.sroa.0.i62.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i77.i.i = load i64, ptr %word.sroa.0.i62.i.i, align 8, !noalias !59
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i62.i.i)
  %16 = add i64 %word.sroa.0.i62.i.i.0.word.sroa.0.i62.i.i.0.word.sroa.0.i62.i.i.0.word.sroa.0.i62.i.0.word.sroa.0.i62.i.0.word.sroa.0.i62.0.word.sroa.0.i62.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i77.i.i, 256
  %_50.sroa.0.0.i.i = select i1 %15, i64 %16, i64 %word.sroa.0.i62.i.i.0.word.sroa.0.i62.i.i.0.word.sroa.0.i62.i.i.0.word.sroa.0.i62.i.0.word.sroa.0.i62.i.0.word.sroa.0.i62.0.word.sroa.0.i62.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i77.i.i
  %spec.select.i.i = select i1 %single_segment.not.i.i, i64 %window_size.sroa.0.0.i.i, i64 %_50.sroa.0.0.i.i
  br label %bb41.i

bb39.i.i:                                         ; preds = %bb18.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i62.i.i)
  br label %bb12

bb35.i:                                           ; preds = %bb3.i
  %_22.i.i55.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.0103, i32 4
  %word.sroa.0.i43.0.copyload.i = load i32, ptr %_22.i.i55.i, align 1, !alias.scope !68, !noalias !72
  %_4.i.i = add nsw i32 %input.sroa.6.0102, -8
  %_3.i.i = icmp ugt i32 %word.sroa.0.i43.0.copyload.i, %_4.i.i
  br i1 %_3.i.i, label %bb12, label %bb2.i.i

bb2.i.i:                                          ; preds = %bb35.i
  %end.i.i = add nuw nsw i32 %word.sroa.0.i43.0.copyload.i, 8
  %_13.not.i.i = icmp samesign ugt i32 %end.i.i, %input.sroa.6.0102
  br i1 %_13.not.i.i, label %bb6.i66.i, label %bb13, !prof !25

bb6.i66.i:                                        ; preds = %bb2.i.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef 8, i32 noundef %end.i.i, i32 noundef range(i32 1, -2147483648) %input.sroa.6.0102, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_f98695e4aa1fd53eef7097a70735602a) #7, !noalias !76
  unreachable

bb41.i:                                           ; preds = %bb2.i.i69.i.i, %bb16.i.i
  %cursor.sroa.15.1.i.i = phi i32 [ %end.i.i51.i.i, %bb16.i.i ], [ %end.i.i70.i.i, %bb2.i.i69.i.i ]
  %window_size.sroa.0.1.i.i = phi i64 [ %window_size.sroa.0.0.i.i, %bb16.i.i ], [ %spec.select.i.i, %bb2.i.i69.i.i ]
  %17 = and i8 %_2.i.i.i, 4
  store ptr %input.sroa.0.0103, ptr %cursor.i, align 4, !noalias !30
  store i32 %input.sroa.6.0102, ptr %2, align 4, !noalias !30
  %_3.i70.i = icmp samesign ugt i32 %cursor.sroa.15.1.i.i, %input.sroa.6.0102
  br i1 %_3.i70.i, label %bb12, label %bb9.i

bb9.i:                                            ; preds = %bb41.i, %bb52.i
  %_6.i102179.i = phi i32 [ %end.i106.i, %bb52.i ], [ %cursor.sroa.15.1.i.i, %bb41.i ]
  %block_count.sroa.0.0.i = phi i32 [ %_141.0.i, %bb52.i ], [ 0, %bb41.i ]
  %_4.i.i87.i = sub i32 %input.sroa.6.0102, %_6.i102179.i
  %_3.i.i88.i = icmp ult i32 %_4.i.i87.i, 3
  br i1 %_3.i.i88.i, label %bb12, label %bb2.i.i89.i

bb2.i.i89.i:                                      ; preds = %bb9.i
  %end.i.i90.i = add i32 %_6.i102179.i, 3
  %_19.i.i91.i = icmp ugt i32 %_6.i102179.i, -4
  %_13.not.i.i92.i = icmp ugt i32 %end.i.i90.i, %input.sroa.6.0102
  %or.cond.i.i93.i = or i1 %_19.i.i91.i, %_13.not.i.i92.i
  br i1 %or.cond.i.i93.i, label %bb6.i.i98.i, label %bb45.i, !prof !25

bb6.i.i98.i:                                      ; preds = %bb2.i.i89.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_6.i102179.i, i32 noundef %end.i.i90.i, i32 noundef range(i32 1, -2147483648) %input.sroa.6.0102, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_f98695e4aa1fd53eef7097a70735602a) #7, !noalias !80
  unreachable

bb45.i:                                           ; preds = %bb2.i.i89.i
  %_22.i.i96.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.0103, i32 %_6.i102179.i
  %word.sroa.0.i83.0.copyload.i = load i24, ptr %_22.i.i96.i, align 1, !alias.scope !87, !noalias !91
  %word.sroa.0.i83.0.insert.ext.i = zext i24 %word.sroa.0.i83.0.copyload.i to i64
  %_42.i = lshr i64 %word.sroa.0.i83.0.insert.ext.i, 1
  %trunc.i = trunc i64 %_42.i to i2
  switch i2 %trunc.i, label %bb45.unreachabledefault187.i [
    i2 0, label %bb47.i
    i2 -2, label %bb47.i
    i2 1, label %bb14.i
    i2 -1, label %bb12
  ]

bb45.unreachabledefault187.i:                     ; preds = %bb45.i
  unreachable

bb47.i:                                           ; preds = %bb45.i, %bb45.i
  %_46.i = lshr i64 %word.sroa.0.i83.0.insert.ext.i, 3
  %_128.i = trunc nuw nsw i64 %_46.i to i32
  br label %bb14.i

bb14.i:                                           ; preds = %bb47.i, %bb45.i
  %payload_size.sroa.0.0.i = phi i32 [ %_128.i, %bb47.i ], [ 1, %bb45.i ]
  %_4.i103.i = sub nsw i32 %input.sroa.6.0102, %end.i.i90.i
  %_3.i104.i = icmp ugt i32 %payload_size.sroa.0.0.i, %_4.i103.i
  br i1 %_3.i104.i, label %bb12, label %bb2.i105.i

bb2.i105.i:                                       ; preds = %bb14.i
  %end.i106.i = add nuw i32 %payload_size.sroa.0.0.i, %end.i.i90.i
  %_13.not.i108.i = icmp ugt i32 %end.i106.i, %input.sroa.6.0102
  br i1 %_13.not.i108.i, label %bb6.i114.i, label %bb49.i, !prof !25

bb6.i114.i:                                       ; preds = %bb2.i105.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %end.i.i90.i, i32 noundef %end.i106.i, i32 noundef range(i32 1, -2147483648) %input.sroa.6.0102, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_f98695e4aa1fd53eef7097a70735602a) #7, !noalias !92
  unreachable

bb49.i:                                           ; preds = %bb2.i105.i
  %_141.1.i = icmp eq i32 %block_count.sroa.0.0.i, -1
  br i1 %_141.1.i, label %bb12, label %bb52.i, !prof !96

bb52.i:                                           ; preds = %bb49.i
  %_141.0.i = add nuw i32 %block_count.sroa.0.0.i, 1
  %_59.i = and i64 %word.sroa.0.i83.0.insert.ext.i, 1
  %18 = icmp eq i64 %_59.i, 0
  br i1 %18, label %bb9.i, label %bb16.i

bb16.i:                                           ; preds = %bb52.i
  store i32 %end.i106.i, ptr %3, align 4, !noalias !30
  %..i = zext nneg i8 %17 to i32
  call void @llvm.lifetime.start.p0(ptr nonnull %_62.i), !noalias !30
; call <zstdoxide_margin_component::cursor::ByteCursor>::take
  call fastcc void @_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take(ptr noalias nofree noundef align 4 captures(none) dereferenceable(8) %_62.i, ptr noalias nofree noundef align 4 dereferenceable(12) %cursor.i, i32 noundef %..i) #6, !noalias !97
  %19 = load ptr, ptr %_62.i, align 4, !noalias !30, !noundef !24
  %20 = icmp eq ptr %19, null
  br i1 %20, label %bb53.i, label %bb57.i

bb53.i:                                           ; preds = %bb16.i
  %21 = getelementptr inbounds nuw i8, ptr %_62.i, i32 4
  %_156.i = load i8, ptr %21, align 4, !range !98, !noalias !30, !noundef !24
  call void @llvm.lifetime.end.p0(ptr nonnull %_62.i), !noalias !30
  br label %bb12

bb57.i:                                           ; preds = %bb16.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_62.i), !noalias !30
  %_162.0.i = add nuw nsw i32 %cursor.sroa.15.1.i.i, %..i
  %_68.i = load i32, ptr %3, align 4, !noalias !30, !noundef !24
  %_75.i = tail call i64 @llvm.umin.i64(i64 %window_size.sroa.0.1.i.i, i64 131072)
  %_74.i = trunc nuw nsw i64 %_75.i to i32
  %22 = tail call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %_141.0.i, i32 3)
  %23 = tail call i32 @llvm.umax.i32(i32 %maximum_block.sroa.0.0101, i32 %_74.i)
  br label %bb13

bb2:                                              ; preds = %bb18
  %_20.0 = add i32 %_6.sroa.24.1, %_31.0.i
  %_20.1 = icmp ult i32 %_20.0, %_31.0.i
  br i1 %_20.1, label %bb9, label %bb11, !prof !99

bb12:                                             ; preds = %bb32.i.i, %bb41.i, %bb3.i, %bb3, %bb35.i, %bb2.i.i62.i, %bb10.i60.i, %bb8.i.i, %bb2.i.i27.i.i, %bb4.i.i, %bb14.i, %bb45.i, %bb9.i, %bb49.i, %bb53.i, %bb39.i.i
  %_6.sroa.5.1.ph = phi i8 [ 10, %bb49.i ], [ %_156.i, %bb53.i ], [ 2, %bb39.i.i ], [ 2, %bb9.i ], [ 4, %bb45.i ], [ 2, %bb14.i ], [ 2, %bb2.i.i62.i ], [ 2, %bb41.i ], [ 2, %bb3 ], [ 2, %bb3.i ], [ 2, %bb8.i.i ], [ 2, %bb4.i.i ], [ 4, %bb2.i.i27.i.i ], [ 3, %bb32.i.i ], [ 4, %bb10.i60.i ], [ 2, %bb35.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %cursor.i), !noalias !30
  %24 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 %_6.sroa.5.1.ph, ptr %24, align 1
  br label %bb8

bb13:                                             ; preds = %bb2.i.i, %bb57.i
  %_6.sroa.24.1 = phi i32 [ %23, %bb57.i ], [ %maximum_block.sroa.0.0101, %bb2.i.i ]
  %_6.sroa.19.1.off0 = phi i32 [ %_162.0.i, %bb57.i ], [ %end.i.i, %bb2.i.i ]
  %_6.sroa.19.1.off32 = phi { i32, i1 } [ %22, %bb57.i ], [ zeroinitializer, %bb2.i.i ]
  %_6.sroa.1615.1 = phi i32 [ %_68.i, %bb57.i ], [ %end.i.i, %bb2.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %cursor.i), !noalias !30
  %_14.0.i = extractvalue { i32, i1 } %_6.sroa.19.1.off32, 0
  %_14.1.i = extractvalue { i32, i1 } %_6.sroa.19.1.off32, 1
  br i1 %_14.1.i, label %bb14, label %bb4.i, !prof !96

bb4.i:                                            ; preds = %bb13
  %_23.0.i = add i32 %_6.sroa.19.1.off0, %overhead.sroa.0.0100
  %_23.1.i = icmp ult i32 %_23.0.i, %overhead.sroa.0.0100
  br i1 %_23.1.i, label %bb14, label %bb7.i, !prof !96

bb7.i:                                            ; preds = %bb4.i
  %_31.0.i = add i32 %_14.0.i, %_23.0.i
  %_31.1.i = icmp ult i32 %_31.0.i, %_23.0.i
  br i1 %_31.1.i, label %bb14, label %bb15, !prof !96

bb14:                                             ; preds = %bb4.i, %bb7.i, %bb13
  %25 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %25, align 1
  br label %bb8

bb15:                                             ; preds = %bb7.i
  %_37 = icmp ugt i32 %_6.sroa.1615.1, %input.sroa.6.0102
  br i1 %_37, label %bb17, label %bb18, !prof !96

bb18:                                             ; preds = %bb15
  %_40 = sub nuw nsw i32 %input.sroa.6.0102, %_6.sroa.1615.1
  %_44 = getelementptr inbounds nuw i8, ptr %input.sroa.0.0103, i32 %_6.sroa.1615.1
  %_3 = icmp eq i32 %_40, 0
  br i1 %_3, label %bb2, label %bb3

bb17:                                             ; preds = %bb15
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_6.sroa.1615.1, i32 noundef %input.sroa.6.0102, i32 noundef %input.sroa.6.0102, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_0b5be9b8ae129437adc2039ef774f149) #7
  unreachable

bb8:                                              ; preds = %bb11, %bb9, %bb14, %bb12
  %.sink = phi i8 [ 1, %bb14 ], [ 1, %bb12 ], [ 0, %bb11 ], [ 1, %bb9 ]
  store i8 %.sink, ptr %_0, align 4
  ret void

bb11:                                             ; preds = %start, %bb2
  %_20.0150 = phi i32 [ %_20.0, %bb2 ], [ 0, %start ]
  %26 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %_20.0150, ptr %26, align 4
  br label %bb8

bb9:                                              ; preds = %bb2
  %27 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %27, align 1
  br label %bb8
}

; <zstdoxide_margin_component::error::Error as core::fmt::Display>::fmt
; Function Attrs: nounwind
define dso_local noundef zeroext i1 @_RNvXNtCs3fddM0pOzd6_26zstdoxide_margin_component5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt(ptr noalias nofree noundef readonly captures(none) dereferenceable(1) %self, ptr noalias nofree noundef align 4 dereferenceable(16) %f) unnamed_addr #1 !guid !100 {
start:
  %0 = load i8, ptr %self, align 1, !range !98, !noundef !24
  %1 = zext nneg i8 %0 to i32
  %switch.gep = getelementptr inbounds nuw i8, ptr @switch.table._RNvXNtCs3fddM0pOzd6_26zstdoxide_margin_component5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt, i32 %1
  %switch.load = load i8, ptr %switch.gep, align 1
  %switch.ext = zext i8 %switch.load to i32
  %2 = zext nneg i8 %0 to i32
  %switch.gep2 = getelementptr inbounds nuw [4 x i8], ptr @switch.table._RNvXNtCs3fddM0pOzd6_26zstdoxide_margin_component5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt.3, i32 %2
  %switch.load3 = load ptr, ptr %switch.gep2, align 4
; call <core::fmt::Formatter>::write_str
  %_0 = tail call noundef zeroext i1 @_RNvMsa_NtCsavDHSl9k1eG_4core3fmtNtB5_9Formatter9write_str(ptr noalias nofree noundef nonnull align 4 dereferenceable(16) %f, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %switch.load3, i32 noundef %switch.ext) #6
  ret i1 %_0
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i32, i1 immarg) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #2

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #2

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #3

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nounwind
declare dso_local void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef, i32 noundef, i32 noundef, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16)) unnamed_addr #4

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #3

; <core::fmt::Formatter>::write_str
; Function Attrs: nounwind
declare dso_local noundef zeroext i1 @_RNvMsa_NtCsavDHSl9k1eG_4core3fmtNtB5_9Formatter9write_str(ptr noalias nofree noundef align 4 dereferenceable(16), ptr noalias nofree noundef nonnull readonly captures(address, read_provenance), i32 noundef) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #5

attributes #0 = { noinline nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #1 = { nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { cold noinline noreturn nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.module.flags = !{!20}
!llvm.ident = !{!21}

!0 = !{i64 -507813728061673588}
!1 = !{i64 8988562274180390229}
!2 = !{i64 4740781876942328178}
!3 = !{i64 588984373593818617}
!4 = !{i64 -8170922141904828614}
!5 = !{i64 -6232927244055801255}
!6 = !{i64 7054942821236925264}
!7 = !{i64 6874385408294899546}
!8 = !{i64 453680272250180342}
!9 = !{i64 1853024519486405509}
!10 = !{i64 6212155164224422469}
!11 = !{i64 -2399512211690608059}
!12 = !{i64 -5942270590352194275}
!13 = !{i64 8696629659717089969}
!14 = !{i64 3875744067033755575}
!15 = !{i64 -1067564451523186472}
!16 = !{i64 3043877604536781233}
!17 = !{i64 1122694971393280989}
!18 = !{i64 -9191857573970037296}
!19 = !{i64 7535919307317198379}
!20 = !{i32 7, !"frame-pointer", i32 2}
!21 = !{!"rustc version 1.101.0-nightly (1d81eb4ad 2026-10-07)"}
!22 = !{i64 7543327747134159079}
!23 = !{i64 3743218004728803186}
!24 = !{}
!25 = !{!"branch_weights", i32 4001, i32 4000000}
!26 = !{i64 5140997336073172954}
!27 = !{!28}
!28 = distinct !{!28, !29, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component12frame_layoutNtB2_11FrameLayout4read: %input.0"}
!29 = distinct !{!29, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component12frame_layoutNtB2_11FrameLayout4read"}
!30 = !{!31, !28}
!31 = distinct !{!31, !29, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component12frame_layoutNtB2_11FrameLayout4read: %_0"}
!32 = !{!33, !35, !28}
!33 = distinct !{!33, !34, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component: %dest.0"}
!34 = distinct !{!34, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component"}
!35 = distinct !{!35, !34, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component: %src.0"}
!36 = !{!37, !39, !31}
!37 = distinct !{!37, !38, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %_0"}
!38 = distinct !{!38, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian"}
!39 = distinct !{!39, !38, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %self"}
!40 = !{!41}
!41 = distinct !{!41, !42, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component5frameNtB2_11FrameHeader5parse: %input.0"}
!42 = distinct !{!42, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component5frameNtB2_11FrameHeader5parse"}
!43 = !{!41, !28}
!44 = !{!45, !47, !31}
!45 = distinct !{!45, !46, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4byte: %self"}
!46 = distinct !{!46, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4byte"}
!47 = distinct !{!47, !42, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component5frameNtB2_11FrameHeader5parse: %_0"}
!48 = !{!49, !47, !31}
!49 = distinct !{!49, !50, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4byte: %self"}
!50 = distinct !{!50, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4byte"}
!51 = !{!47, !41, !31, !28}
!52 = !{!53, !55, !56, !58, !47, !41, !31, !28}
!53 = distinct !{!53, !54, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take: %_0"}
!54 = distinct !{!54, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take"}
!55 = distinct !{!55, !54, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take: %self"}
!56 = distinct !{!56, !57, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %_0"}
!57 = distinct !{!57, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian"}
!58 = distinct !{!58, !57, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %self"}
!59 = !{!60, !62, !47, !41, !31, !28}
!60 = distinct !{!60, !61, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %_0"}
!61 = distinct !{!61, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian"}
!62 = distinct !{!62, !61, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %self"}
!63 = !{!64, !66}
!64 = distinct !{!64, !65, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component: %dest.0"}
!65 = distinct !{!65, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component"}
!66 = distinct !{!66, !65, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component: %src.0"}
!67 = !{!60, !62, !47, !31}
!68 = !{!69, !71, !28}
!69 = distinct !{!69, !70, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component: %dest.0"}
!70 = distinct !{!70, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component"}
!71 = distinct !{!71, !70, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component: %src.0"}
!72 = !{!73, !75, !31}
!73 = distinct !{!73, !74, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %_0"}
!74 = distinct !{!74, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian"}
!75 = distinct !{!75, !74, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %self"}
!76 = !{!77, !79, !31, !28}
!77 = distinct !{!77, !78, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take: %_0"}
!78 = distinct !{!78, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take"}
!79 = distinct !{!79, !78, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take: %self"}
!80 = !{!81, !83, !84, !86, !31}
!81 = distinct !{!81, !82, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take: %_0"}
!82 = distinct !{!82, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take"}
!83 = distinct !{!83, !82, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take: %self"}
!84 = distinct !{!84, !85, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %_0"}
!85 = distinct !{!85, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian"}
!86 = distinct !{!86, !85, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor13little_endian: %self"}
!87 = !{!88, !90, !28}
!88 = distinct !{!88, !89, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component: %dest.0"}
!89 = distinct !{!89, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component"}
!90 = distinct !{!90, !89, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs3fddM0pOzd6_26zstdoxide_margin_component: %src.0"}
!91 = !{!84, !86, !31}
!92 = !{!93, !95, !31}
!93 = distinct !{!93, !94, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take: %_0"}
!94 = distinct !{!94, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take"}
!95 = distinct !{!95, !94, !"_RNvMNtCs3fddM0pOzd6_26zstdoxide_margin_component6cursorNtB2_10ByteCursor4take: %self"}
!96 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!97 = !{!31}
!98 = !{i8 0, i8 14}
!99 = !{!"branch_weights", !"expected", i32 18073191, i32 2129410457}
!100 = !{i64 4731312288209393497}
