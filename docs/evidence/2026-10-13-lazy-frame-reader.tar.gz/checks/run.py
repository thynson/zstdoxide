from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/zstdoxide-lazy-frame-reader')
source_files=['src/lib.rs','tests/support/greedy_frame_oracle.rs','tests/support/lazy_frame_oracle.rs']
def sources():return {f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in source_files}
original=sources()
commands=[['cargo','fmt','--check'],['cargo','clippy','--all-targets','--','-D','warnings'],['cargo','clippy','--all-targets','--all-features','--','-D','warnings']]
for features in [[],['--features','unsafe-reference-chain'],['--features','unsafe-row-table'],['--all-features']]:
 commands.append(['cargo','test','--lib',*features,'lazy_frame_oracle_fixture'])
 commands.append(['cargo','check','--no-default-features',*features])
for features in [[],['--all-features']]:
 commands.append(['cargo','test','--lib',*features,'greedy_frame_oracle_fixture'])
 commands.append(['cargo','test',*features,'--test','reference_greedy_defaults'])
results=[]
for i,cmd in enumerate(commands):
 if sources()!=original:raise ValueError('source changed during checks')
 with (root/f'{i:02}.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':cmd,'status':r.returncode,'log':f'{i:02}.log'})
 (root/'results.json').write_text(json.dumps({'sources':original,'commands':results},indent=2)+'\n')
 print(i,r.returncode,' '.join(cmd),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
if sources()!=original:raise ValueError('final source changed')
