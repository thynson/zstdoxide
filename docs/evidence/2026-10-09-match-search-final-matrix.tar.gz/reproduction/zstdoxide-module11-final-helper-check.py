import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path('/tmp/zstdoxide-module11-final-9537371');source=root/'source'
manifest=json.loads((root/'source-hashes-before.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();overrides={'RUSTUP_TOOLCHAIN':'nightly-2026-10-08','CARGO_TARGET_DIR':str(root/'helper-target'),'CARGO_TERM_COLOR':'never'};env.update(overrides)
checks=[('helper-format',['cargo','fmt','--manifest-path','test-support/allocator/Cargo.toml','--','--check']),('helper-tests',['cargo','test','--offline','--locked','--manifest-path','test-support/allocator/Cargo.toml']),('helper-clippy',['cargo','clippy','--offline','--locked','--manifest-path','test-support/allocator/Cargo.toml','--all-targets','--','-D','warnings'])]
e={'revision':'9537371','environment':overrides,'commands':[],'complete':False}
for name,command in checks:
 log=root/(name+'.log');start=time.monotonic()
 with log.open('w') as out:r=subprocess.run(command,cwd=source,env=env,stdout=out,stderr=subprocess.STDOUT)
 changed=[p for p,h in manifest.items() if digest(source/p)!=h]
 e['commands'].append({'name':name,'command':command,'cwd':str(source),'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log),'sha256':digest(log),'source_changed':changed})
 (root/'helper-evidence.json').write_text(json.dumps(e,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode or changed:raise SystemExit('Helper validation failed')
e['complete']=True;e['runner_sha256']=digest(pathlib.Path(__file__));(root/'helper-evidence.json').write_text(json.dumps(e,indent=2)+'\n')
