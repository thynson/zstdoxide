import hashlib, json, os, pathlib, re, subprocess, tarfile, time
repo = pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize')
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
root = pathlib.Path('/tmp') / ('zstdoxide-module11-final-' + revision[:7])
root.mkdir(exist_ok=False)
source = root / 'source'; source.mkdir()
archive = root / 'source.tar'
with archive.open('wb') as out:
    subprocess.run(['git', 'archive', revision], cwd=repo, stdout=out, check=True)
with tarfile.open(archive) as contents:
    contents.extractall(source, filter='data')
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
manifest = {str(p.relative_to(source)): digest(p) for p in source.rglob('*') if p.is_file()}
(root / 'source-hashes-before.json').write_text(json.dumps(manifest, indent=2)+'\n')
features = ['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-dictionary','unsafe-training']
env = os.environ.copy()
overrides = {'CARGO_TARGET_DIR': str(root/'target'), 'RUSTUP_TOOLCHAIN':'nightly-2026-10-08', 'CARGO_TERM_COLOR':'never', 'ZSTD_UPSTREAM':'/tmp/zstdoxize-upstream-1.5.7', 'ZSTD_BIN':'/tmp/zstdoxize-upstream-1.5.7/programs/zstd'}
env.update(overrides)
commands = []
def add(name, command, kind='check', expected=0): commands.append((name, command, kind, expected))
def cargo(name, operation, *args, kind='check'): add(name, ['cargo', operation, '--offline', '--locked', *args], kind)
add('compiler', ['rustc','--version','--verbose'])
add('official-version', [env['ZSTD_BIN'],'--version'])
add('format', ['cargo','fmt','--all','--','--check'])
cargo('tests-safe','test',kind='full-suite')
for feature in features:
    cargo('tests-'+feature,'test','--features',feature,kind='full-suite')
cargo('tests-all','test','--all-features',kind='full-suite')
cargo('tests-release-all','test','--release','--all-features',kind='full-suite')
for suffix, args in [('safe',[])] + [(f,['--features',f]) for f in features] + [('all',['--features',','.join(features)])]:
    cargo('no-std-'+suffix,'check','--no-default-features','--lib',*args)
for suffix, args in [('safe',[]),('all',['--all-features'])]:
    cargo('clippy-'+suffix,'clippy','--all-targets',*args,'--','-D','warnings')
    add('usage-'+suffix,['python3','scripts/check_doc_examples.py',*args],'usage')
    cargo('search-oracle-'+suffix,'test','--release',*args,'--test','match_search_options','--','--ignored','--nocapture',kind='oracle')
    cargo('search-lifecycle-oracle-'+suffix,'test','--release',*args,'--test','upstream_search_lifecycle','--','--ignored','--nocapture',kind='oracle')
add('hash-fixture-reproduction',['python3','scripts/import_match_search_fixtures.py',env['ZSTD_UPSTREAM'],'--check'])
add('default-baseline-audit',['python3','scripts/check_match_search_baseline.py'])
add('fixtures',['python3','scripts/check_upstream_fixtures.py'])
add('inventory',['python3','scripts/audit_upstream_tests.py','--upstream',env['ZSTD_UPSTREAM']])
add('oracle-script-syntax',['sh','-n','scripts/check_upstream_oracles.sh'])
add('require-complete-known-gap',['python3','scripts/audit_upstream_tests.py','--require-complete'],'known-gap',1)
external_inputs = {path: digest(pathlib.Path(path)) for path in [env['ZSTD_BIN']]}
record = {'external_input_hashes': external_inputs, 'revision':revision,'source_root':str(source),'source_archive_sha256':digest(archive),'tracked_file_count':len(manifest),'environment':overrides,'commands':[],'complete':False}
(root/'plan.json').write_text(json.dumps({'revision':revision,'commands':commands},indent=2)+'\n')
pattern = re.compile(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out')
for name, command, kind, expected in commands:
    start=time.monotonic(); log=root/(name+'.log')
    with log.open('w') as out:
        result=subprocess.run(command,cwd=source,env=env,stdout=out,stderr=subprocess.STDOUT)
    text=log.read_text()
    tests=[dict(zip(['passed','failed','ignored','measured','filtered_out'],map(int,m))) for m in pattern.findall(text)]
    changed=[path for path,value in manifest.items() if not (source/path).is_file() or digest(source/path)!=value]
    entry={'name':name,'command':command,'kind':kind,'expected_exit_code':expected,'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log),'sha256':digest(log),'test_results':tests,'test_totals':{k:sum(t[k] for t in tests) for k in ['passed','failed','ignored','measured','filtered_out']},'source_changed':changed}
    record['commands'].append(entry)
    (root/'evidence.json').write_text(json.dumps(record,indent=2)+'\n')
    print(name,result.returncode,entry['seconds'],entry['test_totals'],flush=True)
    if result.returncode != expected or changed or (kind in ('full-suite','usage','oracle') and (not tests or not sum(t['passed'] for t in tests))):
        raise SystemExit('Validation failed: '+name)
if not all(digest(pathlib.Path(path)) == value for path, value in external_inputs.items()):
    raise SystemExit('External input changed')
record['external_inputs_unchanged']=True
suite_totals = [c['test_totals'] for c in record['commands'] if c['kind']=='full-suite']
if len(suite_totals)!=15 or any(t!=suite_totals[0] for t in suite_totals):
    raise SystemExit('Full suite matrix differs across configurations')
record['complete']=True
record['all_task_processes_finished']=True
record['full_suite_runs']=len([c for c in record['commands'] if c['kind']=='full-suite'])
record['full_suite_aggregate']={k:sum(c['test_totals'][k] for c in record['commands'] if c['kind']=='full-suite') for k in ['passed','failed','ignored']}
record['source_unchanged']=True
(root/'source-hashes-after.json').write_text(json.dumps({p:digest(source/p) for p in manifest},indent=2)+'\n')
(root/'evidence.json').write_text(json.dumps(record,indent=2)+'\n')
print('Complete evidence:',root/'evidence.json',flush=True)
