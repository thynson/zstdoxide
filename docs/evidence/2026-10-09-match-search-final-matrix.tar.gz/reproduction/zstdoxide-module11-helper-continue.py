import hashlib,json,os,pathlib,shutil,subprocess,time
root=pathlib.Path('/tmp/zstdoxide-module11-final-9537371');original=root/'source/test-support/allocator';source=root/'helper-source'
shutil.copytree(original,source)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inputs={str(p.relative_to(source)):digest(p) for p in source.rglob('*') if p.is_file()}
e={'scope':'Standalone allocator helper copied from the immutable final source; generate its absent ignored Cargo.lock offline before locked checks. The initial --locked attempt ran no tests.','inputs_before':inputs,'source':str(source),'commands':[],'complete':False}
env=os.environ.copy();overrides={'RUSTUP_TOOLCHAIN':'nightly-2026-10-08','CARGO_TARGET_DIR':str(root/'helper-target'),'CARGO_TERM_COLOR':'never'};env.update(overrides);e['environment']=overrides
checks=[('helper-lock',['cargo','generate-lockfile','--offline']),('helper-tests-final',['cargo','test','--offline','--locked']),('helper-clippy-final',['cargo','clippy','--offline','--locked','--all-targets','--','-D','warnings'])]
for name,command in checks:
 log=root/(name+'.log');start=time.monotonic()
 with log.open('w') as out:r=subprocess.run(command,cwd=source,env=env,stdout=out,stderr=subprocess.STDOUT)
 changed=[p for p,h in inputs.items() if digest(source/p)!=h]
 e['commands'].append({'name':name,'command':command,'cwd':str(source),'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log),'sha256':digest(log),'source_changed':changed})
 (root/'helper-final-evidence.json').write_text(json.dumps(e,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode or changed:raise SystemExit('Helper validation failed')
e['complete']=True;e['runner_sha256']=digest(pathlib.Path(__file__));e['generated_lock']={'sha256':digest(source/'Cargo.lock'),'contents':(source/'Cargo.lock').read_text()};(root/'helper-final-evidence.json').write_text(json.dumps(e,indent=2)+'\n')
