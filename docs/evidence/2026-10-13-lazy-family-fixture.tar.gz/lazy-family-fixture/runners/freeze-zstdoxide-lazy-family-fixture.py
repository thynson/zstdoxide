from pathlib import Path
import hashlib,json,sys
R=Path('/Users/lanxingcan/Workspace/zstdoxize');C=Path('/private/tmp/zstdoxide-lazy-families-2026-10-12');sys.path.insert(0,str(R/'scripts'))
import check_lazy_family_recipes as inputs
import check_lazy_family_capture as audit
report=audit.audit(C);e=json.loads((C/'evidence.json').read_bytes());g,cases,recipes=inputs.inputs()
def sha(b):return hashlib.sha256(b).hexdigest()
import check_lazy_family_fixture as fixture
parts=[];records={};observed={};cursor=0
for name,label in [(c.name,'normal-case-'+c.name) for c in cases]+[(f'salt-{mode}-{d}',f'{mode}-fresh-salt-{d}') for mode in ['normal','sanitized'] for d in range(3)]:
 raw=(C/'logs'/(label+'.stdout')).read_bytes();records[name]={'offset':cursor,'bytes':len(raw),'sha256':sha(raw)};parts.append(raw);observed[name]=raw;cursor+=len(raw)
pack=b''.join(parts)
manifest={'schema_version':1,'upstream_revision':g.REVISION,'source':e['source_before'],'auditor_sha256':sha((R/'scripts/check_lazy_family_capture.py').read_bytes()),'raw_evidence_sha256':sha((C/'evidence.json').read_bytes()),'compiler':(C/'logs/compiler-version.stdout').read_text(),'compiler_sha256':e['compiler_sha256'],'pack_bytes':len(pack),'pack_sha256':sha(pack),'records':records,'audit':report,'score_observations':fixture.score_observations(g,cases,recipes,observed),'qualification':'Real normal/sanitized pinned C observations. Every direct byte agrees across builds. Fresh-context peaks are retained separately because upstream ASan workspace redzones differ. Full final tables/frontiers are not chronological probe traces. No Rust Lazy execution or complete-frame interoperability is claimed.'}
saved=json.loads(Path('/tmp/zstdoxide-lazy-family-audit-normal.json').read_bytes())
if saved != report:raise ValueError('resumed audit differs')
Path('/tmp/zstdoxide-lazy-family-freeze-audit.json').write_text(json.dumps(report,sort_keys=True)+'\n')
dest=R/'tests/fixtures/reference-lazy-families'
for name,data in [('observations.ndjson',pack),('capture.json',(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())]:
 p=dest/name
 if p.exists():raise ValueError('fresh output required')
 p.write_bytes(data);print(name,len(data),sha(data))
