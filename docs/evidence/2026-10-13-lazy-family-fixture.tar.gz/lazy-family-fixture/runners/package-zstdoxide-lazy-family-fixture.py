from pathlib import Path
from collections import Counter
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';T=Path('/tmp');C=Path('/private/tmp/zstdoxide-lazy-families-2026-10-12');F=R/'tests/fixtures/reference-lazy-families'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(ok,msg):
 if not ok:raise ValueError(msg)
m=json.loads((F/'capture.json').read_bytes());pack=(F/'observations.ndjson').read_bytes();files={}
need(sha(pack)==m['pack_sha256'] and len(pack)==m['pack_bytes'],'pack identity')
need(sha((C/'evidence.json').read_bytes())==m['raw_evidence_sha256'],'capture identity')
capture=json.loads((C/'evidence.json').read_bytes())
need(m['source']==capture['source_before']==capture['source_after'],'capture source')
for n,h in m['source'].items():
 raw=(R/n).read_bytes();need(sha(raw)==h,'source identity '+n);files['source/'+n]=raw
observed={}
for name,r in m['records'].items():
 raw=pack[r['offset']:r['offset']+r['bytes']];need(sha(raw)==r['sha256'],'record hash')
 label=name.replace('salt-normal-','normal-fresh-salt-').replace('salt-sanitized-','sanitized-fresh-salt-') if name.startswith('salt-') else 'normal-case-'+name
 need(raw==(C/'logs'/(label+'.stdout')).read_bytes(),'exact captured bytes '+name)
 if name.startswith('d'):
  need(raw==(C/'logs'/('sanitized-case-'+name+'.stdout')).read_bytes(),'cross-build bytes '+name)
  observed[name]=json.loads(raw.splitlines()[1])
for h in json.loads((F/'recipes.json').read_bytes())['score_hypotheses']:
 if h['branch']==0:
  need(observed[h['id']]['sequences']==observed[h['id'].replace('-chain-','-row-')]['sequences'],'full chain/row score sequences')
for mode in ('normal','optimized'):
 p=T/('zstdoxide-lazy-family-fixture-controls-'+mode+'.json');v=json.loads(p.read_bytes())
 need(v['status']=='passed' and (v['positive'],v['rejected'],v['child_processes'])==(2,24,0),'control results '+mode)
 need(v['optimized']==(mode=='optimized'),'mode')
 need(v['fixture_checker_sha256']==sha((R/'scripts/check_lazy_family_fixture.py').read_bytes()),'checker identity')
 need(v['runner_sha256']==sha((T/'check-zstdoxide-lazy-family-fixture-controls.py').read_bytes()),'runner identity')
 files['controls-'+mode+'.json']=p.read_bytes();files['controls-'+mode+'.stderr']=(T/('zstdoxide-lazy-family-fixture-controls-'+mode+'.stderr')).read_bytes()
for n in ('freeze-zstdoxide-lazy-family-fixture.py','check-zstdoxide-lazy-family-fixture-controls.py','package-zstdoxide-lazy-family-fixture.py','check-zstdoxide-lazy-score-substitutions.py'):files['runners/'+n]=(T/n).read_bytes()
for n in ('zstdoxide-lazy-family-freeze-audit.json','zstdoxide-lazy-family-freeze.stdout','zstdoxide-lazy-family-freeze.stderr','zstdoxide-lazy-family-score-substitutions.json'):files[n]=(T/n).read_bytes()
need(not files['zstdoxide-lazy-family-freeze.stderr'],'freeze diagnostics')
need(json.loads(files['zstdoxide-lazy-family-freeze-audit.json'])==m['audit'],'freeze audit exact')
for n in ('scripts/check_lazy_family_fixture.py','scripts/check_lazy_family_capture.py','tests/fixtures/reference-lazy-families/capture.json','tests/fixtures/reference-lazy-families/observations.ndjson','tests/fixtures/reference-lazy-families/README.md'):files['source/'+n]=(R/n).read_bytes()
w=json.loads((E/'2026-10-12-lazy-family-wip.json').read_bytes());need(sha((E/w['archive']).read_bytes())==w['archive_sha256'],'capture archive identity')
for n in ('2026-10-12-lazy-family-wip.json','2026-10-13-lazy-family-controls.json'):files['evidence/'+n]=(E/n).read_bytes()
report=dict(date='2026-10-13',status='passed',pack_bytes=len(pack),pack_sha256=sha(pack),manifest_bytes=(F/'capture.json').stat().st_size,manifest_sha256=sha((F/'capture.json').read_bytes()),stored_observation_groups=len(m['records']),direct_recipes=645,score_inputs=96,score_classifications=dict(Counter(r['classification'] for r in m['score_observations'])),chain_row_complete_sequence_pairs=48,exact_tiny_controls=138,predecessor_controls=173,controls_per_mode=dict(positive=2,rejected=24,child_processes=0),checker_sha256=sha((R/'scripts/check_lazy_family_fixture.py').read_bytes()),capture_archive=w['archive'],capture_archive_sha256=w['archive_sha256'],raw_evidence_sha256=m['raw_evidence_sha256'],source_unchanged=True,qualification='Frozen real C direct observations only. All pack groups compared against their actual captured bytes and all direct groups against both builds. New score summaries classify final publication, not chronological probes or initial baseline-repeat selection. Semantic forgery controls override the manifest pin only to exercise deeper checks; production checking retains the immutable pin. Immutable input recipes/predecessors cached after real validation with source hashes checked before/after. No Rust Lazy execution, new C run, ordinary/public frame or timing claim.',archive='2026-10-13-lazy-family-fixture.tar.gz')
files['review.json']=enc(report);files['bundle-manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())})
a=E/report['archive'];need(not a.exists(),'fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('lazy-family-fixture/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a,'r|gz') as t:actual={m.name:t.extractfile(m).read() for m in t}
need(actual=={'lazy-family-fixture/'+n:b for n,b in files.items()},'exact archive readback')
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(files))
(E/'2026-10-13-lazy-family-fixture.json').write_bytes(enc(report));print(json.dumps(report,sort_keys=True))
