import sys,json,hashlib
from pathlib import Path
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(R/'scripts'))
from oracles import lazy_direct as g,lazy_families as f
root=Path('/private/tmp/zstdoxide-lazy-families-2026-10-12/logs');results=[]
for branch,name in enumerate(('chain','row')):
 case=f.extended(next(c for c,h in f.threshold_hypotheses(branch) if c.name==name+'-explicit-depth-1-above'),1)
 rows=g.records((root/('normal-case-'+case.name+'.stdout')).read_bytes())
 old=g.records((root/('normal-case-d0-'+name+'-explicit-depth-1-above.stdout')).read_bytes())
 for i in (1,2):
  old[i].update(id=rows[i]['id'],depth=rows[i]['depth'],strategy=rows[i]['strategy']);rows[i]=old[i]
 raw=b''.join((json.dumps(r,sort_keys=True)+'\n').encode() for r in rows)
 g.validate(case,raw)
 results.append({'case':case.name,'semantic_replay':'passed','emitted':[[r['ll'],r['ml'],r['off_base']] for r in rows[1]['sequences']],'substitution':'complete depth-zero case records with Lazy selectors','raw_sha256':hashlib.sha256(raw).hexdigest()})
print(json.dumps(results,indent=2,sort_keys=True))
