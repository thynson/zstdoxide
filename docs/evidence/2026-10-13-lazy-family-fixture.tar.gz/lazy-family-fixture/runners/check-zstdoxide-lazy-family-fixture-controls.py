from pathlib import Path
import contextlib,copy,hashlib,json,os,runpy,subprocess,sys
from unittest.mock import patch
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(R/'scripts'));sys.dont_write_bytecode=True
m=runpy.run_path(str(R/'scripts/check_lazy_family_fixture.py'));g=m['fixture'].__globals__;read=g['bounded'];pin=g['FIXTURE_SHA'];prefix=m['COLLECTION']
original=read(prefix+'/capture.json',1<<20);pack=read(prefix+'/observations.ndjson',64<<20);base=json.loads(original);shadow={};children=[];checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True)+'\n').encode()
def bad(name,mutate):
 try:
  mutate()
  try:m['fixture']()
  except (ValueError,OSError,TypeError,KeyError) as error:
   checks.append({'name':name,'reason':str(error)})
   print('rejected: '+name,file=sys.stderr,flush=True)
  else:raise RuntimeError('accepted '+name)
 finally:shadow.clear();g['FIXTURE_SHA']=pin

def manifest(name,mutate):
 def change():
  v=copy.deepcopy(base);mutate(v);b=enc(v);shadow[prefix+'/capture.json']=b;g['FIXTURE_SHA']=sha(b)
 bad(name,change)
def record(name,case,mutate):
 def change():
  v=copy.deepcopy(base);r=v['records'][case];start=r['offset'];end=start+r['bytes'];rows=[json.loads(x) for x in pack[start:end].splitlines()];mutate(rows);new=b''.join(enc(x) for x in rows);combined=pack[:start]+new+pack[end:];delta=len(new)-r['bytes']
  for item in v['records'].values():
   if item['offset']>=end:item['offset']+=delta
  r.update(bytes=len(new),sha256=sha(new));v.update(pack_bytes=len(combined),pack_sha256=sha(combined));b=enc(v);shadow[prefix+'/observations.ndjson']=combined;shadow[prefix+'/capture.json']=b;g['FIXTURE_SHA']=sha(b)
 bad(name,change)
def deny(*a,**kw):children.append('process');raise RuntimeError('child forbidden')
# Cache only real-validated immutable input recipes and predecessor fixtures.
# Every changed fixture still goes through the new checker and semantic replay.
import check_lazy_family_recipes as recipes
import check_lazy_tiny_fixture as tiny
import check_greedy_family_capture as predecessor
cached_files={p:sha(p.read_bytes()) for pattern in ('scripts/**/*.py','tests/fixtures/reference-lazy*/**/*','tests/fixtures/reference-greedy*/**/*') for p in R.glob(pattern) if p.is_file()}
def memo(fn):
 values=[]
 def cached(*args):
  if not values:values.append(fn(*args))
  return values[0]
 return cached

def replace_with_depth_zero(rows, branch):
 name=f'd0-{branch}-explicit-depth-1-above'
 r=base['records'][name]
 earlier=[json.loads(x) for x in pack[r['offset']:r['offset']+r['bytes']].splitlines()]
 for i in (1,2):
  earlier[i].update(id=rows[i]['id'],depth=rows[i]['depth'],strategy=rows[i]['strategy'])
  rows[i]=earlier[i]

with contextlib.ExitStack() as stack:
 stack.enter_context(patch.dict(g,bounded=lambda n,c:shadow[n] if n in shadow else read(n,c)))
 for mod,n in [(subprocess,'Popen'),(os,'system'),(os,'posix_spawn'),(os,'posix_spawnp')]:
  if hasattr(mod,n):stack.enter_context(patch.object(mod,n,deny))
 for module,name in [(recipes,'inputs'),(tiny,'fixture'),(predecessor,'fixture')]:
  stack.enter_context(patch.object(module,name,memo(getattr(module,name))))
 positive=m['fixture']()
 print('initial positive passed',file=sys.stderr,flush=True)
 bad('changed-manifest-pin',lambda:shadow.update({prefix+'/capture.json':original+b' '}))
 bad('changed-pack',lambda:shadow.update({prefix+'/observations.ndjson':pack+b' '}))
 manifest('wrong-revision',lambda v:v.update(upstream_revision='0'*40))
 manifest('wrong-auditor',lambda v:v.update(auditor_sha256='0'*64))
 manifest('missing-source',lambda v:v['source'].pop(next(iter(v['source']))))
 manifest('missing-observation',lambda v:v['records'].pop('d2-chain-first-tail'))
 manifest('offset-bool',lambda v:v['records']['d0-chain-fresh-7'].update(offset=False))
 manifest('oversized-extent',lambda v:v['records']['d0-chain-fresh-7'].update(bytes=len(pack)+1))
 manifest('changed-predecessor-map',lambda v:v['audit']['predecessor_controls'][0].update(predecessor_id='missing'))
 manifest('changed-tail-frontier',lambda v:v['audit']['geometry_observations'][0].update(final_next_to_update=99))
 record('depth','d2-chain-first-tail',lambda r:r[1].update(depth=1))
 record('wire-repeat','d1-chain-first-tail',lambda r:r[1].update(wire_repeats=[0,0,0]))
 record('huge-frontier','d2-row-second-tail',lambda r:r[1].update(final_next_to_update=2**32))
 record('salt-strategy','salt-normal-1',lambda r:r[1]['resolved'].__setitem__(6,3))
 record('table-fingerprint','d2-row-second-tail',lambda r:r[1]['first_table'].update(after_fnv1a64='0'*16))
 manifest('boolean-capture-total',lambda v:v['audit'].update(recipes=True))
 manifest('changed-capture-total',lambda v:v['audit'].update(direct_observations=2579))
 manifest('missing-score-observation',lambda v:v['score_observations'].pop())
 manifest('changed-score-publication',lambda v:v['score_observations'][0].update(emitted=[1,9,128]))
 manifest('changed-score-classification',lambda v:v['score_observations'][0].update(classification='invented-probe-trace'))
 for branch in ('chain','row'):
  record('coherent-depth-zero-in-lazy-'+branch,'d1-'+branch+'-explicit-depth-1-above',lambda r,branch=branch:replace_with_depth_zero(r,branch))
  if 'observed constructed threshold outcome' not in checks[-1]['reason']:raise RuntimeError('wrong score rejection layer')
 record('coherent-tiny-entropy','d1-row-period-four',lambda r:[x.update(final_entropy=(x['final_entropy']+1)&0xffffffff) for x in r[1:3]])
 if 'unchanged complete tiny observation' not in checks[-1]['reason']:raise RuntimeError('wrong tiny rejection layer')
 record('coherent-predecessor-entropy','d0-row-explicit-window-15',lambda r:[x.update(final_entropy=(x['final_entropy']+1)&0xffffffff) for x in r[1:3]])
 if 'depth-zero predecessor semantics' not in checks[-1]['reason']:raise RuntimeError('wrong predecessor rejection layer')
 restored=m['fixture']()
 if positive!=restored or children or len(checks)!=24:raise RuntimeError('control counts')
for p,digest in cached_files.items():
 if sha(p.read_bytes())!=digest:raise RuntimeError('cached input changed: '+str(p))
print(json.dumps({'qualification':'Immutable recipe/predecessor inputs cached after real validation with source hashes checked before/after; changed fixture bytes always replayed. Manifest pin overridden only in semantic controls to exercise deeper checks.', 'status':'passed','optimized':not __debug__,'positive':2,'rejected':len(checks),'child_processes':len(children),'cases':checks,'fixture_checker_sha256':sha((R/'scripts/check_lazy_family_fixture.py').read_bytes()),'runner_sha256':sha(Path(__file__).read_bytes())},sort_keys=True))
