from pathlib import Path
import hashlib,json,os,subprocess,tomllib,time
R=Path.cwd();O=Path('/tmp/zstdoxide-optimal-public-matrix-1016');O.mkdir(exist_ok=False)
features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'})
env=dict(os.environ,CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-public-matrix-1016-target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
paths=list((R/'examples').rglob('*.rs'))+list((R/'src').rglob('*.rs'))+list((R/'tests').rglob('*.rs'))+list((R/'test-support').rglob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock',R/'rust-toolchain.toml']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source={str(p.relative_to(R)):sha(p)for p in paths};commands=[]
def save(status,error=None):
 unchanged=all(sha(R/p)==h for p,h in source.items())
 (O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,source_unchanged=unchanged,features=features,isolated_features=len(features),prior_full_safe_sha256=sha(Path('/tmp/zstdoxide-optimal-public-full-safe-v3-1016/evidence.json')),failed_commands=sum(c['exit_code']!=0 for c in commands),environment_overrides={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG']},commands=commands),indent=2)+'\n')
def run(label,args):
 cmd=['cargo',*args];start=time.monotonic();print('START',label,flush=True)
 with(O/(label+'.log')).open('wb')as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 commands.append(dict(label=label,argv=cmd,exit_code=p.returncode,seconds=time.monotonic()-start,log=label+'.log',sha256=sha(O/(label+'.log'))));save('running')
 if p.returncode:raise RuntimeError(label)
 print('END',label,flush=True)
try:
 prior=Path('/tmp/zstdoxide-optimal-public-full-safe-v3-1016/evidence.json');previous=json.loads(prior.read_text())
 if previous['status']!='passed' or not previous['source_unchanged'] or previous['source']!=source:raise ValueError('full safe prerequisite must match current complete source')
 for feature in features:
  run('test-'+feature,['test','--offline','--locked','--features',feature,'--lib','optimal_'])
  run('public-'+feature,['test','--offline','--locked','--features',feature,'--test','reference_optimal','--test','reference_optimal_platform'])
  run('nostd-'+feature,['check','--offline','--locked','--no-default-features','--features',feature])
 for mode,flags in [('all',['--all-features']),('release-all',['--release','--all-features'])]:run('full-'+mode,['test','--offline','--locked',*flags])
 run('clippy',['clippy','--offline','--locked','--all-features','--all-targets','--','-D','warnings'])
 run('fmt',['fmt','--all','--','--check'])
 if not all(sha(R/p)==h for p,h in source.items()):raise ValueError('source changed')
 save('passed')
except BaseException as e:save('failed',repr(e));raise
