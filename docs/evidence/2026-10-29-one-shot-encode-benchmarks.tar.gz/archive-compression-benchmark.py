"""Archive the measured module35 encode-selection benchmark campaign."""
from pathlib import Path
import hashlib, json, tarfile, importlib.util, datetime

D = Path('/private/tmp/module35-encode-selection-benchmark')
E = Path(__file__).parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('measure', D / 'measure.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
b, gates = m.validate()
r = json.loads((D / 'repeat/evidence.json').read_text())
q = json.loads((D / 'timed.json').read_text())
z = json.loads((D / 'repeat/timed.json').read_text())
s = json.loads((D / 'summary.json').read_text())
assert q['status'] == z['status'] == 'passed' and len(q['runs']) == 24 and len(z['runs']) == 2
assert q['gates'] == z['gates'] == gates
assert z['primary_timing_sha256'] == sha(D / 'timed.json') and z['build_evidence_sha256'] == sha(D / 'repeat/evidence.json')
for folder, build, timed in [(D, b, q), (D / 'repeat', r, z)]:
    for row in build['builds']:
        assert sha(folder / row['executable']) == row['sha256']
        assert (folder / (row['name'] + '-qualify.tsv')).read_bytes() == (D / 'safe-qualify.tsv').read_bytes()
    for row in timed['runs']:
        assert sha(folder / (row['name'] + '-timed.tsv')) == row['sha256']
fixtures = {'source/tests/upstream/data/golden-compression/http', 'source/tests/upstream/data/golden-compression/large-literal-and-match-lengths', 'source/tests/upstream/dictionaries/formatted.dict'}
files = {}
for p in D.rglob('*'):
    if not p.is_file():
        continue
    rel = p.relative_to(D)
    if any(x == 'target' or x.endswith('-target') or x == '__pycache__' for x in rel.parts):
        continue
    if 'source' in rel.parts and p.suffix not in {'.rs', '.toml', '.lock', '.json', '.py', '.md', '.sh', '.csv', '.tsv'} and str(rel) not in fixtures:
        continue
    files[str(rel)] = p
assert fixtures <= files.keys()
files['archive-compression-benchmark.py'] = Path(__file__)
files['LICENSE.zstd'] = Path('/Users/lanxingcan/Workspace/zstdoxize/LICENSE.zstd')
name = '2026-10-29-one-shot-encode-benchmarks'
archive = E / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
result = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), build=b, repeat_build=r, primary_timing=q, repeat_timing=z, summary=s, members={n: dict(sha256=sha(p), bytes=p.stat().st_size) for n, p in files.items()}, archive=archive.name, archive_sha256=sha(archive), qualification='All 24 safe/isolated/all production feature selections and two independently rebuilt safe/all repeats retain 675 timing samples and 297 role-specific qualification rows per executable: four compression modes (stateless baseline, persistent coordinator, prefix rearming outside and inside the compression clock) plus setup-only arm/observe/clear batch observations whose loop and black-box overhead is included and not directly subtractable. Staging/workspace/dictionary ledgers are outside timings; Global per-call scratch is inside. Every mode borrows the same immutable view, writes the same caller destination and ends in the verified consumed or persistent selection state. Actual process barriers precede campaigns. No universal speedup, desktop idleness, C byte identity or complete codec replacement is claimed.')
(E / (name + '.json')).write_text(json.dumps(result, indent=2) + '\n')
print(name, archive.stat().st_size)
report = """# One-shot encode selection measurements

Thirty-three fixed pairs combine empty, raw and prepared dictionaries with
eleven inputs: empty/tiny data, content-size boundaries, raw/RLE and multiblock
input, and two retained upstream golden fixtures. The stateless baseline, the
persistent coordinator and both prefix schedules borrow the same immutable
DictionaryView, write the same caller-owned destination prepared outside
clocks, and produce exactly the stateless encoder bytes. Every attempt starts
with the intended selection and ends consumed (prefix) or retained
(persistent); guards, suffixes, complete-byte equality and unchanged dictionary
bytes are checked outside clocks.

Twenty-four primary executables (safe, all 22 isolated features and all
features) and independently rebuilt safe/all repeats each retain 675 samples:
33 pairs, four compression modes and five samples, plus 15 setup-only batch
samples. Per-attempt compression clocks include all Global scratch
allocation/release; prefix-outside excludes rearming from the compression
clock while prefix-inside includes it, so each timed call is actually selected.
The setup-only observation clocks whole 4096-operation arm/observe/clear
batches; both armed and cleared states are black-box observable so
optimization cannot remove the assignment pair. That batch includes loop and
black-box overhead and is not a directly subtractable estimate of per-attempt
overhead. Immutable dictionary construction and caller destination setup stay
outside every clock.

Each executable retains 297 identical qualification rows across stateless,
persistent and prefix configurations. The original allocator owns one-block
staging; independent clones own workspace. A separate dictionary family
records construction/release with unchanged snapshots through every selected
call; these ledger counts are not timed scratch counts. Timed calls use
Global without the role router. Two fresh process observations gate each
campaign without claiming desktop idleness.

| Campaign | Backend | Mode | Reference | All nonempty pairs | Empty dictionary | Raw dictionary | Prepared dictionary |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |
"""
for x in s['comparisons']:
    if x['backend'] in ['safe', 'all'] and (x['numerator'] != x['denominator'] or x['backend'] == 'all'):
        values = [x['nonempty_geomean'], *[x['dictionary_geomeans'][k] for k in ['empty-dictionary', 'raw-dictionary', 'prepared-dictionary']]]
        report += f"| {x['campaign']} | {x['backend']} | {x['numerator']} | {x['reference_backend']} {x['denominator']} | " + ' | '.join(f'{v:.4f}' for v in values) + ' |\n'
report += """
Ratios are equal-weight geometric means of per-pair median latency ratios,
using 30 nonempty pairs overall and ten per dictionary kind. The three
empty-input pairs remain in raw data. Values below one mean lower observed
numerator latency on this host. Fixed order and five samples do not establish
statistical significance, a universal unsafe benefit or elimination of scratch
allocation. The coordinator claim is a borrow on the persistent path and a
small ownership move on the prefix path; ratios near one are consistent with
that machinery, not proof of zero cost. Setup-only batch medians are retained
separately in the evidence and are not subtracted from any compression clock.
All executables, source, fixture payloads, raw samples and barriers are
retained. Evidence: `evidence/2026-10-29-one-shot-encode-benchmarks.json`.
"""
(E / 'one-shot-encode-benchmarks.md').write_text(report)
