//! Fixed input/dictionary pairs compare the stateless borrowed-view baseline
//! with the call-scoped coordinator. Allocation ledgers are separate from
//! timing: caller destination setup and dictionary construction stay outside
//! every compression clock, while all codec scratch allocation and release is
//! timed. The setup-only batch clock includes loop and black-box overhead and
//! is not a directly subtractive estimate of per-attempt overhead.
use std::{
    alloc::{AllocError, Allocator, Global, Layout},
    hint::black_box,
    ptr::NonNull,
    sync::Arc,
    time::Instant,
};
use zstdoxide::{
    DecodeOptions, Dictionary, DictionaryView, OneShotEncoder, compress_into_with_dictionary_in,
    compress_with_dictionary_in, decompress_with_dictionary_in,
};
use zstdoxide_test_allocator::{AllocationSnapshot, AllocatorConfig, TrackingAllocator};

/// The original allocator routes to one-block staging; clones route to codec
/// workspace, each with an independent allocation identity. This routing
/// affects only clock-free qualification; timed calls use Global directly.
struct Roles {
    owner: TrackingAllocator,
    workspace: Arc<TrackingAllocator>,
}
impl Clone for Roles {
    fn clone(&self) -> Self {
        Self {
            owner: (*self.workspace).clone(),
            workspace: Arc::clone(&self.workspace),
        }
    }
}
// SAFETY: All allocation operations delegate unchanged to the exact owned
// TrackingAllocator. The owner moves with its blocks; cloning deliberately
// creates an independent identity, never a foreign deallocation handle. The
// shared workspace seed allocates nothing itself. TrackingAllocator provides
// valid aligned storage, initialization where requested and allocator lifetime
// guarantees. No pointer is cached or exposed beyond Allocator's contract.
unsafe impl Allocator for Roles {
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.owner.allocate(layout)
    }
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.owner.allocate_zeroed(layout)
    }
    /// # Safety
    /// ptr must be a live allocation from this exact owner's allocation domain;
    /// layout must fit it with valid alignment/size. Its lifetime ends here and
    /// no later alias may access it. Initialization is irrelevant to freeing.
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SAFETY: The caller supplies this exact owner's live block and fitting
        // layout with no later access; delegation changes no precondition.
        unsafe { self.owner.deallocate(ptr, layout) }
    }
    /// # Safety
    /// ptr must be live in this owner's domain and old must fit it; new has the
    /// requested valid alignment and no smaller size. The old block's aliases must not be
    /// used after success. Initialized bytes retain the underlying contract;
    /// the caller handles any uninitialized extension before reading it.
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old: Layout,
        new: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: The caller establishes domain, lifetime, fitting old layout,
        // valid new layout, growth direction and post-success alias invalidation.
        unsafe { self.owner.grow(ptr, old, new) }
    }
    /// # Safety
    /// Identical live-domain/layout/alignment/lifetime/alias requirements to
    /// grow; new is no smaller. Existing initialization is preserved and the
    /// underlying allocator zeroes the extension on successful growth.
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old: Layout,
        new: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: The caller satisfies grow's complete preconditions unchanged;
        // direct delegation preserves the additional zeroed-extension guarantee.
        unsafe { self.owner.grow_zeroed(ptr, old, new) }
    }
    /// # Safety
    /// ptr must be live in this owner's domain and old must fit it; new has the
    /// requested valid alignment and no larger size. After success no alias may use the
    /// former allocation. Initialization of the retained prefix is preserved.
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old: Layout,
        new: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: The caller establishes the exact allocation domain, fitting
        // old layout, valid new layout, shrink direction and invalidated aliases.
        unsafe { self.owner.shrink(ptr, old, new) }
    }
}
fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |h, &b| {
        (h ^ u64::from(b)).wrapping_mul(0x100000001b3)
    })
}
fn cases() -> Vec<(&'static str, Vec<u8>)> {
    let noise = |length| {
        let mut seed = 0x6a09e667u32;
        (0..length)
            .map(|_| {
                seed ^= seed << 13;
                seed ^= seed >> 17;
                seed ^= seed << 5;
                seed as u8
            })
            .collect()
    };
    let repeated = |length| {
        (0..length)
            .map(|i| b"caller owned output preserves deterministic block selection"[i % 59])
            .collect()
    };
    vec![
        ("empty", vec![]),
        ("tiny", b"abcde".to_vec()),
        ("size255", noise(255)),
        ("size256", noise(256)),
        ("size65791", repeated(65_791)),
        ("size65792", repeated(65_792)),
        ("raw-block", noise(131_072)),
        ("rle-block-plus", vec![0x5a; 131_073]),
        ("multi-block", repeated(393_233)),
        (
            "http",
            include_bytes!("../tests/upstream/data/golden-compression/http").to_vec(),
        ),
        (
            "large-lengths",
            include_bytes!(
                "../tests/upstream/data/golden-compression/large-literal-and-match-lengths"
            )
            .to_vec(),
        ),
    ]
}
fn row(name: &str, config: &str, role: &str, source: &[u8], frame: &[u8], s: AllocationSnapshot) {
    assert_eq!(s.live_blocks, 0);
    assert_eq!(s.identities_created, s.owners_dropped);
    assert!(!s.violations.any());
    println!(
        "{name}\t{config}\t{role}\t{}\t{:016x}\t{}\t{:016x}\t{}\t{}\t{}\t{}",
        source.len(),
        fingerprint(source),
        frame.len(),
        fingerprint(frame),
        s.attempts,
        s.requested_bytes,
        s.peak_bytes,
        s.deallocate_calls
    );
}
#[derive(Clone, Copy)]
enum DictionaryKind {
    Empty,
    Raw,
    Prepared,
}
impl DictionaryKind {
    fn name(self) -> &'static str {
        match self {
            Self::Empty => "empty-dictionary",
            Self::Raw => "raw-dictionary",
            Self::Prepared => "prepared-dictionary",
        }
    }
    fn build<A: Allocator + Clone>(self, owner: A) -> Dictionary<A> {
        match self {
            Self::Empty => Dictionary::raw_in(b"", owner).unwrap(),
            Self::Raw => Dictionary::raw_in(
                b"caller owned output preserves deterministic block selection",
                owner,
            )
            .unwrap(),
            Self::Prepared => Dictionary::from_bytes_in(
                include_bytes!("../tests/upstream/dictionaries/formatted.dict"),
                owner,
            )
            .unwrap(),
        }
    }
}
fn validate_frame(input: &[u8], output: &[u8], dictionary: DictionaryView<'_>) {
    let decoded =
        decompress_with_dictionary_in(output, &dictionary, DecodeOptions::new(input.len()), Global)
            .unwrap();
    assert_eq!(decoded, input);
}
fn check_output(output: &[u8], expected: &[u8]) {
    assert_eq!(&output[16..16 + expected.len()], expected);
    assert!(
        output[..16]
            .iter()
            .chain(&output[16 + expected.len()..])
            .all(|&b| b == 0xa5)
    );
}
/// Arm/clear batch size for the setup-only observation. A whole batch is one
/// clocked sample so scalar timer resolution cannot erase the pair cost.
const SETUP_BATCH: u32 = 4096;

fn main() {
    let command = std::env::args().nth(1).expect("qualify or measure");
    assert!(command == "qualify" || command == "measure");
    for kind in [
        DictionaryKind::Empty,
        DictionaryKind::Raw,
        DictionaryKind::Prepared,
    ] {
        // The immutable dictionary is built once outside every clock, and the
        // same borrowed view serves the stateless baseline and the coordinator.
        let dictionary = kind.build(Global);
        let view = dictionary.view();
        let dictionary_hash = fingerprint(dictionary.as_bytes());
        if command == "measure" {
            // Setup-only observation: a batch of arm/observe/clear pairs. Both
            // the armed and the cleared states are observable through
            // black_box, so optimization cannot dead-store-eliminate either
            // assignment of the borrowed-state pair. Loop and black-box
            // overhead is included and not subtractable from the per-attempt
            // compression clocks.
            let mut encoder = OneShotEncoder::with_prefix(view);
            let name = format!("{}-rearm-setup", kind.name());
            for sample in 0..5 {
                let start = Instant::now();
                for _ in 0..SETUP_BATCH {
                    encoder.set_prefix(Some(view));
                    black_box(encoder.prefix_pending());
                    encoder.set_prefix(None);
                    black_box(encoder.prefix_pending());
                }
                let elapsed = start.elapsed().as_nanos();
                assert!(!encoder.prefix_pending());
                assert!(encoder.dictionary().is_none());
                assert_eq!(fingerprint(dictionary.as_bytes()), dictionary_hash);
                println!("{name}\tsetup\t{sample}\t{SETUP_BATCH}\t{elapsed}");
            }
        }
        for (case, input) in cases() {
            let name = format!("{}-{case}", kind.name());
            let expected = compress_with_dictionary_in(&input, &view, Global).unwrap();
            validate_frame(&input, &expected, view);
            let mut output = vec![0xa5; expected.len() + 32];
            if command == "qualify" {
                for config in ["stateless", "persistent", "prefix"] {
                    let dictionary_owner =
                        TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                    let dictionary_monitor = dictionary_owner.monitor();
                    let tracked_dictionary = kind.build(dictionary_owner);
                    let dictionary_before = dictionary_monitor.snapshot();
                    assert_eq!(tracked_dictionary.as_bytes(), dictionary.as_bytes());
                    let tracked_view = tracked_dictionary.view();
                    let owner = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                    let owner_monitor = owner.monitor();
                    let workspace = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                    let workspace_monitor = workspace.monitor();
                    let roles = Roles {
                        owner,
                        workspace: Arc::new(workspace),
                    };
                    output.fill(0xa5);
                    match config {
                        "stateless" => {
                            assert_eq!(
                                compress_into_with_dictionary_in(
                                    &input,
                                    &mut output[16..16 + expected.len()],
                                    &tracked_view,
                                    roles
                                ),
                                Ok(expected.len())
                            );
                        }
                        "persistent" => {
                            let mut encoder = OneShotEncoder::with_dictionary(tracked_view);
                            assert!(!encoder.prefix_pending());
                            assert_eq!(
                                encoder.dictionary().unwrap().as_bytes(),
                                dictionary.as_bytes()
                            );
                            assert_eq!(
                                encoder.compress_into_in(
                                    &input,
                                    &mut output[16..16 + expected.len()],
                                    roles
                                ),
                                Ok(expected.len())
                            );
                            assert!(!encoder.prefix_pending());
                            assert!(encoder.dictionary().is_some());
                        }
                        "prefix" => {
                            let mut encoder = OneShotEncoder::with_prefix(tracked_view);
                            assert!(encoder.prefix_pending());
                            assert!(encoder.dictionary().is_some());
                            assert_eq!(
                                encoder.compress_into_in(
                                    &input,
                                    &mut output[16..16 + expected.len()],
                                    roles
                                ),
                                Ok(expected.len())
                            );
                            assert!(!encoder.prefix_pending());
                            assert!(encoder.dictionary().is_none());
                        }
                        _ => unreachable!("fixed configuration names"),
                    }
                    check_output(&output, &expected);
                    assert_eq!(owner_monitor.snapshot().live_blocks, 0);
                    assert!(owner_monitor.snapshot().peak_bytes <= 131_075);
                    workspace_monitor.assert_released();
                    assert_eq!(dictionary_monitor.snapshot(), dictionary_before);
                    assert_eq!(fingerprint(tracked_dictionary.as_bytes()), dictionary_hash);
                    drop(tracked_dictionary);
                    dictionary_monitor.assert_released();
                    owner_monitor.assert_released();
                    workspace_monitor.assert_released();
                    row(
                        &name,
                        config,
                        "staging",
                        &input,
                        &expected,
                        owner_monitor.snapshot(),
                    );
                    row(
                        &name,
                        config,
                        "workspace",
                        &input,
                        &expected,
                        workspace_monitor.snapshot(),
                    );
                    // This row records dictionary construction/release outside
                    // every clock; the unchanged snapshot equality above proves
                    // zero dictionary allocation activity during the selected
                    // compression call. It is not counted as scratch cost.
                    row(
                        &name,
                        config,
                        "dictionary",
                        &input,
                        &expected,
                        dictionary_monitor.snapshot(),
                    );
                }
                continue;
            }
            let iterations = (2 * 1024 * 1024 / (input.len() + 1)).clamp(8, 128);
            // Stateless baseline: the caller resolves selection by passing the
            // same borrowed view directly to the stateless encoder.
            for sample in 0..5 {
                let mut elapsed = 0u128;
                for _ in 0..iterations {
                    let start = Instant::now();
                    let size = black_box(
                        compress_into_with_dictionary_in(
                            black_box(&input),
                            black_box(&mut output[16..16 + expected.len()]),
                            black_box(&view),
                            Global,
                        )
                        .unwrap(),
                    );
                    black_box(size);
                    elapsed += start.elapsed().as_nanos();
                }
                check_output(&output, &expected);
                assert_eq!(fingerprint(dictionary.as_bytes()), dictionary_hash);
                println!("{name}\tstateless\t{sample}\t{iterations}\t{elapsed}");
            }
            // Persistent coordinator: selection survives every attempt.
            {
                let mut encoder = OneShotEncoder::with_dictionary(view);
                for sample in 0..5 {
                    let mut elapsed = 0u128;
                    for _ in 0..iterations {
                        let start = Instant::now();
                        let size = black_box(
                            encoder
                                .compress_into(
                                    black_box(&input),
                                    black_box(&mut output[16..16 + expected.len()]),
                                )
                                .unwrap(),
                        );
                        black_box(size);
                        elapsed += start.elapsed().as_nanos();
                    }
                    check_output(&output, &expected);
                    assert!(!encoder.prefix_pending());
                    assert!(encoder.dictionary().is_some());
                    assert_eq!(fingerprint(dictionary.as_bytes()), dictionary_hash);
                    println!("{name}\tpersistent\t{sample}\t{iterations}\t{elapsed}");
                }
            }
            // Prefix schedule with rearming outside the compression clock.
            // Every attempt is rearmed individually; no single setup covers a
            // batch of calls, so every timed call is actually selected.
            {
                let mut encoder = OneShotEncoder::with_prefix(view);
                for sample in 0..5 {
                    let mut elapsed = 0u128;
                    for _ in 0..iterations {
                        encoder.set_prefix(Some(view));
                        assert!(encoder.prefix_pending());
                        let start = Instant::now();
                        let size = black_box(
                            encoder
                                .compress_into(
                                    black_box(&input),
                                    black_box(&mut output[16..16 + expected.len()]),
                                )
                                .unwrap(),
                        );
                        black_box(size);
                        elapsed += start.elapsed().as_nanos();
                    }
                    check_output(&output, &expected);
                    assert!(!encoder.prefix_pending());
                    assert!(encoder.dictionary().is_none());
                    assert_eq!(fingerprint(dictionary.as_bytes()), dictionary_hash);
                    println!("{name}\tprefix-outside\t{sample}\t{iterations}\t{elapsed}");
                }
            }
            // Prefix schedule with rearming inside the compression clock.
            {
                let mut encoder = OneShotEncoder::with_prefix(view);
                for sample in 0..5 {
                    let mut elapsed = 0u128;
                    for _ in 0..iterations {
                        let start = Instant::now();
                        encoder.set_prefix(Some(view));
                        let size = black_box(
                            encoder
                                .compress_into(
                                    black_box(&input),
                                    black_box(&mut output[16..16 + expected.len()]),
                                )
                                .unwrap(),
                        );
                        black_box(size);
                        elapsed += start.elapsed().as_nanos();
                    }
                    check_output(&output, &expected);
                    assert!(!encoder.prefix_pending());
                    assert!(encoder.dictionary().is_none());
                    assert_eq!(fingerprint(dictionary.as_bytes()), dictionary_hash);
                    println!("{name}\tprefix-inside\t{sample}\t{iterations}\t{elapsed}");
                }
            }
        }
    }
}
