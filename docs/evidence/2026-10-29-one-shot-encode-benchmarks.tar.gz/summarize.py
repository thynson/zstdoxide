"""Summarize the module35 encode-selection measurements without overclaiming.

Per-case medians of per-operation nanoseconds for the four compression modes,
cross-mode and cross-backend geometric-mean ratios over the 30 nonempty pairs,
and separate setup-only batch observations whose loop/black-box overhead is
explicitly not subtractable from the per-attempt compression clocks.
"""
from pathlib import Path
import json, statistics, math, csv

D = Path(__file__).parent
MODES = ['stateless', 'persistent', 'prefix-outside', 'prefix-inside']
KINDS = ['empty-dictionary', 'raw-dictionary', 'prepared-dictionary']
records = []
setup = []
index = {}
comparisons = []
builds = json.loads((D / 'evidence.json').read_text())['builds']
for campaign, folder, names in [('primary', D, [r['name'] for r in builds]), ('repeat', D / 'repeat', ['safe', 'all'])]:
    assert json.loads((folder / 'timed.json').read_text())['status'] == 'passed'
    for name in names:
        groups = {}
        batches = {}
        for line in (folder / (name + '-timed.tsv')).read_text().splitlines():
            case, mode, sample, iterations, elapsed = line.split('\t')
            if mode == 'setup':
                batches.setdefault(case, []).append(int(elapsed))
            else:
                groups.setdefault((case, mode), []).append(int(elapsed) / int(iterations))
        for (case, mode), samples in groups.items():
            assert len(samples) == 5
            row = dict(campaign=campaign, backend=name, case=case, mode=mode, median_ns=statistics.median(samples), minimum_ns=min(samples), maximum_ns=max(samples))
            records.append(row)
            index[campaign, name, case, mode] = row['median_ns']
        for case, samples in batches.items():
            assert len(samples) == 5
            median = statistics.median(samples)
            setup.append(dict(campaign=campaign, backend=name, case=case, batch_size=4096, median_batch_ns=median, minimum_batch_ns=min(samples), maximum_batch_ns=max(samples), mean_pair_ns=median / 4096))
with (D / 'summary.csv').open('w') as f:
    w = csv.DictWriter(f, fieldnames=list(records[0]))
    w.writeheader()
    w.writerows(records)
cases = sorted({line.split('\t')[0] for line in (D / 'safe-qualify.tsv').read_text().splitlines()})
assert len(cases) == 33
gm = lambda v: math.exp(sum(math.log(x) for x in v) / len(v))
for campaign in ['primary', 'repeat']:
    for backend in (['safe', 'all'] if campaign == 'repeat' else [r['name'] for r in builds]):
        pairs = [(m, m, 'safe') for m in MODES] + [('persistent', 'stateless', backend), ('prefix-outside', 'stateless', backend), ('prefix-inside', 'stateless', backend), ('prefix-inside', 'prefix-outside', backend)]
        for numerator, denominator, reference in pairs:
            ratios = {case: index[campaign, backend, case, numerator] / index[campaign, reference, case, denominator] for case in cases}
            comparisons.append(dict(campaign=campaign, backend=backend, numerator=numerator, denominator=denominator, reference_backend=reference, ratios=ratios, nonempty_geomean=gm([v for k, v in ratios.items() if not k.endswith('-empty')])))
for row in comparisons:
    row['dictionary_geomeans'] = {}
    for kind in KINDS:
        values = [v for k, v in row['ratios'].items() if k.startswith(kind + '-') and not k.endswith('-empty')]
        assert len(values) == 10
        row['dictionary_geomeans'][kind] = gm(values)
(D / 'summary.json').write_text(json.dumps(dict(samples_per_row=5, unit='nanoseconds per operation for compression modes; nanoseconds per 4096-pair batch for setup observations', aggregation='Equal-weight geometric mean of per-pair median latency ratios over thirty nonempty dictionary/input pairs; the three empty-input pairs remain separate. All four compression modes include per-call Global codec scratch and write a caller destination prepared outside clocks; the stateless baseline receives the same borrowed view directly. Coordinator ratios isolate claim/selection machinery; prefix-outside excludes rearming from the compression clock while prefix-inside includes it, so their ratio bounds the rearm cost inside clocks. Setup-only observations time whole 4096-operation arm/observe/clear batches that include loop and black-box overhead and are not a directly subtractive estimate of per-attempt overhead. No confidence intervals or universal speedup claim.', rows=records, setup_observations=setup, comparisons=comparisons), indent=2) + '\n')
for a in comparisons:
    if a['backend'] in ['safe', 'all'] and (a['numerator'] != a['denominator'] or a['backend'] == 'all'):
        print(a['campaign'], a['backend'], a['numerator'], '/', a['denominator'], 'vs', a['reference_backend'], round(a['nonempty_geomean'], 4))
for s in setup:
    if s['backend'] in ['safe', 'all']:
        print(s['campaign'], s['backend'], s['case'], 'batch median', s['median_batch_ns'], 'ns (not subtractable)')
