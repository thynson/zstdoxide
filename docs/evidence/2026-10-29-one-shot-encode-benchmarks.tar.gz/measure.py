"""Time the module35 encode-selection benchmark only after every gate passes.

Validates the frozen source inventory, all 24 qualified executables with their
byte-identical 297-row ledgers, the completed 75-command final matrix, the
public/platform/native/corpus campaign sources, the harness checks and the CPU
barrier, then measures 675 rows per backend: 33 pairs times four compression
modes (stateless, persistent, prefix rearm outside, prefix rearm inside) times
five samples, plus 15 setup-only arm/observe/clear batch samples. A zero
elapsed sample rejects the campaign and is retained, never discarded.
"""
from pathlib import Path
import json, hashlib, subprocess, time, datetime, argparse, os, signal

D = Path(__file__).parent
S = Path('/private/tmp/module35-final')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
MODES = ['stateless', 'persistent', 'prefix-outside', 'prefix-inside']
KINDS = ['empty-dictionary', 'raw-dictionary', 'prepared-dictionary']


def validate():
    b = json.loads((D / 'evidence.json').read_text())
    assert b['status'] == 'qualified-not-timed' and len(b['builds']) == 24
    for n, h in b['source'].items():
        assert sha(D / 'source' / n) == h, ('benchmark snapshot', n)
    for n, h in b['production_source'].items():
        assert sha(S / n) == h, ('production', n)
    for row in b['builds']:
        assert sha(D / row['executable']) == row['sha256']
        assert (D / (row['name'] + '-qualify.tsv')).read_bytes() == (D / 'safe-qualify.tsv').read_bytes()
        assert sha(D / (row['name'] + '-qualify.tsv')) == row['qualification_sha256']
    gates = {}
    for label, path, count in [('matrix', 'module35-matrix/evidence.json', 75), ('public', 'module35-public/evidence.json', 21), ('platform', 'module35-platform/evidence.json', 11), ('native', 'module35-native/evidence.json', 15), ('corpus', 'module35-final-corpus/evidence.json', 10)]:
        p = Path('/private/tmp') / path
        j = json.loads(p.read_text())
        assert j['status'] == 'passed' and len(j['commands']) == count and all(c['exit_code'] == 0 for c in j['commands']), label
        for n, h in b['production_source'].items():
            assert j.get('production_source', j.get('source', {}))[n] == h, (label, n)
        gates[label] = sha(p)
    p = D / 'harness-check.json'
    j = json.loads(p.read_text())
    assert j['status'] == 'passed' and j['source_sha256'] == sha(D / 'source/benches/one_shot_encode.rs')
    gates['harness'] = sha(p)
    p = D / 'cpu-barrier.json'
    assert json.loads(p.read_text())['status'] == 'passed'
    gates['cpu-barrier'] = sha(p)
    return b, gates


def measure(repeat=False):
    b, gates = validate()
    folder = D / 'repeat' if repeat else D
    build = json.loads((folder / 'evidence.json').read_text())
    if repeat:
        assert build['status'] == 'qualified-not-timed' and len(build['builds']) == 2
        assert build['source_evidence_sha256'] == sha(D / 'evidence.json')
        assert json.loads((D / 'timed.json').read_text())['status'] == 'passed'
        assert json.loads((folder / 'cpu-barrier.json').read_text())['status'] == 'passed'
    assert not (folder / 'timed.json').exists()
    e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), gates=gates, build_evidence_sha256=sha(folder / 'evidence.json'), runs=[], qualification='Per-attempt compression clocks include every codec scratch allocation and release through Global. Stateless, persistent and both prefix schedules borrow the same immutable view and write the same caller destination prepared outside clocks; dictionary construction, full-byte/guard validation and role-routed allocation ledgers remain outside clocks. Prefix rearming is outside or inside the clock exactly as labeled; every attempt starts with the intended selection and ends consumed or persistent. The setup-only batch clock includes loop and black-box overhead and is not a directly subtractive estimate of per-attempt overhead. Equal timer overhead is retained; no universal unsafe benefit, allocator elimination or desktop idleness is claimed.')
    if repeat:
        e.update(primary_timing_sha256=sha(D / 'timed.json'), repeat_barrier_sha256=sha(folder / 'cpu-barrier.json'))

    def save():
        (folder / 'timed.json').write_text(json.dumps(e, indent=2) + '\n')

    save()
    deadline = datetime.datetime(2026, 10, 29, 9, 40, 0, tzinfo=datetime.timezone.utc).timestamp()
    try:
        cases = {l.split('\t')[0] for l in (D / 'safe-qualify.tsv').read_text().splitlines()}
        expected = {(c, m, i) for c in cases for m in MODES for i in range(5)} | {(k + '-rearm-setup', 'setup', i) for k in KINDS for i in range(5)}
        for row in build['builds']:
            assert sha(folder / row['executable']) == row['sha256']
            assert (folder / (row['name'] + '-qualify.tsv')).read_bytes() == (D / 'safe-qualify.tsv').read_bytes()
            remaining = deadline - time.time() - 30
            if remaining < 30:
                raise TimeoutError('User deadline before ' + row['name'])
            start = time.monotonic()
            p = subprocess.Popen([str(folder / row['executable']), 'measure'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            try:
                out, err = p.communicate(timeout=remaining)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGTERM)
                out, err = p.communicate()
                raise TimeoutError('User deadline during ' + row['name'])
            name = row['name']
            (folder / (name + '-timed.tsv')).write_bytes(out)
            (folder / (name + '-timed.stderr')).write_bytes(err)
            assert p.returncode == 0, (name, err)
            lines = out.decode().splitlines()
            assert len(lines) == 675
            seen = set()
            for line in lines:
                case, mode, sample, iterations, elapsed = line.split('\t')
                sample = int(sample)
                iterations = int(iterations)
                elapsed = int(elapsed)
                assert 0 <= sample < 5 and elapsed > 0, (name, line)
                if mode == 'setup':
                    assert case.endswith('-rearm-setup') and iterations == 4096, (name, line)
                else:
                    assert mode in MODES and 8 <= iterations <= 128, (name, line)
                key = (case, mode, sample)
                assert key not in seen
                seen.add(key)
            assert seen == expected
            e['runs'].append(dict(name=name, rows=len(lines), seconds=time.monotonic() - start, sha256=sha(folder / (name + '-timed.tsv')), executable_sha256=row['sha256']))
            save()
            print(('repeat ' if repeat else '') + name, '675 samples', flush=True)
        validate()
        e.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
    except BaseException as ex:
        e.update(status='failed', error=repr(ex))
        save()
        raise


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--repeat', action='store_true')
    p.add_argument('--validate-only', action='store_true')
    a = p.parse_args()
    if a.validate_only:
        validate()
        print('All source, executable, qualification and completed qualification gates verified')
    else:
        measure(a.repeat)
