from pathlib import Path
import hashlib,io,json,os,re,subprocess,tarfile,time
root=Path('/Users/lanxingcan/Workspace/zstdoxize');work=Path('/tmp/zstdoxide-fast-fixture-reader-checkpoint');work.mkdir();source=work/'source';source.mkdir();revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
paths=['src','tests','test-support','scripts','benches','Cargo.toml','Cargo.lock','rust-toolchain.toml','AGENTS.md']
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',revision,*paths],cwd=root))) as tar:tar.extractall(source,filter='data')
overlays=['src/lib.rs','tests/support/fast_oracle.rs','scripts/pack_fast_parser_fixtures.py','scripts/check.sh','scripts/check_upstream_oracles.sh','tests/fixtures/reference-fast/README.md','tests/fixtures/reference-fast/cases.bin','tests/fixtures/reference-fast/provenance.json']
for name in overlays:
 target=source/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/name).read_bytes())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest={p.relative_to(source).as_posix():sha(p) for p in sorted(source.rglob('*')) if p.is_file()}
features='unsafe-byte-cursor,unsafe-bitstream,unsafe-history,unsafe-ring-history,unsafe-fse,unsafe-fse-encoder,unsafe-huffman,unsafe-huffman-codebook,unsafe-match-table,unsafe-match-chain,unsafe-dictionary,unsafe-training'
commands=[]
for label,flags in [('safe',[]),('all',['--all-features']),('nostd-safe',['--no-default-features']),('nostd-all',['--no-default-features','--features',features])]:commands.append(('fixture-'+label,['cargo','test','--locked','--lib',*flags,'fast_oracle_fixture::'],4,{}))
for label,flags in [('safe',[]),('all',['--all-features'])]:commands.append(('clippy-'+label,['cargo','clippy','--locked','--all-targets',*flags,'--','-D','warnings'],None,{}))
commands.extend([('nostd-check',['cargo','check','--locked','--lib','--no-default-features'],None,{}),('format',['cargo','fmt','--all','--','--check'],None,{}),('pack',['python3','scripts/pack_fast_parser_fixtures.py','--check'],None,{}),('pack-optimized',['python3','-O','scripts/pack_fast_parser_fixtures.py','--check'],None,{})])
# Only the small scalar/count guard is interpreted cross-width. Full large static
# fixtures already replay natively; their repetition under Miri adds little here.
commands.append(('i686-count-guards',['cargo','+nightly-2026-10-08','miri','test','--offline','--locked','--lib','--target','i686-unknown-linux-gnu','fast_oracle_fixture::counts_are_checked_before_reservation_and_records_require_exact_ends','--','--exact'],1,{'MIRI_SYSROOT':'/tmp/zstdoxide-platform-sysroot-i686','MIRIFLAGS':'-Zmiri-strict-provenance'}))
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(work/'target')
report={'base_revision':revision,'scope':'Test-only packed reference observations and structurally checked Rust reader; no production parser implementation','source_manifest':manifest,'overlays':overlays,'compiler':subprocess.check_output(['rustc','-Vv'],cwd=source,text=True),'commands':[]}
for label,command,expected,override in commands:
 start=time.monotonic();r=subprocess.run(command,cwd=source,env=env|override,capture_output=True);raw=r.stdout+r.stderr;log=work/(label+'.log');log.write_bytes(raw);counts=[tuple(map(int,m)) for m in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)]
 report['commands'].append({'label':label,'command':command,'exit':r.returncode,'environment':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']}|override,'seconds':time.monotonic()-start,'log':log.name,'sha256':sha(log),'counts':counts});(work/'evidence.json').write_text(json.dumps(report,indent=2)+'\n');print(label,r.returncode,counts,flush=True)
 if r.returncode or expected is not None and counts!=[(expected,0,0)]:print(raw.decode()[-12000:]);raise SystemExit(1)
report['source_unchanged']=all(sha(source/name)==digest for name,digest in manifest.items());report['workspace_overlays_unchanged']=all(sha(source/name)==sha(root/name) for name in overlays)
assert report['source_unchanged'] and report['workspace_overlays_unchanged'];report['status']='passed';(work/'evidence.json').write_text(json.dumps(report,indent=2)+'\n');print('Frozen inputs unchanged',flush=True)
