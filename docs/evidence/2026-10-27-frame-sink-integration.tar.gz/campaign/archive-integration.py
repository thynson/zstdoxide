from pathlib import Path
import hashlib,json,tarfile,datetime
D=Path(__file__).parent;S=D/'source';E=Path('/private/tmp/module33-archives');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=json.loads((D/'integration.json').read_text());assert j['status']=='passed' and len(j['commands'])==7
for n,h in j['source'].items():assert sha(S/n)==h,n
for c in j['commands']:assert c['exit_code']==0 and sha(D/('integration-'+c['label']+'.log'))==c['log_sha256']
p=E/'2026-10-27-frame-sink-component.json';component=json.loads(p.read_text());assert component['status']=='passed' and sha(E/component['archive'])==component['archive_sha256'];assert sha(S/'src/frame_sink.rs')==component['source']['src/frame_sink.rs'];assert sha(S/'src/error.rs')==component['source']['src/error.rs']
files={'source/'+n:S/n for n in j['source']};files.update({'campaign/'+p.name:p for p in D.iterdir() if p.is_file() and (p.name.startswith('integration') or p.name in ['prepare-integration.py','check-integration.py','archive-integration.py'])})
name='2026-10-27-frame-sink-integration';archive=E/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
e=dict(status='passed',scope='focused-storage-integration-only',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=j['source'],production_source={n:h for n,h in j['source'].items() if n.startswith('src/')},component_receipt_sha256=sha(E/'2026-10-27-frame-sink-component.json'),component_archive_sha256=component['archive_sha256'],commands=j['commands'],members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()},archive=archive.name,archive_sha256=sha(archive),qualification=j['qualification']);(E/(name+'.json')).write_text(json.dumps(e,indent=2)+'\n');print(name,archive.stat().st_size)
