from pathlib import Path
import json,hashlib,os,subprocess,time,tomllib
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=json.loads((D/'integration-preparation.json').read_text());assert j['status']=='prepared';assert json.loads((D/'evidence.json').read_text())['status']=='passed'
for n,h in j['source'].items():assert sha(S/n)==h,n
features=sorted(f for f in tomllib.loads((S/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'));assert len(features)==22
e=dict(status='running',source=j['source'],component_receipt_sha256=sha(D/'evidence.json'),commands=[]);env={**os.environ,'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_TARGET_DIR':str(D/'integration-target')}
def save():(D/'integration.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 plan=[]
 for name,flags in [('safe',[]),('sink',['--features','unsafe-frame-sink']),('all',['--features',','.join(features)])]:
  plan.extend([(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*flags]),(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])])
 plan.append(('format',['cargo','fmt','--all','--','--check']))
 for label,args in plan:
  t=time.monotonic()
  with (D/('integration-'+label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/('integration-'+label+'.log'))));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
 for n,h in j['source'].items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='Seven full-codec compilation/lint/format commands in safe, isolated sink and all22-feature configurations. No full-codec test execution is inferred from Clippy. Exact leaf/error bytes already passed four tests per host/Miri backend and core-only concrete ARM checks in the separate15-command component receipt. Caller-owned compression framing/API and whole-module regression/timing remain open.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
