from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-helper-preflight')
sha=lambda b:hashlib.sha256(b).hexdigest();enc=lambda v:(json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
e=json.loads((O/'evidence.json').read_text());assert e['status']=='passed' and e['source_unchanged'] and len(e['commands'])==4 and len(e['dependencies'])==22
assert e['helper_sha256']==sha((R/'scripts/oracles/tree_direct_v1.c').read_bytes())
for c in e['commands']:assert c['exit_code']==0 and sha((O/c['log']).read_bytes())==c['sha256']
files={p.name:p.read_bytes() for p in O.iterdir() if p.is_file()}
for n in ['scripts/oracles/tree_direct_v1.c','docs/reference-tree-oracle.md']:files[n]=(R/n).read_bytes()
for n in ['zstdoxide-tree-helper-preflight.py','package-zstdoxide-tree-helper.py']:files['runners/'+n]=(Path('/tmp')/n).read_bytes()
files['manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in files.items()})
a=R/'docs/evidence/2026-10-13-tree-helper-review.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in files.items():
  i=tarfile.TarInfo('tree-helper/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:found={m.name:t.extractfile(m).read() for m in t}
assert found=={'tree-helper/'+n:b for n,b in files.items()}
e.update(archive=a.name,archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files));(R/'docs/evidence/2026-10-13-tree-helper-review.json').write_bytes(enc(e));print(a.stat().st_size)
