from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');U=Path('/private/tmp/zstdoxide-reference-lazy-1.5.7');O=Path('/tmp/zstdoxide-tree-helper-preflight');O.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
helper=R/'scripts/oracles/tree_direct_v1.c';before=sha(helper)
pins=json.loads(Path('/private/tmp/zstdoxide-lazy-public-2026-10-13/evidence.json').read_text())['upstream_source_sha256']
for n,h in pins.items():
 if sha(U/n)!=h:raise ValueError('pinned source changed '+n)
env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','TMPDIR','SDKROOT','MACOSX_DEPLOYMENT_TARGET','DEVELOPER_DIR']};env.update(LC_ALL='C',LANG='C',TZ='UTC')
base=['clang','-std=c99','-Wall','-Wextra','-Werror','-I',str(U/'lib')]
commands=[('compiler',['clang','--version']),('normal',base+['-fsyntax-only',str(helper)]),('instrumented',base+['-fsanitize=address,undefined','-fno-sanitize-recover=all','-fsyntax-only',str(helper)]),('dependencies',base+['-MM',str(helper)])]
records=[]
for name,args in commands:
 start=time.monotonic();p=O/(name+'.log')
 with p.open('xb') as f:r=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=60)
 records.append(dict(name=name,argv=args,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)))
 if r.returncode:raise ValueError(name)
text=(O/'dependencies.log').read_text().replace('\\\n',' ');dependencies={}
for name in text.split(':',1)[1].split():
 p=Path(name).resolve()
 if p==helper:continue
 relative=str(p.relative_to(U));h=sha(p)
 if pins.get(relative)!=h:raise ValueError('unreviewed dependency '+relative)
 dependencies[relative]=h
if sha(helper)!=before:raise ValueError('helper changed')
e=dict(status='passed',source_unchanged=True,helper_sha256=before,upstream_revision='f8745da6ff1ad1e7bab384bd1f9d742439278e99',dependencies=dependencies,environment=env,commands=records,scope='Syntax/dependency qualification only. The helper includes unchanged zstd_lazy.c and must replace that separate object at link time. No helper executable, codec search or observed tree result was run.')
(O/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n');print(len(dependencies))
