from pathlib import Path
from unittest.mock import patch
import contextlib,copy,hashlib,json,os,shutil,subprocess,sys,tempfile
repo=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(repo/'scripts'))
import check_lazy_family_capture as checker
source=Path('/tmp/zstdoxide-lazy-families-2026-10-12')
root=Path(tempfile.mkdtemp(prefix='zstdoxide-lazy-family-controls-',dir='/tmp')).resolve()
for name in ('evidence.json','recipes.json'):shutil.copyfile(source/name,root/name)
for name in ('logs','requests','c-normal','c-sanitized'):shutil.copytree(source/name,root/name)
original=(root/'evidence.json').read_bytes();base=json.loads(original)
results=[];calls=[]
def denied(*a,**kw):calls.append('process');raise RuntimeError('child process forbidden')
def reject(name,edit,undo=lambda:None):
 try:
  edit()
  try:checker.audit(root)
  except (ValueError,KeyError,TypeError,OSError) as error:
   results.append({'name': name, 'reason': str(error)})
   print('rejected: '+name, file=sys.stderr, flush=True)
  else:raise RuntimeError('accepted mutation: '+name)
 finally:
  undo();(root/'evidence.json').write_bytes(original)
def evidence(name,edit):
 def change():
  data=copy.deepcopy(base);edit(data);(root/'evidence.json').write_text(json.dumps(data))
 reject(name,change)
def log_change(name,label,edit):
 p=root/'logs'/(label+'.stdout');saved=p.read_bytes()
 def change():
  data=copy.deepcopy(base);rows=[json.loads(x) for x in saved.splitlines()];edit(rows)
  raw=b''.join((json.dumps(r,separators=(',',':'))+'\n').encode() for r in rows);p.write_bytes(raw)
  command=next(c for c in data['commands'] if c['label']==label)
  command['stdout'].update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
  (root/'evidence.json').write_text(json.dumps(data))
 reject(name,change,lambda:p.write_bytes(saved))
def coherent_control(name, case, expected_reason):
 labels=[mode+'-case-'+case for mode in ('normal','sanitized')]
 saved={label:(root/'logs'/(label+'.stdout')).read_bytes() for label in labels}
 def change():
  data=copy.deepcopy(base)
  for label in labels:
   rows=[json.loads(x) for x in saved[label].splitlines()]
   for row in rows[1:3]: row['final_entropy']=(row['final_entropy']+1)&0xffffffff
   raw=b''.join((json.dumps(r,separators=(',',':'))+'\n').encode() for r in rows)
   (root/'logs'/(label+'.stdout')).write_bytes(raw)
   next(c for c in data['commands'] if c['label']==label)['stdout'].update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
  (root/'evidence.json').write_text(json.dumps(data))
 def undo():
  for label,raw in saved.items():(root/'logs'/(label+'.stdout')).write_bytes(raw)
 reject(name,change,undo)
 if expected_reason not in results[-1]['reason']:raise RuntimeError('wrong rejection layer: '+str(results[-1]))

# Reuse independently checked immutable recipe/fixture inputs across capture-only
# mutations. The capture auditor, binary/log reads and semantic validators run
# afresh for each mutation; every cached source is checked before and afterward.
import check_lazy_family_recipes as recipe_checker
import check_lazy_tiny_fixture as tiny_fixture
import check_greedy_family_capture as greedy_fixture
cached_files={p:hashlib.sha256(p.read_bytes()).hexdigest() for pattern in
              ('scripts/**/*.py','tests/fixtures/reference-lazy*/**/*','tests/fixtures/reference-greedy*/**/*')
              for p in repo.glob(pattern) if p.is_file()}
def memo(function):
 values=[]
 def reused(*args):
  if not values:values.append(function(*args))
  return values[0]
 return reused

with contextlib.ExitStack() as stack:
 for module,name in [(subprocess,'Popen'),(os,'system'),(os,'posix_spawn'),(os,'posix_spawnp')]:
  if hasattr(module,name):stack.enter_context(patch.object(module,name,denied))
 for module, name in [(recipe_checker,'inputs'),(recipe_checker,'malformed_packets'),(tiny_fixture,'fixture'),(greedy_fixture,'fixture')]:
  stack.enter_context(patch.object(module,name,memo(getattr(module,name))))
 if checker.audit(root)['direct_observations']!=2580:raise RuntimeError('positive count')
 print('initial positive passed',file=sys.stderr,flush=True)
 evidence('incomplete-status',lambda e:e.update(status='failed'))
 evidence('boolean-schema',lambda e:e.update(schema_version=True))
 evidence('support-archive',lambda e:e.update(support_archive_used=True))
 evidence('hidden-sanitizer-exclusions',lambda e:e.update(upstream_sanitizer_annotations_retained=False))
 evidence('changed-source',lambda e:e['source_after'].update({'scripts/oracles/lazy_direct.c':'0'*64}))
 evidence('missing-instrumented-unit',lambda e:e['builds']['sanitized']['instrumented_codec_sources'].pop())
 evidence('disabled-helper-instrumentation',lambda e:e['builds']['sanitized'].update(helper_instrumented=False))
 evidence('missing-object',lambda e:e['builds']['normal']['objects'].pop('c-normal/unit-0.o'))
 evidence('missing-dependency',lambda e:e['builds']['normal']['dependencies'].pop(next(iter(e['builds']['normal']['dependencies']))))
 evidence('bool-total',lambda e:e['totals'].update(fresh_contexts=True))
 evidence('changed-context-peak',lambda e:e['context_peak_guarded_bytes']['normal'].update({'0':[1,1]}))
 evidence('missing-command',lambda e:e['commands'].pop())
 def argv(e):next(c for c in e['commands'] if c['label']=='sanitized-compile-0')['argv'].remove('-fsanitize=address,undefined')
 evidence('uninstrumented-compile',argv)
 def link(e):next(c for c in e['commands'] if c['label']=='normal-link')['argv'].insert(-2,'libzstd.a')
 evidence('archive-link',link)
 def escape(e):next(c for c in e['commands'] if c['label']=='normal-fresh-salt-0')['stdout']['path']='../escape'
 evidence('escaping-log',escape)
 log_change('changed-case-id','normal-case-d0-chain-fresh-7',lambda r:r[1].update(id='forged'))
 log_change('bool-frontier','normal-case-d0-chain-fresh-7',lambda r:r[1].update(final_next_to_update=True))
 log_change('huge-frontier','normal-case-d0-row-fresh-7',lambda r:r[1].update(final_next_to_update=2**63))
 log_change('changed-trailing','normal-case-d0-chain-fresh-7',lambda r:r[1].update(trailing_literals=6))
 log_change('changed-entropy','normal-case-d0-row-period-four',lambda r:r[1].update(final_entropy=(r[1]['final_entropy']+1)&0xffffffff))
 log_change('changed-table-fingerprint','normal-case-d0-row-period-four',lambda r:r[1]['first_table'].update(after_fnv1a64='0'*16))
 log_change('unknown-case-field','normal-case-d0-chain-fresh-7',lambda r:r[1].update(unknown=0))
 log_change('bad-cache','normal-case-d0-row-fresh-7',lambda r:r[1].update(hash_cache=[2**32]*8))
 log_change('bad-initial-map','normal-case-d0-chain-prefix-17',lambda r:r[1]['first_table'].update(before=[]))
 log_change('bad-raw-repeat','normal-case-d0-chain-period-four',lambda r:r[1].update(parser_repeats=[0,0,0]))
 log_change('bad-salt','normal-fresh-salt-0',lambda r:r[1].update(final_salt='0'*16))
 log_change('mode-qualified-peak-tamper','normal-fresh-salt-0',lambda r:[x.update(peak_guarded_bytes=x['peak_guarded_bytes']+1) for x in r[1:3]])
 log_change('bad-completion','normal-case-d0-chain-fresh-7',lambda r:r[3].update(success=False))
 extra=root/'logs/unexpected'
 reject('extra-log',lambda:extra.write_text('x'),lambda:extra.unlink())
 p=root/'requests/d0-chain-fresh-7.bin';saved=p.read_bytes()
 reject('changed-packet',lambda:p.write_bytes(saved[:-1]+bytes([saved[-1]^1])),lambda:p.write_bytes(saved))
 evidence('command-order',lambda e:e['commands'].reverse())
 evidence('duplicate-command-label',lambda e:e['commands'][1].update(label=e['commands'][0]['label']))
 evidence('extra-command-field',lambda e:e['commands'][0].update(extra=1))
 evidence('wrong-timeout',lambda e:e['commands'][0].update(timeout_seconds=121))
 evidence('hidden-environment',lambda e:e['environment'].update(LD_PRELOAD='unexpected'))
 evidence('sanitizer-recovery',lambda e:e['environment'].update(UBSAN_OPTIONS='halt_on_error=0'))
 evidence('changed-output-cap-accounting',lambda e:e['commands'][0]['stdout'].update(bytes=0))
 log_change('depth-boolean','normal-case-d1-chain-first-tail',lambda r:r[0].update(depth=True))
 log_change('wrong-strategy','normal-case-d1-chain-first-tail',lambda r:r[0].update(strategy=5))
 log_change('wrong-entry-point','normal-case-d2-row-second-tail',lambda r:r[0].update(entry_point='ZSTD_compressBlock_lazy_row'))
 log_change('wrong-case-depth','normal-case-d2-chain-first-tail',lambda r:r[1].update(depth=1))
 log_change('wrong-case-strategy','normal-case-d2-chain-first-tail',lambda r:r[1].update(strategy=4))
 log_change('wrong-completion-depth','normal-case-d1-chain-first-tail',lambda r:r[3].update(depth=0))
 log_change('wrong-salt-depth','normal-fresh-salt-2',lambda r:r[1].update(depth=1))
 log_change('wrong-salt-strategy','normal-fresh-salt-1',lambda r:r[1]['resolved'].__setitem__(6,3))
 for name in ['c-normal/lazy-direct','c-sanitized/unit-0.o']:
  p=root/name;saved=p.read_bytes()
  reject('missing-binary:'+name,lambda p=p:p.unlink(),lambda p=p,saved=saved:p.write_bytes(saved))
  reject('changed-binary:'+name,lambda p=p,saved=saved:p.write_bytes(saved+b'x'),lambda p=p,saved=saved:p.write_bytes(saved))
 p=root/'logs/normal-negative-depth-three.stderr';saved=p.read_bytes()
 def sanitizer():
  data=copy.deepcopy(base);raw=saved+b'AddressSanitizer: forged diagnostic\n';p.write_bytes(raw)
  next(c for c in data['commands'] if c['label']=='normal-negative-depth-three')['stderr'].update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
  (root/'evidence.json').write_text(json.dumps(data))
 reject('sanitizer-on-malformed-input',sanitizer,lambda:p.write_bytes(saved))
 coherent_control('coherent-tiny-both-modes-and-paddings','d1-row-period-four','unchanged complete tiny observation')
 coherent_control('coherent-predecessor-both-modes-and-paddings','d0-row-explicit-window-15','depth-zero predecessor semantics')
 if checker.audit(root)['direct_observations']!=2580:raise RuntimeError('restored positive')
if calls:raise RuntimeError('child creation attempted')
for p,digest in cached_files.items():
 if hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise RuntimeError('cached source changed: '+str(p))

print(json.dumps({'status':'passed','runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'positive':2,'qualification':'Immutable recipe and predecessor fixture results cached after real validation; source identities checked before/after. Each capture mutation reruns the full auditor and all log/binary/semantic checks.','rejected':len(results),'child_processes':len(calls),'optimized':not __debug__,'cases':results,'checker_sha256':hashlib.sha256((repo/'scripts/check_lazy_family_capture.py').read_bytes()).hexdigest()},sort_keys=True))
shutil.rmtree(root)
