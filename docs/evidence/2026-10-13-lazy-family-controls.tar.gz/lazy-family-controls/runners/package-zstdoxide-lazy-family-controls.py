from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';T=Path('/tmp')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def require(ok,msg):
 if not ok:raise ValueError(msg)
files={}
wip=json.loads((E/'2026-10-12-lazy-family-wip.json').read_bytes())
require(sha((E/wip['archive']).read_bytes())==wip['archive_sha256'],'original capture archive')
files['resume-verification.json']=(T/'zstdoxide-lazy-family-resume-verification.json').read_bytes()
require(json.loads(files['resume-verification.json'])['raw_capture_files_compared']==3698,'resume file count')
for mode in ('normal','optimized'):
 p=T/('zstdoxide-lazy-family-controls-'+mode+'.json');d=json.loads(p.read_bytes())
 require(d['status']=='passed' and (d['positive'],d['rejected'],d['child_processes'])==(2,52,0),'control results '+mode)
 require(d['optimized']==(mode=='optimized'),'mode')
 require(d['runner_sha256']==sha((T/'zstdoxide-lazy-family-capture-controls.py').read_bytes()),'runner identity')
 files['controls-'+mode+'.json']=p.read_bytes()
 files['controls-'+mode+'.stderr']=(T/('zstdoxide-lazy-family-controls-'+mode+'.stderr')).read_bytes()
for name in ('zstdoxide-lazy-family-capture-controls.py','package-zstdoxide-lazy-family-controls.py'):files['runners/'+name]=(T/name).read_bytes()
for name in ('scripts/check_lazy_family_capture.py','scripts/check_lazy_family_recipes.py','docs/evidence/2026-10-12-lazy-family-wip.json'):files['source/'+name]=(R/name).read_bytes()
report=dict(date='2026-10-13',status='passed',capture_archive=wip['archive'],capture_archive_sha256=wip['archive_sha256'],capture_report_sha256=sha((E/'2026-10-12-lazy-family-wip.json').read_bytes()),capture_evidence_sha256=wip['capture_evidence_sha256'],commands=1468,totals=wip['totals'],controls_per_mode=dict(positive=2,rejected=52,child_processes=0),modes=['normal','optimized'],raw_capture_files_compared=3698,manifest_members_verified=3702,qualification='Capture qualification only. Immutable recipe and predecessor fixture results are cached after real validation, with their source identities rechecked before/after; every mutation reruns the capture auditor, log/binary reads and semantic checks. Two coherent controls change both builds and both paddings with refreshed local hashes and require rejection at the tiny/predecessor comparison layer. Score-family reconciliation, permanent fixtures, Rust projection and Lazy implementation remain open. No new C execution or chronological probe trace claim.',interrupted_attempts='Two initial uncached task-owned control runs were stopped before completion to avoid repeatedly rebuilding immutable inputs. No capture, helper or auditor changed; complete normal/optimized runs use the archived successor driver.',archive='2026-10-13-lazy-family-controls.tar.gz')
files['review.json']=enc(report)
files['bundle-manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())})
a=E/report['archive'];require(not a.exists(),'fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('lazy-family-controls/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a,'r|gz') as t:
 observed={m.name:t.extractfile(m).read() for m in t}
require(observed=={'lazy-family-controls/'+n:b for n,b in files.items()},'exact archive contents')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files))
(E/'2026-10-13-lazy-family-controls.json').write_bytes(enc(report));print(json.dumps(report,sort_keys=True))
