from pathlib import Path
import hashlib,json,tarfile,subprocess,sys
root=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(root/'scripts'));import check_double_fast_families as check
parent=Path('/tmp/zstdoxide-double-fast-families-initial-2026-10-12');refined=Path('/tmp/zstdoxide-double-fast-refinement-2026-10-12')
controls=[Path('/tmp/zstdoxide-double-fast-family-controls-'+m) for m in ('normal','optimized')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,why):
 if not ok:raise ValueError(why)
e=json.loads((parent/'evidence.json').read_text());r=json.loads((refined/'evidence.json').read_text())
require(e['status']==r['status']=='passed' and len(e['commands'])==343 and len(r['commands'])==2,'capture completeness')
require(e['source_before']==e['source_after'] and r['source_before']==r['source_after'],'source identity snapshots')
for item in e['source_before']:
 p=Path(item['path']);require(p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],'parent input identity')
for p,digest in r['source_before'].items():require(sha(Path(p))==digest,'refinement input identity')
for directory,evidence in ((parent,e),(refined,r)):
 for command in evidence['commands']:
  require(command.get('exit_code')==0 and 'error' not in command,'capture failure')
  for stream in ('stdout','stderr'):
   item=command[stream];p=directory/item['path'];require(sha(p)==item['sha256'] and p.stat().st_size==item['bytes'],'capture log identity')
for case in e['results']['normal']['cases']:
 name='normal-'+case['id']+'.stdout';require(sha(parent/name)==case['stdout_sha256']==sha(check.COLLECTION/name),'frozen base observation')
 require((parent/name).read_bytes()==(parent/('sanitized-'+case['id']+'.stdout')).read_bytes(),'complete build equality')
require((refined/'normal.stdout').read_bytes()==(refined/'sanitized.stdout').read_bytes()==(check.COLLECTION/'normal-long-literal-extended-tail.stdout').read_bytes(),'refinement output identity')
control_summaries=[]
for directory in controls:
 record=json.loads((directory/'results.json').read_text());require(record['status']=='passed' and record['positive']==2 and record['rejected']==32,'control results')
 control_summaries.append({'optimized':record['optimized'],'positive':2,'rejected':32,'report_sha256':sha(directory/'results.json')})
files={}
for directory,prefix in [(parent,'capture'),(refined,'refinement'),*[(d,'controls/'+m) for d,m in zip(controls,('normal','optimized'))]]:
 for p in directory.rglob('*'):
  if p.is_file() and p.name not in ('double-fast-families-normal','double-fast-families-sanitized') and not any(part.endswith('.dSYM') for part in p.parts):files[prefix+'/'+p.relative_to(directory).as_posix()]=p
sources=sorted(set(check.PINS)|{'scripts/check_double_fast_families.py','scripts/check.sh','scripts/check_upstream_oracles.sh','scripts/check_upstream_fixtures.py','docs/reference-double-fast-families.md','docs/reference-double-fast-validation.md','TODO.md'})
for name in sources:files['repository/'+name]=root/name
for directory in (check.COLLECTION,root/'tests/fixtures/reference-double-fast-recipes'):
 for p in directory.iterdir():files['repository/'+p.relative_to(root).as_posix()]=p
for name in ['capture-zstdoxide-double-fast-refinement.py','check-zstdoxide-double-fast-family-controls.py','package-zstdoxide-double-fast-families.py']:files['tools/'+name]=Path('/tmp')/name
out=root/'docs/evidence/2026-10-12-double-fast-families.tar.gz'
with tarfile.open(out,'w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname='double-fast-families/'+name,recursive=False)
with tarfile.open(out,'r:gz') as tar:
 require(len(tar.getmembers())==len(files),'archive cardinality')
 for member in tar.getmembers():require(member.isfile() and hashlib.sha256(tar.extractfile(member).read()).hexdigest()==sha(files[member.name.removeprefix('double-fast-families/')]),'archive member identity')
manifest=json.loads((check.COLLECTION/'manifest.json').read_text())
summary={'schema_version':1,'status':'passed','date':'2026-10-12','git_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':e['scope'],'original_recipes':168,'separately_frozen_refinements':1,'recipes':169,'padding_observations_per_build':338,'C_padding_case_executions':676,'capture_commands':345,'capture_evidence_sha256':sha(parent/'evidence.json'),'refinement_evidence_sha256':sha(refined/'evidence.json'),'normal_sanitized_equal':True,'source_before_after_equal':True,'compiler':e['compiler'],'compiler_sha256':e['compiler_sha256'],'reference_revision':e['reference_revision'],'source_sha256':e['source_sha256'],'support_archive_sha256':e['support_archive_sha256'],'instrumentation':e['instrumentation'],'family_review':manifest['capture']['family_review'],'controls':control_summaries,'offline_normal_and_optimized':'passed','fixture_registry_normal_and_optimized':{'status':'passed','files':715,'collections':19},'diff_whitespace':'passed','new_rust_parser_or_production_change':False,'fixture_catalog_sha256':check.CATALOG_SHA256,'repository_source_sha256':{name:sha(root/name) for name in sources},'archive':{'path':out.relative_to(root).as_posix(),'bytes':out.stat().st_size,'sha256':sha(out),'members':len(files),'exclusions':'Compiled C executables/debug bundles (binary hashes retained) and external pinned C sources (full recorded source/header catalog retained).'}}
(root/'docs/evidence/2026-10-12-double-fast-families.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps({'archive':summary['archive'],'commands':345,'executions':676,'controls':control_summaries},indent=2))
