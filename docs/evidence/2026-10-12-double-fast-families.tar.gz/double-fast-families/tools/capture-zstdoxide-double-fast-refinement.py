from pathlib import Path
from dataclasses import replace
import hashlib,json,os,sys,traceback
root=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(root/'scripts'))
import check_double_fast_recipes as recipes
families=recipes.load_families();oracle=families.direct
require=oracle.require
require(oracle.sha(root/'scripts/capture_double_fast_tiny.py')=='5dea723222db1171e6302411d4d59870e01a09dfd7df74bf47c51cc6978bef19','bounded runner identity')
import capture_double_fast_tiny as bounded
parent=Path('/tmp/zstdoxide-double-fast-families-initial-2026-10-12');out=Path('/tmp/zstdoxide-double-fast-refinement-2026-10-12')
require(not out.exists() and bounded.disjoint(out,root) and bounded.disjoint(out,parent),'fresh disjoint output')
manifest=root/'tests/fixtures/reference-double-fast-recipes/refinement-long-literal.json'
require(oracle.sha(manifest)=='db2009c5cbadde7d7f244ff2f46eed879005ed0fba3379258bff4122f8c2acf2','pre-execution refinement identity')
record=oracle.decode_json(manifest.read_bytes());base=next(c.recipe for c in recipes.check_manifest(recipes.MANIFEST) if c.recipe.name==record['base_case'])
case=replace(base,name='long-literal-extended-tail',source=base.source+b'A'*896)
require(oracle.exact(case.metadata(),record['recipe']),'exact refinement recipe')
parent_evidence=oracle.decode_json((parent/'evidence.json').read_bytes());require(parent_evidence['status']=='passed','parent capture complete')
for row in parent_evidence['source_after']:
 p=Path(row['path']);require(p.stat().st_size==row['bytes'] and oracle.sha(p)==row['sha256'],'parent source retained')
inputs=[manifest,recipes.MANIFEST,Path(__file__),parent/'evidence.json',*[Path(r['path']) for r in parent_evidence['source_after']]]
for mode in ('normal','sanitized'):
 exe=parent/('double-fast-families-'+mode);require(oracle.sha(exe)==parent_evidence['results'][mode]['executable_sha256'],'same compiled helper/parser');inputs.append(exe)
def state():return {str(p):oracle.sha(p) for p in inputs}
before=state();out.mkdir();packet=out/'refinement.packet';packet.write_bytes(case.packet());e={'status':'running','schema_version':1,'parent_evidence_sha256':oracle.sha(parent/'evidence.json'),'parent_capture':str(parent),'recipe_manifest_sha256':oracle.sha(manifest),'source_before':before,'commands':[],'recipe':case.metadata(),'scope':'One separately frozen tail-extension refinement; original zero-match candidate remains unchanged.'}
def save():(out/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
env={'PATH':os.environ.get('PATH',os.defpath),'LANG':'C','LC_ALL':'C'};save()
try:
 for mode in ('normal','sanitized'):
  require(state()==before,'input state before run')
  extra={'ASAN_OPTIONS':'halt_on_error=1:detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'} if mode=='sanitized' else {}
  command=bounded.run_command([str(parent/('double-fast-families-'+mode)),str(packet)],out,mode,env|extra);e['commands'].append(command);save()
  require(command.get('exit_code')==0 and 'error' not in command,'reference refinement failed')
  require(command['stderr']['bytes']==0,'unexpected sanitizer/helper diagnostic')
  rows=oracle.validate(case,out/(mode+'.stdout'))
  require(rows[1]['long_length_type']==1,'refinement has not observed a long literal marker')
  if mode=='sanitized':require((out/'normal.stdout').read_bytes()==(out/'sanitized.stdout').read_bytes(),'complete build equality')
  require(state()==before,'input state after run')
  e['observation_summary']={'sequences':rows[1]['sequences'],'long_length_type':rows[1]['long_length_type'],'long_length_position':rows[1]['long_length_position'],'trailing_literals':rows[1]['trailing_literals']};save()
 e['source_after']=state();e['status']='passed';save();print(json.dumps(e['observation_summary'],indent=2))
except BaseException:
 e['status']='failed';e['failure']=traceback.format_exc();save();raise
