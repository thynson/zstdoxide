from pathlib import Path
import copy,json,sys,hashlib,shutil
root=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(root/'scripts'))
import check_double_fast_families as check
out=Path(sys.argv[1]);out.mkdir();oracle,cases=check.load_cases();byname={r.name:r for r in cases};rows=[]
def reject(label,call):
 try:call()
 except (ValueError,KeyError,TypeError,OSError) as error:rows.append({'label':label,'rejected':True,'diagnostic':str(error)});return
 raise ValueError('accepted '+label)
# Reuse previously validated complete captures for isolated witness controls;
# the separate whole-collection checks replay every record in both Python modes.
records={r.name:oracle.decode_json((check.COLLECTION/('normal-'+r.name+'.stdout')).read_bytes().splitlines()[1]) for r in cases}
review=check.review(oracle,cases,records);rows.append({'label':'positive-isolated-witnesses','passed':True,'equivalences':len(review['equivalence_pairs']),'sequence_witnesses':len(review['sequence_witnesses'])})
base=oracle.validate(byname['long-literal-extended-tail'],check.COLLECTION/'normal-long-literal-extended-tail.stdout');rows.append({'label':'positive-refined-long-literal','passed':True})
mutations={
 'raw-long-ll':lambda r:r[1]['sequences'][0].update(raw_ll=17),
 'long-kind':lambda r:r[1].update(long_length_type=2),
 'long-position':lambda r:r[1].update(long_length_position=1),
 'expanded-ll':lambda r:r[1]['sequences'][0].update(ll=18),
 'raw-match-base':lambda r:r[1]['sequences'][0].update(raw_ml_base=62),
 'stored-literal-size':lambda r:r[1].update(stored_literal_bytes=18),
 'wrong-literal-byte':lambda r:r[1].update(stored_literals_hex='ff'+r[1]['stored_literals_hex'][2:]),
 'invalid-overlap-distance':lambda r:r[1]['sequences'][1].update(distance=0),
 'wrong-repeat-intent':lambda r:r[1]['sequences'][1].update(intent='repeat'),
 'raw-third-replaced':lambda r:r[1].update(parser_repeats=r[1]['wire_repeats']),
 'bool-count':lambda r:r[1].update(sequence_count=True),
 'schema-boolean':lambda r:r[0].update(schema_version=True),
 'floor-change':lambda r:r[1].update(prefix_floor=1),
 'seed-order':lambda r:r[1].update(long_seeds=[1]),
 'unknown-id':lambda r:r[1].update(id='unknown'),
 'missing-table-cell':lambda r:r[1]['long_table']['changes'].pop(),
 'wrong-old-cell':lambda r:r[1]['short_table']['changes'][0].__setitem__(1,999),
 'final-hash':lambda r:r[1]['long_table'].update(after_le32_fnv1a64='0'*16),
 'reverse-padding':lambda r:r[2].update(padding=106),
 'missing-completion':lambda r:r.pop(),
 'extra-record':lambda r:r.append(r[-1]),
}
for name,mutation in mutations.items():
 changed=copy.deepcopy(base);mutation(changed);p=out/(name+'.ndjson');p.write_text(''.join(json.dumps(row)+'\n' for row in changed));reject('record-'+name,lambda p=p:oracle.validate(byname['long-literal-extended-tail'],p))
for name in ['conditional-store-step3','conditional-store-step4','lookahead-length-12','current-long-priority-seeded','adjacent-long-control','repeats-loop-available','repeat-bound-1025','floor-short-540','long-literal-candidate']:
 changed=copy.deepcopy(records)
 if changed[name]['sequences']:changed[name]['sequences'][0]['ll']+=1
 else:changed[name]['sequences']=[{'ll':0,'ml':4,'distance':1,'off_base':1}]
 reject('witness-'+name,lambda changed=changed:check.review(oracle,cases,changed))
changed=copy.deepcopy(records);changed['width-period-m3-w18']['trailing_literals']+=1
reject('whole-equivalence',lambda:check.review(oracle,cases,changed))
# Repairing a local catalog does not alter the independently pinned observations.
destination=out/'forged';shutil.copytree(check.COLLECTION,destination)
p=destination/'normal-long-literal-candidate.stdout';text=p.read_text().replace('"trailing_literals":65664','"trailing_literals":0');oracle.require(text!=p.read_text(),'forgery changes bytes');p.write_text(text)
m=json.loads((destination/'manifest.json').read_text())
for item in m['fixtures']:
 f=destination/item['path'];item.update(size=f.stat().st_size,sha256=oracle.sha(f))
m['fixture_catalog_sha256']=hashlib.sha256(json.dumps(m['fixtures'],sort_keys=True,separators=(',',':')).encode()).hexdigest();(destination/'manifest.json').write_text(json.dumps(m))
reject('repaired-catalog',lambda:check.check(destination))
report={'status':'passed','optimized':sys.flags.optimize,'positive':sum(r.get('passed',False) for r in rows),'rejected':sum(r.get('rejected',False) for r in rows),'controls':rows,'script_sha256':oracle.sha(Path(__file__))}
(out/'results.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('status','optimized','positive','rejected')}))
