from pathlib import Path
import argparse,hashlib,json,os,sys,shutil,traceback,csv,io
p=argparse.ArgumentParser();p.add_argument('--upstream',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path.cwd().resolve();upstream=a.upstream.resolve();out=a.output.resolve()
sys.path.insert(0,str(root/'scripts'));import check_double_fast_tiny as pins
oracle=pins.load_oracle() # verifies the shared frozen command runner before import
import capture_double_fast_tiny as bounded
require=oracle.require
for protected in (root,upstream):require(bounded.disjoint(out,protected),'protected destination')
require(not out.exists(),'fresh destination')
manifest=oracle.decode_json((root/'tests/upstream/manifest.json').read_bytes())
require(manifest['upstream']['revision']==oracle.REVISION,'revision')
sources={row['path']:row['sha256'] for row in manifest['sources']+manifest['excluded_sources'] if row['path'].startswith('lib/') and Path(row['path']).suffix in ('.c','.h')}
for name,digest in sources.items():require(oracle.sha(upstream/name)==digest,'reference source '+name)
helper=root/'scripts/oracles/double_fast_hashes.c';patterns=root/'tests/upstream/match-search/patterns.bin';prior=root/'tests/upstream/match-search/vectors.tsv'
require(oracle.sha(patterns)=='1081bb9bf9f8165786c86c63c227ad9e7450c0a87a83dd4645a3bddac6771ac3','frozen patterns')
require(oracle.sha(prior)=='628ff9df0d3b6c972233c43e5ffbc4aa11a1445908054c5d30da47b3afd078ce','frozen old vectors')
inputs=[Path(__file__),helper,patterns,prior,root/'scripts/oracles/double_fast_direct.py',root/'scripts/capture_double_fast_tiny.py',root/'scripts/check_double_fast_tiny.py',*[upstream/name for name in sources]]
def state():return {str(p):oracle.sha(p) for p in inputs}
before=state();out.mkdir(parents=True)
e={'status':'running','schema_version':1,'source_before':before,'source_sha256':sources,'reference_revision':oracle.REVISION,'commands':[],'results':{},'scope':'512 inline hash observations per build; no parser, codec or archive linkage.'}
def save():(out/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
env={'PATH':os.environ.get('PATH',os.defpath),'LANG':'C','LC_ALL':'C'}
if 'TMPDIR' in os.environ:env['TMPDIR']=os.environ['TMPDIR']
def command(label,argv,extra=None):
 require(state()==before,'source changed before command')
 row=bounded.run_command(argv,out,label,env|(extra or {}));e['commands'].append(row);save()
 require(row.get('exit_code')==0 and 'error' not in row,'command '+label)
 require(state()==before,'source changed after command');return out/row['stdout']['path']
cc=Path(shutil.which('clang')).resolve();e['compiler']=str(cc);e['compiler_sha256']=oracle.sha(cc);save()
try:
 require(command('revision',['git','-C',str(upstream),'rev-parse','HEAD']).read_text().strip()==oracle.REVISION,'git revision')
 require(command('status',['git','-C',str(upstream),'status','--porcelain']).read_bytes()==b'','clean reference')
 command('compiler',[str(cc),'--version'])
 expected_old={(int(r['log']),int(r['pattern'])):int(r['bucket']) for r in csv.DictReader(io.StringIO(prior.read_text()),delimiter='\t') if r['width']=='8'}
 for mode in ('normal','sanitized'):
  exe=out/('hash-'+mode);options=['-O2'] if mode=='normal' else ['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer']
  args=[str(cc),'-std=c11','-Wall','-Wextra','-Werror','-I',str(upstream/'lib'),'-I',str(upstream/'lib/common'),'-I',str(upstream/'lib/compress'),*options]
  command(mode+'-dependencies',args+['-MM',str(helper)])
  command(mode+'-compile',args+[str(helper),'-o',str(exe)])
  extra={'ASAN_OPTIONS':'halt_on_error=1:detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'} if mode=='sanitized' else {}
  path=command(mode+'-vectors',[str(exe),str(patterns)],extra)
  require((out/(mode+'-vectors.stderr')).read_bytes()==b'','no sanitizer diagnostic')
  reader=csv.DictReader(io.StringIO(path.read_text()),delimiter='\t');require(reader.fieldnames==['log','shift','pattern','bytes','bucket'],'TSV schema');rows=list(reader);require(len(rows)==512,'row count')
  for i,row in enumerate(rows):
   log=6+i//128;shift=(i//64)%2;pattern=i%64;key=patterns.read_bytes()[pattern*8:pattern*8+8]
   require([row[k] for k in ('log','shift','pattern','bytes')]==[str(log),str(shift),str(pattern),key.hex()],'exact row identity')
   observed=int(row['bucket']);require(str(observed)==row['bucket'] and observed==oracle.bucket(key,log)==expected_old[10,pattern]>>(10-log),'direct mathematical/prior agreement')
  e['results'][mode]={'rows':512,'executable_sha256':oracle.sha(exe),'vectors_sha256':oracle.sha(path)};save()
 require((out/'normal-vectors.stdout').read_bytes()==(out/'sanitized-vectors.stdout').read_bytes(),'complete build equality')
 e['source_after']=state();require(e['source_after']==before,'source unchanged')
 e['status']='passed';e['instrumentation']={'inline_hash_and_helper':True,'archive_linked':False,'leak_sanitizer':False};save();print(json.dumps(e['results'],indent=2))
except BaseException:
 e['status']='failed';e['failure']=traceback.format_exc();save();raise
