from pathlib import Path
import json,sys,shutil,os
root=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(root/'scripts'))
import check_double_fast_hashes as check
import capture_double_fast_tiny as bounded
out=Path(sys.argv[1]);out.mkdir();rows=[]
def require(ok,why):
 if not ok:raise ValueError(why)
def rejected(label,call):
 try:call()
 except (ValueError,KeyError,TypeError,OSError) as e:rows.append({'label':label,'rejected':True,'diagnostic':str(e)});return
 raise ValueError('accepted '+label)
check.check(check.COLLECTION);rows.append({'label':'positive-fixture','passed':True})
base=(check.COLLECTION/'vectors.tsv').read_bytes();lines=base.decode().splitlines()
changes={'missing-row':lines[:-1],'extra-row':lines+[lines[-1]],'wrong-header':['width\tshift\tpattern\tbytes\tbucket']+lines[1:],'swapped':lines[:1]+[lines[2],lines[1]]+lines[3:]}
for field,value in [(0,'5'),(0,'06'),(1,'2'),(1,'false'),(2,'64'),(3,'0'*15),(3,'f'*16),(4,'99999'),(4,'00'),(4,'true')]:
 modified=lines.copy();cells=modified[1].split('\t');cells[field]=value;modified[1]='\t'.join(cells);changes[f'field-{field}-{value}']=modified
changes['extra-column']=[lines[0],lines[1]+'\t0']+lines[2:]
for label,data in changes.items():
 encoded=('\n'.join(data)+'\n').encode();(out/(label+'.tsv')).write_bytes(encoded);rejected(label,lambda encoded=encoded:check.validate_vectors(encoded))
for label,data in [('duplicate','{"a":1,"a":2}'),('nan','{"a":NaN}'),('infinity','{"a":Infinity}')]:rejected(label,lambda data=data:check.decode(data))
for label,mutate in [('bool-schema',lambda m:m.update(schema_version=True)),('false-scope',lambda m:m['coverage'].update(inline_hash_only=False)),('forged-source',lambda m:m['source_sha256'].update({'lib/zstd.h':'0'*64}))]:
 directory=out/label;shutil.copytree(check.COLLECTION,directory);m=json.loads((directory/'manifest.json').read_text());mutate(m);(directory/'manifest.json').write_text(json.dumps(m));rejected(label,lambda directory=directory:check.check(directory))
directory=out/'repaired-forgery';shutil.copytree(check.COLLECTION,directory);p=directory/'vectors.tsv';p.write_bytes(base.replace(b'\t0\n',b'\t1\n',1));m=json.loads((directory/'manifest.json').read_text());m['fixtures'][0].update(size=p.stat().st_size,sha256=check.sha(p));(directory/'manifest.json').write_text(json.dumps(m));rejected('repaired-forgery',lambda:check.check(directory))
# Bounds are checked before TSV output. Both executables reject malformed input.
for size in (0,511,513):(out/f'patterns-{size}.bin').write_bytes(b'\0'*size)
env={'PATH':os.environ.get('PATH',os.defpath),'LC_ALL':'C','LANG':'C'}
for mode in ('normal','sanitized'):
 for size in (0,511,513):
  label=f'{mode}-size-{size}';extra={'ASAN_OPTIONS':'halt_on_error=1:detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'} if mode=='sanitized' else {}
  command=bounded.run_command([f'/tmp/zstdoxide-double-fast-hashes-2026-10-12/hash-{mode}',str(out/f'patterns-{size}.bin')],out,label,env|extra)
  require(command.get('exit_code')==1 and 'error' not in command,label)
  require(command['stdout']['bytes']==0 and (out/command['stderr']['path']).read_text().startswith('double-fast hash oracle: exact regular 512-byte pattern file'),label+' before observation')
  rows.append({'label':label,'rejected':True,'command':command})
report={'status':'passed','optimized':sys.flags.optimize,'positive':sum(r.get('passed',False) for r in rows),'rejected':sum(r.get('rejected',False) for r in rows),'controls':rows,'script_sha256':check.sha(Path(__file__))}
(out/'results.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('status','optimized','positive','rejected')}))
