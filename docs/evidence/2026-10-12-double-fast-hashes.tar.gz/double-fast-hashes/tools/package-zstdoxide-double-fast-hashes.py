from pathlib import Path
import hashlib,json,re,tarfile,subprocess
root=Path('/Users/lanxingcan/Workspace/zstdoxize');capture=Path('/tmp/zstdoxide-double-fast-hashes-2026-10-12');rust=Path('/tmp/zstdoxide-double-fast-hash-rust-2026-10-12')
control_dirs=[Path('/tmp/zstdoxide-double-fast-hash-controls-'+m) for m in ('normal','optimized')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,why):
 if not ok:raise ValueError(why)
e=json.loads((capture/'evidence.json').read_text());r=json.loads((rust/'evidence.json').read_text())
require(e['status']=='passed' and len(e['commands'])==9 and e['source_before']==e['source_after'],'C capture')
require(r['status']=='passed' and len(r['commands'])==13 and r['source_unchanged'],'Rust checks')
for p,digest in e['source_before'].items():require(sha(Path(p))==digest,'C input changed')
for p,digest in r['source'].items():require(sha(root/p)==digest,'Rust input changed')
for c in e['commands']:
 require(c.get('exit_code')==0 and 'error' not in c,'C failure')
 for stream in ('stdout','stderr'):
  item=c[stream];p=capture/item['path'];require(sha(p)==item['sha256'] and p.stat().st_size==item['bytes'],'C log')
counts=[]
for c in r['commands']:
 require(c['exit_code']==0 and sha(rust/c['log'])==c['log_sha256'],'Rust command/log')
 matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', (rust/c['log']).read_text())
 for passed,failed,ignored in matches:require(int(failed)==int(ignored)==0,'test failure/ignore');counts.append(int(passed))
require(sum(counts)==77,'test total')
controls=[]
for directory in control_dirs:
 report=json.loads((directory/'results.json').read_text());require(report['status']=='passed' and report['positive']==1 and report['rejected']==28,'controls')
 for row in report['controls']:
  if 'command' in row:
   for stream in ('stdout','stderr'):
    item=row['command'][stream];p=directory/item['path'];require(sha(p)==item['sha256'] and p.stat().st_size==item['bytes'],'control log')
 controls.append({'optimized':report['optimized'],'positive':1,'rejected':28,'report_sha256':sha(directory/'results.json')})
files={}
for directory,prefix in [(capture,'capture'),(rust,'rust'),*[(d,'controls/'+m) for d,m in zip(control_dirs,('normal','optimized'))]]:
 for p in directory.rglob('*'):
  if p.is_file() and p.name not in ('hash-normal','hash-sanitized') and not any(c.endswith('.dSYM') for c in p.parts):files[prefix+'/'+p.relative_to(directory).as_posix()]=p
sources=['src/matchfinder.rs','scripts/oracles/double_fast_hashes.c','scripts/check_double_fast_hashes.py','scripts/check_double_fast_tiny.py','scripts/capture_double_fast_tiny.py','scripts/oracles/double_fast_direct.py','scripts/check.sh','scripts/check_upstream_fixtures.py','scripts/check_upstream_oracles.sh','docs/reference-double-fast-hashes.md','TODO.md','Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/upstream/match-search/patterns.bin','tests/upstream/match-search/vectors.tsv']
for name in sources:files['repository/'+name]=root/name
for p in (root/'tests/upstream/double-fast-hashes').iterdir():files['repository/'+p.relative_to(root).as_posix()]=p
for name in ['capture-zstdoxide-double-fast-hashes.py','check-zstdoxide-double-fast-hash-rust.py','check-zstdoxide-double-fast-hash-controls.py','package-zstdoxide-double-fast-hashes.py']:files['tools/'+name]=Path('/tmp')/name
out=root/'docs/evidence/2026-10-12-double-fast-hashes.tar.gz'
with tarfile.open(out,'w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname='double-fast-hashes/'+name,recursive=False)
with tarfile.open(out,'r:gz') as tar:
 require(len(tar.getmembers())==len(files),'archive count')
 for member in tar.getmembers():require(member.isfile() and hashlib.sha256(tar.extractfile(member).read()).hexdigest()==sha(files[member.name.removeprefix('double-fast-hashes/')]),'archive member')
summary={'schema_version':1,'status':'passed','date':'2026-10-12','git_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'Direct small-log eight-byte hashes and Rust table comparisons; no production-code change or DoubleFast parser/frame claim.','C_capture':{'commands':9,'rows_per_build':512,'normal_sanitized_equal':True,'evidence_sha256':sha(capture/'evidence.json'),'source_before_after_equal':True,'source_sha256':e['source_sha256'],'compiler':e['compiler'],'compiler_sha256':e['compiler_sha256'],'results':e['results'],'instrumentation':e['instrumentation']},'rust':{'commands':13,'focused_tests_per_configuration':11,'configurations':['safe','unsafe-match-table','all-features','no-default','no-default-all-features'],'baseline_tests':22,'total_passed':77,'failed':0,'ignored':0,'evidence_sha256':sha(rust/'evidence.json'),'source_unchanged':True},'controls':controls,'coordinator_checks':{'offline_normal_and_optimized':'passed','fixture_registry_normal_and_optimized':{'status':'passed','files':546,'collections':18},'clang_format':'passed','diff_whitespace':'passed'},'repository_source_sha256':{n:sha(root/n) for n in sources},'archive':{'path':out.relative_to(root).as_posix(),'bytes':out.stat().st_size,'sha256':sha(out),'members':len(files),'exclusions':'Compiled C executables/debug bundles (hashes retained), external pinned C source (hash catalog retained), unchanged Rust dependencies available from recorded git base.'}}
(root/'docs/evidence/2026-10-12-double-fast-hashes.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps({'archive':summary['archive'],'rust':summary['rust']},indent=2))
