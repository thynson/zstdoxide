from pathlib import Path
import hashlib,json,os,subprocess,time,collections
D=Path(__file__).parent;R=D/'source';C=Path('/private/tmp/module25-external-corpora/extracted/dictionary_decompress');A=C.parents[1]/'archives/dictionary_decompress_seed_corpus.zip'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert A.stat().st_size==117184521 and sha(A)=='4165df80490877b9b8f32dc0460d49896a362e192369cdc77ad1a0fd54e263e8'
f=json.loads((D/'focused.json').read_text());assert f['status']=='passed' and len(f['commands'])==7
files=sorted(p for p in C.rglob('*') if p.is_file());assert len(files)==12063 and sum(p.stat().st_size for p in files)==353411091
for p in files:assert not p.is_symlink() and '\n' not in str(p) and '\t' not in str(p) and p.stat().st_size<=2*1024*1024
members={str(p.relative_to(C)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files};(D/'members.json').write_text(json.dumps(members,indent=2)+'\n')
e=dict(status='running',source=f['source'],focused_sha256=sha(D/'focused.json'),archive_sha256=sha(A),members_sha256=sha(D/'members.json'),files=12063,bytes=353411091,commands=[])
def save():(D/'corpus.json').write_text(json.dumps(e,indent=2)+'\n')
assert not (D/'corpus.json').exists();save()
try:
 env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','ZSTDOXIDE_DICTIONARY_CORPUS':str(C),'ZSTDOXIDE_DICTIONARY_TARGET':'decompress','ZSTDOXIDE_DICTIONARY_MAX_FILES':'12063'}
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  args=['cargo','test','--offline','--locked','--release','--test','upstream_trained_dictionary_fuzz',*flags,'--','--ignored','--exact','external_trained_dictionary_file_corpus','--nocapture'];t=time.monotonic()
  with (D/(name+'-corpus.log')).open('xb') as log:p=subprocess.run(args,cwd=R,env={**env,'ZSTDOXIDE_DICTIONARY_LEDGER':str(D/(name+'-ledger.tsv'))},stdout=log,stderr=subprocess.STDOUT,timeout=1800)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(name+'-corpus.log'))));save();print(name,p.returncode,flush=True);assert p.returncode==0,name
  rows=[line.split('\t') for line in (D/(name+'-ledger.tsv')).read_text().splitlines()];assert len(rows)==12063
  for row,path in zip(rows,files):
   assert len(row)==6 and row[0]==str(path) and row[1] in ['prepared','loaded','prefix'];assert 0<=int(row[2])<=path.stat().st_size and 0<=int(row[3])<=10*int(row[2]);assert row[4] in ['0','1'] and row[5] in ['0','1']
  branches=dict(collections.Counter(row[1] for row in rows));trained=sum(int(row[4]) for row in rows);decoded=sum(int(row[5]) for row in rows)
  assert trained==11768 and decoded==20,('historical bounded outcomes changed',trained,decoded)
  e.setdefault('backends',{})[name]=dict(ledger_sha256=sha(D/(name+'-ledger.tsv')),branches=branches,direct=sum(row[1]!='prefix' for row in rows),prefix=sum(row[1]=='prefix' for row in rows),trained=trained,training_failed_fallback=12063-trained,decoded=decoded,rejected=12063-decoded);save()
 assert (D/'safe-ledger.tsv').read_bytes()==(D/'all-ledger.tsv').read_bytes()
 for n,h in f['source'].items():assert sha(R/n)==h,n
 for n,row in members.items():assert sha(C/n)==row['sha256'],n
 e.update(status='passed',qualification='All12063 hash-pinned rolling dictionary_decompress inputs run under safe/all release with zero skips. Persistent prepared/loaded branches use actual fixed destinations and guards, and compare success/bytes with the previous buffered decoder. Prefix branches deliberately retain buffered output. Exact branch/size/capacity/training/success ledgers match safe/all; historical bounded counts remain11768 trained,295 fallback,20 successes. Training is the independent Rust algorithm, not native fastCover. This is not an assertion of native byte-identical trained dictionaries or complete upstream API/stateful/by-reference parity.');save();print(e['backends'],flush=True)
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
