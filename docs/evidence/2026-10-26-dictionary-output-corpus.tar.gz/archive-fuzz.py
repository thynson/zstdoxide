from pathlib import Path
import json,hashlib,tarfile
D=Path(__file__).parent;F=Path('/private/tmp/module25-fuzz');S=F/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((F/'focused.json').read_text());c=json.loads((F/'corpus.json').read_text());assert f['status']==c['status']=='passed'
assert len(f['commands'])==7 and len(c['commands'])==2
for record in [f,c]:
 for command in record['commands']:assert command['exit_code']==0
for n,h in f['source'].items():assert sha(S/n)==h,n
assert c['focused_sha256']==sha(F/'focused.json')
assert (F/'safe-ledger.tsv').read_bytes()==(F/'all-ledger.tsv').read_bytes()
assert c['files']==12063 and c['bytes']==353411091
for name in ['safe','all']:
 assert c['backends'][name]['ledger_sha256']==sha(F/(name+'-ledger.tsv'))
assert c['members_sha256']==sha(F/'members.json')
base=json.loads((D/'2026-10-26-dictionary-output-public-api.json').read_text());omitted=base['fixture_provenance']['omitted_binary_files']
for n,h in omitted.items():assert sha(S/n)==h,n
name='2026-10-26-dictionary-output-corpus';archive=D/(name+'.tar.gz');assert not archive.exists()
files=[p for p in F.iterdir() if p.is_file()]
for folder in ['src','tests','test-support','benches','examples','scripts']:
 files += [p for p in (S/folder).rglob('*') if p.is_file() and p.suffix in {'.rs','.toml','.lock','.md','.json','.py','.sh','.tsv','.csv'}]
files += [S/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']]
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(set(files)):t.add(p,arcname=str(p.relative_to(F)))
 t.add(__file__,arcname='archive-fuzz.py')
result=dict(status='passed',focused=f,corpus=c,archive=archive.name,archive_sha256=sha(archive),fixture_provenance=base['fixture_provenance'],qualification=c['qualification']+' The full corpus payload remains external; archive pin, all member hashes, frozen adapter/production source and per-input safe/all ledgers are retained. The final matrix separately incorporates this exact adapter source.')
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
