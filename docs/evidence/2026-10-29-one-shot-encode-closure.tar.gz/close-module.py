"""Close the module35 milestone: reconcile, archive, document and commit."""
from pathlib import Path
import json, hashlib, subprocess, tarfile, datetime

D = Path(__file__).parent
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
E = R / 'docs/evidence'
F = Path('/private/tmp/module35-final')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = D / 'promotion-state.json'
previous = json.loads(state.read_text())
assert previous['stage'] == 'next-design'
assert previous['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
production = {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')}
assert production == previous['production_source']
names = ['2026-10-28-one-shot-encode-engine', '2026-10-28-one-shot-encode-public-api', '2026-10-27-one-shot-encode-native', '2026-10-28-one-shot-encode-corpus', '2026-10-28-one-shot-encode-platform', '2026-10-29-one-shot-encode-feature-matrix', '2026-10-29-one-shot-encode-benchmarks']
records = {}
for n in names:
    p = E / (n + '.json')
    j = json.loads(p.read_text())
    assert j['status'] == 'passed' and sha(E / j['archive']) == j['archive_sha256']
    records[n] = dict(receipt_sha256=sha(p), archive_sha256=j['archive_sha256'])
for n in ['2026-10-28-one-shot-encode-public-api', '2026-10-27-one-shot-encode-native', '2026-10-28-one-shot-encode-corpus', '2026-10-28-one-shot-encode-platform', '2026-10-29-one-shot-encode-feature-matrix']:
    assert json.loads((E / (n + '.json')).read_text())['production_source'] == production, n
matrix = json.loads((E / '2026-10-29-one-shot-encode-feature-matrix.json').read_text())
post32 = json.loads((E / '2026-10-27-query-utility-corpus-inventory.json').read_text())
assert post32['status'] == 'passed'
recon = E / '2026-10-28-dictionary-selection-reason-reconciliation.json'
k = json.loads(recon.read_text())
assert k['status'] == 'passed' and sha(R / 'tests/upstream/manifest.json') == k['integrated_manifest_sha256']
for n, h in matrix['source'].items():
    if n == 'tests/upstream/FUZZER.md':
        assert sha(F / n) == h, ('matrix input FUZZER.md changed', n)
        assert sha(R / n) == post32['members']['integrated-FUZZER.md']['sha256'], ('repo FUZZER.md is not the authorized post32 inventory result', n)
    elif n == 'tests/upstream/manifest.json':
        assert sha(F / n) == h == k['production_baseline_manifest_sha256'], ('matrix input manifest.json changed', n)
        assert sha(R / n) == k['integrated_manifest_sha256'], ('repo manifest.json is not the authorized reason-reconciliation result', n)
    else:
        assert sha(R / n) == h, n
bench = json.loads((E / '2026-10-29-one-shot-encode-benchmarks.json').read_text())
assert bench['build']['production_source'] == production
pred = E / '2026-10-27-dictionary-slice-encode-closure.json'
j = json.loads(pred.read_text())
assert j['status'] == 'passed' and sha(E / j['archive']) == j['archive_sha256']
todo = (R / 'TODO.md').read_text()
start = todo.index('## Module 35:')
end = todo.index('\n## ', start + 1)
unchecked = [l for l in todo[start:end].splitlines() if l.startswith('- [ ]')]
assert len(unchecked) == 1 and unchecked[0].startswith('- [ ] Reconcile bounded selection coverage'), unchecked
assert '## Module 36:' in todo and (R / 'docs/one-shot-encode-parameters-design.md').exists()
assert sha(R / 'docs/one-shot-encode-parameters-design.md') == previous['next_design_sha256']
C = Path('/private/tmp/module35-reconciliation')
C.mkdir()
args = ['python3', 'scripts/audit_upstream_tests.py', '--upstream', '/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99']
with (C / 'inventory.log').open('xb') as f:
    p = subprocess.run(args, cwd=R, stdout=f, stderr=subprocess.STDOUT)
assert p.returncode == 0
receipt = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), production_source=production, integrated_manifest_sha256=sha(R / 'tests/upstream/manifest.json'), final_matrix_source=matrix['source'], evidence=records, predecessor_closure_sha256=sha(pred), reason_reconciliation_sha256=sha(recon), separate_inventory_receipt_sha256=sha(E / '2026-10-27-fuzz-capability-reconciliation.json'), inventory_command=args, inventory_log_sha256=sha(C / 'inventory.log'), next_design_sha256=sha(R / 'docs/one-shot-encode-parameters-design.md'), qualification='Bounded call-scoped persistent/prefix dictionary selection for caller-owned one-shot compression over the existing ordinary Greedy encoder. Exact existing Rust bytes, attempt-exact consumption, independent dictionary/scratch ownership and inherited one-block staging contracts. Full feature/release, guarded native/corpus/platform and independent measured campaigns are retained. The repository keeps the authorized post32 FUZZER.md and reason-reconciliation manifest.json over the campaign inputs. No parameterized dictionary combination, reference levels with LDM, native workspace semantics, threading or complete codec replacement is claimed.')
(C / 'reconciliation.json').write_text(json.dumps(receipt, indent=2) + '\n')
name = '2026-10-29-one-shot-encode-closure'
archive = E / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    for p in C.iterdir():
        tar.add(p, arcname=p.name)
    tar.add(__file__, arcname='close-module.py')
receipt.update(archive=archive.name, archive_sha256=sha(archive))
(E / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
p = R / 'docs/one-shot-encode-selection-validation.md'
s = p.read_text()
old = 'Module 35 is in progress. The internal coordinator and public caller-owned\nmethods have focused qualification. Complete feature/release regression, measurements and reconciliation remain\nopen.'
assert old in s
s = s.replace(old, 'Module 35 is complete within its call-scoped dictionary/prefix selection\nscope for caller-owned one-shot compression. Focused, guarded native/corpus,\nplatform, complete feature/release and independent measurement gates have\nsuccessful source-bound receipts.')
s += '''
## Final reconciliation and remaining scope

Integrated production and matrix sources match the qualified public/native/
platform/corpus and measured snapshots; every stage archive is rehashed. The
repository retains the authorized post32 FUZZER.md and reason-reconciliation
manifest.json results over the pre-apply campaign inputs, with both sides
verified rather than silently overwritten. Earlier internal snapshots retain
their distinct identities. No new supplemental native or deterministic corpus
case promotes an original upstream group by inference.

Parameterized dictionary-backed one-shot compression is designed and decomposed
next. Reference levels with LDM, streaming variants, native workspace/reset
semantics, threading and complete upstream library/CLI parity remain open.
Short output may retain earlier complete appends; all writes remain within the
caller slice, and the dictionary is unchanged.
Evidence: `evidence/2026-10-29-one-shot-encode-closure.json`.
'''
p.write_text(s)
p = R / 'README.md'
s = p.read_text()
anchor = '[the dictionary output validation report](docs/dictionary-slice-encode-validation.md).\n'
assert s.count(anchor) == 1
s = s.replace(anchor, anchor + '''
Reusable call-scoped selection is available through `OneShotEncoder`: a
persistent dictionary selection survives calls and errors, while
`with_prefix`/`set_prefix` arm exactly the next attempted call, including
empty input, short output and allocation failure. Its completed bounded
qualification and remaining scope are recorded in
[the selection validation report](docs/one-shot-encode-selection-validation.md).
''')
p.write_text(s)
p = R / 'docs/progress.md'
ratios = [f"{x['campaign']} {x['backend']} {x['numerator']}/{x['denominator']} vs {x['reference_backend']} {x['nonempty_geomean']:.4f}" for x in bench['summary']['comparisons'] if x['backend'] in ['safe', 'all'] and (x['numerator'] != x['denominator'] or x['backend'] == 'all')]
p.write_text(p.read_text() + '''
## Module 35: reusable one-shot compression dictionary and prefix selection complete (2026-10-29)

OneShotEncoder wraps the existing plain Selection/Claimed ownership records
over any dictionary handle type. Persistent selection is borrowed per call; a
pending prefix is claimed by exclusive replacement before output admission or
allocator work and lives until the attempt returns or unwinds. No handle is
cloned, no dictionary content is copied and no workspace is retained; borrowed
views cannot outlive their owner. compress_into/compress_into_in reuse the
module34 caller-owned emitter and the ordinary Greedy path byte-for-byte.

All 75 final commands pass: safe/all/22 isolated full suites, no_std and strict
Clippy, safe/all release and format. Every complete/release suite reports 1766
passed and 76 ignored across 117 groups; one interrupted-at-deadline partial
command was never credited and its log is retained. Twenty-seven typed native
schedules retain 87 native rows, 42 successes and 6 capacity errors with 12
fresh controls and zero unexplained subsequent differences; ASan leak
detection stays uncredited on this runtime. The merged trained adapter keeps
both module34 and module35 helpers with byte-identical ledgers across four
feature selections. Four foreign Miri runs and four concrete thumbv6m
no-atomics checks/builds pass.

Thirty-three dictionary/input pairs retain 297 allocation/result rows and 675
samples per executable across 24 primary backends and independent safe/all
rebuilds: stateless baseline, persistent coordinator, prefix rearming outside
and inside the compression clock, plus setup-only arm/observe/clear batches
that include loop and black-box overhead and are not subtractable. Geometric
mean ratios over 30 nonempty pairs: ''' + '; '.join(ratios) + '''. No
universal unsafe speedup or absence of scratch allocation is inferred.

Completed tasks are archived in Git history. The next module combines the
qualified reference parameter profiles with immutable dictionary selection in
caller-owned one-shot output; see
`docs/one-shot-encode-parameters-design.md`. Reference levels with LDM,
threading, native workspace semantics and complete upstream migration remain
open.
''')
replacement = '''Module 35 is complete within its call-scoped one-shot selection scope.
Completed items are archived in Git history and `docs/progress.md`; contracts,
measurements and limits are in `docs/one-shot-encode-selection-validation.md`
and `docs/one-shot-encode-benchmarks.md`. Final reconciliation is in
`docs/evidence/2026-10-29-one-shot-encode-closure.json`.
Complete upstream parity remains open.
'''
(R / 'TODO.md').write_text(todo[:start] + replacement + todo[end:])
paths = ['README.md', 'TODO.md', 'docs/progress.md', 'docs/one-shot-encode-selection-validation.md', 'docs/evidence/' + name + '.json', 'docs/evidence/' + name + '.tar.gz']
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Close one-shot encode selection milestone'], cwd=R, check=True)
previous.update(stage='closed', head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip())
state.write_text(json.dumps(previous, indent=2) + '\n')
print('module35 closed')
