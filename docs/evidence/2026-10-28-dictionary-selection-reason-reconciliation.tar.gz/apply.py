"""Apply the six validated reason-only manifest corrections after Module34 closure.

The module35-inventory-plan candidate was validated in the previous window but
could not be applied until its dependent frozen milestones closed. Modules 32,
33 and 34 are now closed with passed receipts. This script applies only the six
reason texts, preserves every status, mapping, anchor and count, reruns the
integrated pinned audit against the repository root, records its receipt with
an archive, and commits the reconciliation separately.
"""
from pathlib import Path
import collections, datetime, hashlib, json, shutil, subprocess, tarfile

D = Path('/private/tmp/module35-inventory-plan')
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan = json.loads((D / 'plan.json').read_text())
assert plan['status'] == 'validated-candidate-not-applied', plan['status']

assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
closures = {}
for name in ['frame-utility', 'one-shot-selection', 'slice-encode', 'dictionary-slice-encode']:
    p = E / ('2026-10-27-' + name + '-closure.json')
    j = json.loads(p.read_text())
    assert j['status'] == 'passed' and sha(E / j['archive']) == j['archive_sha256'], name
    closures[name] = sha(p)

assert sha(R / 'tests/upstream/manifest.json') == plan['baseline_manifest_sha256'], 'Integrated manifest moved'
assert sha(D / 'manifest.json') == plan['manifest_sha256'], 'Validated candidate manifest changed'
candidate = json.loads((D / 'manifest.json').read_text())
integrated = json.loads((R / 'tests/upstream/manifest.json').read_text())
ids = {c['id'] for c in plan['changes']}
changed_ids = set()
for old_new, now in [(plan['changes'], candidate)]:
    pass
# Verify every case: only the six reasons differ, byte-for-byte elsewhere.
by_id_new = {}
for s in candidate['sources']:
    for c in s.get('cases', []):
        by_id_new[c['id']] = c
by_id_old = {}
for s in integrated['sources']:
    for c in s.get('cases', []):
        by_id_old[c['id']] = c
assert set(by_id_new) == set(by_id_old)
for cid, new in by_id_new.items():
    old = by_id_old[cid]
    assert {k: v for k, v in old.items() if k != 'reason'} == {k: v for k, v in new.items() if k != 'reason'}, cid
    if cid in ids:
        assert old['status'] == 'partial' and 'byte-identical encoder comparisons remain unported' in old['reason'], cid
        assert old['reason'] != new['reason']
        changed_ids.add(cid)
assert changed_ids == ids, changed_ids
for change in plan['changes']:
    assert by_id_new[change['id']]['reason'] == change['after'], change['id']

shutil.copyfile(D / 'manifest.json', R / 'tests/upstream/manifest.json')
args = ['python3', 'scripts/audit_upstream_tests.py', '--upstream',
        '/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99']
with (D / 'integrated-audit.log').open('xb') as f:
    p = subprocess.run(args, cwd=R, stdout=f, stderr=subprocess.STDOUT)
assert p.returncode == 0, (D / 'integrated-audit.log').read_text()
j = json.loads((R / 'tests/upstream/manifest.json').read_text())
counts = collections.Counter(c['status'] for s in j['sources'] for c in s.get('cases', []))
assert dict(counts) == plan['case_counts'], counts

todo = R / 'TODO.md'
s = todo.read_text()
anchor = '- [ ] Reconcile bounded selection coverage and decompose the next evidenced contract without claiming native workspace or complete upstream parity.'
assert s.count(anchor) == 1
s = s.replace(anchor, '- [x] Reconcile the six dictionary-encode selection reasons with the qualified native selection evidence after Module 34 source closure.\n' + anchor)
todo.write_text(s)

progress = R / 'docs/progress.md'
progress.write_text(progress.read_text() + """
## Dictionary-encode selection reason reconciliation (2026-10-28)

After Module34 closure, six pinned fuzzer.c dictionary-encode selection groups
(3032..3078) carry reasons that state exactly what their original assertions
check: successful persistent/prefix selection operations and one compression
call, not compressed-byte identity. Every status, test mapping, frozen anchor
and count is unchanged; the complete pinned audit passes against the integrated
root. This is a separate metadata-only reconciliation; no new port and no
Module35 completion is claimed.
Evidence: `evidence/2026-10-28-dictionary-selection-reason-reconciliation.json`.
""")

name = '2026-10-28-dictionary-selection-reason-reconciliation'
archive = E / (name + '.tar.gz')
assert not archive.exists()
files = {p.name: p for p in D.iterdir() if p.is_file() and p.suffix in ['.json', '.py', '.log']}
files['integrated-manifest.json'] = R / 'tests/upstream/manifest.json'
files['apply.py'] = Path(__file__)
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
receipt = dict(
    status='passed',
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    production_baseline_manifest_sha256=plan['baseline_manifest_sha256'],
    integrated_manifest_sha256=sha(R / 'tests/upstream/manifest.json'),
    closures=closures,
    changes=plan['changes'],
    case_counts=dict(counts),
    audit_command=args,
    audit_log_sha256=sha(D / 'integrated-audit.log'),
    archive=archive.name,
    archive_sha256=sha(archive),
    qualification='Reason-only manifest corrections applied after every dependent frozen milestone closed. Six dictionary-encode selection reasons now match the executed supplemental native/Rust selection evidence; statuses, mappings, anchors and counts unchanged. The complete pinned audit passes against the integrated root. No new port and no Module35 completion is claimed.')
(E / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
paths = ['tests/upstream/manifest.json', 'TODO.md', 'docs/progress.md',
         'docs/evidence/' + name + '.json', 'docs/evidence/' + name + '.tar.gz']
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *paths], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Reconcile dictionary selection reasons with native selection evidence'], cwd=R, check=True)
print('applied six reason-only corrections; audit passed; committed')
