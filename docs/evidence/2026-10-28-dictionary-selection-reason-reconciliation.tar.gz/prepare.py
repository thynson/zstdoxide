from pathlib import Path
import collections,datetime,hashlib,json,importlib.util,contextlib,sys
D=Path(__file__).parent;T=Path('/private/tmp');R=Path('/Users/lanxingcan/Workspace/zstdoxize');base=T/'module33-inventory-plan/manifest.json';study=T/'module35-design/original-groups-study.json';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
j=json.loads(base.read_text());before=json.loads(base.read_text());proof=json.loads(study.read_text());assert proof['status']=='source-study-only'
ids={g['id'] for g in proof['groups']};assert len(ids)==6
changes=[]
for s in j['sources']:
 for c in s.get('cases',[]):
  if c['id'] in ids:
   assert c['status']=='partial' and 'byte-identical encoder comparisons remain unported' in c['reason'];changes.append(dict(id=c['id'],before=c['reason']))
   c['reason']='Setting a persistent dictionary or one-use prefix replaces the other configuration and selects the expected frame ID/content in supplemental Rust checks. These six pinned C groups assert successful selection operations and one compression call, not compressed-byte identity. Rust unifies raw/prepared ownership; the exact inherited CNBuffer/dictBuffer preparation, current context parameters, and separate native loadDictionary/refCDict/refPrefix API semantics remain unported.'
   changes[-1]['after']=c['reason']
assert len(changes)==6
for old,new in zip(before['sources'],j['sources']):
 for a,b in zip(old.get('cases',[]),new.get('cases',[])):
  assert {k:v for k,v in a.items() if k!='reason'}=={k:v for k,v in b.items() if k!='reason'}
  if a['id'] not in ids:assert a==b
candidate=D/'manifest.json';candidate.write_text(json.dumps(j,indent=2)+'\n')
# The original auditor still checks every pinned upstream source/case. The
# staged source root contains the future mapped tests already present in the
# post33 candidate; the current integrated root intentionally does not yet.
script=R/'scripts/audit_upstream_tests.py';spec=importlib.util.spec_from_file_location('inventory_audit',script);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.ROOT=T/'module35-public/source';sys.argv=[str(script),'--manifest',str(candidate),'--upstream',str(T/'module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99')]
with (D/'audit.log').open('x') as f,contextlib.redirect_stdout(f),contextlib.redirect_stderr(f):result=module.main()
assert result in [None,0],result
counts=dict(collections.Counter(c['status'] for s in j['sources'] for c in s.get('cases',[])))
(D/'plan.json').write_text(json.dumps(dict(status='validated-candidate-not-applied',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_manifest_sha256=sha(base),manifest_sha256=sha(candidate),source_study_sha256=sha(study),auditor_sha256=sha(script),audit_root=str(module.ROOT),audit_log_sha256=sha(D/'audit.log'),changes=changes,case_counts=counts,qualification='Six reason-only corrections preserve every source/case status, test mapping, frozen anchor and count. Full pinned inventory audit executes against the staged source root. Apply only after dependent frozen milestones close, then rerun the integrated audit and commit separately. No new original assertion port or Module35 completion is claimed.'),indent=2)+'\n')
print('Validated six reason-only corrections; statuses and test mappings unchanged')
