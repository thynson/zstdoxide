from pathlib import Path
import json,hashlib,shutil,subprocess
T=Path('/private/tmp');R=T/'module25-candidate';D=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
gates={}
for name,path,count in [('storage','module25-storage/evidence.json',17),('engine','module25-engine/evidence.json',17),('public','module25-candidate/public.json',24),('native','module25-native/rust.json',5),('platform','module25-platform/evidence.json',8),('fuzz','module25-fuzz/focused.json',7)]:
 p=T/path;j=json.loads(p.read_text());assert j['status']=='passed' and len(j['commands'])==count and all(c['exit_code']==0 for c in j['commands']),name;gates[name]=sha(p)
assert (T/'module25-archives/2026-10-26-dictionary-output-public-api.tar.gz').exists(),'Archive focused snapshot before test additions'
assert not (D/'preparation.json').exists()
changes={}
for source,dest in [('module24-fuzz/source/tests/stable_stream_fuzz.rs','tests/stable_stream_fuzz.rs'),('module25-fuzz/source/tests/upstream_trained_dictionary_fuzz.rs','tests/upstream_trained_dictionary_fuzz.rs'),('module25-native/rust/dictionary_output_native.rs','tests/dictionary_output_native.rs'),('module25-platform/dictionary_output_platform.rs','tests/dictionary_output_platform.rs')]:
 old=sha(R/dest) if (R/dest).exists() else None;shutil.copyfile(T/source,R/dest);changes[dest]=dict(before=old,after=sha(R/dest),qualified_source=source)
m=json.loads((T/'module24-fuzz/source/tests/upstream/manifest.json').read_text())
targets={f'tests/fuzzer.c:{line}' for line in [2461,2488,2777,2815,2874,2896]};found=set()
for row in m['sources']:
 if row['path']=='tests/fuzzer.c':
  for c in row['cases']:
   if c['id'] in targets:
    assert c['status']=='partial';found.add(c['id']);c['reason']+=' Direct caller-owned dictionary output is additionally qualified against119 independent guarded fixed-destination cases, using both native usingDict/prepared-DDict APIs in normal and ASan/UBSan builds, and shared/borrowed Rust handles under five backend selections. Original C context/workspace and frame-construction parameter gaps remain partial.';c['rust_tests']+=['src/decode.rs#prepared_raw_and_crossing_fixtures_match_independent_originals','tests/dictionary_output.rs#public_exact_short_and_options_limits_preserve_destination_identity_and_guards','tests/dictionary_output_native.rs#pinned_native_dictionary_destinations_and_guarded_errors']
 if row['path']=='tests/fuzz/dictionary_decompress.c':
  for v in [row,*row['cases']]:
   v['reason']='Historical buffered adapter qualification: '+v['reason']+' The current persistent prepared/loaded branches additionally use actual guarded direct destinations and compare success/output with the buffered API; prefix branches retain buffered output. Focused independent storage-feature checks pass. Its new full corpus replay has a separate completion receipt; historical counts do not establish this changed branch coverage.'
   v['rust_tests']+=['tests/dictionary_output.rs#truncations_mutations_and_concatenation_do_not_cross_output_allowance']
assert found==targets
p=R/'tests/upstream/manifest.json';changes['tests/upstream/manifest.json']=dict(before=sha(p));p.write_text(json.dumps(m,indent=2)+'\n');changes['tests/upstream/manifest.json']['after']=sha(p)
for label,args in [('format',['cargo','fmt','--all','--','--check']),('inventory',['python3','scripts/audit_upstream_tests.py','--upstream',str(T/'module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99')])]:
 with (D/('prepare-'+label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,label
(D/'preparation.json').write_text(json.dumps(dict(status='passed',gates=gates,changes=changes,qualification='All added tests are included before final full-matrix freeze. Corpus metadata can later be reconciled in a separate audited manifest without changing production or test source bytes.'),indent=2)+'\n')
print('Final candidate tests prepared, formatted and inventory-audited')
