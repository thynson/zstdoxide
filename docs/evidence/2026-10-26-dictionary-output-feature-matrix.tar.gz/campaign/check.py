from pathlib import Path
import os,subprocess,json,time,hashlib,tomllib,datetime,signal
R=Path('/private/tmp/module25-candidate');D=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((R/'public.json').read_text())['status']=='passed'
assert json.loads((D/'preparation.json').read_text())['status']=='passed'
features=sorted(f for f in tomllib.loads((R/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'))
paths=list((R/'src').rglob('*.rs'))+list((R/'tests').rglob('*.rs'))+[R/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/upstream/manifest.json']]
e=dict(status='running',source={str(p.relative_to(R)):sha(p) for p in paths},features=features,commands=[],started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module25-candidate-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
deadline=datetime.datetime(2026,10,26,8,59,25,tzinfo=datetime.timezone.utc).timestamp()
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 start=time.monotonic();remaining=deadline-time.time()-30
 if remaining<30:raise TimeoutError('User work window elapsed before '+label)
 with (D/(label+'.log')).open('xb') as f:
  p=subprocess.Popen(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=p.wait(timeout=remaining)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   raise TimeoutError('User work window elapsed during '+label)
 e['commands'].append(dict(label=label,argv=args,exit_code=code,seconds=time.monotonic()-start));save();print(label,code,flush=True);assert code==0,label
assert not (D/'evidence.json').exists();save()
try:
 for name,flags,no in [('safe',[],[]),('all',['--all-features'],['--features',','.join(features)]),*[(f,['--features',f],['--features',f]) for f in features]]:
  run(name+'-full',['cargo','test','--offline','--locked',*flags])
  run(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*no])
  run(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  run(name+'-release',['cargo','test','--offline','--locked','--release',*flags])
 run('format',['cargo','fmt','--all','--','--check'])
 for n,h in e['source'].items():assert sha(R/n)==h,n
 e['status']='passed';save()
except TimeoutError as ex:e.update(status='interrupted-at-user-deadline',error=repr(ex));save();raise
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
