from pathlib import Path
import hashlib,json,os,subprocess,time,tomllib,shutil
R=Path.cwd();O=Path('/tmp/zstdoxide-ultra-path-thumb-1016');O.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source={str(p.relative_to(R)):sha(p)for p in list((R/'src').rglob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock']}
shutil.copytree(R/'src',O/'probe/src')
features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'})
(O/'probe/Cargo.toml').write_text('[package]\nname="ultra-path-no-atomics"\nversion="0.0.0"\nedition="2024"\n[features]\ndefault=[]\nstd=[]\n'+''.join(f'{f}=[]\n' for f in features)+'[lints.rust]\nunsafe_op_in_unsafe_fn="deny"\n[lints.clippy]\nundocumented_unsafe_blocks="deny"\n')
s='''
struct UltraProbeProvider<'a>(&'a [(usize,u32,usize)]);
impl optimal_parse::PathProvider for UltraProbeProvider<'_> {
 fn query<A: core::alloc::Allocator>(&mut self, q: optimal_search_layout::OptimalQuery, matches: &mut optimal_matches::OptimalMatches<A>) -> Result<()> {
  for &(position,off,length) in self.0 {
   if position==q.position {matches.push(optimal_search_layout::OptimalMatch::new(off,length)?)?;}
  }
  Ok(())
 }
}
struct UltraProbeObserver(usize);
impl optimal_parse::PathObserver for UltraProbeObserver {
 fn event<P:core::alloc::Allocator,F:core::alloc::Allocator>(&mut self,event:optimal_parse::PathEvent,_:&optimal_paths::OptimalPaths<P>,_:&optimal_frequencies::OptimalFrequencies<F>,_:&[optimal_search_layout::OptimalMatch])->Result<()> {
  self.0+=usize::from(event.alternative.is_some()); Ok(())
 }
}
pub fn ultra_path_probe(source:&[u8],script:&[(usize,u32,usize)],minimum:u8,target:usize)->Result<(usize,[u32;3],usize)> {
 use alloc::alloc::Global;
 let mut parser=optimal_parse::OptimalParser::from_policy_parts(optimal_price::PricePolicy::Ultra,source,minimum,target,
  optimal_frequencies::OptimalFrequencies::new_with_policy_in(optimal_price::PricePolicy::Ultra,false,Global)?,
  optimal_paths::OptimalPaths::new_in(Global)?,optimal_matches::OptimalMatches::new_in(Global)?)?;
 let mut observer=UltraProbeObserver(0);
 let result=parser.parse(&mut UltraProbeProvider(script),&mut observer)?;
 parser.reset()?;
 Ok((result.sequences,result.repeats,observer.0))
}
'''
p=O/'probe/src/lib.rs';p.write_text(p.read_text()+s)
env={k:v for k,v in os.environ.items()if k in ['PATH','HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR']};env.update(RUSTUP_TOOLCHAIN='nightly-2026-10-08',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-ultra-frequency-thumb-target');records=[]
commands=[('library-safe',['cargo','check','--offline','--locked','--lib','--no-default-features','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc'],R),('library-all',['cargo','check','--offline','--locked','--lib','--no-default-features','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc','--features',','.join(features)],R),('codegen-safe',['cargo','build','--offline','--lib','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc'],O/'probe'),('codegen-all',['cargo','build','--offline','--lib','--target','thumbv6m-none-eabi','-Zbuild-std=core,alloc','--features',','.join(features)],O/'probe')]
def save(status,error=None):(O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,source_unchanged=all(sha(R/p)==h for p,h in source.items()),commands=records,qualification='Safe/all no_std thumbv6m library checks and concrete private scripted Ultra construction/parse/observer/reset/drop code generation. No firmware execution or public Ultra admission.'),indent=2)+'\n')
try:
 for label,argv,cwd in commands:
  print('START',label,flush=True);start=time.monotonic();p=O/(label+'.log')
  with p.open('w')as f:r=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  records.append(dict(label=label,argv=argv,cwd=str(cwd),exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)));save('running')
  if r.returncode:raise ValueError(label)
  print('END',label,flush=True)
 if any(sha(R/p)!=h for p,h in source.items()):raise ValueError('source changed')
 save('passed')
except BaseException as error:save('failed',repr(error));raise
