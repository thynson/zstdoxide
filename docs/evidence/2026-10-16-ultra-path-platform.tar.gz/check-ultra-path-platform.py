from pathlib import Path
import hashlib,json,os,subprocess,time,tomllib
R=Path.cwd();O=Path('/tmp/zstdoxide-ultra-path-platform-1016');O.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=list((R/'src').rglob('*.rs'))+[R/'tests/support/ultra_path_parse.rs',R/'tests/support/ultra_path_fixture.rs',R/'Cargo.toml',R/'Cargo.lock'];source={str(p.relative_to(R)):sha(p)for p in paths};commands=[]
env={k:v for k,v in os.environ.items()if k in ['PATH','HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR']};env.update(RUSTUP_TOOLCHAIN='nightly-2026-10-08',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-ultra-frequency-miri-target',MIRIFLAGS='-Zmiri-strict-provenance')
def save(status,error=None):(O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,source_unchanged=all(sha(R/p)==h for p,h in source.items()),commands=commands,qualification='Selected strict-provenance Ultra parser owner, policy, boundary and reset tests interpreted on 32-bit and big-endian targets; no native foreign execution.'),indent=2)+'\n')
selectors=['optimal_parse::ultra_tests::borrowed_ultra_owners_preserve_policy_without_parse_or_reset_allocations', 'optimal_parse::ultra_tests::explicit_ultra_mismatch_and_bounds_release_exact_moved_owners']
try:
 for target in ['i686-unknown-linux-gnu','s390x-unknown-linux-gnu']:
  env['MIRI_SYSROOT']='/tmp/zstdoxide-platform-sysroot-'+target.split('-')[0]
  for mode,flags in [('safe',[]),('all',['--all-features'])]:
   for i,test in enumerate(selectors):
    label=f'{target}-{mode}-{i}';argv=['cargo','miri','test','--offline','--locked','--target',target,*flags,'--lib','--','--exact',test];print('START',label,flush=True);begin=time.monotonic()
    with(O/(label+'.log')).open('wb')as f:r=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
    p=O/(label+'.log');commands.append(dict(label=label,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-begin,log=p.name,sha256=sha(p)));save('running')
    if r.returncode or b'test result: ok. 1 passed; 0 failed;'not in p.read_bytes():raise ValueError(label)
    print('END',label,flush=True)
 if any(sha(R/p)!=h for p,h in source.items()):raise ValueError('source changed')
 save('passed')
except BaseException as error:save('failed',repr(error));raise
