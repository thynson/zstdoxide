import datetime,hashlib,json,os,pathlib,re,shlex,subprocess,sys,time
PREFIX='/tmp/zstdoxide-module10-parameter-platform';manifest=json.loads(pathlib.Path(PREFIX+'-snapshot.json').read_text());ROOT=pathlib.Path(manifest['snapshot_directory']);TOOLCHAIN='nightly-2026-10-08';mode=sys.argv[1]
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def unchanged():return all(sha((ROOT/p).read_bytes())==digest for p,digest in manifest['files'].items())
assert unchanged()
features='unsafe-byte-cursor,unsafe-bitstream,unsafe-history,unsafe-ring-history,unsafe-fse,unsafe-fse-encoder,unsafe-huffman,unsafe-huffman-codebook,unsafe-match-table,unsafe-match-chain,unsafe-dictionary,unsafe-training'
selectors=['parameters::resolution_tests::'+v for v in ['raw_adjustment_uses_signed32_clamps_and_target_width_bounds','empty_adjustment_downsizes_hash_and_chain_before_flooring_window','row_hash_caps_apply_only_to_the_three_reference_row_strategies','request_resolution_preserves_initial_adjustment_before_strategy_override','source_hints_change_unknown_resolution_only_and_never_mutate_requests','checked_size_policy_is_specific_to_the_arithmetic_each_operation_uses']]
commands=[]
if mode in ['i686','s390x']:
 target=mode+'-unknown-linux-gnu';sysroot='/tmp/zstdoxide-platform-sysroot-'+mode
 assert (pathlib.Path(sysroot)/'lib/rustlib'/target/'lib').is_dir()
 env={'MIRI_SYSROOT':sysroot,'CARGO_TARGET_DIR':'/tmp/zstdoxide-platform-build-'+mode,'MIRIFLAGS':'-Zmiri-strict-provenance','CARGO_TERM_COLOR':'never'}
 for backend,flags in [('safe',[]),('all',['--all-features'])]:
  if mode=='i686':
   commands.append((mode+'-unit-'+backend,['cargo','+'+TOOLCHAIN,'miri','test','--offline','--locked','--target',target,'--lib',*flags,'parameters::','--','--test-threads=1'],env,26,None))
   commands.append((mode+'-integration-'+backend,['cargo','+'+TOOLCHAIN,'miri','test','--offline','--locked','--target',target,'--test','upstream_parameters',*flags,'--','--test-threads=1'],env,11,None))
  else:
   commands.append((mode+'-selected-'+backend,['cargo','+'+TOOLCHAIN,'miri','test','--offline','--locked','--target',target,'--lib',*flags,'--','--exact',*selectors,'--test-threads=1'],env,6,selectors))
else:
 assert mode=='thumb';target='thumbv6m-none-eabi';env={'CARGO_TARGET_DIR':'/tmp/zstdoxide-platform-build-thumb','CARGO_TERM_COLOR':'never'}
 for backend,flags in [('safe',[]),('all',['--features',features])]:
  commands.append(('thumb-library-'+backend,['cargo','+'+TOOLCHAIN,'check','--offline','--locked','-Z','build-std=core,alloc','--target',target,'--no-default-features','--lib',*flags],env,None,None))
report={'mode':mode,'revision':manifest['revision'],'snapshot':str(ROOT),'extra_integration_source':manifest['extra_uncommitted_file'],'commands':[],'running':True,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};result=pathlib.Path(PREFIX+'-'+mode+'-results.json')
for name,command,env,count,names in commands:
 log=pathlib.Path(PREFIX+'-'+name+'.log');start=time.monotonic();print('START '+name,flush=True)
 with log.open('wb')as out:r=subprocess.run(command,cwd=ROOT,env=os.environ|env,stdout=out,stderr=subprocess.STDOUT)
 raw=log.read_bytes();text=raw.decode(errors='replace');summaries=[{'passed':int(p),'failed':int(f),'ignored':int(i)}for p,f,i in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)];actual=re.findall(r'^test (\S+) \.\.\. ok$',text,re.M)
 matched=count is None or(len(actual)==count and len(set(actual))==count and summaries==[{'passed':count,'failed':0,'ignored':0}]and(names is None or set(names)==set(actual)))
 entry={'name':name,'cwd':str(ROOT),'command':command,'command_shell':shlex.join(command),'environment':env,'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':str(log),'log_sha256':sha(raw),'expected_test_count':count,'exact_selectors':names,'actual_passing_tests':actual,'summaries':summaries,'nonempty_expected_selection_verified':matched if count is not None else None,'snapshot_unchanged':unchanged()};report['commands'].append(entry);result.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(entry),flush=True)
 if r.returncode or not matched or not entry['snapshot_unchanged']:break
report.update(running=False,complete=len(report['commands'])==len(commands),snapshot_unchanged=unchanged());report['exit_code']=0 if report['complete'] and report['snapshot_unchanged'] and all(c['exit_code']==0 and c['nonempty_expected_selection_verified'] is not False for c in report['commands'])else 1;result.write_text(json.dumps(report,indent=2)+'\n');print(str(result)+' '+sha(result.read_bytes()),flush=True);sys.exit(report['exit_code'])
