#![no_std]
#![forbid(unsafe_code)]
#![allow(dead_code)]
#[path = "/Users/lanxingcan/Workspace/zstdoxize/src/constants.rs"]
mod constants;
#[path = "/Users/lanxingcan/Workspace/zstdoxize/src/optimal_price.rs"]
mod optimal_price;
