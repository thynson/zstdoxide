from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-optimal-scalar-checks');O.mkdir();env=os.environ.copy();env.update(CARGO_TARGET_DIR='/tmp/zstdoxide-tree-baseline-target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
paths=['Cargo.toml','Cargo.lock','src/constants.rs','src/optimal_price.rs','tests/reference_optimal_prices.rs','tests/support/optimal_price_fixture.rs','tests/fixtures/reference-optimal-prices/cases.bin'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths};rows=[]
def run(label,args,tests=None):
 log=O/(label+'.log');start=time.monotonic();print('START',label,flush=True)
 with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest());rows.append(r);print('END',label,p.returncode,flush=True)
 if tests is not None:
  counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)];r['tests']=counts
  if counts!=[tests]:raise ValueError('test totals '+label)
 if p.returncode:raise ValueError(label)
for name,flags in [('safe',[]),('all',['--all-features']),('release-all',['--release','--all-features'])]:run('scalar-'+name,['cargo','test','--offline','--locked',*flags,'--test','reference_optimal_prices'],(3,0,0))
for name,flags in [('safe',[]),('all',['--all-features'])]:run('clippy-'+name,['cargo','clippy','--offline','--locked','--test','reference_optimal_prices',*flags,'--','-D','warnings'])
run('format',['cargo','fmt','--all','--','--check'])
run('nostd-scalar',['rustc','--edition=2024','--crate-type=lib','--crate-name=optimal_scalar_nostd','/tmp/zstdoxide-optimal-scalar-nostd.rs','-D','warnings','-o',str(O/'liboptimal_scalar_nostd.rlib')])
(O/'nostd-wrapper.rs').write_bytes(Path('/tmp/zstdoxide-optimal-scalar-nostd.rs').read_bytes())
if source!={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}:raise ValueError('source changed')
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,tests=9,captured_queries_per_configuration=1420,qualification='Allocation-free preparatory scalar module, compiled through focused harness and standalone no_std wrapper; not yet added to library module graph or public dispatch. Every captured C query matches in safe/all/release-all. Private copied value records need no artificial unsafe implementation. Outside running Module16 matrix.'),sort_keys=True,indent=2)+'\n')
