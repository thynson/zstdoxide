import runpy,subprocess,sys
def forbidden(*a,**k): raise RuntimeError("SUBPROCESS_FORBIDDEN")
subprocess.run=forbidden
sys.argv=['/Users/lanxingcan/Workspace/zstdoxize/scripts/import_fast_collector.py',"--check"]
runpy.run_path('/Users/lanxingcan/Workspace/zstdoxize/scripts/import_fast_collector.py',run_name="__main__")
