from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');COL=ROOT/'tests/upstream/fast-collector';SCRIPT=ROOT/'scripts/import_fast_collector.py'
def require(ok,reason):
 if not ok:raise RuntimeError(reason)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,sort_keys=True,indent=2)+'\n')
def main(out):
 require(not out.exists(),'fresh controls dir');out.mkdir();commands=[]
 sources=[SCRIPT,ROOT/'tests/upstream/manifest.json',*sorted(p for p in COL.iterdir() if p.is_file())]
 state=lambda:[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in sources]
 before=state();env={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','TMP','TEMP')}|{'PYTHONDONTWRITEBYTECODE':'1','LANG':'C','LC_ALL':'C','TZ':'UTC'}
 def run(label,cmd,code,diagnostic):
  require(state()==before,'source/fixture changed before control')
  p=subprocess.run(cmd,cwd=out,env=env,text=True,capture_output=True,timeout=60)
  stdout=out/(label+'.stdout');stderr=out/(label+'.stderr');stdout.write_text(p.stdout);stderr.write_text(p.stderr)
  commands.append({'label':label,'command':cmd,'cwd':str(out),'environment':env,'exit_code':p.returncode,'expected_exit_code':code,'required_diagnostic':diagnostic,'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr),'stdout':stdout.name,'stderr':stderr.name})
  save(out/'commands.json',commands)
  require(p.returncode==code and diagnostic in p.stdout+p.stderr,f'{label}: {p.returncode}: {p.stdout}{p.stderr}')
  require(state()==before,'source/fixture changed after control')
 variants=[]
 def variant(name,change,diagnostic):
  target=out/name;shutil.copytree(COL,target);change(target);variants.append((name,target,diagnostic))
 def manifest_change(fn):
  def change(target):
   p=target/'manifest.json';d=json.loads(p.read_text());fn(d);save(p,d)
  return change
 variant('schema-bool',manifest_change(lambda d:d.__setitem__('schema_version',True)),'collector manifest schema/revision')
 variant('revision',manifest_change(lambda d:d.__setitem__('upstream_revision','0'*40)),'collector manifest schema/revision')
 variant('coverage',manifest_change(lambda d:d['coverage'].__setitem__('ordinary_frames',True)),'collector coverage scope')
 variant('generator-pin',manifest_change(lambda d:d.__setitem__('generator_sha256','0'*64)),'frozen C helper')
 variant('helper-bytes',lambda p:(p/'collector_oracle.c').write_bytes((p/'collector_oracle.c').read_bytes()+b'\n'),'frozen C helper')
 variant('support-pin',manifest_change(lambda d:d['repository_input_sha256'].__setitem__('tests/upstream/fast-collector/collector.py','0'*64)),'frozen support identities')
 variant('importer-pin',manifest_change(lambda d:d.__setitem__('importer_sha256','0'*64)),'current importer hash')
 variant('catalog-missing',manifest_change(lambda d:d['fixtures'].pop()),'exact collector fixture catalog')
 variant('catalog-duplicate',manifest_change(lambda d:d['fixtures'].append(d['fixtures'][0])),'exact collector fixture catalog')
 variant('catalog-size-bool',manifest_change(lambda d:d['fixtures'][0].__setitem__('size',True)),'exact collector fixture catalog')
 variant('catalog-digest',manifest_change(lambda d:d.__setitem__('fixture_catalog_sha256','0'*64)),'frozen collector observation and source identities')
 variant('source-digest',manifest_change(lambda d:d['source_sha256'].__setitem__('lib/compress/zstd_fast.c','0'*64)),'pinned source hash')
 variant('source-required-missing',manifest_change(lambda d:d['source_sha256'].pop('lib/compress/zstd_compress.c')),'required pinned collector sources')
 variant('metadata-detached',manifest_change(lambda d:d['capture']['metadata'].__setitem__('little_endian',False)),'captured metadata bound')
 variant('outcome-detached',manifest_change(lambda d:d['capture']['cases'][0].__setitem__('rows',1)),'observed outcome/corroboration summary')
 variant('original-evidence',manifest_change(lambda d:d['capture'].__setitem__('original_archive_sha256','0'*64)),'original immutable evidence references')
 variant('instrumentation',manifest_change(lambda d:d['capture']['instrumentation'].__setitem__('remaining_archive_instrumented',True)),'capture counts/instrumentation')
 variant('missing-file',lambda p:(p/'normal-width-4.stdout').unlink(),'missing or unlisted collector collection files')
 variant('unlisted-file',lambda p:(p/'extra').write_text('x'),'missing or unlisted collector collection files')
 def detached(target):
  p=target/'recipes.json';d=json.loads(p.read_text());d['case_count']=39;save(p,d)
  mp=target/'manifest.json';m=json.loads(mp.read_text());entry=next(x for x in m['fixtures'] if x['path']=='recipes.json');entry['size']=p.stat().st_size;entry['sha256']=sha(p)
  m['fixture_catalog_sha256']=hashlib.sha256(json.dumps(m['fixtures'],sort_keys=True,separators=(',',':')).encode()).hexdigest();save(mp,m)
 variant('rehashed-detachment',detached,'frozen collector observation and source identities')
 def symlink(target):
  p=target/'normal-width-4.stdout';p.unlink();p.symlink_to(COL/'normal-width-4.stdout')
 variant('outside-symlink',symlink,'collection path escapes')
 # A minimal cloned repository tests the before-import hash guard without
 # changing any shared repository file or running detached Python definitions.
 clone=out/'driver-root';(clone/'scripts').mkdir(parents=True);(clone/'tests/upstream/fast-collector').mkdir(parents=True)
 shutil.copyfile(SCRIPT,clone/'scripts/import_fast_collector.py');(clone/'tests/upstream/fast-collector/collector.py').write_text('raise RuntimeError("MUST NOT EXECUTE")\n')
 for optimized in (False,True):
  mode='optimized' if optimized else 'normal';prefix=[sys.executable,*(['-O'] if optimized else [])]
  run(mode+'-positive',prefix+[str(SCRIPT),'--check'],0,'no subprocess was used')
  for name,path,diagnostic in variants:run(mode+'-'+name,prefix+[str(SCRIPT),'--check','--collection',str(path)],1,diagnostic)
  run(mode+'-before-import',prefix+[str(clone/'scripts/import_fast_collector.py'),'--check'],1,'frozen replay driver before import')
  # Guarded dispatch proves offline checking cannot reach subprocess.run.
  spy=out/(mode+'-spy.py');spy.write_text('import runpy,subprocess,sys\ndef forbidden(*a,**k): raise RuntimeError("SUBPROCESS_FORBIDDEN")\nsubprocess.run=forbidden\nsys.argv=['+repr(str(SCRIPT))+',"--check"]\nrunpy.run_path('+repr(str(SCRIPT))+',run_name="__main__")\n')
  run(mode+'-subprocess-spy',prefix+[str(spy)],0,'no subprocess was used')
  run(mode+'-mixed-mode',prefix+[str(SCRIPT),'--check','--sanitize'],1,'--check is offline')
  upstream=Path('/tmp/zstdoxize-upstream-1.5.7');common=prefix+[str(SCRIPT),'--upstream',str(upstream)]
  probe=ROOT/'collector-output-must-not-exist';require(not probe.exists(),'probe absent')
  run(mode+'-protected-output',common+['--output',str(probe)],1,'regeneration output overlaps protected source');require(not probe.exists(),'no protected output created')
  output=out/(mode+'-must-not-exist')
  for label,report in [('inside-output',output/'normal-width-4.stdout'),('ancestor-output',out),('inside-repo',ROOT/'collector-report-must-not-exist')]:
   run(mode+'-report-'+label,common+['--output',str(output),'--report',str(report)],1,'preserve existing report' if report==out else 'report overlaps protected source or output')
   require(not output.exists(),'no output before report validation')
 summary={'status':'passed','commands':len(commands),'positive_controls':sum(c['expected_exit_code']==0 for c in commands),'expected_rejections':sum(c['expected_exit_code']!=0 for c in commands),'collection_mutations_per_mode':len(variants),'source_before':before,'source_after':state(),'commands_sha256':sha(out/'commands.json')}
 save(out/'summary.json',summary);print(json.dumps({k:v for k,v in summary.items() if k not in ('source_before','source_after')},indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args();main(args.output.resolve())
