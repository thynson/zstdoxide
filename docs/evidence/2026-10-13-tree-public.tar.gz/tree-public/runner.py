from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-public-checks');O.mkdir();env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/zstdoxide-tree-reader-target'
paths=sorted((R/'src').glob('*.rs'))+[R/n for n in ['Cargo.toml','Cargo.lock','tests/support/tree_frame_encode.rs','tests/reference_tree.rs','tests/reference_fast.rs','tests/reference_double_fast.rs','tests/reference_lazy.rs','tests/upstream_reference_fast.rs','src/reference_encode.rs','README.md','docs/reference-fast-usage.md']];source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};rows=[]
def run(label,args,tests=None):
 log=O/(label+'.log');start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
 b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest());rows.append(r);print(label,p.returncode,flush=True)
 if tests is not None:
  counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)];r['tests']=counts
  if counts!=[tests]:raise ValueError('test totals '+label)
 if label.startswith('public-'):
  counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)]
  if len(counts)!=5 or tuple(map(sum,zip(*counts)))!=(42,0,0):raise ValueError('public totals '+label)
  r['tests']=counts
 if p.returncode:raise ValueError(label)
selectors=['reference_frame_encode::tree_tests::tree_admission_preserves_selected_owners_and_predecessor_gates']
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree']),('all',['--all-features'])]:
 run('gate-'+name,['cargo','test','--offline','--locked',*flags,'--lib','--','--exact',*selectors],(1,0,0))
 run('public-'+name,['cargo','test','--offline','--locked',*flags,'--test','reference_tree','--test','reference_fast','--test','reference_double_fast','--test','reference_lazy','--test','upstream_reference_fast'])
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree'])]:
 run('nostd-'+name,['cargo','check','--offline','--locked','--no-default-features',*flags])
for name,flags in [('safe',[]),('all',['--all-features'])]:
 run('clippy-'+name,['cargo','clippy','--offline','--locked','--all-targets',*flags,'--','-D','warnings'])
run('format',['cargo','fmt','--all','--','--check'])
assert source=={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,tests=129,qualification='Public strategy-6 dispatch after private ordinary-state and independent-tuple gates; all original selector/numeric inputs retained, with source-only v5 error classification. Safe/tree/all public boundaries and exact allocator failures. Public C capture remains separate.'),sort_keys=True,indent=2)+'\n')
