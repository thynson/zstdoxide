from pathlib import Path
import json,shutil,hashlib
D=Path(__file__).parent;S=Path('/private/tmp/module30-final');N=Path('/private/tmp/module30-native');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=json.loads((D/'preflight.json').read_text());assert j['status']=='failed' and j['error']=="AssertionError('clippy')";P=D/'initial-native-chunk-lint';P.mkdir()
for name in ['preflight.json','preflight-format.log','preflight-clippy.log','preparation.json']:shutil.copyfile(D/name,P/name)
name='tests/frame_queries_native.rs';shutil.copyfile(S/name,P/'frame_queries_native.rs');old='assert!(expected.chunks_exact(2).all(|p| p == b"a\\0"));';new='let (pairs, remainder) = expected.as_chunks::<2>();\n                assert!(remainder.is_empty());\n                assert!(pairs.iter().all(|pair| pair == b"a\\0"));';s=(S/name).read_text();assert old in s;s=s.replace(old,new)
for p in [S/name,N/'replay-source'/name,N/'frame_queries_native.rs']:p.write_text(s)
pre=json.loads((D/'preparation.json').read_text());pre['source'][name]=sha(S/name);pre.update(prior_preflight_rejection_sha256=sha(P/'preflight.json'),repair='Final preflight rejects a newly linted constant chunks_exact use in the external native test. A typed as_chunks view plus explicit empty remainder check replaces it; production/query rows unchanged. Native adapter is re-executed on the final test source before matrix dispatch.');(D/'preparation.json').write_text(json.dumps(pre,indent=2)+'\n')
for name in ['preflight.json','preflight-format.log','preflight-clippy.log']:(D/name).unlink()
P=N/'initial-slice-chunks-replay';P.mkdir();old_replay=json.loads((N/'replay.json').read_text());assert old_replay['status']=='passed';shutil.copyfile(N/'replay.json',P/'replay.json');shutil.copyfile(D/'initial-native-chunk-lint/frame_queries_native.rs',P/'frame_queries_native.rs')
for row in old_replay['commands']:
 p=N/(row['label']+'-replay.log');shutil.copyfile(p,P/p.name);p.unlink()
(N/'replay.json').unlink()
