from pathlib import Path
import hashlib,json,shutil,datetime
D=Path(__file__).parent;S=Path('/private/tmp/module30-final');C=Path('/private/tmp/module30-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();S.mkdir()
for n in ['src','tests','test-support','benches']:shutil.copytree(C/n,S/n)
for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(C/n,S/n)
for name,origin in [('frame_queries_native.rs','module30-native/replay-source/tests'),('frame_queries_history.rs','module30-native-history/replay-source/tests'),('frame_queries_platform.rs','module30-platform/source/tests'),('upstream_decodecorpus.rs','module30-corpus/source/tests')]:shutil.copyfile(Path('/private/tmp')/origin/name,S/'tests'/name)
source={str(p.relative_to(S)):sha(p) for folder in ['src','tests','test-support'] for p in (S/folder).rglob('*') if p.is_file()};source.update({n:sha(S/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']})
(D/'preparation.json').write_text(json.dumps(dict(status='prepared',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source=source,production_source={n:h for n,h in source.items() if n.startswith('src/')},qualification='Final external Module30 candidate includes focused public query tests, native query/bound adapters, exact original-history replay, full copied-module foreign test and every decodecorpus structural supplement. Production matches the focused candidate; no promotion before Module29 closure.'),indent=2)+'\n')
