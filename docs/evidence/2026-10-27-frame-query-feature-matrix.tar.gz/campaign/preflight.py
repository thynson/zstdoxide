from pathlib import Path
import json,subprocess,hashlib,time,os
D=Path(__file__).parent;S=Path('/private/tmp/module30-final');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pre=json.loads((D/'preparation.json').read_text());assert pre['status']=='prepared'
for n,h in pre['source'].items():assert sha(S/n)==h,n
e=dict(status='running',source=pre['source'],commands=[])
def save():(D/'preflight.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for label,args in [('format',['cargo','fmt','--all','--','--check']),('clippy',['cargo','clippy','--offline','--locked','--lib','--tests','--all-features','--','-D','warnings'])]:
  t=time.monotonic()
  with (D/('preflight-'+label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module30-public-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'},stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/('preflight-'+label+'.log'))));save();assert p.returncode==0,label
 for n,h in pre['source'].items():assert sha(S/n)==h,n
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
