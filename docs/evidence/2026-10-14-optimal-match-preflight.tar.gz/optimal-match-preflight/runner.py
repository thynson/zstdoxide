from pathlib import Path
import hashlib,json,os,subprocess
root=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize');out=Path('/tmp/zstdoxide-optimal-match-preflight');out.mkdir()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');rows=[]
commands=[('plan-normal',['python3','scripts/check_optimal_match_capture_plan.py','--upstream','/private/tmp/zstdoxide-reference-lazy-1.5.7']),('plan-optimized',['python3','-O','scripts/check_optimal_match_capture_plan.py','--upstream','/private/tmp/zstdoxide-reference-lazy-1.5.7'])]
base=['clang','-std=c11','-g','-DDEBUGLEVEL=2','-DZSTD_DISABLE_ASM','-DZSTD_LEGACY_SUPPORT=0','-UZSTD_MULTITHREAD','-DXXH_NAMESPACE=ZSTD_','-I','/private/tmp/zstdoxide-reference-lazy-1.5.7/lib','-I','/private/tmp/zstdoxide-reference-lazy-1.5.7/lib/common','-I','/private/tmp/zstdoxide-reference-lazy-1.5.7/lib/compress']
for mode,flags in [('normal',['-O2']),('sanitized',['-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer'])]:
 commands.append(('syntax-'+mode,base+flags+['-Wall','-Wextra','-Werror','-fsyntax-only','scripts/oracles/optimal_matches_v1.c']))
for name,argv in commands:
 log=out/(name+'.log')
 with log.open('xb') as f:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 rows.append(dict(label=name,argv=argv,exit_code=r.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
 (out/'evidence.json').write_text(json.dumps(rows,indent=2)+'\n')
 if r.returncode:raise RuntimeError(name)
print('PASS',len(rows))
