from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');U=Path('/private/tmp/zstdoxide-reference-lazy-1.5.7');O=Path('/tmp/zstdoxide-tree-frame-helper-checks');O.mkdir();names=['scripts/oracles/tree_frame_v1.c','scripts/oracles/tree_frame_validation.py','scripts/check_tree_frame_validator.py','scripts/oracles/tree_frames.py','docs/reference-tree-frame-oracle.md'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in names};rows=[];cc=shutil.which('clang');assert cc
base=[cc,'-std=c11','-g','-I',str(U/'lib'),'-I',str(U/'lib/common'),'-I',str(U/'lib/compress'),'-UZSTD_MULTITHREAD','-DZSTD_DISABLE_ASM','-DZSTD_LEGACY_SUPPORT=0','-DXXH_NAMESPACE=ZSTD_','-Wall','-Wextra','-Werror','-Wno-deprecated-declarations']
commands=[('normal-syntax',base+['-O2','-fsyntax-only',str(R/'scripts/oracles/tree_frame_v1.c')]),('instrumented-syntax',base+['-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer','-fsyntax-only',str(R/'scripts/oracles/tree_frame_v1.c')]),('normal-replay',['python3','scripts/check_tree_frame_validator.py']),('optimized-replay',['python3','-O','scripts/check_tree_frame_validator.py'])]
for label,args in commands:
 start=time.monotonic();p=subprocess.run(args,cwd=R,capture_output=True,timeout=120);b=p.stdout+p.stderr;log=O/(label+'.log');log.write_bytes(b);rows.append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest()));print(label,p.returncode,flush=True)
 if p.returncode:raise ValueError(label)
 if label.endswith('replay'):
  value=json.loads(p.stdout);assert value['rejections']==80 and value['child_attempts']==0
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,forgery_rejections=160,qualification='Normal/instrumented helper syntax only; independent offline replay with synthetic controls. No tree frame C execution yet.'),sort_keys=True,indent=2)+'\n')
