from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-search-checks');O.mkdir();env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/zstdoxide-tree-reader-target'
paths=sorted((R/'src').glob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock',R/'tests/support/tree_oracle.rs',R/'tests/fixtures/reference-tree/cases.bin'];source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};rows=[]
def run(label,args,tests=None):
 log=O/(label+'.log');start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
 b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest());rows.append(r);print(label,p.returncode,flush=True)
 if tests is not None:
  counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)];r['tests']=counts
  if counts!=[tests]:raise ValueError('test totals '+label)
 if p.returncode:raise ValueError(label)
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree']),('all',['--all-features']),('release-all',['--release','--all-features'])]:
 run('search-'+name,['cargo','test','--offline','--locked',*flags,'--lib','tree_search::tests'],(4,0,0))
for name,flags in [('safe',[]),('all',['--all-features'])]:
 for module,count in [('tree_sort',5),('tree_source',1),('tree_layout',5),('reference_tree',7)]:
  run(module+'-'+name,['cargo','test','--offline','--locked',*flags,'--lib',module+'::tests'],(count,0,int(module=='reference_tree')))
 run('baseline-'+name,['cargo','test','--offline','--locked',*flags,'--test','reference_lazy_defaults'],(21,0,0))
 run('reader-'+name,['cargo','test','--offline','--locked',*flags,'--test','reference_tree_fixture'],(8,0,0))
 run('clippy-'+name,['cargo','clippy','--offline','--locked','--all-targets',*flags,'--','-D','warnings'])
flags=[n for n in __import__('tomllib').loads((R/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-')]
for name,fs in [('safe',[]),*[(n,['--features',n]) for n in flags],('all',['--features',','.join(flags)])]:
 run('nostd-'+name,['cargo','check','--offline','--locked','--no-default-features',*fs])
run('format',['cargo','fmt','--all','--','--check'])
assert source=={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,tests=110,exact_c_operations=9336,no_std_configurations=17,qualification='Four configurations each replay 2334 complete frozen direct C operations. Includes 58 permanent frame/allocator and independent reader regressions. Private parser/public tree admission still pending.'),sort_keys=True,indent=2)+'\n')
