use zstdoxide::{DictionaryTrainingOptions,RawTrainingOptions,finalize_dictionary,train_dictionary};
fn main() {
 let content:Vec<_>=(0..1024).map(|i|(i*37) as u8).collect();
 let samples=[&b"short"[..],&b"several repeated symbols aaaabbbbccccdddd"[..],&b"aaaabbbbccccddddeeee repeated suffix"[..]];
 let mut hash=0xcbf29ce484222325_u64; let mut cases=0;
 let mut add=|bytes:&[u8]|{for b in (bytes.len() as u32).to_le_bytes().iter().chain(bytes){hash=(hash^u64::from(*b)).wrapping_mul(0x100000001b3);}cases+=1;};
 for capacity in [256,512] {for id in [None,Some(u32::MAX)] {let options=DictionaryTrainingOptions{selection:RawTrainingOptions{dictionary_size:capacity,max_sample_bytes:1024,segment_size:16},dictionary_id:id};
 for length in [0,1,7,8,9,1024] {for samples in [&[][..],&samples[..]] {add(finalize_dictionary(&content[..length],samples,options).unwrap().as_bytes());}}
 for budget in [512,1024] {add(train_dictionary(&samples,DictionaryTrainingOptions{selection:RawTrainingOptions{max_sample_bytes:budget,..options.selection},..options}).unwrap().as_bytes());}
 }}
 println!("FORMATTED_BASELINE cases={cases} fnv64={hash}");
}
