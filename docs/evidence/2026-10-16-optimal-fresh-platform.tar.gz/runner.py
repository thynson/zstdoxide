from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-optimal-fresh-platform-1016');O.mkdir()
env={k:v for k,v in os.environ.items()if k in ['PATH','HOME','TMPDIR','CARGO_HOME','RUSTUP_HOME','SDKROOT','DEVELOPER_DIR']};env.update(RUSTUP_TOOLCHAIN='nightly-2026-10-08',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-fresh-miri-target-1016',MIRIFLAGS='-Zmiri-strict-provenance')
source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()for p in list((R/'src').rglob('*.rs'))+list((R/'tests').rglob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock']};commands=[]
selectors=['optimal_search::fresh_tests::direct_repeat_guards_remain_and_invalid_fresh_queries_preserve_state','optimal_search::fresh_tests::fresh_entry_rejects_unqualified_source_and_geometry_before_mutation','optimal_parse::fresh_tests::fresh_pair_rejects_source_parameters_and_used_search_before_parser_mutation','optimal_parse::fresh_tests::fresh_observer_failures_require_both_resets_and_preserve_external_output','optimal_parse::fresh_tests::fresh_moved_nonclone_owner_failures_release_every_allocation','optimal_parse::fresh_tests::fresh_borrowed_owners_never_allocate_during_parse_or_reset']
def save(status,error=None):
 (O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,commands=commands,qualification='Selected strict-provenance Miri checks on i686 and s390x; no native foreign execution claim.'),indent=2)+'\n')
try:
 for target in ['i686-unknown-linux-gnu','s390x-unknown-linux-gnu']:
  env['MIRI_SYSROOT']='/tmp/zstdoxide-platform-sysroot-'+target.split('-')[0]
  for mode,flags in [('safe',[]),('paths',['--features','unsafe-reference-tree,unsafe-optimal-short-key,unsafe-optimal-frequencies,unsafe-optimal-matches,unsafe-optimal-paths']),('all',['--all-features'])]:
   for i,test in enumerate(selectors):
    label=f'{target}-{mode}-{i}';cmd=['cargo','miri','test','--offline','--locked','--target',target,*flags,'--lib','--','--exact',test];print('START',label,flush=True)
    start=time.monotonic()
    with(O/(label+'.log')).open('wb')as f:p=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
    data=(O/(label+'.log')).read_bytes();commands.append(dict(label=label,argv=cmd,exit_code=p.returncode,seconds=time.monotonic()-start,log=label+'.log',sha256=hashlib.sha256(data).hexdigest()));save('running')
    if p.returncode or b'test result: ok. 1 passed; 0 failed;'not in data:raise RuntimeError(label)
    print('END',label,flush=True)
 assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in source.items())
 save('passed')
except BaseException as e:save('failed',repr(e));raise
