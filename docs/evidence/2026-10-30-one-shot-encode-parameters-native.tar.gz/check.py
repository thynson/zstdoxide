"""Supplementary module36 guarded native schedules for parameterized
dictionary calls.

Normal and sanitized builds of the pinned v1.5.7 library run typed supported and
explicitly rejected cases with observable fresh controls. Rust frames decode
natively and native frames decode in Rust; native compressed-byte identity is
not required. No original fuzzer group or milestone closure is claimed.
"""
from pathlib import Path
import os, subprocess, json, hashlib, time, datetime, re, signal, shutil

D = Path(__file__).parent
S = D / 'source'
U = Path('/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
deadline = datetime.datetime.fromisoformat('2026-10-30T08:40:00+00:00').timestamp()
assert deadline - time.time() >= 120
source = {}
for folder in ['src', 'tests', 'test-support']:
    for p in (S / folder).rglob('*'):
        if p.is_file():
            source[str(p.relative_to(S))] = sha(p)
for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']:
    source[n] = sha(S / n)
library = {str(p.relative_to(U)): sha(p) for p in (U / 'lib').rglob('*')
           if p.is_file() and p.suffix in ['.c', '.h', '.S']}
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         deadline_utc='2026-10-30T08:40:00+00:00', source=source,
         production_source={n: h for n, h in source.items() if n.startswith('src/')},
         reference_revision='f8745da6ff1ad1e7bab384bd1f9d742439278e99',
         library=library, helper_sha256=sha(D / 'one_shot_encode_parameters_oracle.c'),
         commands=[], qualification='Supplementary guarded native schedules only: 20 typed parameterized dictionary cases cover the admitted Fast/DoubleFast/Greedy/Lazy/Lazy2/BinaryTreeLazy2 profiles, prepared entropy, empty and window-bounded inputs, and five fresh/retained optimal-family rejections against normal and sanitized pinned v1.5.7 controls. Rust frames decode natively and native frames decode in Rust; native byte/capacity/workspace identity is not required. No original fuzzer group, platform, matrix, timing or milestone closure is claimed.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(D / 'target'), 'CARGO_BUILD_JOBS': '6',
       'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
       'CARGO_PROFILE_TEST_OPT_LEVEL': '1'}


def save():
    (D / 'evidence.json').write_text(json.dumps(e, indent=2) + '\n')


def run(label, args, extra=None, cwd=S, expected=None):
    remaining = deadline - time.time() - 15
    if remaining < 15:
        raise TimeoutError('deadline before ' + label)
    e['active_command'] = dict(label=label, argv=args, environment=extra or {},
                               started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    start = time.monotonic()
    log = D / (label + '.log')
    with log.open('xb') as f:
        p = subprocess.Popen(args, cwd=cwd, env={**env, **(extra or {})}, stdout=f,
                             stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = p.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGTERM)
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                p.wait()
            raise TimeoutError('deadline during ' + label)
    row = dict(label=label, argv=args, environment=extra or {}, exit_code=code,
               seconds=time.monotonic() - start, log_sha256=sha(log))
    if code == 0 and expected is not None:
        groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text())
        assert groups == [(str(expected), '0', '0')], (label, groups)
        row.update(passed=expected, failed=0, ignored=0)
    e['commands'].append(row)
    e.pop('active_command', None)
    save()
    print(label, code, flush=True)
    assert code == 0, (label, log.read_text()[-4000:])


def inventory(folder):
    return {str(p.relative_to(folder)): sha(p) for p in folder.rglob('*') if p.is_file()}


save()
try:
    export = D / 'safe-export'
    export.mkdir()
    run('safe-export', ['cargo', 'test', '--offline', '--locked', '--test',
                        'one_shot_encode_parameters_native',
                        'parameterized_dictionary_schedules_interoperate_with_guarded_native_controls',
                        '--', '--ignored', '--exact', '--nocapture'],
        dict(ZSTDOXIDE_ONE_SHOT_ENCODE_PARAMETERS_NATIVE=str(export),
             ZSTDOXIDE_ONE_SHOT_ENCODE_PARAMETERS_EXPORT='1'), expected=1)
    exported = inventory(export)
    e['inputs'] = exported
    save()
    sources = sorted((U / 'lib/common').glob('*.c')) + sorted((U / 'lib/decompress').glob('*.c')) + sorted((U / 'lib/compress').glob('*.c'))
    for label, flags in [('normal', ['-O2']),
                         ('sanitized', ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer'])]:
        exe = D / ('oracle-' + label)
        run(label + '-build', ['cc', '-std=c99', '-Wall', '-Wextra', '-Werror', '-DZSTD_MULTITHREAD=0',
                               '-I' + str(U / 'lib'), '-I' + str(U / 'lib/common'), *flags,
                               str(D / 'one_shot_encode_parameters_oracle.c'),
                               *[str(p) for p in sources], '-o', str(exe)])
        e.setdefault('executables', {})[label] = sha(exe)
        save()
        output = D / (label + '-outputs')
        output.mkdir()
        run(label + '-capture', [str(exe), str(export), str(output)],
            dict(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',
                 UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'), cwd=D)
        shutil.copyfile(D / (label + '-capture.log'), D / (label + '.tsv'))
    normal = (D / 'normal.tsv').read_text().splitlines()
    assert len(normal) == 20, len(normal)
    assert (D / 'normal.tsv').read_bytes() == (D / 'sanitized.tsv').read_bytes()
    assert inventory(D / 'normal-outputs') == inventory(D / 'sanitized-outputs')
    outputs = inventory(D / 'normal-outputs')
    assert len(outputs) == 20  # one native frame per case
    rows = [line.split('\t') for line in normal]
    assert all(len(row) == 8 for row in rows)
    assert all(row[1] == 'ok' and row[7] == '1' for row in rows)
    assert sum(row[5] == '1' for row in rows) == 15
    assert sum(row[5] == '-1' for row in rows) == 5
    e.update(rows=20, supported=15, rejected=5, outputs=outputs)
    save()
    replay = D / 'replay'
    replay.mkdir()
    shutil.copytree(export / 'inputs', replay / 'inputs')
    shutil.copyfile(export / 'steps.tsv', replay / 'steps.tsv')
    shutil.copyfile(D / 'normal.tsv', replay / 'native.tsv')
    shutil.copytree(D / 'normal-outputs', replay / 'outputs')
    for label, flags in [('safe', []), ('all', ['--all-features'])]:
        run(label + '-replay', ['cargo', 'test', '--offline', '--locked', '--test',
                                'one_shot_encode_parameters_native',
                                'parameterized_dictionary_schedules_interoperate_with_guarded_native_controls',
                                '--', '--ignored', '--exact', '--nocapture'],
            dict(ZSTDOXIDE_ONE_SHOT_ENCODE_PARAMETERS_NATIVE=str(replay)), expected=1)
        run(label + '-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--test',
                                'one_shot_encode_parameters_native', *flags, '--', '-D', 'warnings'])
    run('format', ['cargo', 'fmt', '--all', '--', '--check'])
    for n, h in source.items():
        assert sha(S / n) == h, ('Source changed during the campaign', n)
    e.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
except TimeoutError as ex:
    e.update(status='interrupted-at-deadline', error=repr(ex)); save(); raise
except BaseException as ex:
    e.update(status='failed', error=repr(ex)); save(); raise
