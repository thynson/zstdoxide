"""Archive the qualified module36 guarded native parameterized schedules."""
from pathlib import Path
import json, hashlib, tarfile, re, datetime

D = Path(__file__).parent
C = Path('/private/tmp/module36-native')
S = C / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
j = json.loads((C / 'evidence.json').read_text())
assert j['status'] == 'passed' and len(j['commands']) == 10
for n, h in j['source'].items():
    assert sha(S / n) == h, n
for r in j['commands']:
    assert r['exit_code'] == 0 and sha(C / (r['label'] + '.log')) == r['log_sha256']
files = {}
for p in C.rglob('*'):
    if not p.is_file():
        continue
    n = p.relative_to(C)
    if any(x == 'target' or x.endswith('-target') or x == '__pycache__' or x in {'source', 'safe-export', 'normal-outputs', 'sanitized-outputs', 'replay'} for x in n.parts):
        continue
    if n.name.startswith('oracle-'):
        continue
    if p.suffix in {'.rs', '.toml', '.lock', '.json', '.py', '.log', '.md', '.tsv', '.c'}:
        files[str(n)] = p
files['archive-native.py'] = Path(__file__)
name = '2026-10-30-one-shot-encode-parameters-native'
archive = D / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
r = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source=j['source'], production_source=j['production_source'], reference_revision=j['reference_revision'], library=j['library'], helper_sha256=j['helper_sha256'], commands=j['commands'], rows=j['rows'], supported=j['supported'], rejected=j['rejected'], inputs=j['inputs'], outputs=j['outputs'], executables=j['executables'], members={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()}, archive=archive.name, archive_sha256=sha(archive), qualification="Supplementary guarded native schedules only: 20 typed parameterized dictionary cases cover the admitted Fast/DoubleFast/Greedy/Lazy/Lazy2/BinaryTreeLazy2 profiles, prepared entropy, empty and window-bounded inputs, and five fresh/retained optimal-family rejections against normal and sanitized pinned v1.5.7 controls. Rust frames decode natively and native frames decode in Rust; native byte/capacity/workspace identity is not required. No original fuzzer group, corpus, platform, matrix, timing or milestone closure is claimed.")
(D / (name + '.json')).write_text(json.dumps(r, indent=2) + '\n')
print(name, archive.stat().st_size)
