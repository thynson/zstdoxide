"""Promote the qualified module36 guarded native parameterized schedules."""
from pathlib import Path
import json, hashlib, subprocess, shutil

D = Path(__file__).parent
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
S = Path('/private/tmp/module36-native/source')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = Path('/private/tmp/module36-archives/promotion-state.json')
prev = json.loads(state.read_text())
assert prev['stage'] == 'public-api'
assert prev['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == prev['production_source']
name = '2026-10-30-one-shot-encode-parameters-native'
p = D / (name + '.json')
r = json.loads(p.read_text())
assert r['status'] == 'passed' and sha(D / r['archive']) == r['archive_sha256']
changed = []
for n in ['tests/one_shot_encode_parameters_native.rs']:
    assert sha(S / n) == r['source'][n], n
    shutil.copyfile(S / n, R / n)
    changed.append(n)
for q in [p, D / r['archive']]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
    changed.append('docs/evidence/' + q.name)
p = R / 'TODO.md'
s = p.read_text()
task = '- [ ] Qualify parameterized dictionary schedules, unsupported-strategy rejection and window expiry against guarded native controls and deterministic selections.'
assert s.count(task) == 1
s = s.replace(task, task.replace('[ ]', '[x]'))
p.write_text(s)
changed.append('TODO.md')
p = R / 'docs/one-shot-encode-parameters-validation.md'
s = p.read_text()
old = '''Native/corpus/platform validation, the complete feature/release regression,
measurements and reconciliation remain open.'''
assert s.count(old) == 1
s = s.replace(old, '''Corpus/platform validation, the complete feature/release regression,
measurements and reconciliation remain open.''')
old = '''Evidence: `evidence/2026-10-30-one-shot-encode-parameters-public-api.json`.'''
assert s.count(old) == 1
s = s.replace(old, old + '''

## Guarded native parameterized schedules

Twenty typed parameterized dictionary cases run against normal and sanitized
builds of the pinned v1.5.7 library: Fast, DoubleFast, Greedy, Lazy, Lazy2 and
BinaryTreeLazy2 with raw and prepared attachments, empty input, prepared
entropy, window-bounded inputs, multiblock sources, and five fresh/retained
Optimal/Ultra/Ultra2 profiles that Rust rejects before writing. Every native row
uses independent 16-byte destination guards; both builds produce the same
twenty rows and twenty native frames. Rust frames decode natively and native
frames decode in Rust for every case, and each observable dictionary control
differs from its fresh no-dictionary control. Native compressed-byte,
capacity-precedence and workspace identity are not Rust contracts; the
window-bounded cases establish interoperation and Rust-side suffix expiry is
covered by the focused unit campaign rather than a native byte-equality claim.

Ten commands pass: Rust input export, normal and sanitized oracle builds and
captures, safe and all-feature replays and strict Clippy, and formatting.
Evidence: `evidence/{name}.json`.'''.format(name=name))
p.write_text(s)
changed.append('docs/one-shot-encode-parameters-validation.md')
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *changed], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Qualify parameterized dictionary calls against guarded native schedules'], cwd=R, check=True)
prev.update(stage='native', head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(), production_source={str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')})
state.write_text(json.dumps(prev, indent=2) + '\n')
print('module36 guarded native schedules promoted at', prev['head'][:12])
