import subprocess,json,pathlib
root=pathlib.Path('/tmp/zstdoxide-lazy-one-final')
commands=[['cargo','fmt','--check'],['cargo','clippy','--all-targets','--','-D','warnings'],['cargo','clippy','--all-targets','--all-features','--','-D','warnings']]
for features in [[],['--features','unsafe-reference-chain'],['--features','unsafe-row-table'],['--all-features']]:
 for name in ['greedy_parse::tests']:
  commands.append(['cargo','test','--lib',*features,name])
 commands.append(['cargo','check','--no-default-features',*features])

records=[]
for i,command in enumerate(commands):
 with (root/f'{i:02}.log').open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 records.append({'command':command,'status':r.returncode,'log':f'{i:02}.log'})
 print(i,r.returncode,' '.join(command),flush=True)
 (root/'results.json').write_text(json.dumps(records,indent=2)+'\n')
 if r.returncode:break
