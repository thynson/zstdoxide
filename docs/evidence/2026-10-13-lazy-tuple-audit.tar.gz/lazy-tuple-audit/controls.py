from pathlib import Path
from types import SimpleNamespace
import csv,hashlib,json,sys
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(ROOT/'scripts'))
import check_lazy_interop_capture_v2 as m
attempts=[]
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec','os.spawn'):
  attempts.append(event);raise RuntimeError('no children')
sys.addaudithook(audit)
table=m.presets();before=json.dumps(table,default=str) if False else repr(table)
known=ROOT/'tests/upstream/parameters/requests.tsv'
# Identity is already pinned in the official fixture inventory; additionally
# record it in the result so this independent comparison remains reproducible.
compared=0
for row in csv.DictReader(known.open(),delimiter='\t'):
 level=int(row['level'])
 if not 1<=level<=22:continue
 controls=tuple(int(row[k]) for k in ('level','window_log','chain_log','hash_log','search_log','min_match','target_length','strategy','source_hint'))
 for size,prefix in [(0,'empty'),(16385,'known')]:
  expected=[int(row[prefix+'_'+k]) for k in ('window','chain','hash','search','match','target','strategy')]
  actual=m.resolved_new_request(SimpleNamespace(source=bytes(size),request=controls),table)
  m.require(actual==expected,'independent original C requested tuple '+row['scenario']+'/'+row['step']+'/'+prefix)
  compared+=1
m.require(repr(table)==before,'preset ownership unchanged')
controls=[]
def reject(name,fn):
 try:fn()
 except (ValueError,TypeError):controls.append(name)
 else:raise ValueError('accepted '+name)
base=(6,21,18,19,8,4,0,4,0)
for source in ['',bytearray(),None,bytes((4<<20)+1)]:
 reject('source-'+str(type(source))+'-'+str(len(source) if source is not None else 0),lambda:m.resolved_new_request(SimpleNamespace(source=source,request=base),table))
for value in [list(base),base[:-1],base+(0,),None]:reject('request-'+repr(value),lambda:m.resolved_new_request(SimpleNamespace(source=b'',request=value),table))
for i in range(9):
 for value in [True,1.0,'1']:
  changed=list(base);changed[i]=value;changed=tuple(changed)
  reject(f'type-{i}-{value!r}',lambda:m.resolved_new_request(SimpleNamespace(source=b'',request=changed),table))
for i,value in [(0,0),(0,23),(1,9),(1,32),(2,5),(2,31),(3,5),(3,31),(4,31),(5,2),(5,8),(6,131073),(7,10),(8,-1),(8,1<<31)]:
 changed=list(base);changed[i]=value;changed=tuple(changed)
 reject(f'bound-{i}-{value}',lambda:m.resolved_new_request(SimpleNamespace(source=b'',request=changed),table))
m.require(not attempts,'zero children')
print(json.dumps(dict(optimized=not __debug__,original_c_tuples=compared,requests_sha256=hashlib.sha256(known.read_bytes()).hexdigest(),controls=controls,child_attempts=len(attempts)),sort_keys=True,indent=2))
