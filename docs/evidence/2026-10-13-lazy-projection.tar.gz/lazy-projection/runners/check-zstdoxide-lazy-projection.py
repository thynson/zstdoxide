from pathlib import Path
from unittest.mock import patch
import contextlib,copy,hashlib,json,os,struct,subprocess,sys
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(R/'scripts'))
F=R/'tests/fixtures/reference-lazy';calls=[]
def require(x,why):
 if not x:raise ValueError(why)
def forbidden(*a,**k):calls.append(1);raise RuntimeError('child process prohibited')
class Reader:
 def __init__(self,b,base=0):self.b=b;self.p=0;self.base=base
 def take(self,n):
  require(0<=n<=len(self.b)-self.p,'bounded read');out=self.b[self.p:self.p+n];self.p+=n;return out
 def num(self,n=4):return int.from_bytes(self.take(n),'little')
 def nums(self,n):return [self.num() for _ in range(n)]
 def blob(self,cap):
  n=self.num();require(n<=cap,'blob cap');return self.take(n)
 def records(self,cap,width):
  n=self.num();require(n<=cap and n*width*4<=len(self.b)-self.p,'record cap');return [self.nums(width) for _ in range(n)]
 def finish(self):require(self.p==len(self.b),'exact EOF')
def unpack(data,expected):
 require(len(data)<=64<<20,'collection cap');r=Reader(data);require(r.take(8)==b'ZLZST01\0','magic');require(r.num()==645,'count');offsets={};extents={}
 for case,row in expected:
  length=r.num();require(length<=32<<20,'body cap');start=r.p;body=r.take(length);b=Reader(body,start)
  def mark(label):offsets[case.name,label]=b.base+b.p
  mark('depth');require(b.num(1)==case.depth,'depth selector');mark('reserved');require(b.take(3)==bytes(3),'zero reserved selector bytes')
  mark('name_length');n=b.num(2);require(1<=n<=63,'name width');require(b.take(n)==case.name.encode('ascii'),'case identity')
  mark('parameters');require(list(b.take(8))==[case.branch,case.window_log,case.hash_log,case.chain_log,case.search_log,case.min_match,row['key_width'],row['row_log']],'parameters')
  mark('state');require(b.nums(20)==[case.target,case.prefix,case.floor,case.next,*case.repeats,*row['parser_repeats'],*row['wire_repeats'],row['trailing_literals'],row['initial_current'],row['repeat_floor'],row['final_next_to_update'],row['final_lazy_skipping'],case.entropy,row['final_entropy']],'state fields')
  mark('salts');require([b.num(8),b.num(8)]==[case.salt,int(row['final_salt'],16)],'salt fields')
  mark('cache');require(b.nums(8)==row['hash_cache'],'cache fields')
  mark('long_length');require((b.num(1),b.num())==(row['long_length_type'],row['long_length_position']),'long marker')
  mark('source_length');require(b.blob((2<<20)+(128<<10))==case.source,'source bytes')
  mark('source_hash');require(b.num(8)==int(row['source_fnv1a64'],16),'source hash')
  mark('seeds');require([x[0] for x in b.records(524288,1)]==list(case.seeds),'seed records')
  mark('literals');require(b.blob(128<<10)==bytes.fromhex(row['stored_literals_hex']),'literal bytes')
  mark('sequences');require(b.records(case.block//3+1,6)==[[s[k] for k in ('raw_ll','raw_ml_base','ll','ml','distance','off_base')] for s in row['sequences']],'sequence records')
  for name in ('first_table','second_table'):
   t=row[name];mark(name+'-geometry');require((b.num(1),b.num(1),b.num(2))==(t['element_bytes'],t['log'],0),'owner geometry')
   mark(name+'-before');require(b.records(1<<t['log'],2)==t['before'],'complete initial owner map')
   mark(name+'-changes');require(b.records(1<<t['log'],3)==t['changes'],'complete final owner deltas')
   mark(name+'-hashes');require([b.num(8),b.num(8)]==[int(t['before_fnv1a64'],16),int(t['after_fnv1a64'],16)],'complete owner fingerprints')
  b.finish();extents[case.name]={'offset':start,'bytes':length,'sha256':hashlib.sha256(body).hexdigest()}
 r.finish();return offsets,extents
with contextlib.ExitStack() as stack:
 for module,name in [(subprocess,'Popen'),(os,'system'),(os,'posix_spawn'),(os,'posix_spawnp')]:
  if hasattr(module,name):stack.enter_context(patch.object(module,name,forbidden))
 import pack_lazy_parser_fixtures as packer
 # The generator checks both capture-checker identities before any of their code
 # runs; then each capture checker admits its recipe module before import.
 for name,digest in packer.CHECKERS.items():require(hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,'checker pin')
 import check_lazy_family_fixture as checker
 accepted,observed=checker.fixture()
 import check_lazy_family_recipes as inputs
 g,cases,_=inputs.inputs()
 expected=[(c,g.records(observed[c.name])[1]) for c in cases]
 original=(F/'cases.bin').read_bytes();metadata=json.loads((F/'provenance.json').read_bytes())
 offsets,extents=unpack(original,expected)
 require(metadata['records']==extents and metadata['fixture']['bytes']==len(original) and metadata['fixture']['sha256']==hashlib.sha256(original).hexdigest(),'independent provenance extents')
 rejected=[]
 def reject(label,data):
  try:unpack(data,expected)
  except (ValueError,KeyError,TypeError):rejected.append(label);print('rejected: '+label,file=sys.stderr,flush=True)
  else:raise RuntimeError('accepted mutation '+label)
 def change(label,offset,width,value):
  data=bytearray(original);data[offset:offset+width]=value.to_bytes(width,'little');reject(label,bytes(data))
 first=expected[0][0].name
 change('signature',0,1,0);change('case-count',8,4,644);change('oversized-body',12,4,0xffffffff)
 for label,field,width,value in [('empty-name','name_length',2,0),('bad-branch','parameters',1,2),('bad-target','state',4,131073),('bad-salt','salts',8,1),('bad-cache','cache',4,0xffffffff),('bad-long-kind','long_length',1,3),('huge-source','source_length',4,0xffffffff),('bad-source-hash','source_hash',8,0),('huge-seed-count','seeds',4,0xffffffff),('huge-literals','literals',4,0xffffffff),('huge-sequences','sequences',4,0xffffffff),('bad-owner-width','first_table-geometry',1,3),('huge-owner-before','first_table-before',4,0xffffffff),('huge-owner-changes','first_table-changes',4,0xffffffff),('bad-owner-fingerprint','first_table-hashes',8,0)]:change(label,offsets[first,field],width,value)
 reject('truncated-source-collection',original[:-1]);reject('trailing-byte',original+b'\0')
 change('changed-row-entropy',offsets['d0-row-entropy-wrap','state']+19*4,4,0)
 change('changed-second-owner',offsets['d0-row-width-64-insertions-65','second_table-hashes'],8,0)
 change('changed-match-sequence',offsets['d0-chain-long-match-65543','sequences']+4+3*4,4,65538)
 change('changed-seed-order',offsets['d0-chain-cyclic-prefix-63','seeds']+4,4,1)
 change('invalid-depth',offsets[first,'depth'],1,3)
 change('wrong-valid-depth',offsets[first,'depth'],1,1)
 change('reserved-selector',offsets[first,'reserved'],1,1)
 change('lazy-score-sequence',offsets['d2-row-explicit-depth-2-above','sequences']+4+3*4,4,9)
 # A final positive decode checks that controls did not modify the real fixture.
 require((F/'cases.bin').read_bytes()==original,'fixture unchanged');unpack(original,expected)
 require(not calls,'subprocess use')
print(json.dumps({'status':'passed','records':645,'positive':2,'rejected':len(rejected),'controls':rejected,'child_processes':len(calls),'optimized':not __debug__,'fixture_sha256':hashlib.sha256(original).hexdigest()},sort_keys=True))
