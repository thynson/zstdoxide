from pathlib import Path
from unittest.mock import patch
import contextlib,hashlib,io,json,os,shutil,subprocess,sys,tempfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(R/'scripts'))
import pack_lazy_parser_fixtures as p
source=p.DESTINATION;raw=(source/'cases.bin').read_bytes();metadata=(source/'provenance.json').read_bytes()
root=Path(tempfile.mkdtemp(prefix='zstdoxide-lazy-projection-io-',dir='/tmp'));p.DESTINATION=root/'output'
calls=[];positive=0;rejected=[]
def require(x,why):
 if not x:raise ValueError(why)
def denied(*a,**k):calls.append(1);raise RuntimeError('subprocess forbidden')
def invoke(reject=None):
 global positive
 with patch.object(sys,'argv',['packer','--write']),contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
  try:p.main()
  except SystemExit as e:
   require(reject is not None and e.code==1,'expected rejection');rejected.append(reject)
  else:require(reject is None,'accepted changed output');positive+=1
try:
 with contextlib.ExitStack() as stack:
  for module,name in [(subprocess,'Popen'),(os,'system'),(os,'posix_spawn'),(os,'posix_spawnp')]:
   if hasattr(module,name):stack.enter_context(patch.object(module,name,denied))
  # I/O-policy controls reuse the separately verified immutable projection. This
  # stub does not test or bypass source admission in the independent replay suite.
  stack.enter_context(patch.object(p,'projection',lambda:(raw,metadata)))
  invoke();invoke()
  require((p.DESTINATION/'cases.bin').read_bytes()==raw and (p.DESTINATION/'provenance.json').read_bytes()==metadata,'positive publication')
  cases=p.DESTINATION/'cases.bin';provenance=p.DESTINATION/'provenance.json'
  changed=raw[:-1]+bytes([raw[-1]^1]);cases.write_bytes(changed)
  invoke('changed-case-bytes');require(cases.read_bytes()==changed,'refused overwrite');cases.write_bytes(raw)
  provenance.write_bytes(b'{}\n');invoke('changed-provenance');require(provenance.read_bytes()==b'{}\n','metadata not overwritten')
  cases.unlink();invoke('no-partial-publication');require(not cases.exists(),'preflight before any write');provenance.write_bytes(metadata)
  cases.symlink_to(source/'cases.bin');invoke('symlink-output');require(cases.is_symlink() and (source/'cases.bin').read_bytes()==raw,'symlink target unchanged')
  require(not calls,'no child processes')
 print(json.dumps({'status':'passed','positive':positive,'rejected':len(rejected),'controls':rejected,'child_processes':len(calls),'optimized':not __debug__,'scope':'Publication policy only; independently validated projection bytes substituted for generation.'},sort_keys=True))
finally:shutil.rmtree(root)
