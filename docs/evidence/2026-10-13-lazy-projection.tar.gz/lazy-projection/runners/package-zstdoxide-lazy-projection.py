from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');T=Path('/tmp');E=R/'docs/evidence'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,s):
 if not v:raise ValueError(s)
files={}
for mode in ('normal','optimized'):
 for kind,count in [('',28),('-publication',4)]:
  n='zstdoxide-lazy-projection'+kind+'-'+mode+'.json';b=(T/n).read_bytes();v=json.loads(b)
  need(v['status']=='passed' and (v['positive'],v['rejected'],v['child_processes'])==(2,count,0),'controls');files[n]=b
for n in ['check-zstdoxide-lazy-projection.py','check-zstdoxide-lazy-projection-publication.py','package-zstdoxide-lazy-projection.py']:files['runners/'+n]=(T/n).read_bytes()
for action in ('write','check'):
 for stream in ('stdout','stderr'):files[action+'.'+stream]=(T/('zstdoxide-lazy-projection-'+action+'.'+stream)).read_bytes()
 need(not files[action+'.stderr'],'projection diagnostics')
for n in ['scripts/pack_lazy_parser_fixtures.py','scripts/check_lazy_family_fixture.py','tests/fixtures/reference-lazy/README.md','tests/fixtures/reference-lazy/cases.bin','tests/fixtures/reference-lazy/provenance.json','scripts/check.sh']:files['source/'+n]=(R/n).read_bytes()
p=json.loads(files['source/tests/fixtures/reference-lazy/provenance.json']);need(p['generator_sha256']==sha(files['source/scripts/pack_lazy_parser_fixtures.py']),'generator identity')
need(p['fixture']['sha256']==sha(files['source/tests/fixtures/reference-lazy/cases.bin']),'fixture identity')
report=dict(date='2026-10-13',status='passed',records=645,fixture_bytes=p['fixture']['bytes'],fixture_sha256=p['fixture']['sha256'],source_manifest_sha256=p['source_collections'][0]['capture_sha256'],generator_sha256=p['generator_sha256'],independent_controls_per_mode=dict(positive=2,rejected=28,child_processes=0),publication_controls_per_mode=dict(positive=2,rejected=4,child_processes=0),qualification='Independent reader compares all input/state/source/sequence/map fields and record extents against immutable C observations. Publication controls substitute already validated bytes and test only refusal to overwrite or partially publish changed expectations. CLI write/check, shell syntax, formatting and diff checks passed. No new C execution, Rust parser, ordinary/public frame or timing claim.',archive='2026-10-13-lazy-projection.tar.gz')
files['report.json']=enc(report);files['manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())});a=E/report['archive'];need(not a.exists(),'fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('lazy-projection/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a,'r|gz') as t:actual={m.name:t.extractfile(m).read() for m in t}
need(actual=={'lazy-projection/'+n:b for n,b in files.items()},'exact archive readback')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files));(E/'2026-10-13-lazy-projection.json').write_bytes(enc(report));print(report)
