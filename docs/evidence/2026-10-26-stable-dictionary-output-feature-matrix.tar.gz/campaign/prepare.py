from pathlib import Path
import json,hashlib,shutil,subprocess
T=Path('/private/tmp');R=T/'module26-candidate';D=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
gates={}
for name,path,count in [('sink','module26-sink/evidence.json',17),('engine','module26-engine/evidence.json',17),('public','module26-candidate/public.json',24),('native','module26-native/rust.json',5),('platform','module26-platform/evidence.json',8),('fuzz','module26-fuzz/focused.json',7)]:
 p=T/path;j=json.loads(p.read_text());assert j['status']=='passed' and len(j['commands'])==count and all(c['exit_code']==0 for c in j['commands']),name;gates[name]=sha(p)
assert (T/'module26-archives/2026-10-26-stable-dictionary-output-public-api.tar.gz').exists(),'Archive focused snapshot before test additions'
assert not (D/'preparation.json').exists()
changes={}
for source,dest in [('module26-fuzz/source/tests/upstream_trained_dictionary_fuzz.rs','tests/upstream_trained_dictionary_fuzz.rs'),('module26-native/rust/stable_dictionary_output_native.rs','tests/stable_dictionary_output_native.rs'),('module26-platform/stable_dictionary_output_platform.rs','tests/stable_dictionary_output_platform.rs')]:
 old=sha(R/dest) if (R/dest).exists() else None;shutil.copyfile(T/source,R/dest);changes[dest]=dict(before=old,after=sha(R/dest),qualified_source=source)
m=json.loads((R/'tests/upstream/manifest.json').read_text())
targets={f'tests/zstreamtest.c:{line}' for line in [1120,1198,1240]};found=set()
for row in m['sources']:
 if row['path']=='tests/zstreamtest.c':
  for c in row['cases']:
   if c['id'] in targets:
    assert c['status']=='partial';found.add(c['id']);c['reason']+=' Fixed borrowed output sessions additionally preserve persistent shared/view dictionary selection across fragmented frames and reset. A separate pinned stable-output oracle checks loaded and prepared dictionaries with actual guards at whole/one/seven-byte schedules. Opaque C context initialization/replacement and original generated workloads remain outside this added scope.';c['rust_tests']+=['tests/stable_dictionary_output.rs#every_prepared_split_and_reset_preserves_fixed_storage_and_dictionary_selection','tests/stable_dictionary_output_native.rs#pinned_native_stable_dictionary_destinations_and_guarded_errors']
 if row['path']=='tests/fuzz/dictionary_decompress.c':
  for v in [row,*row['cases']]:
   v['reason']+=' A seven-byte fixed-input stable-output persistent-session supplement now compares success and bytes with direct and buffered output. It consumes no new upstream selector and is explicitly not part of the original one-shot target. Prefix branches remain buffered. Full corpus completion is tracked separately; older evidence alone does not qualify the supplement.'
   v['rust_tests']+=['tests/stable_dictionary_output.rs#truncated_and_mutated_frames_preserve_guards_and_match_one_shot_success']
assert found==targets
p=R/'tests/upstream/manifest.json';changes['tests/upstream/manifest.json']=dict(before=sha(p));p.write_text(json.dumps(m,indent=2)+'\n');changes['tests/upstream/manifest.json']['after']=sha(p)
for label,args in [('format',['cargo','fmt','--all','--','--check']),('inventory',['python3','scripts/audit_upstream_tests.py','--upstream',str(T/'module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99')])]:
 with (D/('prepare-'+label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,label
(D/'preparation.json').write_text(json.dumps(dict(status='passed',gates=gates,changes=changes,qualification='All qualified tests are included before final full-matrix freeze. Corpus metadata can later be reconciled separately without changing production or test source bytes.'),indent=2)+'\n')
print('Final candidate tests prepared, formatted and inventory-audited')
