"""Prepare mandatory release test targets using spare build capacity; run no tests."""
from pathlib import Path
import json,hashlib,os,subprocess,time,datetime,signal
D=Path(__file__).parent;S=Path('/private/tmp/module26-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();original=json.loads((D/'evidence.json').read_text());assert original['status']=='running';source=original['source']
for n,h in source.items():assert sha(S/n)==h,n
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module26-candidate-target','CARGO_BUILD_JOBS':'3','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
e=dict(status='running',source=source,build_jobs=3,commands=[],started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),qualification='Precompile only the mandatory safe/all release test targets with the same frozen source, target and profile settings. Cargo target locking serializes this preparation with the existing matrix. --no-run executes no test and earns no correctness gate; the original full matrix must still run and record both release suites.')
p=D/'release-precompile.json';assert not p.exists()
def save():p.write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  args=['cargo','test','--offline','--locked','--release','--no-run',*flags];start=time.monotonic();remaining=datetime.datetime(2026,10,26,8,59,25,tzinfo=datetime.timezone.utc).timestamp()-time.time()-30;assert remaining>30
  with (D/('release-precompile-'+name+'.log')).open('xb') as f:
   child=subprocess.Popen(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=child.wait(timeout=remaining)
   except subprocess.TimeoutExpired:
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    raise
  e['commands'].append(dict(label=name,argv=args,exit_code=code,seconds=time.monotonic()-start));save();print(name,'release targets precompiled',code,flush=True);assert code==0
 for n,h in source.items():assert sha(S/n)==h,n
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
