from pathlib import Path
import json,time,subprocess,datetime
D=Path(__file__).parent;T=Path('/private/tmp')
gates=['module26-sink/evidence.json','module26-engine/evidence.json','module26-candidate/public.json','module26-native/rust.json','module26-platform/evidence.json','module26-fuzz/focused.json']
end=datetime.datetime(2026,10,26,8,59,0,tzinfo=datetime.timezone.utc).timestamp();previous=None
while time.time()<end:
 states=[]
 for n in gates:
  try:states.append(json.loads((T/n).read_text())['status'])
  except (FileNotFoundError,json.JSONDecodeError):states.append('pending')
 if states!=previous:print(dict(zip(gates,states)),flush=True);previous=states
 assert not any(s in ['failed','interrupted-at-user-deadline'] for s in states),states
 if all(s=='passed' for s in states):break
 time.sleep(20)
else:raise TimeoutError('No final matrix start before authorized deadline')
for script in [T/'module26-archives/archive-focused.py',D/'prepare.py']:
 print('Run',script,flush=True);subprocess.run(['python3',str(script)],check=True)

print('Prepared final candidate; full matrix deferred until predecessor timing/promotion checkpoint',flush=True)
