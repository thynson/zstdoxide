from pathlib import Path
import hashlib,json,tarfile
D=Path(__file__).parent;T=Path('/private/tmp');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
N=T/'module27-native';j=json.loads((N/'native.json').read_text());b=json.loads((N/'build.json').read_text());r=json.loads((N/'rust.json').read_text());assert j['status']==b['status']==r['status']=='passed' and len(j['results'])==750 and len(r['commands'])==5
assert all(c['exit_code']==0 for c in r['commands'])
for name,h in b['executables'].items():assert sha(N/('oracle-'+name))==h
for name,h in j['inputs'].items():assert sha(N/'inputs'/name)==h
for name,h in r['source'].items():assert sha(N/'rust-source'/name)==h
assert r['native_sha256']==sha(N/'native.json')
for row in j['results']:assert row['result']['guards']==1
name='2026-10-26-stable-prefix-output-native';archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(N.rglob('*')):
  if p.is_file() and not {'rust-target','__pycache__'}.intersection(p.relative_to(N).parts) and '.dSYM' not in str(p):t.add(p,arcname=str(p.relative_to(N)))
 t.add(T/'module24-preparation/reference-identity.json',arcname='reference-identity.json');t.add(__file__,arcname='archive-native-platform.py')
result=dict(status='passed',native=j,build=b,rust=r,archive=archive.name,archive_sha256=sha(archive),qualification='125 descriptors at whole/one/seven-byte input schedules use native refPrefix_advanced auto-detected single-use content under normal and ASan/UBSan builds (750 calls). Both shared and borrowed Rust prefixes execute all375 cases under safe, isolated slice, isolated dictionary, both and all (3750 calls). Native streaming consumes prefixes on skippable frames; Rust preserves unclaimed prefixes, and explicit leading-skip cases qualify this difference. Empty standard frames consume prefixes in both. Repeated dictionary-dependent concatenations reject after one prefix use. The established p>window native-success/Rust-CorruptData policy difference remains explicit. Real guards, independently expected success bytes and Rust unused suffixes are checked. Native opaque reset/workspace ABI equivalence is not claimed. Downloaded reference source stays external; helper sources, library hashes and retained executables are archived.')
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size,flush=True)
S=T/'module27-platform';j=json.loads((S/'evidence.json').read_text());assert j['status']=='passed' and len(j['commands'])==8 and all(c['exit_code']==0 for c in j['commands'])
for n,h in j['source'].items():assert sha(S/'source'/n)==h,n
for rows in j['artifacts'].values():
 for row in rows:assert sha(S/row['path'])==row['sha256']
name='2026-10-26-stable-prefix-output-platform';archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(S.iterdir()):
  if p.is_file():t.add(p,arcname='campaign/'+p.name)
 for folder in ['source','probe','artifacts']:
  for p in sorted((S/folder).rglob('*')):
   if p.is_file() and 'target' not in p.relative_to(S/folder).parts:t.add(p,arcname=folder+'/'+str(p.relative_to(S/folder)))
 t.add(__file__,arcname='archive-native-platform.py')
(D/(name+'.json')).write_text(json.dumps({**j,'archive':archive.name,'archive_sha256':sha(archive)},indent=2)+'\n');print(name,archive.stat().st_size,flush=True)
