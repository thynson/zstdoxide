//! Supplemental fixed-capacity prefix claim/reset scenarios.
#![forbid(unsafe_code)]
use zstdoxide::{DecodeOptions, Dictionary, Error, SharedDictionary, SliceDecoder, StreamStatus};
fn feed(d: &mut SliceDecoder<'_>, input: &[u8], chunk: usize) -> Result<(), Error> {
    let mut pos = 0;
    while pos < input.len() {
        let end = pos + chunk.min(input.len() - pos);
        let p = d.process(&input[pos..end])?;
        assert!(p.consumed > 0 || p.status == StreamStatus::FrameFinished);
        assert!(p.consumed <= end-pos);
        pos += p.consumed;
    }
    Ok(())
}
#[test]
fn fixed_capacity_claim_reset_and_retry_agree_with_the_documented_rust_contract() {
    let path = std::path::PathBuf::from(std::env::var_os("PREFIX_LIFECYCLE_INPUTS").unwrap());
    let dictionary_bytes = std::fs::read(path.join("formatted-id.dict")).unwrap();
    let frame = std::fs::read(path.join("formatted-id.zst")).unwrap();
    let original = std::fs::read(path.join("formatted-id.raw")).unwrap();
    let mut count = 0;
    for name in ["partial", "invalid-magic", "invalid-header", "over-limit-header", "skip", "empty", "complete"] {
        for chunk in [1, 7, 4194304] {
            let dictionary = Dictionary::from_bytes(&dictionary_bytes).unwrap().into_shared();
            let weak = SharedDictionary::downgrade(&dictionary);
            let mut oversized_header = vec![0x28,0xb5,0x2f,0xfd,0x63];
            oversized_header.extend_from_slice(&dictionary.id().to_le_bytes());
            oversized_header.extend_from_slice(&u16::try_from(original.len()+1-256).unwrap().to_le_bytes());
            let first: &[u8] = match name {
                "partial" => &frame[..3],
                "invalid-magic" => &[0],
                "invalid-header" => &[0x28,0xb5,0x2f,0xfd,8],
                "over-limit-header" => &oversized_header,
                "skip" => &[0x50,0x2a,0x4d,0x18,1,0,0,0,42],
                "empty" => &[0x28,0xb5,0x2f,0xfd,0x20,0,1,0,0],
                "complete" => &frame,
                _ => unreachable!(),
            };
            let pending = matches!(name,"partial"|"invalid-magic"|"invalid-header"|"skip");
            let mut storage = vec![0xa5; original.len()+64];
            let (prefix,rest) = storage.split_at_mut(32);
            let (output,suffix) = rest.split_at_mut(original.len());
            let mut d = SliceDecoder::with_prefix(output,DecodeOptions::new(original.len()),dictionary);
            let initial = feed(&mut d,first,chunk);
            assert_eq!(initial.is_err(),matches!(name,"invalid-magic"|"invalid-header"|"over-limit-header"));
            if name=="over-limit-header" { assert_eq!(initial,Err(Error::ResourceLimit)); }
            if initial.is_err() { assert_eq!(d.output(),Err(Error::InvalidState)); }
            if name=="complete" { assert_eq!(d.output().unwrap(),original); }
            assert!(prefix.iter().chain(suffix.iter()).all(|&b|b==0xa5));
            assert_eq!(weak.upgrade().is_some(),!matches!(name,"empty"|"complete"));
            d.reset();
            assert_eq!(weak.upgrade().is_some(),pending);
            assert_eq!(d.dictionary_retained_capacity()>0,pending);
            let retry=feed(&mut d,&frame,chunk).and_then(|_|d.finish());
            assert_eq!(retry.is_ok(),pending,"{name} {chunk}");
            if pending { assert_eq!(d.output().unwrap(),original); }
            else { assert_eq!(retry,Err(Error::DictionaryRequired)); assert_eq!(d.output(),Err(Error::InvalidState)); }
            drop(d);
            assert!(weak.upgrade().is_none());
            assert!(prefix.iter().chain(suffix.iter()).all(|&b|b==0xa5));
            count+=1;
        }
    }
    assert_eq!(count,21);
    eprintln!("21 fixed-capacity prefix lifecycle scenarios passed with actual guards and weak-owner checks");
}
