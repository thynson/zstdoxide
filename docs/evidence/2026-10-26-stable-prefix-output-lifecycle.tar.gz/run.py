from pathlib import Path
import json,hashlib,subprocess
D=Path(__file__).parent;I=Path('/private/tmp/module25-native/inputs');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((D/'build.json').read_text());assert b['status']=='passed'
cases={'partial':True,'invalid-magic':True,'invalid-header':True,'short':True,'over-limit-header':True,'skip':False,'empty':False,'complete':False}
e=dict(status='running',build_sha256=sha(D/'build.json'),inputs={n:sha(I/n) for n in ['formatted-id.dict','formatted-id.zst','formatted-id.raw']},results=[])
def save():(D/'native.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for backend in ['normal','sanitized']:
  assert sha(D/('oracle-'+backend))==b['executables'][backend]
  for name,retry in cases.items():
   for chunk in [1,7,4194304]:
    args=[str(D/('oracle-'+backend)),str(I/'formatted-id.dict'),str(I/'formatted-id.zst'),str(I/'formatted-id.raw'),name,str(chunk)];p=subprocess.run(args,capture_output=True);label=f'{backend}-{name}-{chunk}';(D/(label+'.stdout')).write_bytes(p.stdout);(D/(label+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,(label,p.stderr)
    r=json.loads(p.stdout);e['results'].append(dict(label=label,argv=args,result=r,expected_retry=retry));save();assert r['version']==10507 and r['first_guards']==r['retry_guards']==1;assert bool(r['retry_exact'])==retry,(label,r)
    if not retry:assert r['retry_error_code']==32,(label,r)
    if name in ['short','over-limit-header']:assert r['first_error_code']==70,(label,r)
 e.update(status='passed',qualification='48 normal/sanitized lifecycle scenarios across eight first inputs and three widths. Session-only reset preserves an unconsumed native prefix. Native capacity rejection precedes prefix consumption, and native skips consume prefixes. Seven scenarios use unchanged fixed capacity; the native-only short scenario deliberately changes capacity across reset and has no direct Rust fixed-output counterpart.');save();print('Native lifecycle48passed')
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
