from pathlib import Path
import json,hashlib,shutil,subprocess,os,time
D=Path(__file__).parent;R=Path('/private/tmp/module27-candidate');S=D/'rust-source';S.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
n=json.loads((D/'native.json').read_text());assert n['status']=='passed' and len(n['results'])==48
for name in ['src','test-support','benches']:shutil.copytree(R/name,S/name)
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(R/name,S/name)
(S/'tests').mkdir();shutil.copyfile(D/'prefix_lifecycle.rs',S/'tests/prefix_lifecycle.rs')
subprocess.run(['rustfmt','--edition','2024','tests/prefix_lifecycle.rs'],cwd=S,check=True)
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};e=dict(status='running',source=source,native_sha256=sha(D/'native.json'),commands=[])
def save():(D/'rust.json').write_text(json.dumps(e,indent=2)+'\n')
save();env={**os.environ,'CARGO_TARGET_DIR':str(D/'rust-target'),'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','PREFIX_LIFECYCLE_INPUTS':'/private/tmp/module25-native/inputs'}
try:
 for name,flags in [('safe',[]),('slice',['--features','unsafe-slice-history']),('dictionary',['--features','unsafe-dictionary']),('both',['--features','unsafe-slice-history,unsafe-dictionary']),('all',['--all-features'])]:
  args=['cargo','test','--offline','--locked','--release','--test','prefix_lifecycle',*flags,'--','--nocapture'];t=time.monotonic()
  with (D/('rust-'+name+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t));save();assert p.returncode==0,name;assert '21 fixed-capacity prefix lifecycle scenarios passed' in (D/('rust-'+name+'.log')).read_text();print(name,'21 scenarios passed',flush=True)
 for label,args in [('clippy',['cargo','clippy','--offline','--locked','--test','prefix_lifecycle','--all-features','--','-D','warnings']),('format',['rustfmt','--edition','2024','--check','tests/prefix_lifecycle.rs'])]:
  with (D/('rust-'+label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode));save();assert p.returncode==0,label
 for name,h in source.items():assert sha(S/name)==h,name
 for name,h in source.items():
  if name.startswith('src/'):assert sha(R/name)==h,name
 e.update(status='passed',qualification='Five independent storage selections each replay21 fixed-capacity claim/reset scenarios with real guards and weak-owner lifetime checks. Over-limit valid headers consume Rust prefixes before rejection, so reset releases them; native rejects capacity before consumption. Rust skips preserve prefixes; native skips consume them. Other retained scenarios agree on retry success. Native-only capacity replacement is not emulated.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
