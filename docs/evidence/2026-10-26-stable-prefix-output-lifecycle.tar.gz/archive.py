from pathlib import Path
import json,hashlib,tarfile,time
D=Path(__file__).parent;A=Path('/private/tmp/module27-archives');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while True:
 r=json.loads((D/'rust.json').read_text())
 if r['status']=='passed':break
 assert r['status']=='running',r['status'];time.sleep(10)
n=json.loads((D/'native.json').read_text());b=json.loads((D/'build.json').read_text());assert n['status']==b['status']=='passed' and len(n['results'])==48 and len(r['commands'])==7
for name,h in b['executables'].items():assert sha(D/('oracle-'+name))==h
for name,h in r['source'].items():assert sha(D/'rust-source'/name)==h
assert r['native_sha256']==sha(D/'native.json')
name='2026-10-26-stable-prefix-output-lifecycle';archive=A/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(D.rglob('*')):
  if p.is_file() and not {'rust-target','__pycache__'}.intersection(p.relative_to(D).parts) and '.dSYM' not in str(p):t.add(p,arcname=str(p.relative_to(D)))
result=dict(status='passed',native=n,build=b,rust=r,archive=archive.name,archive_sha256=sha(archive),qualification='Separate claim/reset supplement:48 native scenarios (normal/sanitized, eight initial inputs, three widths);105 Rust scenarios (five storage selections, seven unchanged-capacity initial inputs, three widths), with strict Clippy and formatting. Native-only capacity replacement has no direct fixed-output Rust counterpart. Actual guards and Rust weak-owner checks distinguish pre-claim parsing errors, valid over-limit headers, skips and completed standard frames. This does not inflate the earlier750 native/3750 Rust streaming campaign counts. The initially successful native capacity-only prototype and subsequent additional fixed-capacity header design are retained separately.')
(A/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
p=A/'stable-prefix-output-validation.md';s=p.read_text();s+='''\n## Claim, session-only reset and retry supplement\n\n`evidence/2026-10-26-stable-prefix-output-lifecycle.json` separately records\n48 native and 105 Rust lifecycle scenarios. Normal/sanitized native builds\nexercise eight first-input kinds at whole/one/seven-byte widths; five Rust\nstorage selections exercise the seven cases with unchanged fixed capacity.\nNative-only capacity replacement is retained as an observation, not emulated\nthrough a Rust API that cannot resize its destination. Real guards and Rust\nweak-owner checks remain active across initial processing, reset and retry.\n\nBoth retain a prefix after partial headers and parsing rejection, and consume\nit after completed or empty standard frames. Native streaming consumes on a\nskip, while Rust preserves the pending prefix. A valid header advertising more\noutput than the unchanged allowance is rejected before native prefix consumption,\nbut after Rust's documented claim point. Native can therefore retry with its\noriginal prefix after session-only reset; Rust reset releases that claimed\nhandle and a later dependent frame requires an explicit new selection. These\nare intentional lifecycle differences, with no C opaque-context equivalence claim.\n''';p.write_text(s)
p=A/'stable-prefix-usage-addition.md';s=p.read_text();s+='''\nA further difference concerns a valid header whose advertised output exceeds the\nallowance. Native stable output checks that capacity before consuming its prefix;\nRust claims the prefix first. Reset after this Rust error releases the claimed\nselection. When reusing that reset session for a later frame that needs a prefix,\nselect it again explicitly. The output capacity and options remain fixed.\n''';p.write_text(s)
print('Archived prefix lifecycle supplement',archive.stat().st_size,flush=True)
