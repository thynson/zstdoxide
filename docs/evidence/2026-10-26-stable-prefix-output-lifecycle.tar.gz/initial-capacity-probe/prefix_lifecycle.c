/* External pinned-v1.5.7 test oracle only; never linked into the Rust codec. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "zstd_errors.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct Run { size_t result, consumed, written; unsigned guards; };
static unsigned char* read_file(char const* name, size_t* size) {
    FILE* f = fopen(name, "rb");
    if (!f || fseek(f, 0, SEEK_END)) exit(2);
    long n = ftell(f);
    if (n < 0 || n > 4 * 1024 * 1024 || fseek(f, 0, SEEK_SET)) exit(2);
    *size = (size_t)n;
    unsigned char* p = malloc(*size ? *size : 1);
    if (!p || fread(p, 1, *size, f) != *size || fclose(f)) exit(2);
    return p;
}
static struct Run run(ZSTD_DCtx* ctx, unsigned char const* source, size_t size,
                      unsigned char* storage, size_t capacity, size_t chunk) {
    memset(storage, 0xa5, capacity + 64);
    ZSTD_inBuffer in = { source, 0, 0 };
    ZSTD_outBuffer out = { storage + 32, capacity, 0 };
    size_t result = 1;
    for (size_t calls = 0; calls < 2 * (size + 1) + 8; calls++) {
        if (in.pos == in.size) {
            size_t left = size - in.size;
            in.size += left < chunk ? left : chunk;
        }
        size_t before = in.pos;
        result = ZSTD_decompressStream(ctx, &out, &in);
        if (ZSTD_isError(result) || in.pos == size) break;
        if (in.pos == before) exit(3);
    }
    if (out.pos > capacity) exit(3);
    unsigned guards = 1;
    for (size_t i = 0; i < 32; i++)
        if (storage[i] != 0xa5 || storage[32 + capacity + i] != 0xa5) guards = 0;
    return (struct Run){ result, in.pos, out.pos, guards };
}
int main(int argc, char** argv) {
    if (argc != 6) return 2;
    size_t dictionary_size, frame_size, original_size;
    unsigned char* dictionary = read_file(argv[1], &dictionary_size);
    unsigned char* frame = read_file(argv[2], &frame_size);
    unsigned char* original = read_file(argv[3], &original_size);
    size_t chunk = (size_t)strtoul(argv[5], NULL, 10);
    if (chunk != 1 && chunk != 7 && chunk != 4194304) return 2;
    static unsigned char const invalid[] = { 0 };
    static unsigned char const invalid_header[] = { 0x28,0xb5,0x2f,0xfd,8 };
    static unsigned char const skip[] = { 0x50,0x2a,0x4d,0x18,1,0,0,0,42 };
    static unsigned char const empty[] = { 0x28,0xb5,0x2f,0xfd,0x20,0,1,0,0 };
    unsigned char const* first = frame;
    size_t first_size = frame_size, first_capacity = original_size;
    if (!strcmp(argv[4], "partial")) first_size = 3;
    else if (!strcmp(argv[4], "invalid-magic")) { first = invalid; first_size = sizeof(invalid); }
    else if (!strcmp(argv[4], "invalid-header")) { first = invalid_header; first_size = sizeof(invalid_header); }
    else if (!strcmp(argv[4], "short")) first_capacity = 0;
    else if (!strcmp(argv[4], "skip")) { first = skip; first_size = sizeof(skip); }
    else if (!strcmp(argv[4], "empty")) { first = empty; first_size = sizeof(empty); }
    else if (strcmp(argv[4], "complete")) return 2;
    unsigned char* storage = malloc(original_size + 64);
    ZSTD_DCtx* ctx = ZSTD_createDCtx();
    if (!storage || !ctx || ZSTD_isError(ZSTD_DCtx_setParameter(ctx, ZSTD_d_stableOutBuffer, 1))
        || ZSTD_isError(ZSTD_DCtx_refPrefix_advanced(ctx, dictionary, dictionary_size, ZSTD_dct_auto))) return 2;
    struct Run a = run(ctx, first, first_size, storage, first_capacity, chunk);
    if (ZSTD_isError(ZSTD_DCtx_reset(ctx, ZSTD_reset_session_only))) return 2;
    struct Run b = run(ctx, frame, frame_size, storage, original_size, chunk);
    unsigned exact = !ZSTD_isError(b.result) && b.result == 0 && b.consumed == frame_size
                     && b.written == original_size && !memcmp(storage + 32, original, original_size);
    printf("{\"version\":%u,\"first_error\":%u,\"first_error_code\":%u,\"first_result\":%zu,\"first_consumed\":%zu,\"first_written\":%zu,\"first_guards\":%u,\"retry_error\":%u,\"retry_error_code\":%u,\"retry_consumed\":%zu,\"retry_written\":%zu,\"retry_guards\":%u,\"retry_exact\":%u}\n",
           ZSTD_versionNumber(), ZSTD_isError(a.result), (unsigned)ZSTD_getErrorCode(a.result), a.result,
           a.consumed, a.written, a.guards, ZSTD_isError(b.result), (unsigned)ZSTD_getErrorCode(b.result),
           b.consumed, b.written, b.guards, exact);
    ZSTD_freeDCtx(ctx); free(storage); free(original); free(frame); free(dictionary);
    return a.guards && b.guards ? 0 : 3;
}
