/* Test oracle only. Pinned facebook/zstd v1.5.7; never linked into Rust. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "zstd_errors.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static size_t number(char const* text, size_t limit) {
    char* end = NULL;
    errno = 0;
    unsigned long long n = strtoull(text, &end, 10);
    if (errno || !end || end == text || *end || n > limit) exit(2);
    return (size_t)n;
}
int main(int argc, char** argv) {
    if (argc != 6) return 2;
    size_t const capacity = number(argv[2], 16U * 1024U * 1024U);
    size_t const chunk = number(argv[4], 4U * 1024U * 1024U);
    int const modified = strcmp(argv[5], "normal") != 0;
    if (chunk == 0 || (modified && strcmp(argv[5], "position") && strcmp(argv[5], "pointer") && strcmp(argv[5], "capacity"))) return 2;
    FILE* f = fopen(argv[1], "rb");
    if (!f || fseek(f, 0, SEEK_END)) return 2;
    long const file_size = ftell(f);
    if (file_size < 0 || file_size > 4 * 1024 * 1024 || fseek(f, 0, SEEK_SET)) return 2;
    size_t const size = (size_t)file_size;
    unsigned char* source = malloc(size ? size : 1);
    unsigned char* storage = malloc(capacity + 64);
    if (!source || !storage || fread(source, 1, size, f) != size || fclose(f)) return 2;
    memset(storage, 0xa5, capacity + 64);
    ZSTD_DCtx* ctx = ZSTD_createDCtx();
    if (!ctx) return 2;
    size_t const initial_workspace = ZSTD_sizeof_DCtx(ctx);
    if (ZSTD_isError(ZSTD_DCtx_setParameter(ctx, ZSTD_d_stableOutBuffer, 1))) return 2;
    ZSTD_inBuffer in = {source, 0, 0};
    ZSTD_outBuffer out = {storage + 32, capacity, 0};
    size_t result = 1, calls = 0, frames = 0;
    if (modified) {
        if (size < 2 || capacity == 0) return 2;
        in.size = size - 1;
        result = ZSTD_decompressStream(ctx, &out, &in);
        if (ZSTD_isError(result) || result == 0 || out.pos == 0) return 3;
        if (!strcmp(argv[5], "position")) out.pos = 0;
        if (!strcmp(argv[5], "pointer")) out.dst = storage + 33;
        if (!strcmp(argv[5], "capacity")) out.size--;
        in.size = size;
        result = ZSTD_decompressStream(ctx, &out, &in);
        calls = 2;
    } else {
        while (calls < 2 * (size + 1) + 8) {
            if (in.pos == in.size) {
                size_t const remaining = size - in.size;
                in.size += remaining < chunk ? remaining : chunk;
            }
            size_t const before = in.pos;
            result = ZSTD_decompressStream(ctx, &out, &in);
            calls++;
            if (ZSTD_isError(result)) break;
            if (result == 0) frames++;
            if (in.pos == size) break;
            if (in.pos == before) return 3;
        }
    }
    unsigned const error = ZSTD_isError(result);
    unsigned const complete = !error && result == 0 && in.pos == size;
    unsigned guards = 1;
    for (size_t i = 0; i < 32; i++) {
        if (storage[i] != 0xa5 || storage[32 + capacity + i] != 0xa5) guards = 0;
    }
    if (out.pos > capacity) return 3;
    f = fopen(argv[3], "wb");
    if (!f || (complete && out.pos && fwrite(storage + 32, 1, out.pos, f) != out.pos) || fclose(f)) return 2;
    printf("{\"version\":%u,\"error\":%u,\"error_code\":%u,\"complete\":%u,\"consumed\":%zu,\"written\":%zu,\"frames\":%zu,\"calls\":%zu,\"guards\":%u,\"initial_workspace\":%zu,\"final_workspace\":%zu}\n", ZSTD_versionNumber(), error, (unsigned)ZSTD_getErrorCode(result), complete, in.pos, out.pos, frames, calls, guards, initial_workspace, ZSTD_sizeof_DCtx(ctx));
    ZSTD_freeDCtx(ctx);
    free(source);
    free(storage);
    return guards ? 0 : 3;
}
