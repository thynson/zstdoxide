from pathlib import Path
import json,hashlib,subprocess,shutil,time
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');I=D/'inputs';I.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build=json.loads((D/'build.json').read_text());assert build['status']=='passed'
frames=[]
for row in json.loads((R/'tests/upstream/decodecorpus/manifest.json').read_text())['frames']:
 name=row['name']
 for ext in ['zst','raw']:shutil.copyfile(R/'tests/upstream/decodecorpus'/(name+'.'+ext),I/(name+'.'+ext))
 assert sha(I/(name+'.zst'))==row['encoded_sha256'] and sha(I/(name+'.raw'))==row['original_sha256']
 frames.append((name,'ok'))
for name,frame,original in [('http',R/'tests/upstream/data/generated/http.zst',R/'tests/upstream/data/golden-compression/http')]:
 shutil.copyfile(frame,I/(name+'.zst'));shutil.copyfile(original,I/(name+'.raw'));frames.append((name,'ok'))
for name,encoded,original in [('empty',bytes([0x28,0xb5,0x2f,0xfd,0x20,0,1,0,0]),b''),('skip',bytes([0x50,0x2a,0x4d,0x18,3,0,0,0,9,8,7]),b''),('concatenated',(I/'skip.zst').read_bytes() if (I/'skip.zst').exists() else b'',b'')]:
 if name=='concatenated':continue
 (I/(name+'.zst')).write_bytes(encoded);(I/(name+'.raw')).write_bytes(original);frames.append((name,'ok'))
(I/'concatenated.zst').write_bytes((I/'http.zst').read_bytes()+(I/'skip.zst').read_bytes()+(I/'compressed-05.zst').read_bytes())
(I/'concatenated.raw').write_bytes((I/'http.raw').read_bytes()+(I/'compressed-05.raw').read_bytes());frames.append(('concatenated','ok'))
for name,encoded,original,kind in [('truncated',(I/'http.zst').read_bytes()[:-1],(I/'http.raw').read_bytes(),'incomplete'),('bad-checksum',(I/'mixed-04.zst').read_bytes()[:-1]+bytes([(I/'mixed-04.zst').read_bytes()[-1]^1]),(I/'mixed-04.raw').read_bytes(),'checksum'),('empty-input',b'',b'','incomplete')]:
 (I/(name+'.zst')).write_bytes(encoded);(I/(name+'.raw')).write_bytes(original);frames.append((name,kind))
cases=[]
for name,kind in frames:
 size=(I/(name+'.raw')).stat().st_size;encoded_size=(I/(name+'.zst')).stat().st_size
 caps=sorted({0,max(0,size-1),size,size+17}) if kind=='ok' else [size+17]
 for cap in caps:
  for chunk in sorted({1,7,max(1,encoded_size)}):
   cases.append(dict(name=name,capacity=cap,chunk=chunk,mode='normal',expected='small' if kind=='ok' and cap<size else kind))
for mode in ['position','pointer','capacity']:
 cases.append(dict(name='mixed-04',capacity=(I/'mixed-04.raw').stat().st_size+17,chunk=1,mode=mode,expected='wrong-buffer'))
(D/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
e=dict(status='running',build_sha256=sha(D/'build.json'),cases_sha256=sha(D/'cases.json'),inputs={p.name:sha(p) for p in I.iterdir()},results=[])
def save():(D/'native.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for backend in ['normal','sanitized']:
  assert sha(D/('oracle-'+backend))==build['executables'][backend]
  O=D/backend;O.mkdir()
  for index,case in enumerate(cases):
   n=case['name'];output=O/(str(index)+'.out');args=[str(D/('oracle-'+backend)),str(I/(n+'.zst')),str(case['capacity']),str(output),str(case['chunk']),case['mode']]
   p=subprocess.run(args,capture_output=True);(O/(str(index)+'.stdout')).write_bytes(p.stdout);(O/(str(index)+'.stderr')).write_bytes(p.stderr)
   assert p.returncode==0,(backend,index,case,p.returncode,p.stdout,p.stderr)
   result=json.loads(p.stdout);assert result['version']==10507 and result['guards']==1
   expected=case['expected']
   if expected=='ok':
    assert result['complete']==1 and result['error']==0 and output.read_bytes()==(I/(n+'.raw')).read_bytes(),(backend,index,case,result)
   elif expected=='incomplete':assert not result['complete'],(backend,index,case,result)
   else:assert result['error']==1 and result['error_code']=={'small':70,'checksum':22,'wrong-buffer':104}[expected],(backend,index,case,result)
   e['results'].append(dict(backend=backend,index=index,case=case,result=result,output_sha256=sha(output)))
   if index%100==0:save();print(backend,index,'passed',flush=True)
  save()
 e['status']='passed';save();print('passed',len(cases),'cases per native backend',flush=True)
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
