from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-module14-platform')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,m):
 if not v:raise ValueError(m)
e=json.loads((O/'evidence.json').read_bytes());m=json.loads((O/'source-manifest.json').read_bytes())
need(e['status']=='passed' and e['source_unchanged'] and e['processes_remaining']==0 and len(e['commands'])==19,'complete run')
count=0
for c in e['commands']:
 b=Path(c['log']).read_bytes();need(c['passed'] and c['exit_code']==0 and c['source_unchanged'] and sha(b)==c['log_sha256'],'command '+c['name'])
 if c['name'].startswith('miri-') and c['name']!='miri-version':
  need(c['count_and_names_valid'],'exact nonempty selector count');count+=len(c['actual_tests'])
need(count==44,'interpreted counts')
critical=[n for n in m['files'] if n.startswith(('src/','test-support/allocator/')) or n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/reference_greedy_platform.rs','tests/support/greedy_frame_encode.rs')]
for n in critical:need(sha((R/n).read_bytes())==m['files'][n]['sha256'],'delivered source '+n)
reconciled={}
for mode,r in e['caller_artifacts'].items():
 matches=[p for p in Path('/tmp/zstdoxide-module14-platform-thumb-target').rglob('libzstdoxide_module14_thumb_caller*.rlib') if sha(p.read_bytes())==r['sha256']]
 need(matches,'retained caller identity '+mode)
 reconciled[mode]=[str(p) for p in matches]
(O/'caller-artifact-reconciliation.json').write_bytes(enc(reconciled))
report=dict(date='2026-10-12',status='passed',base=e['revision'],overlays=['tests/reference_greedy_platform.rs','tests/support/greedy_frame_encode.rs'],commands=19,interpreted_executions=44,native_smoke_executions=1,thumb_library_checks=2,thumb_caller_codegen=2,source_unchanged=True,source_comparisons=critical,qualification=e['qualification'],artifact_qualification='The canonical caller path is overwritten by the second backend. Both originally recorded rlibs remain under distinct Cargo output paths and are rehashed and archived without rebuilding.',scope='Ten selected chain/row/parser/ownership/frame tests and one public tiny-frame ownership test per safe/all interpreted target; no whole foreign suite or native foreign execution.',archive='2026-10-12-greedy-platform.tar.gz')
files={str(p.relative_to(O)):p.read_bytes() for p in O.iterdir() if p.is_file()}
files.update({str(p.relative_to(O)):p.read_bytes() for p in (O/'thumb-caller').rglob('*') if p.is_file()})
files['package.py']=Path(__file__).read_bytes();files['review.json']=enc(report)
for mode,paths in reconciled.items():files['artifacts/'+mode+'.rlib']=Path(paths[0]).read_bytes()
for name in m['test_overlays']:files['overlays/'+name]=(O/'snapshot'/name).read_bytes()
files['bundle-manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())})
a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh archive');prefix='greedy-platform/'
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo(prefix+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:found={m.name:t.extractfile(m).read() for m in t}
need(found=={prefix+n:b for n,b in files.items()},'archive exact bytes')
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(files));(R/'docs/evidence/2026-10-12-greedy-platform.json').write_bytes(enc(report));print(count,len(files),a.stat().st_size)
