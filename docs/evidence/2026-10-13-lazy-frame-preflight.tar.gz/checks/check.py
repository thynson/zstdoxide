import hashlib, json, os, subprocess, sys, tempfile
from pathlib import Path
from types import SimpleNamespace
root = Path('/Users/lanxingcan/Workspace/zstdoxize')
sys.path.insert(0, str(root / 'scripts'))
child_attempts = []
def forbidden(*args, **kwargs):
    child_attempts.append('blocked')
    raise RuntimeError('process creation forbidden in controller preflight')
subprocess.Popen = forbidden
for name in ['system', 'fork', 'forkpty', 'posix_spawn', 'posix_spawnp', 'spawnl', 'spawnle', 'spawnlp', 'spawnlpe', 'spawnv', 'spawnve', 'spawnvp', 'spawnvpe', 'execl', 'execle', 'execlp', 'execlpe', 'execv', 'execve', 'execvp', 'execvpe']:
    if hasattr(os, name): setattr(os, name, forbidden)
import capture_lazy_frames as m
plan = m.plan()
if plan != {'recipes':510, 'source_bytes':22499784, 'scheduled_calls':1401, 'positive_calls':1377, 'whole_comparisons':39, 'incomplete_headers':45, 'malformed_per_build':51, 'codec_executions':0, 'status':'pre-execution plan checked'}:
    raise ValueError('unexpected plan')
original_load = m.load_inputs
loaded = original_load()
m.load_inputs = lambda: loaded
rejected = []
reference = Path('/private/tmp/zstdoxide-reference-lazy-1.5.7')
with tempfile.TemporaryDirectory(prefix='zstdoxide-lazy-controller-') as directory:
    tmp = Path(directory).resolve()
    existing = tmp / 'existing'; existing.mkdir()
    link = tmp / 'linked-repository'; link.symlink_to(root, target_is_directory=True)
    rows = [('repository', root, reference, 'clang'),
            ('repository_child', root/'must-not-create-lazy-output', reference, 'clang'),
            ('repository_ancestor', root.parent, reference, 'clang'),
            ('reference', reference, reference, 'clang'),
            ('reference_child', reference/'must-not-create-lazy-output', reference, 'clang'),
            ('existing', existing, reference, 'clang'),
            ('symlink', link/'must-not-create-lazy-output', reference, 'clang'),
            ('internal_reference', tmp/'internal-reference-output', root, 'clang'),
            ('absent_compiler', tmp/'missing-compiler-output', reference, 'zstdoxide-no-such-compiler')]
    for name, output, upstream, cc in rows:
        present = output.exists()
        try:
            m.run(SimpleNamespace(output=output, upstream=upstream, cc=cc))
        except ValueError:
            rejected.append(name)
        else:
            raise ValueError('unsafe preflight accepted: '+name)
        if output.exists() != present:
            raise ValueError('rejected preflight wrote output: '+name)
    first = next(iter(m.PINS)); digest = m.PINS[first]; m.PINS[first] = '0'*64
    try:
        original_load()
    except ValueError:
        rejected.append('changed_pinned_input')
    else:
        raise ValueError('changed pin accepted')
    finally:
        m.PINS[first] = digest
import check_lazy_frame_capture as auditor
auditor.inputs()
transport_rejections=[]
with tempfile.TemporaryDirectory(prefix='zstdoxide-lazy-auditor-') as directory:
    tmp=Path(directory).resolve(); (tmp/'one').write_bytes(b'x')
    (tmp/'link').symlink_to(tmp/'one')
    for name,cap in [('missing',64),('../one',64),('/one',64),('one',0),('link',64),('a/../one',64),('a\\one',64)]:
        try:auditor.read(tmp,name,cap)
        except ValueError:transport_rejections.append(name)
        else:raise ValueError('bad artifact transport accepted')
    if auditor.read(tmp,'one',1)!=b'x':raise ValueError('positive artifact transport')
    for status in ['running','failed',True,None]:
        (tmp/'evidence.json').write_text(json.dumps({'status':status}))
        try:auditor.audit(tmp)
        except ValueError:transport_rejections.append('status_'+str(status))
        else:raise ValueError('incomplete capture accepted')
if len(transport_rejections)!=11:raise ValueError('transport control count')
if child_attempts or len(rejected) != 10:
    raise ValueError('offline preflight outcome')
print(json.dumps({'python':sys.version, 'optimization':sys.flags.optimize, 'child_attempts':len(child_attempts), 'plan':plan, 'rejected':rejected,'auditor_transport_rejections':transport_rejections, 'controller_sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()}, sort_keys=True))
