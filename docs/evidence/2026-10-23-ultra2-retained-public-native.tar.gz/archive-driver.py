"""Additive v4: same bounded lossless chunk inventory and independent complete reconstruction checks as v3; gzip level 1 reduces archive CPU work without changing evidence content."""
import argparse,concurrent.futures,gzip,hashlib,io,json,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('name');a=p.parse_args();root=a.root.resolve(strict=True);repo=Path('/Users/lanxingcan/Workspace/zstdoxize');dest=repo/'docs/evidence'/(a.name+'.tar.gz');report=dest.with_suffix('').with_suffix('.json')
def need(v,m):
 if not v:raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
e=json.loads((root/'evidence.json').read_bytes());need(e['status']=='passed'and e['source_unchanged']is True,'complete source-bound campaign');need(all(c['exit_code']==c.get('expected_exit',0)for c in e['commands']),'successful primary commands');need(not dest.exists()and not report.exists(),'fresh archive')
paths=sorted(p for p in root.rglob('*')if p.is_file());print('inventory',len(paths),flush=True)
def read(p):
 need(not p.is_symlink()and p.stat().st_size<=256<<20,'bounded regular file');b=p.read_bytes();need(len(b)==p.stat().st_size,'stable extent')
 chunks=[(sha(b[i:i+65536]),b[i:i+65536])for i in range(0,len(b),65536)]
 return p.relative_to(root).as_posix(),dict(bytes=len(b),sha256=sha(b),chunks=[h for h,_ in chunks]),chunks
files={};chunks={};expanded=0
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for index,(name,row,parts)in enumerate(pool.map(read,paths,buffersize=8),1):
  files[name]=row;expanded+=row['bytes'];need(expanded<=5<<30,'bounded aggregate')
  for h,b in parts:
   if h in chunks:need(chunks[h]==b,'chunk identity')
   else:chunks[h]=b
  if index%10000==0:print('read',index,flush=True)
print('indexed',len(files),expanded,len(chunks),flush=True)
reconstruct='''import hashlib,json\nfrom pathlib import Path\nr=Path(__file__).resolve().parent\nfor name,row in json.loads((r/'file-map.json').read_bytes()).items():\n p=r/'bundle'/name\n if not p.resolve().is_relative_to((r/'bundle').resolve()):raise ValueError('path')\n b=b''.join((r/'chunks'/h).read_bytes()for h in row['chunks'])\n if len(b)!=row['bytes']or hashlib.sha256(b).hexdigest()!=row['sha256']:raise ValueError('content')\n p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)\nprint('Reconstructed and verified all archived files; inspect captured source before execution.')\n'''
meta={'file-map.json':(json.dumps(files,sort_keys=True,indent=2)+'\n').encode(),'reconstruct.py':reconstruct.encode(),'archive-driver.py':Path(__file__).read_bytes()}
with dest.open('xb')as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=1)as gz,tarfile.open(fileobj=gz,mode='w|')as tar:
 for name,b in sorted(meta.items())+[(f'chunks/{h}',b)for h,b in sorted(chunks.items())]:
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b))
loaded={}
with tarfile.open(dest,'r|gz')as tar:
 for m in tar:
  need(m.isfile()and m.name not in loaded,'unique regular member');loaded[m.name]=tar.extractfile(m).read()
need(set(loaded)==set(meta)|{'chunks/'+h for h in chunks},'exact archive member set')
for n,b in meta.items():need(loaded[n]==b,'exact metadata')
for h in chunks:need(sha(loaded['chunks/'+h])==h,'independent complete chunk hash')
for n,row in json.loads(loaded['file-map.json']).items():
 h=hashlib.sha256();size=0
 for c in row['chunks']:b=loaded['chunks/'+c];h.update(b);size+=len(b)
 need(size==row['bytes']and h.hexdigest()==row['sha256'],'complete reconstructed original')
print('archive reconstruction passed',flush=True)
def unchanged(p):return digest(p)==files[p.relative_to(root).as_posix()]['sha256']
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:need(all(pool.map(unchanged,paths,buffersize=8)),'every original file unchanged after archive')
need(sorted(p.relative_to(root).as_posix()for p in root.rglob('*')if p.is_file())==sorted(files),'unchanged file inventory')
result=dict(status='passed',archive=dest.name,archive_bytes=dest.stat().st_size,archive_sha256=digest(dest),regular_files=len(files),expanded_bytes=expanded,unique_chunks=len(chunks),unique_chunk_bytes=sum(map(len,chunks.values())),file_map_sha256=sha(meta['file-map.json']),commands=len(e['commands']),source=e['source'],qualification=e.get('qualification','Complete verified campaign.')+' Every regular bundle file is retained by lossless chunks. Independent archive replay reconstructs every file; a second concurrent read verifies every original remained unchanged. Any omissions made while preparing the bundle are explicitly documented in its qualification and manifests; this archive omits no regular bundle file.')
report.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='source'}),flush=True)
