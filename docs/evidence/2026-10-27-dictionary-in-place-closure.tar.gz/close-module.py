"""Close only after integrated focused, native, full-matrix and measured gates."""
from pathlib import Path
import json,hashlib,subprocess,tarfile,datetime
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();state=D/'promotion-state.json';previous=json.loads(state.read_text());assert previous['stage']=='benchmarks'
assert previous['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
production={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')};assert production==previous['production_source']
names=['2026-10-27-dictionary-in-place-'+stage for stage in ['engine','public-api','native','platform','platform-final','corpus','feature-matrix','benchmarks']];records={}
for n in names:
 p=E/(n+'.json');j=json.loads(p.read_text());assert j['status']=='passed',n;assert sha(E/j['archive'])==j['archive_sha256'],n;records[n]=dict(receipt_sha256=sha(p),archive_sha256=j['archive_sha256'])
for stage in ['public-api','native','platform-final','corpus','feature-matrix']:
 j=json.loads((E/('2026-10-27-dictionary-in-place-'+stage+'.json')).read_text());assert j['production_source']==production,stage
matrix=json.loads((E/'2026-10-27-dictionary-in-place-feature-matrix.json').read_text())
for n,h in matrix['source'].items():assert sha(R/n)==h,n
bench=json.loads((E/'2026-10-27-dictionary-in-place-benchmarks.json').read_text());assert bench['build']['production_source']==production
pred=E/'2026-10-27-in-place-output-closure.json';assert json.loads(pred.read_text())['status']=='passed';assert sha(E/json.loads(pred.read_text())['archive'])==json.loads(pred.read_text())['archive_sha256']
todo=(R/'TODO.md').read_text();start=todo.index('## Module 29:');end=todo.index('\n## ',start+1);unchecked=[l for l in todo[start:end].splitlines() if l.startswith('- [ ]')];assert len(unchecked)==1 and unchecked[0].startswith('- [ ] Reconcile');assert '## Module 30:' in todo and (R/'docs/frame-scan-design.md').exists()
C=Path('/private/tmp/module29-reconciliation');C.mkdir()
args=['python3','scripts/audit_upstream_tests.py','--upstream','/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99']
with (C/'inventory.log').open('xb') as f:p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
receipt=dict(status='passed',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,integrated_manifest_sha256=sha(R/'tests/upstream/manifest.json'),final_matrix_source=matrix['source'],evidence=records,predecessor_closure_sha256=sha(pred),inventory_command=args,inventory_log_sha256=sha(C/'inventory.log'),next_design_sha256=sha(R/'docs/frame-scan-design.md'),qualification='Bounded persistent dictionary suffix-input in-place milestone. Final public/native/platform/corpus/full-matrix and measured production sources match integrated bytes. Earlier component snapshots and rejected observation/test attempts retain their identities. Native helpers are external v1.5.7 oracles; generated layout cases do not upgrade unrelated original assertions. Prefix in-place, incremental overlap, workspace contracts and complete upstream parity remain open.')
(C/'reconciliation.json').write_text(json.dumps(receipt,indent=2)+'\n');name='2026-10-27-dictionary-in-place-closure';archive=E/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in C.iterdir():t.add(p,arcname=p.name)
 t.add(__file__,arcname='close-module.py')
receipt.update(archive=archive.name,archive_sha256=sha(archive));(E/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
p=R/'docs/dictionary-in-place-validation.md';s=p.read_text();old='Module 29 is in progress; final feature/release regression, measurements and\nsource reconciliation remain separate gates. Focused checks below are complete.';assert old in s;s=s.replace(old,'Module 29 is complete within its bounded persistent dictionary in-place scope.\nFocused, full feature/release, native/platform, measurements and final source\nreconciliation have independently retained successful receipts.');s+='\n## Final reconciliation and remaining scope\n\nAll integrated production and final tests match the frozen full-matrix source.\nEarlier staging and rejected helper/test attempts keep their original identities.\nRaw and prepared persistent dictionaries are supported. Prefix in-place lifecycle,\nincremental overlap, external workspaces, legacy/magicless frames and complete\nupstream parity remain outside this milestone.\nEvidence: `evidence/2026-10-27-dictionary-in-place-closure.json`.\n';p.write_text(s)
p=R/'README.md';s=p.read_text();old='Final qualification\nfor this extension remains in progress in `TODO.md`.';assert old in s;p.write_text(s.replace(old,'Its bounded qualification is recorded in\n[the dictionary in-place report](docs/dictionary-in-place-validation.md).'))
ratios=[f"{x['campaign']} {x['numerator']} {x['nonempty_geomean']:.4f}" for x in bench['summary']['comparisons'] if x['backend']=='all' and x['reference_backend']=='safe'];p=R/'docs/progress.md';p.write_text(p.read_text()+'''\n## Module 29: persistent dictionaries in in-place output complete (2026-10-27)

Persistent raw/prepared dictionaries remain immutably borrowed while one exclusive
caller buffer holds encoded suffix and decoded prefix. Frame selection validates
IDs, resets repeat offsets and applies immutable entropy fallback without cloned
handles, copied dictionary history or output allocation. Dictionary and scratch
allocators remain independent; fallible scratch is released on each failure.

All 72 final commands pass, including safe/all and 21 isolated complete suites,
true no_std and strict Clippy, safe/all release and formatting. Every full/release
suite reports 1,676 passed / 64 ignored across 97 groups. Normal/sanitized native
helpers qualify 1,836 shared-buffer layouts; explicit empty-input/window-expiry
and unused-suffix differences are retained. All 12,063 pinned dictionary corpus
files execute in safe/all release with zero skips. Prefix selections remain
outside this in-place supplement. Four foreign Miri and four core+alloc/actual
ARM artifact checks pass on the final test source.

All 23 primary and two independent-repeat backends have matching output and
allocation qualification, with separately timed restoration and combined modes.
All/safe nonempty median-latency geometric mean ratios: '''+ '; '.join(ratios)+'''.
Fixed-order host measurements establish no universal unsafe speedup.

The closure rehashes focused, matrix and measurement archives and matches final
integrated production/tests. Rejected helper/test attempts remain historical;
no unexecuted check or ignored adapter is credited as passing. The completed
checklist is cleared; Module 30 retains its structural-query decomposition.
Prefix in-place lifecycle, incremental overlap, workspaces and complete upstream
library/CLI parity remain open. See `dictionary-in-place-validation.md`,
`dictionary-in-place-benchmarks.md` and
`evidence/2026-10-27-dictionary-in-place-closure.json`.
''')
replacement='''Module 29 is complete within its bounded persistent dictionary in-place scope.
Completed work items are archived in Git history and `docs/progress.md`.
Qualification and measurements are in `docs/dictionary-in-place-validation.md`
and `docs/dictionary-in-place-benchmarks.md`. The final receipt is
`docs/evidence/2026-10-27-dictionary-in-place-closure.json`.
Complete upstream migration remains open.
''';(R/'TODO.md').write_text(todo[:start]+replacement+todo[end:])
paths=['TODO.md','README.md','docs/progress.md','docs/dictionary-in-place-validation.md','docs/evidence/'+name+'.json','docs/evidence/'+name+'.tar.gz'];subprocess.run(['cargo','fmt','--all','--','--check'],cwd=R,check=True);subprocess.run(['git','diff','--check'],cwd=R,check=True);subprocess.run(['git','add','--',*paths],cwd=R,check=True);subprocess.run(['git','commit','-m','Close persistent dictionary in-place decoding milestone'],cwd=R,check=True);previous.update(stage='closed',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip());state.write_text(json.dumps(previous,indent=2)+'\n')
