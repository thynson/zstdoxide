//! Supplementary frozen-preset integration boundary for Module 40.
use zstdoxide::{
    CompiledStreamOptions, CompressionParameterRequest, EndDirective, ReferenceStrategy,
    ReferenceStreamEncoder, StreamStatus, decompress,
};
fn frame(encoder: &mut ReferenceStreamEncoder<'_>, input: &[u8]) -> Vec<u8> {
    let mut bytes = Vec::new();
    let mut pos = 0;
    loop {
        let end = (pos + 997).min(input.len());
        let mut output = [0_u8; 31];
        let directive = if end == input.len() {
            EndDirective::Finish
        } else {
            EndDirective::Continue
        };
        let progress = encoder
            .process(&input[pos..end], &mut output, directive)
            .unwrap();
        pos += progress.consumed;
        bytes.extend_from_slice(&output[..progress.produced]);
        if progress.status == StreamStatus::FrameFinished {
            assert_eq!(pos, input.len());
            return bytes;
        }
    }
}
#[test]
fn a_level_request_switches_families_on_reused_frame_boundaries() {
    // Expected families are from the independently captured pinned v1.5.7
    // presets.tsv, level four in tiers 3, 2, 1 and 0 respectively.
    let fixtures = include_str!("upstream/parameters/presets.tsv");
    let request = CompressionParameterRequest::with_level(4);
    let mut encoder = ReferenceStreamEncoder::with_options(
        request,
        CompiledStreamOptions {
            pledged_size: Some(0),
            ..Default::default()
        },
    )
    .unwrap();
    for (length, pledged, tier, expected) in [
        (0, true, 3, ReferenceStrategy::Greedy),
        (16384, true, 3, ReferenceStrategy::Greedy),
        (65536, true, 2, ReferenceStrategy::DoubleFast),
        (200000, true, 1, ReferenceStrategy::Greedy),
        (4096, false, 0, ReferenceStrategy::DoubleFast),
        (513, true, 3, ReferenceStrategy::Greedy),
    ] {
        let row = fixtures
            .lines()
            .find(|line| line.starts_with(&format!("{tier}\t4\t")))
            .unwrap();
        let native_code: usize = row.split('\t').next_back().unwrap().parse().unwrap();
        assert_eq!(
            native_code,
            if expected == ReferenceStrategy::Greedy {
                3
            } else {
                2
            }
        );
        let source: Vec<_> = (0..length)
            .map(|i| b"family changes preserve reset entropy and history"[i % 48])
            .collect();
        let options = CompiledStreamOptions {
            pledged_size: pledged.then_some(length as u64),
            checksum: true,
            ..Default::default()
        };
        encoder.reset_with_options(options).unwrap();
        assert_eq!(encoder.parameters(), None);
        let reused = frame(&mut encoder, &source);
        assert_eq!(encoder.parameters().unwrap().strategy(), expected);
        let mut fresh = ReferenceStreamEncoder::with_options(request, options).unwrap();
        let independent = frame(&mut fresh, &source);
        assert_eq!(reused, independent);
        assert_eq!(decompress(&reused, source.len()).unwrap(), source);
        println!(
            "{length}\t{pledged}\t{tier}\t{native_code}\t{}",
            reused.len()
        );
    }
}
