from pathlib import Path
import copy,hashlib,json,struct,sys,tempfile
sys.path.insert(0,str(Path.cwd()/'scripts'))
import check_optimal_frame_baseline as m
attempts=[]
def guard(event,args):
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec','os.spawn'):
  attempts.append(event);raise RuntimeError('no children')
sys.addaudithook(guard)
original=m.check();pack=(m.ROOT/m.COLLECTION/'cases.bin').read_bytes();provenance=(m.ROOT/m.COLLECTION/'provenance.json').read_bytes();manifest=(m.ROOT/'tests/fixtures/reference-optimal-interop-recipes/recipes.json').read_bytes();records=[]
def test(name,change,trust=False):
 with tempfile.TemporaryDirectory()as tmp:
  root=Path(tmp);d=root/m.COLLECTION;d.mkdir(parents=True);other=root/'tests/fixtures/reference-optimal-interop-recipes';other.mkdir();(other/'recipes.json').write_bytes(manifest)
  b=bytearray(pack);v=copy.deepcopy(original);b,v=change(b,v);encoded=(json.dumps(v,sort_keys=True,indent=2)+'\n').encode();(d/'cases.bin').write_bytes(b);(d/'provenance.json').write_bytes(encoded)
  pins=m.PACK_SHA,m.PROVENANCE_SHA
  if trust:m.PACK_SHA=hashlib.sha256(b).hexdigest();v['pack_sha256']=m.PACK_SHA;v['pack_bytes']=len(b);encoded=(json.dumps(v,sort_keys=True,indent=2)+'\n').encode();(d/'provenance.json').write_bytes(encoded);m.PROVENANCE_SHA=hashlib.sha256(encoded).hexdigest()
  try:
   try:m.check(root)
   except (ValueError,KeyError,StopIteration,UnicodeError,struct.error):records.append(name)
   else:raise RuntimeError('accepted '+name)
  finally:m.PACK_SHA,m.PROVENANCE_SHA=pins

def byte(at,value):
 def alter(b,v):b[at]=value;return b,v
 return alter
for name,change in [('truncated',lambda b,v:(b[:-1],v)),('trailing',lambda b,v:(b+b'x',v)),('magic',byte(0,0)),('count',byte(8,23)),('name-bound',byte(12,255)),('name',byte(16,0)),('frame-byte',byte(len(pack)-1,0))]:test(name,change)
for name,change in [('truncated-structural',lambda b,v:(b[:-1],v)),('trailing-structural',lambda b,v:(b+b'x',v)),('magic-structural',byte(0,0)),('count-structural',byte(8,23)),('name-bound-structural',byte(12,255)),('name-structural',byte(16,0))]:test(name,change,True)
for name,key,val in [('schema-bool','schema_version',True),('wrong-revision','upstream_revision','0'*40),('wrong-manifest','recipe_manifest_sha256','0'*64),('capture-evidence','capture_evidence_sha256','bad'),('missing-case','cases',original['cases'][:-1])]:
 def mutate(b,v):v[key]=val;return b,v
 test(name,mutate,True)
for field,val in [('index',True),('bytes',64.0),('offset',0),('frame_sha256','0'*64),('resolved',[10,6,6,1,3,1,7])]:
 def mutate(b,v):v['cases'][0][field]=val;return b,v
 test('case-'+field,mutate,True)
assert len(records)==23 and not attempts and m.check()==original
print(json.dumps(dict(status='passed',optimized=not __debug__,positive_cases=24,rejected=len(records),controls=records,child_attempts=len(attempts)),sort_keys=True,indent=2))
