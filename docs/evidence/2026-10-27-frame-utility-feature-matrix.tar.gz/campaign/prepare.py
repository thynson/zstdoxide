from pathlib import Path
import subprocess,shutil,json,hashlib
D=Path(__file__).parent;S=Path('/private/tmp/module31-final');R=Path('/private/tmp/module31-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not S.exists();subprocess.run(['cp','-cR',str(R),str(S)],check=True)
for folder,name in [('module31-native/replay-final','frame_utilities_native.rs'),('module31-native/replay-source','frame_utilities_history.rs'),('module31-platform/source','frame_utilities_platform.rs')]:shutil.copyfile(Path('/private/tmp')/folder/'tests'/name,S/'tests'/name)
subprocess.run(['cargo','fmt','--all'],cwd=S,check=True)
for p in (R/'src').glob('*.rs'):assert p.read_bytes()==(S/'src'/p.name).read_bytes()
source={str(p.relative_to(S)):sha(p) for f in ['src','tests','test-support'] for p in (S/f).rglob('*') if p.is_file()};source.update({n:sha(S/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']});(D/'preparation.json').write_text(json.dumps(dict(status='prepared',source=source,qualification='Frozen final utility candidate assembled from public and exact native/history/platform test sources. Full-matrix dispatch is deferred until the preceding three modules finish timing; do not modify this snapshot.'),indent=2)+'\n')
