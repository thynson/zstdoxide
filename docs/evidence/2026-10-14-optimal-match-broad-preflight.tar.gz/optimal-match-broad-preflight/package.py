from pathlib import Path
import hashlib,io,json,sys,tarfile
R=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize');sys.path.insert(0,str(R/'scripts'));sys.dont_write_bytecode=True
import optimal_match_broad_capture_plan as plan
O=Path('/tmp/zstdoxide-optimal-match-broad-preflight')
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
rows=json.loads((O/'evidence.json').read_text())
for row in rows:
 if row['exit_code']!=0 or sha((O/row['log']).read_bytes())!=row['sha256']:raise ValueError('checks')
source=plan.source_manifest();files={n:(R/n).read_bytes() for n in source}
files['scripts/check_optimal_match_broad_capture_controls.py']=(R/'scripts/check_optimal_match_broad_capture_controls.py').read_bytes()
files.update({'checks/'+p.name:p.read_bytes() for p in O.iterdir() if p.is_file()});files['runner.py']=Path('/tmp/zstdoxide-optimal-match-broad-preflight.py').read_bytes();files['package.py']=Path(__file__).read_bytes()
report=dict(status='passed',source=source,commands=180,positive_requests=37,malformed_packets=22,plan_rejections_per_mode=19,syntax_modes=['normal','sanitized'],scalar_comparisons=333,model_forgeries_per_mode=14,qualification='Reviewed helper, complete dependency/source plan, no-child plan controls and strict syntax checks before any C helper execution.')
files['manifest.json']=enc(report)
a=R/'docs/evidence/2026-10-14-optimal-match-broad-preflight.tar.gz'
if a.exists():raise ValueError('fresh archive required')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('optimal-match-broad-preflight/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 if {m.name:t.extractfile(m).read() for m in t}!={'optimal-match-broad-preflight/'+n:b for n,b in files.items()}:raise ValueError('archive verification')
report.update(archive=a.name,archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(files))
(R/'docs/evidence/2026-10-14-optimal-match-broad-preflight.json').write_bytes(enc(report))
p=R/'TODO.md';p.write_text(p.read_text().replace('- [ ] Validate chunked independent suffix replay and preflight the broader guarded helper before C execution.','- [x] Validate chunked independent suffix replay and preflight the broader guarded helper before C execution.'))
print(a.name,a.stat().st_size)
