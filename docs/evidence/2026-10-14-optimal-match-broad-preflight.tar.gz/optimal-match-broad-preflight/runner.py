from pathlib import Path
import hashlib,json,os,subprocess
R=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize');O=Path('/tmp/zstdoxide-optimal-match-broad-preflight');O.mkdir()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');rows=[];commands=[]
for mode,flags in [('normal',[]),('optimized',['-O'])]:
 commands.append(('model-'+mode,['python3',*flags,'scripts/check_optimal_match_broad_validation.py']))
 commands.append(('plan-'+mode,['python3',*flags,'scripts/check_optimal_match_broad_capture_plan.py','--upstream','/private/tmp/zstdoxide-reference-lazy-1.5.7']))
base=['clang','-std=c11','-g','-DDEBUGLEVEL=2','-DZSTD_DISABLE_ASM','-DZSTD_LEGACY_SUPPORT=0','-UZSTD_MULTITHREAD','-DXXH_NAMESPACE=ZSTD_','-I','/private/tmp/zstdoxide-reference-lazy-1.5.7/lib','-I','/private/tmp/zstdoxide-reference-lazy-1.5.7/lib/common','-I','/private/tmp/zstdoxide-reference-lazy-1.5.7/lib/compress']
for mode,flags in [('normal',['-O2']),('sanitized',['-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer'])]:
 commands.append(('syntax-'+mode,base+flags+['-Wall','-Wextra','-Werror','-fsyntax-only','scripts/oracles/optimal_matches_broad.c']))
for label,argv in commands:
 log=O/(label+'.log');print('START',label,flush=True)
 with log.open('xb') as f:r=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 rows.append(dict(label=label,argv=argv,exit_code=r.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
 (O/'evidence.json').write_text(json.dumps(rows,indent=2)+'\n')
 if r.returncode:raise RuntimeError(label)
 print('PASS',label,flush=True)
