from pathlib import Path
import json,time,subprocess,os,hashlib
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while True:
 p=D/'evidence.json'
 if p.exists():
  try:j=json.loads(p.read_text())
  except json.JSONDecodeError:time.sleep(1);continue
  assert j['status'] in ['building','qualified-not-timed'],j.get('error')
  if j['status']=='qualified-not-timed':break
 time.sleep(10)
e={'status':'running','commands':[],'source_sha256':sha(S/'benches/dictionary_in_place_output.rs')}
for label,args in [('format',['cargo','fmt','--all','--','--check']),('clippy',['cargo','clippy','--offline','--locked','--bench','dictionary_in_place_output','--all-features','--','-D','warnings'])]:
 with (D/('harness-'+label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env={**os.environ,'CARGO_TARGET_DIR':str(D/'harness-target'),'CARGO_BUILD_JOBS':'2'},stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode));(D/'harness-check.json').write_text(json.dumps(e,indent=2)+'\n');assert p.returncode==0,label
 e['status']='passed' if label=='clippy' else 'running';(D/'harness-check.json').write_text(json.dumps(e,indent=2)+'\n')
subprocess.run(['python3',str(D/'repeat-build.py')],check=True)
