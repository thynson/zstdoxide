//! Identical fixed layouts, separate source restoration and scratch accounting.
//! Every timed operation uses a per-call clock, including the direct baseline.
//! Source/destination allocation, validation and tracking ledgers are not timed.
use std::{hint::black_box, time::Instant};
use zstdoxide::{
    DecodeOptions, Dictionary, decompress_in_place_with_dictionary,
    decompress_in_place_with_dictionary_in, decompress_into_with_dictionary,
    decompress_into_with_dictionary_in, decompression_margin,
};
use zstdoxide_test_allocator::{AllocatorConfig, TrackingAllocator};

fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |h, &b| {
        (h ^ u64::from(b)).wrapping_mul(0x100000001b3)
    })
}
struct Case {
    name: &'static str,
    frame: Vec<u8>,
    source: Vec<u8>,
    dictionary: Vec<u8>,
    raw: bool,
    tight: bool,
}
fn cases() -> Vec<Case> {
    let mut cases = Vec::new();
    macro_rules! fixture {
        ($name:literal, $dict:literal, $raw:literal) => {
            cases.push(Case {
                name: $name,
                frame: include_bytes!(concat!("../tests/upstream/dictionaries/", $name, ".zst"))
                    .to_vec(),
                source: include_bytes!(concat!(
                    "../tests/upstream/dictionaries/",
                    $name,
                    ".expected"
                ))
                .to_vec(),
                dictionary: include_bytes!(concat!("../tests/upstream/dictionaries/", $dict))
                    .to_vec(),
                raw: $raw,
                tight: false,
            });
        };
    }
    fixture!("p0-far-dictionary", "boundary-dictionary.raw", true);
    fixture!(
        "dictionary-to-frame-eviction",
        "boundary-dictionary.raw",
        true
    );
    fixture!("formatted-id", "formatted.dict", false);
    fixture!("formatted-omitted-id", "formatted.dict", false);
    fixture!("dictionary-treeless-literals", "formatted.dict", false);
    fixture!("dictionary-treeless-four-streams", "formatted.dict", false);
    fixture!("dictionary-repeat-sequences", "trained.dict", false);
    let dictionary =
        include_bytes!("../tests/upstream/data/golden-dictionaries/http-dict-missing-symbols")
            .to_vec();
    cases.push(Case {
        name: "http",
        frame: include_bytes!("../tests/upstream/data/generated/http-dictionary.zst").to_vec(),
        source: include_bytes!("../tests/upstream/data/golden-compression/http").to_vec(),
        dictionary: dictionary.clone(),
        raw: false,
        tight: false,
    });
    cases.push(Case {
        name: "empty",
        frame: vec![0x28, 0xb5, 0x2f, 0xfd, 0x20, 0, 1, 0, 0],
        source: Vec::new(),
        dictionary: dictionary.clone(),
        raw: false,
        tight: false,
    });
    let mut frame = cases[7].frame.clone();
    frame.extend_from_slice(&cases[7].frame);
    let mut source = cases[7].source.clone();
    source.extend_from_slice(&cases[7].source);
    cases.push(Case {
        name: "concatenated",
        frame,
        source,
        dictionary: dictionary.clone(),
        raw: false,
        tight: false,
    });
    let source: Vec<_> = (0..120000).map(|i| (i * 7 + 13) as u8).collect();
    let mut frame = vec![0x28, 0xb5, 0x2f, 0xfd, 0xa0];
    frame.extend_from_slice(&(source.len() as u32).to_le_bytes());
    frame.extend_from_slice(&(((source.len() as u32) << 3) | 1).to_le_bytes()[..3]);
    frame.extend_from_slice(&source);
    cases.push(Case {
        name: "raw-overlap",
        frame,
        source,
        dictionary,
        raw: false,
        tight: true,
    });
    cases
}
fn main() {
    let command = std::env::args().nth(1).expect("qualify or measure");
    assert!(command == "qualify" || command == "measure");
    for Case {
        name,
        frame,
        source,
        dictionary: dictionary_bytes,
        raw,
        tight,
    } in cases()
    {
        let dictionary = if raw {
            Dictionary::raw(&dictionary_bytes)
        } else {
            Dictionary::from_bytes(&dictionary_bytes)
        }
        .unwrap()
        .into_shared();
        let capacity = if tight {
            frame.len()
        } else {
            (source.len() + decompression_margin(&frame).unwrap()).max(frame.len())
        };
        let input_start = capacity - frame.len();
        let mut buffer = vec![0xa5; capacity + 16];
        buffer[8 + input_start..8 + capacity].copy_from_slice(&frame);
        let before = buffer.clone();
        let mut direct = vec![0xa5; capacity + 16];
        let options = DecodeOptions::new(source.len());
        assert_eq!(
            decompress_in_place_with_dictionary(
                &mut buffer[8..8 + capacity],
                input_start,
                &dictionary,
                options
            ),
            Ok(source.len())
        );
        assert_eq!(&buffer[8..8 + source.len()], source);
        assert_eq!(&buffer[..8], &before[..8]);
        assert_eq!(&buffer[8 + source.len()..], &before[8 + source.len()..]);
        assert_eq!(
            decompress_into_with_dictionary(
                &frame,
                &mut direct[8..8 + capacity],
                &dictionary,
                options
            ),
            Ok(source.len())
        );
        assert_eq!(&direct[8..8 + source.len()], source);
        if command == "qualify" {
            for mode in ["in-place", "direct"] {
                let owner = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                let monitor = owner.monitor();
                let dictionary_owner = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                let dictionary_monitor = dictionary_owner.monitor();
                let selected = if raw {
                    Dictionary::raw_in(&dictionary_bytes, &dictionary_owner)
                } else {
                    Dictionary::from_bytes_in(&dictionary_bytes, &dictionary_owner)
                }
                .unwrap();
                let dictionary_before = dictionary_monitor.snapshot();
                let view = selected.view();
                if mode == "in-place" {
                    buffer[8 + input_start..8 + capacity].copy_from_slice(&frame);
                    assert_eq!(
                        decompress_in_place_with_dictionary_in(
                            &mut buffer[8..8 + capacity],
                            input_start,
                            &view,
                            options,
                            owner
                        ),
                        Ok(source.len())
                    );
                } else {
                    assert_eq!(
                        decompress_into_with_dictionary_in(
                            &frame,
                            &mut direct[8..8 + capacity],
                            &view,
                            options,
                            owner
                        ),
                        Ok(source.len())
                    );
                }
                assert_eq!(dictionary_monitor.snapshot(), dictionary_before);
                drop(selected);
                drop(dictionary_owner);
                dictionary_monitor.assert_released();
                monitor.assert_released();
                let s = monitor.snapshot();
                assert_eq!(s.identities_created, s.owners_dropped);
                println!(
                    "{name}\t{mode}\t{}\t{:016x}\t{capacity}\t{input_start}\t{}\t{}\t{}\t{}",
                    source.len(),
                    fingerprint(&source),
                    s.attempts,
                    s.requested_bytes,
                    s.peak_bytes,
                    s.deallocate_calls
                );
                let d = dictionary_monitor.snapshot();
                assert_eq!(d.identities_created, d.owners_dropped);
                println!(
                    "{name}\tdictionary-{mode}\t{}\t{:016x}\t{}\t{}\t{}\t{}",
                    dictionary_bytes.len(),
                    fingerprint(&dictionary_bytes),
                    d.attempts,
                    d.requested_bytes,
                    d.peak_bytes,
                    d.deallocate_calls
                );
            }
            continue;
        }
        let iterations = (1024 * 1024 / source.len().max(1)).clamp(8, 1024);
        for mode in [
            "in-place-decode",
            "direct-decode",
            "restore-only",
            "in-place-with-restore",
        ] {
            for sample in 0..5 {
                let mut elapsed = 0;
                for _ in 0..iterations {
                    if mode == "in-place-decode" {
                        buffer[8 + input_start..8 + capacity].copy_from_slice(black_box(&frame));
                    }
                    let start = Instant::now();
                    match mode {
                        "in-place-decode" => {
                            black_box(
                                decompress_in_place_with_dictionary(
                                    black_box(&mut buffer[8..8 + capacity]),
                                    black_box(input_start),
                                    black_box(&dictionary),
                                    black_box(options),
                                )
                                .unwrap(),
                            );
                        }
                        "direct-decode" => {
                            black_box(
                                decompress_into_with_dictionary(
                                    black_box(&frame),
                                    black_box(&mut direct[8..8 + capacity]),
                                    black_box(&dictionary),
                                    black_box(options),
                                )
                                .unwrap(),
                            );
                        }
                        "restore-only" => {
                            black_box(&mut buffer[8 + input_start..8 + capacity])
                                .copy_from_slice(black_box(&frame));
                        }
                        "in-place-with-restore" => {
                            black_box(&mut buffer[8 + input_start..8 + capacity])
                                .copy_from_slice(black_box(&frame));
                            black_box(
                                decompress_in_place_with_dictionary(
                                    black_box(&mut buffer[8..8 + capacity]),
                                    black_box(input_start),
                                    black_box(&dictionary),
                                    black_box(options),
                                )
                                .unwrap(),
                            );
                        }
                        _ => unreachable!(),
                    }
                    elapsed += start.elapsed().as_nanos();
                }
                if mode != "restore-only" {
                    assert_eq!(&buffer[8..8 + source.len()], source);
                }
                assert_eq!(&direct[8..8 + source.len()], source);
                assert_eq!(&buffer[..8], &before[..8]);
                assert_eq!(&buffer[8 + source.len()..], &before[8 + source.len()..]);
                println!("{name}\t{mode}\t{sample}\t{iterations}\t{elapsed}");
            }
        }
    }
}
