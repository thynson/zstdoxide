from pathlib import Path
import shutil
D=Path(__file__).parent;S=D/'source';R=Path('/private/tmp/module29-candidate');S.mkdir()
for n in ['src','tests','test-support','benches']:shutil.copytree(R/n,S/n)
for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(R/n,S/n)
with (S/'Cargo.toml').open('a') as f:f.write('\n[[bench]]\nname = "dictionary_in_place_output"\nharness = false\n')
s=Path('/private/tmp/module28-benchmark/source/benches/in_place_output.rs').read_text().replace('DecodeOptions, decompress_in_place_with_options, decompress_in_place_with_options_in,','DecodeOptions, Dictionary, decompress_in_place_with_dictionary, decompress_in_place_with_dictionary_in,').replace('decompress_into_with_options, decompress_into_with_options_in,','decompress_into_with_dictionary, decompress_into_with_dictionary_in,')
start=s.index('fn cases()');end=s.index('fn main()',start)
s=s[:start]+'''struct Case {
    name: &'static str,
    frame: Vec<u8>,
    source: Vec<u8>,
    dictionary: Vec<u8>,
    raw: bool,
    tight: bool,
}
fn cases() -> Vec<Case> {
    let mut cases = Vec::new();
    macro_rules! fixture {
        ($name:literal, $dict:literal, $raw:literal) => {
            cases.push(Case {
                name: $name,
                frame: include_bytes!(concat!("../tests/upstream/dictionaries/", $name, ".zst")).to_vec(),
                source: include_bytes!(concat!("../tests/upstream/dictionaries/", $name, ".expected")).to_vec(),
                dictionary: include_bytes!(concat!("../tests/upstream/dictionaries/", $dict)).to_vec(),
                raw: $raw,
                tight: false,
            });
        };
    }
    fixture!("p0-far-dictionary", "boundary-dictionary.raw", true);
    fixture!("dictionary-to-frame-eviction", "boundary-dictionary.raw", true);
    fixture!("formatted-id", "formatted.dict", false);
    fixture!("formatted-omitted-id", "formatted.dict", false);
    fixture!("dictionary-treeless-literals", "formatted.dict", false);
    fixture!("dictionary-treeless-four-streams", "formatted.dict", false);
    fixture!("dictionary-repeat-sequences", "trained.dict", false);
    let dictionary = include_bytes!("../tests/upstream/data/golden-dictionaries/http-dict-missing-symbols").to_vec();
    cases.push(Case { name: "http", frame: include_bytes!("../tests/upstream/data/generated/http-dictionary.zst").to_vec(), source: include_bytes!("../tests/upstream/data/golden-compression/http").to_vec(), dictionary: dictionary.clone(), raw: false, tight: false });
    cases.push(Case { name: "empty", frame: vec![0x28, 0xb5, 0x2f, 0xfd, 0x20, 0, 1, 0, 0], source: Vec::new(), dictionary: dictionary.clone(), raw: false, tight: false });
    let mut frame = cases[7].frame.clone();
    frame.extend_from_slice(&cases[7].frame);
    let mut source = cases[7].source.clone();
    source.extend_from_slice(&cases[7].source);
    cases.push(Case { name: "concatenated", frame, source, dictionary: dictionary.clone(), raw: false, tight: false });
    let source: Vec<_> = (0..120000).map(|i| (i * 7 + 13) as u8).collect();
    let mut frame = vec![0x28, 0xb5, 0x2f, 0xfd, 0xa0];
    frame.extend_from_slice(&(source.len() as u32).to_le_bytes());
    frame.extend_from_slice(&(((source.len() as u32) << 3) | 1).to_le_bytes()[..3]);
    frame.extend_from_slice(&source);
    cases.push(Case { name: "raw-overlap", frame, source, dictionary, raw: false, tight: true });
    cases
}
''' + s[end:]
s=s.replace('for (name, frame, source, tight) in cases() {','for Case { name, frame, source, dictionary: dictionary_bytes, raw, tight } in cases() {\n        let dictionary = if raw { Dictionary::raw(&dictionary_bytes) } else { Dictionary::from_bytes(&dictionary_bytes) }.unwrap().into_shared();')
s=s.replace('decompress_in_place_with_options','decompress_in_place_with_dictionary').replace('decompress_into_with_options','decompress_into_with_dictionary')
s=s.replace('input_start, options)', 'input_start, &dictionary, options)').replace('capacity], options)', 'capacity], &dictionary, options)')
s=s.replace('let monitor = owner.monitor();','''let monitor = owner.monitor();
                let dictionary_owner = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                let dictionary_monitor = dictionary_owner.monitor();
                let selected = if raw { Dictionary::raw_in(&dictionary_bytes, &dictionary_owner) } else { Dictionary::from_bytes_in(&dictionary_bytes, &dictionary_owner) }.unwrap();
                let dictionary_before = dictionary_monitor.snapshot();
                let view = selected.view();''')
s=s.replace('                            input_start,\n                            options,','                            input_start,\n                            &view,\n                            options,').replace('                            &mut direct[8..8 + capacity],\n                            options,','                            &mut direct[8..8 + capacity],\n                            &view,\n                            options,')
s=s.replace('                monitor.assert_released();','''                assert_eq!(dictionary_monitor.snapshot(), dictionary_before);
                drop(selected);
                drop(dictionary_owner);
                dictionary_monitor.assert_released();
                monitor.assert_released();''')
s=s.replace('                                    black_box(options),','                                    black_box(&dictionary),\n                                    black_box(options),')
s=s.replace('s.deallocate_calls\n','s.deallocate_calls\n')
# The second ledger line records independently allocated immutable dictionary ownership.
s=s.replace('''                );
            }
            continue;''','''                );
                let d = dictionary_monitor.snapshot();
                assert_eq!(d.identities_created, d.owners_dropped);
                println!("{name}\\tdictionary-{mode}\\t{}\\t{:016x}\\t{}\\t{}\\t{}\\t{}", dictionary_bytes.len(), fingerprint(&dictionary_bytes), d.attempts, d.requested_bytes, d.peak_bytes, d.deallocate_calls);
            }
            continue;''')
(S/'benches/dictionary_in_place_output.rs').write_text(s)
s=Path('/private/tmp/module28-benchmark/build.py').read_text().replace('module28-candidate','module29-candidate').replace("'in_place_output'","'dictionary_in_place_output'").replace('len(rows)==22','len(rows)==44');(D/'build.py').write_text(s)
