"""Bounded independent stage-three review inputs; outside repository fixtures."""
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import time

upstream = Path('/tmp/zstdoxize-upstream-1.5.7')
prefix = Path('/tmp/zstdoxide-parameter-review-probe')
source = prefix.with_suffix('.c')
output = prefix.with_suffix('.tsv')
revision = 'f8745da6ff1ad1e7bab384bd1f9d742439278e99'
assert subprocess.check_output(['git', '-C', str(upstream), 'rev-parse', 'HEAD'], text=True).strip() == revision
subprocess.run(['git', '-C', str(upstream), 'diff', '--quiet', 'HEAD', '--', 'lib', 'tests'], check=True)
commands = [
    ['cc', '-std=c99', '-O2', '-Wall', '-Wextra', '-Werror', '-I', str(upstream / 'lib'), str(source), str(upstream / 'lib/libzstd.a'), '-pthread', '-o', str(prefix)],
    [str(prefix)],
]
records = []
for index, command in enumerate(commands):
    start = time.monotonic()
    result = subprocess.run(command, capture_output=True)
    log = prefix.with_suffix(f'.{index}.log')
    log.write_bytes(result.stderr if index else result.stdout + result.stderr)
    if index:
        output.write_bytes(result.stdout)
    records.append({'command': command, 'exit_code': result.returncode,
                    'seconds': round(time.monotonic() - start, 4), 'log': str(log),
                    'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()})
    result.check_returncode()
rows = list(csv.DictReader(output.read_text().splitlines(), delimiter='\t'))
assert len(rows) == 46 and all(len(row) == 21 and None not in row for row in rows)
fields = ('window', 'chain', 'hash', 'search', 'match', 'target', 'strategy')
def profile(row):
    return tuple(int(row[key]) for key in fields)
def group(case):
    return [row for row in rows if row['case'] == case]
assert [profile(row) for row in group('overrides_then_level')] == [profile(row) for row in group('level_then_overrides')]
for case in ('known_empty_ignores_hint', 'known_size_ignores_hint'):
    assert len({profile(row) for row in group(case)}) == 1
assert len({profile(row) for row in group('hint_and_dictionary')}) > 1
assert profile(group('original_adjust_assertion')[0])[1:3] == (17, 18)
assert len([row for row in rows if row['domain'].startswith('rust_reject_')]) == 5
files = [source, Path(__file__), output, upstream / 'lib/libzstd.a',
         upstream / 'lib/compress/zstd_compress.c', upstream / 'lib/compress/zstd_compress_internal.h',
         upstream / 'lib/zstd.h']
evidence = {'scope': 'External C-only preparation; no Rust comparison has run.',
            'revision': revision, 'executed_size_t_bits': 64, 'executed_int_bits': 32,
            'compiler': subprocess.check_output(['cc', '--version'], text=True),
            'rows': len(rows), 'ordinary_expected_comparisons': 41,
            'intentional_rust_rejections': 5, 'commands': records,
            'files': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files},
            'checks': ['all 46 C results pass ZSTD_checkCParams', 'all four override-order pairs agree',
                       'two known-size profiles ignore three source hints', 'unknown hint affects profile',
                       'original adjustment result chain17/hash18', 'five overflow/reserved rows explicitly classified'],
            'qualification': 'Checked Rust-domain classifications are expectations from the approved design, not C errors. Public adjustment with dictionary and window overflow intentionally rejects even where C wrapping happens to return unchanged fields.'}
path = prefix.with_suffix('.json')
path.write_text(json.dumps(evidence, indent=2) + '\n')
print('C-only probe: 46 rows / 41 ordinary comparisons / 5 intended Rust rejections')
print('Evidence SHA256:', hashlib.sha256(path.read_bytes()).hexdigest())
