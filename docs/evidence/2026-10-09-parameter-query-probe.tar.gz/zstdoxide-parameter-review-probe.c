/* External review oracle only; never compiled or linked into zstdoxide.
 * facebook/zstd v1.5.7 f8745da6ff1ad1e7bab384bd1f9d742439278e99.
 * Calls the pinned implementation directly; contains no adjustment algorithm.
 */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "compress/zstd_compress_internal.h"
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void require(int condition, const char* message) {
    if (!condition) { fprintf(stderr, "%s\n", message); exit(1); }
}
static void check(size_t value) { require(!ZSTD_isError(value), ZSTD_getErrorName(value)); }
static void fields(ZSTD_compressionParameters p) {
    printf("\t%u\t%u\t%u\t%u\t%u\t%u\t%u", p.windowLog, p.chainLog,
           p.hashLog, p.searchLog, p.minMatch, p.targetLength, (unsigned)p.strategy);
}
static void row(const char* label, const char* operation, const char* domain,
                U64 source, size_t dictionary, const ZSTD_CCtx_params* request) {
    ZSTD_compressionParameters result;
    if (!strcmp(operation,"public_query"))
        result=ZSTD_getCParams(request->compressionLevel, source, dictionary);
    else if (!strcmp(operation,"public_adjust"))
        result=ZSTD_adjustCParams(request->cParams, source, dictionary);
    else
        result=ZSTD_getCParamsFromCCtxParams(request,source,dictionary,ZSTD_cpm_noAttachDict);
    printf("%s\t%s\t%s\t%llu\t%llu\t%d\t%d",label,operation,domain,
           (unsigned long long)source,(unsigned long long)dictionary,
           request->compressionLevel,request->srcSizeHint);
    fields(request->cParams);fields(result);putchar('\n');
    check(ZSTD_checkCParams(result));
}
static void init(ZSTD_CCtx_params* request, int level) { check(ZSTD_CCtxParams_init(request,level)); }
static void mixed_overrides(ZSTD_CCtx_params* request) {
    check(ZSTD_CCtxParams_setParameter(request,ZSTD_c_windowLog,23));
    check(ZSTD_CCtxParams_setParameter(request,ZSTD_c_chainLog,25));
    check(ZSTD_CCtxParams_setParameter(request,ZSTD_c_hashLog,26));
    check(ZSTD_CCtxParams_setParameter(request,ZSTD_c_searchLog,6));
    check(ZSTD_CCtxParams_setParameter(request,ZSTD_c_strategy,ZSTD_btlazy2));
}
int main(void) {
    ZSTD_CCtx_params request;unsigned i,j;
    const U64 small[]={2,63,64,65,255,256,257,2047,2048,2049};
    const U64 large[]={(1ULL<<30)-2,(1ULL<<30)+2,(1ULL<<31)-2,(1ULL<<31)+2,1ULL<<32,1ULL<<40};
    const U64 override_sizes[]={0,16,513,16385};
    const unsigned hints[]={1,513,16384};
    require(ZSTD_versionNumber()==10507 && sizeof(size_t)==8 && sizeof(int)==4,"pinned host64 ABI required");
    puts("case\toperation\tdomain\tsource\tdictionary\tlevel\thint\toverride_window\toverride_chain\toverride_hash\toverride_search\toverride_match\toverride_target\toverride_strategy\twindow\tchain\thash\tsearch\tmatch\ttarget\tstrategy");
    init(&request,3);
    for(i=0;i<sizeof(small)/sizeof(small[0]);++i)
        row("small_source_dictionary_neighbors","public_query","ordinary_known",small[i],127,&request);
    init(&request,22);
    for(i=0;i<sizeof(large)/sizeof(large[0]);++i)
        row("large_source_neighbors","public_query","ordinary_known",large[i],1<<20,&request);
    for(i=0;i<2;++i) {
        init(&request,3);
        if(i==0)check(ZSTD_CCtxParams_setParameter(&request,ZSTD_c_compressionLevel,19));
        mixed_overrides(&request);
        if(i==1)check(ZSTD_CCtxParams_setParameter(&request,ZSTD_c_compressionLevel,19));
        for(j=0;j<sizeof(override_sizes)/sizeof(override_sizes[0]);++j)
            row(i?"overrides_then_level":"level_then_overrides","typed_request","ordinary_known",override_sizes[j],257,&request);
    }
    init(&request,3);mixed_overrides(&request);
    check(ZSTD_CCtxParams_setParameter(&request,ZSTD_c_strategy,ZSTD_btultra2));
    for(i=0;i<sizeof(override_sizes)/sizeof(override_sizes[0]);++i)
        row("two_pass_mixed_small","typed_request","ordinary_known",override_sizes[i],0,&request);
    for(i=0;i<sizeof(hints)/sizeof(hints[0]);++i) {
        init(&request,7);check(ZSTD_CCtxParams_setParameter(&request,ZSTD_c_srcSizeHint,(int)hints[i]));
        row("hint_and_dictionary","typed_request","ordinary_unknown",ZSTD_CONTENTSIZE_UNKNOWN,1000,&request);
        row("known_empty_ignores_hint","typed_request","ordinary_known",0,1000,&request);
        row("known_size_ignores_hint","typed_request","ordinary_known",65,1000,&request);
    }
    init(&request,22);
    row("known_sum_exact_max","public_query","ordinary_known",UINT64_MAX-1,1,&request);
    row("known_sum_overflow","public_query","rust_reject_sum_overflow",UINT64_MAX-1,2,&request);
    row("unknown_plus499_exact_max","typed_request","ordinary_unknown",UINT64_MAX,SIZE_MAX-499,&request);
    row("unknown_plus499_overflow","typed_request","rust_reject_plus499_overflow",UINT64_MAX,SIZE_MAX-498,&request);
    row("reserved_known","typed_request","rust_reject_reserved_known",UINT64_MAX,0,&request);
    init(&request,3);check(ZSTD_CCtxParams_setParameter(&request,ZSTD_c_srcSizeHint,16384));
    row("hint_makes_known_sum_overflow","typed_request","rust_reject_hint_sum_overflow",UINT64_MAX,SIZE_MAX-1000,&request);
    init(&request,1);
    request.cParams=ZSTD_getCParams(1,UINT64_MAX,0);
    request.cParams.windowLog=10;
    row("dictionary_window_exact_max","public_adjust","ordinary_known",1,SIZE_MAX-1024,&request);
    row("dictionary_window_overflow","public_adjust","rust_reject_dictionary_window_overflow",1,SIZE_MAX-1023,&request);
    request.cParams=(ZSTD_compressionParameters){10,19,19,0,0,0,0};
    row("original_adjust_assertion","public_adjust","ordinary_known",1000,100000,&request);
    return ferror(stdout)?1:0;
}
