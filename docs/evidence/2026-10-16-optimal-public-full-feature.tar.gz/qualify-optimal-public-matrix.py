from pathlib import Path
import hashlib,json,re,tomllib
R=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def need(v,why):
 if not v:raise ValueError(why)
def load(path):
 p=Path(path);v=json.loads(p.read_text());need(v['status']=='passed' and v.get('source_unchanged',True) is True,'completed '+path);return p,v
safe_p,safe=load('/tmp/zstdoxide-optimal-public-full-safe-v3-1016/evidence.json')
focus_p,focus=load('/tmp/zstdoxide-optimal-public-matrix-1016/evidence.json')
full_p,full=load('/tmp/zstdoxide-optimal-public-full-feature-1016/evidence.json')
features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'})
need(len(features)==19 and focus['features']==full['features']==features,'all isolated features')
need(focus['source']==full['source']==safe['source'],'identical full source inventories')
need(all(sha(R/p)==h for p,h in safe['source'].items()),'current sources unchanged')
need(focus['prior_full_safe_sha256']==full['prior_full_safe_sha256']==sha(safe_p),'bound prior safe qualification')
expected_focus=[p+f for f in features for p in ('test-','public-','nostd-')]+['full-all','full-release-all','clippy','fmt']
expected_full=['full-'+f for f in features]+['nostd-safe','nostd-all','clippy-safe','allocator-test','allocator-clippy','allocator-fmt']
need([r['label']for r in focus['commands']]==expected_focus and [r['label']for r in full['commands']]==expected_full,'complete ordered command inventory')
rows=[]
case_pattern=re.compile(r'^test (.+?) \.\.\. (ok|ignored(?:,.*)?)$',re.M)
def cases(p):return sorted((name,'ignored'if status.startswith('ignored')else status)for name,status in case_pattern.findall(p.read_text()))
baseline_cases=cases(safe_p.parent/safe['log']);need(len(baseline_cases)==1395 and sum(status=='ignored'for _,status in baseline_cases)==55,'complete safe case-name inventory')
def totals(p):
 values=[tuple(map(int,x))for x in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.read_text())];need(values,'actual test summaries');return list(map(sum,zip(*values)))
for root,record in [(focus_p.parent,focus),(full_p.parent,full)]:
 for row in record['commands']:
  need(row['exit_code']==0 and sha(root/row['log'])==row['sha256'],'successful intact command '+row['label'])
  if row['label'].startswith('full-'):
   need(cases(root/row['log'])==baseline_cases,'same complete case names/outcomes '+row['label'])
   rows.append(dict(label=row['label'],counts=totals(root/row['log']),log_sha256=row['sha256']))
need(sha(safe_p.parent/safe['log'])==safe['sha256'] and safe['exit_code']==0,'complete safe log')
rows.insert(0,dict(label='full-safe',counts=totals(safe_p.parent/safe['log']),log_sha256=safe['sha256']))
need(len(rows)==22 and all(r['counts']==[1340,0,55]for r in rows),'same complete passing suites and explicit ignores')
components=[dict(path=str(p),sha256=sha(p))for p in (safe_p,focus_p,full_p)]
report=dict(status='passed',source_unchanged=True,isolated_features=19,failed_commands=0,full_suites=22,identical_full_case_outcome_inventory=True,full_test_executions=29480,explicit_ignored_executions=1210,focused_feature_test_executions=19*(86+5),true_no_std_builds=21,source=safe['source'],components=components,suites=rows,qualification='All nineteen isolated features run the complete unfiltered Cargo suite; safe, all, release-all, separate Optimal-focused checks, strict Clippy/formatting, allocator and true no_std commands also pass. Ignored tests are not successes.')
Path('/tmp/optimal-public-matrix-barrier.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ('source','suites')},sort_keys=True))
