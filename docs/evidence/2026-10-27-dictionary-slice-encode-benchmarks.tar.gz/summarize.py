from pathlib import Path
import json,statistics,math,csv
D=Path(__file__).parent;records=[];index={};comparisons=[];builds=json.loads((D/'evidence.json').read_text())['builds']
for campaign,folder,names in [('primary',D,[r['name'] for r in builds]),('repeat',D/'repeat',['safe','all'])]:
 assert json.loads((folder/'timed.json').read_text())['status']=='passed'
 for name in names:
  groups={}
  for line in (folder/(name+'-timed.tsv')).read_text().splitlines():
   case,mode,sample,iterations,elapsed=line.split('\t');groups.setdefault((case,mode),[]).append(int(elapsed)/int(iterations))
  for (case,mode),samples in groups.items():
   assert len(samples)==5;row=dict(campaign=campaign,backend=name,case=case,mode=mode,median_ns=statistics.median(samples),minimum_ns=min(samples),maximum_ns=max(samples));records.append(row);index[campaign,name,case,mode]=row['median_ns']
with (D/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
cases=sorted({line.split('\t')[0] for line in (D/'safe-qualify.tsv').read_text().splitlines()});assert len(cases)==33;gm=lambda v:math.exp(sum(math.log(x) for x in v)/len(v))
for campaign in ['primary','repeat']:
 for backend in (['safe','all'] if campaign=='repeat' else [r['name'] for r in builds]):
  for numerator,denominator,reference in [('allocated','allocated','safe'),('borrowed','borrowed','safe'),('borrowed','allocated',backend)]:
   ratios={case:index[campaign,backend,case,numerator]/index[campaign,reference,case,denominator] for case in cases};comparisons.append(dict(campaign=campaign,backend=backend,numerator=numerator,denominator=denominator,reference_backend=reference,ratios=ratios,nonempty_geomean=gm([v for k,v in ratios.items() if not k.endswith('-empty')])))
for row in comparisons:
 row['dictionary_geomeans']={}
 for kind in ['empty-dictionary','raw-dictionary','prepared-dictionary']:
  values=[v for k,v in row['ratios'].items() if k.startswith(kind+'-') and not k.endswith('-empty')];assert len(values)==10;row['dictionary_geomeans'][kind]=gm(values)
(D/'summary.json').write_text(json.dumps(dict(samples_per_row=5,unit='nanoseconds per operation',aggregation='Equal-weight geometric mean of per-case median latency ratios over thirty nonempty dictionary/input pairs; the three empty-input pairs remain separate. Both modes include per-call codec scratch. Allocated mode includes returned destination allocation/destruction; borrowed mode excludes caller buffer setup. Immutable dictionary preparation is excluded in both modes. Role-routed allocation qualification is separate from Global timing. No confidence intervals or universal speedup claim.',rows=records,comparisons=comparisons),indent=2)+'\n')
for a in comparisons:
 if a['backend'] in ['safe','all'] and (a['numerator']!=a['denominator'] or a['backend']=='all'):print(a['campaign'],a['backend'],a['numerator'],a['denominator'],a['reference_backend'],round(a['nonempty_geomean'],4))
