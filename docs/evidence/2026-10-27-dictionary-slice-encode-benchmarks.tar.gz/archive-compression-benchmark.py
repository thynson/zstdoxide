from pathlib import Path
import hashlib,json,tarfile,importlib.util,datetime
D=Path('/private/tmp/module34-compression-benchmark');E=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();spec=importlib.util.spec_from_file_location('measure',D/'measure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b,gates=m.validate();r=json.loads((D/'repeat/evidence.json').read_text());q=json.loads((D/'timed.json').read_text());z=json.loads((D/'repeat/timed.json').read_text());s=json.loads((D/'summary.json').read_text())
assert q['status']==z['status']=='passed' and len(q['runs'])==24 and len(z['runs'])==2;assert q['gates']==z['gates']==gates;assert z['primary_timing_sha256']==sha(D/'timed.json') and z['build_evidence_sha256']==sha(D/'repeat/evidence.json')
for folder,build,timed in [(D,b,q),(D/'repeat',r,z)]:
 for row in build['builds']:
  assert sha(folder/row['executable'])==row['sha256'];assert (folder/(row['name']+'-qualify.tsv')).read_bytes()==(D/'safe-qualify.tsv').read_bytes()
 for row in timed['runs']:assert sha(folder/(row['name']+'-timed.tsv'))==row['sha256']
fixtures={'source/tests/upstream/data/golden-compression/http','source/tests/upstream/data/golden-compression/large-literal-and-match-lengths','source/tests/upstream/dictionaries/formatted.dict'};files={}
for p in D.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(D)
 if any(x=='target' or x.endswith('-target') or x=='__pycache__' or x.endswith('.dSYM') for x in rel.parts):continue
 if 'source' in rel.parts and p.suffix not in {'.rs','.toml','.lock','.json','.py','.md','.sh','.csv','.tsv'} and str(rel) not in fixtures:continue
 files[str(rel)]=p
assert fixtures<=files.keys();files['archive-compression-benchmark.py']=Path(__file__);files['LICENSE.zstd']=Path('/Users/lanxingcan/Workspace/zstdoxize/LICENSE.zstd');name='2026-10-27-dictionary-slice-encode-benchmarks';archive=E/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
result=dict(status='passed',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),build=b,repeat_build=r,primary_timing=q,repeat_timing=z,summary=s,members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()},archive=archive.name,archive_sha256=sha(archive),qualification='All 24 safe/isolated/all production feature selections and two independently rebuilt repeats retain all 330 samples and 198 role-specific qualification rows per executable. Destination/staging/workspace/dictionary ledgers are outside timings; Global per-call scratch and allocated destination destruction are inside. Caller output setup is outside borrowed clocks; immutable dictionary construction is outside both modes, with unchanged snapshots during compression. Actual process barriers precede campaigns. No universal speedup, desktop idleness, C byte identity or complete codec replacement is claimed.')
(E/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
report = """# Dictionary-backed caller-owned compression measurements

Thirty-three fixed pairs combine empty, raw and prepared dictionaries with eleven
inputs: empty/tiny data, content-size boundaries, raw/RLE and multiblock input,
and two retained upstream golden fixtures. Every output exactly matches the
existing Rust allocating dictionary encoder. Caller guards and unused success
suffixes are checked outside timing; C byte identity is not a contract.

Twenty-four primary executables (safe, all 22 isolated features and all features)
and independently rebuilt safe/all repeats each retain 330 samples: 33 pairs,
two operations and five samples. Per-operation clocks include all Global scratch
allocation/release. Allocated mode includes returned destination allocation and
destruction; borrowed mode uses a preallocated caller buffer. Immutable dictionary
construction, input/buffer setup, byte/guard verification and accounting are
outside both clocks. Both operations borrow the same DictionaryView. Two fresh
process observations gate each campaign without claiming desktop idleness.

Each executable retains 198 identical qualification rows. The original allocator
owns destination or one-block staging; independent clones own workspace. A separate
dictionary family records construction/release, with exact unchanged snapshots
through compression. These dictionary ledger counts are not timed scratch counts.
Every owner releases through its own domain. Borrowed staging stays within one
raw block plus its header. Timed calls use Global without the role router.

| Campaign | Backend | Operation | Reference | All nonempty pairs | Empty dictionary | Raw dictionary | Prepared dictionary |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |
"""
for x in s['comparisons']:
 if x['backend'] in ['safe','all'] and (x['numerator']!=x['denominator'] or x['backend']=='all'):
  values=[x['nonempty_geomean'],*[x['dictionary_geomeans'][k] for k in ['empty-dictionary','raw-dictionary','prepared-dictionary']]]
  report+=f"| {x['campaign']} | {x['backend']} | {x['numerator']} | {x['reference_backend']} {x['denominator']} | "+' | '.join(f'{v:.4f}' for v in values)+' |\n'
report+="""
Ratios are equal-weight geometric means of per-pair median latency ratios, using
30 nonempty pairs overall and ten per dictionary kind. The three empty-input
pairs remain in raw data. Values below one mean lower observed numerator latency
on this host. Fixed order and five samples do not establish statistical
significance, a universal unsafe benefit or elimination of scratch allocation.
All executables, source, fixture payloads, raw samples and barriers are retained.
Evidence: `evidence/2026-10-27-dictionary-slice-encode-benchmarks.json`.
"""
(E/'dictionary-slice-encode-benchmarks.md').write_text(report)
