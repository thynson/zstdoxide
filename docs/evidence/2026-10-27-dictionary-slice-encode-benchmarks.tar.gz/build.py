from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,tomllib,datetime,signal
D=Path(__file__).parent;S=D/'source';R=Path('/private/tmp/module34-public/source');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,28,9,38,0,tzinfo=datetime.timezone.utc).timestamp();features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'));assert len(features)==22
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};production={n:h for n,h in source.items() if n.startswith('src/')};assert production=={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')}
env={**os.environ,'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(D/'target')}
def command(args,cwd,environment,out,err=None):
 assert time.time()<deadline-30,args
 p=subprocess.Popen(args,cwd=cwd,env=environment,stdout=out,stderr=err if err is not None else subprocess.STDOUT,start_new_session=True)
 try:return p.wait(timeout=max(1,deadline-time.time()-30))
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  raise TimeoutError('Work window reached during '+str(args))
h=dict(status='running',source=source,source_sha256=sha(S/'benches/dictionary_slice_encode.rs'),commands=[])
def save_h():(D/'harness-check.json').write_text(json.dumps(h,indent=2)+'\n')
save_h()
try:
 for label,args in [('safe',['cargo','clippy','--offline','--locked','--bench','dictionary_slice_encode','--','-D','warnings']),('all',['cargo','clippy','--offline','--locked','--bench','dictionary_slice_encode','--all-features','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check'])]:
  t=time.monotonic()
  with (D/('harness-'+label+'.log')).open('xb') as f:code=command(args,S,{**env,'CARGO_TARGET_DIR':str(D/'harness-target')},f)
  h['commands'].append(dict(label=label,argv=args,exit_code=code,seconds=time.monotonic()-t,log_sha256=sha(D/('harness-'+label+'.log'))));save_h();assert code==0,label
 h['status']='passed';save_h()
except BaseException as ex:h.update(status='interrupted-at-user-deadline' if isinstance(ex,TimeoutError) else 'failed',error=repr(ex));save_h();raise
for repeat in [False,True]:
 Q=D/'repeat' if repeat else D
 if repeat:Q.mkdir()
 e=dict(status='building',source=source,production_source=production,builds=[],qualification='Thirty-three fixed dictionary/input pairs, three immutable dictionary kinds and eleven inputs. Clock-free ledgers separate destination or staging, workspace and dictionary construction/release. Dictionary snapshots must remain unchanged during either codec call; no handle clone or runtime dictionary allocation is inferred from timing. No measured performance claim before complete qualified builds and full matrix.')
 if repeat:e['source_evidence_sha256']=sha(D/'evidence.json')
 def save():(Q/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
 save()
 try:
  for name,flags in ([('safe',[]),('all',['--all-features'])] if repeat else [('safe',[]),*[(f,['--features',f]) for f in features],('all',['--all-features'])]):
   args=['cargo','bench','--offline','--locked','--bench','dictionary_slice_encode','--no-run','--message-format=json',*flags];t=time.monotonic()
   with (Q/(name+'-build.jsonl')).open('xb') as out,(Q/(name+'-build.log')).open('xb') as err:code=command(args,S,{**env,'CARGO_TARGET_DIR':str(Q/'target')},out,err)
   assert code==0,(name,'build')
   artifacts=[json.loads(line) for line in (Q/(name+'-build.jsonl')).read_text().splitlines() if line.startswith('{')];exes=[a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='dictionary_slice_encode' and a.get('executable')];assert len(exes)==1
   exe=Q/'executables'/name;exe.parent.mkdir(exist_ok=True);shutil.copyfile(exes[0],exe);exe.chmod(0o755)
   with (Q/(name+'-qualify.tsv')).open('xb') as out,(Q/(name+'-qualify.stderr')).open('xb') as err:code=command([str(exe),'qualify'],S,env,out,err)
   payload=(Q/(name+'-qualify.tsv')).read_bytes();assert code==0 and len(payload.decode().splitlines())==198,(name,'qualification')
   if repeat or name!='safe':assert payload==(D/'safe-qualify.tsv').read_bytes(),(name,'ledger parity')
   e['builds'].append(dict(name=name,argv=args,seconds=time.monotonic()-t,executable=str(exe.relative_to(Q)),sha256=sha(exe),qualification_sha256=sha(Q/(name+'-qualify.tsv'))));save();print('repeat' if repeat else 'primary',name,'built and qualified',flush=True)
  for n,value in source.items():assert sha(S/n)==value,n
  e['status']='qualified-not-timed';save()
 except BaseException as ex:e.update(status='interrupted-at-user-deadline' if isinstance(ex,TimeoutError) else 'failed',error=repr(ex));save();raise
