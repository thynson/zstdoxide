"""Observe actual compiler/test quiescence immediately before each timed campaign."""
from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,28,9,38,0,tzinfo=datetime.timezone.utc).timestamp()
# This explicit dispatch ledger is frozen when timing is authorized locally.
ledger=json.loads((D/'timing-dispatch-gates.json').read_text());assert ledger['status']=='ready'
for name,status in ledger['receipts'].items():assert json.loads(Path(name).read_text())['status']==status,name
pattern=re.compile('(?:/|\\s)(?:rustc|cargo(?:-miri)?|miri|cc|clang)(?:\\s|$)|/private/tmp/module\\d+-[^ ]*(?:target/|/(?:check[^ /]*|run[^ /]*|build[^ /]*|capture|generate|repeat-build|after-build|resume[^ /]*|prepare[^ /]*|archive[^ /]*|prune[^ /]*)\\.py)')
def barrier(folder):
 observations=[]
 while len(observations)<2:
  raw=subprocess.check_output(['ps','-axo','pid,ppid,pcpu,etime,command'],text=True)
  matches=[line.strip() for line in raw.splitlines()[1:] if int(line.split()[0])!=os.getpid() and pattern.search(line)]
  if matches:observations=[]
  else:observations.append(dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),active_task_or_compiler_processes=matches))
  if time.time()>=deadline-30:raise TimeoutError('User deadline before measurement CPU barrier')
  time.sleep(5)
 p=folder/'cpu-barrier.json';assert not p.exists();p.write_text(json.dumps(dict(status='passed',observer_sha256=sha(Path(__file__)),dispatch_gate_sha256=sha(D/'timing-dispatch-gates.json'),receipt_sha256={n:sha(Path(n)) for n in ledger['receipts']},process_observations=observations,qualification='Two fresh process inventories show no matched task compiler/test/build/archive processes. This is not a claim that the entire desktop is idle.'),indent=2)+'\n')
for repeat in [False,True]:
 barrier(D/'repeat' if repeat else D)
 subprocess.run(['python3',str(D/'measure.py'),*(['--repeat'] if repeat else [])],check=True)
subprocess.run(['python3',str(D/'summarize.py')],check=True)
