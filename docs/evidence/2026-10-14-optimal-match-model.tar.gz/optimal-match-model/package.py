from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize')
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
files={n:(R/n).read_bytes() for n in ['scripts/oracles/optimal_match_validation.py','scripts/check_optimal_match_validation.py','scripts/oracles/optimal_matches.py','scripts/oracles/optimal_match_recipes.py','scripts/oracles/tree_validation.py','scripts/oracles/tree_direct.py','docs/reference-optimal-match-protocol.md','tests/fixtures/reference-optimal-match-recipes/recipes.json']}
for mode in ['normal','optimized']:
 b=Path('/tmp/zstdoxide-optimal-match-model-'+mode+'.log').read_bytes();v=json.loads(b)
 if v['status']!='passed' or v['forged_rejections']!=44 or v['child_attempts']!=0:raise ValueError('checks')
 files['logs/'+mode+'.json']=b
report=dict(status='passed',recipes=29,queries=273,forged_rejections_per_mode=44,child_attempts=0,qualification='Independent Python model with direct source suffix comparison and checked integer links. Synthetic transcripts and hand-calculated cases only; no C execution or observed C match expectations.',files={n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())})
files['package.py']=Path(__file__).read_bytes();files['manifest.json']=enc(report)
a=R/'docs/evidence/2026-10-14-optimal-match-model.tar.gz'
if a.exists():raise ValueError('fresh archive required')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('optimal-match-model/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 if {m.name:t.extractfile(m).read() for m in t}!={'optimal-match-model/'+n:b for n,b in files.items()}:raise ValueError('archive verification')
report.update(archive=a.name,archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(files))
(R/'docs/evidence/2026-10-14-optimal-match-model.json').write_bytes(enc(report))
p=R/'TODO.md';s=p.read_text().replace('- [ ] Implement independent tiny sorted-tree/all-match replay','- [x] Implement independent tiny sorted-tree/all-match replay');p.write_text(s)
p=R/'docs/reference-optimal-validation.md';s=p.read_text();s+='''\n## Independent tiny search model\n\nDirect suffix comparison and checked integer links independently reconstruct\ncomplete heads, paired nodes, short-key heads, both frontiers and ordered matches\nfor all 29 recipes / 273 queries. Hand-calculated cases cover repeat intent order,\nstrict target equality, short-key early return, full tails and skipped positions.\nNormal and optimized Python each reject 44 forged records without child execution.\n\n`evidence/2026-10-14-optimal-match-model.json` retains exact code and logs. These\nare synthetic model transcripts before C capture, not upstream observed fixtures.\nThe model is a test oracle only and is not part of the Rust codec.\n''';p.write_text(s)
print(a.name,a.stat().st_size)
