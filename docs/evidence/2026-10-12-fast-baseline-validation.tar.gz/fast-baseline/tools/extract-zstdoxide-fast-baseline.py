from pathlib import Path
import hashlib,io,json,tarfile
root=Path('/Users/lanxingcan/Workspace/zstdoxize');dest=root/'tests/fixtures/reference-fast-baseline';dest.mkdir(parents=True,exist_ok=False)
arc=root/'docs/evidence/2026-10-09-fast-benchmark-harness.tar.gz';raw=arc.read_bytes();pin='86dbe4cf13e542944bb6ae7fc2bd8e8dfbee513b1b24b25729b97c47096da968';assert hashlib.sha256(raw).hexdigest()==pin
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 def get(n):return t.extractfile(n).read()
 e=json.loads(get('smoke-5/evidence.json'));lm=json.loads(get('log-map.json'));fm=json.loads(get('frame-map.json'))
 assert e['status']=='passed' and not e['timed'] and e['configs']==['safe','all']
 rows={c:[json.loads(x) for x in get(lm['smoke-5/run-'+c+'.stdout']).splitlines()][1:] for c in e['configs']};assert rows['safe']==rows['all']
 fields=['attempts','allocate_calls','grow_calls','peak_live_blocks','peak_requested_bytes','peak_bytes','returned_requested_bytes','returned_bytes','identities_created','owners_dropped','final_live_blocks','final_live_bytes']
 header=['workload','profile','source_bytes','source_fnv1a64','source_sha256','window_log','chain_log','hash_log','search_log','min_match','target_length','strategy','frame_offset','frame_bytes','frame_fnv1a64','frame_sha256']+fields
 text=['\t'.join(header)];pack=bytearray();offsets={}
 for r in rows['safe']:
  name=r['workload']+'-'+r['profile']+'.zst';b=get(fm['smoke-5/frames/safe/'+name]);assert b==get(fm['smoke-5/frames/all/'+name]);h=hashlib.sha256(b).hexdigest()
  assert e['frames']['safe'][name]=={'bytes':len(b),'sha256':h}
  if h not in offsets:offsets[h]=len(pack);pack.extend(b)
  values=[r['workload'],r['profile'],r['source_bytes'],r['source_fnv1a64'],e['inputs'][r['workload']]['sha256'],*r['resolved'],offsets[h],len(b),r['frame_fnv1a64'],h,*[r['allocation'][f] for f in fields]]
  assert r['allocation']['violations'] is False and r['samples']==[]
  text.append('\t'.join(map(str,values)))
 (dest/'expected.tsv').write_text('\n'.join(text)+'\n');(dest/'frames.bin').write_bytes(pack)
 provenance={'schema_version':1,'archive':arc.relative_to(root).as_posix(),'archive_sha256':pin,'campaign_member':'smoke-5/evidence.json','campaign_sha256':hashlib.sha256(get('smoke-5/evidence.json')).hexdigest(),'captured_revision':get(lm['smoke-5/head.stdout']).decode().strip(),'compiler':e['compiler'],'target':e['host'],'toolchain':e['toolchain'],'configs':e['configs'],'timed':False,'source':e['source'],'inputs':e['inputs'],'rows':9,'unique_frames':len(offsets),'pack_bytes':len(pack),'allocation_fields':fields,'files':{n:hashlib.sha256((dest/n).read_bytes()).hexdigest() for n in ['expected.tsv','frames.bin']},'qualification':'Complete zstdoxide frames and exact allocation survey from the reviewed clock-free smoke-5, before DoubleFast changes. No timing or exact independent C decode is claimed for these nine frames. Exact allocation replay is qualified to the recorded target/toolchain.'}
 (dest/'provenance.json').write_text(json.dumps(provenance,sort_keys=True,indent=2)+'\n')
 print('rows',9,'unique frames',len(offsets),'pack bytes',len(pack),'capture revision',provenance['captured_revision'])
