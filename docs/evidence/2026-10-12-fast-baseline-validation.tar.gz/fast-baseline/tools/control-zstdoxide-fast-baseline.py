from pathlib import Path
import hashlib,json,shutil,subprocess,tempfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-fast-baseline-controls-2026-10-12');OUT.mkdir(exist_ok=False)
COL='tests/fixtures/reference-fast-baseline';ARC='docs/evidence/2026-10-09-fast-benchmark-harness.tar.gz'
mutations=['tsv-byte','tsv-extra-row','allocation-float','offset','frame-byte','frame-missing','provenance-bool','provenance-duplicate','provenance-source','extra-file','archive-byte','escaping-frame']
records=[]
for optimized in [False,True]:
 for name in ['positive',*mutations]:
  directory=OUT/(('optimized-' if optimized else 'normal-')+name);(directory/'docs/evidence').mkdir(parents=True);shutil.copy2(ROOT/ARC,directory/ARC);shutil.copytree(ROOT/COL,directory/COL)
  c=directory/COL;t=c/'expected.tsv';p=c/'provenance.json';f=c/'frames.bin'
  if name=='tsv-byte':t.write_bytes(t.read_bytes().replace(b'skewed',b'sKEWED',1))
  elif name=='tsv-extra-row':t.write_bytes(t.read_bytes()+t.read_bytes().splitlines(keepends=True)[1])
  elif name in ['allocation-float','offset']:
   rows=t.read_text().splitlines();v=rows[1].split('\t');v[16 if name=='allocation-float' else 12]='137.0' if name=='allocation-float' else '1';rows[1]='\t'.join(v);t.write_text('\n'.join(rows)+'\n')
  elif name=='frame-byte':b=bytearray(f.read_bytes());b[0]^=1;f.write_bytes(b)
  elif name=='frame-missing':f.unlink()
  elif name=='provenance-bool':j=json.loads(p.read_text());j['rows']=True;p.write_text(json.dumps(j))
  elif name=='provenance-duplicate':p.write_text('{"rows":9,'+p.read_text().lstrip()[1:])
  elif name=='provenance-source':j=json.loads(p.read_text());j['source']['src/fast_parse.rs']='0'*64;p.write_text(json.dumps(j))
  elif name=='extra-file':(c/'extra.txt').write_text('extra')
  elif name=='archive-byte':a=directory/ARC;a.write_bytes(a.read_bytes()+b'extra')
  elif name=='escaping-frame':f.unlink();f.symlink_to(ROOT/COL/'frames.bin')
  argv=['python3']+(['-O'] if optimized else [])+[str(ROOT/'scripts/check_reference_fast_baseline.py'),'--root',str(directory)]
  r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30);expected=0 if name=='positive' else 1
  record={'name':name,'optimized':optimized,'argv':argv,'exit_code':r.returncode,'expected_exit':expected,'output':r.stdout.decode()};records.append(record)
  if r.returncode!=expected:raise RuntimeError(record)
  shutil.rmtree(directory)
(OUT/'evidence.json').write_text(json.dumps({'status':'passed','controls':records,'positive':2,'rejected':24},indent=2)+'\n')
print('26 controls passed: 2 positive, 24 rejected; normal and optimized Python.')
