from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,tomllib
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-fast-baseline-validation-final-2026-10-12');OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'scripts'));import benchmark_search
ENV=benchmark_search.effective_environment()|{'CARGO_TARGET_DIR':'/tmp/zstdoxide-fast-baseline-target','CARGO_NET_OFFLINE':'true','CARGO_TERM_COLOR':'never'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=list((ROOT/'src').rglob('*.rs'))+[ROOT/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/reference_fast_defaults.rs','scripts/check_reference_fast_baseline.py','examples/fast_benchmark.rs','scripts/benchmark_fast.py']]+list((ROOT/'tests/fixtures/reference-fast-baseline').iterdir())
def source():return {str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}
e={'status':'running','date':'2026-10-12','source':source(),'environment':ENV,'commands':[]}
def save():(OUT/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
def run(label,argv):
 start=time.monotonic();p=OUT/(label+'.log')
 with p.open('wb') as f:r=subprocess.run(argv,cwd=ROOT,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 record={'label':label,'argv':argv,'cwd':str(ROOT),'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':p.name,'log_sha256':sha(p)}
 matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',p.read_text())
 if matches:record['test_counts']=[list(map(int,m)) for m in matches]
 e['commands'].append(record);save();print(label,r.returncode,record.get('test_counts',''),flush=True)
 if r.returncode:raise RuntimeError(label)
cargo=['cargo','+nightly-2026-10-08'];features=[x for x in tomllib.loads((ROOT/'Cargo.toml').read_text())['features'] if x not in ['default','std']]
try:
 run('rustc',['rustc','+nightly-2026-10-08','-vV'])
 for label,flags in [('safe',[]),('match-table',['--features','unsafe-match-table']),('all',['--all-features']),('nostd',['--no-default-features']),('nostd-all',['--no-default-features','--features',','.join(features)])]:
  run('baseline-'+label,cargo+['test','--offline','--locked','--test','reference_fast_defaults']+flags)
 for label,flags in [('safe',[]),('all',['--all-features'])]:
  run('named-'+label,cargo+['test','--offline','--locked','--test','match_search_defaults']+flags)
  run('clippy-'+label,cargo+['clippy','--offline','--locked','--test','reference_fast_defaults']+flags+['--','-D','warnings'])
 run('format',['rustfmt','--edition','2024','--config','skip_children=true','--check','tests/reference_fast_defaults.rs'])
 run('audit',['python3','scripts/check_reference_fast_baseline.py']);run('audit-optimized',['python3','-O','scripts/check_reference_fast_baseline.py'])
 e['source_unchanged']=source()==e['source'];assert e['source_unchanged'];e['status']='passed';save()
except BaseException as error:e['status']='failed';e['error']=repr(error);save();raise
