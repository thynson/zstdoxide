from pathlib import Path
import hashlib,io,json,tarfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize')
FINAL=Path('/tmp/zstdoxide-fast-baseline-validation-final-2026-10-12');INITIAL=Path('/tmp/zstdoxide-fast-baseline-validation-2026-10-12');CONTROLS=Path('/tmp/zstdoxide-fast-baseline-controls-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
e=json.loads((FINAL/'evidence.json').read_text());assert e['status']=='passed' and e['source_unchanged']
for n,h in e['source'].items(): assert sha((ROOT/n).read_bytes())==h,n
members={}
for label,folder in [('final',FINAL),('initial',INITIAL),('controls',CONTROLS)]:
 for p in folder.iterdir():
  if p.is_file():members[label+'/'+p.name]=p.read_bytes()
for source in ['/tmp/check-zstdoxide-fast-baseline.py','/tmp/check-zstdoxide-fast-baseline-final.py','/tmp/control-zstdoxide-fast-baseline.py','/tmp/extract-zstdoxide-fast-baseline.py','/tmp/package-zstdoxide-fast-baseline.py']:
 members['tools/'+Path(source).name]=Path(source).read_bytes()
for n in ['tests/reference_fast_defaults.rs','scripts/check_reference_fast_baseline.py','scripts/check.sh','scripts/check_upstream_oracles.sh','tests/fixtures/reference-fast-baseline/expected.tsv','tests/fixtures/reference-fast-baseline/provenance.json','tests/fixtures/reference-fast-baseline/README.md']:
 members['source/'+n]=(ROOT/n).read_bytes()
old=(ROOT/'tests/reference_fast_defaults.rs').read_text().replace('let saved = request;','let saved = request.clone();').encode()
assert sha(old)==json.loads((INITIAL/'evidence.json').read_text())['source']['tests/reference_fast_defaults.rs'];members['initial-source/tests/reference_fast_defaults.rs']=old
report={'status':'passed','date':'2026-10-12','scope':'Activate a complete pre-DoubleFast Fast frame and allocator regression using historical clock-free observations; no production, timed benchmark or C oracle execution.','final_commands':len(e['commands']),'new_test_executions':20,'new_test_configurations':['safe','unsafe-match-table','all','no-default','no-default-plus-all-unsafe'],'unchanged_named_test_executions':14,'ignored':0,'offline_controls':{'positive':2,'rejected':24},'initial_diagnostic':'Clippy rejected clone() on Copy CompressionParameterRequest in the new test. Replaced with a copy; all focused commands reran and passed. Initial logs and test source are retained.','archive':'2026-10-12-fast-baseline-validation.tar.gz','capture_archive':'2026-10-09-fast-benchmark-harness.tar.gz','capture_mode':'clock-free smoke-5, safe/all','frame_rows':9,'distinct_frames':7,'distinct_frame_bytes':1090164,'source_manifest':e['source'],'omissions':'Original frame pack remains in the committed fixture and original capture archive; its exact hash is retained. Build artifacts/executables are omitted.'}
members['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode()
manifest={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())};members['bundle-manifest.json']=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
archive=ROOT/'docs/evidence'/report['archive'];assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('fast-baseline/'+n);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())=={'fast-baseline/'+n for n in members}
 for n,b in members.items():assert t.extractfile('fast-baseline/'+n).read()==b
report.update(archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,archive_members=len(members))
(ROOT/'docs/evidence/2026-10-12-fast-baseline-validation.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print('Passed',report['final_commands'],'commands;',len(members),'archive members;',archive.stat().st_size,'bytes')
