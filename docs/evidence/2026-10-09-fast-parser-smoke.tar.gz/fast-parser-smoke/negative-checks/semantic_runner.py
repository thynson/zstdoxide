import importlib.util, pathlib, sys
sys.dont_write_bytecode=True
s=importlib.util.spec_from_file_location("subject",sys.argv[1]); m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
try:
 m.validate(pathlib.Path(sys.argv[2]))
except (ValueError, OSError, KeyError, TypeError, OverflowError) as error:
 print("rejected: "+str(error));sys.exit(3)
print("accepted")
