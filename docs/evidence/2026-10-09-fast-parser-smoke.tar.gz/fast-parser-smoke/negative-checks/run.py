#!/usr/bin/env python3
"""Independent offline positive/negative checks; no C process is launched."""
from pathlib import Path
import copy, hashlib, importlib.util, json, os, shutil, subprocess, sys
sys.dont_write_bytecode = True
ROOT = Path('/Users/lanxingcan/Workspace/zstdoxize')
DRIVER = ROOT / 'scripts/import_fast_parser_smoke.py'
COLLECTION = ROOT / 'tests/upstream/fast-parser'
DEST = Path('/tmp/zstdoxide-fast-parser-negative-validation')

def check(value, message):
    if not value:
        raise RuntimeError(message)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(p, value):
    p.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

check(not DEST.exists(), 'use a fresh negative-validation directory')
DEST.mkdir()
spec=importlib.util.spec_from_file_location('oracle', DRIVER)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=[json.loads(x) for x in (COLLECTION/'observations.jsonl').read_text().splitlines()]
source_before={str(p):sha(p) for p in [DRIVER,*sorted(COLLECTION.iterdir())] if p.is_file()}
commands=[]
runner_code='''import importlib.util, pathlib, sys\nsys.dont_write_bytecode=True\ns=importlib.util.spec_from_file_location("subject",sys.argv[1]); m=importlib.util.module_from_spec(s);s.loader.exec_module(m)\ntry:\n m.validate(pathlib.Path(sys.argv[2]))\nexcept (ValueError, OSError, KeyError, TypeError, OverflowError) as error:\n print("rejected: "+str(error));sys.exit(3)\nprint("accepted")\n'''
(DEST/'semantic_runner.py').write_text(runner_code)

def execute(label, args, code, contains, optimized):
    command=[sys.executable,*(['-O'] if optimized else []),*map(str,args)]
    env={'PATH':'/nonexistent','PYTHONDONTWRITEBYTECODE':'1','LC_ALL':'C','LANG':'C','TZ':'UTC'}
    result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,timeout=30)
    prefix=DEST/(('optimized-' if optimized else 'normal-')+label)
    out=prefix.with_suffix('.stdout');err=prefix.with_suffix('.stderr')
    out.write_text(result.stdout);err.write_text(result.stderr)
    record={'label':label,'optimized':optimized,'command':command,'environment':env,'expected_exit_code':code,'exit_code':result.returncode,'expected_text':contains,'stdout':out.name,'stdout_sha256':sha(out),'stderr':err.name,'stderr_sha256':sha(err)}
    commands.append(record)
    save(DEST/'commands.json',commands)
    check(result.returncode==code, f'{label}: exit {result.returncode} != {code}: {result.stdout}{result.stderr}')
    check(contains in result.stdout+result.stderr, f'{label}: missing expected text {contains}: {result.stdout}{result.stderr}')

# Each semantic control bypasses fixed observation hashes to reach the independent parser.
mutations=[]
def case(name, change, message):
    rows=copy.deepcopy(original);change(rows)
    path=DEST/(name+'.jsonl');path.write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in rows))
    mutations.append((name,path,message))

def row(rows,name,padding=106):
    return next(r for r in rows[1:] if r['id']==name and r['padding']==padding)

def table_update(item,slot,value):
    item['table_after_c'][slot]=value
    item['table_after_positions'][slot]=None if value<2 else value-2
    item['table_after_le32_fnv1a64']=module.fingerprint(b''.join(v.to_bytes(4,'little') for v in item['table_after_c']))

case('missing-row',lambda r:r.pop(),'exactly one metadata and eighteen case records')
case('duplicate-row',lambda r:r.__setitem__(2,copy.deepcopy(r[1])),'unexpected or duplicate recipe/padding')
case('reordered-rows',lambda r:r.__setitem__(slice(1,3),list(reversed(r[1:3]))),'canonical recipe/padding order')
case('unknown-field',lambda r:r[1].__setitem__('unknown',1),'exact case fields')
case('metadata-boolean-count',lambda r:r[0].__setitem__('case_count',True),'metadata integer/host types')
case('metadata-zero-size',lambda r:r[0].__setitem__('sizeof_match_state',0),'metadata integer/host types')
case('boolean-literal-length',lambda r:row(r,'repeat-one')['sequences'][0].__setitem__('ll',True),'sequence integers')
case('boolean-distance',lambda r:row(r,'repeat-one')['sequences'][0].__setitem__('distance',True),'sequence positive match/offset')
case('negative-match-length',lambda r:row(r,'repeat-one')['sequences'][0].__setitem__('ml',-1),'sequence integers')
case('oversized-match',lambda r:row(r,'repeat-one')['sequences'][0].__setitem__('ml',2**50),'bounded match reconstruction')
case('zero-offset-base',lambda r:row(r,'repeat-one')['sequences'][0].__setitem__('off_base',0),'sequence positive match/offset')
case('zero-repeat',lambda r:row(r,'repeat-one')['parser_repeats'].__setitem__(2,0),'repeat array types')
case('source-bytes-wrong',lambda r:r[1].__setitem__('source_hex','00'+r[1]['source_hex'][2:]),'independent recipe bytes')
case('literal-bytes-short',lambda r:row(r,'repeat-one').__setitem__('stored_literals_hex','41'),'literal source range')
case('parser-third-cell',lambda r:row(r,'prefix-explicit')['parser_repeats'].__setitem__(2,4),'distinct repeat state')
case('long-length-type',lambda r:row(r,'long-match').__setitem__('long_length_type',0),'exact expanded long-length metadata')
case('long-length-position',lambda r:row(r,'long-match').__setitem__('long_length_position',1),'exact expanded long-length metadata')
case('table-sentinel-one',lambda r:table_update(row(r,'repeat-four'),0,1),'sentinel one is not supplied or produced by Fast')
case('normalized-table-mismatch',lambda r:row(r,'repeat-four')['table_after_positions'].__setitem__(0,123),'normalized table')
case('table-key-partial-tail',lambda r:table_update(row(r,'repeat-four'),0,64),'complete table key fits logical source')
case('offset-intent-label',lambda r:row(r,'prefix-explicit')['sequences'][0].__setitem__('intent','repeat'),'offset label')
case('negative-trailing-literals',lambda r:row(r,'short-seven').__setitem__('trailing_literals',-1),'case nonnegative integer fields')
case('false-helper-success',lambda r:row(r,'repeat-four').__setitem__('guards_intact',False),'helper success flags')
case('boolean-table-slot',lambda r:row(r,'repeat-four')['table_after_c'].__setitem__(0,True),'table U32 schema')

def pair_mutation(rows):
    item=row(rows,'repeat-four',195)
    for slot,value in enumerate(item['table_after_c']):
        if 2<=value<=58:
            table_update(item,slot,value+4)
            return
    raise RuntimeError('no same-key alternate table witness')
case('padding-pair-detachment',pair_mutation,'complete padding-pair observation independence')
for name,content,reason in [
    ('duplicate-json-field',(COLLECTION/'observations.jsonl').read_text().replace('"record":"metadata"','"record":"metadata","record":"metadata"',1),'duplicate JSON field record'),
    ('nonfinite-json',(COLLECTION/'observations.jsonl').read_text().replace('"recipe_count":9','"recipe_count":NaN',1),'non-JSON scalar NaN')]:
    # Original C uses compact JSON; substitutions must actually occur.
    check(content!=(COLLECTION/'observations.jsonl').read_text(),f'{name}: control did not change source')
    path=DEST/(name+'.jsonl');path.write_text(content);mutations.append((name,path,reason))

collections=[]
def fixture_case(name,change,message):
    dest=DEST/name;shutil.copytree(COLLECTION,dest);change(dest)
    collections.append((name,dest,message))

def edit_manifest(directory, change):
    path=directory/'manifest.json';value=json.loads(path.read_text());change(value);save(path,value)

fixture_case('missing-observations',lambda d:(d/'observations.jsonl').unlink(),'fixture collection contains missing/unlisted files')
fixture_case('missing-helper',lambda d:(d/'fast_oracle.c').unlink(),'fixture collection contains missing/unlisted files')
fixture_case('corrupt-observations',lambda d:(d/'observations.jsonl').write_bytes((d/'observations.jsonl').read_bytes().replace(b'abcdefg',b'xbcdefg',1)),'frozen C observation bytes')
fixture_case('stale-importer-hash',lambda d:edit_manifest(d,lambda m:m.__setitem__('importer_sha256','0'*64)),'current importer source hash')
fixture_case('source-hash-detached',lambda d:edit_manifest(d,lambda m:m['source_sha256'].__setitem__('lib/zstd.h','0'*64)),'pinned source catalog: lib/zstd.h')
fixture_case('unlisted-file',lambda d:(d/'unlisted').write_text('unlisted'),'fixture collection contains missing/unlisted files')
fixture_case('coverage-boolean-confusion',lambda d:edit_manifest(d,lambda m:m['coverage'].__setitem__('collector',0)),'fixture coverage scope')
fixture_case('capture-host-detached',lambda d:edit_manifest(d,lambda m:m['capture']['metadata'].__setitem__('pointer_bits',32)),'capture metadata differs from the observations')
def symlink_escape(d):
    (d/'observations.jsonl').unlink();(d/'observations.jsonl').symlink_to(COLLECTION/'observations.jsonl')
fixture_case('symlink-escape',symlink_escape,'fixture path escapes collection')
def resign(d):
    path=d/'observations.jsonl';path.write_bytes(path.read_bytes()+b'\n')
    edit_manifest(d,lambda m:m['fixtures'][0].update(size=path.stat().st_size,sha256=sha(path)))
fixture_case('resigned-observation-substitution',resign,'frozen observation manifest')

for optimized in (False,True):
    execute('offline-control',[DRIVER,'--check'],0,'18 observations / 9 recipes',optimized)
    execute('semantic-control',[DEST/'semantic_runner.py',DRIVER,COLLECTION/'observations.jsonl'],0,'accepted',optimized)
    for name,path,message in mutations:
        execute(name,[DEST/'semantic_runner.py',DRIVER,path],3,'rejected: '+message,optimized)
    for name,path,message in collections:
        execute(name,[DRIVER,'--check','--collection',path],1,message,optimized)
    for inverse in (False,True):
        outer=DEST/f'overlap-{optimized}-{inverse}'
        output,report=((outer/'nested',outer) if inverse else (outer,outer/'normal-observations.stdout'))
        execute('output-under-report' if inverse else 'report-under-output',
                [DRIVER,'--upstream','/tmp/zstdoxize-upstream-1.5.7','--output',output,'--report',report],
                1,'regeneration output and report must have disjoint paths',optimized)
        check(not outer.exists(),'overlap rejection created filesystem artifacts')
source_after={str(p):sha(p) for p in [DRIVER,*sorted(COLLECTION.iterdir())] if p.is_file()}
check(source_before==source_after,'source changed during offline validation')
summary={'schema_version':1,'result':'passed','normal_commands':sum(not c['optimized'] for c in commands),
         'optimized_commands':sum(c['optimized'] for c in commands),'positive_controls':4,
         'semantic_negatives_per_mode':len(mutations),'collection_negatives_per_mode':len(collections),
         'path_overlap_negatives_per_mode':2,'expected_rejections':len(commands)-4,
         'empty_search_path':True,'compiler_or_subprocess_from_importer':False,
         'source_before':source_before,'source_after':source_after,'commands_sha256':sha(DEST/'commands.json'),
         'runner_sha256':sha(Path(__file__))}
save(DEST/'summary.json',summary)
print(json.dumps(summary,indent=2))
