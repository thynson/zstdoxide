# Verified first direct Fast helper checkpoint

Final helper and driver are frozen. No repository file was edited.
The README is preserved as the pre-execution design included in the recorded
input manifests; this report supplies the subsequent execution status.

The reviewed C helper passed normal and ASan/UBSan builds, with nine recipes
and two initialized padding patterns per recipe. Each final mode executed
18 cases, covering 132334 logical source bytes including saved prefix bytes.
All 18 canonical records and the metadata are byte-identical across the two
final builds. The independent Python validator reconstructed source recipes,
every sequence and repeat state, table buckets, normalized coordinates and
little-endian table fingerprints. All fields match across padding pairs except
the padding selector.

| Recipe | Observed sequence (LL, ML, distance, offBase) | Trailing literals |
| --- | --- | --- |
| short-seven | none | 7 |
| short-twelve | none | 12 |
| repeat-one | (2, 62, 1, 1) | 0 |
| repeat-four | (4, 60, 4, 7) | 0 |
| offset-sixteen | (16, 80, 16, 19) | 0 |
| prefix-explicit | (0, 64, 16, 19) | 0 |
| prefix-duplicate-repeats | (1, 63, 4, 1) | 0 |
| maximum-acceleration | none | 64 |
| long-match | (2, 65698, 1, 1) | 0 |

The explicit-offset cases demonstrate the distinction between parser and full
wire repeats. For prefix-explicit, the parser returns [16,1,8], while full
semantic replay gives [16,1,4]. Only the first two cells are required to match.
The long-match case actually uses longLengthType=2; its decoded ML is 65698.

## Commands and provenance

Both final driver invocations finished successfully:

    python3 -u /tmp/zstdoxide-fast-oracle-work/run_smoke.py normal --label normal-final
    python3 -u /tmp/zstdoxide-fast-oracle-work/run_smoke.py sanitized --label sanitized-final

Each mode records reference revision/status, compiler version, exact build
and execution command, effective environment, raw stdout/stderr, artifact
hashes and complete source/header/archive hashes before and after execution.
The source manifests are identical between the final modes and remained
unchanged within each mode.

Normal mode links the existing pinned libzstd.a. Sanitizer mode compiles the
helper and unchanged zstd_fast.c with AddressSanitizer and
UndefinedBehaviorSanitizer, covering Fast and its inlined memory helpers.
Other archive support objects are not sanitizer-instrumented.
LeakSanitizer is disabled; no leak-detection claim is made.

There were no compiler errors, sanitizer reports, guard failures or failed
recipe assertions. Earlier successful normal/sanitized runs are retained in
normal/ and sanitized/. A final metadata-only refinement explicitly recorded
the fixed strategy, chain/search logs and no-dictionary window state. Final
runs are in normal-final/ and sanitized-final/. Their case records are exactly
the same as the earlier records; only metadata grew. The original source bytes
are preserved as initial-fast_oracle.c and initial-run_smoke.py, with hashes
matching those earlier manifests. Thus the final validation has 36 C case
executions; an additional 36 earlier executions are preserved, not silently
substituted for it.

Independent static review by golden_tests found no blocking pointer/setup,
capacity or replay issue. Its two fixture-integrity suggestions were applied:
the complete four-byte final table key must fit logical input, and complete
padding-pair records must match. The final metadata-only delta was separately
submitted for review.

## Frozen identities and limits

- fast_oracle.c SHA-256:
  f9ab6e65ba20671560040d674d54ff64e78fc39c73a0e76f509722cb85b75f82
- run_smoke.py SHA-256:
  cd1fd8dfcaa95a9fa600c102763b9fab74b8d2a1e8c70369d9540dc864d82825
- Final canonical observations SHA-256:
  806bdbbadae4afa38d49390852955ec53b0b67c67d0e4e502b1c0517ad8ae5b7

This is the first direct no-dictionary Fast helper checkpoint only. It does
not establish collision-branch coverage, every hash width/window/target,
collector behavior, normal-frame raw/RLE publication, Rust Fast behavior, or
complete migration of any broad upstream test source. Recorded table states
are not chronological store traces.

Both final runners and all synchronous compiler/helper subprocesses have
finished. No task-owned process remains.
