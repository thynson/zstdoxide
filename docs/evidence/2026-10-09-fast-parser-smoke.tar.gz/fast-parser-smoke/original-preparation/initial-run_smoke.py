#!/usr/bin/env python3
"""Bounded direct-Fast compile/run evidence, only when coordinator authorizes."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import subprocess
import sys
import traceback

WORK = Path(__file__).resolve().parent
UPSTREAM = Path("/tmp/zstdoxize-upstream-1.5.7")
REVISION = "f8745da6ff1ad1e7bab384bd1f9d742439278e99"
RECIPES = {
    "short-seven": ("abcdefg", 0, 7, 10, 0, [1, 4, 8], False),
    "short-twelve": ("abcdefghijkl", 0, 12, 10, 0, [1, 4, 8], False),
    "repeat-one": ("A", 0, 64, 10, 0, [1, 4, 8], False),
    "repeat-four": ("abcd", 0, 64, 10, 0, [1, 4, 8], False),
    "offset-sixteen": ("0123456789ABCDEF", 0, 96, 10, 0, [1, 4, 8], False),
    "prefix-explicit": ("0123456789ABCDEF", 16, 64, 10, 0, [1, 4, 8], True),
    "prefix-duplicate-repeats": ("abcd", 16, 64, 10, 0, [4, 4, 8], True),
    "maximum-acceleration": ("abcd", 0, 64, 10, 131072, [1, 4, 8], False),
    "long-match": ("A", 0, 65700, 17, 0, [1, 4, 8], False),
}

def require(condition, reason):
    if not condition:
        raise ValueError(reason)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def fingerprint(data):
    value = 0xcbf29ce484222325
    for byte in data:
        value = ((value ^ byte) * 0x100000001b3) & ((1 << 64) - 1)
    return f"{value:016x}"

def sources():
    files = [WORK / "fast_oracle.c", WORK / "run_smoke.py", WORK / "README.md"]
    files += sorted((UPSTREAM / "lib").rglob("*.h"))
    files += sorted((UPSTREAM / "lib").rglob("*.c"))
    files += [UPSTREAM / "lib/libzstd.a"]
    return [{"path": str(path), "bytes": path.stat().st_size, "sha256": sha(path)} for path in files]

def unique_json(line):
    def fields(pairs):
        result = {}
        for name, value in pairs:
            require(name not in result, f"duplicate JSON field {name}")
            result[name] = value
        return result
    def reject(value):
        raise ValueError(f"non-JSON scalar {value}")
    return json.loads(line, object_pairs_hook=fields, parse_constant=reject)

def validate(path):
    records = [unique_json(line) for line in path.read_text().splitlines()]
    require(len(records) == 19, "exactly one metadata and eighteen case records")
    metadata, rows = records[0], records[1:]
    require(metadata["record"] == "metadata" and metadata["recipe_count"] == 9
            and metadata["case_count"] == 18 and metadata["upstream_revision"] == REVISION,
            "metadata count/revision")
    expected = {(name, padding) for name in RECIPES for padding in (0x6a, 0xc3)}
    observed = {}
    source_hashes = {}
    for row in rows:
        key = row["id"], row["padding"]
        require(key in expected and key not in observed, "unexpected or duplicate recipe/padding")
        observed[key] = row
        pattern, prefix, block, window, target, initial, seeded = RECIPES[row["id"]]
        source = (pattern.encode() * ((prefix + block + len(pattern) - 1) // len(pattern)))[:prefix + block]
        require(bytes.fromhex(row["source_hex"]) == source, "independent recipe bytes")
        require(row["source_fnv1a64"] == fingerprint(source), "source fingerprint")
        require(row["pattern"] == pattern and row["prefix_bytes"] == prefix and row["block_bytes"] == block
                and row["window_log"] == window and row["target_length"] == target
                and row["min_match"] == 4 and row["hash_log"] == 6
                and row["initial_repeats"] == initial, "independent recipe scalar metadata")
        require(row["physical_leading_bytes"] == 64 and row["physical_suffix_bytes"] == 262656
                and row["sequence_capacity"] == block // 3 + 1 and row["literal_slack_bytes"] == 32,
                "physical/capacity metadata")
        require(row["replay_equal"] is True and row["guards_intact"] is True, "helper success flags")
        literals = bytes.fromhex(row["stored_literals_hex"])
        replay = bytearray(source[:prefix])
        repeats = initial.copy()
        cursor = 0
        for sequence in row["sequences"]:
            require(set(sequence) == {"ll", "ml", "off_base", "distance", "intent"}, "sequence schema")
            ll, ml, off_base = sequence["ll"], sequence["ml"], sequence["off_base"]
            require(all(type(v) is int and v >= 0 for v in (ll, ml, off_base)), "sequence integers")
            require(ml >= 3 and off_base >= 1, "sequence positive match/offset")
            require(cursor + ll <= len(literals), "literal source range")
            replay.extend(literals[cursor:cursor + ll]); cursor += ll
            if off_base > 3:
                distance = off_base - 3
                repeats = [distance, repeats[0], repeats[1]]
            else:
                selector = off_base - 1 + (ll == 0)
                if selector == 0:
                    distance = repeats[0]
                elif selector == 1:
                    distance = repeats[1]
                    repeats = [distance, repeats[0], repeats[2]]
                else:
                    distance = repeats[2] if selector == 2 else repeats[0] - 1
                    repeats = [distance, repeats[0], repeats[1]]
            require(sequence["distance"] == distance and distance > 0 and distance <= len(replay), "wire offset intent")
            require(sequence["intent"] == ("repeat" if off_base <= 3 else "offset"), "offset label")
            require(len(replay) + ml <= len(source), "bounded match reconstruction")
            for _ in range(ml):
                replay.append(replay[-distance])
        require(cursor == len(literals), "stored literals exhausted")
        require(row["trailing_literals"] == len(source) - len(replay), "last literals coverage")
        replay.extend(source[len(replay):])
        require(bytes(replay) == source, "independent Python byte replay")
        require(row["wire_repeats"] == repeats and row["parser_repeats"][:2] == repeats[:2]
                and row["parser_repeats"][2] == initial[2], "distinct repeat state")
        for phase in ("before", "after"):
            raw = row[f"table_{phase}_c"]
            require(len(raw) == 64 and all(type(v) is int and 0 <= v < 2**32 for v in raw), "table U32 schema")
            require(row[f"table_{phase}_positions"] == [None if v < 2 else v - 2 for v in raw], "normalized table")
            require(row[f"table_{phase}_le32_fnv1a64"] == fingerprint(b"".join(v.to_bytes(4, "little") for v in raw)),
                    "canonical table fingerprint")
            for slot, value in enumerate(raw):
                require(value != 1, "sentinel one is not supplied or produced by Fast")
                if value:
                    require(2 <= value <= len(source) + 2 - 4, "complete table key fits logical source")
                    tail = source[value - 2:value - 2 + 4]
                    tail += bytes([row["padding"]]) * (4 - len(tail))
                    bucket = ((int.from_bytes(tail, "little") * 2654435761) & 0xffffffff) >> 26
                    require(bucket == slot, "independent hash bucket")
            if phase == "before":
                initial_table = [0] * 64
                if seeded:
                    bucket = ((int.from_bytes(source[:4], "little") * 2654435761) & 0xffffffff) >> 26
                    initial_table[bucket] = 2
                require(raw == initial_table, "exact prior-prefix seed")
        if row["id"] in ("short-seven", "short-twelve", "maximum-acceleration"):
            require(row["sequences"] == [] and row["trailing_literals"] == block, "short/large-step cleanup witness")
        if row["id"] == "prefix-explicit":
            require(row["sequences"] == [{"ll": 0, "ml": 64, "distance": 16, "off_base": 19, "intent": "offset"}],
                    "hand-readable explicit offset witness")
        if row["id"] == "long-match":
            require(row["long_length_type"] == 2 and row["long_length_position"] < len(row["sequences"])
                    and any(s["ml"] - 3 >= 65536 for s in row["sequences"]), "actual long-match metadata witness")
        source_hashes[row["id"]] = hashlib.sha256(source).hexdigest()
    require(set(observed) == expected, "complete recipes")
    for name in RECIPES:
        left, right = observed[name, 0x6a], observed[name, 0xc3]
        require({k: v for k, v in left.items() if k != "padding"} ==
                {k: v for k, v in right.items() if k != "padding"},
                f"complete padding-pair observation independence: {name}")
    return {"recipes": 9, "cases": 18, "source_sha256": source_hashes,
            "sequences": {name: observed[name, 0x6a]["sequences"] for name in RECIPES},
            "full_record_sha256": sha(path)}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("normal", "sanitized"))
    parser.add_argument("--label")
    args = parser.parse_args()
    label = args.label or args.mode
    require(label and all(c.isalnum() or c in "-_" for c in label), "label must be a simple name")
    output = WORK / label
    output.mkdir(exist_ok=False)
    environment = {k: v for k, v in os.environ.items()
                   if k in {"PATH", "HOME", "TMPDIR", "SDKROOT", "MACOSX_DEPLOYMENT_TARGET", "DEVELOPER_DIR"}}
    environment.update({"LC_ALL": "C", "LANG": "C", "TZ": "UTC"})
    original = sources()
    evidence = {"schema_version": 1, "mode": args.mode, "started_at": now(), "source_before": original,
                "environment": environment, "commands": [], "scope": "direct Fast only; no collector or frame"}
    def save():
        write_json(output / "evidence.json", evidence)
    def run(name, command, overrides=None):
        require(sources() == original, "inputs changed before command")
        stdout, stderr = output / f"{name}.stdout", output / f"{name}.stderr"
        env = environment | (overrides or {})
        with stdout.open("w") as out, stderr.open("w") as err:
            process = subprocess.run(command, cwd=WORK, env=env, stdout=out, stderr=err, check=False)
        evidence["commands"].append({"name": name, "command": command, "environment": env,
                                     "cwd": str(WORK), "exit_code": process.returncode,
                                     "stdout": str(stdout), "stdout_sha256": sha(stdout),
                                     "stderr": str(stderr), "stderr_sha256": sha(stderr)})
        save()
        require(process.returncode == 0, f"failed command {name}; diagnostics {stderr}")
        require(sources() == original, "inputs changed after command")
        return stdout
    save()
    try:
        version = run("reference-revision", ["git", "-C", str(UPSTREAM), "rev-parse", "HEAD"])
        require(version.read_text().strip() == REVISION, "pinned revision")
        status = run("reference-status", ["git", "-C", str(UPSTREAM), "status", "--porcelain"])
        require(status.read_text() == "", "reference must be clean")
        run("compiler", ["clang", "--version"])
        executable = output / "fast_oracle"
        command = ["clang", "-std=c11", "-Wall", "-Wextra", "-Werror", "-I", str(UPSTREAM / "lib"),
                   "-I", str(UPSTREAM / "lib/common"), "-I", str(UPSTREAM / "lib/compress")]
        if args.mode == "sanitized":
            command += ["-O1", "-g", "-fsanitize=address,undefined", "-fno-omit-frame-pointer",
                        str(WORK / "fast_oracle.c"), str(UPSTREAM / "lib/compress/zstd_fast.c")]
        else:
            command += ["-O2", str(WORK / "fast_oracle.c")]
        command += [str(UPSTREAM / "lib/libzstd.a"), "-o", str(executable)]
        run("compile", command)
        evidence["executable_sha256"] = sha(executable)
        overrides = ({"ASAN_OPTIONS": "halt_on_error=1:detect_leaks=0",
                      "UBSAN_OPTIONS": "halt_on_error=1:print_stacktrace=1"} if args.mode == "sanitized" else {})
        records = run("observations", [str(executable)], overrides)
        evidence["validation"] = validate(records)
        evidence["source_after"] = sources()
        require(evidence["source_after"] == original, "final source equality")
        evidence["finished_at"] = now()
        evidence["result"] = "passed"
        save()
        print(json.dumps({"mode": args.mode, "case_count": 18, "result": "passed",
                          "evidence": str(output / "evidence.json")}, sort_keys=True))
    except BaseException:
        evidence["failure"] = traceback.format_exc()
        save()
        raise

if __name__ == "__main__":
    main()
