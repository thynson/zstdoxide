# Direct Fast oracle preparation

This directory is outside the repository. It is the first bounded helper
checkpoint from docs/reference-fast-oracle-design.md, using unchanged
facebook/zstd v1.5.7 revision
f8745da6ff1ad1e7bab384bd1f9d742439278e99.

The helper invokes only the exported no-dictionary ZSTD_compressBlock_fast
parser. It neither invokes the sequence collector nor generates ordinary
frames. Its observations are sequences and final hash-table state, not a
chronological probe/store trace.

## Owners and initialized extents

Every owned buffer is allocated separately by the helper, with 64-byte guards
on both sides. malloc alignment and a guard displacement divisible by the
alignment of U32, SeqDef and Observation preserve typed array alignment. No
borrow or pointer is saved after its owning allocation is freed.

Source data begins 64 bytes inside its initialized arena. C base is two bytes
before source, so zero is an invalid but physically in-allocation candidate.
Logical source index zero maps to C index two. A separate initialized leading
region also keeps short-block iend-8, iend-32 and ZSTD_count's negative
constant end offsets inside the allocation.

The suffix has 131072 + 131072 + 512 = 262656 initialized bytes. It covers
initial ip0+128, initial ip0+step+1, loop pair expressions, nextStep increments,
and 64/128-byte prefetch pointer expressions. Monotonic source progress bounds
the number of step increments by block length; therefore even the conservative
step bound target+2+block remains inside this suffix. All actual loads and
matches still use the original logical iend. The maximum-target recipe
exercises pointer formation followed by immediate cleanup.

Literal storage permits block length plus the unchanged
WILDCOPY_OVERLENGTH=32 bytes. Its guard follows that full writable region:
the upstream routine may issue an initial 16-byte store for a short literal
run. Sequence storage has floor(block length/MINMATCH)+1 complete SeqDef slots.
Every emitted match is at least MINMATCH and consumes source, so this bounds
all stores. Ancillary code arrays are allocated too, although direct Fast
does not consume them. The whole source arena is compared after the call,
including initialized padding.

The saved-prefix recipes seed only the bucket for source position zero, which
is earlier than the current block and has eight initialized key bytes.
No future or invalid nonzero candidate is supplied. Saved repeats are positive;
the unchanged parser handles availability and restores disabled values.

## Smoke scope and independent checks

Nine fixed recipes run with padding bytes 0x6a and 0xc3:

1. Seven literal bytes.
2. Twelve literal bytes.
3. 64 copies of A.
4. 64 bytes from repeated abcd.
5. 96 bytes from repeated 0123456789ABCDEF.
6. A 16-byte prior prefix and 64-byte block of that 16-byte pattern, with one
   valid preseed slot: a direct explicit-offset witness.
7. Prior-prefix abcd with duplicate saved repeats [4,4,8].
8. 64-byte abcd with maximum target length 131072.
9. 65700 copies of A: one small-memory long-match metadata witness.

The two short cases directly call the parser on a safely prepared arena; they
are not claims about the normal compressor's tiny-block bypass behavior.
No collision-family, alternate hash width, large hash table, multi-block
publication or format-level migration claim is made by this smoke set.

The helper expands the long-length metadata independently, compares it with
ZSTD_getSequenceLength, resolves each offBase with fully expanded LL, and
reconstructs every output byte. Its full semantic repeat triple is distinct
from the three parser cells: Fast updates only cells zero and one. The third
cell is checked for preservation, not equality with the wire replay.

Complete raw C table entries and normalized source positions are saved.
Zero/sentinel entries become null in normalized form. Table fingerprints
explicitly serialize each U32 little-endian; no native structure padding or
addresses enter the records. Final nonzero slots are checked against their
source key, including the complete four-byte key's logical bounds.

All recipes are generated from fixed ASCII patterns and fixed lengths.
The normal and sanitizer drivers, when authorized, must require exactly
18 case records and complete successful replay. Every field of the padding-pair
records is compared independently except the padding selector itself. This
stronger complete-state comparison is appropriate for these four-byte cases;
the broad future design still qualifies final unused slots for other modes.
Any compile, sanitizer or recipe assertion failure
must remain in the logs instead of being discarded.

## Planned compilation qualification

Normal mode links the pinned existing libzstd.a and records its hash.
Sanitizer mode additionally compiles the unchanged zstd_fast.c with the helper
under AddressSanitizer and UndefinedBehaviorSanitizer, using the archive only
for remaining support symbols. This instruments the parser and its inlined
memory helpers; it does not claim to instrument every object in the archive.

At this draft checkpoint no compiler or helper execution has happened.
The coordinator's timing boundary is active. Build/run authorization is
required from the coordinator before launching the prepared smoke driver.
