from pathlib import Path
import json,hashlib,subprocess,os,time,shutil,datetime
D=Path(__file__).parent;T=Path('/private/tmp');S=T/'module34-final';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,28,9,38,0,tzinfo=datetime.timezone.utc).timestamp()
assert time.time()<deadline-600
for name in ['module34-public/evidence.json','module34-native/replay.json','module34-platform/evidence.json','module34-corpus/evidence.json','module34-focused-promotion/evidence.json']:assert json.loads((T/name).read_text())['status']=='passed',name
assert not S.exists();subprocess.run(['cp','-cR',str(T/'module34-public/source'),str(S)],check=True)
for folder,source,name in [('native','replay-source','tests/dictionary_slice_encode_output_native.rs'),('platform','source','tests/dictionary_slice_encode_output_platform.rs'),('corpus','source','tests/upstream_trained_dictionary_fuzz.rs')]:shutil.copyfile(T/('module34-'+folder)/source/name,S/name)
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};e=dict(status='running',source=source,commands=[]);env={**os.environ,'CARGO_TARGET_DIR':str(T/'module34-public/target'),'CARGO_BUILD_JOBS':'4','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'preflight.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for label,args in [('clippy',['cargo','clippy','--offline','--locked','--lib','--tests','--all-features','--','-D','warnings']),('format',['cargo','fmt','--all','--','--check'])]:
  t=time.monotonic()
  with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=max(1,deadline-time.time()-30))
  e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log'))));save();assert p.returncode==0,label
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed');save();(D/'preparation.json').write_text(json.dumps(dict(status='prepared',source=source,qualification='Explicit final34 snapshot with focused public/native/platform/corpus adapters and audited post33 metadata. No full-matrix pass is implied. Work-window deadline applies to each command.'),indent=2)+'\n')
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
