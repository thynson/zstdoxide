"""Complete the module34 matrix: rerun only the final format command.

The ENOSPC resume rebuilt the evidence with 74 verified passed rows and then
could not create format.log exclusively: the matrix preparation's preflight
format command had left a zero-byte format.log with the same name in the
campaign directory. This script verifies the 74-row prefix, archives the
interrupted evidence, preserves the preflight log under a distinct name, runs
the final format command, and completes the campaign.
"""
from pathlib import Path
import datetime, hashlib, json, os, re, shutil, subprocess, time

COUNTS = (114, 1752, 75)
ROOT = Path('/private/tmp')
D = ROOT / 'module34-matrix'
S = ROOT / 'module34-final'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def counts(text):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert all(int(f) == 0 for _, f, _ in rows), 'A test group failed'
    return len(rows), sum(int(p) for p, _, _ in rows), sum(int(i) for _, _, i in rows)


deadline_dt = datetime.datetime.fromisoformat('2026-10-28T09:38:00+00:00')
deadline = deadline_dt.timestamp()
assert deadline - time.time() >= 120
evidence = D / 'evidence.json'
original = evidence.read_bytes()
j = json.loads(original)
assert j['status'] == 'failed', j['status']
assert len(j['commands']) == 74 and all(r['exit_code'] == 0 for r in j['commands'])
for name, digest in j['source'].items():
    assert sha(S / name) == digest, ('Source changed', name)
gates = {
    'public': 'module34-public/evidence.json',
    'platform': 'module34-platform/evidence.json',
    'native': 'module34-native/replay.json',
    'corpus': 'module34-corpus/evidence.json',
    'preflight': 'module34-matrix/preflight.json',
}
assert set(gates) == set(j['focused_gate_receipts'])
for name, digest in j['focused_gate_receipts'].items():
    receipt = ROOT / gates[name]
    assert sha(receipt) == digest, ('Focused gate changed', name)
    assert json.loads(receipt.read_text())['status'] == 'passed'
for row, (label, argv) in zip(j['commands'], j['plan']):
    assert row['label'] == label and row['argv'] == argv, 'Completed rows must be the exact plan prefix'
    log = D / (label + '.log')
    assert sha(log) == row['log_sha256'], ('Log changed', label)
    if label.endswith(('-full', '-release')):
        assert counts(log.read_text()) == COUNTS, ('Unexpected counts', label)
assert j['plan'][74][0] == 'format'
# Preserve the preflight's format log under a distinct name before the rerun.
stale = D / 'format.log'
preflight_log = D / 'preflight-format-command.log'
if stale.exists():
    assert not preflight_log.exists()
    shutil.move(str(stale), str(preflight_log))
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
attempt = D / 'resume-attempts' / stamp
attempt.mkdir(parents=True, exist_ok=False)
(attempt / 'prior-evidence.json').write_bytes(original)
shutil.copyfile(__file__, attempt / 'resume-format.py')
record = dict(prior_evidence_sha256=hashlib.sha256(original).hexdigest(),
              controller_sha256=sha(Path(__file__)),
              resumed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              deadline_utc=deadline_dt.isoformat(),
              completed_reused=74,
              stale_log_preserved=dict(name=preflight_log.name, sha256=sha(preflight_log),
                                       cause='the matrix preparation preflight format command left a zero-byte format.log; the matrix format command needs its own log'),
              note='The preflight receipt records only exit codes for its two commands; no recorded digest referenced the stale log path.')
(attempt / 'reconciliation.json').write_text(json.dumps(record, indent=2) + '\n')
j.setdefault('resume_attempts', []).append(dict(path=str(attempt.relative_to(D)), **record))
j['commands'] = j['commands'][:74]
j.pop('active_command', None)
j.pop('error', None)
j.update(status='running')
env = {**os.environ, 'CARGO_TARGET_DIR': str(ROOT / 'module34-matrix-target'), 'CARGO_BUILD_JOBS': '6',
       'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
       'CARGO_PROFILE_DEV_DEBUG': '0'}


def save():
    temp = evidence.with_suffix('.pending.json')
    temp.write_text(json.dumps(j, indent=2) + '\n')
    temp.replace(evidence)


save()
try:
    label, argv = j['plan'][74]
    remaining = deadline - time.time() - 30
    assert remaining > 0
    j['active_command'] = dict(label=label, argv=argv, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    start = time.monotonic()
    log = D / (label + '.log')
    with log.open('xb') as f:
        proc = subprocess.Popen(argv, cwd=S, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        code = proc.wait(timeout=remaining)
    row = dict(label=label, argv=argv, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
    j['commands'].append(row)
    j.pop('active_command', None)
    save()
    print(label, code, flush=True)
    assert code == 0, label
    assert len(j['commands']) == 75
    for row, (rlabel, rargv) in zip(j['commands'], j['plan']):
        assert row['label'] == rlabel and row['argv'] == rargv and row['exit_code'] == 0
        assert sha(D / (rlabel + '.log')) == row['log_sha256']
        if rlabel.endswith(('-full', '-release')):
            assert counts((D / (rlabel + '.log')).read_text()) == COUNTS
    j.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
except BaseException as ex:
    j.update(status='failed', error=repr(ex))
    save()
    raise
