"""Resume the module34 matrix after an environmental ENOSPC linker failure.

The first matrix run completed 66 commands successfully; unsafe-slice-history-full
failed with ld: write() failed, errno=28 because the disk was 100% full. That is
an infrastructure failure, not a codec failure: the failed row is not credited,
the failed log and evidence are archived verbatim, closed-module build caches
were pruned with a receipt (106Gi freed), and this script reruns the failed
command and the remaining plan under the same environment and deadline.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, os, shutil, signal, subprocess, time

COUNTS = (114, 1752, 75)
ROOT = Path('/private/tmp')
TARGET = 'module34-matrix-target'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def counts(text):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert all(int(f) == 0 for _, f, _ in rows), 'A test group failed'
    return len(rows), sum(int(p) for p, _, _ in rows), sum(int(i) for _, _, i in rows)


import re

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--deadline-utc', required=True)
    a = ap.parse_args()
    deadline_dt = datetime.datetime.fromisoformat(a.deadline_utc)
    assert deadline_dt.tzinfo is not None and deadline_dt.utcoffset() == datetime.timedelta(0)
    deadline = deadline_dt.timestamp()
    assert deadline - time.time() >= 120
    d = ROOT / 'module34-matrix'
    s = ROOT / 'module34-final'
    evidence = d / 'evidence.json'
    original = evidence.read_bytes()
    j = json.loads(original)
    assert j['status'] == 'failed', 'Only a failed campaign is resumable here'
    assert j['deadline_utc'] == deadline_dt.isoformat(), 'Deadline must match the authorized window'
    # Source inventory integrity: every recorded file must still match.
    for name, digest in j['source'].items():
        assert sha(s / name) == digest, ('Source changed', name)
    # Focused gate receipts must still verify.
    gates = {
        'public': 'module34-public/evidence.json',
        'platform': 'module34-platform/evidence.json',
        'native': 'module34-native/replay.json',
        'corpus': 'module34-corpus/evidence.json',
        'preflight': 'module34-matrix/preflight.json',
    }
    assert set(gates) == set(j['focused_gate_receipts'])
    for name, digest in j['focused_gate_receipts'].items():
        receipt = ROOT / gates[name]
        assert sha(receipt) == digest, ('Focused gate changed', name)
        assert json.loads(receipt.read_text())['status'] == 'passed'
    # Completed prefix: exact plan rows, successful, logs intact, counts exact.
    rows = j['commands']
    passed = [r for r in rows if r['exit_code'] == 0]
    failed = [r for r in rows if r['exit_code'] != 0]
    assert len(failed) == 1 and failed[0]['exit_code'] == 101, failed
    assert len(passed) == 66, len(passed)
    for row, (label, argv) in zip(passed, j['plan']):
        assert row['label'] == label and row['argv'] == argv, 'Completed rows must be the exact plan prefix'
        log = d / (label + '.log')
        assert sha(log) == row['log_sha256'], ('Log changed', label)
        if label.endswith(('-full', '-release')):
            assert counts(log.read_text()) == COUNTS, ('Unexpected or zero test counts', label)
    failed_label = failed[0]['label']
    assert failed_label == j['plan'][len(passed)][0]
    # Archive the failed attempt verbatim before touching anything.
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    attempt = d / 'resume-attempts' / stamp
    attempt.mkdir(parents=True, exist_ok=False)
    (attempt / 'prior-evidence.json').write_bytes(original)
    shutil.copyfile(__file__, attempt / 'resume.py')
    failed_log = d / (failed_label + '.log')
    interrupted = []
    if failed_log.exists():
        interrupted.append(dict(name=failed_log.name, sha256=sha(failed_log), bytes=failed_log.stat().st_size))
        failed_log.rename(attempt / failed_log.name)
    record = dict(prior_evidence_sha256=hashlib.sha256(original).hexdigest(),
                  controller_sha256=sha(Path(__file__)),
                  resumed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  deadline_utc=deadline_dt.isoformat(),
                  completed_reused=len(passed),
                  environmental_failure=dict(label=failed_label, exit_code=101,
                                             cause='ld: write() failed, errno=28 (ENOSPC); disk was 100% full'),
                  interrupted_logs=interrupted)
    (attempt / 'reconciliation.json').write_text(json.dumps(record, indent=2) + '\n')
    j.setdefault('resume_attempts', []).append(dict(path=str(attempt.relative_to(d)), **record))
    j['commands'] = passed
    j.pop('active_command', None)
    j.pop('error', None)
    j.update(status='running')
    env = {**os.environ, 'CARGO_TARGET_DIR': str(ROOT / TARGET), 'CARGO_BUILD_JOBS': '6',
           'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
           'CARGO_PROFILE_DEV_DEBUG': '0'}

    def save():
        temp = evidence.with_suffix('.pending.json')
        temp.write_text(json.dumps(j, indent=2) + '\n')
        temp.replace(evidence)

    save()
    try:
        for label, argv in j['plan'][len(passed):]:
            remaining = deadline - time.time() - 30
            if remaining < 30:
                raise TimeoutError('User work window reached before ' + label)
            j['active_command'] = dict(label=label, argv=argv, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
            save()
            start = time.monotonic()
            log = d / (label + '.log')
            with log.open('xb') as f:
                proc = subprocess.Popen(argv, cwd=s, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
                try:
                    code = proc.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid, signal.SIGKILL)
                        proc.wait()
                    raise TimeoutError('User work window reached during ' + label)
            row = dict(label=label, argv=argv, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
            if code == 0 and label.endswith(('-full', '-release')):
                result = counts(log.read_text())
                assert result == COUNTS, (label, result)
                row.update(result_groups=result[0], passed=result[1], ignored=result[2])
            j['commands'].append(row)
            j.pop('active_command', None)
            save()
            print(label, code, flush=True)
            assert code == 0, label
        # Final verification of the whole plan.
        allrows = j['commands']
        assert len(allrows) == len(j['plan'])
        for row, (label, argv) in zip(allrows, j['plan']):
            assert row['label'] == label and row['argv'] == argv and row['exit_code'] == 0
            assert sha(d / (label + '.log')) == row['log_sha256']
            if label.endswith(('-full', '-release')):
                assert counts((d / (label + '.log')).read_text()) == COUNTS
        j.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
    except TimeoutError as ex:
        j.update(status='interrupted-at-user-deadline', error=repr(ex))
        save()
        raise
    except BaseException as ex:
        j.update(status='failed', error=repr(ex))
        save()
        raise


if __name__ == '__main__':
    main()
