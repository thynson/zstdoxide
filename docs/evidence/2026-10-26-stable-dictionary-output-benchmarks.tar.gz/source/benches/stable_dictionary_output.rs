//! Cold stable versus buffered sessions, with fixed whole/seven-byte input schedules.
//! Destinations and source preparation are outside clocks; session creation/drop,
//! scratch ownership, frame validation and full decoding are inside each sample.
//! Dictionary preparation stays outside clocks; each session handle clone/drop is timed.
//! TrackingAllocator is used only for clock-free qualification, never timing.
use std::{alloc::Allocator, hint::black_box, time::Instant};
use zstdoxide::{DecodeOptions, Decoder, Dictionary, SharedDictionary, SliceDecoder};
use zstdoxide_test_allocator::{AllocatorConfig, TrackingAllocator};

fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |hash, byte| {
        (hash ^ u64::from(*byte)).wrapping_mul(0x100000001b3)
    })
}
struct Case {
    name: &'static str,
    frame: &'static [u8],
    source: &'static [u8],
    dictionary: SharedDictionary,
}
fn cases() -> Vec<Case> {
    let mut cases = Vec::new();
    macro_rules! fixture {
        ($name:literal,$dictionary:literal) => {
            cases.push(Case {
                name: $name,
                frame: include_bytes!(concat!("../tests/upstream/dictionaries/", $name, ".zst")),
                source: include_bytes!(concat!(
                    "../tests/upstream/dictionaries/",
                    $name,
                    ".expected"
                )),
                dictionary: Dictionary::from_bytes(include_bytes!(concat!(
                    "../tests/upstream/dictionaries/",
                    $dictionary
                )))
                .unwrap()
                .into_shared(),
            });
        };
    }
    fixture!("raw-small-window", "boundary-dictionary.raw");
    fixture!("p0-far-dictionary", "boundary-dictionary.raw");
    fixture!("p-window-equal", "boundary-dictionary.raw");
    fixture!("dictionary-to-frame-eviction", "boundary-dictionary.raw");
    fixture!("formatted-id", "formatted.dict");
    fixture!("dictionary-treeless-four-streams", "formatted.dict");
    fixture!("dictionary-repeat-sequences", "trained.dict");
    fixture!("duplicate-reps-initial", "duplicate-reps.dict");
    fixture!("persistent-concatenation", "formatted.dict");
    cases.push(Case {
        name: "http",
        frame: include_bytes!("../tests/upstream/data/generated/http-dictionary.zst"),
        source: include_bytes!("../tests/upstream/data/golden-compression/http"),
        dictionary: Dictionary::from_bytes(include_bytes!(
            "../tests/upstream/data/golden-dictionaries/http-dict-missing-symbols"
        ))
        .unwrap()
        .into_shared(),
    });
    cases.push(Case {
        name: "empty",
        frame: &[0x28, 0xb5, 0x2f, 0xfd, 0x20, 0, 1, 0, 0],
        source: &[],
        dictionary: Dictionary::from_bytes(include_bytes!(
            "../tests/upstream/dictionaries/formatted.dict"
        ))
        .unwrap()
        .into_shared(),
    });
    cases
}
fn stable<A: Allocator + Clone>(
    encoded: &[u8],
    output: &mut [u8],
    limit: usize,
    chunk: usize,
    allocator: A,
    dictionary: &SharedDictionary,
) -> usize {
    let mut decoder = SliceDecoder::with_dictionary_in(
        output,
        DecodeOptions::new(limit),
        dictionary.clone(),
        allocator,
    );
    let mut consumed = 0;
    while consumed < encoded.len() {
        let end = consumed + chunk.min(encoded.len() - consumed);
        let p = decoder.process(&encoded[consumed..end]).unwrap();
        assert!(p.consumed > 0 || p.produced > 0);
        consumed += p.consumed;
    }
    decoder.finish().unwrap();
    decoder.output().unwrap().len()
}
fn buffered<A: Allocator + Clone>(
    encoded: &[u8],
    output: &mut [u8],
    limit: usize,
    chunk: usize,
    allocator: A,
    dictionary: &SharedDictionary,
) -> usize {
    let mut decoder = Decoder::new_in(DecodeOptions::new(limit), allocator);
    decoder.set_dictionary(Some(dictionary.clone())).unwrap();
    let mut consumed = 0;
    let mut produced = 0;
    while consumed < encoded.len() || produced < limit {
        let end = consumed + chunk.min(encoded.len() - consumed);
        let p = decoder
            .process(&encoded[consumed..end], &mut output[produced..])
            .unwrap();
        assert!(p.consumed > 0 || p.produced > 0);
        consumed += p.consumed;
        produced += p.produced;
    }
    decoder.finish().unwrap();
    produced
}
fn decode<A: Allocator + Clone>(
    mode: &str,
    encoded: &[u8],
    output: &mut [u8],
    limit: usize,
    allocator: A,
    dictionary: &SharedDictionary,
) -> usize {
    let chunk = if mode.ends_with("whole") {
        usize::MAX
    } else {
        7
    };
    if mode.starts_with("stable") {
        stable(encoded, output, limit, chunk, allocator, dictionary)
    } else {
        buffered(encoded, output, limit, chunk, allocator, dictionary)
    }
}
fn main() {
    let command = std::env::args().nth(1).expect("qualify or measure");
    assert!(command == "qualify" || command == "measure");
    for Case {
        name,
        frame: encoded,
        source: original,
        dictionary,
    } in cases()
    {
        let mut output = vec![0xa5; original.len() + 16];
        for mode in [
            "stable-whole",
            "buffered-whole",
            "stable-fragmented",
            "buffered-fragmented",
        ] {
            output.fill(0xa5);
            assert_eq!(
                decode(
                    mode,
                    encoded,
                    &mut output,
                    original.len(),
                    std::alloc::Global,
                    &dictionary
                ),
                original.len()
            );
            assert_eq!(&output[..original.len()], original);
            assert_eq!(&output[original.len()..], &[0xa5; 16]);
            if command == "qualify" {
                let allocator = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                let monitor = allocator.monitor();
                assert_eq!(
                    decode(
                        mode,
                        encoded,
                        &mut output,
                        original.len(),
                        allocator,
                        &dictionary
                    ),
                    original.len()
                );
                assert_eq!(&output[..original.len()], original);
                assert_eq!(&output[original.len()..], &[0xa5; 16]);
                monitor.assert_released();
                assert_eq!(SharedDictionary::strong_count(&dictionary), 1);
                let s = monitor.snapshot();
                assert_eq!(s.identities_created, s.owners_dropped);
                println!(
                    "{name}\t{mode}\t{}\t{:016x}\t{}\t{}\t{}\t{}",
                    original.len(),
                    fingerprint(original),
                    s.attempts,
                    s.requested_bytes,
                    s.peak_bytes,
                    s.deallocate_calls
                );
            } else {
                let iterations = (512 * 1024 / original.len().max(1)).clamp(8, 1024);
                for sample in 0..5 {
                    let start = Instant::now();
                    for _ in 0..iterations {
                        black_box(decode(
                            black_box(mode),
                            black_box(encoded),
                            black_box(&mut output),
                            black_box(original.len()),
                            std::alloc::Global,
                            black_box(&dictionary),
                        ));
                    }
                    let elapsed = start.elapsed().as_nanos();
                    assert_eq!(SharedDictionary::strong_count(&dictionary), 1);
                    assert_eq!(&output[..original.len()], original);
                    assert_eq!(&output[original.len()..], &[0xa5; 16]);
                    println!("{name}\t{mode}\t{sample}\t{iterations}\t{elapsed}");
                }
            }
        }
    }
}
