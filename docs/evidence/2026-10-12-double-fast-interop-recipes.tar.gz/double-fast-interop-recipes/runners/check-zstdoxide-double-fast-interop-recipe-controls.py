from pathlib import Path
from dataclasses import replace
import hashlib,json,subprocess,sys,tempfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(R/'scripts'))
import check_double_fast_interop_recipes as checker
from oracles import double_fast_interop as generator
subprocess.Popen=lambda *a,**k: (_ for _ in ()).throw(RuntimeError('child creation forbidden'))
rejected=[]
def require(v,m):
 if not v:raise ValueError(m)
def reject(name,f):
 try:f()
 except (ValueError,TypeError):rejected.append(name)
 else:raise RuntimeError('accepted '+name)
value=checker.check();baseline=generator.recipes()[0]
for name,value in [('bad-name','../frame'),('bad-source',bytearray()),('oversized-source',bytes(generator.MAX_SOURCE+1)),('bad-expected','admitted'),('empty-origin','')]:
 field={'bad-name':'name','bad-source':'source','oversized-source':'source','bad-expected':'expected','empty-origin':'origin'}[name]
 reject(name,lambda field=field,value=value:replace(baseline,**{field:value}).metadata())
for index in range(9):
 values=list(baseline.request);values[index]=True
 reject('boolean-field-'+str(index),lambda values=values:replace(baseline,request=tuple(values)).metadata())
for index,value in enumerate([1<<31,32,31,31,31,8,131073,10,1<<31]):
 values=list(baseline.request);values[index]=value
 reject('high-field-'+str(index),lambda values=values:replace(baseline,request=tuple(values)).metadata())
for value in [(),[0]*9,(0,)*10]:reject('shape-'+str(len(value)),lambda value=value:replace(baseline,request=value).metadata())
with tempfile.TemporaryDirectory(prefix='zstdoxide-double-fast-interop-inputs-') as directory:
 p=Path(directory)/'recipes.json'
 for name,data in [('changed',checker.MANIFEST.read_bytes()+b' '),('duplicate',b'{"a":1,"a":2}'),('nonfinite',b'{"x":NaN}'),('oversized',b' '*(256*1024+1))]:
  p.write_bytes(data);reject(name,lambda:checker.check(p))
 p.unlink();reject('missing',lambda:checker.check(p));p.symlink_to(checker.MANIFEST);reject('symlink',lambda:checker.check(p))
 original=checker.GENERATOR;checker.GENERATOR=Path(directory)/'malicious.py';checker.GENERATOR.write_text('raise RuntimeError("must not execute")\n')
 reject('generator-before-import',lambda:checker.check());checker.GENERATOR=original
 original=generator.ROOT;generator.ROOT=Path(directory)
 reject('input-before-import',lambda:generator.recipes());generator.ROOT=original
value=checker.check()
print(json.dumps(dict(mode='normal' if __debug__ else 'optimized',positive=2,rejected=len(rejected),controls=rejected,child_processes=0,recipe_count=value['recipe_count'],source_bytes=value['source_bytes'],classifications=value['classifications']),sort_keys=True))
