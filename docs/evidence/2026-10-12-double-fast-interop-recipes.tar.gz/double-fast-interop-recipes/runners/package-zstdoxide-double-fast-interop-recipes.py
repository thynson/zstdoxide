from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize')
def sha(b):return hashlib.sha256(b).hexdigest()
def require(v,m):
 if not v:raise ValueError(m)
paths=['scripts/oracles/double_fast_interop.py','scripts/check_double_fast_interop_recipes.py','docs/reference-double-fast-interop-protocol.md','tests/fixtures/reference-double-fast-interop-recipes/recipes.json','tests/fixtures/reference-double-fast-interop-recipes/README.md']
members={'source/'+n:(R/n).read_bytes() for n in paths}
for mode in ('normal','optimized'):
 p=Path('/tmp/zstdoxide-double-fast-interop-recipe-controls-'+mode+'.log');v=json.loads(p.read_text());require(v['positive']==2 and v['rejected']==34 and v['child_processes']==0,'controls');members['controls/'+p.name]=p.read_bytes()
for mode in ('normal','optimized','registry','policy'):
 p=Path('/tmp/zstdoxide-double-fast-interop-recipes-'+mode+'.log');require(p.read_bytes(),'nonempty successful check log');members['checks/'+p.name]=p.read_bytes()
for n in ['check-zstdoxide-double-fast-interop-recipe-controls.py','package-zstdoxide-double-fast-interop-recipes.py']:members['runners/'+n]=(Path('/tmp')/n).read_bytes()
report={'date':'2026-10-12','status':'passed','scope':'Source-only broader public-frame protocol and input hypotheses. Normal/optimized Python with child creation disabled; no C/Rust codec, Clippy/no_std, Miri or timing result.','recipes':159,'source_bytes':38855519,'classifications':{'success':113,'unsupported':42,'resource':4},'rust_equivalence_groups':16,'controls_per_mode':{'positive':2,'rejected':34,'child_processes':0},'source':{n:sha((R/n).read_bytes()) for n in paths},'archive':'2026-10-12-double-fast-interop-recipes.tar.gz'}
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
members['report.json']=enc(report);members['manifest.json']=enc({n:sha(b) for n,b in members.items()})
a=R/'docs/evidence'/report['archive'];require(not a.exists(),'fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('double-fast-interop-recipes/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:require({m.name:t.extractfile(m).read() for m in t}=={'double-fast-interop-recipes/'+n:b for n,b in members.items()},'archive exact bytes')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(members))
(R/'docs/evidence/2026-10-12-double-fast-interop-recipes.json').write_bytes(enc(report));print(len(members),'verified members')
