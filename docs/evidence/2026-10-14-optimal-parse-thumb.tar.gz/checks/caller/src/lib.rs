#![no_std]
#![feature(allocator_api)]
#![deny(unsafe_op_in_unsafe_fn)]
#![allow(dead_code)]
extern crate alloc;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/error.rs"] mod error;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/constants.rs"] mod constants;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/greedy_key.rs"] mod greedy_key;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/tree_layout.rs"] mod tree_layout;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_search_layout.rs"] mod optimal_search_layout;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_price.rs"] mod optimal_price;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_frequencies.rs"] mod optimal_frequencies;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_matches.rs"] mod optimal_matches;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_path_layout.rs"] mod optimal_path_layout;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_paths.rs"] mod optimal_paths;
#[path="/Users/lanxingcan/Workspace/zstdoxize/src/optimal_parse.rs"] mod optimal_parse;

pub use error::{Error,Result};
use core::alloc::Allocator;
struct Provider;
impl optimal_parse::PathProvider for Provider {
 fn query<A:Allocator>(&mut self,q:optimal_search_layout::OptimalQuery,m:&mut optimal_matches::OptimalMatches<A>)->Result<()> {
  if q.position==1 {m.push(optimal_search_layout::OptimalMatch::new(4,15)?)?;}Ok(())
 }
}
struct Observer;
impl optimal_parse::PathObserver for Observer {
 fn event<P:Allocator,F:Allocator>(&mut self,_:optimal_parse::PathEvent,_:&optimal_paths::OptimalPaths<P>,_:&optimal_frequencies::OptimalFrequencies<F>,_:&[optimal_search_layout::OptimalMatch])->Result<()>{Ok(())}
}
pub fn exercise()->Result<usize>{
 use alloc::alloc::Global;
 let frequencies=optimal_frequencies::OptimalFrequencies::new_in(true,Global)?;
 let paths=optimal_paths::OptimalPaths::new_in(Global)?;
 let matches=optimal_matches::OptimalMatches::new_in(Global)?;
 let mut parser=optimal_parse::OptimalParser::from_parts(b"aaaaaaaaaaaaaaaa",4,0,frequencies,paths,matches)?;
 let result=parser.parse(&mut Provider,&mut Observer)?;parser.reset()?;Ok(result.sequences)
}
