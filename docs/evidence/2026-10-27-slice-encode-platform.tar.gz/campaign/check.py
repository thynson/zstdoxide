from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,tomllib,concurrent.futures
R=Path('/private/tmp/module33-public/source');D=Path(__file__).parent;
while True:
 try:gate=json.loads(Path('/private/tmp/module33-public/evidence.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):gate={'status':'running'}
 assert gate['status']!='failed',gate.get('error')
 if gate['status']=='passed':break
 time.sleep(5)
S=D/'source';assert not S.exists();subprocess.run(['cp','-cR',str(R),str(S)],check=True)
shutil.copyfile(D/'slice_encode_output_platform.rs',S/'tests/slice_encode_output_platform.rs')
subprocess.run(['cargo','fmt','--all'],cwd=S,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()}
env={**os.environ,'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
e={'status':'running','source':source,'commands':[]}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,cwd,extra):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=cwd,env={**env,**extra},stdout=f,stderr=subprocess.STDOUT)
 row={'label':label,'argv':args,'environment':extra,'exit_code':p.returncode,'seconds':time.monotonic()-t,'log_sha256':sha(D/(label+'.log'))};(D/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode:raise ValueError(label)
 return row
save()
def interpret(target,suffix):
 rows=[]
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  row=run(suffix+'-'+name,['cargo','miri','test','--offline','--locked','--target',target,'--test','slice_encode_output_platform',*flags,'borrowed_compression_wire_bytes_capacity_and_guards','--','--exact'],S,{'CARGO_TARGET_DIR':str(D/('miri-'+suffix)),'MIRI_SYSROOT':'/private/tmp/zstdoxide-ultra-miri-'+suffix,'MIRIFLAGS':'-Zmiri-strict-provenance'})
  assert '1 passed; 0 failed; 0 ignored' in (D/(row['label']+'.log')).read_text();rows.append(row)
 return rows
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(interpret,t,s) for t,s in [('i686-unknown-linux-gnu','i686'),('s390x-unknown-linux-gnu','s390x')]]
  for f in concurrent.futures.as_completed(futures):e['commands']+=f.result();save()
 probe=D/'probe';shutil.copytree(S,probe)
 with (probe/'src/lib.rs').open('a') as f:f.write('\n// Instantiate actual caller-owned compression and bounded copying on ARM.\n#[inline(never)]\npub fn slice_encode_codegen_probe(input: &[u8], output: &mut [u8]) -> Result<usize> { compress_into(input,output) }\n')
 features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
 for name,flags in [('safe',[]),('all',['--features',','.join(features)])]:
  common=['--offline','--locked','-Zbuild-std=core,alloc','--target','thumbv6m-none-eabi','--no-default-features','--lib',*flags]
  e['commands'].append(run('thumb-'+name+'-check',['cargo','check',*common],S,{'CARGO_TARGET_DIR':str(D/'thumb-check')}));save()
  target=D/('thumb-'+name)
  e['commands'].append(run('thumb-'+name+'-objects',['cargo','rustc','--release',*common,'--','--emit=llvm-ir,obj'],probe,{'CARGO_TARGET_DIR':str(target)}));save()
  ir=[p for p in target.rglob('*.ll') if any(line.startswith(b'define ') and b'slice_encode_codegen_probe' in line for line in p.read_bytes().splitlines())];assert len(ir)==1
  assert b'llvm.memcpy' in ir[0].read_bytes(), 'Actual encoded-output copy not instantiated'
  objects=list(ir[0].parent.glob('*.o'));assert objects
  artifacts=[]
  for p in [ir[0],*objects]:
   if p.suffix=='.o':
    h=p.read_bytes()[:20];assert h[:6]==b'\x7fELF\x01\x01' and int.from_bytes(h[18:20],'little')==40
   q=D/'artifacts'/(name+'-'+p.name);q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q);artifacts.append({'path':str(q.relative_to(D)),'sha256':sha(q)})
  e.setdefault('artifacts',{})[name]=artifacts;save()
 for n,h in source.items():
  assert sha(S/n)==h,n
  if n.startswith('src/'):assert sha(R/n)==h,n
 e.update(status='passed',qualification='Four strict-provenance i686/s390x safe/all Miri executions of actual caller-owned compression and exact allocating-output parity, known size, decode, raw/RLE/compressed and short-destination guards. Four actual thumbv6m core+alloc check/object commands instantiate compression and encoded copying. Interpreter and code-generation evidence only, not foreign hardware execution. Full regression and compression timing remain separate.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
