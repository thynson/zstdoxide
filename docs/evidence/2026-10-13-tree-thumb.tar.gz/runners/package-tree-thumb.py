from pathlib import Path
import hashlib,json,io,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-thumb-v2-checks');sha=lambda b:hashlib.sha256(b).hexdigest();e=json.loads((O/'evidence.json').read_bytes());assert e['status']=='passed' and e['source_unchanged'];files={str(p.relative_to(O)):p.read_bytes() for p in O.rglob('*') if p.is_file()}
for c in e['commands']:assert c['exit_code']==0 and sha((O/c['log']).read_bytes())==c['sha256']
for n,h in e['source'].items():assert sha((R/n).read_bytes())==h;files['source/'+n]=(R/n).read_bytes()
for mode,a in e['artifacts'].items():assert sha((O/a['path']).read_bytes())==a['sha256']
for p in Path('/tmp/zstdoxide-tree-thumb-checks').rglob('*'):
 if p.is_file():files['initial/'+str(p.relative_to('/tmp/zstdoxide-tree-thumb-checks'))]=p.read_bytes()
for n in ['zstdoxide-tree-thumb-checks.py','zstdoxide-tree-thumb-v2-checks.py','package-tree-thumb.py']:files['runners/'+n]=(Path('/tmp')/n).read_bytes()
report=e|dict(initial_failure='The external probe initially selected stable Cargo outside the repository; its -Z build-std request rejected before compilation. v2 pins RUSTUP_TOOLCHAIN=nightly-2026-10-08 for every command. Both attempts and caller sources retained; production code unchanged.',thumb_library_checks=2,thumb_caller_codegen=2,processes_remaining=0)
a=R/'docs/evidence/2026-10-13-tree-thumb.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:assert {m.name:t.extractfile(m).read() for m in t}==files
report.update(archive=a.name,archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()));(R/'docs/evidence/2026-10-13-tree-thumb.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
miri=json.loads((R/'docs/evidence/2026-10-13-tree-platform-final.json').read_bytes());assert miri['status']=='passed' and miri['interpreted_test_executions']==44
combined=dict(status='passed',source_unchanged=True,processes_remaining=0,interpreted_test_executions=44,thumb_library_checks=2,thumb_caller_codegen=2,evidence={'miri':{'path':'docs/evidence/2026-10-13-tree-platform-final.json','sha256':sha((R/'docs/evidence/2026-10-13-tree-platform-final.json').read_bytes())},'thumb':{'path':'docs/evidence/2026-10-13-tree-thumb.json','sha256':sha((R/'docs/evidence/2026-10-13-tree-thumb.json').read_bytes())}},qualification='Selected strict-provenance interpretation on 32-bit little-endian i686 and 64-bit big-endian s390x; thumbv6m library/caller compile-only. No native foreign execution or firmware claim.')
Path('/tmp/zstdoxide-tree-platform-complete.json').write_text(json.dumps(combined,sort_keys=True,indent=2)+'\n');print(a.name,len(files),a.stat().st_size)
