from pathlib import Path
import hashlib,json,os,subprocess,time,tomllib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-thumb-checks');O.mkdir();P=O/'caller';(P/'src').mkdir(parents=True)
(P/'Cargo.toml').write_text('[package]\nname="zstdoxide-tree-thumb-caller"\nversion="0.0.0"\nedition="2024"\n[dependencies]\nzstdoxide={path="'+str(R)+'",default-features=false}\n')
(P/'src/lib.rs').write_text('''//! Compile/codegen-only tree caller on the no-pointer-atomics target.
#![no_std]
#![forbid(unsafe_code)]
extern crate alloc;
use alloc::{alloc::Global,rc::Rc,vec::Vec};
use core::alloc::Allocator;
use zstdoxide::{CompressionParameterRequest,Dictionary,ReferenceStrategy,Result,SharedDictionary,compress_with_parameters_in};
#[cfg(target_has_atomic="ptr")]
compile_error!("no-pointer-atomics target required");
pub fn shared_is_rc<A:Allocator>(dictionary:SharedDictionary<A>)->Rc<Dictionary<A>> {dictionary}
pub fn borrowed<'a>(input:&[u8],allocator:&'a Global)->Result<Vec<u8,&'a Global>> {
 let mut request=CompressionParameterRequest::with_level(9);
 request.set_strategy(Some(ReferenceStrategy::BinaryTreeLazy2));
 request.set_window_log(10)?;request.set_hash_log(6)?;request.set_chain_log(6)?;request.set_search_log(4)?;
 compress_with_parameters_in(input,&request,allocator)
}
''')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source={str(p.relative_to(R)):sha(p) for p in sorted((R/'src').rglob('*.rs'))};source|={n:sha(R/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']}
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/tmp/zstdoxide-tree-thumb-target',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never');rows=[];artifacts={}
def run(label,args,cwd=R):
 p=O/(label+'.log');start=time.monotonic()
 with p.open('wb') as f:r=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 rows.append(dict(label=label,argv=args,cwd=str(cwd),exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)));print(label,r.returncode,flush=True)
 if r.returncode:raise ValueError(label)
run('target-cfg',['rustc','--print','cfg','--target','thumbv6m-none-eabi'])
assert 'target_has_atomic=' not in (O/'target-cfg.log').read_text()
run('lock',['cargo','generate-lockfile','--offline'],P)
features=[k for k in tomllib.loads((R/'Cargo.toml').read_text())['features'] if k not in ['std','default']]
for mode in ['safe','all']:
 flags=[] if mode=='safe' else ['--features',','.join(features)]
 run('library-'+mode,['cargo','check','--offline','--locked','-Z','build-std=core,alloc','--target','thumbv6m-none-eabi','--no-default-features','--lib',*flags])
 flags=[] if mode=='safe' else ['--features',','.join('zstdoxide/'+f for f in features)]
 run('caller-'+mode,['cargo','build','--offline','--locked','-Z','build-std=core,alloc','--target','thumbv6m-none-eabi','--lib',*flags],P)
 p=Path(env['CARGO_TARGET_DIR'])/'thumbv6m-none-eabi/debug/libzstdoxide_tree_thumb_caller.rlib';b=p.read_bytes();q=O/(mode+'.rlib');q.write_bytes(b);artifacts[mode]=dict(path=q.name,bytes=len(b),sha256=sha(q))
assert all(sha(R/n)==h for n,h in source.items())
(O/'evidence.json').write_text(json.dumps(dict(status='passed',source_unchanged=True,source=source,commands=rows,artifacts=artifacts,environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_NET_OFFLINE']},qualification='Compile and concrete generic codegen only on thumbv6m with no pointer atomics; Rc dictionary fallback and borrowed allocator tree call. No firmware, native execution or memory-fit claim.'),sort_keys=True,indent=2)+'\n')
