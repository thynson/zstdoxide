//! Compile/codegen-only tree caller on the no-pointer-atomics target.
#![no_std]
#![forbid(unsafe_code)]
extern crate alloc;
use alloc::{alloc::Global,rc::Rc,vec::Vec};
use core::alloc::Allocator;
use zstdoxide::{CompressionParameterRequest,Dictionary,ReferenceStrategy,Result,SharedDictionary,compress_with_parameters_in};
#[cfg(target_has_atomic="ptr")]
compile_error!("no-pointer-atomics target required");
pub fn shared_is_rc<A:Allocator>(dictionary:SharedDictionary<A>)->Rc<Dictionary<A>> {dictionary}
pub fn borrowed<'a>(input:&[u8],allocator:&'a Global)->Result<Vec<u8,&'a Global>> {
 let mut request=CompressionParameterRequest::with_level(9);
 request.set_strategy(Some(ReferenceStrategy::BinaryTreeLazy2));
 request.set_window_log(10)?;request.set_hash_log(6)?;request.set_chain_log(6)?;request.set_search_log(4)?;
 compress_with_parameters_in(input,&request,allocator)
}
