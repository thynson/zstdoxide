from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,s):
 if not v:raise ValueError(s)
checks={mode:json.loads(Path('/tmp/zstdoxide-lazy-tiny-preflight-'+mode+'.json').read_bytes()) for mode in ['normal','optimized']}
for mode,e in checks.items():
 need(e['status']=='passed' and e['python_optimized']==(mode=='optimized') and e['positive_preflights']==2 and e['rejected_controls']==23 and e['child_processes']==0,'preflight controls')
 for n,h in e['source'].items():need(sha((R/n).read_bytes())==h,'source identity')
report={'date':'2026-10-12','status':'passed','source':checks['normal']['source'],'recipes':138,'planned_commands':422,'positive_preflights_per_mode':2,'rejected_controls_per_mode':23,'child_processes':0,'reference_executions':0,'qualification':'Controller preflight and early offline rejection checks before first C helper execution. Actual command and observation checks require the future capture. Review corrected a stale undefined source variable and added negative-input sanitizer diagnostic rejection before either helper execution or these completed checks.','archive':'2026-10-12-lazy-tiny-preflight.tar.gz'}
files={'controls-'+mode+'.json':enc(e) for mode,e in checks.items()}
for n in report['source']:files['source/'+n]=(R/n).read_bytes()
for n in ['check-zstdoxide-lazy-tiny-preflight.py','package-zstdoxide-lazy-tiny-preflight.py']:files['runners/'+n]=(Path('/tmp')/n).read_bytes()
files['review.json']=enc(report);files['bundle-manifest.json']=enc({n:{'bytes':len(v),'sha256':sha(v)} for n,v in files.items()})
a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh archive');prefix='lazy-tiny-preflight/'
with tarfile.open(a,'w:gz') as t:
 for n,v in sorted(files.items()):
  i=tarfile.TarInfo(prefix+n);i.size=len(v);i.mode=0o644;t.addfile(i,io.BytesIO(v))
with tarfile.open(a) as t:found={v.name:t.extractfile(v).read() for v in t}
need(found=={prefix+n:v for n,v in files.items()},'archive verification')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files));(R/'docs/evidence/2026-10-12-lazy-tiny-preflight.json').write_bytes(enc(report));print(report['archive_members'],report['archive_bytes'])
