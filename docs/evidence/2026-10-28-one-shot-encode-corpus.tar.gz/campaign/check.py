"""Formal merged-corpus campaign on the assembled module35 final source.

Executes the final-plan step-4 focused checks on the frozen assembled tree:
the merged trained-dictionary adapter (both helpers and both call sites) runs
the two deterministic corpus tests under safe, isolated frame-sink, isolated
dictionary and all-features selections. Both ledgers are validated: the
module35 ENCODE_SELECTION rows and the module34 DICT_OUTPUT rows, each with
exact cross-selection parity, and each cross-checked against the corresponding
qualified predecessor campaign ledger for exact byte identity. Strict Clippy
and format close the campaign. This is a focused evidence campaign, not the
milestone matrix, benchmark or closure.
"""
from pathlib import Path
import datetime, hashlib, json, os, re, subprocess, time

T = Path('/private/tmp')
D = T / 'module35-final-corpus'
D.mkdir(exist_ok=True)
S = T / 'module35-final'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
deadline = datetime.datetime.fromisoformat('2026-10-28T09:38:00+00:00').timestamp()
assert deadline - time.time() >= 120
assert os.getpriority(os.PRIO_PROCESS, 0) == 19, 'run under nice 19'

assembly = json.loads((T / 'module35-final-plan' / 'assembly-receipt.json').read_text())
assert assembly['status'] == 'prepared-final-source-assembled'
for n, h in assembly['source'].items():
    assert sha(S / n) == h, ('Final source changed since assembly', n)
formal = json.loads((T / 'module35-formal-phase' / 'evidence.json').read_text())
assert formal['status'] == 'passed' and len(formal['commands']) == 2
pred = json.loads((T / 'module34-archives' / 'promotion-state.json').read_text())
assert pred['stage'] == 'closed'

source = dict(assembly['source'])
plan = []
for label, flags in [('safe', []), ('sink', ['--features', 'unsafe-frame-sink']),
                     ('dictionary', ['--features', 'unsafe-dictionary']), ('all', ['--all-features'])]:
    for kind, test in [('controlled', 'trained_roundtrip_covers_modes_prefixes_reduced_bounds_and_training_fallback'),
                       ('noise', 'trained_dictionary_targets_accept_deterministic_noise_and_truncated_frames')]:
        plan.append((label + '-' + kind, ['cargo', 'test', '--offline', '--locked', '--test',
                                          'upstream_trained_dictionary_fuzz', *flags, test, '--', '--exact', '--nocapture']))
plan.extend([('clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--test',
                         'upstream_trained_dictionary_fuzz', '--all-features', '--', '-D', 'warnings']),
             ('format', ['cargo', 'fmt', '--all', '--', '--check'])])
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         deadline_utc='2026-10-28T09:38:00+00:00', source=source, production_source={n: h for n, h in source.items() if n.startswith('src/')},
         assembly_receipt_sha256=sha(T / 'module35-final-plan' / 'assembly-receipt.json'),
         formal_phase_sha256=sha(T / 'module35-formal-phase' / 'evidence.json'),
         merged_adapter_sha256=source['tests/upstream_trained_dictionary_fuzz.rs'],
         controller_sha256=sha(Path(__file__)), plan=plan, commands=[],
         qualification='Merged-adapter focused campaign on the assembled module35 final source. Both supplemental ledgers are validated with exact cross-selection parity and cross-checked against the qualified module34-corpus and module35-corpus safe ledgers. Original selectors, training and reduced-bound assertions remain. This is not the milestone matrix, benchmark campaign or closure.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(T / 'module35-final-target'), 'CARGO_BUILD_JOBS': '4',
       'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '1',
       'CARGO_PROFILE_DEV_DEBUG': '0'}


def save():
    p = D / 'evidence.pending.json'
    p.write_text(json.dumps(e, indent=2) + '\n')
    p.replace(D / 'evidence.json')


save()
try:
    for label, args in plan:
        remaining = deadline - time.time() - 30
        if remaining < 30:
            raise TimeoutError('Final-corpus cutoff before ' + label)
        e['active_command'] = label
        save()
        start = time.monotonic()
        log = D / (label + '.log')
        with log.open('xb') as f:
            proc = subprocess.Popen(args, cwd=S, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = proc.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                import signal as signal_module
                os.killpg(proc.pid, signal_module.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal_module.SIGKILL)
                    proc.wait()
                raise TimeoutError('Final-corpus cutoff during ' + label)
        row = dict(label=label, argv=args, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
        e['commands'].append(row)
        e.pop('active_command', None)
        save()
        print(label, code, flush=True)
        assert code == 0, (label, log.read_text()[-4000:])
        if label not in ['clippy', 'format']:
            text = log.read_text()
            assert re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text) == [('1', '0', '0')]
            kind = label.split('-')[1]
            enc = [line for line in text.splitlines() if line.startswith('ENCODE_SELECTION\t')]
            dic = [line for line in text.splitlines() if line.startswith('DICT_OUTPUT\t')]
            assert len(enc) == (104 if kind == 'controlled' else 13), (label, len(enc))
            assert len(dic) == (48 if kind == 'controlled' else 13) or (kind == 'noise' and len(dic) > 0), (label, len(dic))
            erows = [line.split('\t') for line in enc]
            assert all(len(r) == 10 and r[1] in ['prefix', 'persistent'] for r in erows)
            if kind == 'controlled':
                assert sum(r[1] == 'persistent' for r in erows) == 48 and sum(r[1] == 'prefix' for r in erows) == 56
            enc_payload = '\n'.join(enc) + '\n'
            dic_payload = '\n'.join(dic) + '\n'
            (D / (label + '-encode-selection.tsv')).write_text(enc_payload)
            (D / (label + '-dict-output.tsv')).write_text(dic_payload)
            if not label.startswith('safe-'):
                assert enc_payload == (D / ('safe-' + kind + '-encode-selection.tsv')).read_text(), label
                assert dic_payload == (D / ('safe-' + kind + '-dict-output.tsv')).read_text(), label
            e.setdefault('selected_cases', {})[label] = dict(
                encode_selection_rows=len(erows), dict_output_rows=len(dic),
                encode_ledger_sha256=sha(D / (label + '-encode-selection.tsv')),
                dict_ledger_sha256=sha(D / (label + '-dict-output.tsv')))
            save()
    # Cross-check both safe ledgers against the qualified predecessor campaigns.
    assert (D / 'safe-controlled-dict-output.tsv').read_bytes() == (T / 'module34-corpus' / 'safe-controlled.tsv').read_bytes(), 'DICT_OUTPUT ledger differs from the qualified module34 corpus campaign'
    assert (D / 'safe-controlled-encode-selection.tsv').read_bytes() == (T / 'module35-corpus' / 'safe-controlled.tsv').read_bytes(), 'ENCODE_SELECTION ledger differs from the qualified module35 corpus campaign'
    for n, h in source.items():
        assert sha(S / n) == h, ('Final source changed during campaign', n)
    assert len(e['commands']) == 10
    e.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
except TimeoutError as ex:
    e.update(status='interrupted-at-user-deadline', error=repr(ex))
    save()
    raise
except BaseException as ex:
    e.update(status='failed', error=repr(ex))
    save()
    raise
