"""Archive a qualified module35 focused campaign: native, platform or corpus."""
from pathlib import Path
import argparse, json, hashlib, tarfile, datetime

p = argparse.ArgumentParser()
p.add_argument('stage', choices=['native', 'platform', 'corpus'])
a = p.parse_args()
D = Path(__file__).parent
T = Path('/private/tmp')
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
folder, source, count, date = {'native': ('module35-native', 'source', 15, '2026-10-27'), 'platform': ('module35-platform', 'source', 11, '2026-10-28'), 'corpus': ('module35-final-corpus', None, 10, '2026-10-28')}[a.stage]
C = T / folder
S = C / 'source' if source else T / 'module35-final'
records = {'evidence.json': json.loads((C / 'evidence.json').read_text())}
for n, j in records.items():
    assert j['status'] == 'passed', (n, j['status'])
    assert all(r['exit_code'] == 0 for r in j.get('commands', [])), n
assert len(records['evidence.json']['commands']) == count
complete = {str(p.relative_to(S)): sha(p) for p in S.rglob('*') if p.is_file()}
production = {n: h for n, h in complete.items() if n.startswith('src/')}
for n, j in records.items():
    for path, h in j.get('source', {}).items():
        assert complete[path] == h, (n, path)
    for row in j.get('commands', []):
        if 'log_sha256' in row:
            assert any(sha(p) == row['log_sha256'] for p in C.glob('*.log')), (n, row.get('label'))
files = {}
payloads = {}
extensions = {'.rs', '.toml', '.lock', '.json', '.py', '.md', '.log', '.tsv', '.stderr', '.c', '.txt', '.ll', '.o'}
excluded = {'target', 'miri-i686', 'miri-s390x', 'host-check', 'probe', 'source', '__pycache__'}
for p in C.rglob('*'):
    if not p.is_file():
        continue
    rel = p.relative_to(C)
    if any(x in excluded or x.endswith('-target') or x.endswith('.dSYM') for x in rel.parts):
        continue
    if any(x in ['inputs', 'all-inputs', 'normal-outputs', 'sanitized-outputs'] for x in rel.parts):
        h = sha(p)
        payloads[str(rel)] = h
        files.setdefault('payloads/' + h, p)
        continue
    if p.suffix in extensions or p.name.startswith('oracle-'):
        files['campaign/' + str(rel)] = p
for p in S.rglob('*'):
    if p.is_file() and (p.suffix in {'.rs', '.toml', '.lock', '.json', '.py', '.md', '.sh', '.csv', '.tsv'} or p == S / 'tests/upstream/dictionaries/formatted.dict'):
        files['source/' + str(p.relative_to(S))] = p
if a.stage == 'platform':
    files['probe/lib.rs'] = C / 'probe/src/lib.rs'
    for name in ['interrupted-attempts']:
        for p in (C / name).rglob('*'):
            if p.is_file() and p.suffix in extensions:
                files['campaign/' + str(p.relative_to(C))] = p
files['LICENSE.zstd'] = R / 'LICENSE.zstd'
files['archive-focused.py'] = Path(__file__)
name = date + '-one-shot-encode-' + a.stage
archive = D / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
result = dict(status='passed', stage=a.stage, recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), production_source=production, complete_source=complete, records=records, receipt_sha256={n: sha(C / n) for n in records}, external_fixture_payloads=payloads, members={n: dict(sha256=sha(p), bytes=p.stat().st_size) for n, p in files.items()}, archive=archive.name, archive_sha256=sha(archive), qualification='Source-bound focused one-shot encode selection gate. Full feature/release regression, measured comparison and major-module closure remain separate. Native C is an external pinned oracle only; no native compressed-byte identity, capacity precedence, workspace equivalence or complete upstream migration is claimed. Deterministic trained selection supplements do not imply an external rolling corpus rerun or fastCover equivalence. Foreign Miri and concrete no-atomics ARM code generation check ownership transitions and actual encoding without claiming native context semantics.')
(D / (name + '.json')).write_text(json.dumps(result, indent=2) + '\n')
print(name, archive.stat().st_size)
