from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-ordinary-checks');O.mkdir();env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/zstdoxide-tree-reader-target'
paths=sorted((R/'src').glob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock',R/'tests/support/tree_frame_encode.rs',R/'tests/support/tree_frame_oracle.rs',R/'tests/support/greedy_frame_oracle.rs',R/'tests/support/greedy_frame_encode.rs'];source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};rows=[]
def run(label,args,tests=None):
 log=O/(label+'.log');start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
 b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest());rows.append(r);print(label,p.returncode,flush=True)
 if tests is not None:
  counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)];r['tests']=counts
  if counts!=[tests]:raise ValueError('test totals '+label)
 if p.returncode:raise ValueError(label)
selectors=['tree_frame_oracle_fixture::all_tree_records_replay_complete_maps_sequences_and_publication','tree_frame_oracle_fixture::bounded_tree_reader_rejects_identity_extent_selector_and_trailing_bytes','tree_frame_oracle_fixture::actual_tree_marker_and_geometry_forgeries_reject','tree_frame_oracle_fixture::every_complete_c_tree_frame_decodes_to_its_original_source','greedy_state::tests::all_tree_ordinary_trajectories_retain_exact_state','reference_frame_encode::tree_tests::ordinary_tree_frames_match_retained_publication','greedy_state::tests::all_lazy_family_ordinary_trajectories_retain_exact_state','greedy_state::tests::all_ordinary_c_candidates_tables_and_frontiers_match_without_reseeding']
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree']),('all',['--all-features']),('release-all',['--release','--all-features'])]:
 run('trajectories-'+name,['cargo','test','--offline','--locked',*flags,'--lib','--','--exact',*selectors,'--test-threads=1'],(8,0,0))
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree'])]:
 run('nostd-'+name,['cargo','check','--offline','--locked','--no-default-features',*flags])
for name,flags in [('safe',[]),('all',['--all-features'])]:
 run('clippy-'+name,['cargo','clippy','--offline','--locked','--all-targets',*flags,'--','-D','warnings'])
run('format',['cargo','fmt','--all','--','--check'])
assert source=={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,tests=32,qualification='245 ordinary tree recipes/531 exact retained blocks per configuration, 365 complete C frames decoded, 488 independently emitted Rust frames checked per configuration. Full predecessor retained-state regressions. Initial aggregate frame count 489 corrected to 488 because two empty cases emit one frame each; original failure log preserved. C entropy bytes are not required to equal Rust bytes.'),sort_keys=True,indent=2)+'\n')
