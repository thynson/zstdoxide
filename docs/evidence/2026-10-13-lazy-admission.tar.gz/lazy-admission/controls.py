import csv,io,json,pathlib,sys,tempfile,hashlib
ROOT=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize')
sys.path.insert(0,str(ROOT/'scripts'))
import check_reference_admission_v4 as m
attempts=[]
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec','os.spawn'):
  attempts.append(event);raise RuntimeError('no child execution')
sys.addaudithook(audit)
files=m.projection();m.verify(files)
def rows(data):return list(csv.DictReader(io.StringIO(data.decode()),delimiter='\t'))
def independent(v):
 w,c,h,s,_,_,strategy=v
 if strategy>=6:return 'unsupported'
 bounds={1:(20,18),2:(21,18),3:(21,19),4:(21,19),5:(21,19)}
 if w>bounds[strategy][0] or h>bounds[strategy][1]:return 'resource'
 if strategy==2 and c>18:return 'resource'
 if strategy>=3 and w<=14 and (c>18 or s>8):return 'resource'
 return 'success'
presets={(int(r['tier']),int(r['row'])):[int(r[k]) for k in ('window_log','chain_log','hash_log','search_log','min_match','target_length','strategy')] for r in rows((ROOT/'tests/upstream/parameters/presets.tsv').read_bytes())}
checked=0
for filename in ('fuzz.tsv','loops.tsv','interop.tsv','broader.tsv'):
 before=rows((ROOT/'tests/fixtures/reference-admission-v3'/filename).read_bytes());after=rows(files[filename])
 m.require(len(before)==len(after),'unchanged cardinality')
 for old,new in zip(before,after):
  for key in old:
   if key not in ('v2','additive_c_required'):m.require(old[key]==new[key],'unchanged '+key)
  if new['v3']=='advanced':expected='advanced'
  else:
   values=presets[int(new['preset_tier']),int(new['preset_row'])] if filename in ('fuzz.tsv','loops.tsv') else list(map(int,new['historical_resolved_tuple'].split(',')))
   expected=independent(values)
  m.require(new['v4']==expected,'independent policy');checked+=1
capture=(pathlib.Path('/private/tmp/zstdoxide-greedy-public-2026-10-12/evidence.json')).read_bytes()
m.require(hashlib.sha256(capture).hexdigest()==json.loads(files['provenance.json'])['greedy_capture_evidence_sha256'],'independent original capture identity')
for old,new in zip(json.loads(capture)['cases'],rows(files['greedy.tsv']),strict=True):
 r=old['recipe'];v=old['rust']['safe']['resolved']
 m.require(new['case']==r['id'] and new['source_sha256']==r['source_sha256'] and int(new['source_size'])==r['source_bytes'] and list(map(int,new['request'].split(',')))==r['request'],'all original recipe fields')
 m.require(list(map(int,new['historical_resolved_tuple'].split(',')))==v and new['v3']==old['rust']['safe']['status'] and new['v4']==independent(v),'independent historical tuple policy');checked+=1
controls=[]
def reject(name,fn):
 try:fn()
 except (ValueError,FileNotFoundError):controls.append(name)
 else:raise ValueError('accepted '+name)
for strategy in range(1,10):
 for w in [10,14,15,20,21,22,31]:
  for c in [6,18,19,30]:
   for h in [6,18,19,20,30]:
    for s in [1,6,8,9,30]:
     v=[w,c,h,s,4,0,strategy];m.require(m.classify(v)==independent(v),'boundary classification')
base=[14,18,19,8,4,0,4]
for i,(lo,hi) in enumerate([(10,31),(6,30),(6,30),(1,30),(3,7),(0,131072),(1,9)]):
 for value in [lo-1,hi+1,True,1.0,'1']:
  v=base.copy();v[i]=value;reject(f'scalar-{i}-{value!r}',lambda:m.classify(v))
for v in [[],base[:-1],base+[0],tuple(base),None]:reject('tuple-'+repr(v),lambda:m.classify(v))
with tempfile.TemporaryDirectory(prefix='zstdoxide-v4-control-') as d:
 d=pathlib.Path(d);(d/'README.md').write_text('Test documentation\n')
 for n,b in files.items():(d/n).write_bytes(b)
 m.verify(files,d)
 for n,b in files.items():
  (d/n).write_bytes(b+b'\n');reject('changed-'+n,lambda:m.verify(files,d));(d/n).write_bytes(b)
 (d/'extra').touch();reject('extra-file',lambda:m.verify(files,d));(d/'extra').unlink()
 for n in ['fuzz.tsv','README.md']:
  p=d/n;saved=p.read_bytes();p.unlink();p.symlink_to(m.DESTINATION/n);reject('linked-'+n,lambda:m.verify(files,d));p.unlink();p.write_bytes(saved)
 link=d/'linked';link.symlink_to(m.DESTINATION);reject('linked-directory',lambda:m.verify(files,link))
m.require(not attempts,'no child attempts')
print(json.dumps(dict(optimized=not __debug__,independent_rows=checked,boundary_classifications=6300,controls=controls,child_attempts=len(attempts),fixture_sha256={n:m.sha(b) for n,b in files.items()}),indent=2,sort_keys=True))
