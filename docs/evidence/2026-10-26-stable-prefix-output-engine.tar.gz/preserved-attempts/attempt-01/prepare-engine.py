from pathlib import Path
import shutil,json,hashlib
S=Path('/private/tmp/module26-candidate');R=Path('/private/tmp/module27-engine');assert not R.exists();R.mkdir()
for folder in ['src','tests','test-support','benches','examples','scripts']:
 if (S/folder).exists():shutil.copytree(S/folder,R/folder)
for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(S/n,R/n)
p=R/'src/lib.rs';s=p.read_text().replace('mod slice_decode;','mod slice_attachment;\nmod slice_decode;');p.write_text(s)
s=Path('/private/tmp/module27-attachment/slice_attachment.rs').read_text().replace('    PendingPrefix(D),','    // Private integration precedes public prefix constructors.\n    #[cfg_attr(not(test), allow(dead_code))]\n    PendingPrefix(D),');(R/'src/slice_attachment.rs').write_text(s)
p=R/'src/slice_decode.rs';s=p.read_text().replace('use crate::slice_history::SliceHistory;','use crate::slice_history::SliceHistory;\nuse crate::slice_attachment::Attachment;').replace('    dictionary: Option<D>,','    attachment: Attachment<D>,').replace('Self::with_attachment(output, options, None, allocator)','Self::with_attachment(output, options, Attachment::None, allocator)').replace('Self::with_attachment(output, options, Some(dictionary), allocator)','Self::with_attachment(output, options, Attachment::Persistent(dictionary), allocator)').replace('            dictionary,\n            history:', '            attachment,\n            history:')
s=s.replace('        self.history.reset();','        self.attachment.release_active();\n        self.history.reset();')
s=s.replace('        self.dictionary\n            .as_ref()','        self.attachment\n            .retained()')
s=s.replace('let dictionary = self.dictionary.as_ref().map(DictionaryHandle::view);','let dictionary = self.attachment.current().map(DictionaryHandle::view);')
s=s.replace('let (header, _) = FrameHeader::parse(&self.scratch[..size])?;','let (header, _) = FrameHeader::parse(&self.scratch[..size])?;\n                    self.attachment.claim();')
s=s.replace('        self.phase = Phase::Header;\n        self.filled = 0;\n        self.frame = None;\n        self.history.start_frame(0);','        self.attachment.release_active();\n        self.phase = Phase::Header;\n        self.filled = 0;\n        self.frame = None;\n        self.history.start_frame(0);')
assert 'self.dictionary' not in s
p.write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(R/'preparation.json').write_text(json.dumps(dict(status='prepared',predecessor_source={str(p.relative_to(S)):sha(p) for p in (S/'src').glob('*.rs')},attachment_source_sha256=sha(Path('/private/tmp/module27-attachment/slice_attachment.rs')),qualification='External private prefix engine; no public prefix entrypoint yet, predecessor source unchanged.'),indent=2)+'\n')
