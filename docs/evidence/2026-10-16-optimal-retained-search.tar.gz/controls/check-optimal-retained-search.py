from pathlib import Path
import subprocess,json,hashlib,time
root=Path.cwd();out=Path('/tmp/zstdoxide-optimal-retained-search-checks');out.mkdir(exist_ok=False)
paths=[root/p for p in ['src/lib.rs','src/optimal_search.rs','src/optimal_search_layout.rs']]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={str(p.relative_to(root)):sha(p) for p in paths};commands=[]
configs=[('safe',[]),('tree',['--features','unsafe-reference-tree']),('short',['--features','unsafe-optimal-short-key']),('matches',['--features','unsafe-optimal-matches']),('all',['--all-features']),('release-all',['--release','--all-features'])]
for label,args in configs:
 argv=['cargo','test','--offline','--locked',*args,'--lib','optimal_search'];p=out/(label+'.log');start=time.monotonic()
 with p.open('wb') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
 commands.append(dict(label=label,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)));print(label,r.returncode,flush=True)
 if r.returncode:break
else:
 for label,args in [('clippy',['clippy','--all-features','--tests','--','-D','warnings']),('nostd',['check','--no-default-features']),('fmt',['fmt','--all','--','--check'])]:
  argv=['cargo',*args];p=out/(label+'.log');start=time.monotonic()
  with p.open('wb') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
  commands.append(dict(label=label,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)));print(label,r.returncode,flush=True)
  if r.returncode:break
unchanged=source=={str(p.relative_to(root)):sha(p) for p in paths}
(out/'evidence.json').write_text(json.dumps(dict(status='passed' if unchanged and len(commands)==9 and all(c['exit_code']==0 for c in commands) else 'failed',source=source,source_unchanged=unchanged,commands=commands),indent=2)+'\n')
