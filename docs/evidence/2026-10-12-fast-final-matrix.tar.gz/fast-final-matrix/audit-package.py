from pathlib import Path
import hashlib, io, json, re, subprocess, tarfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize'); OUT=Path('/tmp/zstdoxide-module12-final-matrix')
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
e=read(OUT/'evidence.json'); before=read(OUT/'source-before.json'); after=read(OUT/'source-after.json'); snap=read(OUT/'snapshot.json')
assert len(e['commands'])==53 and before==after and e['source_unchanged'] is True
assert e['interruption']['interrupted_label'] is None and not e['interruption']['remaining_owned_processes']
for n,k in [('snapshot.json','snapshot_sha256'),('source-before.json','source_before_sha256'),('source-after.json','source_after_sha256')]:
 assert sha((OUT/n).read_bytes())==e[k]
for name,digest in before.items(): assert sha((OUT/'source'/name).read_bytes())==digest,name
comparisons={}; differences=[]
for name,digest in before.items():
 p=ROOT/name
 same=p.exists() and sha(p.read_bytes())==digest
 if not same: differences.append(name)
 if name.startswith(('src/','scripts/','examples/','benches/','test-support/')) or name in ('Cargo.toml','Cargo.lock','rust-toolchain.toml') or (name.startswith('tests/') and not name.endswith('.md')):
  comparisons[name]=same
assert all(comparisons.values()),[n for n,v in comparisons.items() if not v]
counts=[]
for c in e['commands']:
 assert c['exit_code']==c['expected_exit'] and c['exception'] is None,c['label']
 b=Path(c['log']).read_bytes(); assert sha(b)==c['log_sha256'],c['label']
 if c['kind'] in ('full-suite','allocator-suite','doc-examples'):
  rows=[list(map(int,m)) for m in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',b)]
  total=[sum(x[i] for x in rows) for i in range(5)]
  assert rows==c['test_harnesses'] and total==c['totals']
  if c['kind']=='full-suite':
   assert total==[956,0,54,0,0];counts.append(total)
  elif c['kind']=='doc-examples': assert total==[21,0,0,0,0]
  else: assert total==[13,0,0,0,0]
assert len(counts)==15 and e['full_suite_totals']==[14340,0,810,0,0]
nostd=[c for c in e['commands'] if c['label'].startswith('nostd-')];assert len(nostd)==14
known=next(c for c in e['commands'] if c['label']=='known-incomplete');assert known['unfinished_source_units']==[188] and known['exit_code']==1
report={'schema_version':1,'status':'passed','audit_date':'2026-10-12','execution_date':'2026-10-09','current_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'snapshot_base':e['base'],'original_evidence_sha256':sha((OUT/'evidence.json').read_bytes()),'original_status':e['status'],'pause_qualification':'All 53 commands and final unchanged-source check completed before pause. The later pause marker changed status but records no interrupted command or remaining process. Original evidence is preserved unchanged. This audit reruns no tests.','source_comparisons':comparisons,'documentation_differences':differences,'full_suites':15,'per_suite_totals':[956,0,54,0,0],'totals_order':['passed','failed','ignored','measured','filtered'],'full_suite_totals':[14340,0,810,0,0],'no_std_configurations':14,'registered_examples_safe':21,'registered_examples_all':21,'allocator_tests':13,'known_unfinished_upstream_sources':188,'commands_verified':53,'archive':'2026-10-12-fast-final-matrix.tar.gz'}
members={p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()}
members['runner.py']=Path('/tmp/zstdoxide-module12-matrix.py').read_bytes()
members['audit-package.py']=Path(__file__).read_bytes()
for row in snap['overlays']: members['overlays/'+row['path']]=(OUT/'source'/row['path']).read_bytes()
members['resume-audit.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode()
members['README.txt']=b'Complete original command logs, source catalogs, runner and snapshot overlays. Reconstruct source from recorded Git base plus overlays. Targets, executables and unchanged base files omitted. Resume audit preserves the original pause status and verifies completed checks without rerunning them.\n'
manifest={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())}
members['bundle-manifest.json']=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
archive=ROOT/'docs/evidence'/report['archive']; assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('fast-final-matrix/'+n);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert set(t.getnames())=={'fast-final-matrix/'+n for n in members}
 for n,b in members.items(): assert t.extractfile('fast-final-matrix/'+n).read()==b
report['archive_sha256']=sha(archive.read_bytes());report['archive_bytes']=archive.stat().st_size;report['archive_members']=len(members)
(ROOT/'docs/evidence/2026-10-12-fast-final-matrix.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['source_comparisons']},indent=2))
