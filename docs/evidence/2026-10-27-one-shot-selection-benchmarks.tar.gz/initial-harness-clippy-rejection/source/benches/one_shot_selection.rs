//! Identical fixed layouts, separate source restoration and scratch accounting.
//! Every timed operation uses a per-call clock, including the direct baseline.
//! Source/destination allocation, validation and tracking ledgers are not timed.
#![feature(allocator_api)]
use std::{alloc::Global, hint::black_box, time::Instant};
use zstdoxide::{
    DecodeOptions, Dictionary, OneShotDecoder, decompress_in_place_with_dictionary_in,
    decompress_into_with_dictionary_in, decompression_margin,
};
use zstdoxide_test_allocator::{AllocatorConfig, TrackingAllocator};

fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |h, &b| {
        (h ^ u64::from(b)).wrapping_mul(0x100000001b3)
    })
}
struct Case {
    name: &'static str,
    frame: Vec<u8>,
    source: Vec<u8>,
    dictionary: Vec<u8>,
    raw: bool,
    tight: bool,
}
fn cases() -> Vec<Case> {
    let mut cases = Vec::new();
    macro_rules! fixture {
        ($name:literal, $dict:literal, $raw:literal) => {
            cases.push(Case {
                name: $name,
                frame: include_bytes!(concat!("../tests/upstream/dictionaries/", $name, ".zst"))
                    .to_vec(),
                source: include_bytes!(concat!(
                    "../tests/upstream/dictionaries/",
                    $name,
                    ".expected"
                ))
                .to_vec(),
                dictionary: include_bytes!(concat!("../tests/upstream/dictionaries/", $dict))
                    .to_vec(),
                raw: $raw,
                tight: false,
            });
        };
    }
    fixture!("p0-far-dictionary", "boundary-dictionary.raw", true);
    fixture!(
        "dictionary-to-frame-eviction",
        "boundary-dictionary.raw",
        true
    );
    fixture!("formatted-id", "formatted.dict", false);
    fixture!("formatted-omitted-id", "formatted.dict", false);
    fixture!("dictionary-treeless-literals", "formatted.dict", false);
    fixture!("dictionary-treeless-four-streams", "formatted.dict", false);
    fixture!("dictionary-repeat-sequences", "trained.dict", false);
    let dictionary =
        include_bytes!("../tests/upstream/data/golden-dictionaries/http-dict-missing-symbols")
            .to_vec();
    cases.push(Case {
        name: "http",
        frame: include_bytes!("../tests/upstream/data/generated/http-dictionary.zst").to_vec(),
        source: include_bytes!("../tests/upstream/data/golden-compression/http").to_vec(),
        dictionary: dictionary.clone(),
        raw: false,
        tight: false,
    });
    cases.push(Case {
        name: "empty",
        frame: vec![0x28, 0xb5, 0x2f, 0xfd, 0x20, 0, 1, 0, 0],
        source: Vec::new(),
        dictionary: dictionary.clone(),
        raw: false,
        tight: false,
    });
    let mut frame = cases[7].frame.clone();
    frame.extend_from_slice(&cases[7].frame);
    let mut source = cases[7].source.clone();
    source.extend_from_slice(&cases[7].source);
    cases.push(Case {
        name: "concatenated",
        frame,
        source,
        dictionary: dictionary.clone(),
        raw: false,
        tight: false,
    });
    let source: Vec<_> = (0..120000).map(|i| (i * 7 + 13) as u8).collect();
    let mut frame = vec![0x28, 0xb5, 0x2f, 0xfd, 0xa0];
    frame.extend_from_slice(&(source.len() as u32).to_le_bytes());
    frame.extend_from_slice(&(((source.len() as u32) << 3) | 1).to_le_bytes()[..3]);
    frame.extend_from_slice(&source);
    cases.push(Case {
        name: "raw-overlap",
        frame,
        source,
        dictionary,
        raw: false,
        tight: true,
    });
    cases
}
fn main() {
    let command = std::env::args().nth(1).expect("qualify or measure");
    assert!(command == "qualify" || command == "measure");
    for Case {
        name,
        frame,
        source,
        dictionary: dictionary_bytes,
        raw,
        tight,
    } in cases()
    {
        let dictionary = if raw {
            Dictionary::raw(&dictionary_bytes)
        } else {
            Dictionary::from_bytes(&dictionary_bytes)
        }
        .unwrap();
        let view = dictionary.view();
        let capacity = if tight {
            frame.len()
        } else {
            (source.len() + decompression_margin(&frame).unwrap()).max(frame.len())
        };
        let input_start = capacity - frame.len();
        let mut buffer = vec![0xa5; capacity + 16];
        buffer[8 + input_start..8 + capacity].copy_from_slice(&frame);
        let before = buffer.clone();
        let mut direct = vec![0xa5; capacity + 16];
        let options = DecodeOptions::new(source.len());
        if command == "qualify" {
            for mode in [
                "stateless-direct",
                "persistent-direct",
                "prefix-direct",
                "stateless-in-place",
                "persistent-in-place",
                "prefix-in-place",
            ] {
                let owner = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                let monitor = owner.monitor();
                let dictionary_owner = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                let dictionary_monitor = dictionary_owner.monitor();
                let selected = if raw {
                    Dictionary::raw_in(&dictionary_bytes, &dictionary_owner)
                } else {
                    Dictionary::from_bytes_in(&dictionary_bytes, &dictionary_owner)
                }
                .unwrap();
                let dictionary_before = dictionary_monitor.snapshot();
                let view = selected.view();
                let mut decoder = OneShotDecoder::without_dictionary(options);
                if mode.starts_with("persistent") {
                    decoder.set_dictionary(Some(view));
                }
                if mode.starts_with("prefix") {
                    decoder.set_prefix(Some(view));
                }
                assert_eq!(dictionary_monitor.snapshot(), dictionary_before);
                assert_eq!(monitor.snapshot().attempts, 0);
                buffer.copy_from_slice(&before);
                direct.fill(0xa5);
                let result = if mode.ends_with("in-place") {
                    if mode.starts_with("stateless") {
                        decompress_in_place_with_dictionary_in(
                            &mut buffer[8..8 + capacity],
                            input_start,
                            &view,
                            options,
                            owner,
                        )
                    } else {
                        decoder.decompress_in_place_in(
                            &mut buffer[8..8 + capacity],
                            input_start,
                            owner,
                        )
                    }
                } else if mode.starts_with("stateless") {
                    decompress_into_with_dictionary_in(
                        &frame,
                        &mut direct[8..8 + capacity],
                        &view,
                        options,
                        owner,
                    )
                } else {
                    decoder.decompress_into_in(&frame, &mut direct[8..8 + capacity], owner)
                };
                assert_eq!(result, Ok(source.len()));
                assert!(!decoder.prefix_pending());
                assert_eq!(
                    decoder.dictionary().is_some(),
                    mode.starts_with("persistent")
                );
                if mode.ends_with("in-place") {
                    assert_eq!(&buffer[8..8 + source.len()], source);
                    assert_eq!(&buffer[..8], &before[..8]);
                    assert_eq!(&buffer[8 + source.len()..], &before[8 + source.len()..]);
                } else {
                    assert_eq!(&direct[8..8 + source.len()], source);
                    assert!(
                        direct[..8]
                            .iter()
                            .chain(&direct[8 + source.len()..])
                            .all(|&b| b == 0xa5)
                    );
                }
                assert_eq!(dictionary_monitor.snapshot(), dictionary_before);
                drop(decoder);
                drop(selected);
                drop(dictionary_owner);
                dictionary_monitor.assert_released();
                monitor.assert_released();
                let a = monitor.snapshot();
                let d = dictionary_monitor.snapshot();
                assert_eq!(a.identities_created, a.owners_dropped);
                assert_eq!(d.identities_created, d.owners_dropped);
                println!(
                    "{name}\t{mode}\t{}\t{:016x}\t{capacity}\t{input_start}\t{}\t{}\t{}\t{}",
                    source.len(),
                    fingerprint(&source),
                    a.attempts,
                    a.requested_bytes,
                    a.peak_bytes,
                    a.deallocate_calls
                );
                println!(
                    "{name}\tdictionary-{mode}\t{}\t{:016x}\t{}\t{}\t{}\t{}",
                    dictionary_bytes.len(),
                    fingerprint(&dictionary_bytes),
                    d.attempts,
                    d.requested_bytes,
                    d.peak_bytes,
                    d.deallocate_calls
                );
            }
            continue;
        }
        let iterations = (1024 * 1024 / source.len().max(1)).clamp(8, 1024);
        for mode in [
            "stateless-direct",
            "persistent-direct",
            "prefix-direct",
            "prefix-direct-with-setup",
            "stateless-in-place",
            "persistent-in-place",
            "prefix-in-place",
            "prefix-in-place-with-setup-restore",
            "setup-restore-only",
        ] {
            let mut persistent = OneShotDecoder::with_dictionary(options, view);
            let mut prefix = OneShotDecoder::without_dictionary(options);
            buffer.copy_from_slice(&before);
            direct.fill(0xa5);
            for sample in 0..5 {
                let mut elapsed = 0;
                for _ in 0..iterations {
                    if mode.ends_with("in-place") {
                        buffer[8 + input_start..8 + capacity].copy_from_slice(black_box(&frame));
                    }
                    if mode == "prefix-direct" || mode == "prefix-in-place" {
                        prefix.set_prefix(Some(view));
                    }
                    let start = Instant::now();
                    let result = match mode {
                        "stateless-direct" => decompress_into_with_dictionary_in(
                            black_box(&frame),
                            black_box(&mut direct[8..8 + capacity]),
                            black_box(&view),
                            black_box(options),
                            Global,
                        ),
                        "persistent-direct" => persistent.decompress_into(
                            black_box(&frame),
                            black_box(&mut direct[8..8 + capacity]),
                        ),
                        "prefix-direct" => prefix.decompress_into(
                            black_box(&frame),
                            black_box(&mut direct[8..8 + capacity]),
                        ),
                        "prefix-direct-with-setup" => {
                            prefix.set_prefix(Some(black_box(view)));
                            prefix.decompress_into(
                                black_box(&frame),
                                black_box(&mut direct[8..8 + capacity]),
                            )
                        }
                        "stateless-in-place" => decompress_in_place_with_dictionary_in(
                            black_box(&mut buffer[8..8 + capacity]),
                            black_box(input_start),
                            black_box(&view),
                            black_box(options),
                            Global,
                        ),
                        "persistent-in-place" => persistent.decompress_in_place(
                            black_box(&mut buffer[8..8 + capacity]),
                            black_box(input_start),
                        ),
                        "prefix-in-place" => prefix.decompress_in_place(
                            black_box(&mut buffer[8..8 + capacity]),
                            black_box(input_start),
                        ),
                        "prefix-in-place-with-setup-restore" => {
                            black_box(&mut buffer[8 + input_start..8 + capacity])
                                .copy_from_slice(black_box(&frame));
                            prefix.set_prefix(Some(black_box(view)));
                            prefix.decompress_in_place(
                                black_box(&mut buffer[8..8 + capacity]),
                                black_box(input_start),
                            )
                        }
                        "setup-restore-only" => {
                            black_box(&mut buffer[8 + input_start..8 + capacity])
                                .copy_from_slice(black_box(&frame));
                            prefix.set_prefix(Some(black_box(view)));
                            prefix.set_prefix(None);
                            Ok(0)
                        }
                        _ => unreachable!(),
                    };
                    black_box(result.as_ref());
                    elapsed += start.elapsed().as_nanos();
                    assert_eq!(
                        result,
                        Ok(if mode == "setup-restore-only" {
                            0
                        } else {
                            source.len()
                        })
                    );
                }
                if mode.contains("direct") {
                    assert_eq!(&direct[8..8 + source.len()], source);
                    assert!(
                        direct[..8]
                            .iter()
                            .chain(&direct[8 + source.len()..])
                            .all(|&b| b == 0xa5)
                    );
                } else if mode == "setup-restore-only" {
                    assert_eq!(buffer, before);
                } else {
                    assert_eq!(&buffer[8..8 + source.len()], source);
                    assert_eq!(&buffer[..8], &before[..8]);
                    assert_eq!(&buffer[8 + source.len()..], &before[8 + source.len()..]);
                }
                assert!(!prefix.prefix_pending());
                assert!(prefix.dictionary().is_none());
                assert!(persistent.dictionary().is_some());
                println!("{name}\t{mode}\t{sample}\t{iterations}\t{elapsed}");
            }
        }
    }
}
