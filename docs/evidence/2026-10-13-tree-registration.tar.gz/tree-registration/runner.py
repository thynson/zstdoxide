from pathlib import Path
import hashlib,json,shlex,subprocess,sys,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-registration');O.mkdir()
commands=['python3 scripts/check_reference_lazy_baseline.py','python3 scripts/check_tree_recipes.py --self-test','python3 scripts/check_tree_family_recipes.py','python3 scripts/check_tree_validator.py','python3 scripts/capture_tree_tiny.py --check-plan','python3 scripts/capture_tree_families.py --check-plan','python3 scripts/pack_tree_fixtures.py']
results=[]
for mode in ['normal','optimized']:
 for i,cmd in enumerate(commands):
  args=shlex.split(cmd)
  if mode=='optimized':args.insert(1,'-O')
  log=O/(mode+'-'+str(i)+'.log');start=time.monotonic()
  with log.open('wb') as f:p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  results.append(dict(argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
  print(mode,cmd,p.returncode,flush=True)
  if p.returncode:raise ValueError('registration check')
p=subprocess.run(['sh','-n','scripts/check.sh'],cwd=R,capture_output=True,check=True)
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=results,shell_syntax=True,driver_sha256=hashlib.sha256((R/'scripts/check.sh').read_bytes()).hexdigest()),indent=2)+'\n')
