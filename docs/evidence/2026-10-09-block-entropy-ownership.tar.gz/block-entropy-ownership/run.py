from pathlib import Path
import subprocess,os,json,re,hashlib,sys
root=Path(__file__).resolve().parent; source=root/'source';env=os.environ.copy();env['CARGO_TARGET_DIR']=str(root/'target')
features=["unsafe-byte-cursor","unsafe-bitstream","unsafe-history","unsafe-ring-history","unsafe-fse","unsafe-fse-encoder","unsafe-huffman","unsafe-huffman-codebook","unsafe-match-table","unsafe-match-chain","unsafe-dictionary","unsafe-training"]
commands=[]
for label,flags in [('safe',[]),('all',['--all-features']),('nostd-safe',['--no-default-features']),('nostd-all',['--no-default-features','--features',','.join(features)])]:
 commands.append(('encode-'+label,['cargo','test','--locked','--lib',*flags,'encode::tests::'],True))
for label,flags in [('safe',[]),('all',['--all-features'])]:
 commands.append(('defaults-'+label,['cargo','test','--locked','--test','match_search_defaults',*flags],True))
 commands.append(('controls-'+label,['cargo','test','--locked','--test','match_search_options',*flags],True))
commands.extend([('clippy-safe',['cargo','clippy','--locked','--all-targets','--','-D','warnings'],False),('clippy-all',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings'],False),('nostd-safe',['cargo','check','--locked','--lib','--no-default-features'],False),('nostd-all',['cargo','check','--locked','--lib','--no-default-features','--features',','.join(features)],False),('format',['cargo','fmt','--all','--','--check'],False)])
records=[]
for label,command,tests in commands:
 r=subprocess.run(command,cwd=source,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log=root/(label+'.log');log.write_bytes(r.stdout);text=r.stdout.decode(errors='replace')
 counts=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
 records.append({'label':label,'command':command,'exit':r.returncode,'log':log.name,'sha256':hashlib.sha256(r.stdout).hexdigest(),'test_counts':counts})
 (root/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(label,r.returncode,counts,flush=True)
 if r.returncode or tests and(not counts or sum(c[0] for c in counts)==0 or any(c[1] for c in counts)):
  print(text[-12000:]);sys.exit(1)
original=json.loads((root/'source-manifest.json').read_text())
assert all(hashlib.sha256((source/p).read_bytes()).hexdigest()==h for p,h in original.items())
print('all frozen inputs unchanged',flush=True)
