# Block entropy extraction preflight

Read-only review for Module 12, 2026-10-09. No source edits, builds, tests or
timing were performed. The proposed destination is `src/block_entropy.rs`;
root owns implementation and commits. Golden owns sequence-context work.
This note supplements the committed reference-fast/offset-interface designs.

## Existing constructor graph: preserve the actual clone sources and order

`BlockEncoder::new_in` currently evaluates fresh children in this order
(`src/encode.rs:162–190`). With a fresh owned TrackingAllocator identity 1,
which gives each clone a distinct identity, the exact construction is:

| Step | Operation | Result owner |
| --- | --- | --- |
| 1 | clone outer A; construct named literal Vec | id 2 |
| 2 | clone outer A; enter LiteralEncoder::new_in | argument id 3 |
| 3 | clone literal argument; construct BitWriter | id 4 |
| 4 | clone literal argument; construct streams Vec | id 5 |
| 5 | move literal argument into section Vec | id 3 |
| 6 | clone outer A; construct named LogicalSequence Vec | id 6 |
| 7 | clone outer A; enter SequenceEncoder::new_in | argument/factory id 7 |
| 8 | clone sequence argument into plans Vec | id 8 |
| 9–11 | clone sequence argument into LL/OF/ML symbol Vecs | ids 9, 10, 11 |
| 12 | clone sequence argument into section Vec | id 12 |
| 13 | clone sequence argument into BitWriter | id 13 |
| 14 | move sequence argument into its retained factory | id 7 |
| 15 | clone outer A into candidate payload Vec | id 14 |
| 16 | move original outer A into BlockEncoder factory | id 1 |

There are **13 clone calls, 14 retained identities and zero payload allocation
requests** at construction. Match/seed/chain/ring slots and dictionary are None.
LiteralEncoder owns three allocator values; SequenceEncoder owns six buffer
values plus its factory; named literal/sequence/payload vectors own three more;
outer factory owns the original. Codebooks own fixed arrays, not allocations.
They are movable values but the actual HuffmanCodebook type is not Copy/Clone.

Preserve this graph with locals in the exact old evaluation order:

```rust
let literals = Vec::new_in(allocator.clone());
let literal_encoder = LiteralEncoder::new_in(allocator.clone());
let sequences = Vec::new_in(allocator.clone());
let sequence_encoder = SequenceEncoder::new_in(allocator.clone());
let payload = Vec::new_in(allocator.clone());
let entropy = BlockEntropyEncoder::from_parts(
    literal_encoder, sequence_encoder, payload,
);
// Move literals, sequences, entropy and original allocator into BlockEncoder.
```

`from_parts` should move complete owners without cloning, reserving, clearing
or resetting. Do not call a newly grouped `new_in(allocator.clone())` at the old
literal field position: it would construct sequence-entropy and payload owners
before the named sequence Vec, changing observable clone identities. Do not
pass an allocator clone to adopt any existing Vec. No equivalence of distinct
allocator clones is assumed.

The Global const constructor can compose a const `from_parts` from the same
existing empty children. A later Fast convenience constructor may use its own
explicit fresh-owner order, moving its original argument into payload and
cloning for children, without retaining an extra factory. That constructor is
not needed to refactor the named path first.

## Normal drop order is a separate, observable detail

Current field declaration order drops match table, dictionary seed, chain,
chain seed, active dictionary, history, named literals, literal context,
codebooks, named sequences, sequence context, payload, then outer allocator
(scalar fields omitted). Within LiteralEncoder the order is writer, streams,
section; within SequenceEncoder it is defaults, channels, plans, three symbol
vectors, section, writer, factory. Vec and each child's internal destruction
retain its own allocator until that child's backing storage is freed.

A single aggregate containing literal context, codebooks, sequence context and
payload cannot preserve the old interleaving around the separately owned named
sequence Vec merely by choosing the aggregate's field position. For example,
putting named literals then named sequences then entropy moves id 6's drop
before the literal context. Placing entropy before sequences moves id 6 after
sequence context/payload. This does not change ownership safety or release
completeness, but do not claim identical destructor order.

There is no public guarantee of private field destruction order. Prefer the
simple safe composition and explicitly qualify that constructor clone/move
order and each owner's identity are preserved, while aggregate field-drop
interleaving may change. Do not add Option/explicit Drop/ManuallyDrop machinery
merely to preserve this otherwise unpromised detail. In particular no unsafe
operation belongs in this extraction. Ordinary A::clone may panic, and locals
can also change unwind destruction order; preserve sound automatic cleanup
without claiming a stronger panic-order contract than existing APIs document.

## Exact frame setup order and failure boundary

Current BlockEncoder::start_frame (`src/encode.rs:193–275`) performs:

1. Validate complete named SearchShape, before clones or mutations.
2. Borrow dictionary entropy and construct the fixed HuffmanCodebook from its
   lengths. This is fallible validation but allocates no heap storage.
3. Build/reconfigure/fill named dictionary seeds, or reset seed tags if no usable
   dictionary. A seed can already change before a later failure.
4. SequenceEncoder::start_frame_with_entropy constructs prospective LL, OF and
   ML inverse tables into local owners, in that order, then resets/publishes
   sequence state only when all three are ready.
5. Install the prepared literal table, clear its pending table, replace active
   dictionary, clear existing history, zero position and install the window.

The sequence context's setup failure preserves its complete previous context,
including any pending candidate (`sequence_context.rs:173–208`, and existing
allocator_dictionary_copy_failures_preserve_the_complete_pending_context).
But the enclosing BlockEncoder setup does **not** roll back seed work. Its
reset-before-reuse rule is intentional and independently tested.

Moving all entropy setup after seed work would move Huffman validation later;
moving all entropy setup before seeds would reorder FSE allocation and failure
ordinals. Neither is the narrow extraction. Keep the prospective literal table
local in outer start_frame, then pass that already-validated movable value and
the same borrowed entropy view to the aggregate only after seed preparation.
For example `entropy.start_frame(entropy_view, literal_table)` internally calls
SequenceEncoder::start_frame_with_entropy first, then installs the codebook and
clears pending state. Document that this crate-private pair originates from the
same view; there is only one named caller. A separately designed prepared-setup
record is possible later, but not necessary for this refactor.

No dictionary view or input reference survives the call. The active dictionary
handle remains owned by BlockEncoder, and only its ordinary outer reset/drop
releases it. The aggregate must not duplicate that handle or its accounting.

## Reset, candidate and allocation behavior to retain

Block reset first clears active dictionary, clears committed/pending literal
tables, resets sequence availability/repeats, clears history and resets frame
counters/window. It does not free child allocations. Sequence reset calls
its discard, marks channels unavailable and restores [1,4,8], retaining all
current/spare/default tables and buffers (`sequence_context.rs:361–372`).
LiteralEncoder currently has no reset method; its section/streams/writer buffers
may retain stale scratch bytes, but no codebook is published by that scratch.
Named literal/sequence/payload lengths also need not be cleared to retain their
capacity. New aggregate discard/reset may clear candidate payload availability,
but do not add allocation, shrinking or replacement of any typed owner.

At each named encode_block, pending codebook and sequence candidate are
invalidated **before** output.try_reserve(block.len()+3). The reserve precedes
raw/RLE selection and all new parse/entropy work. Therefore a destination
allocation failure must not parse, clone, allocate entropy or advance source
history. The outer encode may already have prepared the ring; preserve that
existing boundary rather than promising no scratch effect at all.

The named early uniform-RLE path must remain early; this extraction is not the
Fast parser's parse-before-fallback schedule. Raw output from a rejected parsed
candidate drops only pending codebook/sequence publication. A compressed block
appends its reserved bytes, then installs the pending codebook and commits
sequence tables/repeats; both publication steps are infallible. Only afterwards
does outer encode commit original bytes to the ring and advance position.

Current compress_block can leave a pending literal codebook after a later
sequence/payload allocation failure. The public caller must reset, so this is
not committed-state corruption. A new shared prepare should discard all pending
state on error as committed design requires; describe that as tighter private
candidate exposure, not evidence that the old code already cleared every
pending field. Keep source/history/output unchanged and keep scratch capacity
accounted, even when it grew before failure.

## Minimal first-checkpoint API

The aggregate owns LiteralEncoder, committed/pending codebooks, SequenceEncoder
and payload. It owns no extra allocator factory or parser vectors. Suggested
first extraction interface:

- const `from_parts(LiteralEncoder<A>, SequenceEncoder<A>, Vec<u8,A>) -> Self`;
- `start_frame(Option<DictionaryEntropyView>, Option<HuffmanCodebook>) -> Result<()>`,
  with prevalidated codebook from the same view as described above;
- `prepare_named(regenerated_size, literals, &[LogicalSequence]) -> Result<()>`;
- `as_bytes() -> &[u8]`, `commit()`, `discard()`, `reset()`, `retained_capacity()`.

Before fallible preparation, validate sum(LL)<=literal bytes and literal bytes
+sum(ML)==regenerated_size, with checked sums and MAX_BLOCK_SIZE. This adds no
owner. Keep literal select followed by canonical sequence prepare followed by
payload reserve/push in its existing order. A checked maximum-size helper can
share the reconstruction check with the later Fast intent path without creating
a temporary sequence vector. Candidate size comparison stays outside the
aggregate, so named any-smaller policy is unchanged. Existing frame/block header
writers, match parsing, ring updates and early-RLE choice stay in encode.rs.

Golden's forthcoming context changes supply committed_repeats and explicit
prepare_with_offsets. Do not implement those again or replace its canonical
prepare. Fast-only literal/gain/header policy belongs to the next planned
checkpoint, not this byte-neutral extraction.

Capacity accounting is a mechanical regrouping:
`entropy.retained_capacity = literal_encoder.retained_capacity +
sequence_encoder.retained_capacity + payload.capacity`.
Outer adds unchanged search owners, named literal capacity and named sequence
capacity*size_of::<LogicalSequence>. Fixed codebooks, wrapper inline bytes,
opaque allocator bookkeeping and externally accounted dictionaries remain
excluded under the existing documented meaning. Do not count dictionary bytes
again or omit inactive cached sequence tables.

## Reuse existing witnesses; add only extraction-specific observations

Existing tests in encode.rs directly inspect private entropy fields. Keep their
logical assertions rather than weakening them to round trips. Either move only
pure entropy tests into block_entropy.rs, or provide narrowly cfg(test) probe
helpers (committed tree view, pending-tree presence and a mutable sequence probe)
for the existing outer integration tests. Avoid making all fields generally
pub(crate) merely to satisfy test access. Golden's new committed-repeat getter
will remove one need for mutable probes, but emitted sequence-byte comparisons
remain a useful independent state witness.

The following existing selectors directly guard this extraction:

| Selector | Existing protection |
| --- | --- |
| encode::tests::sequence_state_is_published_only_for_accepted_blocks_and_reset_for_new_frames | Real unprofitable sequence candidate -> raw, RLE preservation, successful compressed publication, then resets; subsequent probe bytes distinguish state. |
| encode::tests::only_emitted_compressed_blocks_publish_pending_literal_tables | An eight-byte tie produces a genuinely new pending tree but raw emission preserves old tree; accepted sixteen-byte witness replaces it; RLE and resets handled. |
| encode::tests::search_storage_nondefault_shapes_preserve_literal_and_sequence_publication | Same meaningful transactions under all three policies and nondefault width/layout. |
| encode::tests::allocator_block_output_failure_keeps_prior_bytes_and_committed_history | Independent failing output owner preserves pointer/capacity/prior bytes, frame/ring counters and workspace allocator snapshot. |
| encode::tests::allocator_block_failed_dictionary_setup_requires_reset_after_seed_mutation | Failure after seed mutation preserves old attachment but requires reset; prevents claiming atomic whole setup. |
| encode::tests::allocator_block_every_setup_and_encode_failure_recovers_after_reset | Every observed setup/encode allocation for all policies, unchanged output prefix, retained-memory equality, recovery and final release. |
| encode::tests::allocator_block_all_strategies_keep_dictionary_workspace_and_output_domains_independent | Raw/prepared independent dictionaries; raw/RLE/compressed blocks; exact Global bytes and each allocator's accounting. |
| encode::tests::allocator_block_borrowed_nonclone_context_reuses_history_and_releases_shared_source | No unnecessary Clone bound and no additional dictionary ownership. |
| literal_encode::tests::distinct_allocator_domains_move_with_the_complete_context | Child allocator owners stay with literal buffers on move/reuse/drop. |
| sequence_context::tests::allocator_context_retains_every_slot_across_move_reset_and_discard | Six table slots/defaults and buffers retain capacity and exact owners. |
| sequence_context::tests::allocator_prepare_failure_sweeps_preserve_committed_state_and_release_candidates | Pending failure versus committed table/repeat state; retry and all allocation releases. |

Two bounded additions/strengthenings are enough rather than a new test family:

1. Add an empty-constructor identity witness in encode tests: zero attempts,
   identities_created==14, named literal id2, named sequence id6, payload id14
   (through a test-only observation), outer factory id1. Dropping releases all
   14 identities. Existing child tests guard their internal owner choices;
   code review verifies clone-parent graph. Borrowed &NonClone construction
   keeps one identity. Do not assert destruction event order, which the existing
   helper does not record and the extraction does not promise.
2. Strengthen the existing independent-output failure witness to observe
   committed repeats/tree as well as history. Its current first block exercises
   sequences; reuse the established sixteen-byte accepted Huffman witness from
   only_emitted_compressed_blocks_publish_pending_literal_tables when a real
   committed tree is needed. Assert the pending candidate is unavailable after
   failure and a reset/retry produces the same earlier bytes. This supplements,
   rather than replaces, the existing raw/RLE and fail-every-ordinal tests.

For parser-independent reconstruction, three direct aggregate cases suffice:
valid trailing literals, sum(LL)>literal bytes, and total regenerated mismatch.
Assert malformed reconstruction is rejected before any scratch allocation and
before publication. Reuse an existing warmed state to make preservation
observable. Do not write tests that merely reproduce all internal sums.

## Focused follow-up validation selectors (not run in this review)

Use owned isolated target directories and record source hashes before/after.
After focused aggregate and above allocator/publication tests, guard established
bytes with:

- `--lib encode::tests::allocator_one_shot_preserves_36_pre_migration_frames_and_original_output_owner`
- `--lib stream_encode::tests::allocator_stream_bytes_preserve_the_pre_migration_baseline`
  (the existing 108-frame fingerprint)
- `--test sequence_encoding` and `--test entropy_encoding`: independent wire
  mode/lifetime inspectors, prepared dictionary replacement, raw/RLE/zero-sequence
  preservation and fragmentation. No fixture or fingerprint regeneration.

Relevant optional C selectors already exist:
`encode::tests::official_codec_decodes_allocator_owned_blocks_with_borrowed_dictionaries`
(six complete raw/prepared dictionary frames),
`--test sequence_encoding official_decoder_accepts_public_sequence_modes_and_dictionary_lifetimes`, and
`entropy_encoding`'s `official_decoder_accepts_treeless_lifetimes_and_dictionary_replacement`.
Use the pinned CLI explicitly and preserve actual pass/frame counts separately.
The complete codec/backend matrix belongs to root's later milestone scope.

No current check is reported as passed by this read-only preflight. No new
unsafe backend is introduced; any focused Miri uses the existing child features
and the actual move/failure witnesses, not a synthetic unsafe aggregate.

## Review of the subsequent root extraction diff

After the preflight source reads, root published an uncommitted extraction in
block_entropy.rs, encode.rs and lib.rs. I reviewed that diff without running it.
The preceding constructor/ordering analysis refers to the original encode.rs
at the reviewed HEAD, whose source hash is recorded below; concurrent worktree
snapshots must not be confused with that baseline.

No concrete production ordering or ownership regression was found:

- new_in constructs the original children as locals in the exact original order
  and moves them via from_parts; no additional clone/factory was introduced.
- The original pre-seed Huffman validation remains in outer start_frame, and
  the new helper calls sequence setup before installing the literal table.
- discard before destination reserve, early uniform RLE, named match parsing,
  literal then sequence encoding, payload reserve/push, post-append commit and
  post-emission ring advancement retain their prior ordering.
- Capacity accounting regroups the same summands without excluding any owner.
- Every previous direct literal/sequence test access in the diff is redirected
  to the aggregate; the raw/RLE/accepted/reset assertions themselves remain.
- Field destruction interleaving changes as documented; no guarantee of exact
  drop order is implied, and each complete owner still holds its allocator.

The current neutral extraction intentionally preserves two old scratch details:
as_bytes may expose the retained previous payload after discard/reset, and a
later prepare error can leave a pending literal candidate. These are not a new
bug for the sole named caller, which never appends/commits after failure and
requires reset. They are also not the fully checked standalone candidate
contract proposed earlier: before the later Fast path uses this shared API,
add complete reconstruction validation and clear/guard candidate availability
on error/discard. Do not claim those strengthened behaviors were implemented
by this field-only extraction. Source eligibility remains outside the aggregate.

Root currently uses crate-visible table/context fields for the existing test
accesses. Narrow test hooks would reduce accidental production mutation surface,
but this is a maintainability refinement, not a discovered codec/ownership
regression. Keep the intended future Fast consumer on commit/discard/preparation
methods instead of directly writing those fields.

The narrowly independent constructor regression test can stay wholly in the
existing encode.rs test module without any child-field introspection:
TrackingAllocator starts at identity1; construct BlockEncoder; assert attempts0,
identities_created14, named literal allocator2, named sequence allocator6 and
outer factory1; drop it and assert owners_dropped14 plus assert_released. Existing
literal/context tests remain responsible for their internal identities.

An optional direct from_parts test may create literal/sequence/payload children
from three independent TrackingAllocator monitor domains of the same allocator
type, reserve the payload, capture its pointer and all monitor snapshots, then
assemble and move the aggregate. as_bytes().as_ptr() identifies the moved payload
storage; all three monitor snapshots must be unchanged by assembly. Drop and
assert complete release in all three domains. This detects an allocator clone
or hidden adoption during the new composition without exposing child internals
or implementing another unsafe allocator wrapper.

These are static review findings, not validation results. Root's isolated
archive excludes concurrent context edits and will provide the actual test
results. No file outside /tmp was edited by this review.

## Reviewed byte identities

HEAD at final review: `7c2e92826c3d732288cffaf3acc7ee8650a742b5`.

- Baseline HEAD `src/encode.rs`: `64b95cf0c649b0a4dd4ac08e7af0a05d39666c633a134db0085894d4f43085d9`
- Baseline HEAD `src/literal_encode.rs`: `471f440df7ca255460bb580fc7d67ae6f1a3ff91a38e0aebd6d7fdf45535dd78`
- Baseline HEAD `src/sequence_context.rs`: `e2979c4ba3ab89889c7f3345d7d226dbbdebc09f03e78b4735249ad7ff5491c6`
- Baseline HEAD `src/huffman_codebook.rs`: `e7f6c99f99b9ee16236ae3447eca02fe6a0db89c946a6d6ff890bb2d0e32c14b`
- Baseline HEAD `src/stream_encode.rs`: `2dce0e577d03aca28796f7b724202a92ac73106c5d57561ca5d625dbc3842d9e`
- Baseline HEAD `tests/sequence_encoding.rs`: `329584f30c245b1eac55ab542880a36ae39b9e7497081030be7267c023bf2975`
- Baseline HEAD `tests/entropy_encoding.rs`: `68743c447c861d6a97afaa07c935e9bbf9f65afa31e55c4bf29aee9ecd9c4708`
- Baseline HEAD `test-support/allocator/src/lib.rs`: `41c8b8c7b1508691fac5c43e4a599e2b24a2f6215b6dfb8641e190cb342a8971`

Actual worktree files read for the subsequent diff review:

- `src/encode.rs`: `af7c60385e4fe181994dadd1972bbc8acace7f07e1600af34d0a3f6e281ede91`
- `src/block_entropy.rs`: `63aaa7a339c4571f244dc5ad4b2b8ebc0b202481ebee2447b01fa18828c2ab18`
- `src/lib.rs`: `a27c63009fce7063d249ec504b264f02fd30635078f559e765401d756eb2e86f`
- `src/sequence_context.rs`: `5824fea99f85b3cc1c63a62bb68f79873d1e3818af487b7107cf1bdda5f9c81c`
