"""Append only the 12 individual-feature smoke runs after verified safe/all.

No benchmark source changes; archive the original two-backend checkpoint first.
Actual final order is safe, all, then the 12 declared individual features.
"""
from pathlib import Path
import importlib.util,json,shutil,subprocess
root=Path('/Users/lanxingcan/Workspace/zstdoxize')
output=Path('/tmp/zstdoxide-module11-search-smoke-final').resolve()
checkpoint=Path('/tmp/zstdoxide-module11-search-smoke-safe-all-checkpoint').resolve()
spec=importlib.util.spec_from_file_location('driver',root/'scripts/benchmark_search.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
source=m.load_json(output/'source.json');inputs=m.load_json(output/'inputs.json');environment=m.load_json(output/'environment.json');commands=m.load_json(output/'commands.json')
m.require(environment['configuration_order']==['safe','all'] and environment['timed'] is False,'Expected final-source safe/all smoke checkpoint')
m.require(m.exact(m.source_manifest(root),source),'Source differs from initial safe/all checkpoint')
m.require(m.exact(m.corpus_manifest((root/m.FIXTURE).read_bytes()),inputs),'Input pins differ')
m.validate_environment(environment,root,['safe','all'],environment['toolchain'],False,environment['samples'],environment['minimum_ms'])
paths=m.validate_command_records(commands,root,output,source,environment)
results={name:m.parse_results(paths[name],name,False,inputs,environment['samples'],environment['minimum_ms']) for name in ['safe','all']}
m.compare(results['safe'],results['all'],'all')
m.require(m.exact(m.result_document(source,False,results),m.load_json(output/'results.json')),'Existing aggregate differs')
m.require(not checkpoint.exists(),'Preserve prior checkpoint')
checkpoint.mkdir()
for path in output.iterdir():
 if path.is_file():shutil.copy2(path,checkpoint/path.name)
 elif path.name=='reproduction':shutil.copytree(path,checkpoint/path.name)
environment['configuration_order']=['safe','all',*m.FEATURES]
(output/'environment.json').write_text(json.dumps(environment,indent=2)+'\n')
def unchanged():
 m.require(m.exact(m.source_manifest(root),source),'Frozen source/input changed')
 m.require(m.exact(m.cargo_config_manifest(root,environment['base_environment']),environment['cargo_configs']),'Cargo configs changed')
for configuration in m.FEATURES:
 unchanged()
 build,build_env,target=m.build_command(root,output,configuration,environment['toolchain'],environment['host_target'],environment['base_environment'])
 artifacts=output/(configuration+'.build.jsonl');build_log=output/(configuration+'.build.log')
 with artifacts.open('w') as stdout,build_log.open('w') as stderr:
  result=subprocess.run(build,cwd=root,env=build_env,stdout=stdout,stderr=stderr,check=False)
 commands.append({'stage':'build','backend':configuration,'command':build,'cwd':str(root),'environment':build_env,'exit_code':result.returncode,'stdout':artifacts.name,'stdout_sha256':m.sha(artifacts),'stderr':build_log.name,'stderr_sha256':m.sha(build_log),'source_sha256':source['sha256']})
 (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 m.require(result.returncode==0,f'Build failed: {configuration}')
 unchanged()
 executable=m.executable_from_artifacts(artifacts,target);m.require(executable.is_file(),'Missing executable');exe_sha=m.sha(executable)
 path=output/(configuration+'.jsonl');run_log=output/(configuration+'.run.log');run_env=m.run_environment(environment)
 m.require(run_env['ZSTDOXIDE_SEARCH_BENCH_TIMED']=='0','Timing forbidden in smoke campaign')
 print('Clock-free individual smoke: '+configuration,flush=True)
 unchanged()
 with path.open('w') as stdout,run_log.open('w') as stderr:
  result=subprocess.run([str(executable)],cwd=root,env=run_env,stdout=stdout,stderr=stderr,check=False)
 commands.append({'stage':'run','backend':configuration,'command':[str(executable)],'cwd':str(root),'environment':run_env,'executable_sha256':exe_sha,'exit_code':result.returncode,'stdout':path.name,'stdout_sha256':m.sha(path),'stderr':run_log.name,'stderr_sha256':m.sha(run_log),'source_sha256':source['sha256']})
 (output/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 m.require(result.returncode==0,f'Smoke failed: {configuration}')
 m.require(m.sha(executable)==exe_sha,'Executable changed during run')
 unchanged()
 results[configuration]=m.parse_results(path,configuration,False,inputs,environment['samples'],environment['minimum_ms'])
 m.compare(results['safe'],results[configuration],configuration)
m.validate_environment(environment,root,environment['configuration_order'],environment['toolchain'],False,environment['samples'],environment['minimum_ms'])
m.validate_command_records(commands,root,output,source,environment)
(output/'results.json').write_text(json.dumps(m.result_document(source,False,results),indent=2)+'\n')
m.write_report(output,results,False)
unchanged()
print('Complete: 14 configurations, 378 rows; exact non-timing equivalence; no timed samples',flush=True)
