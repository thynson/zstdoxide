from pathlib import Path
import os,json,subprocess,hashlib,time
root=Path('/Users/lanxingcan/Workspace/zstdoxize');base=Path('/tmp/zstdoxide-module11-search-quality');base.mkdir(exist_ok=True)
env=os.environ | {'CARGO_TARGET_DIR':'/tmp/zstdoxide-module11-search-clippy-target','CARGO_TERM_COLOR':'never'}
commands=[('clippy-safe',['cargo','clippy','--locked','--bench','search','--','-D','warnings']),('clippy-all',['cargo','clippy','--locked','--bench','search','--all-features','--','-D','warnings']),('format',['rustfmt','+nightly-2026-10-08','--edition','2024','--check','benches/search.rs']),('python-syntax',['python3','-c',"import ast,pathlib;ast.parse(pathlib.Path('scripts/benchmark_search.py').read_text());ast.parse(pathlib.Path('/tmp/zstdoxide-search-benchmark-negative.py').read_text())"]),('diff-check',['git','diff','--check','--','benches/search.rs','scripts/benchmark_search.py'])]
records=[]
for name,command in commands:
 path=base/(name+'.log');start=time.monotonic()
 with path.open('wb') as out:r=subprocess.run(command,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 record={'name':name,'command':command,'environment':{k:env[k] for k in ('CARGO_TARGET_DIR','CARGO_TERM_COLOR')},'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()};records.append(record)
 (base/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise RuntimeError(path.read_text())
