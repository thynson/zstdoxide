#!/usr/bin/env python3
"""Reject altered search evidence under normal and optimized Python.

Run only after the repaired harness has produced a verified clock-free campaign.
This program never builds or runs a Rust executable. Full-validator cases copy
only archived text artifacts, preserving the original campaign. Separate timed
parser fixtures contain synthetic durations and are explicitly NOT measurements.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def import_driver(path):
    spec = importlib.util.spec_from_file_location("search_driver", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def update_rows(directory, backend, mutate):
    path = directory / (backend + ".jsonl")
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    mutate(rows)
    path.write_text("\n".join(json.dumps(row) for row in rows) + "\n")
    update_result_hash(directory, backend)


def update_result_hash(directory, backend):
    path = directory / (backend + ".jsonl")
    records = read(directory / "commands.json")
    for record in records:
        if record["backend"] == backend and record["stage"] == "run":
            record["stdout_sha256"] = sha(path)
    write(directory / "commands.json", records)


def command_mutation(directory, mutate):
    path = directory / "commands.json"
    value = read(path)
    mutate(value)
    write(path, value)


def environment_mutation(directory, mutate):
    path = directory / "environment.json"
    value = read(path)
    mutate(value)
    write(path, value)


def first_case(rows):
    return next(row for row in rows if row["record"] == "case")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("campaign", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--driver", required=True, type=Path)
    args = parser.parse_args()
    campaign = args.campaign.resolve()
    output = args.output.resolve()
    driver_path = args.driver.resolve()
    require(campaign.is_dir() and not output.exists(), "Require an existing campaign and a fresh output directory")
    environment = read(campaign / "environment.json")
    require(environment["timed"] is False, "Use a real clock-free smoke campaign for negative fixtures")
    configurations = environment["configuration_order"]
    require(len(configurations) >= 2 and configurations[0] == "safe", "Use at least safe plus another backend")
    second = configurations[1]
    files = [path for path in campaign.iterdir() if path.is_file()]
    require(sum(path.stat().st_size for path in files) <= 32 * 1024 * 1024,
            "Bound negative fixture base to 32 MiB of archived text artifacts")
    output.mkdir()
    module = import_driver(driver_path)
    results = []

    def prepare(name, mutation):
        directory = output / name
        directory.mkdir()
        for path in files:
            shutil.copyfile(path, directory / path.name)
        mutation(directory)
        return directory

    def invoke(name, directory, expected, optimized=False, timed_parser=False):
        command = [sys.executable] + (["-O"] if optimized else [])
        if timed_parser:
            code = (
                "import importlib.util,pathlib,sys;"
                "s=importlib.util.spec_from_file_location('driver',sys.argv[1]);"
                "m=importlib.util.module_from_spec(s);s.loader.exec_module(m);"
                "m.parse_results(pathlib.Path(sys.argv[2]),'safe',True,"
                "m.load_json(pathlib.Path(sys.argv[3])),6,int(sys.argv[4]))"
            )
            command += ["-c", code, str(driver_path), str(directory / "safe.jsonl"),
                        str(directory / "inputs.json"), str(environment["minimum_ms"])]
        else:
            command += [str(driver_path), str(directory), "--root", str(args.root.resolve()),
                "--validate-only", "--configs", ",".join(configurations),
                "--toolchain", environment["toolchain"], "--samples", str(environment["samples"]),
                "--minimum-ms", str(environment["minimum_ms"])]
        result = subprocess.run(command, text=True, capture_output=True, check=False)
        suffix = "optimized" if optimized else "normal"
        stdout = output / (name + "." + suffix + ".stdout")
        stderr = output / (name + "." + suffix + ".stderr")
        stdout.write_text(result.stdout)
        stderr.write_text(result.stderr)
        accepted = result.returncode == 0
        require(accepted == (expected is None), f"Unexpected acceptance for {name}/{suffix}: {result.stderr}")
        if expected is not None:
            require(expected in result.stderr, f"Wrong rejection gate for {name}/{suffix}: {result.stderr}")
        results.append({"case": name, "optimized_python": optimized, "synthetic_timed_parser": timed_parser,
            "expected": "accept" if expected is None else expected, "command": command,
            "exit_code": result.returncode, "stdout": str(stdout), "stdout_sha256": sha(stdout),
            "stderr": str(stderr), "stderr_sha256": sha(stderr)})
        write(output / "results.json", {"schema_version": 1, "driver_sha256": sha(driver_path),
            "runner_sha256": sha(__file__), "source_campaign": str(campaign), "checks": results})

    def both(name, mutation, expected, timed_parser=False):
        directory = prepare(name, mutation)
        for optimized in (False, True):
            invoke(name, directory, expected, optimized, timed_parser)

    both("unaltered-smoke", lambda directory: None, None)

    def detached(directory):
        # Both files are valid and have the same hash. Only canonical association
        # can reject this; hash-only validation would accept the redirection.
        shutil.copyfile(directory / "safe.jsonl", directory / "detached.jsonl")
        command_mutation(directory, lambda records: records[1].update(stdout="detached.jsonl"))
    both("detached-run-stdout", detached, "canonical result")
    both("noncanonical-equivalent-stdout", lambda d: command_mutation(d,
        lambda records: records[1].update(stdout="./safe.jsonl")), "canonical result")
    both("missing-backend-command", lambda d: command_mutation(d, lambda records: records.pop()),
         "ordered successful build and run")
    both("duplicate-backend-command", lambda d: command_mutation(d, lambda records: records.append(copy.deepcopy(records[0]))),
         "ordered successful build and run")
    both("omitted-command-field", lambda d: command_mutation(d, lambda records: records[0].pop("environment")),
         "Command evidence schema")
    both("bool-exit-code", lambda d: command_mutation(d, lambda records: records[0].update(exit_code=False)),
         "Stored command/source evidence")
    both("altered-build-command", lambda d: command_mutation(d, lambda records: records[0]["command"].append("--all-features")),
         "Build command/effective environment")
    both("altered-build-environment", lambda d: command_mutation(d, lambda records: records[0]["environment"].update(RUSTFLAGS="-Copt-level=0")),
         "Build command/effective environment")
    both("altered-run-sample-setting", lambda d: command_mutation(d, lambda records: records[1]["environment"].update(ZSTDOXIDE_SEARCH_BENCH_SAMPLES="99")),
         "Run command/effective environment")
    both("uncontrolled-parent-environment", lambda d: environment_mutation(d, lambda env: env["base_environment"].update(RUSTC_BOOTSTRAP="1")),
         "Uncontrolled effective environment")
    both("wrong-recorded-configuration-order", lambda d: environment_mutation(d, lambda env: env["configuration_order"].reverse()),
         "Environment configuration/mode/sample")
    both("wrong-compiler-host", lambda d: environment_mutation(d, lambda env: env.update(host_target="unrelated-target")),
         "Compiler host/explicit target")
    both("missing-row", lambda d: update_rows(d, "safe", lambda rows: rows.pop()), "Incomplete 27-row matrix")
    both("duplicate-row", lambda d: update_rows(d, "safe", lambda rows: rows.append(copy.deepcopy(first_case(rows)))),
         "Unknown/duplicate row")
    both("omitted-feature-metadata", lambda d: update_rows(d, second, lambda rows: rows[0].pop("features")),
         "Metadata keys")
    both("wrong-feature-metadata", lambda d: update_rows(d, second, lambda rows: rows[0].update(features=["safe"])),
         "Metadata/scalars/features differ")
    both("missing-row-scalar", lambda d: update_rows(d, "safe", lambda rows: first_case(rows).pop("output_chunk")),
         "Case schema")
    both("changed-search-option", lambda d: update_rows(d, "safe", lambda rows: first_case(rows)["search"].update(history_bytes=17)),
         "Complete options")
    both("changed-source-identity", lambda d: update_rows(d, "safe", lambda rows: first_case(rows).update(source_fnv1a64="0" * 16)),
         "Independent source/dictionary identity")
    def changed_all(directory):
        for backend in configurations:
            update_rows(directory, backend, lambda rows: [row.update(source_fnv1a64="0" * 16)
                for row in rows if row.get("workload") == "block"])
    both("same-wrong-source-in-all-backends", changed_all, "Independent source/dictionary identity")
    both("bool-source-length", lambda d: update_rows(d, "safe", lambda rows: first_case(rows).update(source_bytes=True)),
         "Schedule/scalar mismatch")
    both("unbalanced-final-owner", lambda d: update_rows(d, "safe", lambda rows:
        first_case(rows)["allocation_survey"]["final_drop"].update(owners_dropped=0)), "Incomplete release")
    both("owner-violation", lambda d: update_rows(d, "safe", lambda rows:
        first_case(rows)["allocation_survey"]["cold"].update(violations=True)), "Owner violation")
    both("smoke-with-timing", lambda d: update_rows(d, "safe", lambda rows: first_case(rows).update(timing={})),
         "Smoke started timing")
    def duplicate_json_field(directory):
        path = directory / "safe.jsonl"
        original = path.read_text()
        changed = original.replace('"schema_version":', '"schema_version":9,"schema_version":', 1)
        require(changed != original, "Duplicate-field mutation did not change its fixture")
        path.write_text(changed)
        update_result_hash(directory, "safe")
    both("duplicate-json-field", duplicate_json_field, "Duplicate JSON field")
    def omitted_aggregate(directory):
        value = read(directory / "results.json")
        value["configurations"].pop(second)
        write(directory / "results.json", value)
    both("omitted-aggregate-backend", omitted_aggregate, "Aggregated results/configurations differ")
    def altered_input_manifest(directory):
        value = read(directory / "inputs.json")
        value["workloads"]["block"]["source_fnv1a64"] = "0" * 16
        write(directory / "inputs.json", value)
    both("altered-independent-input-manifest", altered_input_manifest, "Independent input manifest differs")

    def synthetic_timed(directory):
        path = directory / "safe.jsonl"
        rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        rows[0]["samples"] = 6
        for row in rows[1:]:
            row["mode"] = "timed"
            row["samples"] = [{"iterations": 1, "elapsed_ns": environment["minimum_ms"] * 1_000_000 * factor}
                              for factor in (1, 2, 3, 5, 7, 11)]
            costs = [sample["elapsed_ns"] / row["source_bytes"] for sample in row["samples"]]
            rates = [1e9 / (cost * 1048576) for cost in costs]
            row["timing"] = dict(zip(("minimum_ns_per_byte", "median_ns_per_byte", "maximum_ns_per_byte"),
                (min(costs), module.statistics.median(costs), max(costs))))
            row["timing"].update(dict(zip(("minimum_mib_per_second", "median_mib_per_second", "maximum_mib_per_second"),
                (min(rates), module.statistics.median(rates), max(rates)))))
        path.write_text("\n".join(json.dumps(row) for row in rows) + "\n")
    both("synthetic-six-sample-control", synthetic_timed, None, timed_parser=True)
    def wrong_median(directory):
        synthetic_timed(directory)
        update_rows(directory, "safe", lambda rows: first_case(rows)["timing"].update(
            median_mib_per_second=1e9 / (first_case(rows)["timing"]["median_ns_per_byte"] * 1048576)))
    both("synthetic-reciprocal-median", wrong_median, "Timing summary", timed_parser=True)
    def missing_sample(directory):
        synthetic_timed(directory)
        update_rows(directory, "safe", lambda rows: first_case(rows)["samples"].pop())
    both("synthetic-missing-sample", missing_sample, "Incomplete samples", timed_parser=True)
    def zero_iterations(directory):
        synthetic_timed(directory)
        update_rows(directory, "safe", lambda rows: first_case(rows)["samples"][0].update(iterations=0))
    both("synthetic-zero-iterations", zero_iterations, "Sample bound", timed_parser=True)
    def infinite_timing(directory):
        synthetic_timed(directory)
        update_rows(directory, "safe", lambda rows: first_case(rows)["timing"].update(median_ns_per_byte=float("inf")))
    both("synthetic-infinite-timing", infinite_timing, "Non-JSON constant", timed_parser=True)
    print(f"Validated {len(results)} parser/control checks without building or timing Rust: {output}")


if __name__ == "__main__":
    main()
