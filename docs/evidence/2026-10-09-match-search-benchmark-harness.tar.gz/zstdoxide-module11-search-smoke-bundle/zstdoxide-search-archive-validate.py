from pathlib import Path
import json,subprocess,sys,hashlib
root=Path('/Users/lanxingcan/Workspace/zstdoxize');output=Path('/tmp/zstdoxide-module11-search-smoke-final');environment=json.loads((output/'environment.json').read_text());records=[]
for optimized in [False,True]:
 command=[sys.executable]+(['-O'] if optimized else [])+[str(root/'scripts/benchmark_search.py'),str(output),'--root',str(root),'--configs',','.join(environment['configuration_order']),'--samples',str(environment['samples']),'--minimum-ms',str(environment['minimum_ms']),'--toolchain',environment['toolchain'],'--validate-only']
 path=Path('/tmp/zstdoxide-module11-search-archive-'+('optimized' if optimized else 'normal')+'.log')
 with path.open('wb') as out:r=subprocess.run(command,cwd=root,stdout=out,stderr=subprocess.STDOUT)
 records.append({'command':command,'exit_code':r.returncode,'log':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 Path('/tmp/zstdoxide-module11-search-archive-validation.json').write_text(json.dumps(records,indent=2)+'\n')
 print('optimized',optimized,'exit',r.returncode,flush=True)
 if r.returncode:raise RuntimeError(path.read_text())
