from pathlib import Path
import hashlib,json,os,re,subprocess,time
out=Path('/tmp/zstdoxide-upstream-reference-fast-checkpoint');work=out/'source';p=out/'evidence.json';v=json.loads(p.read_text());env=dict(os.environ);env.update(CARGO_TARGET_DIR=str(out/'target'),CARGO_TERM_COLOR='never')
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET']:env.pop(key,None)
for flag in ['unsafe-bitstream','unsafe-fse-encoder','unsafe-huffman-codebook']:
 argv=['cargo','test','--offline','--locked','--test','upstream_reference_fast','--features',flag];start=time.monotonic();r=subprocess.run(argv,cwd=work,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180);log=out/('test-'+flag+'.log');log.write_bytes(r.stdout);counts=[list(map(int,a)) for a in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',r.stdout)]
 v['commands'].append({'label':'test-'+flag,'argv':argv,'cwd':str(work),'environment':{'CARGO_TARGET_DIR':str(out/'target'),'CARGO_TERM_COLOR':'never'},'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'test_counts':counts});p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
 if r.returncode or counts!=[[9,0,0,0,0]]:raise RuntimeError(flag)
 print(flag,'9 passed',flush=True)
after={str(x.relative_to(work)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(work.rglob('*')) if x.is_file()}
if v['source_before']!=after:raise RuntimeError('source mutation')
v['source_after']=after;p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');print(hashlib.sha256(p.read_bytes()).hexdigest())
