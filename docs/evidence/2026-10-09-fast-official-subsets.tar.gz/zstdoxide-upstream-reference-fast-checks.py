from pathlib import Path
import hashlib,io,json,os,re,shutil,subprocess,tarfile,time
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-upstream-reference-fast-checkpoint');OUT.mkdir();WORK=OUT/'source';WORK.mkdir();TARGET=OUT/'target'
base=subprocess.check_output(['git','rev-parse','30d0caf'],cwd=ROOT,text=True).strip();archive=subprocess.check_output(['git','archive',base],cwd=ROOT)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(WORK,filter='data')
owned='tests/upstream_reference_fast.rs';shutil.copy(ROOT/owned,WORK/owned)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source():return {str(p.relative_to(WORK)):sha(p) for p in sorted(WORK.rglob('*')) if p.is_file()}
before=source();env=dict(os.environ);env.update(CARGO_TARGET_DIR=str(TARGET),CARGO_TERM_COLOR='never')
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET']:env.pop(key,None)
evidence={'base':base,'owned_sha256':sha(ROOT/owned),'source_before':before,'source_after':None,'commands':[],'scope':'Four original-source adapted tests plus five existing producer tests. Each codec run executes126 frame encodes,62 exact Rust decodes,96 explicit UnsupportedFeature results and records4 unexecuted advanced branches. No new C process or caller-buffer/context/in-place claim.'}
def run(label,argv,count=None):
 start=time.monotonic();p=subprocess.run(argv,cwd=WORK,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180);log=OUT/(label+'.log');log.write_bytes(p.stdout);row={'label':label,'argv':argv,'cwd':str(WORK),'environment':{'CARGO_TARGET_DIR':str(TARGET),'CARGO_TERM_COLOR':'never'},'exit_code':p.returncode,'seconds':time.monotonic()-start,'log':str(log),'log_sha256':sha(log)}
 if count is not None:
  found=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',p.stdout)
  row['test_counts']=[list(map(int,x)) for x in found]
  if row['test_counts']!=[[count,0,0,0,0]]:row['unexpected_counts']=True
 evidence['commands'].append(row);(OUT/'evidence.json').write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n');print(label,p.returncode,flush=True)
 if p.returncode or row.get('unexpected_counts'):raise RuntimeError(label)
run('rustc',['rustc','-Vv']);run('cargo',['cargo','-V'])
for name,flags in [('safe',[]),('match-table',['--features','unsafe-match-table']),('all',['--all-features']),('no-std',['--no-default-features']),('no-std-all',['--no-default-features','--all-features'])]:
 # --all-features also enables std; use explicit unsafe list for true no_std-all.
 if name=='no-std-all':flags=['--no-default-features','--features',','.join(['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-dictionary','unsafe-training'])]
 run('test-'+name,['cargo','test','--offline','--locked','--test','upstream_reference_fast',*flags],9)
 if name in ('no-std','no-std-all'):run('check-'+name,['cargo','check','--offline','--locked','--lib',*flags])
for name,flags in [('safe',[]),('all',['--all-features'])]:run('clippy-'+name,['cargo','clippy','--offline','--locked','--test','upstream_reference_fast',*flags,'--','-D','warnings'])
run('format',['rustfmt','--check','--edition','2024','--config','skip_children=true',owned])
after=source();evidence['source_after']=after;evidence['source_unchanged']=before==after;evidence['owned_workspace_unchanged']=sha(ROOT/owned)==evidence['owned_sha256'];evidence['status']='passed';
if not evidence['source_unchanged'] or not evidence['owned_workspace_unchanged']:raise RuntimeError('source mutation')
(OUT/'evidence.json').write_text(json.dumps(evidence,sort_keys=True,indent=2)+'\n');print('PASS',sha(OUT/'evidence.json'))
