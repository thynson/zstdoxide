from pathlib import Path
import hashlib,json,os,re,subprocess,tarfile,time,io
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize'); BASE='45c332198e8f6e1ae00ae5e8c93d24de25510c5b'; OUT=Path('/tmp/zstdoxide-fast-frame-trajectory-checkpoint'); SNAP=OUT/'source'
OUT.mkdir(exist_ok=False); SNAP.mkdir()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
archive=subprocess.check_output(['git','archive',BASE],cwd=ROOT)
with tarfile.open(fileobj=io.BytesIO(archive)) as t:t.extractall(SNAP,filter='data')
owned=['scripts/pack_fast_frame_trajectories.py','tests/support/fast_frame_oracle.rs',*[str(p.relative_to(ROOT)) for p in (ROOT/'tests/fixtures/reference-fast-frames').iterdir() if p.is_file()]]
for relative in owned:
 p=SNAP/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/relative).read_bytes())
lib=SNAP/'src/lib.rs'; text=lib.read_text(); declaration='#[cfg(test)]\n#[path = "../tests/support/fast_frame_oracle.rs"]\nmod fast_frame_oracle_fixture;\n'
if 'mod fast_frame_oracle_fixture;' not in text:lib.write_text(text+'\n'+declaration)
tracked=[p for p in SNAP.rglob('*') if p.is_file()]
before={str(p.relative_to(SNAP)):sha(p) for p in tracked}
unsafe=['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-dictionary','unsafe-training']
commands=[]
for name,flags in [('safe',[]),('all',['--all-features']),('no-std',['--no-default-features']),('no-std-all',['--no-default-features','--features',','.join(unsafe)])]:
 commands.append(('test-'+name,['cargo','test','--offline','--locked','--lib',*flags,'fast_frame_oracle_fixture::tests::','--','--test-threads=1'],4))
for name,flags in [('safe',[]),('all',['--all-features'])]:commands.append(('clippy-'+name,['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'],None))
for name,argv in [('format',['rustfmt','--edition','2024','--config','skip_children=true','--check','tests/support/fast_frame_oracle.rs']),('pack-check',['python3','scripts/pack_fast_frame_trajectories.py','--check']),('pack-check-optimized',['python3','-O','scripts/pack_fast_frame_trajectories.py','--check'])]:commands.append((name,argv,None))
env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(OUT/'target'),CARGO_TERM_COLOR='never')
result={'base_commit':BASE,'snapshot':str(SNAP),'owned_sha256':{p:sha(ROOT/p) for p in owned},'snapshot_before_sha256':before,'commands':[],'status':'running','qualifications':['Derived ordinary C trajectories only; no new C invocation or compressed decoding.','Header-only cases excluded; raw C third distinct from semantic wire third.']}
(OUT/'rustc.txt').write_bytes(subprocess.check_output(['rustc','-Vv'],cwd=SNAP,env=env))
def save():(OUT/'evidence.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
save()
for name,argv,expected in commands:
 start=time.monotonic();log=OUT/(name+'.log')
 with log.open('wb') as f:completed=subprocess.run(argv,cwd=SNAP,env=env,stdout=f,stderr=subprocess.STDOUT)
 record={'name':name,'argv':argv,'cwd':str(SNAP),'environment':{'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR'],'CARGO_TERM_COLOR':'never'},'exit_code':completed.returncode,'elapsed_seconds':time.monotonic()-start,'log':log.name,'log_sha256':sha(log)}
 if expected is not None:
  matches=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',log.read_text()); record['test_summaries']=[dict(zip(('passed','failed','ignored','measured','filtered'),map(int,m))) for m in matches];record['expected_count_satisfied']=len(matches)==1 and tuple(map(int,matches[0][:4]))==(expected,0,0,0)
 result['commands'].append(record);save();print(name,record['exit_code'],record.get('test_summaries',''),flush=True)
 if completed.returncode or expected is not None and not record['expected_count_satisfied']: result['status']='failed';save();raise SystemExit(1)
after={str(p.relative_to(SNAP)):sha(p) for p in tracked};result['snapshot_after_sha256']=after;result['snapshot_unchanged']=before==after;result['owned_unchanged']=all(sha(ROOT/p)==h for p,h in result['owned_sha256'].items());result['status']='passed' if result['snapshot_unchanged'] and result['owned_unchanged'] else 'failed';save();print(result['status'],sha(OUT/'evidence.json'))
