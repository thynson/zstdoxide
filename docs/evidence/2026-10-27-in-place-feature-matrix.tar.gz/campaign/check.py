from pathlib import Path
import os,subprocess,json,hashlib,time,datetime,tomllib,re,signal
D=Path(__file__).parent;S=Path('/private/tmp/module28-candidate');R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();deadline=datetime.datetime(2026,10,27,8,32,32,tzinfo=datetime.timezone.utc).timestamp()
assert json.loads((R/'docs/evidence/2026-10-26-stable-prefix-output-closure.json').read_text())['status']=='passed'
assert json.loads(Path('/private/tmp/module28-session-archives/promotion-state.json').read_text())['stage']=='platform'
assert all((S/n).read_bytes()==(R/n).read_bytes() for folder in ['src','tests','test-support'] for q in (S/folder).rglob('*') if q.is_file() for n in [q.relative_to(S)])
source={str(q.relative_to(S)):sha(q) for folder in ['src','tests','test-support'] for q in (S/folder).rglob('*') if q.is_file()};source.update({n:sha(S/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']})
features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'));assert len(features)==21
plan=[]
for name,flags,no in [('safe',[],[]),('all',['--all-features'],['--features',','.join(features)]),*[(n,['--features',n],['--features',n]) for n in features]]:
 plan += [(name+'-full',['cargo','test','--offline','--locked',*flags]),(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*no]),(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])]
plan += [('safe-release',['cargo','test','--offline','--locked','--release']),('all-release',['cargo','test','--offline','--locked','--release','--all-features']),('format',['cargo','fmt','--all','--','--check'])];assert len(plan)==72
assert not (D/'evidence.json').exists()
e=dict(status='running',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),deadline_utc=datetime.datetime.fromtimestamp(deadline,datetime.timezone.utc).isoformat(),features=features,source=source,commands=[],plan=plan)
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module28-public-target','CARGO_BUILD_JOBS':'6','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for label,args in plan:
  remaining=deadline-time.time()-30
  if remaining<30:raise TimeoutError('User work window reached before '+label)
  start=time.monotonic()
  with (D/(label+'.log')).open('xb') as f:
   p=subprocess.Popen(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=remaining)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise TimeoutError('User work window reached during '+label)
  row=dict(label=label,argv=args,exit_code=code,seconds=time.monotonic()-start,log_sha256=sha(D/(label+'.log')))
  if label.endswith(('-full','-release')) and code==0:
   g=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (D/(label+'.log')).read_text());assert all(int(f)==0 for _,f,_ in g)
   counts=(len(g),sum(int(a) for a,_,_ in g),sum(int(i) for _,_,i in g));assert counts==(94,1661,63),(label,counts)
   row.update(result_groups=counts[0],passed=counts[1],ignored=counts[2])
  e['commands'].append(row);save();print(label,code,flush=True);assert code==0,label
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed',finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except TimeoutError as ex:e.update(status='interrupted-at-user-deadline',error=repr(ex));save();raise
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
