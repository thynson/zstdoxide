from pathlib import Path
import json,hashlib,tarfile,datetime
D=Path(__file__).parent;E=Path('/private/tmp/module28-session-archives');R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records={n:json.loads((D/n).read_text()) for n in ['preparation.json','capture.json','build.json','originals.json','replay.json']}
for n,j in records.items():
 assert j['status']==('prepared' if n=='preparation.json' else 'passed'),n
 for c in j.get('commands',[]):assert c['exit_code']==0,(n,c)
assert sha(D/'normal-cn-buffer.bin')==sha(D/'sanitized-cn-buffer.bin')==records['capture.json']['exact_input_sha256']
assert records['preparation.json']['instrumented_fuzzer_sha256']==sha(D/'fuzzer-capture.c')
assert records['preparation.json']['patch_sha256']==sha(D/'capture.patch')
assert sha(D/'normal/original-1.raw')==sha(D/'normal-cn-buffer.bin')
production={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')}
for n,h in production.items():assert records['replay.json']['source'][n]==h,n
files={'LICENSE.zstd':R/'LICENSE.zstd'}
for p in D.iterdir():
 if not p.is_file() or p.name=='fuzzer-capture.c':continue
 if p.suffix in ['.json','.log','.tsv','.stderr','.py','.patch','.c'] or p.name in ['capture-normal','capture-sanitized','oracle-normal','oracle-sanitized']:files['campaign/'+p.name]=p
payloads={}
for folder in ['normal','sanitized']:
 for p in (D/folder).iterdir():
  digest=sha(p);payloads[str(p.relative_to(D))]=digest;files.setdefault('payloads/'+digest,p)
for p in [D/'normal-cn-buffer.bin',D/'sanitized-cn-buffer.bin']:
 digest=sha(p);payloads[p.name]=digest;files.setdefault('payloads/'+digest,p)
for p in (D/'replay-source').rglob('*'):
 if p.is_file() and p.suffix in ['.rs','.toml','.lock']:files['rust-source/'+str(p.relative_to(D/'replay-source'))]=p
name='2026-10-27-in-place-native-exact-history';archive=E/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
j=dict(status='passed',recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,records=records,payloads=payloads,members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in sorted(files.items())},archive=archive.name,archive_sha256=sha(archive),supersedes_original_input_claim_in='2026-10-27-in-place-native.json',qualification='The older isolated initial-RDG recipe is preserved as supplemental evidence. This receipt alone establishes exact original input history: unmodified preceding upstream assertions/mutations execute before an inserted capture at line 1344, normal/sanitized 5 MiB snapshots agree, and original single/two-frame layouts/assertions replay against those bytes in both native modes and five Rust configurations. Downloaded reference source remains outside Git; its hash and the observation-only patch reconstruct the captured executable. The 1300 earlier supplemental layouts are reused without relabelling their input history.')
(E/(name+'.json')).write_text(json.dumps(j,indent=2)+'\n');print(name,archive.stat().st_size)
