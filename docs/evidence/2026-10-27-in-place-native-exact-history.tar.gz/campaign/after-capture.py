from pathlib import Path
import subprocess,hashlib,json,time,os,shutil
D=Path(__file__).parent;P=Path('/private/tmp/module28-native');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for receipt in ['capture.json','build.json']:
 while True:
  if (D/receipt).exists():
   try:j=json.loads((D/receipt).read_text())
   except json.JSONDecodeError:time.sleep(1);continue
   assert j['status'] in ['running','passed'],(receipt,j.get('error'))
   if j['status']=='passed':break
  time.sleep(5)
e=dict(status='running',capture_receipt_sha256=sha(D/'capture.json'),build_receipt_sha256=sha(D/'build.json'),commands=[])
def save():(D/'originals.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name in ['normal','sanitized']:
  O=D/name;O.mkdir();args=[str(D/('oracle-'+name)),'originals',str(O)];t=time.monotonic();p=subprocess.run(args,capture_output=True,env={**os.environ,'ZSTDOXIDE_EXACT_CNBUFFER':str(D/(name+'-cn-buffer.bin')),'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
  (D/(name+'-originals.tsv')).write_bytes(p.stdout);(D/(name+'-originals.stderr')).write_bytes(p.stderr);e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t));save();assert p.returncode==0,(name,p.stderr)
 for p in (D/'normal').iterdir():assert sha(p)==sha(D/'sanitized'/p.name)
 assert sha(D/'normal-cn-buffer.bin')==sha(D/'normal/original-1.raw')
 assert sha(D/'normal/original-1.raw')!=sha(P/'normal/original-1.raw'),'The earlier isolated recipe should differ from original execution state'
 assert (D/'normal-originals.tsv').read_bytes()==(D/'sanitized-originals.tsv').read_bytes()
 e.update(status='passed',files={p.name:sha(p) for p in (D/'normal').iterdir()},earlier_isolated_recipe_sha256=sha(P/'normal/original-1.raw'),qualification='Exact CNBuffer captured after all prior original upstream mutations, then unchanged original single/two-frame assertions and real shared-buffer guards executed in normal and ASan/UBSan helpers. The historical isolated initial-RDG recipe remains a separate supplement, not exact original-state evidence.');save()
 # Keep the 1300 prior layouts as separate supplements; the original assertions
 # now load exact upstream-position snapshots from normal/original-*.raw.
 for folder in ['inputs','normal-replay']:shutil.copytree(P/folder,D/folder)
 shutil.copyfile(P/'rust-cases.tsv',D/'rust-cases.tsv')
 shutil.copytree(P/'replay-source',D/'replay-source')
 s=(P/'check-replay.py').read_text().replace("capture_receipt_sha256=sha(D/'rust.json')", "capture_receipt_sha256=sha(D/'capture.json')").replace("native_receipt_sha256=sha(D/'native.json')", "native_receipt_sha256=sha(D/'originals.json')");(D/'check-replay.py').write_text(s)
 subprocess.run(['python3',str(D/'check-replay.py')],check=True)
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
