from pathlib import Path
import hashlib,json,subprocess,os,time
D=Path(__file__).parent;R=Path('/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[p for sub in ['common','compress','decompress','dictBuilder','legacy'] for p in sorted((R/'lib'/sub).glob('*.c'))]+[R/'programs'/n for n in ['datagen.c','util.c','timefn.c']]
e=dict(status='running',preparation=json.loads((D/'preparation.json').read_text()),library={str(p.relative_to(R)):sha(p) for p in (R/'lib').rglob('*') if p.is_file() and p.suffix in ['.c','.h','.S']},commands=[])
def save():(D/'capture.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,env=None):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log'))));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
save()
try:
 for name,flags in [('normal',['-O2']),('sanitized',['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'])]:
  args=['cc','-std=c99','-DZSTD_MULTITHREAD','-DZSTD_WINDOW_OVERFLOW_CORRECT_FREQUENTLY=1','-Wno-deprecated-declarations','-pthread',*[f'-I{R/"lib"/sub}' for sub in ['', 'common','compress','decompress','dictBuilder','deprecated','legacy']],'-I'+str(R/'programs'),*flags,str(D/'fuzzer-capture.c'),*[str(p) for p in sources],'-o',str(D/('capture-'+name))]
  run(name+'-build',args)
  run(name+'-capture',[str(D/('capture-'+name)),'-s0','-P50','-i0'],{**os.environ,'ZSTDOXIDE_CAPTURE_CNBUFFER':str(D/(name+'-cn-buffer.bin')),'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
  assert (D/(name+'-cn-buffer.bin')).stat().st_size==5*1024*1024
 assert sha(D/'normal-cn-buffer.bin')==sha(D/'sanitized-cn-buffer.bin')
 e.update(status='passed',exact_input_sha256=sha(D/'normal-cn-buffer.bin'),qualification='Both original upstream executions at fixed basic-unit seed 0 and compressibility 0.5 reach the in-place group after every preceding mutation. Their 5 MiB snapshots agree exactly. Only the capture/exit is instrumented; no original setup or preceding assertion is removed.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
