from pathlib import Path
import hashlib,json,difflib
D=Path(__file__).parent;R=Path('/private/tmp/module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99');p=R/'tests/fuzzer.c';s=p.read_text();needle='    DISPLAYLEVEL(3, "test%3i : in-place decompression : ", testNb++);';assert s.count(needle)==1
insert='''    /* Test-only observation immediately before the original in-place groups. */
    {
        const char *path = getenv("ZSTDOXIDE_CAPTURE_CNBUFFER");
        FILE *file;
        if (!path || !(file = fopen(path, "wb"))) exit(98);
        if (fwrite(CNBuffer, 1, CNBuffSize, file) != CNBuffSize || fclose(file)) exit(99);
        fprintf(stderr, "Captured exact CNBuffer before original in-place groups: %zu bytes\\n", CNBuffSize);
        exit(0);
    }
'''
new=s.replace(needle,insert+needle);(D/'fuzzer-capture.c').write_text(new);(D/'capture.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),new.splitlines(True),fromfile='tests/fuzzer.c',tofile='tests/fuzzer.c')))
sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();(D/'preparation.json').write_text(json.dumps({'status':'prepared','reference_revision':'f8745da6ff1ad1e7bab384bd1f9d742439278e99','original_fuzzer_sha256':sha(p),'instrumented_fuzzer_sha256':sha(D/'fuzzer-capture.c'),'patch_sha256':sha(D/'capture.patch'),'qualification':'Only an observation/exit is inserted immediately before line 1344; all prior upstream setup and mutations remain intact. Capture is an external reference executable, not a codec implementation.'},indent=2)+'\n')
