from pathlib import Path
import hashlib,json,subprocess,sys,shutil
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-optimal-price-plan-checks');O.mkdir();sys.path.insert(0,str(R/'scripts'));import optimal_price_capture_plan as plan
source=plan.source_manifest();commands=[];upstream=Path('/private/tmp/zstdoxide-reference-lazy-1.5.7');upstream_sources,_=plan.reference_sources(upstream)
def run(name,argv):
 log=O/(name+'.log');p=subprocess.run([str(a) for a in argv],cwd=R,capture_output=True);log.write_bytes(p.stdout+p.stderr)
 if p.returncode:raise ValueError(name)
 commands.append(dict(argv=[str(a) for a in argv],exit_code=p.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
for name,flags in [('normal',[]),('optimized',['-O'])]:run('preflight-'+name,['python3',*flags,'scripts/check_optimal_price_capture_plan.py','--upstream',upstream])
cc=Path(shutil.which('clang')).resolve();common=[cc,'-std=c11','-g','-DDEBUGLEVEL=2','-DZSTD_DISABLE_ASM','-DZSTD_LEGACY_SUPPORT=0','-UZSTD_MULTITHREAD','-DXXH_NAMESPACE=ZSTD_','-I',upstream/'lib','-I',upstream/'lib/common','-I',upstream/'lib/compress','-Wall','-Wextra','-Werror']
for mode,flags in [('normal',['-O2']),('sanitized',['-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer'])]:run('syntax-'+mode,common+flags+['-fsyntax-only',R/plan.HELPER])
if source!=plan.source_manifest():raise ValueError('source changed')
(O/'evidence.json').write_text(json.dumps(dict(status='passed',source=source,commands=commands,upstream_source_sha256=upstream_sources,compiler=str(cc),compiler_sha256=plan.sha(cc.read_bytes()),qualification='Reviewed static price adapter, normal/instrumented strict syntax, exact 390-command capture plan, 17 malformed packets and 19 no-child plan controls per Python mode. No C observation execution yet.'),sort_keys=True,indent=2)+'\n')
