from pathlib import Path
import contextlib,csv,hashlib,importlib.util,io,json,shutil,struct,subprocess,sys,tempfile,time
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize')
NAME='tests/upstream/reference-fast-fuzz'
OUT=Path(sys.argv[1]); OUT.mkdir()
records=[]
def require(ok,message):
 if not ok: raise RuntimeError(message)
def load(root):
 p=root/'scripts/import_reference_fast_fuzz.py'; spec=importlib.util.spec_from_file_location('selector',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
m=load(ROOT); original=(ROOT/NAME/'observations.tsv').read_bytes();raw=Path('/tmp/zstdoxide-reference-fast-fuzz-reproduction/normal-capture.stdout').read_bytes()
def reject(name,fn):
 try: fn()
 except (ValueError,KeyError,TypeError,UnicodeError,SystemExit,OSError) as e:
  records.append({'name':name,'rejected':True,'diagnostic':str(e)});return
 raise RuntimeError('negative accepted: '+name)
def mutate_tsv(data,index,key,value):
 r=list(csv.DictReader(io.StringIO(data.decode()),delimiter='\t'));fields=list(r[0]);r[index][key]=value;o=io.StringIO();w=csv.DictWriter(o,fields,delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(r);return o.getvalue().encode()
for key,value in [('input_size','0'),('prefix_size','1'),('remaining_after_prefix','3'),('capacity_reduction','2'),('remaining_after_capacity','4'),('branch','1'),('remaining_after_branch','3'),('level','19'),('remaining_after_level','2'),('decoder_toggle','2'),('remaining_after_decoder','1'),('input_sha256','0'*64),('input_size','05'),('input_size','True')]:
 reject('tsv-'+key+'-'+value,lambda key=key,value=value:m.validate(mutate_tsv(original,0,key,value)))
reject('advanced-consumed',lambda:m.validate(mutate_tsv(original,77,'level','-3')))
reject('missing-row',lambda:m.validate(b'\n'.join(original.splitlines()[:-1])+b'\n'))
reject('duplicate-row',lambda:m.validate(original+original.splitlines()[1]+b'\n'))
for name,data in [('short-response',raw[:-1]),('extra-response',raw+b'\0'),('magic',b'BADMAGIC'+raw[8:]),('host-bool',raw[:12]+struct.pack('<I',1)+raw[16:]),('advanced-sentinel',raw[:24+77*48+32]+struct.pack('<I',0)+raw[24+77*48+36:])]:
 reject(name,lambda data=data:m.unpack(data))
with tempfile.TemporaryDirectory(prefix='selector-offline-') as tmp:
 root=Path(tmp); (root/'scripts').mkdir();(root/'tests/upstream').mkdir(parents=True)
 shutil.copy(ROOT/'scripts/import_reference_fast_fuzz.py',root/'scripts')
 shutil.copy(ROOT/'tests/upstream/manifest.json',root/'tests/upstream/manifest.json')
 dest=root/NAME; shutil.copytree(ROOT/NAME,dest)
 n=load(root); calls=[]
 def blocked(*a,**k): calls.append(1);raise RuntimeError('offline process attempted')
 n.subprocess.run=blocked
 n.offline();require(not calls,'offline process');records.append({'name':'offline-no-subprocess','passed':True})
 manifest=(dest/'manifest.json').read_bytes()
 def restore():
  (dest/'manifest.json').write_bytes(manifest);(dest/'observations.tsv').write_bytes(original)
 def mfchange(name,change):
  v=json.loads(manifest);change(v);(dest/'manifest.json').write_text(json.dumps(v));reject(name,n.offline);restore()
 # Strong independent pin: this mutation remains plausible and its manifest is rehashed.
 changed=mutate_tsv(original,0,'compression_bound','65');(dest/'observations.tsv').write_bytes(changed)
 v=json.loads(manifest);v['fixtures'][0].update(size=len(changed),sha256=hashlib.sha256(changed).hexdigest());(dest/'manifest.json').write_text(json.dumps(v));reject('rehashed-plausible-C-bound',n.offline);restore()
 for name,change in [('schema-bool',lambda v:v.update(schema_version=True)),('revision',lambda v:v.update(upstream_revision='0'*40)),('host-bool',lambda v:v['capture']['host'].update(size_t_bits=True)),('source-hash',lambda v:v['source_sha256'].update({'lib/zstd.h':'0'*64})),('classification',lambda v:v['expected_rust_classifications'].update(admitted=58)),('generator-hash',lambda v:v.update(generator_sha256='0'*64)),('importer-hash',lambda v:v.update(importer_sha256='0'*64))]: mfchange(name,change)
 (dest/'manifest.json').write_bytes(b'{"schema_version":1,"schema_version":1}');reject('duplicate-json',n.offline);restore()
 (dest/'extra').write_bytes(b'');reject('unlisted-file',n.offline);(dest/'extra').unlink()
 (dest/'observations.tsv').unlink();(dest/'observations.tsv').symlink_to(ROOT/NAME/'observations.tsv');reject('symlink-data',n.offline);(dest/'observations.tsv').unlink();restore()
 old=sys.argv
 for args in [('--check','--upstream','/tmp'),('--check','--output','/tmp'),('--check','--cc','cc'),('--check','--sanitize'),('--check','--capture'),('--cc','cc')]:
  sys.argv=[str(root/'scripts/import_reference_fast_fuzz.py'),*args]
  with contextlib.redirect_stderr(io.StringIO()):reject('arguments-'+str(args),n.main)
 sys.argv=old
 require(not calls,'negative offline process');n.subprocess.run=subprocess.run
# Re-import subprocess because its object was shared with the module patched above.
import importlib
importlib.reload(subprocess)
valid=m.packet(m.cases()); malformed=[('empty',b''),('magic',b'BADMAGIC'+valid[8:]),('count',valid[:8]+struct.pack('<I',80)+valid[12:]),('truncated-length',valid[:14]),('oversize-input',valid[:12]+struct.pack('<I',(1<<20)+1)),('truncated-source',valid[:16]),('truncated-batch',valid[:-1]),('trailing-data',valid+b'\0')]
for mode in ['normal','sanitized']:
 for name,data in malformed:
  env=dict(__import__('os').environ);env.update(ASAN_OPTIONS='halt_on_error=1:detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
  argv=['/tmp/zstdoxide-reference-fast-fuzz-reproduction/'+mode];p=subprocess.run(argv,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=30)
  require(p.returncode!=0 and b'selector oracle:' in p.stderr,'C malformed rejection '+name)
  label=mode+'-'+name;(OUT/(label+'.stdout')).write_bytes(p.stdout);(OUT/(label+'.stderr')).write_bytes(p.stderr)
  records.append({'name':label,'argv':argv,'exit':p.returncode,'input_sha256':hashlib.sha256(data).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest()})
(OUT/'results.json').write_text(json.dumps({'checks':len(records),'optimized':not __debug__,'records':records},indent=2)+'\n')
print('Passed',len(records),'controls; optimized=',not __debug__)
