from pathlib import Path
import os,subprocess,time,json,hashlib
R=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=list((R/'src').rglob('*.rs'))+list((R/'tests').rglob('*.rs'))+[R/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']]
e=dict(status='running',source={str(p.relative_to(R)):sha(p) for p in paths},commands=[])
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module27-candidate-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(R/'public.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 t=time.monotonic()
 with (R/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1500)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
assert not (R/'public.json').exists();save()
try:
 for name,flags in [('safe',[]),('slice',['--features','unsafe-slice-history']),('dictionary',['--features','unsafe-dictionary']),('both',['--features','unsafe-slice-history,unsafe-dictionary']),('all',['--all-features'])]:
  run(name+'-public',['cargo','test','--offline','--locked','--test','stable_prefix_output','--test','stable_dictionary_output','--test','dictionary_output','--test','caller_output','--test','slice_decoder','--test','upstream_dictionary','--test','upstream_decodecorpus',*flags])
  run(name+'-private',['cargo','test','--offline','--locked','--lib','slice_decode::tests',*flags])
  run(name+'-docs',['cargo','test','--offline','--locked','--doc',*flags])
  run(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])
 for name,flags in [('safe',[]),('both',['--features','unsafe-slice-history,unsafe-dictionary']),('all',['--features',','.join(n for n in __import__('tomllib').loads((R/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))])]:
  run(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*flags])
 run('format',['cargo','fmt','--all','--','--check'])
 for n,h in e['source'].items():assert sha(R/n)==h,n
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
