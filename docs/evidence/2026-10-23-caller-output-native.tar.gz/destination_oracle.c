/* Test oracle only: calls pinned facebook/zstd v1.5.7 outside the Rust codec. */
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "zstd.h"
#include "zstd_errors.h"

int main(int argc, char **argv) {
    if (argc != 5 && argc != 6) return 2;
    char *end = NULL;
    errno = 0;
    unsigned long long parsed = strtoull(argv[2], &end, 10);
    if (errno || !end || *end || end == argv[2] || parsed > 16U * 1024U * 1024U) return 2;
    size_t capacity = (size_t)parsed;
    int null_output = argc == 6 && strcmp(argv[5], "null") == 0;
    if ((argc == 6 && !null_output) || (null_output && capacity != 0)) return 2;
    FILE *input = fopen(argv[1], "rb");
    if (!input || fseek(input, 0, SEEK_END)) return 2;
    long length = ftell(input);
    if (length < 0 || length > 4 * 1024 * 1024 || fseek(input, 0, SEEK_SET)) return 2;
    size_t size = (size_t)length;
    unsigned char *source = malloc(size ? size : 1);
    unsigned char *storage = malloc(capacity + 64);
    if (!source || !storage || fread(source, 1, size, input) != size || fclose(input)) return 2;
    memset(storage, 0xa5, capacity + 64);
    void *output = null_output ? NULL : storage + 32;
    if (strcmp(argv[4], "oneshot") != 0) return 2;
    size_t result = ZSTD_decompress(output, capacity, source, size);
    unsigned error = ZSTD_isError(result);
    unsigned guard = 1;
    for (size_t i = 0; i < 32; ++i) {
        if (storage[i] != 0xa5 || storage[32 + capacity + i] != 0xa5) guard = 0;
    }
    if (!error && result > capacity) return 3;
    FILE *decoded = fopen(argv[3], "wb");
    if (!decoded) return 2;
    if (!error && result && fwrite(output, 1, result, decoded) != result) return 2;
    if (fclose(decoded)) return 2;
    printf("{\"version\":%u,\"error\":%u,\"error_code\":%u,\"size\":%zu,\"guards\":%u}\n",
        ZSTD_versionNumber(), error, (unsigned)ZSTD_getErrorCode(result), error ? 0 : result, guard);
    free(source); free(storage);
    return guard ? 0 : 3;
}
