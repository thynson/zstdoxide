from pathlib import Path
import os,subprocess,json,time,hashlib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');D=Path(__file__).parent
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module23-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0','ZSTDOXIDE_DESTINATION_CASES':str(D),'ZSTDOXIDE_FUZZ_CORPUS':'/private/tmp/module23-external-corpora/extracted/decompress_dstSize_tooSmall','ZSTDOXIDE_FUZZ_TARGET':'decompress_destination_too_small','ZSTDOXIDE_FUZZ_MAX_FILES':'1173'}
paths=list(R.glob('src/*.rs'))+[R/'Cargo.toml',R/'Cargo.lock']+[R/('tests/'+n+'.rs') for n in ['caller_output','caller_output_native','upstream_fuzz_targets','upstream_fuzzer','upstream_decodecorpus']]
source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
e={'status':'running','source':source,'commands':[]}
def save():(D/'rust.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append({'label':label,'argv':args,'exit_code':p.returncode,'seconds':time.monotonic()-t});save();print(label,p.returncode,flush=True)
 if p.returncode:raise ValueError(label)
try:
 for name,flags in [('safe',[]),('all',['--all-features'])]:
  run(name+'-native',['cargo','test','--offline','--locked','--test','caller_output_native',*flags,'--','--ignored','--nocapture'])
  run(name+'-upstream',['cargo','test','--offline','--locked','--test','upstream_fuzzer','--test','upstream_fuzz_targets','--test','upstream_decodecorpus',*flags])
  run(name+'-corpus',['cargo','test','--offline','--locked','--release','--test','upstream_fuzz_targets',*flags,'external_file_corpus','--','--ignored','--nocapture'])
  log=(D/(name+'-corpus.log')).read_text();assert 'checked 1173 corpus files' in log and 'skipped 0' in log
  run(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])
 run('format',['cargo','fmt','--all','--','--check'])
 assert source=={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 e['status']='passed';save()
except BaseException as ex:e['status']='failed';e['error']=repr(ex);save();raise
