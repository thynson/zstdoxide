from pathlib import Path
import json,hashlib,subprocess,shutil
R=Path('/Users/lanxingcan/Workspace/zstdoxize'); D=Path(__file__).parent; P=Path('/private/tmp/module23-native-preparation')
cmd=json.loads((P/'compile-command.json').read_text());cmd[cmd.index('-O2')]='-O1';cmd.insert(1,'-fsanitize=address,undefined');cmd.insert(1,'-fno-omit-frame-pointer');cmd[-1]=str(D/'destination-oracle-sanitized')
(D/'sanitized-command.json').write_text(json.dumps(cmd)+'\n')
with (D/'sanitized-build.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
frames=[]
for p in sorted((R/'tests/upstream/decodecorpus').glob('*.zst')):
 q=p.with_suffix('.raw')
 if q.exists():frames.append((p.stem,p.read_bytes(),q.read_bytes()))
for name in ['http','huffman-compressed-larger']:
 frames.append((name,(R/f'tests/upstream/data/generated/{name}.zst').read_bytes(),(R/f'tests/upstream/data/golden-compression/{name}').read_bytes()))
frames.extend([('empty',bytes.fromhex('28b52ffd2000010000'),b''),('skip',bytes.fromhex('502a4d1803000000010203'),b'')])
frames.append(('concatenated',frames[0][1]+frames[-1][1]+frames[1][1],frames[0][2]+frames[1][2]))
rows=[]
for name,frame,source in frames:
 (D/(name+'.zst')).write_bytes(frame);(D/(name+'.raw')).write_bytes(source)
 for cap in sorted(set([0,max(0,len(source)-1),len(source),len(source)+31])):
  rows.append((name,cap,'ok' if cap>=len(source) else 'small'))
# Corrupt checksum and truncated frame: compare rejection without requiring
# upstream error-enum identity or identical provisional bytes.
base=next(x for x in frames if x[0]=='http')
for name,data in [('bad-checksum',base[1][:-1]+bytes([base[1][-1]^1])),('truncated',base[1][:-1])]:
 (D/(name+'.zst')).write_bytes(data);(D/(name+'.raw')).write_bytes(base[2]);rows.append((name,len(base[2]),'error'))
(D/'manifest.tsv').write_text(''.join(f'{n}\t{c}\t{e}\n' for n,c,e in rows))
results=[]
for label,exe in [('normal',P/'destination-oracle'),('sanitized',D/'destination-oracle-sanitized')]:
 for i,(name,cap,expected) in enumerate(rows):
  prefix=f'{label}-{i:04}';out=D/(prefix+'.out');args=[str(exe),str(D/(name+'.zst')),str(cap),str(out),'oneshot']
  p=subprocess.run(args,capture_output=True);(D/(prefix+'.stdout')).write_bytes(p.stdout);(D/(prefix+'.stderr')).write_bytes(p.stderr)
  assert p.returncode==0,(args,p.stderr)
  j=json.loads(p.stdout);assert j['version']==10507 and j['guards']==1
  assert bool(j['error'])==(expected!='ok'),(name,cap,expected,j)
  if expected=='ok':assert out.read_bytes()==(D/(name+'.raw')).read_bytes()
  if expected=='small':assert j['error_code']==70,(name,cap,j)
  results.append(dict(backend=label,name=name,capacity=cap,expected=expected,result=j))
 for name in ['empty','skip']:
  args=[str(exe),str(D/(name+'.zst')),'0',str(D/(label+'-'+name+'-null.out')),'oneshot','null'];p=subprocess.run(args,capture_output=True);assert p.returncode==0
  j=json.loads(p.stdout);assert j['error']==0 and j['guards']==1
  results.append(dict(backend=label,name=name,capacity=0,null_destination=True,result=j))
 print(label,'passed',len(rows)+2,flush=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=dict(status='native-passed-rust-pending',cases=len(rows),frames=len(frames),results=results,files={p.name:sha(p) for p in D.iterdir() if p.is_file()},upstream=json.loads((P/'upstream-source.json').read_text()))
(D/'native.json').write_text(json.dumps(e,indent=2)+'\n')
