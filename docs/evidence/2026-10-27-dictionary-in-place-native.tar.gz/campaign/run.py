from pathlib import Path
import subprocess,json,hashlib,time,os
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cases=json.loads((D/'cases.json').read_text());build=json.loads((D/'build.json').read_text());assert build['status']=='passed'
e=dict(status='running',case_receipt_sha256=sha(D/'cases.json'),build_receipt_sha256=sha(D/'build.json'),commands=[])
def save():(D/'native.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name in ['normal','sanitized']:
  O=D/(name+'-replay');O.mkdir();args=[str(D/('oracle-'+name)),str(D/'manifest.txt'),str(O)];start=time.monotonic()
  p=subprocess.run(args,capture_output=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
  (D/(name+'-replay.tsv')).write_bytes(p.stdout);(D/(name+'-replay.stderr')).write_bytes(p.stderr)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(D/(name+'-replay.tsv')),stderr_sha256=sha(D/(name+'-replay.stderr'))));save();assert p.returncode==0,(name,p.returncode,p.stderr.decode()[-3000:])
  assert len(p.stdout.decode().splitlines())==len(cases['cases'])
 normal=[l.split('\t') for l in (D/'normal-replay.tsv').read_text().splitlines()];sanitized=[l.split('\t') for l in (D/'sanitized-replay.tsv').read_text().splitlines()];assert len(normal)==len(sanitized)
 e['results']=[]
 for c,a,b in zip(cases['cases'],normal,sanitized):
  assert a[:7]==b[:7] and a[8:]==b[8:],(c,a,b)
  assert a[0]==c['name'] and a[6]=='1' and b[6]=='1'
  row=dict(**c,status=a[1],output_size=int(a[2]),normal_unused_suffix_preserved=a[7]=='1',sanitized_unused_suffix_preserved=b[7]=='1')
  if a[1]=='ok':
   q=D/'normal-replay'/(c['name']+'.raw');r=D/'sanitized-replay'/q.name;assert sha(q)==sha(r);row['output_sha256']=sha(q)
   expected=D/'inputs'/(c['frame']+'.raw')
   if c['known_pair'] and expected.exists():assert q.read_bytes()==expected.read_bytes()
  e['results'].append(row)
 e.update(status='passed',qualification='All layouts use one real shared allocation, both guard bands and the configured output allowance are checked. Native unused-success-suffix preservation is observed rather than assumed; Rust has its own stronger suffix contract. Normal and address/undefined sanitized verdicts and output bytes agree. No LeakSanitizer credit on unsupported macOS.');save();print(len(e['results']),'native layouts passed')
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
