/* External independent test oracle: facebook/zstd v1.5.7 only. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char *load(const char *path, size_t *size) {
    FILE *f = fopen(path, "rb"); long n; unsigned char *p;
    if (!f || fseek(f, 0, SEEK_END) || (n=ftell(f)) < 0 || fseek(f,0,SEEK_SET)) exit(11);
    *size=(size_t)n; p=malloc(*size ? *size : 1);
    if (!p || fread(p,1,*size,f)!=*size || fclose(f)) exit(12);
    return p;
}
static void save(const char *path, const void *bytes, size_t size) {
    FILE *f=fopen(path,"wb");
    if (!f || fwrite(bytes,1,size,f)!=size || fclose(f)) exit(13);
}
int main(int argc,char **argv) {
    FILE *manifest; char name[128],dictionary_path[4096],frame_path[4096],kind[16],output_path[4096];
    size_t capacity,limit; int fields;
    if (argc!=3 || ZSTD_versionNumber()!=10507) return 2;
    manifest=fopen(argv[1],"r"); if (!manifest) return 3;
    while ((fields=fscanf(manifest,"%127s %4095s %15s %4095s %zu %zu",name,dictionary_path,kind,frame_path,&capacity,&limit))==6) {
        size_t dictionary_size,frame_size,result,margin,i;
        unsigned char *dictionary=load(dictionary_path,&dictionary_size),*frame=load(frame_path,&frame_size);
        unsigned char *dictionary_before,*bytes,*before,*output;
        ZSTD_DDict *ddict; ZSTD_DCtx *dctx;
        ZSTD_dictContentType_e content_type;
        int guards=1,tail=1;
        if (!strcmp(kind,"raw")) content_type=ZSTD_dct_rawContent;
        else if (!strcmp(kind,"auto")) content_type=ZSTD_dct_auto;
        else return 4;
        if (capacity>32*1024*1024 || limit>capacity || frame_size>capacity) return 5;
        dictionary_before=malloc(dictionary_size ? dictionary_size : 1);
        bytes=malloc(capacity+64);before=malloc(capacity ? capacity : 1);
        if (!dictionary_before || !bytes || !before) return 6;
        memcpy(dictionary_before,dictionary,dictionary_size);
        ddict=ZSTD_createDDict_advanced(dictionary,dictionary_size,ZSTD_dlm_byRef,content_type,ZSTD_defaultCMem);
        dctx=ZSTD_createDCtx(); if (!ddict || !dctx) return 7;
        memset(bytes,0xa5,capacity+64);output=bytes+32;
        memcpy(output+capacity-frame_size,frame,frame_size);memcpy(before,output,capacity);
        margin=ZSTD_decompressionMargin(frame,frame_size);
        result=ZSTD_decompress_usingDDict(dctx,output,limit,output+capacity-frame_size,frame_size,ddict);
        for (i=0;i<32;++i) if (bytes[i]!=0xa5 || bytes[32+capacity+i]!=0xa5) guards=0;
        for (i=limit;i<capacity;++i) if (output[i]!=before[i]) guards=0;
        if (memcmp(dictionary,dictionary_before,dictionary_size)) guards=0;
        if (!ZSTD_isError(result)) for (i=result;i<capacity;++i) if (output[i]!=before[i]) tail=0;
        printf("%s\t%s\t%zu\t%zu\t%zu\t%zu\t%d\t%d\t%s\t%zu\n",name,ZSTD_isError(result)?"error":"ok",ZSTD_isError(result)?0:result,capacity,limit,capacity-frame_size,guards,tail,ZSTD_isError(margin)?"error":"ok",ZSTD_isError(margin)?0:margin);
        if (!guards) return 8;
        if (!ZSTD_isError(result)) {snprintf(output_path,sizeof(output_path),"%s/%s.raw",argv[2],name);save(output_path,output,result);}
        ZSTD_freeDCtx(dctx);ZSTD_freeDDict(ddict);free(dictionary_before);free(dictionary);free(frame);free(before);free(bytes);
    }
    if (fields!=EOF || ferror(manifest) || fclose(manifest)) return 9;
    return 0;
}
