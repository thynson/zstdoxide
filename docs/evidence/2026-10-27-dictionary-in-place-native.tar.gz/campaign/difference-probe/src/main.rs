use zstdoxide::{Dictionary, DecodeOptions, Error, FrameHeader, decompress_into_with_dictionary_in};
fn main() {
    let root = std::path::Path::new("/private/tmp/module29-native");
    let dictionary = Dictionary::raw(&std::fs::read(root.join("inputs/boundary.dict")).unwrap()).unwrap();
    let frame = std::fs::read(root.join("inputs/p-window-plus-one.zst")).unwrap();
    let (header, _) = FrameHeader::parse(&frame).unwrap();
    assert_eq!(header.window_size, 1024);
    let expected = std::fs::read("/Users/lanxingcan/Workspace/zstdoxize/tests/upstream/dictionaries/p-window-plus-one.expected").unwrap();
    assert_eq!(expected.len(), 1028);
    for name in ["case-00439", "case-00441", "case-00443"] {
        assert_eq!(std::fs::read(root.join("normal-replay").join(format!("{name}.raw"))).unwrap(), expected);
    }
    let mut output = vec![0xa5; 17432];
    assert_eq!(decompress_into_with_dictionary_in(&frame, &mut output, &dictionary.view(), DecodeOptions::new(17432), std::alloc::Global), Err(Error::CorruptData));
    println!("Existing direct-output policy rejects the same fixture after its advertised 1024-byte window; all three native successes match pinned expected bytes.");
}
