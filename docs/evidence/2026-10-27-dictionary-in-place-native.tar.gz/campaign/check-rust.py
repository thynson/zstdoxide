from pathlib import Path
import os,subprocess,json,time,hashlib
D=Path(__file__).parent;S=D/'rust-capture';C=Path('/private/tmp/module29-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**os.environ,'CARGO_TARGET_DIR':str(D/'rust-target'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_DEV_OPT_LEVEL':'1'}
e=dict(status='running',source={str(p.relative_to(C)):sha(p) for p in (C/'src').rglob('*.rs')},capture_source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()},commands=[])
def save():(D/'rust.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [('safe',[]),('move',['--features','unsafe-in-place-buffer']),('history',['--features','unsafe-slice-history']),('dictionary',['--features','unsafe-dictionary']),('all',['--all-features'])]:
  O=D/('rust-'+name);O.mkdir();args=['cargo','run','--offline','--locked',*flags,'--',str(D/'manifest.txt'),str(O)];t=time.monotonic()
  p=subprocess.run(args,cwd=S,env=env,capture_output=True);(D/(name+'-rust.tsv')).write_bytes(p.stdout);(D/(name+'-rust.stderr')).write_bytes(p.stderr)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(D/(name+'-rust.tsv')),stderr_sha256=sha(D/(name+'-rust.stderr'))));save();assert p.returncode==0,(name,p.stderr.decode()[-3000:])
 for n,h in e['source'].items():assert sha(C/n)==h,n
 rows=json.loads((D/'native.json').read_text())['results'];assert len(rows)==1836
 safe=(D/'safe-rust.tsv').read_text().splitlines();assert len(safe)==len(rows)
 e['differences']=[];e['compared']=0
 for row,line in zip(rows,safe):
  n,status,result=line.split('\t');assert n==row['name']
  for backend in ['move','history','dictionary','all']:assert (D/(backend+'-rust.tsv')).read_text().splitlines()[e['compared']]==line
  if status!=row['status']:e['differences'].append(dict(case=row,rust_status=status,rust_result=result))
  if status=='ok':
   q=D/'rust-safe'/(n+'.raw')
   for backend in ['move','history','dictionary','all']:assert sha(q)==sha(D/('rust-'+backend)/q.name)
   if row['status']=='ok':assert sha(q)==row['output_sha256']
  e['compared']+=1
 e.update(status='captured',qualification='All guard and Rust unused-suffix assertions passed; all Rust backends agree. Native differences are recorded for explicit review before qualification.');save();print('captured',e['compared'],'layouts; differences',len(e['differences']))
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
