from pathlib import Path
import json,hashlib,subprocess
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');I=D/'inputs';I.mkdir();F=R/'tests/upstream/dictionaries';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();dictionaries={};frames={};pairs=[]
def dictionary(name,data,kind):
 (I/(name+'.dict')).write_bytes(data);dictionaries[name]=dict(kind=kind,size=len(data),sha256=sha(I/(name+'.dict')))
def frame(name,data,expected=None):
 assert name not in frames;(I/(name+'.zst')).write_bytes(data)
 if expected is not None:(I/(name+'.raw')).write_bytes(expected)
 frames[name]=dict(size=len(data),expected_size=len(expected) if expected is not None else None)
for name,file,kind in [('boundary','boundary-dictionary.raw','raw'),('formatted','formatted.dict','auto'),('trained','trained.dict','auto'),('duplicate','duplicate-reps.dict','auto')]:dictionary(name,(F/file).read_bytes(),kind)
dictionary('http',(R/'tests/upstream/data/golden-dictionaries/http-dict-missing-symbols').read_bytes(),'auto');dictionary('empty',b'','raw');dictionary('wrong',b'wrong dictionary','raw');dictionary('formatted-as-raw',(F/'formatted.dict').read_bytes(),'raw')
for dictname,stem in [('boundary','p0-far-dictionary'),('boundary','p-window-minus-one'),('boundary','p-window-equal'),('boundary','dictionary-to-frame-eviction'),('boundary','output-distance-equals-window'),('boundary','raw-small-window'),('formatted','formatted-id'),('formatted','formatted-omitted-id'),('formatted','persistent-concatenation'),('formatted','dictionary-treeless-literals'),('formatted','dictionary-treeless-four-streams'),('trained','dictionary-repeat-sequences'),('duplicate','duplicate-reps-initial')]:
 data=(F/(stem+'.zst')).read_bytes();expected=(F/(stem+'.expected')).read_bytes();frame(stem,data,expected);pairs.append((dictname,stem,True))
 skip=bytes([0x5f,0x2a,0x4d,0x18,3,0,0,0,1,2,3]);frame(stem+'-twice',skip+data+skip+data+skip,expected*2);pairs.append((dictname,stem+'-twice',True))
frame('http',(R/'tests/upstream/data/generated/http-dictionary.zst').read_bytes(),(R/'tests/upstream/data/golden-compression/http').read_bytes());pairs.append(('http','http',True))
for stem in ['p-window-plus-one','dictionary-out-of-bounds']:frame(stem,(F/(stem+'.zst')).read_bytes());pairs.append(('boundary',stem,False))
for name,encoded,expected in [('raw',bytes([0x28,0xb5,0x2f,0xfd,0x20,3,25,0,0])+b'abc',b'abc'),('rle',bytes([0x28,0xb5,0x2f,0xfd,0x20,12,99,0,0,77]),b'M'*12),('empty-frame',bytes([0x28,0xb5,0x2f,0xfd,0x20,0,1,0,0]),b''),('skip',bytes([0x50,0x2a,0x4d,0x18,0,0,0,0]),b''),('empty-input',b'',None)]:
 frame(name,encoded,expected)
 for d in dictionaries:pairs.append((d,name,True))
for d in ['wrong','empty','formatted-as-raw']:pairs.append((d,'formatted-id',False));pairs.append((d,'formatted-omitted-id',False))
for d,stem in [('boundary','p0-far-dictionary'),('formatted','dictionary-treeless-literals'),('http','http')]:
 data=(I/(stem+'.zst')).read_bytes()
 # Exhaust all boundaries for small fixtures, and bounded representative endpoints
 # for the larger fixture; public Rust tests separately exhaust its truncations.
 ends=range(len(data)) if len(data)<=128 else sorted(set(range(20))|set(range(len(data)-20,len(data)))|{len(data)//2})
 for end in ends:
  name=f'{stem}-truncated-{end}';frame(name,data[:end]);pairs.append((d,name,False))
 for index in sorted({0,4,5,6,len(data)//2,len(data)-1}):
  for bit in [0,3,7]:
   changed=bytearray(data);changed[index]^=1<<bit;name=f'{stem}-mutated-{index}-{bit}';frame(name,bytes(changed));pairs.append((d,name,False))
(D/'margin-inputs.txt').write_text(''.join(str(I/(n+'.zst'))+'\n' for n in frames));p=subprocess.run(['/private/tmp/module28-margin/oracle-normal',str(D/'margin-inputs.txt')],capture_output=True);assert p.returncode==0;(D/'margins.tsv').write_bytes(p.stdout)
for line in p.stdout.decode().splitlines():
 path,status,value=line.split('\t');frames[Path(path).stem]['margin']=int(value) if status=='ok' else None
cases=[]
for d,f,known_pair in pairs:
 row=frames[f];size=row['expected_size'] if known_pair else None;length=row['size'];margin=row['margin']
 capacities=sorted({length,length+1,length+8,max(length,size+margin),max(length,size+margin-1)}) if size is not None else sorted({length,length+32,length+16384})
 for capacity in capacities:
  limits=sorted({0,size,max(0,size-1),capacity}) if size is not None else [0,capacity]
  for limit in limits:
   if limit>capacity:continue
   cases.append(dict(name=f'case-{len(cases):05}',dictionary=d,kind=dictionaries[d]['kind'],frame=f,capacity=capacity,limit=limit,known_pair=known_pair))
(D/'manifest.txt').write_text(''.join(f"{c['name']} {I/(c['dictionary']+'.dict')} {c['kind']} {I/(c['frame']+'.zst')} {c['capacity']} {c['limit']}\n" for c in cases))
(D/'cases.json').write_text(json.dumps(dict(status='prepared',dictionaries=dictionaries,frames=frames,cases=cases,files={p.name:sha(p) for p in I.iterdir()},driver_sha256=sha(Path(__file__)),qualification='Explicitly supplemental dictionary in-place layouts using existing pinned fixture provenance. Correct dictionary/frame pairs retain original expected bytes. Wrong selections and malformed input are compared by actual native/Rust verdict and output, not by assuming the original content. No original upstream case is claimed newly ported by these generated layouts.'),indent=2)+'\n');print(len(frames),'frames',len(cases),'layouts')
