"""Promote the qualified module36 prepared-entropy reuse item."""
from pathlib import Path
import json, hashlib, subprocess, shutil

D = Path(__file__).parent
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
S = Path('/private/tmp/module36-entropy/source')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = Path('/private/tmp/module36-archives/promotion-state.json')
prev = json.loads(state.read_text())
assert prev['stage'] == 'tree'
assert prev['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == prev['production_source']
name = '2026-10-30-one-shot-encode-parameters-entropy'
p = D / (name + '.json')
r = json.loads(p.read_text())
assert r['status'] == 'passed' and sha(D / r['archive']) == r['archive_sha256']
changed = []
for n in ['src/reference_frame_encode.rs']:
    assert sha(S / n) == r['source'][n], n
    shutil.copyfile(S / n, R / n)
    changed.append(n)
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == r['production_source']
for q in [p, D / r['archive']]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
    changed.append('docs/evidence/' + q.name)
p = R / 'TODO.md'
s = p.read_text()
task = '- [ ] Reuse prepared dictionary entropy for emitted blocks where the existing dictionary contract applies.'
assert s.count(task) == 1
s = s.replace(task, task.replace('[ ]', '[x]'))
p.write_text(s)
changed.append('TODO.md')
p = R / 'docs/one-shot-encode-parameters-validation.md'
s = p.read_text()
old = '''Module 36 is in progress. Only the internal combined-staging engine, its
DoubleFast extension, the Greedy chain-and-row family extension and the
BinaryTreeLazy2 tree-family extension with the explicit optimal-family
rejection are qualified and integrated. Public parameterized dictionary APIs,
prepared dictionary entropy reuse, native/corpus/platform validation, the
complete feature/release regression, measurements and reconciliation remain
open.'''
assert s.count(old) == 1
s = s.replace(old, '''Module 36 is in progress. Only the internal combined-staging engine, its
DoubleFast extension, the Greedy chain-and-row family extension, the
BinaryTreeLazy2 tree-family extension with the explicit optimal-family
rejection, and prepared formatted-dictionary entropy reuse are qualified and
integrated. Public parameterized dictionary APIs, native/corpus/platform
validation, the complete feature/release regression, measurements and
reconciliation remain open.''')
old = '''Evidence: `evidence/2026-10-30-one-shot-encode-parameters-tree.json`.'''
assert s.count(old) == 1
s = s.replace(old, old + '''

## Prepared formatted-dictionary entropy reuse

A formatted dictionary's validated literal codebook, sequence tables and
repeat triple seed the first emitted block through the existing transactional
entropy owner, matching `ZSTD_loadCEntropy` filling `blockState.prevCBlock`
before the first block. Covered literals may therefore use a treeless header
and covered sequences may repeat the prepared tables; a block containing a
symbol absent from the prepared tree still selects a fresh tree, and raw or
empty dictionaries keep their exact existing bytes. The seed is borrowed only
during workspace construction and copies no dictionary ownership into the
frame.

Sixteen focused commands pass: the complete library suite, true no_std
compilation and strict Clippy under safe, the isolated huffman-codebook,
FSE-encoder and dictionary backends the new path exercises, and all features,
plus formatting. Every full suite reports {passed} passed
and {ignored} ignored across
{groups} result groups. Two new unit tests prove treeless literal and repeat
sequence reuse across the Fast, Greedy and BinaryTreeLazy2 tiers with the
formatted fixture, exact shrink against the same raw dictionary content, and
that a literal block containing a symbol absent from the prepared tree never
emits a treeless header.
Evidence: `evidence/{name}.json`.'''.format(passed=r['full_suite_counts']['passed'], ignored=r['full_suite_counts']['ignored'], groups=r['full_suite_counts']['result_groups'], name=name))
p.write_text(s)
changed.append('docs/one-shot-encode-parameters-validation.md')
p = R / 'docs/data-structures.md'
s = p.read_text()
old = '''construction. This replaces per-profile dictionary-aware parser forks and
copies at most the resolved window; it is per-call scratch released before
return, not retained workspace. Frame flags follow the existing
parameterized-profile family (known content size, no checksum) plus the
dictionary ID field the dictionary paths already emit; modules 33–35 keep
their exact ordinary checksummed bytes. No options record, workspace or live
context is retained between calls; coordinator selection semantics are
unchanged.'''
assert s.count(old) == 1
s = s.replace(old, '''construction. This replaces per-profile dictionary-aware parser forks and
copies at most the resolved window; it is per-call scratch released before
return, not retained workspace. A formatted dictionary's validated entropy is
borrowed only during workspace construction: the literal codebook is an inline
copy and the sequence tables are rebuilt into the workspace's own allocator
domain, together with the dictionary repeat triple. That copied seed is the
first block's previous state, matching `ZSTD_loadCEntropy`, so no dictionary
borrow or table ownership survives the call. Frame flags follow the existing
parameterized-profile family (known content size, no checksum) plus the
dictionary ID field the dictionary paths already emit; modules 33–35 keep
their exact ordinary checksummed bytes. No options record, workspace or live
context is retained between calls; coordinator selection semantics are
unchanged.''')
p.write_text(s)
changed.append('docs/data-structures.md')
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *changed], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Reuse prepared dictionary entropy in combined parameterized emission'], cwd=R, check=True)
prev.update(stage='entropy', head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(), production_source={str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')})
state.write_text(json.dumps(prev, indent=2) + '\n')
print('module36 prepared-entropy reuse promoted at', prev['head'][:12])
