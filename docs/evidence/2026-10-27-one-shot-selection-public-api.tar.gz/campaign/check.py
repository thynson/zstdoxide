from pathlib import Path
import os,subprocess,json,hashlib,time,re
D=Path(__file__).parent;S=Path('/private/tmp/module32-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};e=dict(status='running',source=source,commands=[]);env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module32-public-target','CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
plan=[]
for name,flags,no in [('safe',[],[]),('in-place',['--features','unsafe-in-place-buffer'],['--features','unsafe-in-place-buffer']),('history',['--features','unsafe-slice-history'],['--features','unsafe-slice-history']),('dictionary',['--features','unsafe-dictionary'],['--features','unsafe-dictionary']),('all',['--all-features'],['--features',','.join(__import__('tomllib').loads((S/'Cargo.toml').read_text())['features'].keys()-{'default','std'})])]:
 plan += [(name+'-unit',['cargo','test','--offline','--locked','--lib','one_shot_selection::tests',*flags]),(name+'-public',['cargo','test','--offline','--locked','--test','one_shot_selection',*flags]),(name+'-docs',['cargo','test','--offline','--locked','--doc','one_shot_decode',*flags]),(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*no]),(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])]
plan += [('format',['cargo','fmt','--all','--','--check'])]
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for label,args in plan:
  start=time.monotonic()
  with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log_sha256=sha(D/(label+'.log'))));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
  count={'unit':4,'public':8,'docs':3}.get(label.rsplit('-',1)[-1])
  if count is not None:
   groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (D/(label+'.log')).read_text());assert sum(int(a) for a,_,_ in groups)==count and all(int(b)==int(c)==0 for _,b,c in groups),(label,groups)
 for n,h in source.items():assert sha(S/n)==h,n
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
