# Public reference Fast interoperability

Two fresh successful captures each contain 92 unchanged source/request recipes:
79 admitted, 11 unsupported, and 2 resource-limit rejections. Every admitted
source is encoded by safe/all Rust and by fresh pinned-C contexts in normal and
helper-instrumented builds. Rust safe/all frames are identical. Each C build
decodes both Rust frames and each Rust build decodes both C frames, comparing
all bytes. This yields 316 decodes in each direction and 64,935,672 decoded
bytes per successful capture. C entropy/frame identity with Rust is not required.
Every case record, complete frame hash, source record, compiler record and
reference-library record agrees in the fresh reproduction.

Both successful runs include 32 malformed packet rejections with exact exit2.
Sixteen separate normal/optimized-Python controls validate protected paths,
argument exclusivity, and preserved timeout/launch-failure evidence; their
subprocess calls are mocked, and they execute no C or Rust child program.
Strict Rust example Clippy safe/all, two no_std library configurations,
formatting and optimized offline-plan checks also pass.

The initial capture stopped at an incorrect default-window expectation. The
original runner and complete original evidence remain archived; the source-
backed correction is recorded separately. No codec source changed for it.

C compilation uses the pinned prebuilt archive. ASan/UBSan instruments only
the narrow helper, with LeakSanitizer disabled; do not describe the archive as
instrumented. Public CCtx getters are not used as applied-parameter evidence.
Rejected Rust profiles never enter the C compressor.

Original evidence files preserve every exact command, environment, stdin hash,
stdout/stderr hash and exit status. Identical text logs are stored once by SHA256
and mapped in text-log-map.json. Large binary protocol responses and copied
upstream source bodies are intentionally omitted, with their verified hashes
and sizes in omitted-log-artifacts.json. No compiled artifact, executable,
source corpus, codec source or C source copy is included. The committed Rust
example, C helper and Python recipe generator reproduce these bounded bytes.
Run the script with the pinned external checkout and a fresh disjoint output
directory; do not reuse historical output paths.
