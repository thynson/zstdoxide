import argparse,hashlib,importlib.util,json,pathlib,subprocess,sys
from unittest.mock import patch
sys.dont_write_bytecode=True
root=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize')
spec=importlib.util.spec_from_file_location('fast_interop',root/'scripts/check_reference_fast_interop.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
base=pathlib.Path(sys.argv[1]);base.mkdir()
reference=pathlib.Path('/tmp/zstdoxize-upstream-1.5.7');records=[]
def need(value,message):
 if not value:raise ValueError(message)
def rejected(name,output):
 existed=output.exists()
 with patch.object(module.subprocess,'run',side_effect=AssertionError('unexpected process')):
  try:module.execute(argparse.Namespace(upstream=reference,output=output,compiler=None))
  except ValueError:pass
  else:raise ValueError('accepted '+name)
 need(output.exists()==existed,'path mutation '+name);records.append({'name':name,'result':'rejected-before-process'})
cases=module.recipes();need(len(cases)==92 and sum(r['size'] for r in cases)==11148196,'fixed recipes');records.append({'name':'offline-plan','result':'passed'})
with patch.object(sys,'argv',['runner','--check-plan','--compiler','cc']),patch.object(module.subprocess,'run',side_effect=AssertionError('unexpected process')):
 try:module.main()
 except ValueError:pass
 else:raise ValueError('mixed plan accepted')
records.append({'name':'mixed-plan-arguments','result':'rejected-before-process'})
rejected('repo-child',root/'__fast_oracle_control_must_not_create__')
rejected('reference-child',reference/'__fast_oracle_control_must_not_create__')
existing=base/'existing';existing.mkdir();(existing/'sentinel').write_bytes(b'preserve')
rejected('existing-output',existing);need((existing/'sentinel').read_bytes()==b'preserve','existing bytes')
rejected('protected-ancestor',root.parent)
for name,error in [('timeout',subprocess.TimeoutExpired(['git'],120)),('spawn',FileNotFoundError(2,'injected missing command'))]:
 output=base/name
 with patch.object(module.subprocess,'run',side_effect=error):
  try:module.execute(argparse.Namespace(upstream=reference,output=output,compiler=None))
  except type(error):pass
  else:raise ValueError('missing injected failure')
 evidence=json.loads((output/'evidence.json').read_text());need(len(evidence['commands'])==1,'failure record count');command=evidence['commands'][0]
 need(command['exit_code'] is None and command['exception'] and command['argv'][0]=='git','failure metadata')
 need(command['environment']==evidence['environment'],'failure environment')
 for side in ['stdout','stderr']:
  content=(output/command[side]).read_bytes();need(hashlib.sha256(content).hexdigest()==command[side+'_sha256'],'partial hash')
 records.append({'name':name,'result':'exception-and-partial-logs-preserved'})
summary={'checks':len(records),'records':records,'optimized':not __debug__,'script_sha256':hashlib.sha256((root/'scripts/check_reference_fast_interop.py').read_bytes()).hexdigest(),'no_child_process_executed':True}
(base/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,sort_keys=True))
