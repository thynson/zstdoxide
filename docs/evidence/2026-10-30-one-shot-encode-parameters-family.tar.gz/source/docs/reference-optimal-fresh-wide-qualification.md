# Complete fresh Optimal qualification

The additive ZOPFW03 model reconciles all 8,818 native events from both padding
passes of twelve immutable small startup captures. Normal and optimized Python
each reject fifty transport/state forgeries and launch no children. The twenty
full-source recipe predictions are frozen with manifest SHA-256
`e943081004aa5a4fc144b68e168fd5575a62b07fdd9f97a2722e97db15f7ec8c`.
This is source-only model qualification; native execution is a subsequent gate.

Normal and optimized source-only preflight each qualify the exact 150-command
plan, 77 project source files, 89 pinned reference files, all 26 codec units,
14 uniquely anchored hooks and 24 malformed packets, rejecting 29 forged
plans/dependency/environment/artifact controls without children. Separate
strict normal and sanitized C syntax checks pass. The source-only recipes
predict 64,610 events, 30,314 queries and 48 sequences per padding pass; native
capture remains the next gate.

All 150 native commands passed. Twenty recipes independently match 64,610
events, 30,314 queries and 48 sequences per padding pass. All 80 complete
frames and 80 allocator ledgers agree across normal/sanitized builds and both
padding values; each build rejects 24 malformed requests. The exact artifact
inventory and 362,684,292 log bytes are audited. Normal and optimized offline
controls each accept two exact captures and reject seventy forged records
without children. All 77 frozen capture inputs remain unchanged. The archive
contains 643 individually verified members. Independent Rust fixture/frame
qualification and wider fresh production composition remain subsequent gates.

The complete fresh fixture projection passed in normal and optimized Python: 20 cases, 64,610 events, 8,460,469 bytes, SHA-256 `d6de8128b08fa0cecb4254c8089463b0bfb650abb322884b2b0f319ba00553ee`. Both runs independently checked frozen capture hashes, model states and complete frames. Projection logs are archived in `docs/evidence/2026-10-16-optimal-fresh-wide-projection.tar.gz`.

The independent Rust reader passed four boundary/state/frame tests in safe, all-feature and release-all builds (12 executions), plus strict all-test Clippy, no_std compilation and formatting. It decodes every complete frame and checks all 64,610 events, 30,314 queries and 48 sequences; malformed sparse counts, source windows, horizon cells and strict frame prefixes are rejected. Evidence: `docs/evidence/2026-10-16-optimal-fresh-wide-reader.tar.gz`.

Complete fresh search admission now covers the independently captured 64..16,384-byte, W10..16/H6..12/C6..12/S1..6 domain inside its window. All 30,314 native queries, complete maps and frontiers match. Direct-query guards remain separate; source, window, geometry and mode errors preserve state. The 23 focused tests passed in safe, tree-only, short-key-only, matches-only, all-feature and release-all builds (138 executions), with strict Clippy, no_std and formatting. Source-hash barriers passed; evidence: `docs/evidence/2026-10-16-optimal-fresh-wide-search.tar.gz`.

Complete fresh path composition matches all 64,610 native events, 48 sequences, sparse path/frequency transitions and final complete search maps. The 72 focused tests passed in six configurations (432 executions), plus strict Clippy, no_std and formatting, with unchanged source hashes. An initial paths build exhausted disk space before tests; its evidence is preserved alongside the successful complete rerun with incremental/debug output disabled. Only rebuildable Cargo caches were removed. Evidence: `docs/evidence/2026-10-16-optimal-fresh-wide-parse.tar.gz`.

Complete fresh ownership passed ten focused tests in six configurations (60 executions): all seven moved non-Clone failure points release exactly their own allocations; borrowed owners retain 65,536 short-key cells and parse/reset repeatedly without allocation; observer failures require both resets and preserve external output. Source/parameter/used-search rejection precedes parser mutation. Strict Clippy, no_std, formatting and source barriers passed. Evidence: `docs/evidence/2026-10-16-optimal-fresh-wide-owner.tar.gz`.
