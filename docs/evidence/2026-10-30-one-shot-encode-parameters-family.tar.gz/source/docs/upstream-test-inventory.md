# Official test migration inventory

## Design and decomposition

The reference is facebook/zstd v1.5.7, revision
`f8745da6ff1ad1e7bab384bd1f9d742439278e99`. The migration tracks upstream
test intent separately from whether the current Rust API can execute it.
Copying a fixture or listing a source file is not a successful test port.

The inventory uses three plain value records:

- A source record owns a relative path, SHA-256 digest, Git object identifier,
  role, suite, migration status, explanation, and local test references.
- A case record owns an identifier, source line range, original test label,
  migration status, explanation, and local test references. Ranges are integer
  indices into the referenced source; there are no non-owning pointers.
- A scope record owns a path and exclusion reason for each upstream file that
  is not a test, test dependency, test asset, or test entrypoint. Together with
  source records these classify the complete pinned Git tree.

The JSON manifest owns its strings and lists. The audit uses Python's managed
values and Rust test adapters use ordinary borrowed slices and owned vectors.
These are metadata records, not performance-sensitive codec structures, so
an artificial unsafe backend would add no useful comparison. Upstream
counterparts are Make/CMake/Meson/CI target definitions, C test labels, Google
Test declarations, shell scripts, and golden-file directories.

The work is decomposed into: catalog every upstream source and test entrypoint;
extract stable source case anchors; verify hashes, scope, references, and
status invariants; map executable Rust adaptations after focused tests pass;
document the remaining API dependencies. The coordinating checklist is in
`TODO.md` and codec ownership analysis is in `docs/data-structures.md`.

## Status semantics

- `ported`: the complete named unit has a runnable Rust test adaptation and
  local references; there is no omitted assertion or unsupported parameter
  within the declared unit.
- `partial`: a useful part runs, but the explanation identifies what remains.
- `planned`: identified work for an available API that has not been completed.
- `blocked`: test intent requires an API or format feature not implemented.
- `non_applicable`: documentation, support/build metadata, or a test specific
  to a C/C++ implementation detail without a Rust counterpart. The reason must
  be explicit. Unsupported codec features are never classified this way.

Case anchors identify named upstream test groups, not individual executions of
every seed, parameter combination, or assertion in a loop. A whole-file source
record remains authoritative for unlabelled assertions and randomized drivers.
Case counts must not be presented as full upstream assertion counts.

## Complete source scope

`tests/upstream/manifest.json` classifies all **639** tracked files in the
pinned tree: **418** test-related files and **221** explicit non-test
exclusions. All **222** files under upstream `tests/` are included, including
dotfiles, expected CLI output, symlinks, support code, and binary fixtures.
The larger catalog also includes the test paths outside `tests/`:

| Suite | Files | Named case groups |
| --- | ---: | ---: |
| Core, streaming, stress, and shell integration | 32 | 513 |
| CLI scripts, assertions, and support | 102 | 0 |
| libFuzzer targets and support | 37 | 28 |
| Golden corpora | 14 | 0 |
| Compression regression framework | 14 | 0 |
| Gzip compatibility | 23 | 0 |
| pzstd and C++ utility tests | 15 | 41 |
| Seekable format and examples | 10 | 5 |
| Kernel and freestanding integration | 19 | 6 |
| zlib wrapper and examples | 18 | 21 |
| Public API examples | 14 | 0 |
| Educational decoder and harness | 6 | 0 |
| Single-file C build checks | 18 | 0 |
| Input generation helpers | 5 | 0 |
| Build systems, CI, and other entrypoints | 91 | 1 |

The **615** named groups include 232 anchors in `tests/fuzzer.c`, 89 in
`tests/zstreamtest.c`, and 173 in `tests/playTests.sh`. A named function and a
diagnostic inside it are separate navigation anchors, so these figures are
not additive counts of independent executable tests. Shell tests without a
named heading remain individual whole-file source units. Build entrypoints
include Make, CMake, Meson, Visual Studio, GitHub Actions, and Cirrus.

The exclusions are production implementation, packaging, policy, and format
documentation. They do not hide unsupported streaming, dictionaries, legacy,
seekable, threading, CLI, or gzip test suites. Those are included and retain
their explicit unsupported status until the corresponding behavior exists.
No reference C implementation is vendored into this repository.

Upstream sources and labels retain their original names in this metadata.
The upstream root source notice attributes Meta Platforms, Inc. and affiliates
and offers a BSD-3-Clause option. Individual third-party notices still govern
their files, including the GNU gzip tests and zlib examples; this catalog does
not relicense them. Source links can be formed
as `https://github.com/facebook/zstd/blob/<revision>/<path>#L<line_start>`;
each source record includes its SHA-256 and pinned Git blob identifier.
Hashes use canonical Git bytes; the pinned `.gitattributes` CRLF conversion for
Windows project files is normalized before comparison.

## Executable mappings and remaining work

The manifest's `rust_tests` references point to actual local test declarations,
including declarations generated by test macros. The associated status and
explanation apply to the entire source unit or named group, not just the
existence of a local file.

| Upstream intent | Rust execution | Scope |
| --- | --- | --- |
| Successful and malformed golden frames | `tests/upstream_golden.rs` | Exact original inputs and output/error assertions |
| Golden compression corpus | `tests/upstream_golden.rs` | One-shot roundtrip and independent interoperability; specialized encoder settings remain missing |
| Named fuzzer cases and randomized driver | `tests/upstream_fuzzer.rs` | Exact RNG/noise workload and supported one-shot cases; full label mapping in `tests/upstream/FUZZER.md` |
| Generated complete frames and standalone headers | `tests/upstream_decodecorpus.rs`, `tests/upstream_streaming.rs` | Official generated inputs, original bytes, bounded fresh-generator replay and fragmented decoding; the generator's dictionary/raw-block branches remain unported |
| Inline legacy and skippable regression bytes | `tests/upstream_inline_regressions.rs` | Modern component runs; the full legacy desired-success assertion remains blocked |
| Four public one-shot fuzz targets | `tests/upstream_fuzz_targets.rs` | Exact tail-selected input contracts with bounded deterministic inputs and a configurable external file runner; contexts/parameters/in-place and production scanner APIs remain missing |
| Regression directory corpora | `tests/upstream_regression_corpora.rs` | Every Silesia/GitHub input passes full content comparisons with all three named Rust strategies and reused contexts under safe/all-feature builds; original C methods, numeric levels, dictionary and CSV matrices remain incomplete |
| FSE normalized-count and Huffman fuzz intent | `tests/upstream/entropy.rs`, `tests/upstream/huffman_encode.rs`, `tests/upstream/huffman_round_trip.rs`, `src/entropy_output.rs` | Complete normalized-count target, exact C headers/tables/streams, standalone depth/capacity control flow and all 833 Huffman inputs in both BMI layouts; independent tree, serializer and CPU-engine qualifications remain explicit |
| Single-file DXT1 and kernel empty-frame fixtures | `tests/upstream_testcard.rs` | Exact original bytes and output contracts; maximum-level selection, browser rendering, and kernel workspace APIs remain missing |
| Ordinary streaming and context reuse | `tests/upstream_streaming.rs`, `tests/upstream_window.rs` | Bounded fragmented progress, flush/finish/reset, pledge and checksum failures, official window-distance fixtures and matching external adapters; specialized parameter/control paths remain separate |
| Prepared dictionaries and prefixes | `src/dictionary.rs`, `tests/upstream_dictionary.rs`, `tests/upstream_dictionary_encode.rs` | Exact malformed/prepared metadata, raw/formatted matches, first-block decoding entropy/repeat offsets, IDs, persistent selection, one-use prefixes and resource/state boundaries; original level/strategy and broader random schedules remain incomplete |
| Raw and formatted dictionary training | `tests/upstream_training.rs`, `tests/upstream_formatted_training.rs` | Bounded deterministic content selection, generated sample-derived literal metadata, exact cyclic input construction, held-out improvement and bidirectional C interoperability; COVER/fastCover, shrink, worker optimization and strategy-specific parameter schedules remain incomplete |
| Dictionary fuzz targets | `tests/upstream_dictionary_fuzz.rs`, `tests/upstream_trained_dictionary_fuzz.rs` | All five pinned target corpora replayed through supported APIs with exact source/sample selectors; original fastCover, by-reference lifetimes, advanced parameters and external sequence producers remain partial |

The dictionary decoder checkpoint runs **40 integration tests** and **11 parser
unit tests**. The mapped dictionary encoder checkpoints add **24 regular
tests** and two explicitly exercised CLI tests: 96 streamed and 20 one-shot
frames were independently decoded byte for byte. Raw training adds four regular
tests and a bidirectional 16-frame official-C check on held-out inputs; this is
an independent raw selection strategy. Formatted training adds seven regular
tests and a separately exercised C check accepting eight Rust-built dictionaries
and 36 source/dictionary pairs in both directions. Its cyclic assertion preserves
the exact original 1 MiB sample layout. A second independent C-backed campaign
trains on the original CNBuffer sample layout and verifies all five complete
5 MiB sources. Neither trainer implements COVER/fastCover optimization. The fixtures include the original HTTP/fixed-training/invalid
dictionaries plus **48** reproducible dictionary-related files backed by **123**
independent C oracle outcomes. C acceptance and the selected format lifetime rule
remain separate: dictionary references at P==W are accepted and references at
P>W rejected. Source-backed mappings and remaining qualifications are detailed in
`docs/upstream-dictionary-plan.md`; fixture presence alone never marks a source
test complete.

Rust's dictionary reset contract deliberately preserves selected dictionaries
through `reset` and `reset_with_options`. Upstream groups which also require C
`session_and_parameters` or `initDStream` to clear a selection therefore remain
partial; the explicit Rust operation is `set_dictionary(None)`. Similarly,
first-block entropy witnesses do not complete upstream's exhaustive code-value
or compressor-specific table-reuse sweeps.

Module 8 adds independently bounded Greedy, Chain and Lazy policies, adaptive
sequence tables, transactional Huffman reuse and standalone entropy contracts.
The `huf_round_trip.c:41` source/case remains `partial`, now with a complete
adapted driver: exact tail selectors and cheap-depth arithmetic, independent
optimal tree selection through twelve bits, 256 KiB inputs, guarded caller
destinations and explicit zero/error outcomes. Every one of the 833 corpus
files runs both BMI layouts under safe and all-feature builds. The 1,666
per-file records agree across backends; no file is skipped. Rust's independent
tree/cost policy, exact-fit paired-description copying and single decoder
representation remain distinct from C's serialization and CPU/X1/X2 engines.

Generalized inverse FSE tables and supplied-table sequence encoding have their
own exact bounds, repeat and C interoperability tests. Their existence does
not by itself complete the original dictionary code-value sweep at
`zstreamtest.c:1551` or numeric strategy/level controls. The separate original
`:1831` and `:1884` schedules now preserve exact source and dictionary bytes,
both prior random-state paths, all 43,691 small flushes and nine dictionary
ranges, with independent C comparisons. Numeric levels, borrowed CDict ownership
and nondefault training profiles remain qualified. The normalized-count target remains
ported; `fuzzer.c:4172` remains ported for its arithmetic-trap assertion and
`:4190` remains partial for its caller-owned destination contract. The
[Module 8 coverage plan](upstream-entropy-plan.md) separates these foundations
from the remaining executable upstream campaigns.

An ignored test may contain a complete desired-success assertion while still
being `blocked` because the implementation cannot pass it. In particular,
rejecting an unsupported dictionary or legacy frame never substitutes for an
upstream test that expects successful decoding. The upstream compression
fuzzer that uses random insufficient output buffers also remains blocked:
the current allocating encoder has no equivalent caller-buffer API.

Remaining `planned` units include file-based sample-program ports and exact
late-fuzzer skippable fixtures whose query APIs now exist.
Remaining `blocked` suites need advanced streaming/context behavior, dictionary
encoding/training test adapters, compression parameters, legacy, raw-block,
seekable, threaded, CLI, or external-format interfaces. Their
paths and reasons remain in the machine-readable inventory so future modules
can enable actual assertions without losing the upstream correspondence.

## Query, utility and call-scoped corpus reconciliation (2026-10-27)

Eleven named function/diagnostic anchors now have complete bounded Rust
adaptations for original compression/decompression bounds, known-size single and
multiple-frame queries, and exact original skippable writes/reads. Native history
captures preserve preceding generator state and complete payload bytes; standalone
bound construction records its helper allocation-lifetime difference. These
anchors are navigation groups, not independent assertion or execution counts.

The unknown-size bound group at fuzzer.c:948 remains partial: native queried full
buffer capacity rather than encoded frame length, returned an error sentinel and
then compared it numerically as an upper bound. Rust's useful exact-frame query
is explicitly supplemental. Late skippable metadata groups4117/4121/4125 remain
planned, because API availability does not reproduce their original fixtures.

All12,063 dictionary_decompress inputs additionally exercise call-scoped direct
and in-place selection, with exact Rust Result/output/guard/state comparisons.
The original selectors and historical ledger remain intact. Call-scoped prefixes
serve all frames in one call and are not equated to incremental frame prefixes.
Independent Rust training and native context/workspace differences keep that
source partial. Safe/all corpus receipts are separate from ignored ordinary runs.

After all source-bound Module30–32 closures, the integrated audit retains639 files,
418 test-related sources,221 exclusions and615 named groups. Case statuses are
66 ported,120 partial,411 blocked,3 planned and15 non-applicable. Complete upstream
migration remains open. See `evidence/2026-10-27-query-utility-corpus-inventory.json`
for exact before/after metadata, source identities and executed audit.

## External corpus snapshots

`tests/upstream/external-corpora.json` separately pins sixteen rolling release
archives: thirteen fuzz target corpora and three regression inputs. They are
external release snapshots observed on 2026-10-08 and 2026-10-09, not files proven to belong
to the v1.5.7 tag. Archives and extracted inputs remain in an external cache.
Their original source notices are independent of the codec's root license.

The following complete selected fuzz corpora passed the Rust adapters in
release builds with all unsafe features enabled and no skipped files:

| Corpus | Inputs | Tested contract |
| --- | ---: | --- |
| `simple_decompress` | 11,631 | Tail-selected compressed input, bounded decode, and successful content-size agreement |
| `zstd_frame_info` | 2,395 | Public frame-header parsing and metadata bounds |
| `decompress_dstSize_tooSmall` | 1,173 | Empty input success and nonempty insufficient output failure |
| `huf_decompress` | 605 | Both BMI-dependent parameter-consumption layouts; 604 successful table parses across both layouts |
| `huf_round_trip` | 833 | Both exact BMI layouts, every file and branch outcome; all requested and actual depths 1..12; safe/all-feature transcripts agree |
| `fse_read_ncount` | 79 | Complete writer/readback target with exact count selectors, random suffix bytes and consumed-header assertions |
| `stream_decompress` | 12,462 | Tail-selected chunks, bounded streaming progress, dictionary-free output/error parity and complete input replay |
| `stream_round_trip` | 24,223 | Complete selected source bytes, randomized supported chunk/directive schedules and exact decoded content |
| `dictionary_loader` | 2,271 | Exact tail-selected load modes; 1,919 exact roundtrips and 352 formatted-dictionary parse rejections |
| `raw_dictionary_round_trip` | 13,876 | Exact source/dictionary regions, prefix selection, checksum disabling, compression-bound destination and exact decoded content |
| `dictionary_decompress` | 12,063 | 11,768 trained dictionaries, 295 expected empty fallbacks; 20 bounded successful decodes and 12,043 malformed-source rejections |
| `dictionary_round_trip` | 30,925 | 30,722 trained dictionaries, 203 expected empty fallbacks; every source roundtrips exactly |
| `dictionary_stream_round_trip` | 24,223 | 23,821 trained dictionaries, 402 expected empty fallbacks; every adapted directive schedule restores exact content |

The normalized-count target is fully ported. Other targets retain partial
coverage for their unported API/control paths even when every selected input
passes. The source inventory records those distinctions. The 79-input FSE
corpus, both streaming corpora and all five dictionary corpora also passed safe release
builds; their random C compression parameters, stable-buffer, in-place,
by-reference and sequence-producer branches are not claimed by the adapters.
The three trained-target adapters preserve all 100 original sample-range
selectors, verified against C, and use independent Rust training with the same
explicit training-failure fallback. Their fastCover path is still partial.
The dictionary streaming archive is byte-identical to the ordinary streaming
roundtrip snapshot and has now also passed its separate dictionary target.

The sixteen selected archives contain 2,685,230,749 unpacked bytes. The importer
allows a 4 GiB combined snapshot while retaining its 1 GiB per-archive ceiling.
Each extraction is further bounded by that archive's pinned unpacked size, and
all member paths, sizes, CRCs, archive hashes and extracted-cache bytes are
verified before publication. Archives remain outside the repository.

The selected regression-directory adapter also passed all **512** Silesia and
GitHub inputs (**12,407,963 bytes**) with every named Rust strategy under safe
and all-feature release builds. Per-strategy complete frame fingerprints and
retained-capacity observations agree across backends.
The separately pinned GitHub dictionary is not consumed as a dictionary. This
run preserves complete input/output comparisons, while C compression method,
level, context, streaming, CLI, dictionary, and historical CSV baseline
comparisons remain unimplemented.

## Reproducible audit

Run the local structural audit with only the Python standard library:

```sh
python3 scripts/audit_upstream_tests.py
python3 scripts/check_upstream_fixtures.py
```

To additionally verify every source byte, the complete Git tree, and the
named source anchors, point it at an external v1.5.7 checkout:

```sh
ZSTD_UPSTREAM=/path/to/zstd-v1.5.7 python3 scripts/audit_upstream_tests.py
```

The audit validates statuses, source spans, duplicate IDs, local test files
and referenced Rust function names. It rejects a `ported` source with
unfinished child groups. It does not execute Rust tests; passing this audit
alone establishes inventory integrity, not behavioral parity.

The separate fixture audit checks all bytes listed by the golden,
decodecorpus, entropy, inline-regression, parameter, testcard, window-sequence,
and dictionary manifests.
It verifies sizes, SHA-256 values, upstream source hashes, local oracle source
hashes, optional importer and repository-input hashes, derived byte ranges, and
recorded expected-output metadata. Missing
fixtures/manifests, unlisted files, duplicate records, and paths outside a
fixture collection are errors. It uses only Python's standard library and
does not require a C compiler, upstream checkout, codec executable, or network.
Hash integrity does not replace the Rust assertions that actually decode the
fixtures; oracle regeneration remains available in each fixture importer's
`--check` mode.

The Module13 successor numeric port preserves all81 original selector packets
and their historical57/20/4 classifications. Current Fast/DoubleFast admission
executes61, rejects16 unsupported simple profiles and leaves four advanced
branches unconsumed. Tests identify exactly four added selector cases and compare
every original input hash, prefix, level and preset strategy. The original empty
-1..22 loop now admits five profiles; the30-byte1..19 loop admits three. Historical
3/21 and2/17 loop expectations remain in separately versioned fixtures. Context
reuse, caller-owned destination failure, forced streaming, decoder mutation and
in-place overlap remain explicit gaps; no source or case status is promoted to
complete merely because a new one-shot algorithm exists.

The completion gate is deliberately stricter:

```sh
python3 scripts/audit_upstream_tests.py --require-complete
```

This command must fail while any source test unit is partial, planned, or
blocked. It must also fail while external target coverage remains partial or
blocked, even after selected archives have been separately pinned and their
supported adapters pass. Downloaded archives are not in the v1.5.7 Git tree;
independent snapshot pins do not establish tag membership. An ordinary
`cargo test` cannot imply that optional external corpora were run.
