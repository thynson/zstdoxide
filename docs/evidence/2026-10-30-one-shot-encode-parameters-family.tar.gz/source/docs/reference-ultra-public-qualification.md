# Bounded Ultra public qualification

The main checkout now exposes the independently qualified bounded strategy-8
envelope. Module 18 is complete within that bounded scope: regression, native
interoperability, platform checks and complete-frame measurements are qualified.
The separate Ultra2 lifecycle and complete official test migration remain open.

Public strategy 8 uses the coupled pinned optLevel2 policy: fractional prices,
policy-tagged frequency/cache lifecycles, thorough relaxation and the
match-plus-literal alternative. Its complete fresh no-dictionary envelope is
64..16384 bytes fitting the selected window, W10..16, H/C6..12, S1..6,
minimum-match 3..7 and target 0..4095 after known-source resolution. Default levels
13/14 fit sources 64..2048. Larger supported sources require bounded explicit
settings. Strategy 9 remains unsupported; retained blocks, dictionaries, prefix,
LDM, workers, numeric streaming and window expiry remain outside this scope.

## Public admission and ownership

The candidate dispatcher selects only the independently qualified Ultra plan,
state and static frame branch. The original Optimal-specific constructor still
rejects Ultra. Source/geometry rejection occurs before allocator cloning, and
unsupported Ultra2 retains precedence over operational resource errors. The
candidate passes 34 public/regression tests in each of safe, all-feature and
release/all builds, four plan tests, strict safe/all-target Clippy, true no_std
and formatting. Initial qualification exposed one old classification expectation
at level 16/source 16385: its unchanged tuple resolves to implemented Ultra and
therefore returns ResourceLimit. The original input is preserved and only the
expectation now follows the resolved strategy. That failed run is retained.

Evidence: `evidence/2026-10-19-ultra-public-candidate.tar.gz`, SHA-256
`70a830a5785272ec6f614356f4e395fb0f36bcee26876851df42c1fc96f86261`.
No original selector, request, numeric size assertion or old fixture is rewritten.
Additive v7 admission fixtures preserve historical classifications and carry the
current outcome separately.

## Public foreign-platform checks

Eight selected strict-provenance Miri executions pass: two public tests on each
of i686 and s390x under safe and all-feature builds. They cover preallocation
rejection and a complete minimum-three-byte-key frame with borrowed non-Clone
allocator ownership. These are interpreted tests, not native foreign execution.
Safe/all thumbv6m true no_std checks and actual code generation of concrete
borrowed-Global public Ultra callers pass; IR and objects are retained. This
establishes a no-atomics build path, not firmware execution. The platform run
predates the unrelated level16 classification expectation correction; all
selected platform tests and 87 production source identities remain identical.

Evidence: `evidence/2026-10-19-ultra-public-platform.tar.gz`, SHA-256
`4e2ac9387bcca86e9cf2c624489c9877a9d60933cfe850042cd95b70b8e74fd2`.

## Executable usage and migration limits

All 24 standalone usage checks pass in safe and all-feature builds, including
positive Ultra default/explicit examples and existing compile-fail ownership
contracts. Rustdoc uses Cargo's actual library and metadata artifacts. The
separate allocator package passes 13 tests, strict Clippy and formatting.
The pinned upstream inventory and checkout source audit pass. The distinct
`--require-complete` gate remains nonzero: the official migration is unfinished.
Its diagnostic is an expected limitation, not a successful migration result.

Evidence archives: `evidence/2026-10-19-ultra-public-usage.tar.gz` and
`evidence/2026-10-19-ultra-public-support.tar.gz`.


## Admission source barrier

The main checkout copies exactly the 87 production identities used by the
qualified isolated candidate and both native Rust builds. The complete ordinary
focused product has passed: safe, all 19 isolated unsafe features and all
features together, with parser/search replay, borrowed fixture reading and true
no_std in every configuration (63 commands). Both original and additive native
auditors independently accept the complete captured campaign. The complete final regression product is recorded below. Both normal and optimized Python
adversarial-control campaigns now pass all 56 cases without child execution. The admission record
is `evidence/2026-10-19-ultra-public-admission.json`; it explicitly preserves
those unfinished campaign statuses instead of reporting module completion.

## Complete native public interoperability

The source-bound capture completes 15,132 commands for 1,345 source-only
recipes: 1,222 admitted, 108 resource-limited and 15 unsupported. Normal and
fully ASan/UBSan-instrumented C builds each compile all 26 relevant translation
units. Safe/all Rust frames are decoded by both C builds, and both C frames are
decoded by both Rust builds: 4,888 frames in each direction, 800,050,968 decoded
bytes. All 4,636 predecessor successful encoded responses retain exact bytes.
The 156 malformed-adapter exits are expected exit 2, not crashes or unreported
failures. Interoperability does not imply identical C/Rust compression bytes.

The original, v2 and v3 independent positive audits all pass. V3 normal and
optimized Python each reject 56 forged evidence cases with zero child attempts.
The earlier slow v1/v2 control runs remain explicitly interrupted; their sources,
mutation snapshots and logs are retained and do not contribute passing controls.
See the additive [v3 audit review](reference-ultra-interop-audit-v3.md).

The lossless archive retains all 45,671 regular capture artifacts, including
source snapshots, exact executables, request/response bytes, compiler outputs,
preflight and interrupted-control evidence. Its 2,599,322,696 logical bytes are
stored in 53,344,105 compressed bytes using content-addressed chunks. Every
member and every reconstructed original file were independently rehashed.
Evidence: `evidence/2026-10-19-ultra-public-interop.tar.gz`, SHA-256
`fc99f273d801db8319a55a0352d9a8cd1ad4588494a4d3a5e4e404881ee5d073`.
The adjacent JSON records the complete archive and capture identities.

## Complete public regression product

All 22 configuration products are complete: safe, nineteen isolated unsafe
features, all features, and release/all. Each has the same 1460 individual
case/outcome records: 1405 passes and 55 explicit ignores. This is 30910 passing
and 1210 ignored executions, with 21 true no_std builds. Strict safe/all Clippy,
formatting, allocator support and 48 executable usage checks are qualified by
the unchanged earlier records. Ignored official cases remain open obligations.

Six original 1800-second Cargo attempts timed out without assertion failures.
Sixteen suites completed in one successful invocation; six were completed from
verified prefixes and explicit integration/doc continuations. A prefix group
counts only when Cargo subsequently started the next group. The final child is
rerun even if orphaned output later reported success. Exact individual names and
outcomes match the complete safe suite. All 49 final successful command records
are retained, as are the failed timeout records and both earlier interrupted
schedulers. The summary's zero unresolved failures does not erase those attempts.

The initial before/after snapshot covers 396 selected file formats. A supplemental
check binds 933 additional inherited files, including binary corpora and native
stdout fixtures, to Git blobs preceding public qualification; all match current
main and the frozen candidate. Two later frame-baseline files have their separate
native/clock-free pins, and the generated allocator lockfile is compared directly.
This supplemental check does not invent contemporaneous hashes for formats absent
from the initial inventory. Similarly, the scoped platform inventory is supplemented
with unchanged pre-qualification Git identities for its unrecorded allocator
manifest and native-only oracle example; the latter is not compiled by Miri.

The review archive preserves every raw campaign and 720 regular bundle files.
All 1332 complete inputs are reconstructible from 1331 exact local Git blobs plus
one stored generated lockfile, with independent SHA-256/length checks. It avoids
duplicating large inherited corpora already held in Git; the redundant full-input
archive remains outside the repository and its report is retained.
Evidence: `evidence/2026-10-19-ultra-public-matrix.tar.gz`, SHA-256
`3b40b63560b7b4a0575d82b492fe76b3f1d733091933b9ce5c22cadc743f9c87`.

## Complete-frame measurements and final reconciliation

The clock-free survey verifies 26 complete sources across all 21 backends,
including exact output bytes, allocation ledgers and zero residual live owners.
The primary timed campaign and independent safe/all repeat retain 598 case rows
and 2990 samples. The all/safe aggregate cost direction changes (1.0395 versus
0.8782), so these data do not establish a stable unsafe speedup. Exact samples,
compiled executables, source-bound CPU barriers and normal/optimized malformed
controls are preserved in [the frame report](reference-ultra-frame-benchmark.md).

Final formatting, focused safe/all Ultra tests, strict all-target Clippy safe/all
and true no_std safe/all pass again on unchanged production sources. The full
22-product matrix above remains the full-regression evidence; focused checks do
not replace it. Historical failures, timeouts and scoped source supplements are
retained. The final reconciliation verifies archive/report hashes and unchanged
current source inventories without reclassifying historical checkpoints.

Closure: `evidence/2026-10-20-ultra-closure.json`. The completed Module 18 checklist
is archived in Git history and `progress.md`; Module 19 retains its independent
Ultra2 decomposition. Strategy 9 remains unsupported. Official ignored cases,
188 unfinished upstream source units, retained/dictionary public Ultra, CLI and
other excluded features remain open; this milestone does not imply full parity.
