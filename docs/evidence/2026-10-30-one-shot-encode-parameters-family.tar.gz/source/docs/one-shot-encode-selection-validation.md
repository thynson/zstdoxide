# One-shot encode selection validation

Module 35 is complete within its call-scoped dictionary/prefix selection
scope for caller-owned one-shot compression. Focused, guarded native/corpus,
platform, complete feature/release and independent measurement gates have
successful source-bound receipts.

## Internal clone-free coordinator

OneShotEncoder wraps the existing plain Selection/Claimed ownership records over
any dictionary handle type. A persistent selection is borrowed for every call; a
pending prefix is claimed by an exclusive replacement before any codec or
allocator operation, and the claimed owner lives until the attempt returns or
unwinds. No handle is cloned, no dictionary content is copied, and no encoder
workspace is retained between calls. The private module is exposed only by the
subsequent qualified API item. Selection and Claimed remain plain ownership
records with one safe representation.

Seventeen focused commands pass: the four coordinator units and the four
selection-record units under safe, isolated frame-sink, isolated dictionary and
all 22 feature selections, each with true no_std compilation and strict Clippy,
plus formatting. The claim consumes prefixes before output admission, empty
input, short output and every observed allocation failure, while the
independent dictionary owner's snapshot stays unchanged.
Evidence: `evidence/2026-10-28-one-shot-encode-engine.json`.

## Public caller-owned selection methods

OneShotEncoder::new/without_dictionary/with_dictionary/with_prefix construct and
replace call-scoped selections; dictionary()/prefix_pending() borrow immutable
selection metadata. compress_into/compress_into_in compress one frame into
independent caller storage with Global or supplied scratch, consume a pending
prefix before output admission or any allocator operation, and retain a
persistent selection across calls and errors. Documented lifetime compile-fail
examples establish owner and borrow non-overlap. No handle clone, dictionary
copy, retained workspace or whole-call output atomicity is introduced.

Twenty-one focused commands pass across safe, isolated frame-sink, isolated
dictionary and all 22 feature selections: four coordinator units, six public
integration tests and three doctest groups each, with true no_std compilation
and strict Clippy, plus formatting. Attempt-exact consumption, short-output
recovery, replacement/clearing drops and every observed scratch failure keep
independent owner domains.
Evidence: `evidence/2026-10-28-one-shot-encode-public-api.json`.

## Guarded native schedules and deterministic trained selections

Twenty-seven typed native context schedules across raw/empty/prepared selections
cover persistent reuse, prefix consumption and subsequent calls. Pinned v1.5.7
normal and sanitized helpers produce 87 native rows over {'steps.tsv': 'ecec1023e08d212ea8380d24c41007a6d2e741b11404c31fd3d952d98dbe11a2', 'inputs/rawmagic-persistent-short-2.rust': 'bd57a52b14e3670c786c5ef4c8879a94beaf808c713b8556fb1b8de29c9933e7', 'inputs/raw-prefix-empty-1.rust': 'f96deff1816083fdff8bc3e46c3fe6ca46a6bb49f4d5a00627616c13237a512c', 'inputs/rawmagic-b.dict': 'be09ef154363825af0777603205ef2be9ae7739e1bffbb7f1c40a3f2444e2797', 'inputs/prepared-persistent-short-2.rust': 'cf4021e24e85c210b185a70d143b67d2b194169898c384b3b1634cddbbe90383', 'inputs/raw-prefix-to-persistent-3.rust': 'a4d63d538bcac9d5603a2dc7e9e74f865ab9328b0529b97ea7d12900a465cf09', 'inputs/prepared-a.dict': 'a969cd4a5c1e6624afbf6e9accf15b5a75b430e47d57999ec75c70bc36cc0074', 'inputs/raw.input': 'f645dab32a7f6b691a60d1270059b6766060be037ca5e99fb11d92ac972615b0', 'inputs/raw-prefix-1.rust': 'ebc4805168435f553614fa4364f47466e416a2ebd3a255320937375bb86c80ce', 'inputs/raw-b.dict': '0c8f44f796cd901962e1112f37e965d1fdfb0ce8657334792f73927cdcc348c3', 'inputs/raw-prefix-to-persistent-2.rust': 'a4d63d538bcac9d5603a2dc7e9e74f865ab9328b0529b97ea7d12900a465cf09', 'inputs/raw-prefix-short-2.rust': 'e5ffbb9f7f925d31041930abb5ead519095c19b66180abcb8527a74704b6f2aa', 'inputs/raw-persistent-2.rust': 'ebc4805168435f553614fa4364f47466e416a2ebd3a255320937375bb86c80ce', 'inputs/prepared-prefix-empty-2.rust': 'bc35d6796bc10a43db29cf1844ba0981d622321cd2b54555893bcf83a4abc2d0', 'inputs/rawmagic-prefix-short-2.rust': 'ef3fa6941ca3706dcace8e2fe12f38c0edbe901f7533875f8bc639163e653a47', 'inputs/rawmagic-prefix-to-persistent-3.rust': '647c49f8778a165004a28c2a351ae4ae67d5cf573314bb55d28b7a326883a8c9', 'inputs/prepared-clear-prefix-2.rust': 'bc35d6796bc10a43db29cf1844ba0981d622321cd2b54555893bcf83a4abc2d0', 'inputs/prepared-prefix-to-persistent-2.rust': '88d2258c56d26d058c610dc81b46e56ce0177de90fd60e46edbd2d7890a5dff2', 'inputs/rawmagic.input': '71c944178ddfde33a65838268629d641df6ae4b5edc6de589b3c933c76b3a694', 'inputs/prepared-prefix-to-persistent-3.rust': '88d2258c56d26d058c610dc81b46e56ce0177de90fd60e46edbd2d7890a5dff2', 'inputs/prepared-clear-persistent-2.rust': 'bc35d6796bc10a43db29cf1844ba0981d622321cd2b54555893bcf83a4abc2d0', 'inputs/rawmagic-clear-persistent-2.rust': 'ef3fa6941ca3706dcace8e2fe12f38c0edbe901f7533875f8bc639163e653a47', 'inputs/prepared-persistent-2.rust': 'cf4021e24e85c210b185a70d143b67d2b194169898c384b3b1634cddbbe90383', 'inputs/rawmagic-prefix-to-persistent-2.rust': '647c49f8778a165004a28c2a351ae4ae67d5cf573314bb55d28b7a326883a8c9', 'inputs/rawmagic-persistent-2.rust': 'bd57a52b14e3670c786c5ef4c8879a94beaf808c713b8556fb1b8de29c9933e7', 'inputs/rawmagic-prefix-empty-1.rust': 'f96deff1816083fdff8bc3e46c3fe6ca46a6bb49f4d5a00627616c13237a512c', 'inputs/prepared-prefix-1.rust': 'cf4021e24e85c210b185a70d143b67d2b194169898c384b3b1634cddbbe90383', 'inputs/rawmagic-prefix-2.rust': 'ef3fa6941ca3706dcace8e2fe12f38c0edbe901f7533875f8bc639163e653a47', 'inputs/prepared-persistent-1.rust': 'cf4021e24e85c210b185a70d143b67d2b194169898c384b3b1634cddbbe90383', 'inputs/raw-persistent-to-prefix-3.rust': 'e5ffbb9f7f925d31041930abb5ead519095c19b66180abcb8527a74704b6f2aa', 'inputs/rawmagic-persistent-1.rust': 'bd57a52b14e3670c786c5ef4c8879a94beaf808c713b8556fb1b8de29c9933e7', 'inputs/prepared-prefix-short-2.rust': 'bc35d6796bc10a43db29cf1844ba0981d622321cd2b54555893bcf83a4abc2d0', 'inputs/rawmagic-prefix-empty-2.rust': 'ef3fa6941ca3706dcace8e2fe12f38c0edbe901f7533875f8bc639163e653a47', 'inputs/prepared-prefix-2.rust': 'bc35d6796bc10a43db29cf1844ba0981d622321cd2b54555893bcf83a4abc2d0', 'inputs/rawmagic-prefix-1.rust': 'bd57a52b14e3670c786c5ef4c8879a94beaf808c713b8556fb1b8de29c9933e7', 'inputs/rawmagic-clear-prefix-2.rust': 'ef3fa6941ca3706dcace8e2fe12f38c0edbe901f7533875f8bc639163e653a47', 'inputs/raw-persistent-short-2.rust': 'ebc4805168435f553614fa4364f47466e416a2ebd3a255320937375bb86c80ce', 'inputs/prepared.input': '4d974f0f0908dc004600a123fd5d4aad4e3f7a465916254940c16a18b19a068f', 'inputs/empty.input': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'inputs/raw-persistent-1.rust': 'ebc4805168435f553614fa4364f47466e416a2ebd3a255320937375bb86c80ce', 'inputs/prepared-prefix-empty-1.rust': '7e4e08c9dc8a273c5eccd4ba8e48c42de14e6719be07fab7cb2bda6f8ab6d23c', 'inputs/raw-persistent-to-prefix-2.rust': 'a4d63d538bcac9d5603a2dc7e9e74f865ab9328b0529b97ea7d12900a465cf09', 'inputs/raw-clear-persistent-2.rust': 'e5ffbb9f7f925d31041930abb5ead519095c19b66180abcb8527a74704b6f2aa', 'inputs/prepared-persistent-to-prefix-2.rust': '88d2258c56d26d058c610dc81b46e56ce0177de90fd60e46edbd2d7890a5dff2', 'inputs/raw-a.dict': 'b79a5efa3743c1f1dc4017b54b0be4839ad22fc0d3d49dd197df48dc4f25291d', 'inputs/rawmagic-persistent-to-prefix-3.rust': 'ef3fa6941ca3706dcace8e2fe12f38c0edbe901f7533875f8bc639163e653a47', 'inputs/rawmagic-persistent-to-prefix-2.rust': '647c49f8778a165004a28c2a351ae4ae67d5cf573314bb55d28b7a326883a8c9', 'inputs/prepared-b.dict': '42d58f1e524b53942a8a5a02d0564d4379be52dd0d9fdc9c357d49ed2a506f6f', 'inputs/raw-clear-prefix-2.rust': 'e5ffbb9f7f925d31041930abb5ead519095c19b66180abcb8527a74704b6f2aa', 'inputs/raw-prefix-2.rust': 'e5ffbb9f7f925d31041930abb5ead519095c19b66180abcb8527a74704b6f2aa', 'inputs/prepared-persistent-to-prefix-3.rust': 'bc35d6796bc10a43db29cf1844ba0981d622321cd2b54555893bcf83a4abc2d0', 'inputs/raw-prefix-empty-2.rust': 'e5ffbb9f7f925d31041930abb5ead519095c19b66180abcb8527a74704b6f2aa', 'inputs/rawmagic-a.dict': '80b807b9a7a28c45c9b012315309c2c49bbbc0c3f7b4d76c0d9995aa01c45e3b'} inputs and retain {'prepared-clear-persistent-2.zst': '7dd07e044d4099d4133618678198fff3a9502d27e7bfbb28798fce6bb69a7514', 'prepared-persistent-to-prefix-2.storage': 'fca3af2cdc9f6fd7ff26b0035a9379fd2b630b0519f97fb0de2ebc11b7bad0b2', 'rawmagic-prefix-empty-1.storage': '459d7778af1e7bd56e62423e2528f418c29dbe29653e39acb84f3ea30e6de875', 'rawmagic-prefix-short-1.storage': 'fc8b64001c5fdd0f2f40fb67dae4a865a2c5bd17836676d6d5b58b7917e33717', 'control-raw-a-prefix.zst': '8411fc6a6088d4c954c68d33efbb66a3e8f56ff1908e57ba077f7e04b536e04c', 'raw-prefix-to-persistent-2.storage': '15d2106cf7c28136f4424ad6c16485bf48afbe4073df11cc22af39ee3bcec5db', 'prepared-prefix-2.storage': '033f53a96fa2a3e5990cf336fb90ef640f7455215f70bb946afab0a7475f5987', 'control-raw-a-persistent.zst': '64242a8c4a91a57a82a98a6d9dc699e69236269c2e0e68eef8c02e54bd206ae2', 'raw-persistent-1.storage': 'c1e57bda1c89a3403c078bb90c6312f867205bb8253171645bdbff25c28cc536', 'raw-persistent-short-1.storage': 'fc8b64001c5fdd0f2f40fb67dae4a865a2c5bd17836676d6d5b58b7917e33717', 'raw-prefix-short-2.zst': 'bb1fe175dbe220b1263a89a94db6ad3293ffa35b766d8c4edefde557cbd57f3b', 'rawmagic-persistent-2.zst': '99faff221e3e9696c9d904010a40fe795ca3a7f3f8900dc09d8ef0cb1c3bf330', 'control-prepared-a-persistent.zst': 'a35e995dcc9b6b389b4cbd3d8ce0c85651bebf8bde530cc64f5ae0089715a99f', 'rawmagic-persistent-short-1.storage': 'fc8b64001c5fdd0f2f40fb67dae4a865a2c5bd17836676d6d5b58b7917e33717', 'prepared-prefix-empty-1.storage': 'f570fdc7575fd8d76eba6ca7043b51de9214dd4488f222db21d5ad0bdb24a799', 'prepared-persistent-to-prefix-3.storage': '033f53a96fa2a3e5990cf336fb90ef640f7455215f70bb946afab0a7475f5987', 'rawmagic-persistent-1.zst': '99faff221e3e9696c9d904010a40fe795ca3a7f3f8900dc09d8ef0cb1c3bf330', 'rawmagic-clear-persistent-2.zst': 'cb9144122a0860328cd4d80e3b608d0e8b79e9d61839a13f1351d0c4ad7677d0', 'rawmagic-persistent-2.storage': 'f6065f6fc629976d554f42ef720b8467eff688b76918d53b6dd9fa535f7a0770', 'control-rawmagic-a-prefix.zst': 'c126d358d44b2022aeef91456398cdf61e3bd1fbfcc09ab4326e5f46b3f5788f', 'raw-prefix-to-persistent-3.storage': '15d2106cf7c28136f4424ad6c16485bf48afbe4073df11cc22af39ee3bcec5db', 'prepared-prefix-short-1.storage': 'fc8b64001c5fdd0f2f40fb67dae4a865a2c5bd17836676d6d5b58b7917e33717', 'prepared-prefix-to-persistent-2.zst': '95f6e52a4f5aded4003981252f23d61e4081566733f4f570b22eae84804f79bd', 'raw-persistent-to-prefix-2.zst': 'a4d63d538bcac9d5603a2dc7e9e74f865ab9328b0529b97ea7d12900a465cf09', 'raw-persistent-2.storage': 'c1e57bda1c89a3403c078bb90c6312f867205bb8253171645bdbff25c28cc536', 'rawmagic-prefix-to-persistent-3.storage': '0c0299f556354b721c9c49a3b78784f9b1749e5993e641b333100ccc7fec5609', 'raw-persistent-to-prefix-3.zst': 'bb1fe175dbe220b1263a89a94db6ad3293ffa35b766d8c4edefde557cbd57f3b', 'raw-persistent-short-2.storage': 'c1e57bda1c89a3403c078bb90c6312f867205bb8253171645bdbff25c28cc536', 'rawmagic-prefix-1.zst': 'c126d358d44b2022aeef91456398cdf61e3bd1fbfcc09ab4326e5f46b3f5788f', 'prepared-prefix-to-persistent-3.zst': '95f6e52a4f5aded4003981252f23d61e4081566733f4f570b22eae84804f79bd', 'rawmagic-prefix-empty-2.storage': 'b15d8932cf321437d69e458308da15aef55e29677d40a3a44d43bf986451de4e', 'rawmagic-clear-prefix-2.zst': 'cb9144122a0860328cd4d80e3b608d0e8b79e9d61839a13f1351d0c4ad7677d0', 'prepared-prefix-1.storage': '795fa9f1ae8978f6035fa3b06f2a6c40fee231344f3bb55d04b8444afa13a9f6', 'rawmagic-prefix-2.zst': 'cb9144122a0860328cd4d80e3b608d0e8b79e9d61839a13f1351d0c4ad7677d0', 'control-raw-b-persistent.zst': 'a4d63d538bcac9d5603a2dc7e9e74f865ab9328b0529b97ea7d12900a465cf09', 'rawmagic-prefix-short-2.storage': 'b15d8932cf321437d69e458308da15aef55e29677d40a3a44d43bf986451de4e', 'rawmagic-clear-persistent-2.storage': 'b15d8932cf321437d69e458308da15aef55e29677d40a3a44d43bf986451de4e', 'control-prepared-b-prefix.zst': '95f6e52a4f5aded4003981252f23d61e4081566733f4f570b22eae84804f79bd', 'prepared-prefix-empty-2.storage': '033f53a96fa2a3e5990cf336fb90ef640f7455215f70bb946afab0a7475f5987', 'rawmagic-prefix-empty-1.zst': 'f96deff1816083fdff8bc3e46c3fe6ca46a6bb49f4d5a00627616c13237a512c', 'control-prepared-b-persistent.zst': '95f6e52a4f5aded4003981252f23d61e4081566733f4f570b22eae84804f79bd', 'prepared-prefix-short-2.storage': '033f53a96fa2a3e5990cf336fb90ef640f7455215f70bb946afab0a7475f5987', 'raw-persistent-1.zst': '64242a8c4a91a57a82a98a6d9dc699e69236269c2e0e68eef8c02e54bd206ae2', 'observability.tsv': '05dd0bd598701c617ee0d09cb4938476e931d26ec52c7168580031be5ca12b67', 'rawmagic-persistent-1.storage': 'f6065f6fc629976d554f42ef720b8467eff688b76918d53b6dd9fa535f7a0770', 'raw-clear-persistent-2.storage': 'a401f9d3b60e9db87ad0bc104a3aa6f30beb599ca4d4f1bcf0ea3e86e7061c7f', 'prepared-prefix-short-2.zst': '7dd07e044d4099d4133618678198fff3a9502d27e7bfbb28798fce6bb69a7514', 'raw-clear-prefix-2.storage': 'a401f9d3b60e9db87ad0bc104a3aa6f30beb599ca4d4f1bcf0ea3e86e7061c7f', 'rawmagic-persistent-to-prefix-2.zst': 'e5c413e91a547360e3bfe9f966a168a59ef59fe9473564bee5b1c16f6f2e65ca', 'rawmagic-prefix-to-persistent-2.storage': '0c0299f556354b721c9c49a3b78784f9b1749e5993e641b333100ccc7fec5609', 'rawmagic-prefix-empty-2.zst': 'cb9144122a0860328cd4d80e3b608d0e8b79e9d61839a13f1351d0c4ad7677d0', 'rawmagic-persistent-short-2.storage': 'f6065f6fc629976d554f42ef720b8467eff688b76918d53b6dd9fa535f7a0770', 'raw-persistent-2.zst': '64242a8c4a91a57a82a98a6d9dc699e69236269c2e0e68eef8c02e54bd206ae2', 'raw-persistent-short-2.zst': '64242a8c4a91a57a82a98a6d9dc699e69236269c2e0e68eef8c02e54bd206ae2', 'rawmagic-persistent-to-prefix-3.zst': 'cb9144122a0860328cd4d80e3b608d0e8b79e9d61839a13f1351d0c4ad7677d0', 'prepared-persistent-2.storage': '795fa9f1ae8978f6035fa3b06f2a6c40fee231344f3bb55d04b8444afa13a9f6', 'control-prepared-a-prefix.zst': 'a35e995dcc9b6b389b4cbd3d8ce0c85651bebf8bde530cc64f5ae0089715a99f', 'raw-prefix-1.zst': '8411fc6a6088d4c954c68d33efbb66a3e8f56ff1908e57ba077f7e04b536e04c', 'raw-clear-prefix-2.zst': 'bb1fe175dbe220b1263a89a94db6ad3293ffa35b766d8c4edefde557cbd57f3b', 'prepared-persistent-to-prefix-2.zst': '95f6e52a4f5aded4003981252f23d61e4081566733f4f570b22eae84804f79bd', 'raw-prefix-to-persistent-2.zst': 'a4d63d538bcac9d5603a2dc7e9e74f865ab9328b0529b97ea7d12900a465cf09', 'raw-clear-persistent-2.zst': 'bb1fe175dbe220b1263a89a94db6ad3293ffa35b766d8c4edefde557cbd57f3b', 'rawmagic-prefix-1.storage': 'd5ec0a62258030f815df2ba2cb84fa4e35b9d18d6452e3c31b26ef81c94ae2fa', 'raw-prefix-to-persistent-3.zst': 'a4d63d538bcac9d5603a2dc7e9e74f865ab9328b0529b97ea7d12900a465cf09', 'rawmagic-persistent-to-prefix-2.storage': '0c0299f556354b721c9c49a3b78784f9b1749e5993e641b333100ccc7fec5609', 'raw-prefix-2.zst': 'bb1fe175dbe220b1263a89a94db6ad3293ffa35b766d8c4edefde557cbd57f3b', 'prepared-persistent-short-2.storage': '795fa9f1ae8978f6035fa3b06f2a6c40fee231344f3bb55d04b8444afa13a9f6', 'prepared-persistent-to-prefix-3.zst': '7dd07e044d4099d4133618678198fff3a9502d27e7bfbb28798fce6bb69a7514', 'raw-prefix-2.storage': 'a401f9d3b60e9db87ad0bc104a3aa6f30beb599ca4d4f1bcf0ea3e86e7061c7f', 'rawmagic-prefix-to-persistent-2.zst': 'e5c413e91a547360e3bfe9f966a168a59ef59fe9473564bee5b1c16f6f2e65ca', 'control-rawmagic-b-persistent.zst': 'e5c413e91a547360e3bfe9f966a168a59ef59fe9473564bee5b1c16f6f2e65ca', 'raw-prefix-empty-1.storage': '459d7778af1e7bd56e62423e2528f418c29dbe29653e39acb84f3ea30e6de875', 'rawmagic-persistent-to-prefix-3.storage': 'b15d8932cf321437d69e458308da15aef55e29677d40a3a44d43bf986451de4e', 'raw-prefix-short-1.storage': 'fc8b64001c5fdd0f2f40fb67dae4a865a2c5bd17836676d6d5b58b7917e33717', 'rawmagic-prefix-to-persistent-3.zst': 'e5c413e91a547360e3bfe9f966a168a59ef59fe9473564bee5b1c16f6f2e65ca', 'raw-prefix-empty-1.zst': 'f96deff1816083fdff8bc3e46c3fe6ca46a6bb49f4d5a00627616c13237a512c', 'prepared-clear-persistent-2.storage': '033f53a96fa2a3e5990cf336fb90ef640f7455215f70bb946afab0a7475f5987', 'raw-prefix-empty-2.zst': 'bb1fe175dbe220b1263a89a94db6ad3293ffa35b766d8c4edefde557cbd57f3b', 'rawmagic-prefix-2.storage': 'b15d8932cf321437d69e458308da15aef55e29677d40a3a44d43bf986451de4e', 'prepared-prefix-empty-1.zst': '7e4e08c9dc8a273c5eccd4ba8e48c42de14e6719be07fab7cb2bda6f8ab6d23c', 'raw-prefix-1.storage': '2e4646e7977bab75844ba2ad805fc0da04a3e7299ea2c38cd4c05e36b4136f72', 'prepared-persistent-short-1.storage': 'fc8b64001c5fdd0f2f40fb67dae4a865a2c5bd17836676d6d5b58b7917e33717', 'prepared-persistent-1.storage': '795fa9f1ae8978f6035fa3b06f2a6c40fee231344f3bb55d04b8444afa13a9f6', 'raw-persistent-to-prefix-3.storage': 'a401f9d3b60e9db87ad0bc104a3aa6f30beb599ca4d4f1bcf0ea3e86e7061c7f', 'control-rawmagic-b-prefix.zst': 'e5c413e91a547360e3bfe9f966a168a59ef59fe9473564bee5b1c16f6f2e65ca', 'prepared-prefix-empty-2.zst': '7dd07e044d4099d4133618678198fff3a9502d27e7bfbb28798fce6bb69a7514', 'rawmagic-clear-prefix-2.storage': 'b15d8932cf321437d69e458308da15aef55e29677d40a3a44d43bf986451de4e', 'rawmagic-persistent-short-2.zst': '99faff221e3e9696c9d904010a40fe795ca3a7f3f8900dc09d8ef0cb1c3bf330', 'rawmagic-prefix-short-2.zst': 'cb9144122a0860328cd4d80e3b608d0e8b79e9d61839a13f1351d0c4ad7677d0', 'prepared-prefix-to-persistent-3.storage': 'fca3af2cdc9f6fd7ff26b0035a9379fd2b630b0519f97fb0de2ebc11b7bad0b2', 'raw-persistent-to-prefix-2.storage': '15d2106cf7c28136f4424ad6c16485bf48afbe4073df11cc22af39ee3bcec5db', 'prepared-clear-prefix-2.storage': '033f53a96fa2a3e5990cf336fb90ef640f7455215f70bb946afab0a7475f5987', 'control-raw-b-prefix.zst': 'a4d63d538bcac9d5603a2dc7e9e74f865ab9328b0529b97ea7d12900a465cf09', 'control-rawmagic-a-persistent.zst': '99faff221e3e9696c9d904010a40fe795ca3a7f3f8900dc09d8ef0cb1c3bf330', 'prepared-persistent-2.zst': 'a35e995dcc9b6b389b4cbd3d8ce0c85651bebf8bde530cc64f5ae0089715a99f', 'prepared-persistent-short-2.zst': 'a35e995dcc9b6b389b4cbd3d8ce0c85651bebf8bde530cc64f5ae0089715a99f', 'prepared-prefix-to-persistent-2.storage': 'fca3af2cdc9f6fd7ff26b0035a9379fd2b630b0519f97fb0de2ebc11b7bad0b2', 'prepared-prefix-2.zst': '7dd07e044d4099d4133618678198fff3a9502d27e7bfbb28798fce6bb69a7514', 'raw-prefix-empty-2.storage': 'a401f9d3b60e9db87ad0bc104a3aa6f30beb599ca4d4f1bcf0ea3e86e7061c7f', 'prepared-persistent-1.zst': 'a35e995dcc9b6b389b4cbd3d8ce0c85651bebf8bde530cc64f5ae0089715a99f', 'prepared-clear-prefix-2.zst': '7dd07e044d4099d4133618678198fff3a9502d27e7bfbb28798fce6bb69a7514', 'raw-prefix-short-2.storage': 'a401f9d3b60e9db87ad0bc104a3aa6f30beb599ca4d4f1bcf0ea3e86e7061c7f', 'prepared-prefix-1.zst': 'a35e995dcc9b6b389b4cbd3d8ce0c85651bebf8bde530cc64f5ae0089715a99f'} outputs; 48 attempts include 42 successes and 6 capacity errors, with 39 observed unused-suffix mutations retained as native behavior. Twelve observable fresh
no-prefix/selected-prefix controls anchor every comparison; zero subsequent
control differences remain unexplained. Rust frames decode natively and native
frames decode in Rust across selections. Native compressed-byte identity,
capacity precedence, workspace allocation or full context semantics are not
Rust contracts; ASan leak detection is unavailable on this macOS runtime and is
not credited.

The merged trained-dictionary adapter retains module34's persistent-only
dictionary caller-output helper and module35's all-selection encode helper in
one file. Controlled runs retain 104 encode-selection and 48 dictionary-output ledger rows; noise runs retain 13 and 11 rows. Safe, isolated frame-sink, isolated dictionary and all-feature selections
produce byte-identical ledgers, themselves byte-identical to the qualified
module34 and module35 predecessor corpus ledgers. Original selectors, training
and reduced-bound assertions are unchanged; no external rolling corpus rerun or
fastCover equivalence is claimed.
Evidence: `evidence/2026-10-27-one-shot-encode-native.json` and
`evidence/2026-10-28-one-shot-encode-corpus.json`.

## Foreign Miri and concrete no-atomics ARM emission

Four strict-provenance i686 and s390x Miri runs execute actual raw/prepared
selection attempts: empty/success/short outcomes, prefix consumption, persistent
recovery, exact stateless bytes, dictionary identifier endian layout, known
content size, independent decode and guards. Four concrete thumbv6m no-atomics
checks and object emissions (safe and all features) retain LLVM IR and objects
for the selection paths. Foreign validation checks ownership transitions and
actual encoding only; native context workspace semantics are not claimed.
Evidence: `evidence/2026-10-28-one-shot-encode-platform.json`.

## Complete feature and release qualification

All 75 commands pass on the final frozen candidate: safe/all and every 22
isolated unsafe feature each execute complete tests, true no_std compilation and
strict Clippy; safe/all release and formatting also pass. Each complete/release
suite reports 1766 passed and 76 ignored across 117 result groups. The campaign
was interrupted once at a user work-window boundary after a fully successful
prefix and resumed under a new authorization; no partial command is credited and
the interrupted log is retained. Native adapters are explicitly executed in
their separate focused capture/replay receipts.

The final candidate combines the qualified public production delta, retained
module34 native/platform adapters, the module35 native/platform tests and the
merged trained-dictionary adapter. Integrated production and all matrix source
identities are rechecked before this item is committed, with the authorized
post32 FUZZER.md and reason-reconciliation manifest.json results retained over
the campaign inputs. Measurements and closure remain open.
Evidence: `evidence/2026-10-29-one-shot-encode-feature-matrix.json`.

## Stateless/coordinator selection measurements

All 24 primary feature backends and independently rebuilt safe/all repeats
retain 675 timing samples and 297 role-specific qualification rows per
executable. The stateless baseline, persistent coordinator and both prefix
rearm placements borrow the same immutable view and write the same caller
destination. Per-attempt compression clocks include all Global scratch
allocation/release; rearming is excluded or included exactly as labeled, and
every attempt starts selected and ends consumed or persistent. Dictionary
construction/release, byte/guard validation and role-routed ledgers stay
outside clocks, with unchanged dictionary snapshots during every selected call.
Setup-only arm/observe/clear batch observations include loop and black-box
overhead and are not a directly subtractable estimate. Fixed-order ratios do
not establish a universal unsafe benefit or eliminate scratch allocations. See
`one-shot-encode-benchmarks.md` and
`evidence/2026-10-29-one-shot-encode-benchmarks.json`.

## Final reconciliation and remaining scope

Integrated production and matrix sources match the qualified public/native/
platform/corpus and measured snapshots; every stage archive is rehashed. The
repository retains the authorized post32 FUZZER.md and reason-reconciliation
manifest.json results over the pre-apply campaign inputs, with both sides
verified rather than silently overwritten. Earlier internal snapshots retain
their distinct identities. No new supplemental native or deterministic corpus
case promotes an original upstream group by inference.

Parameterized dictionary-backed one-shot compression is designed and decomposed
next. Reference levels with LDM, streaming variants, native workspace/reset
semantics, threading and complete upstream library/CLI parity remain open.
Short output may retain earlier complete appends; all writes remain within the
caller slice, and the dictionary is unchanged.
Evidence: `evidence/2026-10-29-one-shot-encode-closure.json`.
