"""Promote the qualified module36 Greedy chain-and-row family extension."""
from pathlib import Path
import json, hashlib, subprocess, shutil

D = Path(__file__).parent
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
S = Path('/private/tmp/module36-family/source')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = Path('/private/tmp/module36-archives/promotion-state.json')
prev = json.loads(state.read_text())
assert prev['stage'] == 'double-fast'
assert prev['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == prev['production_source']
name = '2026-10-30-one-shot-encode-parameters-family'
p = D / (name + '.json')
r = json.loads(p.read_text())
assert r['status'] == 'passed' and sha(D / r['archive']) == r['archive_sha256']
changed = []
for n in ['src/greedy_key.rs', 'src/greedy_state.rs', 'src/reference_frame_encode.rs', 'src/reference_search.rs']:
    assert sha(S / n) == r['source'][n], n
    shutil.copyfile(S / n, R / n)
    changed.append(n)
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == r['production_source']
for q in [p, D / r['archive']]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
    changed.append('docs/evidence/' + q.name)
p = R / 'TODO.md'
s = p.read_text()
task = '- [ ] Extend combined dictionary emission to the Greedy/Lazy/Lazy2 chain and row family.'
assert s.count(task) == 1
s = s.replace(task, task.replace('[ ]', '[x]'))
p.write_text(s)
changed.append('TODO.md')
p = R / 'docs/one-shot-encode-parameters-validation.md'
s = p.read_text()
old = '''Module 36 is in progress. Only the internal combined-staging engine and its
DoubleFast extension are qualified and integrated. Public parameterized
dictionary APIs, the remaining profile families, native/corpus/platform
validation, the complete feature/release regression, measurements and
reconciliation remain open.'''
assert s.count(old) == 1
s = s.replace(old, '''Module 36 is in progress. Only the internal combined-staging engine, its
DoubleFast extension and the Greedy chain-and-row family extension are
qualified and integrated. Public parameterized dictionary APIs, the remaining
profile families, native/corpus/platform validation, the complete
feature/release regression, measurements and reconciliation remain open.''')
old = '''Evidence: `evidence/2026-10-30-one-shot-encode-parameters-double-fast.json`.'''
assert s.count(old) == 1
s = s.replace(old, old + '''

## Combined staging extension to the Greedy chain and row families

`GreedyTables::seed_prefix` seeds every staged key position into the selected
chain or row owner - the chain through one insert per position, mirroring
upstream dictionary loading, the row under the same fresh salt the parser
searches with so seeded tags match every later lookup - and
`GreedyMatchState::from_parts_with_prefix` binds the prefix-relative geometry:
parsing starts at the prefix boundary with its sampling frontier there
(upstream sets `nextToUpdate` to the loaded dictionary end), and the existing
window floor bounds every emitted offset. A nonzero prefix now admits the
Greedy, Lazy and Lazy2 chain and row families beside Fast and DoubleFast; the
tree family (BinaryTreeLazy2) and every optimal-family profile still reject
combined staging with `UnsupportedFeature` until their own stages.

Thirteen focused commands pass: the complete library suite, true no_std
compilation and strict Clippy under safe, the isolated match-table and
dictionary backends the combined path exercises, and all features, plus
formatting. Every full suite reports {passed} passed
and {ignored} ignored across
{groups} result groups. Two new unit tests prove chain-family
(Greedy/Lazy/Lazy2) and row-family dictionary reach, output shrink against the
dictionary-free emission and roundtrip decoding with deterministic noise; the
unsupported-profile rejection test moved to the tree and optimal-family
levels.
Evidence: `evidence/{name}.json`.'''.format(passed=r['full_suite_counts']['passed'], ignored=r['full_suite_counts']['ignored'], groups=r['full_suite_counts']['result_groups'], name=name))
p.write_text(s)
changed.append('docs/one-shot-encode-parameters-validation.md')
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *changed], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Extend combined dictionary staging to the Greedy chain and row families'], cwd=R, check=True)
prev.update(stage='family', head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(), production_source={str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')})
state.write_text(json.dumps(prev, indent=2) + '\n')
print('module36 Greedy chain-and-row family promoted at', prev['head'][:12])
