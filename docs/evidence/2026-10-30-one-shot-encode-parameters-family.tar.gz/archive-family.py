"""Archive the qualified module36 Greedy chain-and-row family campaign."""
from pathlib import Path
import json, hashlib, tarfile, re, datetime

D = Path(__file__).parent
C = Path('/private/tmp/module36-family')
S = C / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
j = json.loads((C / 'evidence.json').read_text())
assert j['status'] == 'passed' and len(j['commands']) == 13
for n, h in j['source'].items():
    assert sha(S / n) == h, n
counts = (j['full_suite_counts']['result_groups'], j['full_suite_counts']['passed'], j['full_suite_counts']['ignored'])
for r in j['commands']:
    assert r['exit_code'] == 0 and sha(C / (r['label'] + '.log')) == r['log_sha256']
    if r['label'].endswith('-full'):
        rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (C / (r['label'] + '.log')).read_text())
        assert (len(rows), sum(int(a) for a, _, _ in rows), sum(int(i) for _, _, i in rows)) == counts, r['label']
files = {}
for p in C.rglob('*'):
    if not p.is_file():
        continue
    n = p.relative_to(C)
    if any(x == 'target' or x.endswith('-target') or x == '__pycache__' for x in n.parts):
        continue
    if p.suffix in {'.rs', '.toml', '.lock', '.json', '.py', '.log', '.md', '.tsv'}:
        files[str(n)] = p
files['archive-family.py'] = Path(__file__)
name = '2026-10-30-one-shot-encode-parameters-family'
archive = D / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
r = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source=j['source'], production_source=j['production_source'], commands=j['commands'], full_suite_counts=j['full_suite_counts'], members={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()}, archive=archive.name, archive_sha256=sha(archive), qualification='Focused module36 family item only: every staged key position of the in-window combined borrow is seeded into the Greedy/Lazy/Lazy2 chain or row owner under the parser fresh salt, and the match state binds the prefix-relative geometry with its sampling frontier at the prefix boundary. Existing dictionary-free parameterized bytes and the module33-35 checksummed dictionary paths are unchanged; the tree family and every optimal-family profile still reject combined staging explicitly until their own stages. No public parameterized dictionary API, native/platform schedule, full feature/release matrix, timing or milestone closure is claimed.')
(D / (name + '.json')).write_text(json.dumps(r, indent=2) + '\n')
print(name, archive.stat().st_size)
