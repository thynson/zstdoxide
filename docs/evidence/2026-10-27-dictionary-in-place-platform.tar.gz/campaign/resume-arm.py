from pathlib import Path
import json,hashlib,shutil,os,subprocess,time,tomllib
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();e=json.loads((D/'evidence.json').read_text());assert e['status']=='failed' and e['error']=="ValueError('thumb-safe-objects')";assert len(e['commands'])==5
shutil.copyfile(D/'evidence.json',D/'initial-probe-rejection.json');e['prior_failure_sha256']=sha(D/'initial-probe-rejection.json');e.pop('error');e['status']='running';S=D/'source';probe=D/'corrected-probe';shutil.copytree(S,probe)
with (probe/'src/lib.rs').open('a') as f:f.write('\n#[inline(never)]\npub fn dictionary_in_place_output_codegen_probe(bytes: &mut [u8], input_start: usize, limit: usize, dictionary: &Dictionary) -> Result<usize> {\n    decompress_in_place_with_dictionary_in(bytes, input_start, &dictionary.view(), DecodeOptions::new(limit), alloc::alloc::Global)\n}\n')
e['probe_source_sha256']=sha(probe/'src/lib.rs');env={**os.environ,'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args,cwd,target):
 t=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=cwd,env={**env,'CARGO_TARGET_DIR':str(target)},stdout=f,stderr=subprocess.STDOUT)
 row=dict(label=label,argv=args,environment={'CARGO_TARGET_DIR':str(target)},exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(label+'.log')));e['commands'].append(row);save();assert p.returncode==0,label
save()
try:
 features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
 for name,flags in [('safe',[]),('all',['--features',','.join(features)])]:
  common=['--offline','--locked','-Zbuild-std=core,alloc','--target','thumbv6m-none-eabi','--no-default-features','--lib',*flags]
  if name=='all':run('thumb-all-check',['cargo','check',*common],S,D/'thumb-check')
  target=D/('corrected-thumb-'+name);run('corrected-thumb-'+name+'-objects',['cargo','rustc','--release',*common,'--','--emit=llvm-ir,obj'],probe,target)
  ir=[p for p in target.rglob('*.ll') if any(line.startswith(b'define ') and b'dictionary_in_place_output_codegen_probe' in line for line in p.read_bytes().splitlines())];assert len(ir)==1 and b'llvm.memmove' in ir[0].read_bytes();objects=list(ir[0].parent.glob('*.o'));assert objects
  artifacts=[]
  for p in [ir[0],*objects]:
   if p.suffix=='.o':
    h=p.read_bytes()[:20];assert h[:6]==b'\x7fELF\x01\x01' and int.from_bytes(h[18:20],'little')==40
   q=D/'artifacts'/(name+'-'+p.name);q.parent.mkdir(exist_ok=True);shutil.copyfile(p,q);artifacts.append(dict(path=str(q.relative_to(D)),sha256=sha(q)))
  e.setdefault('artifacts',{})[name]=artifacts;save()
 for n,h in e['source'].items():assert sha(S/n)==h,n
 assert len(e['commands'])==8 and all(x['exit_code']==0 for x in e['commands'])
 e.update(status='passed',qualification='Four strict-provenance foreign i686/s390x Miri executions plus safe/all actual thumbv6m core+alloc checks and concrete IR/ARM object builds. Initial probe incorrectly passed an owned Dictionary instead of its view; compile rejection is retained without runtime/codegen credit. The corrected observation probe supplies its immutable view; production/test source is unchanged. Completed Miri/core checks were preserved and not rerun. Interpretation/code generation is not foreign hardware execution.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
