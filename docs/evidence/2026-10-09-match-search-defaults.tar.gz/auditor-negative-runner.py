import hashlib,io,json,pathlib,shutil,subprocess,tarfile,tempfile,time
ROOT=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize')
SCRIPT=ROOT/'scripts/check_match_search_baseline.py'
BASE='tests/fixtures/match-search-baseline/'
ARCHIVE='docs/evidence/2026-10-09-match-search-baseline.tar.gz'
SUMMARY='docs/evidence/2026-10-09-match-search-baseline.json'
paths=[BASE+'expected.tsv',BASE+'cases.tsv',BASE+'provenance.json',ARCHIVE,SUMMARY,'tests/upstream/support/mod.rs','tests/upstream/dictionaries/formatted.dict']
sha=lambda data:hashlib.sha256(data).hexdigest()
def edit_json(path,fn):
 d=json.loads(path.read_bytes());fn(d);path.write_text(json.dumps(d,indent=2)+'\n')
def changed(path):path.write_bytes(path.read_bytes()+b'X')
def repack(root,kind):
 p=root/ARCHIVE
 with tarfile.open(p) as t: entries=[(m,t.extractfile(m).read()) for m in t]
 if kind=='source':
  for m,data in entries:
   if m.name=='sources/capture.rs':m.size+=1
  entries=[(m,data+b'X' if m.name=='sources/capture.rs' else data) for m,data in entries]
 elif kind=='missing':entries=[(m,data) for m,data in entries if m.name!='sources/capture.rs']
 elif kind=='duplicate':entries.append(entries[-1])
 elif kind=='nonregular':
  m=tarfile.TarInfo('link');m.type=tarfile.SYMTYPE;m.linkname='expected.tsv';entries.append((m,b''))
 elif kind=='traversal':
  m=tarfile.TarInfo('../outside');m.size=1;entries.append((m,b'x'))
 with tarfile.open(p,'w:gz') as t:
  for m,data in entries:t.addfile(m,io.BytesIO(data))
 digest=sha(p.read_bytes())
 edit_json(root/SUMMARY,lambda d:d['archive'].update(sha256=digest))
 edit_json(root/(BASE+'provenance.json'),lambda d:d.update(archived_package_sha256=digest))
def mutate(root,label):
 if label=='positive':return
 if label=='expected-byte':changed(root/(BASE+'expected.tsv'))
 elif label=='expected-local-hash-updated':
  p=root/(BASE+'expected.tsv');changed(p)
  edit_json(root/(BASE+'provenance.json'),lambda d:d.update(expected_tsv_sha256=sha(p.read_bytes())))
 elif label=='cases-byte':changed(root/(BASE+'cases.tsv'))
 elif label.startswith('missing-'):
  target={'expected':BASE+'expected.tsv','cases':BASE+'cases.tsv','provenance':BASE+'provenance.json','archive':ARCHIVE,'rdg':'tests/upstream/support/mod.rs'}[label.removeprefix('missing-')]
  (root/target).unlink()
 elif label=='archive-byte':changed(root/ARCHIVE)
 elif label.startswith('repacked-'):repack(root,label.removeprefix('repacked-'))
 elif label=='rdg-byte':changed(root/'tests/upstream/support/mod.rs')
 elif label=='dictionary-byte':changed(root/'tests/upstream/dictionaries/formatted.dict')
 elif label=='summary-archive-hash':edit_json(root/SUMMARY,lambda d:d['archive'].update(sha256='0'*64))
 elif label=='provenance-source-hash':edit_json(root/(BASE+'provenance.json'),lambda d:d['source_files']['capture.rs'].update(sha256='0'*64))
 elif label=='package-manifest-hash':edit_json(root/SUMMARY,lambda d:d.update(package_manifest_sha256='0'*64))
 elif label=='malformed-json':(root/(BASE+'provenance.json')).write_text('{')
 else:raise RuntimeError(label)
labels=['positive','expected-byte','expected-local-hash-updated','cases-byte','missing-expected','missing-cases','missing-provenance','missing-archive','missing-rdg','archive-byte','repacked-source','repacked-missing','repacked-duplicate','repacked-nonregular','repacked-traversal','rdg-byte','dictionary-byte','summary-archive-hash','provenance-source-hash','package-manifest-hash','malformed-json']
evidence={'script_sha256':sha(SCRIPT.read_bytes()),'frozen_inputs_before':{p:sha((ROOT/p).read_bytes()) for p in paths},'commands':[]}
for optimized in [False,True]:
 for label in labels:
  with tempfile.TemporaryDirectory(prefix='zstdoxide-match-baseline-negative-') as temp:
   dest=pathlib.Path(temp)
   for name in paths:
    (dest/name).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,dest/name)
   mutate(dest,label)
   cmd=['python3']+(['-O'] if optimized else[])+[str(SCRIPT),'--root',str(dest)]
   start=time.monotonic();r=subprocess.run(cmd,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   log=pathlib.Path('/tmp/zstdoxide-module11-baseline-auditor-'+('optimized-' if optimized else 'normal-')+label+'.log');log.write_text(r.stdout)
   success=(r.returncode==0 if label=='positive' else r.returncode==1 and 'audit failed:' in r.stdout)
   evidence['commands'].append({'case':label,'optimized':optimized,'command':cmd,'exit_code':r.returncode,'expected_exit_code':0 if label=='positive' else 1,'passed':success,'elapsed_seconds':round(time.monotonic()-start,4),'log':str(log),'sha256':sha(log.read_bytes())})
   print(optimized,label,r.returncode,success,r.stdout.strip(),flush=True)
   if not success:raise RuntimeError('unexpected audit outcome')
evidence['frozen_inputs_after']={p:sha((ROOT/p).read_bytes()) for p in paths}
evidence['inputs_unchanged']=evidence['frozen_inputs_before']==evidence['frozen_inputs_after']
evidence['script_unchanged']=evidence['script_sha256']==sha(SCRIPT.read_bytes())
evidence['summary']={'positive':2,'negative':40,'all_passed':all(x['passed'] for x in evidence['commands']),'codec_runs':0,'fixture_regenerations':0}
p=pathlib.Path('/tmp/zstdoxide-module11-baseline-auditor-evidence.json');p.write_text(json.dumps(evidence,indent=2)+'\n')
print('EVIDENCE',str(p),sha(p.read_bytes()))
