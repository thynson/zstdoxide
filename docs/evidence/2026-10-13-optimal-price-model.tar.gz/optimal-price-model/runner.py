from pathlib import Path
import hashlib,json,subprocess
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-optimal-price-model-checks');O.mkdir()
paths=['scripts/oracles/optimal_prices_v2.py','scripts/oracles/optimal_price_recipes.py','scripts/oracles/optimal_price_validation.py','scripts/check_optimal_price_validation.py','tests/fixtures/reference-optimal-price-recipes/recipes.json'];source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths};commands=[]
for name,flags in [('normal',[]),('optimized',['-O'])]:
 argv=['python3',*flags,'scripts/check_optimal_price_validation.py'];log=O/(name+'.log');p=subprocess.run(argv,cwd=R,capture_output=True);log.write_bytes(p.stdout+p.stderr)
 if p.returncode:raise ValueError(name)
 v=json.loads(p.stdout)
 if v['status']!='passed' or v['operations']!=2018 or len(v['forgery_rejections'])!=23 or v['child_attempts']!=0:raise ValueError('controls')
 commands.append(dict(argv=argv,exit_code=p.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
if source!={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in paths}:raise ValueError('source changed')
(O/'evidence.json').write_text(json.dumps(dict(status='passed',source=source,commands=commands,qualification='Independent complete table/price arithmetic model, hand-checked identities and 23 forged observation controls per mode. The 147 source-only requests cover 2018 transitions. No C observation has yet been captured or compared.'),sort_keys=True,indent=2)+'\n')
