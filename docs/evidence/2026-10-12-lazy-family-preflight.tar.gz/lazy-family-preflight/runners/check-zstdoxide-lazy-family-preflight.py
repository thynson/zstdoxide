from pathlib import Path
import argparse,ast,contextlib,hashlib,json,os,runpy,shutil,subprocess,sys,tempfile
from unittest.mock import patch
sys.dont_write_bytecode=True
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(R/'scripts'))
m=runpy.run_path(str(R/'scripts/capture_lazy_families.py'));g=m['prepare'].__globals__
a=runpy.run_path(str(R/'scripts/check_lazy_family_capture.py'));ag=a['audit'].__globals__
root=Path(tempfile.mkdtemp(prefix='zstdoxide-lazy-family-preflight-',dir='/tmp')).resolve()
up=Path('/private/tmp/zstdoxize-upstream-1.5.7')
def args(**kw):return argparse.Namespace(**({'upstream':up,'output':root/'fresh','cc':'cc'}|kw))
children=[];checks=[]
def deny(*a,**k):children.append('child');raise RuntimeError('forbidden process')
def bad(name,call):
 before=sorted(str(p.relative_to(root)) for p in root.rglob('*'))
 try:call()
 except (ValueError,OSError,TypeError,KeyError):pass
 else:raise RuntimeError('accepted '+name)
 if before!=sorted(str(p.relative_to(root)) for p in root.rglob('*')):raise RuntimeError('preflight wrote files '+name)
 checks.append({'name':name,'rejected':True})
with contextlib.ExitStack() as stack:
 for mod,n in [(subprocess,'Popen'),(os,'system'),(os,'posix_spawn'),(os,'posix_spawnp')]:
  if hasattr(mod,n):stack.enter_context(patch.object(mod,n,deny))
 for n in ['scripts/capture_lazy_families.py','scripts/check_lazy_family_capture.py']:ast.parse((R/n).read_text())
 prepared=m['prepare'](args())
 if len(prepared[2])!=645 or len(prepared[-1])!=26 or (root/'fresh').exists():raise RuntimeError('positive preflight')
 for name,kw in [('missing-upstream',{'upstream':None}),('missing-output',{'output':None}),('nonexistent-upstream',{'upstream':root/'absent'}),('reference-inside-repository',{'upstream':R}),('output-inside-repository',{'output':R/'preflight-absent'}),('output-inside-reference',{'output':up/'preflight-absent'}),('output-parent-of-reference',{'output':Path('/private/tmp')}),('existing-output',{'output':root}),('missing-compiler',{'cc':'zstdoxide-nonexistent-c-compiler'})]:
  bad(name,lambda kw=kw:m['prepare'](args(**kw)))
 symlink=root/'output-link';symlink.symlink_to(root/'absent')
 bad('dangling-output-symlink',lambda:m['prepare'](args(output=symlink)));symlink.unlink()
 symlink.symlink_to(root)
 bad('existing-output-symlink',lambda:m['prepare'](args(output=symlink)));symlink.unlink()
 plain=root/'plain';plain.write_text('not executable');plain.chmod(0o644)
 bad('reference-is-file',lambda:m['prepare'](args(upstream=plain)))
 with patch.object(shutil,'which',lambda _:str(plain)):bad('nonexecutable-compiler',lambda:m['prepare'](args()))
 with patch.object(shutil,'which',lambda _:str(root)):bad('compiler-is-directory',lambda:m['prepare'](args()))
 oldsha=g['file_sha'];first=up/'lib/common/debug.c'
 with patch.dict(g,file_sha=lambda p:'0'*64 if p==first else oldsha(p)):
  bad('changed-reference-source',lambda:m['prepare'](args()))
 with patch.dict(g,CHECKER_SHA='0'*64):bad('changed-input-checker-identity',lambda:m['prepare'](args()))
 for n in ['CAPTURE_SHA','CHECKER_SHA','PREDECESSOR_CHECKER_SHA']:
  if n=='PREDECESSOR_CHECKER_SHA':
   with patch.dict(ag,**{n:'0'*64}):bad('changed-predecessor-checker',lambda:a['compare_predecessor'](prepared[1],prepared[2],{}))
  else:
   with patch.dict(ag,**{n:'0'*64}):bad('changed-audit-'+n,lambda:a['audit'](root/'fresh'))
 bad('missing-capture',lambda:a['audit'](root/'fresh'))
 capture=root/'capture';capture.mkdir();(capture/'evidence.json').write_text('{}')
 bad('missing-capture-fields',lambda:a['audit'](capture))
 (capture/'evidence.json').write_text('{"status":"failed"}')
 bad('failed-capture-status',lambda:a['audit'](capture))
 (capture/'evidence.json').unlink();(capture/'evidence.json').symlink_to(plain)
 bad('symlink-capture-evidence',lambda:a['audit'](capture))
 restored=m['prepare'](args())
 if prepared[3]!=restored[3] or children:raise RuntimeError('restored positive/children')
report={'status':'passed','python_optimized':not __debug__,'positive_preflights':2,'rejected_controls':len(checks),'child_processes':len(children),'reference_executions':0,'checks':checks,'source':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['scripts/capture_lazy_families.py','scripts/check_lazy_family_capture.py','scripts/check_lazy_family_recipes.py']},'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'qualification':'Read-only controller preflight and offline auditor early rejection controls only. Full command, table and observation validation follows the first real capture; no synthetic expected Lazy output.'}
print(json.dumps(report,sort_keys=True,indent=2));shutil.rmtree(root)
