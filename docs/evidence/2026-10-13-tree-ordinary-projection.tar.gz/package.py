from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for mode in ['normal','optimized']:
 p=Path('/tmp/zstdoxide-tree-projection-'+mode+'.log');b=p.read_bytes();r=json.loads(b.splitlines()[-1]);assert r['cases']==245 and r['blocks']==531 and r['frames']==365 and r['codec_executions']==0;files['logs/'+p.name]=b
sources=['scripts/pack_tree_frame_trajectories.py','scripts/check_tree_frames.py','tests/fixtures/reference-tree-frames/provenance.json','tests/fixtures/reference-tree-frames/README.md','tests/fixtures/reference-tree-frames/NOTICE']
for n in sources:files['source/'+n]=(R/n).read_bytes()
fixture=R/'tests/fixtures/reference-tree-frames/cases.bin';identity=dict(bytes=fixture.stat().st_size,sha256=sha(fixture.read_bytes()))
assert identity==dict(bytes=90242211,sha256='64dfe4a7f855e9e8dde3720e619b3de715bf93a6c06b45b6f9f2b84c4efd6cab')
report=dict(status='passed',cases=245,positive_blocks=531,complete_frames=365,source_bytes=7640096,excluded_partial_headers=15,python_modes=['normal','optimized'],codec_executions=0,fixture=identity,source_sha256={n:sha((R/n).read_bytes()) for n in sources},qualification='Each mode independently replays the complete canonical C collection and reproduces the exact bounded binary fixture. No Rust-generated expectation or public admission claim.')
files['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();files['package.py']=Path(__file__).read_bytes();a=R/'docs/evidence/2026-10-13-tree-ordinary-projection.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:assert {m.name:t.extractfile(m).read() for m in t}==files
report.update(archive=a.name,archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()));(R/'docs/evidence/2026-10-13-tree-ordinary-projection.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(report)
