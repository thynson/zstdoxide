from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,tomllib,re
R=Path('/private/tmp/module27-candidate');D=Path(__file__).parent;S=D/'source';S.mkdir()
for n in ['src','test-support','benches']:shutil.copytree(R/n,S/n)
for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(R/n,S/n)
bench=Path('/private/tmp/module27-benchmark-preparation/stable_prefix_output.rs').read_text();(S/'benches/stable_prefix_output.rs').write_text(bench)
with (S/'Cargo.toml').open('a') as f:f.write('\n[[bench]]\nname = "stable_prefix_output"\nharness = false\nrequired-features = ["std"]\n')
shutil.copytree(R/'tests/upstream/dictionaries',S/'tests/upstream/dictionaries')
for n in ['tests/upstream/data/generated/http-dictionary.zst','tests/upstream/data/golden-dictionaries/http-dict-missing-symbols','tests/upstream/data/golden-compression/http']:
 p=S/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,p)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()}
features=sorted(n for n in tomllib.loads((R/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
env={**os.environ,'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_TARGET_DIR':str(D/'target')}
e={'status':'building','source':source,'production_source':{str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')},'builds':[],'qualification':'Benchmark-only source snapshot adds one harness=false bench registration; production src bytes match the working tree. Clock-free accounting is separate from timing.'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
try:
 for name,flags in [('safe',[]),*[(f,['--features',f]) for f in features],('all',['--all-features'])]:
  args=['cargo','bench','--offline','--locked','--bench','stable_prefix_output','--no-run','--message-format=json',*flags];t=time.monotonic()
  with (D/(name+'-build.jsonl')).open('xb') as out,(D/(name+'-build.log')).open('xb') as err:p=subprocess.run(args,cwd=S,env=env,stdout=out,stderr=err)
  assert p.returncode==0,(name,'build')
  artifacts=[json.loads(line) for line in (D/(name+'-build.jsonl')).read_text().splitlines() if line.startswith('{')]
  exes=[a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='stable_prefix_output' and a.get('executable')];assert len(exes)==1
  exe=D/'executables'/name;exe.parent.mkdir(exist_ok=True);shutil.copyfile(exes[0],exe);exe.chmod(0o755)
  p=subprocess.run([str(exe),'qualify'],capture_output=True);(D/(name+'-qualify.tsv')).write_bytes(p.stdout);(D/(name+'-qualify.stderr')).write_bytes(p.stderr);assert p.returncode==0,(name,'qualify',p.stderr)
  rows=p.stdout.decode().splitlines();assert len(rows)==44
  if name!='safe':assert p.stdout==(D/'safe-qualify.tsv').read_bytes(),(name,'ledger parity')
  e['builds'].append(dict(name=name,argv=args,seconds=time.monotonic()-t,executable=str(exe.relative_to(D)),sha256=sha(exe),qualification_sha256=sha(D/(name+'-qualify.tsv'))));save();print(name,'built and qualified',flush=True)
 for n,h in e['production_source'].items():assert sha(R/n)==h
 for n,h in source.items():assert sha(S/n)==h
 e['status']='qualified-not-timed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
