from pathlib import Path
import json,statistics,math,csv
D=Path(__file__).parent
records=[];index={};comparisons=[]
builds=json.loads((D/'evidence.json').read_text())['builds']
for campaign,folder,names in [('primary',D,[r['name'] for r in builds]),('repeat',D/'repeat',['safe','all'])]:
 assert json.loads((folder/'timed.json').read_text())['status']=='passed'
 for name in names:
  groups={}
  for line in (folder/(name+'-timed.tsv')).read_text().splitlines():
   case,mode,sample,iterations,elapsed=line.split('\t');groups.setdefault((case,mode),[]).append(int(elapsed)/int(iterations))
  for (case,mode),samples in groups.items():
   assert len(samples)==5
   row=dict(campaign=campaign,backend=name,case=case,mode=mode,median_ns=statistics.median(samples),minimum_ns=min(samples),maximum_ns=max(samples));records.append(row);index[campaign,name,case,mode]=row['median_ns']
with (D/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
cases=[line.split('\t')[0] for line in (D/'safe-qualify.tsv').read_text().splitlines() if line.split('\t')[1]=='stable-whole']
gm=lambda values:math.exp(sum(math.log(v) for v in values)/len(values))
for campaign in ['primary','repeat']:
 for backend in (['safe','all'] if campaign=='repeat' else [r['name'] for r in builds]):
  for schedule in ['whole','fragmented']:
   stable_buffered={case:index[campaign,backend,case,'stable-'+schedule]/index[campaign,backend,case,'buffered-'+schedule] for case in cases}
   stable_safe={case:index[campaign,backend,case,'stable-'+schedule]/index[campaign,'safe',case,'stable-'+schedule] for case in cases}
   comparisons.append(dict(campaign=campaign,backend=backend,schedule=schedule,stable_over_buffered=stable_buffered,stable_over_safe=stable_safe,nonempty_geomean_stable_over_buffered=gm([v for k,v in stable_buffered.items() if k!='empty']),nonempty_geomean_stable_over_safe=gm([v for k,v in stable_safe.items() if k!='empty'])))
(D/'summary.json').write_text(json.dumps(dict(samples_per_row=5,unit='nanoseconds per complete cold session',aggregation='Geometric mean of per-case median latency ratios across ten nonempty workloads with equal case weights. Empty streams remain separate. Whole and seven-byte fragmented inputs are separate comparisons. Lower means lower observed latency; no confidence intervals or general speedup claim.',rows=records,comparisons=comparisons),indent=2)+'\n')
for a in comparisons:
 if a['backend'] in ['safe','all','unsafe-slice-history']:print(a['campaign'],a['backend'],a['schedule'],'stable/buffered',round(a['nonempty_geomean_stable_over_buffered'],4),'stable/safe',round(a['nonempty_geomean_stable_over_safe'],4))
