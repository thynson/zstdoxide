from pathlib import Path
import hashlib,json,tarfile,argparse,importlib.util
p=argparse.ArgumentParser();p.add_argument('module',choices=['27']);a=p.parse_args()
D=Path('/private/tmp')/('module'+a.module+'-benchmark');E=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('measure',D/'measure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);b,gates=m.validate()
r=json.loads((D/'repeat/evidence.json').read_text());q=json.loads((D/'timed.json').read_text());z=json.loads((D/'repeat/timed.json').read_text());s=json.loads((D/'summary.json').read_text())
assert q['status']==z['status']=='passed' and len(q['runs'])==22 and len(z['runs'])==2
assert q['gates']==z['gates']==gates
assert z['primary_timing_sha256']==sha(D/'timed.json') and z['build_evidence_sha256']==sha(D/'repeat/evidence.json')
for folder,build,timed in [(D,b,q),(D/'repeat',r,z)]:
 for row in build['builds']:
  assert sha(folder/row['executable'])==row['sha256']
  assert (folder/(row['name']+'-qualify.tsv')).read_bytes()==(D/'safe-qualify.tsv').read_bytes()
 for row in timed['runs']:assert sha(folder/(row['name']+'-timed.tsv'))==row['sha256']
# Preserve exactly the measurement sources, deterministic input fixtures, harness,
# all retained executables and raw samples; no compiler intermediates are needed.
files=[x for x in D.rglob('*') if x.is_file() and not {'target','__pycache__'}.intersection(x.relative_to(D).parts) and '.dSYM' not in str(x)]
name='2026-10-26-'+({'23':'caller-output','24':'stable-output','25':'dictionary-output','26':'stable-dictionary-output','27':'stable-prefix-output'}[a.module])+'-benchmarks';archive=E/(name+'.tar.gz');assert not archive.exists()
members={str(x.relative_to(D)):dict(bytes=x.stat().st_size,sha256=sha(x)) for x in sorted(files)}
with tarfile.open(archive,'w:gz') as t:
 for x in sorted(files):t.add(x,arcname=str(x.relative_to(D)))
 t.add(__file__,arcname='archive-benchmark.py')
result=dict(status='passed',build=b,repeat_build=r,timing=q,repeat_timing=z,summary=s,members=members,archive=archive.name,archive_sha256=sha(archive),qualification='Fixed-order sequential measurements on this host, with task-owned compiler/test jobs completed before the recorded CPU barrier. No claim of desktop idleness, statistical significance, architecture independence or general unsafe speedup. Primary contains safe/all/20 isolated backends; independent rebuilt repeat contains safe/all. Allocation qualification is separate from timing. Every sample is retained.')
(E/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size,'bytes')
