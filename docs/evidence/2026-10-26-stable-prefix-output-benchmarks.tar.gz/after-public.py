from pathlib import Path
import json,time,subprocess
D=Path(__file__).parent;R=Path('/private/tmp/module27-candidate')
while True:
 p=R/'public.json'
 if p.exists():
  j=json.loads(p.read_text())
  if j['status']=='passed':break
  assert j['status']=='running',j['status']
 time.sleep(15)
subprocess.run(['rustfmt','--edition','2024','/private/tmp/module27-benchmark-preparation/stable_prefix_output.rs'],cwd=R,check=True)
for name in ['build.py','repeat-build.py','check-harness.py']:subprocess.run(['python3',str(D/name)],check=True)
print('Prefix benchmark primary22 and independent repeat2 qualified, never timed',flush=True)
