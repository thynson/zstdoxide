from pathlib import Path, PurePosixPath
import hashlib,json,sys
base=Path(__file__).resolve().parent;out=Path(sys.argv[1]).resolve()
if out.exists() or out.is_relative_to(base) or base.is_relative_to(out):raise ValueError("fresh disjoint output required")
rows=json.loads((base/"file-map.json").read_bytes());out.mkdir(parents=True)
for name,row in rows.items():
 p=PurePosixPath(name)
 if p.is_absolute() or ".." in p.parts or str(p)!=name:raise ValueError("canonical relative name")
 target=out/name;target.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256();size=0
 with target.open("xb") as f:
  for key in row["chunks"]:
   if len(key)!=64 or any(c not in "0123456789abcdef" for c in key):raise ValueError("chunk key")
   b=(base/"chunks"/(key+".bin")).read_bytes()
   if hashlib.sha256(b).hexdigest()!=key:raise ValueError("chunk digest")
   f.write(b);h.update(b);size+=len(b)
 if size!=row["bytes"] or h.hexdigest()!=row["sha256"]:raise ValueError("file digest")
print("Reconstructed",len(rows),"exact files into",out)
