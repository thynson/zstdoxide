//! External deterministic request-backed versus named-policy stream timing.
use std::{hint::black_box, time::{Duration, Instant}};
use zstdoxide::{CompiledStreamOptions, CompressionParameterRequest, CompressionStrategy,
    Encoder, EncoderOptions, EndDirective, Progress, ReferenceStrategy, ReferenceStreamEncoder,
    StreamStatus, decompress};

fn barrier() {
    let now = Instant::now(); let mut n = 123_u64;
    while now.elapsed() < Duration::from_millis(500) {
        for _ in 0..10_000 { n = n.wrapping_mul(6364136223846793005).wrapping_add(1); }
        black_box(n);
    }
}
fn pump(mut process: impl FnMut(&[u8], &mut [u8], EndDirective) -> Progress,
        input: &[u8], frame: &mut Vec<u8>, output: &mut [u8]) {
    frame.clear(); let mut pos=0;
    loop {
        let end=(pos+4093).min(input.len());
        let directive=if end==input.len() {EndDirective::Finish} else {EndDirective::Continue};
        let p=process(&input[pos..end],output,directive);
        frame.extend_from_slice(&output[..p.produced]);pos+=p.consumed;
        if p.status==StreamStatus::FrameFinished {assert_eq!(pos,input.len());break;}
    }
}
fn digest(bytes: &[u8]) -> u64 { bytes.iter().fold(0xcbf29ce484222325, |n,&b| (n^u64::from(b)).wrapping_mul(0x100000001b3)) }
#[test]
fn reference_stream_measurements() {
    let root=std::path::PathBuf::from(std::env::var_os("ZSTDOXIDE_REFERENCE_BENCH").unwrap());
    std::fs::create_dir_all(&root).unwrap();
    let mut noise=Vec::new(); let mut state=0x12345678_u32;
    for _ in 0..16384 {state^=state<<13;state^=state>>17;state^=state<<5;noise.push(state as u8);}
    let inputs=[b"request backed reference streaming repeated text ".repeat(171),noise,
        b"multiblock reference streaming retained history ".repeat(3800)];
    let mut ledger=String::new();let mut samples=String::from("case\tround\tsample\tmode\tnanoseconds\tbytes\tdigest\n");
    for (family,strategy) in [ReferenceStrategy::Fast,ReferenceStrategy::DoubleFast,
        ReferenceStrategy::Greedy,ReferenceStrategy::Lazy,ReferenceStrategy::Lazy2,
        ReferenceStrategy::BinaryTreeLazy2].into_iter().enumerate() {
        for (kind,input) in inputs.iter().enumerate() {
            let name=format!("family{}-corpus{kind}",family+1);
            let mut request=CompressionParameterRequest::with_level(3);
            request.set_strategy(Some(strategy));request.set_window_log(17).unwrap();
            request.set_hash_log(14).unwrap();request.set_chain_log(14).unwrap();
            let opts=CompiledStreamOptions{checksum:true,pledged_size:Some(input.len() as u64),..Default::default()};
            let profile=request.resolve(zstdoxide::SourceSize::Known(input.len() as u64),0).unwrap();
            let named_opts=EncoderOptions {strategy:match family {0|1=>CompressionStrategy::Greedy,2=>CompressionStrategy::Chain,_=>CompressionStrategy::Lazy},
                window_log:profile.window_log(),checksum:true,pledged_size:Some(input.len() as u64),..Default::default()};
            let mut reference=ReferenceStreamEncoder::with_options(request,opts).unwrap();
            let mut named=Encoder::with_options(named_opts).unwrap();
            let mut frame=Vec::with_capacity(input.len()*2+1024);let mut output=vec![0_u8;8192];
            let mut expected=Vec::new();
            for mode in 0..2 {
                if mode==0 {pump(|i,o,d|reference.process(i,o,d).unwrap(),input,&mut frame,&mut output);}
                else {pump(|i,o,d|named.process(i,o,d).unwrap(),input,&mut frame,&mut output);}
                assert_eq!(decompress(&frame,input.len()).unwrap(),*input);
                std::fs::write(root.join(format!("{name}-{mode}.zst")),&frame).unwrap();
                expected.push(frame.clone());
                ledger.push_str(&format!("{name}\t{mode}\t{}\t{}\t{}\n",input.len(),frame.len(),digest(&frame)));
            }
            for round in 0..2 {
                barrier();
                for sample in 0..40 {
                    for order in 0..2 {
                        let mode=(order+sample+round)%2;
                        let now=Instant::now();
                        if mode==0 {reference.reset_with_options(opts).unwrap();pump(|i,o,d|reference.process(i,o,d).unwrap(),black_box(input),&mut frame,&mut output);}
                        else {named.reset_with_options(named_opts).unwrap();pump(|i,o,d|named.process(i,o,d).unwrap(),black_box(input),&mut frame,&mut output);}
                        let ns=now.elapsed().as_nanos();
                        assert_eq!(frame,expected[mode]);
                        samples.push_str(&format!("{name}\t{round}\t{sample}\t{mode}\t{ns}\t{}\t{}\n",frame.len(),digest(&frame)));
                    }
                }
            }
        }
    }
    std::fs::write(root.join("ledger.tsv"),ledger).unwrap();std::fs::write(root.join("samples.tsv"),samples).unwrap();
}
