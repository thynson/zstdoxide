from pathlib import Path
import hashlib,json,tarfile,subprocess,os
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((D/'evidence.json').read_text());assert e['status']=='complete';assert e['summary']['samples']==11520
for n,h in e['source'].items():assert sha(R/n)==h,('source mismatch',n)
for n,h in e['outputs'].items():assert sha(D/n)==h
for mode in ['safe','all']:
 assert sha(Path(e['builds'][mode]['binary']))==e['builds'][mode]['binary_sha256']
e['environment']={'system':os.uname().sysname,'machine':os.uname().machine,'rustc':subprocess.check_output(['rustc','-Vv'],cwd=R,text=True),'cpu_model':'not recorded','affinity_or_frequency_lock':'none'}
e['build_commands']={mode:{'argv':['cargo','test','--offline','--locked','--test','reference_bench',*(['--all-features'] if mode=='all' else []),'--no-run'],'environment':{'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'3','CARGO_PROFILE_TEST_DEBUG':'0'}} for mode in ['safe','all']}
e['cargo_metadata']={n:sha(D/'source'/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']}
assert '1 passed; 0 failed' in (D/'smoke.log').read_text()
assert 'Finished' in (D/'harness-clippy.log').read_text()
e['harness_validation']={'smoke_log_sha256':sha(D/'smoke.log'),'clippy_log_sha256':sha(D/'harness-clippy.log'),'note':'Untimed qualification smoke: its durations and samples are excluded from the four official measurement runs.'}
archive=R/'docs/evidence/2026-11-05-reference-streaming-benchmarks.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n in ['check.py','finalize.py','reference_bench.rs','evidence.json','driver.log','safe-build.log','all-build.log','smoke.log','harness-clippy.log']:t.add(D/n,arcname=n)
 for name in ['safe-1','all-1','all-2','safe-2']:
  t.add(D/name,arcname=name);t.add(D/(name+'.log'),arcname=name+'.log')
e['archive']={'path':str(archive.relative_to(R)),'sha256':sha(archive)}
(R/'docs/evidence/2026-11-05-reference-streaming-benchmarks.json').write_text(json.dumps(e,indent=2)+'\n')
s=e['summary'];ratio=s['reference_over_named'];ledger={}
for line in (D/'safe-1/ledger.tsv').read_text().splitlines():
 case,mode,n,size,digest=line.split('\t');ledger[(case,mode)]=(n,size)
lines=['# Request-backed reference streaming measurements','',
'This bounded Module 40 campaign compares the request-backed streaming owner',
'with the existing named-policy encoder. It does not compare against native',
'zstd speed or claim equivalence between their match-search policies.','',
'## Protocol and scope','',
'Eighteen deterministic cases combine six explicit reference families with',
'repeated text, 16 KiB seeded noise and repeated multi-block input beyond the',
'128 KiB window. Fast/DoubleFast use named Greedy as the comparator; reference',
'Greedy uses named Chain; Lazy/Lazy2/BinaryTreeLazy2 use named Lazy. Each pair',
'uses the same resolved window, exact pledge, checksum and caller chunk sizes',
'(4,093-byte input / 8,192-byte output). Reference table logs are explicitly',
'14; named policies retain their own default table/effort settings.','',
'Contexts are warmed and reused. Timed regions include reset and complete-frame',
'pumping into preallocated caller buffers; construction, decoding, byte equality',
'and digest checks are outside timers. Every measured output equals its warmed',
'frame exactly. Safe/all builds and both repeats have byte-identical ledgers',
'and frame artifacts. All warm frames decode to their exact source.','',
'Two rounds of forty alternating-order samples follow a 500 ms CPU barrier per',
'case and round. Two independent repeats run for each backend, in safe/all/all/',
'safe order after the feature matrix completes: 11,520 samples total. Binaries',
'use the optimized test profile (opt-level 3, debug 0, incremental disabled,',
'default test assertions) on Darwin arm64 with pinned nightly-2026-10-08',
'(rustc 1.101.0-nightly, LLVM 23.1.3). No CPU affinity or frequency lock was',
'used; background host activity is not controlled.','',
'## Aggregate observations','',
'Ratios are geometric means of the eighteen per-case ratios of medians.',
'Reference/named greater than one means the reference coordinator took longer;',
'all/safe greater than one means the all-feature build took longer. These are',
'point estimates from this corpus, not confidence bounds or universal rankings.','',
'| Comparison | Repeat 1 | Repeat 2 |','| --- | ---: | ---: |',
f"| Reference/named, safe | {ratio['safe-1']['geometric_mean']:.4f} | {ratio['safe-2']['geometric_mean']:.4f} |",
f"| Reference/named, all features | {ratio['all-1']['geometric_mean']:.4f} | {ratio['all-2']['geometric_mean']:.4f} |",
f"| All/safe, reference | {s['all_over_safe']['1']['0']:.4f} | {s['all_over_safe']['2']['0']:.4f} |",
f"| All/safe, named | {s['all_over_safe']['1']['1']:.4f} | {s['all_over_safe']['2']['1']:.4f} |",'',
'Policy work, encoded size, table geometry and allocation reuse differ between',
'comparators. No universal reference advantage or unsafe speedup is inferred',
'from these aggregate values. Small effects require more isolated measurements.','',
'## Per-case observations','',
'Each ratio uses the median of eighty samples in that independent run. Encoded',
'sizes are constant across both repeats and backend configurations.','',
'| Family / corpus | Source bytes | Reference bytes | Named bytes | Safe R1 | Safe R2 | All R1 | All R2 |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
families=['Fast','DoubleFast','Greedy','Lazy','Lazy2','BinaryTreeLazy2'];corpora=['text','noise','multi-block']
for family in range(1,7):
 for corpus in range(3):
  case=f'family{family}-corpus{corpus}';n,size=ledger[(case,'0')];named=ledger[(case,'1')][1]
  values=[ratio[k]['per_case'][case] for k in ['safe-1','safe-2','all-1','all-2']]
  lines.append(f'| {families[family-1]} / {corpora[corpus]} | {n} | {size} | {named} | '+' | '.join(f'{v:.4f}' for v in values)+' |')
lines+=['','Raw samples, warmed frames, ledgers, harness, controller and build logs are',
'in `evidence/2026-11-05-reference-streaming-benchmarks.tar.gz`. The JSON receipt',
'retains source/build/output hashes, commands, medians and repeat summaries.',
'No timing claim extends to unknown-size streams, prefix-backed inputs, other',
'allocators or platforms, native zstd, LDM, workers or unsupported families.','']
(R/'docs/reference-streaming-benchmarks.md').write_text('\n'.join(lines))
p=R/'TODO.md';text=p.read_text().replace('- [ ] Compare dictionary-free streaming workloads after CPU barriers with','- [x] Compare dictionary-free streaming workloads after CPU barriers with');p.write_text(text)
p=R/'docs/reference-streaming-validation.md';text=p.read_text().replace('The separate timing comparison remains an independent gate until its receipt\nis reconciled. Full matrix success alone is not a performance claim.', 'The independent timing comparison is recorded in\n`reference-streaming-benchmarks.md` and its 2026-11-05 receipt: 18 workloads,\n11,520 samples and byte-identical safe/all repeat ledgers. It compares distinct\nreference and named policies and makes no universal speedup claim.');p.write_text(text)
print(json.dumps({'ratios':{k:v['geometric_mean'] for k,v in ratio.items()},'all_over_safe':s['all_over_safe']},indent=2))
