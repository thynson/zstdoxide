from pathlib import Path
import datetime,hashlib,json,math,os,re,statistics,subprocess,time
D=Path(__file__).parent; S=D/'source';M=Path('/private/tmp/module40-matrix/evidence.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e={'status':'waiting_for_matrix_cpu_barrier','source':{str(p.relative_to(S)):sha(p) for p in (S/'src').rglob('*.rs')},
   'harness_sha256':sha(D/'reference_bench.rs'),'builds':{},'commands':[],
   'scope':'18 deterministic workloads, six explicit reference families x text/noise/multiblock. Reference vs named Greedy/Chain/Lazy at the same resolved window, pledge and checksum. Independent parsers/policies, no output or ratio equivalence claim. Reused contexts, reset and complete-frame pumping timed; validation/digest outside timers. Two rounds x 40 alternating-order samples after 500ms in-test CPU barriers, two independent repeats for safe/all. Optimized test profile opt-level=3 with default test assertions; no production workload guarantee.'}
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
for mode in ['safe','all']:
    log=D/(mode+'-build.log');s=log.read_text();m=re.search(r'Executable tests/reference_bench.rs \((.*?)\)',s);assert m
    binary=Path(m[1]);e['builds'][mode]={'binary':str(binary),'binary_sha256':sha(binary),'log_sha256':sha(log),'profile':'test, opt-level=3, debug=0, incremental=0','features':mode}
save()
try:
    while True:
        matrix=json.loads(M.read_text());assert matrix['status']!='failed',matrix.get('error')
        if matrix['status']=='complete':break
        assert datetime.datetime.now(datetime.timezone.utc)<datetime.datetime(2026,11,5,10,11,tzinfo=datetime.timezone.utc),'Window deadline'
        time.sleep(10)
    e['status']='running';e['started_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
    # Alternate backend order between independent repeats.
    for mode,repeat in [('safe',1),('all',1),('all',2),('safe',2)]:
        name=f'{mode}-{repeat}';out=D/name;binary=e['builds'][mode]['binary'];start=time.monotonic()
        e['active']=name;save()
        with (D/(name+'.log')).open('w') as log:
            result=subprocess.run([binary,'--exact','reference_stream_measurements','--nocapture'],cwd=S,
                env={**os.environ,'ZSTDOXIDE_REFERENCE_BENCH':str(out)},stdout=log,stderr=subprocess.STDOUT)
        assert result.returncode==0,(name,(D/(name+'.log')).read_text()[-3000:])
        e['commands'].append({'label':name,'argv':[binary,'--exact','reference_stream_measurements','--nocapture'],'exit_code':0,'seconds':time.monotonic()-start,'log_sha256':sha(D/(name+'.log'))});save();print(name,flush=True)
    ledger=(D/'safe-1/ledger.tsv').read_bytes()
    medians={};ratios={}
    for mode in ['safe','all']:
        for repeat in [1,2]:
            name=f'{mode}-{repeat}';out=D/name;assert (out/'ledger.tsv').read_bytes()==ledger
            for frame in (D/'safe-1').glob('*.zst'):assert frame.read_bytes()==(out/frame.name).read_bytes()
            rows=[r.split('\t') for r in (out/'samples.tsv').read_text().splitlines()[1:]];assert len(rows)==2880
            grouped={}
            for case,round_,sample,method,ns,n,digest in rows:
                grouped.setdefault((case,method),[]).append(int(ns))
            assert len(grouped)==36 and all(len(v)==80 for v in grouped.values())
            medians[name]={case+'|'+method:statistics.median(v) for (case,method),v in grouped.items()}
            ratios[name]={case:medians[name][case+'|0']/medians[name][case+'|1'] for case in sorted({case for case,_ in grouped})}
    geo=lambda values:math.exp(statistics.mean(math.log(x) for x in values))
    e['summary']={'reference_over_named':{name:{'per_case':values,'geometric_mean':geo(values.values())} for name,values in ratios.items()},
        'all_over_safe':{str(rep):{method:geo(medians[f'all-{rep}'][key]/v for key,v in medians[f'safe-{rep}'].items() if key.endswith('|'+method)) for method in ['0','1']} for rep in [1,2]},
        'medians_nanoseconds':medians,'samples':11520,'ledger_sha256':hashlib.sha256(ledger).hexdigest()}
    e['outputs']={str(p.relative_to(D)):sha(p) for name in medians for p in (D/name).iterdir() if p.is_file()}
    for n,h in e['source'].items():assert sha(S/n)==h
    e.pop('active',None);e['status']='complete';e['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print('complete',flush=True)
except BaseException as ex:e['status']='failed';e['error']=repr(ex);save();raise
