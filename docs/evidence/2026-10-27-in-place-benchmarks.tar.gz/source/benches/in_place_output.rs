//! Identical fixed layouts, separate source restoration and scratch accounting.
//! Every timed operation uses a per-call clock, including the direct baseline.
//! Source/destination allocation, validation and tracking ledgers are not timed.
use std::{hint::black_box, time::Instant};
use zstdoxide::{
    DecodeOptions, decompress_in_place_with_options, decompress_in_place_with_options_in,
    decompress_into_with_options, decompress_into_with_options_in, decompression_margin,
};
use zstdoxide_test_allocator::{AllocatorConfig, TrackingAllocator};

fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |h, &b| {
        (h ^ u64::from(b)).wrapping_mul(0x100000001b3)
    })
}
fn cases() -> Vec<(&'static str, Vec<u8>, Vec<u8>, bool)> {
    let mut cases = Vec::new();
    macro_rules! generated {
        ($name:literal) => {
            cases.push((
                $name,
                include_bytes!(concat!("../tests/upstream/decodecorpus/", $name, ".zst")).to_vec(),
                include_bytes!(concat!("../tests/upstream/decodecorpus/", $name, ".raw")).to_vec(),
                false,
            ));
        };
    }
    generated!("mixed-04");
    generated!("raw-07");
    generated!("rle-03");
    generated!("compressed-05");
    generated!("small-blocks-07");
    generated!("large-content-04");
    cases.push((
        "http",
        include_bytes!("../tests/upstream/data/generated/http.zst").to_vec(),
        include_bytes!("../tests/upstream/data/golden-compression/http").to_vec(),
        false,
    ));
    cases.push((
        "larger",
        include_bytes!("../tests/upstream/data/generated/huffman-compressed-larger.zst").to_vec(),
        include_bytes!("../tests/upstream/data/golden-compression/huffman-compressed-larger")
            .to_vec(),
        false,
    ));
    cases.push((
        "empty",
        vec![0x28, 0xb5, 0x2f, 0xfd, 0x20, 0, 1, 0, 0],
        Vec::new(),
        false,
    ));
    let mut frame = cases[0].1.clone();
    frame.extend_from_slice(&cases[3].1);
    let mut source = cases[0].2.clone();
    source.extend_from_slice(&cases[3].2);
    cases.push(("concatenated", frame, source, false));
    let source: Vec<_> = (0..120000).map(|i| (i * 7 + 13) as u8).collect();
    let mut frame = vec![0x28, 0xb5, 0x2f, 0xfd, 0xa0];
    frame.extend_from_slice(&(source.len() as u32).to_le_bytes());
    frame.extend_from_slice(&(((source.len() as u32) << 3) | 1).to_le_bytes()[..3]);
    frame.extend_from_slice(&source);
    cases.push(("raw-overlap", frame, source, true));
    cases
}
fn main() {
    let command = std::env::args().nth(1).expect("qualify or measure");
    assert!(command == "qualify" || command == "measure");
    for (name, frame, source, tight) in cases() {
        let capacity = if tight {
            frame.len()
        } else {
            (source.len() + decompression_margin(&frame).unwrap()).max(frame.len())
        };
        let input_start = capacity - frame.len();
        let mut buffer = vec![0xa5; capacity + 16];
        buffer[8 + input_start..8 + capacity].copy_from_slice(&frame);
        let before = buffer.clone();
        let mut direct = vec![0xa5; capacity + 16];
        let options = DecodeOptions::new(source.len());
        assert_eq!(
            decompress_in_place_with_options(&mut buffer[8..8 + capacity], input_start, options),
            Ok(source.len())
        );
        assert_eq!(&buffer[8..8 + source.len()], source);
        assert_eq!(&buffer[..8], &before[..8]);
        assert_eq!(&buffer[8 + source.len()..], &before[8 + source.len()..]);
        assert_eq!(
            decompress_into_with_options(&frame, &mut direct[8..8 + capacity], options),
            Ok(source.len())
        );
        assert_eq!(&direct[8..8 + source.len()], source);
        if command == "qualify" {
            for mode in ["in-place", "direct"] {
                let owner = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                let monitor = owner.monitor();
                if mode == "in-place" {
                    buffer[8 + input_start..8 + capacity].copy_from_slice(&frame);
                    assert_eq!(
                        decompress_in_place_with_options_in(
                            &mut buffer[8..8 + capacity],
                            input_start,
                            options,
                            owner
                        ),
                        Ok(source.len())
                    );
                } else {
                    assert_eq!(
                        decompress_into_with_options_in(
                            &frame,
                            &mut direct[8..8 + capacity],
                            options,
                            owner
                        ),
                        Ok(source.len())
                    );
                }
                monitor.assert_released();
                let s = monitor.snapshot();
                assert_eq!(s.identities_created, s.owners_dropped);
                println!(
                    "{name}\t{mode}\t{}\t{:016x}\t{capacity}\t{input_start}\t{}\t{}\t{}\t{}",
                    source.len(),
                    fingerprint(&source),
                    s.attempts,
                    s.requested_bytes,
                    s.peak_bytes,
                    s.deallocate_calls
                );
            }
            continue;
        }
        let iterations = (1024 * 1024 / source.len().max(1)).clamp(8, 1024);
        for mode in [
            "in-place-decode",
            "direct-decode",
            "restore-only",
            "in-place-with-restore",
        ] {
            for sample in 0..5 {
                let mut elapsed = 0;
                for _ in 0..iterations {
                    if mode == "in-place-decode" {
                        buffer[8 + input_start..8 + capacity].copy_from_slice(black_box(&frame));
                    }
                    let start = Instant::now();
                    match mode {
                        "in-place-decode" => {
                            black_box(
                                decompress_in_place_with_options(
                                    black_box(&mut buffer[8..8 + capacity]),
                                    black_box(input_start),
                                    black_box(options),
                                )
                                .unwrap(),
                            );
                        }
                        "direct-decode" => {
                            black_box(
                                decompress_into_with_options(
                                    black_box(&frame),
                                    black_box(&mut direct[8..8 + capacity]),
                                    black_box(options),
                                )
                                .unwrap(),
                            );
                        }
                        "restore-only" => {
                            black_box(&mut buffer[8 + input_start..8 + capacity])
                                .copy_from_slice(black_box(&frame));
                        }
                        "in-place-with-restore" => {
                            black_box(&mut buffer[8 + input_start..8 + capacity])
                                .copy_from_slice(black_box(&frame));
                            black_box(
                                decompress_in_place_with_options(
                                    black_box(&mut buffer[8..8 + capacity]),
                                    black_box(input_start),
                                    black_box(options),
                                )
                                .unwrap(),
                            );
                        }
                        _ => unreachable!(),
                    }
                    elapsed += start.elapsed().as_nanos();
                }
                if mode != "restore-only" {
                    assert_eq!(&buffer[8..8 + source.len()], source);
                }
                assert_eq!(&direct[8..8 + source.len()], source);
                assert_eq!(&buffer[..8], &before[..8]);
                assert_eq!(&buffer[8 + source.len()..], &before[8 + source.len()..]);
                println!("{name}\t{mode}\t{sample}\t{iterations}\t{elapsed}");
            }
        }
    }
}
