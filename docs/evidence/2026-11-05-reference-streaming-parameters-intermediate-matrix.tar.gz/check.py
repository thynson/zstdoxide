"""Module 41 intermediate regression: targeted safe/all/isolated feature tests,
host no_std and strict Clippy, targeted release, atomic-free ARM output, then
full safe/all suites. This does NOT satisfy full isolated-feature/release suite
qualification. Bounded by the user's remaining work window; no milestone claim.
"""
from pathlib import Path
import datetime, hashlib, json, os, re, shutil, signal, subprocess, time, tomllib

D = Path('/private/tmp/module41-matrix')
S = D / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not S.exists()
shutil.copytree('/Users/lanxingcan/Workspace/zstdoxize', S,
                ignore=shutil.ignore_patterns('.git', 'target', 'SESSION_HANDOFF.md'))
deadline = datetime.datetime(2026, 11, 5, 10, 11, tzinfo=datetime.timezone.utc).timestamp()
assert not (D / 'evidence.json').exists()
COUNTS = (130, 1884, 82)
ALL = 'unsafe-bitstream,unsafe-byte-cursor,unsafe-dictionary,unsafe-frame-sink,unsafe-fse,unsafe-fse-encoder,unsafe-history,unsafe-huffman,unsafe-huffman-codebook,unsafe-in-place-buffer,unsafe-match-chain,unsafe-match-table,unsafe-optimal-frequencies,unsafe-optimal-matches,unsafe-optimal-paths,unsafe-optimal-short-key,unsafe-reference-chain,unsafe-reference-tree,unsafe-ring-history,unsafe-row-table,unsafe-slice-history,unsafe-training'
features = sorted(f for f in tomllib.loads((S / 'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'))
assert len(features) == 22, features
source = {str(p.relative_to(S)): sha(p) for folder in ['src', 'tests', 'test-support'] for p in (S / folder).rglob('*') if p.is_file()}
source.update({n: sha(S / n) for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']})
plan = []
for name, flags in [('safe', []), ('all', ['--all-features'])] + [(f, ['--features', f]) for f in features]:
    plan.append((name + '-focused', ['cargo', 'test', '--offline', '--locked', '--test', 'reference_stream', '--test', 'compiled_stream', '--test', 'compiled_stream_selection', *flags]))
    plan.append((name + '-no-std', ['cargo', 'check', '--offline', '--locked', '--lib', '--no-default-features', *(['--features', ALL] if name == 'all' else flags)]))
    plan.append((name + '-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--tests', *flags, '--', '-D', 'warnings']))
plan += [('safe-release', ['cargo', 'test', '--offline', '--locked', '--release', '--test', 'reference_stream', '--test', 'compiled_stream', '--test', 'compiled_stream_selection']),
         ('all-release', ['cargo', 'test', '--offline', '--locked', '--release', '--all-features', '--test', 'reference_stream', '--test', 'compiled_stream', '--test', 'compiled_stream_selection'])]
for label, flags in [('safe', []), ('all', ['--features', ALL])]:
    plan.append(('thumb-' + label + '-check', ['cargo', 'check', '--offline', '--locked',
                                               '-Zbuild-std=core,alloc', '--target', 'thumbv6m-none-eabi',
                                               '--lib', '--no-default-features', *flags]))
    plan.append(('thumb-' + label + '-objects', ['cargo', 'rustc', '--release', '--offline', '--locked',
                                                 '-Zbuild-std=core,alloc', '--target', 'thumbv6m-none-eabi',
                                                 '--target-dir', str(D / ('target-' + label)),
                                                 '--no-default-features', '--lib', *flags,
                                                 '--', '--emit=llvm-ir,obj']))
plan += [('safe-full', ['cargo', 'test', '--offline', '--locked']), ('all-full', ['cargo', 'test', '--offline', '--locked', '--all-features'])]
plan.append(('format', ['cargo', 'fmt', '--all', '--', '--check']))
assert len(plan) == 81, len(plan)
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         deadline_utc=datetime.datetime.fromtimestamp(deadline, datetime.timezone.utc).isoformat(),
         features=features, source=source, expected_counts=list(COUNTS), commands=[], plan=plan,
         qualification='Intermediate regression only: 24 targeted feature configurations, no_std and strict Clippy, targeted safe/all release, ARM concrete output, full safe/all suites and formatting. Full isolated-feature and full release suites remain pending; ignored tests uncredited. No milestone completion.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(D / 'target'), 'CARGO_BUILD_JOBS': '4',
       'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_PROFILE_TEST_OPT_LEVEL': '0',
       'CARGO_PROFILE_DEV_DEBUG': '0'}


def counts(text):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert rows and all(int(f) == 0 for _, f, _ in rows), 'A test group failed'
    return len(rows), sum(int(p) for p, _, _ in rows), sum(int(i) for _, _, i in rows)


def save():
    p = D / 'evidence.pending.json'
    p.write_text(json.dumps(e, indent=2) + '\n')
    p.replace(D / 'evidence.json')


save()
try:
    for label, args in plan:
        remaining = deadline - time.time() - 30
        if remaining < 30:
            raise TimeoutError('User work window reached before ' + label)
        e['active_command'] = dict(label=label, argv=args, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
        start = time.monotonic()
        log = D / (label + '.log')
        with log.open('xb') as f:
            command_env = {**env, **({'CARGO_PROFILE_TEST_OPT_LEVEL':'1'} if label.endswith('-full') else {})}
            proc = subprocess.Popen(args, cwd=S, env=command_env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = proc.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                raise TimeoutError('User work window reached during ' + label)
        row = dict(label=label, argv=args, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
        if label.endswith(('-full', '-release', '-focused')) and code == 0:
            result = counts(log.read_text())
            assert result == (COUNTS if label.endswith('-full') else (3, 32, 0)), (label, result)
            row.update(result_groups=result[0], passed=result[1], ignored=result[2])
        if label.endswith('-objects') and code == 0:
            e['artifacts'] = e.get('artifacts', {})
            for suffix in ['.ll', '.o']:
                candidates = sorted((D / (label.replace('-objects', '').replace('thumb-', 'target-'))).rglob('*' + suffix), key=lambda p: p.stat().st_mtime)
                assert candidates, (label, suffix)
                e['artifacts'][label.replace('-objects', '') + suffix] = sha(candidates[-1])
        e['commands'].append(row)
        e.pop('active_command', None)
        save()
        print(label, code, flush=True)
        assert code == 0, label
    for n, h in source.items():
        assert sha(S / n) == h, ('Final source changed during matrix', n)
    assert len(e['commands']) == len(plan)
    e['status'] = 'complete'
    e['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print('complete', flush=True)
except BaseException as error:
    e['status'] = 'failed'
    e['error'] = repr(error)
    save()
    raise
