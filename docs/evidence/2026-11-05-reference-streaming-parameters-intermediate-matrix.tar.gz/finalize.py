from pathlib import Path
import hashlib,json,tarfile
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((D/'evidence.json').read_text());assert e['status']=='complete' and len(e['commands'])==81
for n,h in e['source'].items():assert sha(R/n)==h
for row in e['commands']:assert row['exit_code']==0 and sha(D/(row['label']+'.log'))==row['log_sha256']
archive=R/'docs/evidence/2026-11-05-reference-streaming-parameters-intermediate-matrix.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n in ['check.py','finalize.py','evidence.json','driver.log']:t.add(D/n,arcname=n)
 for row in e['commands']:t.add(D/(row['label']+'.log'),arcname=row['label']+'.log')
e['archive']={'path':str(archive.relative_to(R)),'sha256':sha(archive)}
e['limitations']='Only safe/all run full suites here. Isolated features and release run the 32 focused public tests. Thus 81 successful commands do not close the module full-suite gate.'
(R/'docs/evidence/2026-11-05-reference-streaming-parameters-intermediate-matrix.json').write_text(json.dumps(e,indent=2)+'\n')
p=R/'docs/reference-streaming-parameters-validation.md';s=p.read_text();a=s.index('## Remaining module gates')
s=s[:a]+'''## Intermediate feature and platform regression

All 81 planned intermediate commands pass on the frozen final source.
Safe/all and all 22 isolated features run the 32 focused streaming/selection
public tests, true host no_std, and strict library/all-test Clippy. Safe/all
release configurations run those same 32 targeted tests. Safe/all atomic-free
ARM checks and concrete release LLVM IR/object emission pass. Formatting and
the complete safe/all suites also pass: each full suite reports 130 result
groups, 1,884 passed, 82 ignored and zero failures. The new native ignored
adapter is qualified separately, not credited from its skipped ordinary run.

All-feature no_std explicitly lists the 22 unsafe flags with defaults disabled;
`--all-features` would otherwise also enable std. The intermediate receipt and
archive record command lists, source hashes, output-object hashes and logs.
These checks do not replace full isolated-feature suites or full release
suites. No Miri ran because only safe code changed.

'''+s[a:];p.write_text(s)
print('Intermediate matrix archived; full isolated-feature gate remains open')
