# Pre-Module-11 match-search baseline package

This package preserves the capture from codec commit
`ba4529c9e44eee2218209bb660038e42848d11e8`, before configurable search storage
or history changes. Its source of truth is the saved frame/input/dictionary bytes
from that capture, independently decoded by the pinned v1.5.7 C CLI. Packaging
only reads and hashes those saved bytes; it never runs a codec or regenerates an
expected result.

## Files and provenance

- `expected.tsv`: all **152 records**, 76 for `safe` and 76 for `all` twelve unsafe
  features. Every record keeps its original per-backend index, role, complete
  frame options, input/dictionary/output fingerprints, process schedule and
  observed capacities. Both backend records are retained even when equal.
- `cases.tsv`: twelve input recipes with their lengths and fingerprints.
- `metadata.json`: source hashes, FNV definition and accounting qualifications.
- `capture-evidence.json`: original commands, oracle outcomes, full file hashes,
  source revision and all recorded frame observations. Absolute `/tmp` paths
  identify the original capture; they are not required paths for future tests.
- `sources/`: byte-identical copies of the original Rust capture program, its
  Cargo files, capture runner, independent C verification runner and existing
  RDG support source. Their original hashes are in `metadata.json`.
- `package.py`: packaging program, which verifies the frozen saved SHA-256 and
  length of every byte source before deriving TSV fingerprints.
- `package-manifest.json`: package file lengths/hashes, excluding the manifest
  itself. Its SHA-256 is reported separately.

The original capture generator is `sources/capture.rs`, SHA-256
`5f924b243f1bc1d8c32b7aad7b4025e61cf0ad008d5e83996986f7964b50cb8e`.
The capture runner is `sources/capture.py`, SHA-256
`960769cd07450e9c6736bedda878f2e935ac6cd9e5d25e1b87a523f7de47586c`.
The oracle/evidence reproducer is `sources/oracle.py`, SHA-256
`149d1177f5678253522e16ddea6316f5c6e86bf921471c7ffa9e7a72b294a289`.
The complete additional source hashes, including the RDG implementation and
Cargo lockfile, are machine-readable in `metadata.json`.

## Fingerprint convention

SHA-256 is computed over each complete raw byte sequence. FNV is the existing
64-bit FNV-1a convention from `tests/upstream/support/mod.rs:247-248`:
start with `0xcbf29ce484222325`, XOR the next byte, multiply by
`0x100000001b3` with wrapping 64-bit arithmetic, and repeat. There is **no length
prefix, label, separator or frame wrapper** in the hashed bytes. FNV values are
lowercase, fixed-width sixteen-digit hexadecimal strings.

A missing dictionary uses kind `none`, zero lengths/ID/capacity, and `-` for both
hashes. This distinguishes no dictionary from an empty raw dictionary. The
present capture has no empty raw dictionary case.

## Future offline Rust regression, without C or new dependencies

The future test can include the TSV at compile time and parse tab-separated
fields with the standard library. It should consume the recorded expected
values, never write or recalculate them with the encoder under test.

1. Regenerate source material with the existing pinned `support::noise` helper.
   `cases.tsv` specifies all lengths, probabilities, seeds and slice boundaries.
   All three raw seed dictionaries are prefixes of the same 65,540-byte RDG
   source. The six history cases share a 262,144-byte RDG prefix and append the
   recorded 65,536-byte slice. No randomly chosen runtime seeds are permitted.
2. Reuse the already tracked
   `tests/upstream/dictionaries/formatted.dict` (2,197 bytes, dictionary ID
   `0x12345678`, content length 2,048). Its whole serialized SHA-256 is
   `354d5499788e19c3b2bb4f0f85d1a733c12204c3333f0f22e7f4fb01067b3281`.
   Cycle the parsed content as recorded. The tiny raw dictionary and flush input
   are the exact literal bytes in the recipe and original capture source.
3. Check regenerated input/dictionary lengths and FNV fingerprints before
   invoking compression. A changed generator must be detected separately from
   an encoder change. The existing dependency-free Python fixture auditor can
   independently verify SHA-256 when auditing assets; ordinary Rust tests need
   no SHA crate and no C executable.
4. For each case and strategy, create a fresh default encoder with only the
   recorded strategy/window selections. Attach the persistent dictionary when
   present. Do not add a pledge: all captured `pledged_size` fields are `none`.
   Use output slices of exactly 257 bytes. Supply the remaining input suffix on
   every call, using `Finish`; the short case first supplies its two-byte prefix
   with `Flush`, drains it completely, then supplies the remainder with `Finish`.
   Preserve the current latched-directive and progress requirements.
5. Compare each complete frame's recorded length and FNV. Also compare the
   exact bytes between the fresh and same-context `reset` reuse run. After
   resetting, assert that the previous owned allocations remain available and
   options/dictionary selection follow the recorded session-only reset contract.
6. Separately reuse one dictionary-attached context for the four recorded
   Greedy/Chain/Lazy/Greedy frames. Use `reset_with_options` before each frame,
   as the original generator does. Compare each frame's fingerprint against its
   own recorded row and its bytes against that strategy's fresh frame.
7. Run that normal test under the existing safe/individual/all-feature matrix.
   The `safe` and `all` recorded rows must remain distinct audit records; they
   are byte/metadata equivalent. Intermediate feature configurations can use
   those same expected frame fingerprints, without inventing a new captured
   backend label or pretending it was measured in the original capture.

Length plus FNV is a regression fingerprint, not a mathematical proof of byte
identity with an absent archived frame. SHA-256 preserves stronger archival
identification and the original complete C byte comparisons remain separately
recorded. Future C interoperability checks may supplement the normal test but
are not required for offline replay.

## Capacity fields are different measurements

`retained_capacity_before`, `retained_capacity_after` and
`peak_reachable_capacity` are the original public `Encoder::retained_capacity`
observations on the captured 64-bit host. They include selected dictionary
payload/tables once, plus owned codec buffers. They exclude inline fields,
shared outer control blocks and allocator bookkeeping.

`selected_dictionary_reachable_bytes` is derived from the original fresh
context before its first process call: no codec payload has yet been allocated,
and all three fresh strategies report the same value. These dictionaries remain
persistently selected through each captured frame. The package verifies this
agreement. It is not just the serialized dictionary length: formatted tables
also contribute to its reachable capacity.

Subtracting that value gives `owned_codec_retained_before/after`, which still
includes **all** codec allocations: search, staging, literal, sequence and
entropy storage. It does not yield a search-only metric.

`narrow_search_retained_capacity` is explicitly `not-recorded` because the new
Module-11 metric did not exist at capture time. It must not be fabricated as
zero, inferred from dictionary subtraction, or compared as if it had already
been measured. A future implementation can report that new metric alongside
these older totals with its own provenance.

Captured capacity values depend on target layout, allocation behavior and the
recorded construction history. Frame fingerprints are the default-compatibility
assertions. Capacity observations should be interpreted using that scope, not
asserted unchanged on every target or treated as a memory-limit/RSS promise.

## Recommended archival boundary

Archive `expected.tsv`, `cases.tsv`, provenance/metadata, the original capture
source and scripts, and the original independent C verification evidence. Keep
source attribution and the existing `LICENSE.zstd` references for RDG support.
The formatted dictionary already has a tracked, pinned fixture; reference it by
its current path and hash rather than duplicate its bytes.

Regenerate RDG inputs, raw dictionaries and tiny literal inputs offline. Do not
check in the 20,707,536 bytes of duplicate safe/all/fresh/reuse encoded frames,
or the repeated saved source/dictionary copies. All original bytes remain under
`/tmp/zstdoxide-module11-baseline-safe` and `...-all` for current review. Optional
long-term full-byte retention can be a separate deduplicated content-addressed
archive outside the source tree; it is not necessary for the normal regression.

These additions complement, and do not replace, existing committed default
fingerprint tests. No operational reference compression levels are implied.
