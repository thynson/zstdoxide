from pathlib import Path
import hashlib,json,os,shlex,subprocess,time
prefix='/tmp/zstdoxide-module11-baseline';helper=Path(prefix+'-driver');snapshot=json.loads(Path(prefix+'-snapshot.json').read_text());root=Path(snapshot['path']);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def unchanged():return all(sha(root/p)==h for p,h in snapshot['files'].items())
assert unchanged();records=[]
features=','.join('zstdoxide/'+n for n in ['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-dictionary','unsafe-training'])
for name,flags in [('safe',[]),('all',['--features',features])]:
 output=Path(prefix+'-'+name);command=['cargo','+nightly-2026-10-08','run','--offline','--release',*flags,'--',str(output)];env={'CARGO_TARGET_DIR':prefix+'-target','CARGO_TERM_COLOR':'never'};log=Path(prefix+'-'+name+'.log');start=time.monotonic();print('START '+name,flush=True)
 with log.open('wb')as stream:r=subprocess.run(command,cwd=helper,env=os.environ|env,stdout=stream,stderr=subprocess.STDOUT)
 entry={'backend':name,'command':command,'command_shell':shlex.join(command),'cwd':str(helper),'environment':env,'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':str(log),'log_sha256':sha(log),'snapshot_unchanged':unchanged()};records.append(entry);Path(prefix+'-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(entry,flush=True)
 if r.returncode or not unchanged():raise SystemExit(1)
