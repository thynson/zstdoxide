//! Read-only pre-Module-11 capture. The dependency is an immutable ba4529c archive.
use std::{fs, path::PathBuf};
use zstdoxide::{
    CompressionStrategy, Dictionary, Encoder, EncoderOptions, EndDirective, FrameHeader,
    SharedDictionary, StreamStatus,
};
#[allow(dead_code)]
#[path = "/tmp/zstdoxide-module11-baseline-ba4529c/tests/upstream/support/mod.rs"]
mod support;
const BLOCK: usize = 131_072;
const FORMATTED: &[u8] = include_bytes!(
    "/tmp/zstdoxide-module11-baseline-ba4529c/tests/upstream/dictionaries/formatted.dict"
);
struct Case {
    name: String,
    input: Vec<u8>,
    dictionary: Option<SharedDictionary>,
    dictionary_bytes: Vec<u8>,
    dictionary_kind: &'static str,
    window: u8,
    flush: usize,
    recipe: String,
}
fn cases() -> Vec<Case> {
    let mut cases = Vec::new();
    cases.push(Case {
        name: "rdg-three-blocks".into(),
        input: support::noise(3 * BLOCK + 17, 0.5, 0.5, 0),
        dictionary: None,
        dictionary_bytes: Vec::new(),
        dictionary_kind: "none",
        window: 17,
        flush: 0,
        recipe: "RDG(length=393233,match=0.5,literal=0.5,seed=0)".into(),
    });
    let history = support::noise(2 * BLOCK, 0.0, 0.0, 0xa55a_1234);
    for window in [17, 18] {
        for (label, start) in [("before", BLOCK - 1), ("at", BLOCK), ("after", BLOCK + 1)] {
            let mut input = history.clone();
            input.extend_from_slice(&history[start..start + BLOCK / 2]);
            cases.push(Case{name:format!("history-{label}-window{window}"),input,dictionary:None,dictionary_bytes:Vec::new(),dictionary_kind:"none",window,flush:0,recipe:format!("RDG(length=262144,match=0,literal=0,seed=2774143540)+copy(start={start},length=65536);third-block-start=262144;retained-start=131072")});
        }
    }
    let dictionary_source = support::noise(65_540, 0.0, 0.0, 1);
    for size in [65_538, 65_539, 65_540] {
        let bytes = dictionary_source[..size].to_vec();
        let dictionary = Dictionary::raw(&bytes).unwrap().into_shared();
        let input = bytes.iter().copied().cycle().take(2 * BLOCK + 37).collect();
        cases.push(Case{name:format!("raw-seed-{size}"),input,dictionary:Some(dictionary),dictionary_bytes:bytes,dictionary_kind:"raw",window:17,flush:0,recipe:format!("dictionary=prefix(RDG(length=65540,match=0,literal=0,seed=1),{size});input=cycle(dictionary,262181)")});
    }
    let dictionary = Dictionary::from_bytes(FORMATTED).unwrap().into_shared();
    let input = dictionary
        .content()
        .iter()
        .copied()
        .cycle()
        .take(2 * BLOCK + 37)
        .collect();
    cases.push(Case {
        name: "formatted-seed".into(),
        input,
        dictionary: Some(dictionary),
        dictionary_bytes: FORMATTED.to_vec(),
        dictionary_kind: "formatted",
        window: 17,
        flush: 0,
        recipe: "dictionary=formatted.dict;input=cycle(dictionary.content,262181)".into(),
    });
    let mut input = b"ab".to_vec();
    input.extend(b"xyzab".repeat(100));
    cases.push(Case {
        name: "short-flush-dictionary-crossing".into(),
        input,
        dictionary: Some(Dictionary::raw(b"xyz").unwrap().into_shared()),
        dictionary_bytes: b"xyz".to_vec(),
        dictionary_kind: "raw",
        window: 17,
        flush: 2,
        recipe: "dictionary=xyz;Flush(ab);Finish(repeat(xyzab,100))".into(),
    });
    assert_eq!(cases.len(), 12);
    cases
}
fn action(
    encoder: &mut Encoder,
    input: &[u8],
    directive: EndDirective,
    encoded: &mut Vec<u8>,
    peak: &mut usize,
) -> usize {
    let mut position = 0;
    let mut output = [0u8; 257];
    let mut calls = 0;
    loop {
        let p = encoder
            .process(&input[position..], &mut output, directive)
            .unwrap();
        calls += 1;
        assert!(p.consumed <= input.len() - position && p.produced <= output.len());
        position += p.consumed;
        encoded.extend_from_slice(&output[..p.produced]);
        *peak = (*peak).max(encoder.retained_capacity());
        if matches!(
            (directive, p.status),
            (EndDirective::Finish, StreamStatus::FrameFinished)
                | (EndDirective::Flush, StreamStatus::Flushed)
        ) {
            assert_eq!(position, input.len());
            return calls;
        }
        assert!(p.consumed + p.produced > 0, "no progress");
        assert!(calls < input.len() + encoded.len() + 100);
    }
}
fn blocks(frame: &[u8]) -> String {
    let (_, mut p) = FrameHeader::parse(frame).unwrap();
    let mut fields = Vec::new();
    loop {
        let bits = u32::from_le_bytes([frame[p], frame[p + 1], frame[p + 2], 0]);
        p += 3;
        let kind = (bits >> 1) & 3;
        let len = (bits >> 3) as usize;
        assert!(kind < 3);
        fields.push(format!("{kind}:{len}"));
        p += if kind == 1 { 1 } else { len };
        if bits & 1 != 0 {
            break;
        }
    }
    assert_eq!(p + 4, frame.len());
    fields.join(",")
}
fn record(
    root: &std::path::Path,
    case: &Case,
    strategy: CompressionStrategy,
    role: &str,
    encoder: &mut Encoder,
    expected: Option<&[u8]>,
) -> Vec<u8> {
    let before = encoder.retained_capacity();
    let mut peak = before;
    let mut encoded = Vec::new();
    let mut calls = 0;
    if case.flush != 0 {
        calls += action(
            encoder,
            &case.input[..case.flush],
            EndDirective::Flush,
            &mut encoded,
            &mut peak,
        );
    }
    calls += action(
        encoder,
        &case.input[case.flush..],
        EndDirective::Finish,
        &mut encoded,
        &mut peak,
    );
    if let Some(expected) = expected {
        assert_eq!(
            encoded, expected,
            "reset bytes differ: {} {strategy:?}",
            case.name
        );
    }
    assert_eq!(encoder.total_input(), case.input.len() as u64);
    assert_eq!(encoder.total_output(), encoded.len() as u64);
    let block_layout = blocks(&encoded);
    if case.input.len() > 2 * BLOCK {
        assert!(block_layout.split(',').count() >= 3);
    }
    let name = format!("{}-{strategy:?}-{role}.zst", case.name);
    fs::write(root.join(&name), &encoded).unwrap();
    println!(
        "FRAME\t{}\t{strategy:?}\t{role}\t{name}\t{}\t{}\t{before}\t{}\t{peak}\t{calls}\t{block_layout}",
        case.name,
        case.input.len(),
        encoded.len(),
        encoder.retained_capacity()
    );
    encoded
}
fn main() {
    let root = PathBuf::from(std::env::args_os().nth(1).expect("output directory"));
    fs::create_dir_all(&root).unwrap();
    let cases = cases();
    for case in &cases {
        fs::write(root.join(format!("{}.input", case.name)), &case.input).unwrap();
        if case.dictionary.is_some() {
            fs::write(
                root.join(format!("{}.dict", case.name)),
                &case.dictionary_bytes,
            )
            .unwrap();
        }
        println!(
            "INPUT\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
            case.name,
            case.input.len(),
            case.dictionary_kind,
            case.dictionary.as_ref().map_or(0, |d| d.id()),
            case.dictionary.as_ref().map_or(0, |d| d.content().len()),
            case.window,
            case.flush,
            case.recipe
        );
        for strategy in [
            CompressionStrategy::Greedy,
            CompressionStrategy::Chain,
            CompressionStrategy::Lazy,
        ] {
            let options = EncoderOptions {
                strategy,
                window_log: case.window,
                ..EncoderOptions::default()
            };
            let mut encoder = Encoder::with_options(options).unwrap();
            encoder.set_dictionary(case.dictionary.clone()).unwrap();
            let fresh = record(&root, case, strategy, "fresh", &mut encoder, None);
            let capacity = encoder.retained_capacity();
            encoder.reset();
            assert_eq!(encoder.retained_capacity(), capacity);
            assert_eq!(encoder.options(), options);
            record(
                &root,
                case,
                strategy,
                "reset-reuse",
                &mut encoder,
                Some(&fresh),
            );
        }
    }
    let case = cases.iter().find(|c| c.name == "raw-seed-65539").unwrap();
    let mut encoder = Encoder::new();
    encoder.set_dictionary(case.dictionary.clone()).unwrap();
    for (index, strategy) in [
        CompressionStrategy::Greedy,
        CompressionStrategy::Chain,
        CompressionStrategy::Lazy,
        CompressionStrategy::Greedy,
    ]
    .into_iter()
    .enumerate()
    {
        let before = encoder.retained_capacity();
        encoder
            .reset_with_options(EncoderOptions {
                strategy,
                window_log: case.window,
                ..EncoderOptions::default()
            })
            .unwrap();
        assert_eq!(encoder.retained_capacity(), before);
        let expected =
            fs::read(root.join(format!("{}-{strategy:?}-fresh.zst", case.name))).unwrap();
        record(
            &root,
            case,
            strategy,
            &format!("strategy-cycle-{index}"),
            &mut encoder,
            Some(&expected),
        );
    }
}
