"""Package frozen Module 11 bytes. Never invokes Cargo, Rust, C, or a codec."""
from pathlib import Path
import csv,hashlib,io,json,shutil
original=Path('/tmp/zstdoxide-module11-baseline-evidence.json');e=json.loads(original.read_text());package=Path('/tmp/zstdoxide-module11-baseline-package');package.mkdir(exist_ok=True);(package/'sources').mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
def fnv(data):
 value=0xcbf29ce484222325
 for byte in data:value=((value^byte)*0x100000001b3)&0xffffffffffffffff
 return f'{value:016x}'
assert fnv(b'')=='cbf29ce484222325'
assert fnv(b'a')=='af63dc4c8601ec8c'
assert fnv(b'foobar')=='85944171f73967e8'
def saved(path,length,digest):
 data=Path(path).read_bytes();assert len(data)==length and sha(data)==digest,path
 return data
sources={
 'capture.rs':'/tmp/zstdoxide-module11-baseline-driver/src/main.rs',
 'capture.Cargo.toml':'/tmp/zstdoxide-module11-baseline-driver/Cargo.toml',
 'capture.Cargo.lock':'/tmp/zstdoxide-module11-baseline-driver/Cargo.lock',
 'capture.py':'/tmp/zstdoxide-module11-baseline-run.py',
 'oracle.py':'/tmp/zstdoxide-module11-baseline-oracle.py',
 'rdg_support.rs':'/tmp/zstdoxide-module11-baseline-ba4529c/tests/upstream/support/mod.rs',
}
for name,path in sources.items():
 data=Path(path).read_bytes();assert sha(data)==e['files'][path]['sha256'];(package/'sources'/name).write_bytes(data)
(package/'capture-evidence.json').write_bytes(original.read_bytes())
(package/'package.py').write_bytes(Path(__file__).read_bytes())
fields=['backend','record_index','case','strategy','role','window_log','checksum','pledged_size','include_content_size','include_dictionary_id','flush_after_input_bytes','output_chunk_capacity','input_length','input_sha256','input_fnv1a64','dictionary_kind','dictionary_id','dictionary_serialized_length','dictionary_content_length','dictionary_sha256','dictionary_fnv1a64','selected_dictionary_reachable_bytes','output_length','output_sha256','output_fnv1a64','retained_capacity_before','retained_capacity_after','peak_reachable_capacity','owned_codec_retained_before','owned_codec_retained_after','process_calls','block_layout_type_and_payload_length','narrow_search_retained_capacity']
stream=io.StringIO(newline='');writer=csv.DictWriter(stream,fieldnames=fields,delimiter='\t',lineterminator='\n');writer.writeheader();records=[]
for backend in ['safe','all']:
 frames=e['frames'][backend];assert len(frames)==76
 for index,frame in enumerate(frames):
  case=e['cases'][backend][frame['case']];input=saved(case['input_path'],case['input_length'],case['input_sha256']);output=saved(frame['output_path'],frame['output_length'],frame['output_sha256']);dictionary=saved(case['dictionary_path'],case['dictionary_serialized_length'],case['dictionary_sha256'])if case['dictionary_kind']!='none'else None
  fresh=[f['retained_capacity_before']for f in frames if f['case']==frame['case']and f['role']=='fresh'];assert len(set(fresh))==1;dictionary_reachable=fresh[0];assert dictionary_reachable>=case['dictionary_serialized_length'];assert dictionary_reachable==0 if dictionary is None else True
  options=frame['options'];record={
   'backend':backend,'record_index':index,'case':frame['case'],'strategy':frame['strategy'],'role':frame['role'],'window_log':options['window_log'],'checksum':int(options['checksum']),'pledged_size':'none'if options['pledged_size']is None else options['pledged_size'],'include_content_size':int(options['include_content_size']),'include_dictionary_id':int(options['include_dictionary_id']),'flush_after_input_bytes':case['flush_after_input_bytes'],'output_chunk_capacity':frame['output_chunk_capacity'],'input_length':len(input),'input_sha256':sha(input),'input_fnv1a64':fnv(input),'dictionary_kind':case['dictionary_kind'],'dictionary_id':case['dictionary_id'],'dictionary_serialized_length':case['dictionary_serialized_length'],'dictionary_content_length':case['dictionary_content_length'],'dictionary_sha256':sha(dictionary)if dictionary is not None else'-','dictionary_fnv1a64':fnv(dictionary)if dictionary is not None else'-','selected_dictionary_reachable_bytes':dictionary_reachable,'output_length':len(output),'output_sha256':sha(output),'output_fnv1a64':fnv(output),'retained_capacity_before':frame['retained_capacity_before'],'retained_capacity_after':frame['retained_capacity_after'],'peak_reachable_capacity':frame['peak_reachable_capacity'],'owned_codec_retained_before':frame['retained_capacity_before']-dictionary_reachable,'owned_codec_retained_after':frame['retained_capacity_after']-dictionary_reachable,'process_calls':frame['process_calls'],'block_layout_type_and_payload_length':frame['block_layout_type_and_payload_length'],'narrow_search_retained_capacity':'not-recorded',
  }
  writer.writerow(record);records.append(record)
assert len(records)==152
for left,right in zip(records[:76],records[76:]):assert {k:v for k,v in left.items()if k!='backend'}=={k:v for k,v in right.items()if k!='backend'}
(package/'expected.tsv').write_text(stream.getvalue())
case_fields=['case','input_length','input_sha256','input_fnv1a64','dictionary_kind','dictionary_id','dictionary_serialized_length','dictionary_content_length','dictionary_sha256','dictionary_fnv1a64','selected_dictionary_reachable_bytes','window_log','flush_after_input_bytes','recipe'];stream=io.StringIO(newline='');writer=csv.DictWriter(stream,fieldnames=case_fields,delimiter='\t',lineterminator='\n');writer.writeheader()
for name,case in e['cases']['safe'].items():
 record=next(r for r in records if r['backend']=='safe'and r['case']==name);row={field:record[field]for field in case_fields if field!='recipe'};row['recipe']=case['recipe'];writer.writerow(row)
(package/'cases.tsv').write_text(stream.getvalue())
metadata={'source_evidence_sha256':sha(original.read_bytes()),'codec_revision':e['codec_revision'],'fnv1a64':{'offset_basis_hex':'cbf29ce484222325','prime_hex':'00000100000001b3','operation':'For each raw byte: (hash XOR byte) * prime modulo 2^64. No length prefix or framing is included.','reference':'tests/upstream/support/mod.rs:247-248'},'row_count':152,'rows_per_backend':76,'input_cases':12,'source_files':{name:{'original_path':path,'sha256':e['files'][path]['sha256'],'bytes':e['files'][path]['bytes']}for name,path in sources.items()},'dictionary_reachable_accounting':'The original fresh Encoder had no allocated codec payload before its first process call, so the equal retained_capacity_before observed across all three fresh strategy records is exactly the selected persistent dictionary reachable capacity. It remains selected throughout this capture. Subtracting it produces owned codec totals, not search-only totals.','narrow_search_capacity':'Not measured by ba4529c public API; never inferred as zero or as total minus dictionary.','derivation':'All data hashes and FNV values were derived from saved pre-change input/dictionary/output bytes after SHA256/length revalidation. No source regeneration or codec execution occurred.'}
(package/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('packaged',len(records),'records; expected.tsv bytes', (package/'expected.tsv').stat().st_size,'sha256',sha((package/'expected.tsv').read_bytes()))
