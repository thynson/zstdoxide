from pathlib import Path
import subprocess,shutil,json,hashlib
D=Path(__file__).parent;S=Path('/private/tmp/module32-final');R=Path('/private/tmp/module32-candidate');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not S.exists();subprocess.run(['cp','-cR',str(R),str(S)],check=True)
for folder,name in [('module32-native/replay-source','one_shot_selection_native.rs'),('module32-platform/source','one_shot_selection_platform.rs'),('module32-fuzz/source','upstream_trained_dictionary_fuzz.rs')]:shutil.copyfile(Path('/private/tmp')/folder/'tests'/name,S/'tests'/name)
subprocess.run(['cargo','fmt','--all'],cwd=S,check=True)
for p in (R/'src').glob('*.rs'):assert p.read_bytes()==(S/'src'/p.name).read_bytes()
source={str(p.relative_to(S)):sha(p) for f in ['src','tests','test-support'] for p in (S/f).rglob('*') if p.is_file()};source.update({n:sha(S/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']});(D/'preparation.json').write_text(json.dumps(dict(status='prepared',source=source,qualification='Frozen final call-scoped selection candidate assembled from public and exact native/history/platform test sources. Full-matrix dispatch is deferred until the preceding three modules finish timing; do not modify this snapshot.'),indent=2)+'\n')
