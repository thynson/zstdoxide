/* External supplementary oracle for compiled-dictionary schedules against pinned v1.5.7. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "zstd_errors.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

static const char *dict_names[2] = {"raw-a", "prepared-a"};
static unsigned char *dicts[2];
static size_t dict_sizes[2];
static ZSTD_DDict *ddicts[2];
static const char *input_root, *output_root;

static void checked(size_t result) {
    if (ZSTD_isError(result)) { fprintf(stderr, "native error: %s\n", ZSTD_getErrorName(result)); exit(20); }
}
static void path_of(char *path, size_t capacity, const char *root, const char *name, const char *suffix) {
    int n = snprintf(path, capacity, "%s/%s.%s", root, name, suffix);
    if (n < 0 || (size_t)n >= capacity) exit(21);
}
static unsigned char *read_file(const char *root, const char *name, const char *suffix, size_t *size) {
    char path[4096]; FILE *f; long n; unsigned char *p;
    path_of(path, sizeof(path), root, name, suffix); f = fopen(path, "rb");
    if (!f || fseek(f, 0, SEEK_END) || (n = ftell(f)) < 0 || fseek(f, 0, SEEK_SET)) exit(22);
    *size = (size_t)n; p = malloc(*size ? *size : 1);
    if (!p || fread(p, 1, *size, f) != *size || fclose(f)) exit(23);
    return p;
}
static void write_file(const char *name, const char *suffix, const void *bytes, size_t size) {
    char path[4096]; FILE *f;
    path_of(path, sizeof(path), output_root, name, suffix);
    f = fopen(path, "wb");
    if (!f || fwrite(bytes, 1, size, f) != size || fclose(f)) exit(24);
}
static void guards(const unsigned char *p, size_t capacity) {
    size_t i;
    for (i = 0; i < 16; i++) if (p[i] != 0xa5 || p[16 + capacity + i] != 0xa5) exit(25);
}
static int dict_index(const char *name) {
    int i;
    for (i = 0; i < 2; i++) if (!strcmp(name, dict_names[i])) return i;
    exit(26);
}
static ZSTD_dictContentType_e content_type(int index) { return index == 1 ? ZSTD_dct_fullDict : ZSTD_dct_rawContent; }
static int decode_matches(ZSTD_DCtx *dc, int index, const unsigned char *frame, size_t frame_size,
                          const unsigned char *input, size_t n) {
    unsigned char *out = malloc(n + 32);
    size_t result; int equal;
    if (!out) exit(31);
    memset(out, 0xa5, n + 32);
    result = ZSTD_decompress_usingDDict(dc, out + 16, n, frame, frame_size, ddicts[index]);
    guards(out, n);
    equal = !ZSTD_isError(result) && result == n && !memcmp(out + 16, input, n);
    free(out);
    return equal;
}
int main(int argc, char **argv) {
    FILE *steps; char input_path[4096], path[4096], id[128], dict[64], input_name[64];
    int level, window, fields, i; size_t rows = 0, supported = 0;
    ZSTD_CCtx *cc; ZSTD_DCtx *dc;
    if (argc != 3 || ZSTD_versionNumber() != 10507) return 2;
    if (snprintf(input_path, sizeof(input_path), "%s/inputs", argv[1]) < 0) return 3;
    input_root = input_path; output_root = argv[2];
    for (i = 0; i < 2; i++) {
        dicts[i] = read_file(input_root, dict_names[i], "dict", &dict_sizes[i]);
        ddicts[i] = ZSTD_createDDict_advanced(dicts[i], dict_sizes[i], ZSTD_dlm_byRef,
                                             content_type(i), ZSTD_defaultCMem);
        if (!ddicts[i]) return 4;
    }
    path_of(path, sizeof(path), argv[1], "steps", "tsv");
    steps = fopen(path, "r");
    cc = ZSTD_createCCtx(); dc = ZSTD_createDCtx();
    if (!steps || !cc || !dc) return 5;
    while ((fields = fscanf(steps, "%127s %d %d %63s %63s", id, &level, &window, dict, input_name)) == 5) {
        size_t n, cap, changed = 0, plain_size, plain_changed = 0, rust_size = 0;
        int index = dict_index(dict), rust_decode = -1, plain_differs, native_decode;
        unsigned char *input = read_file(input_root, input_name, "input", &n);
        unsigned char *storage, *plain_storage, *plain, *rust;
        ZSTD_compressionParameters cparams = ZSTD_getCParams(level, 0, dict_sizes[index]);
        ZSTD_CDict *cdict;
        if (window) cparams.windowLog = (unsigned)window;
        cdict = ZSTD_createCDict_advanced(dicts[index], dict_sizes[index], ZSTD_dlm_byRef,
                                          content_type(index), cparams, ZSTD_defaultCMem);
        if (!cdict) return 6;
        cap = ZSTD_compressBound(n);
        storage = malloc(cap + 32);
        if (!storage) return 7;
        memset(storage, 0xa5, cap + 32);
        {
            size_t frame_size;
            const unsigned char *frame;
            frame_size = ZSTD_compress_usingCDict(cc, storage + 16, cap, input, n, cdict);
            checked(frame_size);
            guards(storage, cap);
            frame = storage + 16;
            if (ZSTD_isError(frame_size)) return 8;
            for (i = 0; (size_t)i < cap - frame_size; i++) if (storage[16 + frame_size + i] != 0xa5) changed++;
            write_file(id, "zst", frame, frame_size);
            native_decode = decode_matches(dc, index, frame, frame_size, input, n);
            /* fresh no-dictionary control with the same level/window */
            plain_storage = malloc(cap + 32);
            if (!plain_storage) return 9;
            memset(plain_storage, 0xa5, cap + 32);
            checked(ZSTD_CCtx_reset(cc, ZSTD_reset_session_and_parameters));
            checked(ZSTD_CCtx_setParameter(cc, ZSTD_c_compressionLevel, level));
            if (window) checked(ZSTD_CCtx_setParameter(cc, ZSTD_c_windowLog, window));
            checked(ZSTD_CCtx_setParameter(cc, ZSTD_c_checksumFlag, 0));
            checked(ZSTD_CCtx_setParameter(cc, ZSTD_c_contentSizeFlag, 1));
            plain_size = ZSTD_compress2(cc, plain_storage + 16, cap, input, n);
            guards(plain_storage, cap);
            if (ZSTD_isError(plain_size)) return 10;
            for (i = 0; (size_t)i < cap - plain_size; i++) if (plain_storage[16 + plain_size + i] != 0xa5) plain_changed++;
            plain = malloc(plain_size ? plain_size : 1);
            if (!plain) return 11;
            memcpy(plain, plain_storage + 16, plain_size);
            plain_differs = !(plain_size == frame_size && !memcmp(plain, frame, plain_size));
            free(plain); free(plain_storage);
            rust = NULL;
            {
                char rust_path[4096]; FILE *f;
                path_of(rust_path, sizeof(rust_path), input_root, id, "rust");
                f = fopen(rust_path, "rb");
                if (f) {
                    long m;
                    if (fseek(f, 0, SEEK_END) || (m = ftell(f)) < 0 || fseek(f, 0, SEEK_SET)) return 12;
                    rust_size = (size_t)m; rust = malloc(rust_size ? rust_size : 1);
                    if (!rust || fread(rust, 1, rust_size, f) != rust_size || fclose(f)) return 13;
                    rust_decode = decode_matches(dc, index, rust, rust_size, input, n);
                    supported++;
                    free(rust);
                }
            }
            printf("%s\tok\t%zu\t%zu\t%zu\t%d\t%d\t%d\n", id, frame_size, changed,
                   plain_changed, rust_decode, plain_differs, native_decode);
            free(storage);
        }
        free(input); ZSTD_freeCDict(cdict);
        rows++;
    }
    if (fields != EOF || ferror(steps) || fclose(steps)) return 14;
    if (rows != 13 || supported != 11) return 15;
    ZSTD_freeCCtx(cc); ZSTD_freeDCtx(dc);
    for (i = 0; i < 2; i++) {
        size_t again;
        unsigned char *copy = read_file(input_root, dict_names[i], "dict", &again);
        if (again != dict_sizes[i] || memcmp(copy, dicts[i], again)) return 16;
        free(copy); ZSTD_freeDDict(ddicts[i]); free(dicts[i]);
    }
    return 0;
}
