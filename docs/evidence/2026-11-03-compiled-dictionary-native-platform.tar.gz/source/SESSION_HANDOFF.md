# Session handoff

Updated: 2026-11-03T04:40:00+00:00 (window ongoing; Module 37 items 1-10
committed; one mislabeled duplicate commit `8398c4f` was created after a server
restart and soft-reset — it is dangling, do not restore it)
Workspace: `/Users/lanxingcan/Workspace/zstdoxize`
Current HEAD: item-10 commit "Expose public compiled-dictionary calls" — clean
and qualified; the working tree is clean except this untracked handoff file.

## Standing user directives (recorded 2026-10-29)

- Validation-flow optimization, effective for future work items: run the
  relevant Miri verification only when a work item adds or modifies unsafe
  code. Items that touch only safe Rust skip Miri and keep their remaining
  qualification gates (focused unit/public checks, native/corpus where
  applicable, the full feature/release matrix, benchmarks). Concrete
  no-atomics ARM code-generation checks are outside this directive's stated
  scope unless the user extends it. Requested by the user during the
  2026-10-29 module35 completion window; apply from module36 onward. The
  module36 engine, DoubleFast, family and tree stages added no unsafe code,
  so no Miri ran. Module 37 item 3 (MatchTableView), items 6/7 (ChainCells,
  RowCells) and item 8 (TreeCells) each moved unsafe reads into a shared
  borrow and ran focused Miri; items 1/2/4/5/9/10 added no unsafe code.
- Preserve this directives section verbatim in every future handoff update.
- Boundary discipline recorded 2026-10-29 evening: advance until the stated
  local-time boundary, start no new tasks after it, and leave unqualified
  work only as clearly-labelled WIP commits that the next session resets.

## Restart incident (2026-11-03)

Two server restarts hit this window. The first rolled the conversation back
after the analysis commit; the resumed flow re-derived item 8 from scratch and
its implementation converged byte-for-byte with the working tree, then
committed items 8 and 9 (`009f487`, `cfabf40`). The second restart rolled the
conversation back into item-8 debugging while leaving item-10 WIP in the
working tree; the resumed flow unknowingly re-derived item 8 again, and the
resulting commit `8398c4f` was mislabeled (it described item 8 but contained
item-10 WIP swept in by a broad `git add`). It was soft-reset the same
session; `8398c4f` is dangling and `git reset --soft HEAD~1` restored the
tree. Lesson recorded: after any restart, check `git log` against the
handoff's expected HEAD before starting new work, and prefer `git add -p`
style staging over broad adds.

## Window (authorized 2026-11-03, 8 hours from 09:22 local): Module 37 items 8-10

1. Item 8 analysis (`bb3cc74`): the pinned dictionary binary-tree load is
   eager and fully sorted ("we want the dictionary table fully sorted",
   `zstd_compress.c:5019-5028` via `ZSTD_updateTree`/`ZSTD_insertBt1`,
   `zstd_opt.c:442-545`, with the fill-target window floor and the forward
   skip). At search time `ZSTD_DUBT_findBestMatch` (`zstd_lazy.c:281-380`)
   runs the context traversal first, suppresses the dictionary branch on an
   improving full-block match (`:349-353`), then consults
   `ZSTD_DUBT_findBetterDictMatch` (`:155-254`, reached at `:369-373`)
   strictly read-only with the remaining shared budget and the
   strictly-longer gate. The pinned upstream checkout had been pruned from
   /private/tmp; a fresh pinned fetch was restored at
   `/private/tmp/module24-preparation/zstd-git` (HEAD = f8745da6f, v1.5.7).
2. Item 8 implementation (`009f487`, re-derived identically post-restart):
   `TreeCells<'a>` shares checked head/edge reads between
   `ReferenceTree`, `ReferenceTreeView<'a>` and `StagedTreeView<'a>`;
   `TreeProbe::for_fill` computes the fill-target window floor;
   `tree_sort::load_sorted_prefix` mirrors `ZSTD_updateTree`/`ZSTD_insertBt1`
   (ascending positions, per-fill attempt cap, forward skip, no inserts within
   one eight-byte query footprint of the loaded end). `tree_search::find`
   counts context candidates, suppresses the compiled descent after an
   improving full-block match, and walks the compiled tree read-only with the
   remaining budget. `GreedySearch::Tree` carries the view; every compiled
   family keeps its sampling frontier at the prefix boundary. A boundary test
   rebuilds retained Optimal/Ultra/Ultra2 plans from resolved records and
   asserts a nonzero staged prefix still rejects with `UnsupportedFeature`
   before parser work. Level 10 resolves search log 9, past the tree plan's
   cap, and the constructor rejects that record; level 9 is the admitted
   compiled tree profile for small dictionaries. Miri ran the reference_tree
   and tree_sort suites, all five tree consultation tests and the compiled
   tree consultation test under `unsafe-reference-tree` (20 tests).
3. Item 9 (`cfabf40`): `compress_reference_with_compiled_in` emits compiled
   frames; the comparison test covers Fast (1), DoubleFast (3), chain Greedy
   (4), row (5, 32 KiB), BinaryTreeLazy2 (9) and a formatted Fast case over
   four deterministic inputs each. Fast, DoubleFast, chain, row and the
   formatted entropy seed match combined staging byte-for-byte; the tree
   family is the measured exception (8176 differing positions frozen in
   `docs/prepared-dictionary-analysis.md#compiled-frame-comparison-item-9`;
   compiled tree frames are often smaller, e.g. 18 vs 2058 bytes on the
   dictionary-prefix input). Both paths decode and release every owner.
4. Item 10 (this session's commit): `CompiledDictionary<'a, A>` is public with
   `new`, `parameters`, `loaded_len`, `content`, `dictionary_id` and `view`;
   `compress_with_compiled(_in)` and `compress_into_with_compiled(_in)` emit
   through the compiled frame path; `CompiledOneShotEncoder` coordinates
   repeated caller-owned calls. Every entry resolves its request against the
   actual source length and the dictionary content length and requires the
   exact compiled seven-field profile (`compiled_call_plan`), rejecting a
   mismatch with `InvalidParameter` before output admission. Four integration
   tests cover allocating/caller-owned byte equality across five families,
   formatted entropy and identifier preservation (byte-equal to the Module 36
   combined path), mismatch/empty/optimal-family rejection before writes, and
   complete allocation-failure release sweeps for both paths. Doctests pin the
   dictionary-view lifetime and input/output borrow non-overlap. The
   frame-encode refactor shares one `compress_reference_with_compiled_to`
   between allocating and caller-owned emission.

## Module 37 state and next steps

Checklist: `TODO.md` Module 37. Items 1-10 are checked. Next: item 11 —
qualify guarded native schedules, window expiry, unsupported-profile rejection
and concrete atomic-free ARM code generation (mirror the module36 platform
campaign under /private/tmp). Then item 12 (full feature/release matrix),
item 13 (timing with CPU barriers), item 14 (reconciliation and closure).
`docs/prepared-dictionary-validation.md` records the evidence so far.

Session controllers, campaigns and receipts live under /private/tmp as listed
in the prior handoffs; the module36 promotion chain stays closed. Reference
and final records are unchanged: pinned upstream f8745da6ff1ad1e7bab384bd1f9d742439278e99
(v1.5.7), Rust nightly-2026-10-08 (1.101).
