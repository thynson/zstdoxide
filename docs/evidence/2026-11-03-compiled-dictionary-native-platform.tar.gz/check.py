"""Module37 guarded native schedules and concrete atomic-free ARM checks for
compiled dictionary emission.

Normal and sanitized pinned v1.5.7 CDict controls cover supported families,
window-capped dictionaries, raw/formatted entropy seeds and unsupported
optimal-family construction. Rust frames decode natively and native frames
decode in Rust. Concrete thumbv6m checks and release IR/objects cover the safe
and all-feature library. No foreign Miri runs because no unsafe code was added.
"""
from pathlib import Path
import os, subprocess, json, hashlib, time, datetime, re, signal, shutil

D = Path(__file__).parent
S = D / 'source'
U = Path('/private/tmp/module24-preparation/zstd-git')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
deadline = datetime.datetime.fromisoformat('2026-11-03T05:30:00+00:00').timestamp()
assert deadline - time.time() >= 120
ALL = 'unsafe-bitstream,unsafe-byte-cursor,unsafe-dictionary,unsafe-frame-sink,unsafe-fse,unsafe-fse-encoder,unsafe-history,unsafe-huffman,unsafe-huffman-codebook,unsafe-in-place-buffer,unsafe-match-chain,unsafe-match-table,unsafe-optimal-frequencies,unsafe-optimal-matches,unsafe-optimal-paths,unsafe-optimal-short-key,unsafe-reference-chain,unsafe-reference-tree,unsafe-ring-history,unsafe-row-table,unsafe-slice-history,unsafe-training'
source = {}
for folder in ['src', 'tests', 'test-support']:
    for p in (S / folder).rglob('*'):
        if p.is_file():
            source[str(p.relative_to(S))] = sha(p)
for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']:
    source[n] = sha(S / n)
library = {str(p.relative_to(U)): sha(p) for p in (U / 'lib').rglob('*')
           if p.is_file() and p.suffix in ['.c', '.h', '.S']}
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         deadline_utc='2026-11-03T05:30:00+00:00', source=source,
         production_source={n: h for n, h in source.items() if n.startswith('src/')},
         reference_revision=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=U, text=True).strip(),
         library=library, helper_sha256=sha(D / 'compiled_dictionary_oracle.c'), commands=[],
         qualification='Focused Module37 native/platform item only: 13 typed compiled-dictionary cases cover supported Fast/DoubleFast/Greedy/tree profiles, raw and formatted attachments, window-capped inputs and unsupported optimal-family construction against normal and sanitized pinned v1.5.7 CDict controls. Rust frames decode natively and native frames decode in Rust; native byte/capacity/workspace identity is not required. Concrete thumbv6m checks and IR/objects cover safe and all-feature library builds. No matrix, timing, complete foreign-platform or milestone closure is claimed.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(D / 'target'), 'CARGO_BUILD_JOBS': '6',
       'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
       'CARGO_PROFILE_TEST_OPT_LEVEL': '1'}
artifacts = D / 'artifacts'
artifacts.mkdir(exist_ok=True)


def save():
    (D / 'evidence.json').write_text(json.dumps(e, indent=2) + '\n')


def run(label, args, extra=None, cwd=S, expected=None):
    remaining = deadline - time.time() - 15
    if remaining < 15:
        raise TimeoutError('deadline before ' + label)
    e['active_command'] = dict(label=label, argv=args, environment=extra or {},
                               started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
    start = time.monotonic()
    log = D / (label + '.log')
    with log.open('xb') as f:
        p = subprocess.Popen(args, cwd=cwd, env={**env, **(extra or {})}, stdout=f,
                             stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = p.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGTERM)
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                p.wait()
            raise TimeoutError('deadline during ' + label)
    row = dict(label=label, argv=args, environment=extra or {}, exit_code=code,
               seconds=time.monotonic() - start, log_sha256=sha(log))
    if code == 0 and expected is not None:
        groups = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text())
        assert groups == [(str(expected), '0', '0')], (label, groups)
        row.update(passed=expected, failed=0, ignored=0)
    e['commands'].append(row)
    e.pop('active_command', None)
    save()
    print(label, code, flush=True)
    assert code == 0, (label, log.read_text()[-4000:])


def inventory(folder):
    return {str(p.relative_to(folder)): sha(p) for p in folder.rglob('*') if p.is_file()}


save()
try:
    export = D / 'safe-export'
    export.mkdir(exist_ok=True)
    run('safe-export', ['cargo', 'test', '--offline', '--locked', '--test', 'compiled_dictionary_native',
                        'compiled_dictionary_schedules_interoperate_with_guarded_native_controls',
                        '--', '--ignored', '--exact', '--nocapture'],
        dict(ZSTDOXIDE_COMPILED_NATIVE=str(export), ZSTDOXIDE_COMPILED_EXPORT='1'), expected=1)
    e['inputs'] = inventory(export)
    save()
    sources = sorted((U / 'lib/common').glob('*.c')) + sorted((U / 'lib/decompress').glob('*.c')) + sorted((U / 'lib/compress').glob('*.c'))
    for label, flags in [('normal', ['-O2']),
                         ('sanitized', ['-O1', '-g', '-fsanitize=address,undefined', '-fno-omit-frame-pointer'])]:
        exe = D / ('oracle-' + label)
        run(label + '-build', ['cc', '-std=c99', '-Wall', '-Wextra', '-Werror', '-DZSTD_MULTITHREAD=0',
                               '-I' + str(U / 'lib'), '-I' + str(U / 'lib/common'), *flags,
                               str(D / 'compiled_dictionary_oracle.c'),
                               *[str(p) for p in sources], '-o', str(exe)])
        e.setdefault('executables', {})[label] = sha(exe)
        save()
        output = D / (label + '-outputs')
        output.mkdir(exist_ok=True)
        run(label + '-capture', [str(exe), str(export), str(output)],
            dict(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',
                 UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'), cwd=D)
        shutil.copyfile(D / (label + '-capture.log'), D / (label + '.tsv'))
    normal = (D / 'normal.tsv').read_text().splitlines()
    assert len(normal) == 13, len(normal)
    assert (D / 'normal.tsv').read_bytes() == (D / 'sanitized.tsv').read_bytes()
    assert inventory(D / 'normal-outputs') == inventory(D / 'sanitized-outputs')
    outputs = inventory(D / 'normal-outputs')
    assert len(outputs) == 13
    rows = [line.split('\t') for line in normal]
    assert all(len(row) == 8 and row[1] == 'ok' and row[7] == '1' for row in rows)
    assert sum(row[5] == '1' for row in rows) == 11
    assert sum(row[5] == '-1' for row in rows) == 2
    e.update(rows=13, supported=11, rejected=2, outputs=outputs)
    save()
    replay = D / 'replay'
    replay.mkdir(exist_ok=True)
    shutil.copytree(export / 'inputs', replay / 'inputs', dirs_exist_ok=True)
    shutil.copyfile(export / 'steps.tsv', replay / 'steps.tsv')
    shutil.copyfile(D / 'normal.tsv', replay / 'native.tsv')
    shutil.copytree(D / 'normal-outputs', replay / 'outputs', dirs_exist_ok=True)
    for label, flags in [('safe', []), ('all', ['--all-features'])]:
        run(label + '-replay', ['cargo', 'test', '--offline', '--locked', '--test', 'compiled_dictionary_native',
                                'compiled_dictionary_schedules_interoperate_with_guarded_native_controls',
                                '--', '--ignored', '--exact', '--nocapture'],
            dict(ZSTDOXIDE_COMPILED_NATIVE=str(replay)), expected=1)
        run(label + '-platform', ['cargo', 'test', '--offline', '--locked', '--test', 'compiled_dictionary_platform', *flags], expected=2)
        run(label + '-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--test',
                                'compiled_dictionary_native', '--test', 'compiled_dictionary_platform',
                                *flags, '--', '-D', 'warnings'])
    e['artifacts'] = {}
    save()
    run('thumb-safe-check', ['cargo', 'check', '--offline', '--locked', '-Zbuild-std=core,alloc',
                             '--target', 'thumbv6m-none-eabi', '--no-default-features', '--lib'])
    run('thumb-all-check', ['cargo', 'check', '--offline', '--locked', '-Zbuild-std=core,alloc',
                            '--target', 'thumbv6m-none-eabi', '--no-default-features', '--lib',
                            '--features', ALL])
    for label, flags, target in [('safe', [], 'target-safe'), ('all', ['--features', ALL], 'target-all')]:
        run('thumb-' + label + '-objects', ['cargo', 'rustc', '--release', '--offline', '--locked',
                                           '-Zbuild-std=core,alloc', '--target', 'thumbv6m-none-eabi',
                                           '--target-dir', str(D / target), '--no-default-features',
                                           '--lib', *flags, '--', '--emit=llvm-ir,obj'])
        out = D / target
        files = {}
        for suffix in ['.ll', '.o']:
            candidates = sorted(out.rglob('*' + suffix), key=lambda p: p.stat().st_mtime)
            assert candidates, (target, suffix)
            p = candidates[-1]
            q = artifacts / (label + '-' + p.name)
            shutil.copyfile(p, q)
            files[suffix] = dict(path=str(q.relative_to(D)), bytes=q.stat().st_size, sha256=sha(q))
        e['artifacts'][label] = files
        save()
    run('format', ['cargo', 'fmt', '--all', '--', '--check'])
    for n, h in source.items():
        assert sha(S / n) == h, ('Source changed during the campaign', n)
    e.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
except TimeoutError as ex:
    e.update(status='interrupted-at-deadline', error=repr(ex)); save(); raise
except BaseException as ex:
    e.update(status='failed', error=repr(ex)); save(); raise
