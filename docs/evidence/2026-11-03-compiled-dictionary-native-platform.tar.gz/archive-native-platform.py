"""Archive the qualified Module37 native/platform campaign."""
from pathlib import Path
import json, hashlib, tarfile, datetime

D = Path(__file__).parent
C = Path('/private/tmp/module37-native')
S = C / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
j = json.loads((C / 'evidence.json').read_text())
assert j['status'] == 'passed' and len(j['commands']) == 16
for n, h in j['source'].items():
    assert sha(S / n) == h, n
for r in j['commands']:
    assert r['exit_code'] == 0 and sha(C / (r['label'] + '.log')) == r['log_sha256']
files = {}
for p in C.rglob('*'):
    if not p.is_file():
        continue
    n = p.relative_to(C)
    if any(x in {'target', 'target-safe', 'target-all', 'safe-export', 'normal-outputs', 'sanitized-outputs', 'replay', '__pycache__'} for x in n.parts):
        continue
    if n.name.startswith('oracle-'):
        continue
    if p.suffix in {'.rs', '.toml', '.lock', '.json', '.py', '.log', '.md', '.tsv', '.c', '.ll', '.o'}:
        files[str(n)] = p
files['archive-native-platform.py'] = Path(__file__)
name = '2026-11-03-compiled-dictionary-native-platform'
archive = D / (name + '.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for n, p in sorted(files.items()):
        t.add(p, arcname=n)
r = dict(status='passed', recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source=j['source'], production_source=j['production_source'], reference_revision=j['reference_revision'], library=j['library'], helper_sha256=j['helper_sha256'], commands=j['commands'], rows=j['rows'], supported=j['supported'], rejected=j['rejected'], inputs=j['inputs'], outputs=j['outputs'], executables=j['executables'], artifacts=j['artifacts'], members={n: dict(bytes=p.stat().st_size, sha256=sha(p)) for n, p in files.items()}, archive=archive.name, archive_sha256=sha(archive), qualification='Focused Module37 native/platform item only: 13 typed compiled-dictionary cases cover supported Fast/DoubleFast/Greedy/tree profiles, raw and formatted attachments, window-capped inputs and unsupported optimal-family construction against normal and sanitized pinned v1.5.7 CDict controls. Rust frames decode natively and native frames decode in Rust; native byte/capacity/workspace identity is not required. Concrete thumbv6m checks and IR/objects cover safe and all-feature library builds. No matrix, timing, complete foreign-platform or milestone closure is claimed.')
(D / (name + '.json')).write_text(json.dumps(r, indent=2) + '\n')
print(name, archive.stat().st_size)
