"""Promote the qualified Module37 native/platform item."""
from pathlib import Path
import json, hashlib, subprocess, shutil

D = Path(__file__).parent
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
S = Path('/private/tmp/module37-native/source')
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
name = '2026-11-03-compiled-dictionary-native-platform'
p = D / (name + '.json')
r = json.loads(p.read_text())
assert r['status'] == 'passed' and sha(D / r['archive']) == r['archive_sha256']
changed = []
for n in ['tests/compiled_dictionary_native.rs', 'tests/compiled_dictionary_platform.rs']:
    assert sha(S / n) == r['source'][n], n
    shutil.copyfile(S / n, R / n)
    changed.append(n)
for q in [p, D / r['archive']]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
    changed.append('docs/evidence/' + q.name)
p = R / 'TODO.md'
s = p.read_text()
task = '- [ ] Qualify guarded native schedules, window expiry, unsupported-profile rejection and concrete atomic-free ARM code generation.'
assert s.count(task) == 1
s = s.replace(task, task.replace('[ ]', '[x]'))
p.write_text(s)
changed.append('TODO.md')
p = R / 'docs/prepared-dictionary-validation.md'
s = p.read_text()
old = '''Remaining Module 37 items are guarded native schedules, the full feature and
release matrix, timing with CPU barriers, and final reconciliation.'''
assert s.count(old) == 1
s = s.replace(old, '''## Guarded native schedules

Thirteen typed compiled-dictionary cases run against normal and sanitized
pinned v1.5.7 CDict controls: Fast, DoubleFast, chain and BinaryTreeLazy2,
raw and formatted attachments, empty/no-match and multi-block inputs, a
window-capped raw dictionary, and unsupported Optimal/Ultra2 construction.
Both builds produce identical thirteen rows and frames; Rust frames decode
natively, native frames decode in Rust, every observable native dictionary
control differs from its fresh no-dictionary control, and the window-capped
Rust case equals the dictionary-free parameterized bytes (native window
adjustment differs and is not claimed as byte identity). Eleven supported and
two rejected rows are retained, with independent destination guards.
Evidence: `evidence/{name}.json`.

## Concrete no-atomics ARM emission

Compiled allocating, caller-owned and coordinator paths run on the host under
safe and all features. Library checks and release LLVM IR/object emission pass
for `thumbv6m-none-eabi` with safe and every opt-in storage backend together;
the IR and object artifacts are retained. Foreign Miri was not run because this
item added or modified no unsafe code, per the standing direction.

Remaining Module 37 items are the full feature and release matrix, timing with
CPU barriers, and final reconciliation.'''.format(name=name))
p.write_text(s)
changed.append('docs/prepared-dictionary-validation.md')
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *changed], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Qualify compiled dictionary calls natively and on atomic-free ARM'], cwd=R, check=True)
print('module37 native/platform promoted at', subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()[:12])
