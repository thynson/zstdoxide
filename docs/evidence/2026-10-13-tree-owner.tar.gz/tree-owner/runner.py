from pathlib import Path
import hashlib,json,os,re,subprocess,time,tomllib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-owner-checks');O.mkdir();env=os.environ.copy();env['CARGO_TARGET_DIR']='/tmp/zstdoxide-tree-reader-target'
flags=[x for x in tomllib.loads((R/'Cargo.toml').read_text())['features'] if x.startswith('unsafe-')];assert len(flags)==15
paths=sorted((R/'src').glob('*.rs'))+[R/n for n in ['Cargo.toml','Cargo.lock','scripts/check.sh','README.md']]
source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};rows=[]
def run(label,args,tests=None):
 log=O/(label+'.log');start=time.monotonic()
 with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
 b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest());rows.append(r);print(label,p.returncode,flush=True)
 if tests is not None:
  counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)];r['tests']=counts
  if counts!=[tests]:raise ValueError('test totals '+label)
 if p.returncode:raise ValueError(label)
base=['cargo','test','--offline','--locked'];check=['cargo','check','--offline','--locked','--no-default-features']
for config in ['safe',*flags,'all']:
 args=[] if config=='safe' else ['--all-features'] if config=='all' else ['--features',config]
 run('owner-'+config,base+args+['--lib','reference_tree::tests'],(7,0,1))
 no=[] if config=='safe' else ['--features',','.join(flags) if config=='all' else config]
 run('nostd-'+config,check+no)
run('owner-release-all',base+['--release','--all-features','--lib','reference_tree::tests'],(7,0,1))
for config,args in [('safe',[]),('tree',['--features','unsafe-reference-tree']),('all',['--all-features'])]:
 run('baseline-'+config,base+args+['--test','reference_lazy_defaults'],(21,0,0))
for config,args in [('safe',[]),('all',['--all-features'])]:
 run('clippy-'+config,['cargo','clippy','--offline','--locked','--all-targets',*args,'--','-D','warnings'])
run('format',['cargo','fmt','--all','--','--check'])
assert source=={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,owner_tests=126,baseline_tests=63,no_std_configurations=17,feature_inventory=flags,qualification='Focused owner and permanent frame/allocator baseline checks, not a full codec matrix. Benchmark is explicitly ignored in correctness runs.'),sort_keys=True,indent=2)+'\n')
