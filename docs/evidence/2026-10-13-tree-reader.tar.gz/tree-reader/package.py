from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';sha=lambda b:hashlib.sha256(b).hexdigest()
for mode in ['safe','all']:
 if 'test result: ok. 8 passed; 0 failed; 0 ignored;' not in Path('/tmp/zstdoxide-tree-reader-'+mode+'-final.log').read_text():raise ValueError('final tests')
for name in ['clippy-final','clippy-all-final']:
 b=Path('/tmp/zstdoxide-tree-reader-'+name+'.log').read_text()
 if 'Finished' not in b or 'error:' in b:raise ValueError('clippy')
if Path('/tmp/zstdoxide-tree-reader-format.log').read_bytes():raise ValueError('format')
files={p.name:p.read_bytes() for p in Path('/tmp').glob('zstdoxide-tree-reader-*.log')}
files['tests/reference_tree_fixture.rs']=(R/'tests/reference_tree_fixture.rs').read_bytes();files['package.py']=Path(__file__).read_bytes()
a=E/'2026-10-13-tree-reader.tar.gz'
if a.exists():raise ValueError('fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('tree-reader/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:actual={m.name:t.extractfile(m).read() for m in t}
if actual!={'tree-reader/'+n:b for n,b in files.items()}:raise ValueError('archive bytes')
r=dict(status='passed',tests_per_configuration=8,configurations=['safe','all'],clippy=['safe','all'],format=True,source_sha256=sha(files['tests/reference_tree_fixture.rs']),fixture_sha256=sha((R/'tests/fixtures/reference-tree/cases.bin').read_bytes()),archive=a.name,archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files),qualification='Independent safe test-only reader, not a tree search implementation. All 2334 operations replay source/hash/map invariants. Initial parameter-order interpretation failure and initial Clippy diagnostic are retained with corrected final runs. Existing Module 15 immutable matrix does not retroactively include these additive tests. No production codec or feature inventory changed.')
(E/'2026-10-13-tree-reader.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n');print('Archived sixteen final test executions and focused lint/format results')
