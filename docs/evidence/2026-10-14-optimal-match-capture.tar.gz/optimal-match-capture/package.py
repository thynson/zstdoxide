from pathlib import Path
import hashlib,io,json,sys,tarfile
R=Path('/Users/lanxingcan/.codex/worktrees/optimal-frequency/zstdoxize');O=Path('/private/tmp/zstdoxide-optimal-matches-2026-10-14');sys.path.insert(0,str(R/'scripts'));sys.dont_write_bytecode=True
import check_optimal_match_capture_v2 as audit
report=audit.audit(O)
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
files={}
for p in O.rglob('*'):
 if p.is_file():
  if p.is_symlink():raise ValueError('symlink')
  files['capture/'+str(p.relative_to(O))]=p.read_bytes()
for mode in ['normal','optimized']:
 b=Path('/tmp/zstdoxide-optimal-match-controls-'+mode+'.log').read_bytes();v=json.loads(b)
 if v['status']!='passed' or len(v['rejections'])!=33 or v['child_attempts']!=0 or v['positive_audits']!=2:raise ValueError('controls')
 files['checks/controls-'+mode+'.json']=b
 for version in ['','-v2']:
  files['checks/model'+version+'-'+mode+'.json']=Path('/tmp/zstdoxide-optimal-match-model'+version+'-'+mode+'.log').read_bytes()
for n in ['scripts/oracles/optimal_match_validation_v2.py','scripts/check_optimal_match_validation_v2.py','scripts/check_optimal_match_capture_v2.py','scripts/check_optimal_match_capture_controls.py','scripts/check_optimal_match_capture_controls_v2.py']:
 files['reconciliation/'+n]=(R/n).read_bytes()
files['checks/capture-controller.log']=Path('/tmp/zstdoxide-optimal-matches-capture.log').read_bytes();files['checks/audit-v2.json']=Path('/tmp/zstdoxide-optimal-match-audit-v2.log').read_bytes();files['package.py']=Path(__file__).read_bytes()
report.update(date='2026-10-14',original_capture_status='failed',original_failure="ValueError('independent complete search state')",correction='minMatch3 primary heads use hash4; only the short-key owner uses hash3. Original sources, unsuccessful v1 comparison and all successful C command transcripts remain unchanged.',reconciliation_sources={n:sha(b) for n,b in files.items() if n.startswith('reconciliation/')},forged_rejections_per_mode=33,positive_audits_per_mode=2,child_attempts=0,raw_files=len(files),raw_bytes=sum(map(len,files.values())),archive='2026-10-14-optimal-match-capture.tar.gz')
files['report.json']=enc(report)
files['file-manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())})
a=R/'docs/evidence'/report['archive']
if a.exists():raise ValueError('fresh archive required')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('optimal-match-capture/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 if {m.name:t.extractfile(m).read() for m in t}!={'optimal-match-capture/'+n:b for n,b in files.items()}:raise ValueError('archive verification')
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(files))
(R/'docs/evidence/2026-10-14-optimal-match-capture.json').write_bytes(enc(report))
p=R/'TODO.md';s=p.read_text().replace('- [ ] Capture direct operations and qualify all-match ordering, window/node floors, three-byte tails and forged evidence.','- [x] Capture tiny direct operations and qualify exact all-match maps, short-key tails and forged evidence.\n- [ ] Project audited tiny match observations into bounded fixtures and add an independent Rust reader.\n- [ ] Capture broader ordinary-geometry/distance/repeat operations before implementing the production sorted search.');p.write_text(s)
p=R/'docs/data-structures.md';s=p.read_text();s=s.replace('Optimal hashing clamps widths to 3..6; minimum-match 3 is real three-byte matching','Optimal template minimum clamps to 3..6, but the primary tree hash uses widths\n4..6 (ZSTD_hashPtr defaults to hash4 for template minimum 3). Only the separate\nshort-key table uses hash3. Minimum-match 3 is real three-byte matching');p.write_text(s)
p=R/'docs/reference-optimal-validation.md';s=p.read_text();s+='''\n## Tiny C match capture and primary-hash correction\n\nThe 164-command capture executed all 29 recipes / 273 operations with two padding\npasses in normal and fully ASan/UBSan-instrumented builds. All 22 malformed packets\nper build were rejected before output; every C command completed as planned.\nThe initial independent comparison failed: its primary hash incorrectly used\nthree bytes for minMatch3. Upstream ZSTD_hashPtr defaults to four-byte hashing;\nonly the separate short-key table uses three bytes. Earlier preparation text\nabout a three-byte primary hash is superseded by this explicit correction.\n\nThe original failed envelope and all original code/logs remain unchanged. The\nadditive v2 model independently matches every head, paired edge, short-key head,\nfrontier and ordered candidate. Both padding passes and both C builds agree\nexactly. Normal and optimized Python each reject 33 capture forgeries with two\npositive audits and zero child execution. The v2 synthetic controls additionally\nreject 44 forged records per mode and distinguish the primary/short-key buckets.\n\n`evidence/2026-10-14-optimal-match-capture.json` binds the full lossless archive,\nincluding every object and executable, all 18,857,576 raw log bytes and the v1\nfailure. This is a reconciled offline audit of actual C observations, not a\nretroactive passing v1 run. Ordinary CCtx geometry and the 2^18 distance boundary\nremain open; no Rust sorted-search or public Optimal admission is claimed.\n''';p.write_text(s)
print(a.name,a.stat().st_size,len(files),report['archive_sha256'])
