# Bounded reference binary-tree measurements

The new harness uses 24 deterministic tree cases: four immutable historical
corpora crossed with six explicit W/H/C/S profiles. Profiles cover small tables,
maximum admitted owners, search log 8, a short window, a tiny wrapping node ring,
and an ignored target-length equivalence. `tree-wide` and `tree-target` must
produce identical complete frames and exact allocator records. Public tuples
are independently adjusted from explicit scalars and known source lengths.

The previous eighty Fast/DoubleFast/Greedy/Lazy/Lazy2 frame and qualified owner
baselines remain permanent full-matrix tests. Their historical timing campaigns
are unchanged; this campaign measures only tree strategy 6. No row-table timing
is relabeled as tree behavior.

Each executable's default mode is clock-free. Build every requested backend
before running any measurements. Record all 15 independent unsafe leaves plus
safe and all features. Complete output bytes, decompression, deterministic
source fingerprints and allocator surveys are checked outside clocks. Timing
covers global-allocation one-shot compression and output destruction, with five
samples of at least 100 ms per case. Run a separate safe/all repeat only after
completion barriers for all task-owned correctness, platform and clock-free jobs.
The barrier does not prove absence of unrelated desktop load.

No measurements have been qualified at this preparation checkpoint. Results,
raw samples, exact frames/owners, compiler/feature identities and limitations
will be recorded separately. An inactive feature's timing difference does not
establish a causal advantage, and no universal unsafe speedup is presumed.
