from pathlib import Path
import hashlib,json,os,re,subprocess,time
ORIGINAL=Path('/tmp/zstdoxide-module16-final-matrix')
OUT=Path('/tmp/zstdoxide-module16-final-matrix-resumed-2026-10-14');OUT.mkdir()
WORK=ORIGINAL/'source';TARGET=ORIGINAL/'target'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source():return {str(p.relative_to(WORK)):sha(p) for p in sorted(WORK.rglob('*')) if p.is_file()}
def need(ok,message):
 if not ok:raise ValueError(message)
prior=json.loads((ORIGINAL/'evidence.json').read_text());before=json.loads((ORIGINAL/'source-before.json').read_text())
need(prior['status']=='failed' and prior['error']=='KeyboardInterrupt()','paused original')
need(source()==before,'exact original source snapshot')
need(len(prior['commands'])==103,'original completed command inventory')
for c in prior['commands']:
 need(c['exit_code']==c['expected_exit'] and c['exception'] is None and not c.get('count_error') and not c.get('missing_new_target'),'prior command passed')
 need(sha(Path(c['log']))==c['log_sha256'],'prior log identity')
need(len([c for c in prior['commands'] if c['kind']=='full-suite'])==12,'twelve completed original suites')
env={k:v for k,v in os.environ.items() if k in ['PATH','HOME','TMPDIR','TMP','TEMP','SYSTEMROOT','SDKROOT','MACOSX_DEPLOYMENT_TARGET','DEVELOPER_DIR','RUSTUP_HOME','CARGO_HOME']}
env.update(CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR=str(TARGET),CARGO_TERM_COLOR='never',CARGO_NET_OFFLINE='true',PYTHONDONTWRITEBYTECODE='1',LC_ALL='C',LANG='C',TZ='UTC')
for label,argv in [('rustc',['rustc','-Vv']),('cargo',['cargo','-V'])]:
 result=subprocess.run(argv,cwd=WORK,env=env,capture_output=True,check=True)
 expected=Path(next(c['log'] for c in prior['commands'] if c['label']==label)).read_bytes()
 need(result.stdout+result.stderr==expected,'same tool identity '+label)
v={k:prior[k] for k in ['schema_version','base','snapshot','snapshot_sha256','source_before','source_before_sha256','scope']}
v.update(status='running',environment=env,commands=list(prior['commands']),continuation=dict(original_evidence=str(ORIGINAL/'evidence.json'),original_sha256=sha(ORIGINAL/'evidence.json'),original_runner_sha256=sha(Path('/tmp/zstdoxide-module16-matrix-runner.py')),original_completed_commands=103,interrupted_log=str(ORIGINAL/'tests-unsafe-reference-tree.log'),interrupted_log_sha256=sha(ORIGINAL/'tests-unsafe-reference-tree.log'),qualification='User-requested interruption preserved. Only completed original commands reused after exact source/log/compiler checks. Interrupted tree suite rerun in full; continuation uses the same snapshot and target.'))
def save():(OUT/'evidence.json').write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def run(label,argv,kind='check',expected=0):
 start=time.monotonic();log=OUT/(label+'.log');print('START',label,flush=True)
 code=None;error=None
 with log.open('xb') as f:
  try:r=subprocess.run(argv,cwd=WORK,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200,check=False);code=r.returncode
  except (OSError,subprocess.TimeoutExpired) as e:error=repr(e)
 data=log.read_bytes();counts=[list(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',data)]
 row=dict(label=label,argv=argv,cwd=str(WORK),exit_code=code,expected_exit=expected,exception=error,seconds=time.monotonic()-start,log=str(log),log_sha256=sha(log),kind=kind)
 if kind in ['full-suite','doc-examples']:
  row['test_harnesses']=counts;row['totals']=[sum(c[i] for c in counts) for i in range(5)]
  row['ignored_tests']=[x.decode() for x in re.findall(rb'^test (.+) \.\.\. ignored(?:,.*)?$',data,re.M)]
  row['count_error']=row['totals'] != ([1204,0,55,0,0] if kind=='full-suite' else [22,0,0,0,0])
  if kind=='full-suite':row['missing_new_target']=not all(s in data for s in [b'Running tests/upstream_reference_fast.rs',b'Running tests/reference_double_fast.rs',b'Running tests/reference_double_fast_platform.rs',b'Running tests/reference_greedy.rs',b'Running tests/reference_greedy_platform.rs',b'Running tests/reference_lazy.rs',b'Running tests/reference_lazy_platform.rs',b'Running tests/reference_tree.rs'])
 v['commands'].append(row);save();print('END',label,code,row.get('totals',[]),flush=True)
 need(code==expected and error is None and not row.get('count_error') and not row.get('missing_new_target'),'command '+label)
try:
 save();print('PRIOR VERIFIED',flush=True)
 flags=['unsafe-byte-cursor','unsafe-bitstream','unsafe-history','unsafe-ring-history','unsafe-fse','unsafe-fse-encoder','unsafe-huffman','unsafe-huffman-codebook','unsafe-match-table','unsafe-match-chain','unsafe-reference-chain','unsafe-reference-tree','unsafe-row-table','unsafe-dictionary','unsafe-training']
 for flag in flags[11:]:
  run('tests-'+flag,['cargo','test','--offline','--locked','--features',flag],'full-suite')
  run('nostd-'+flag,['cargo','check','--offline','--locked','--no-default-features','--features',flag])
 run('tests-all',['cargo','test','--offline','--locked','--all-features'],'full-suite')
 run('tests-release-all',['cargo','test','--offline','--locked','--release','--all-features'],'full-suite')
 run('nostd-all',['cargo','check','--offline','--locked','--no-default-features','--features',','.join(flags)])
 run('clippy-all',['cargo','clippy','--offline','--locked','--all-targets','--all-features','--','-D','warnings'])
 run('docs-all',['python3','scripts/check_doc_examples.py','--all-features'],'doc-examples')
 after=source();(OUT/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n');v.update(source_after=str(OUT/'source-after.json'),source_after_sha256=sha(OUT/'source-after.json'),source_unchanged=before==after)
 need(before==after,'unchanged original snapshot')
 suites=[c for c in v['commands'] if c['kind']=='full-suite'];v.update(full_suites=len(suites),full_suite_totals=[sum(c['totals'][i] for c in suites) for i in range(5)])
 need(v['full_suites']==18 and v['full_suite_totals']==[21672,0,990,0,0],'complete matrix')
 need(len([c for c in v['commands'] if c['label'].startswith('nostd-')])==17,'seventeen no_std')
 need(len(v['commands'])==len({c['label'] for c in v['commands']}),'unique commands')
 v['status']='passed';save();print('COMPLETE',sha(OUT/'evidence.json'),flush=True)
except BaseException as e:
 v.update(status='failed',error=repr(e));save();raise
