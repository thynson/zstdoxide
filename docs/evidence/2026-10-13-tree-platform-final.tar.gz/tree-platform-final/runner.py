from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-platform-final-checks');O.mkdir();env=os.environ.copy()
paths=sorted((R/'src').glob('*.rs'))+[R/'Cargo.toml',R/'Cargo.lock',R/'tests/support/tree_oracle.rs',R/'tests/fixtures/reference-tree/cases.bin',R/'tests/support/tree_frame_encode.rs'];source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};rows=[]
selected=['reference_tree::tests::malformed_heads_dimensions_and_short_owners_reject_before_writes','reference_tree::tests::independent_nonclone_allocators_release_after_each_failure','reference_tree::tests::borrowed_allocators_survive_reset_and_release_exact_layouts','tree_sort::tests::pending_chain_reverses_truncates_and_sorts_equal_tails','tree_sort::tests::stale_ring_links_stop_before_reused_children','tree_sort::tests::strict_ordering_and_terminal_floor_preserve_the_candidate','tree_sort::tests::cyclic_and_future_pending_links_fail_with_bounded_work','tree_search::tests::malformed_sorted_cycles_and_future_heads_reject','tree_search::tests::inclusive_tail_and_skipped_queries_preserve_frontier_and_maps','tree_source::tests::direct_extent_and_retained_prefix_keep_window_expiry_independent']
selected.append('reference_frame_encode::tree_tests::platform_tree_frames_keep_nonclone_owners_and_transactional_boundaries')
for short in ['i686','s390x']:
 for mode,flags in [('safe',[]),('all',['--all-features'])]:
  label=short+'-'+mode;args=['cargo','miri','test','--offline','--locked','--target',short+'-unknown-linux-gnu','--lib',*flags,'--','--exact',*selected,'--test-threads=1'];e=env.copy();e.update(CARGO_INCREMENTAL='0',MIRI_SYSROOT='/tmp/zstdoxide-platform-sysroot-'+short,MIRIFLAGS='-Zmiri-strict-provenance',CARGO_TARGET_DIR='/tmp/zstdoxide-tree-miri-'+short)
  log=O/(label+'.log');start=time.monotonic()
  with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=e,stdout=f,stderr=subprocess.STDOUT,timeout=900)
  b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest(),environment={k:e[k] for k in ['MIRI_SYSROOT','MIRIFLAGS','CARGO_TARGET_DIR']});rows.append(r);print(label,p.returncode,flush=True)
  sums=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b);names=re.findall(rb'^test (\S+) \.\.\. ok$',b,re.M)
  if p.returncode or sums!=[(b'11',b'0',b'0')] or sorted(n.decode() for n in names)!=sorted(selected):raise ValueError(label)
assert source=={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,selected_tests=selected,interpreted_test_executions=44,source_unchanged=True,processes_remaining=0,qualification='Selected strict-provenance Miri checks on 32-bit little-endian i686 and 64-bit big-endian s390x; not native foreign suites or complete algorithm coverage.'),sort_keys=True,indent=2)+'\n')
