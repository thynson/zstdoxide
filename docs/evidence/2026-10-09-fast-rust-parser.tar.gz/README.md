# Safe single-block Fast parser checkpoint

The original evidence JSON and 16 command logs are preserved byte-for-byte.
The source manifest is also included separately; it describes the frozen
11c7c80 snapshot plus the three listed overlays, not the later frame wrapper.
No compiled binaries, target artifacts, C sources, source corpus, or codec
source copies are included. Source bytes are available from the accompanying
implementation commit; the manifest binds every checked file.

The nine parser unit tests passed in five configurations (45 executions).
Each configuration includes all 142 saved direct-C case comparisons inside
one test; these are 710 case replays, not 710 separate Rust test executions.
Two release default-regression runs add 14 passes and four exact host Miri
selectors add four, totaling 63 passes, zero failures, zero ignored. Sixteen
commands also include strict safe/all Clippy, two no_std checks, and rustfmt.
No C program was executed by this checkpoint. Miri is host interpretation
with strict provenance, not native foreign execution or a performance test.
The private parser module is cfg(test) until persistent-frame integration;
no_std parser unit runs cover that foundation while cargo check covers the
existing production crate. No public Fast-frame or byte-identical entropy
claim is made.

The initial eight-test run passed before the future-source isolation witness
was added. The preliminary Clippy run exited 101: an accidentally unconditional
module registration produced nine non-test dead-code errors, and a test byte
array needed the idiomatic byte-string form. The coordinator restored the
planned cfg(test) registration; the test-only syntax was corrected. Neither
fix changed parser behavior or fixture expectations. Both logs are preserved
and excluded from the final 63-pass aggregate.

The original runner has absolute historical paths and creates a fresh snapshot.
For reproduction, use a new temporary path and materialize the recorded base
plus accompanying implementation overlays, checking their recorded hashes
before executing the recorded commands. Do not rerun the archived runner over
an existing snapshot or silently substitute later source.
