import json, pathlib, hashlib, sys
root = pathlib.Path(sys.argv[1])
p = root/'evidence.json'; d = json.loads(p.read_text())
assert d['complete'] and d['source_unchanged'] and d['external_inputs_unchanged']
assert len(d['commands']) == 45
full=[]; checks=[]
for c in d['commands']:
    assert c['exit_code'] == c['expected_exit_code'] and not c['source_changed'], c['name']
    log=pathlib.Path(c['log']); assert hashlib.sha256(log.read_bytes()).hexdigest()==c['sha256']
    if c['kind'] in ('full-suite','usage','oracle'):
        assert c['test_totals']['passed'] > 0 and c['test_totals']['failed'] == 0, c['name']
    if c['kind']=='full-suite': full.append(c['test_totals'])
    if c['kind']=='oracle':
        assert c['test_totals']['passed']==1 and c['test_totals']['ignored']==0, c['name']
        if c['name'].startswith('lifecycle-'):
            assert '30 complete frames / 3072000 decoded bytes' in log.read_text(), c['name']
    checks.append(c['name'])
assert len(full)==15 and all(t==full[0] for t in full)
result={'scope':'Independent post-run selector/count and complete log-hash verification', 'revision':d['revision'], 'checked_commands':checks, 'full_suite_counts':full[0], 'focused_oracles_exactly_one_each':True, 'both_lifecycle_oracle_frame_counts_checked':True, 'zero_test_selectors_rejected':True, 'evidence_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(root/'post-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
