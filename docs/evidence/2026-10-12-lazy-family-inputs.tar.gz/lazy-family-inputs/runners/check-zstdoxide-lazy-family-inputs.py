from pathlib import Path
import contextlib,hashlib,json,os,runpy,shutil,subprocess,sys,tempfile
from unittest.mock import patch
sys.dont_write_bytecode=True
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(R/'scripts'))
m=runpy.run_path(str(R/'scripts/check_lazy_family_recipes.py'));g=m['inputs'].__globals__
root=Path(tempfile.mkdtemp(prefix='zstdoxide-lazy-family-controls-',dir='/tmp')).resolve()
for n in [*m['PINS'],m['MANIFEST']]:
 p=root/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,p)
g['ROOT']=root
manifest=root/m['MANIFEST'];original=manifest.read_bytes();original_sha=m['MANIFEST_SHA'];children=[];checks=[]
def deny(*a,**k):children.append('child');raise RuntimeError('child execution forbidden')
def bad(name,edit,undo):
 edit()
 try:
  try:m['inputs']()
  except (ValueError,OSError,TypeError,KeyError):checks.append({'name':name,'rejected':True})
  else:raise RuntimeError('accepted mutation '+name)
 finally:undo()
def manifest_case(name,change):
 value=json.loads(original);change(value);data=(json.dumps(value,allow_nan=False)+'\n').encode()
 def edit():manifest.write_bytes(data);g['MANIFEST_SHA']=hashlib.sha256(data).hexdigest()
 def undo():manifest.write_bytes(original);g['MANIFEST_SHA']=original_sha
 bad(name,edit,undo)
with contextlib.ExitStack() as stack:
 for module,name in [(subprocess,'Popen'),(os,'system'),(os,'posix_spawn'),(os,'posix_spawnp')]:
  if hasattr(module,name):stack.enter_context(patch.object(module,name,deny))
 positive=m['check']()
 for n in m['PINS']:
  p=root/n;raw=p.read_bytes()
  bad('changed-pin:'+n,lambda p=p,raw=raw:p.write_bytes(raw+b'\n'),lambda p=p,raw=raw:p.write_bytes(raw))
 manifest_case('coherent-recipe-depth',lambda v:v['recipes'][0].update(depth=1,strategy=4))
 manifest_case('coherent-source-identity',lambda v:v['recipes'][0].update(source_sha256='0'*64))
 manifest_case('coherent-packet-identity',lambda v:v['recipes'][0].update(packet_sha256='0'*64))
 manifest_case('coherent-missing-recipe',lambda v:(v['recipes'].pop(),v.update(recipe_count=644)))
 manifest_case('coherent-float-count',lambda v:v.update(recipe_count=645.0))
 manifest_case('coherent-bool-count',lambda v:v.update(recipe_count=True))
 manifest_case('coherent-input-total',lambda v:v.update(source_bytes=18900770))
 manifest_case('coherent-extra-field',lambda v:v.update(extra=0))
 manifest_case('coherent-score-baseline',lambda v:v['score_hypotheses'][0].update(baseline_score=999))
 manifest_case('coherent-score-query',lambda v:v['score_hypotheses'][0].update(query_delta=999))
 manifest_case('coherent-predecessor-map',lambda v:v['predecessor_controls'][0].update(predecessor_id='missing'))
 manifest_case('coherent-missing-predecessor',lambda v:v['predecessor_controls'].pop())
 for name,data in [('duplicate-json-key',original.replace(b'{',b'{"recipe_count":645,',1)),('nonfinite-json',original.replace(b'"recipe_count": 645',b'"recipe_count": NaN',1))]:
  def edit(data=data):manifest.write_bytes(data);g['MANIFEST_SHA']=hashlib.sha256(data).hexdigest()
  def undo():manifest.write_bytes(original);g['MANIFEST_SHA']=original_sha
  bad(name,edit,undo)
 restored=m['check']()
 if positive!=restored or positive['recipes']!=645 or positive['malformed_packets_rejected']!=55 or positive['reference_executions']!=0:raise RuntimeError('positive mismatch')
if children or len(checks)!=len(m['PINS'])+14:raise RuntimeError('wrong control counts')
e={'status':'passed','python_optimized':not __debug__,'positive':positive,'positive_runs':2,'rejected_input_forgeries':len(checks),'child_processes':len(children),'controls':checks,'source':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in [*m['PINS'],m['MANIFEST'],'scripts/check_lazy_family_recipes.py']},'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'qualification':'Source and structural controls only, with no C helper, Rust encoder or archived program executed.'}
print(json.dumps(e,sort_keys=True,indent=2));shutil.rmtree(root)
