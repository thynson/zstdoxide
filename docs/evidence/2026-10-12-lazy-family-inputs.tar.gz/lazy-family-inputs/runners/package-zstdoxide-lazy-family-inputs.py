from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,s):
 if not v:raise ValueError(s)
checks={mode:json.loads(Path('/tmp/zstdoxide-lazy-family-inputs-'+mode+'.json').read_bytes()) for mode in ['normal','optimized']}
expected={'recipes':645,'branches':{'chain':303,'row':342},'depth_counts':[215]*3,'source_bytes':18900771,'packet_bytes':19019595,'malformed_packets_rejected':55,'constructed_score_sources':96,'predecessor_controls':173,'reference_executions':0}
for mode,e in checks.items():
 need(e['status']=='passed' and e['python_optimized']==(mode=='optimized') and e['positive_runs']==2 and e['rejected_input_forgeries']==33 and e['child_processes']==0,'input controls');need(e['positive']==expected,'exact input counts')
 need(not Path('/tmp/zstdoxide-lazy-family-inputs-'+mode+'.stderr').read_bytes(),'clean control diagnostics')
 for n,h in e['source'].items():need(sha((R/n).read_bytes())==h,'unchanged source '+n)
report={'date':'2026-10-12','status':'passed','source':checks['normal']['source'],**expected,'positive_runs_per_mode':2,'rejected_input_forgeries_per_mode':33,'child_processes':0,'qualification':'Frozen broader source hypotheses and input controls only. Prior tiny C observations supply fresh salt and retain 138 input identities; no new broader Lazy output or Rust expected result. Placed-copy score arithmetic is not evidence of a parser branch hit.','archive':'2026-10-12-lazy-family-inputs.tar.gz'}
files={'controls-'+mode+'.json':enc(e) for mode,e in checks.items()}
for n in report['source']:files['source/'+n]=(R/n).read_bytes()
files['source/tests/fixtures/reference-lazy-families/README.md']=(R/'tests/fixtures/reference-lazy-families/README.md').read_bytes()
for n in ['freeze-zstdoxide-lazy-families.py','check-zstdoxide-lazy-family-inputs.py','package-zstdoxide-lazy-family-inputs.py']:files['runners/'+n]=(Path('/tmp')/n).read_bytes()
files['review.json']=enc(report);files['bundle-manifest.json']=enc({n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()})
a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh archive');prefix='lazy-family-inputs/'
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo(prefix+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:found={v.name:t.extractfile(v).read() for v in t}
need(found=={prefix+n:b for n,b in files.items()},'archive verification')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files));(R/'docs/evidence/2026-10-12-lazy-family-inputs.json').write_bytes(enc(report));print(report['archive_members'],report['archive_bytes'])
