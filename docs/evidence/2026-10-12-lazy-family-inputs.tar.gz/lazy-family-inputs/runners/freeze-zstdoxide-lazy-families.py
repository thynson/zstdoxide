from pathlib import Path
import hashlib,json,pprint,re,runpy,sys
R=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(R/'scripts'))
import check_lazy_tiny_recipes as tiny
names=set(tiny.PINS)|{tiny.MANIFEST,'scripts/check_lazy_tiny_recipes.py','scripts/check_lazy_tiny_fixture.py','scripts/check_lazy_tiny_capture.py','tests/fixtures/reference-lazy-tiny/capture.json','tests/fixtures/reference-lazy-tiny/observations.ndjson','scripts/oracles/greedy_families.py','scripts/check_greedy_family_recipes.py','tests/fixtures/reference-greedy-families/recipes.json','scripts/oracles/lazy_families.py'}
pins={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in sorted(names)}
p=R/'scripts/check_lazy_family_recipes.py';s=p.read_text().replace('PINS = {}','PINS = '+pprint.pformat(pins,sort_dicts=True,width=100));p.write_text(s)
m=runpy.run_path(str(p));from oracles import lazy_direct as o,lazy_families as f
manifest=m['expected'](o,f,f.recipes());raw=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode();dest=R/m['MANIFEST'];dest.parent.mkdir(parents=True,exist_ok=True)
if dest.exists():raise ValueError('fresh input manifest')
dest.write_bytes(raw);s=s.replace("MANIFEST_SHA = 'PENDING'","MANIFEST_SHA = '"+hashlib.sha256(raw).hexdigest()+"'");p.write_text(s);print(len(raw),manifest['branches'],manifest['depth_counts'])
