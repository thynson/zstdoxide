from pathlib import Path
import hashlib,json,tarfile
D=Path(__file__).parent;T=Path('/private/tmp');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
S=T/'module24-native';b=json.loads((S/'build.json').read_text());j=json.loads((S/'native.json').read_text());assert b['status']==j['status']=='passed' and len(j['results'])==2392
REF=T/'module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99'
for n,h in b['library'].items():assert sha(REF/n)==h,n
for name,h in b['executables'].items():assert sha(S/('oracle-'+name))==h
for n,h in j['inputs'].items():assert sha(S/'inputs'/n)==h
for row in j['results']:assert row['result']['guards']==1,row
name='2026-10-26-stable-output-native';archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(S.rglob('*')):
  if p.is_file() and '.dSYM' not in str(p):t.add(p,arcname='native/'+str(p.relative_to(S)))
 for p in [T/'module24-preparation/reference-identity.json',T/'module24-candidate/inventory-pinned.log',T/'module24-candidate/tests/slice_decoder_native.rs',T/'module24-candidate/tests/upstream/manifest.json']:
  t.add(p,arcname='qualification/'+p.name)
 for p in sorted((T/'module24-candidate').glob('public-*-native.log')):t.add(p,arcname='qualification/'+p.name)
 t.add(__file__,arcname='archive-native-platform.py')
out=dict(status='passed',native=j,build=b,archive=archive.name,archive_sha256=sha(archive),common_cases_per_backend=1193,native_cases_per_backend=1196,rust_backends=['safe','unsafe-slice-history','all'],public_evidence_sha256=sha(T/'module24-candidate/public.json'),qualification='Normal and ASan/UBSan native runs retain full outputs and guards. Three output-identity mutations are native-only because safe Rust borrowing excludes changing the destination identity during the session. Partial upstream mappings retain exact remaining C ABI/workspace/random corpus/runtime parameter differences. Reference source payload is not archived in the repository; hashes bind the external pinned reference.')
(D/(name+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(name,archive.stat().st_size,flush=True)
S=T/'module24-platform';j=json.loads((S/'evidence.json').read_text());assert j['status']=='passed' and len(j['commands'])==8 and all(c['exit_code']==0 for c in j['commands'])
for n,h in j['source'].items():assert sha(S/'source'/n)==h,n
name='2026-10-26-stable-output-platform';archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(S.iterdir()):
  if p.is_file():t.add(p,arcname='campaign/'+p.name)
 for folder in ['source','probe','artifacts']:
  for p in sorted((S/folder).rglob('*')):
   if p.is_file() and 'target' not in p.relative_to(S/folder).parts:t.add(p,arcname=folder+'/'+str(p.relative_to(S/folder)))
 t.add(__file__,arcname='archive-native-platform.py')
out={**j,'archive':archive.name,'archive_sha256':sha(archive),'test_formatting_qualification':'The public candidate test is rustfmt-formatted from the exact platform test. Production files are unchanged and hash-verified; platform source bytes are retained as executed.'}
(D/(name+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(name,archive.stat().st_size,flush=True)
