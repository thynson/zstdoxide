from pathlib import Path
import copy, importlib.util, json, os, struct, sys, tempfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize')
sys.path.insert(0,str(ROOT/'scripts'))
import check_double_fast_tiny as check
import capture_double_fast_tiny as live
oracle=check.load_oracle()
out=Path(sys.argv[1]);out.mkdir()
capture=Path('/tmp/zstdoxide-double-fast-tiny-initial-2026-10-12')
results=[]
def require(ok,msg):
    if not ok:raise ValueError(msg)
def reject(label,call):
    try:call()
    except (ValueError,KeyError,TypeError,OSError) as error:
        results.append({'label':label,'rejected':True,'diagnostic':str(error)});return
    raise ValueError('control accepted: '+label)
cases=oracle.recipes();byname={c.name:c for c in cases}
for case in cases:
    rows=oracle.validate(case,check.COLLECTION/('normal-'+case.name+'.stdout'))
    results.append({'label':'positive-'+case.name,'passed':True})
period=json.loads((check.COLLECTION/'normal-repeat-four.stdout').read_text().splitlines()[1])
for name,skip in [('dispatch-three',{'id','min_match'}),('ignored-controls',{'id','search_log','target_length'})]:
    row=json.loads((check.COLLECTION/('normal-'+name+'.stdout')).read_text().splitlines()[1])
    require(oracle.exact({k:v for k,v in period.items() if k not in skip},{k:v for k,v in row.items() if k not in skip}),name+' equivalence')
    results.append({'label':'equivalent-'+name,'passed':True,'ignored_fields':sorted(skip)})
for label,data in [('duplicate','{"a":1,"a":2}'),('nan','{"a":NaN}'),('infinity','{"a":Infinity}')]:
    reject('json-'+label,lambda data=data:oracle.decode_json(data))
base=oracle.validate(byname['current-long-floor'],check.COLLECTION/'normal-current-long-floor.stdout')
mutations={
 'bool-count':lambda r:r[1].update(sequence_count=True),
 'bool-schema':lambda r:r[0].update(schema_version=True),
 'bad-host':lambda r:r[0].update(pointer_bits=128),
 'bad-alignment':lambda r:r[0].update(sequence_alignment=3),
 'extra-field':lambda r:r[1].update(invented=0),
 'negative-length':lambda r:r[1]['sequences'][0].update(ll=-1),
 'bool-distance':lambda r:r[1]['sequences'][0].update(distance=True),
 'offset-zero':lambda r:r[1]['sequences'][0].update(off_base=0),
 'bad-intent':lambda r:r[1]['sequences'][0].update(intent='repeat'),
 'repeat-state':lambda r:r[1].update(wire_repeats=[1,4,8]),
 'raw-third':lambda r:r[1].update(parser_repeats=[16,257,263]),
 'marker-kind':lambda r:r[1].update(long_length_type=3),
 'marker-position':lambda r:r[1].update(long_length_position=1),
 'marker-expanded':lambda r:r[1].update(long_length_type=2),
 'literal-extent':lambda r:r[1].update(stored_literal_bytes=1),
 'literal-whitespace':lambda r:r[1].update(stored_literals_hex=' '),
 'tail':lambda r:r[1].update(trailing_literals=1),
 'floor':lambda r:r[1].update(prefix_floor=17),
 'source-hash':lambda r:r[1].update(source_fnv1a64='0'*16),
 'arena-sum':lambda r:r[1].update(requested_allocation_bytes=1),
 'wrong-seed-map':lambda r:r[1]['long_table']['before'][0].__setitem__(1,3),
 'wrong-old-cell':lambda r:r[1]['long_table']['changes'][0].__setitem__(1,999),
 'future-cell':lambda r:r[1]['long_table']['changes'][0].__setitem__(2,999),
 'duplicate-delta':lambda r:r[1]['long_table']['changes'].append(r[1]['long_table']['changes'][0]),
 'before-hash':lambda r:r[1]['long_table'].update(before_le32_fnv1a64='0'*16),
 'after-hash':lambda r:r[1]['short_table'].update(after_le32_fnv1a64='0'*16),
 'wrong-padding':lambda r:r[2].update(padding=106),
 'second-record':lambda r:r[2].update(guards_intact=False),
 'completion':lambda r:r[3].update(success=False),
 'extra-record':lambda r:r.append(r[-1]),
}
for name,mutation in mutations.items():
    rows=copy.deepcopy(base);mutation(rows)
    path=out/(name+'.ndjson');path.write_text(''.join(json.dumps(r)+'\n' for r in rows))
    reject('record-'+name,lambda path=path:oracle.validate(byname['current-long-floor'],path))
# Reject a forged fixture even if its local manifest/catalog hashes are repaired.
import shutil,hashlib
forged=out/'forged';shutil.copytree(check.COLLECTION,forged)
f=forged/'normal-current-long-floor.stdout';r=[json.loads(l) for l in f.read_text().splitlines()];r[1]['padding']=195
f.write_text(''.join(json.dumps(row)+'\n' for row in r))
m=json.loads((forged/'manifest.json').read_text())
for entry in m['fixtures']:
    p=forged/entry['path'];entry.update(size=p.stat().st_size,sha256=oracle.sha(p))
m['fixture_catalog_sha256']=hashlib.sha256(json.dumps(m['fixtures'],sort_keys=True,separators=(',',':')).encode()).hexdigest()
(forged/'manifest.json').write_text(json.dumps(m))
reject('repaired-forged-catalog',lambda:check.check(forged))
# Input mutations reject before any observation output in both build modes.
packet=byname['current-long-floor'].packet()
packets={
 'bad-magic':b'!'+packet[1:], 'id-non-ascii':packet[:8]+b'\xff'+packet[9:],
 'id-no-null':packet[:8]+b'a'*64+packet[72:], 'id-empty':packet[:8]+bytes(64)+packet[72:],
 'id-after-null':packet[:8]+b'a\0b'+bytes(61)+packet[72:],
 'header-short':packet[:131], 'seed-short':packet[:134], 'source-short':packet[:-1], 'extra-byte':packet+b'!'}
for name,offset,value in [('prefix-cap',72,(2<<20)+1),('block-six',76,6),('block-cap',76,(128<<10)+1),
 ('window-low',80,9),('window-high',80,22),('long-low',84,5),('long-high',84,19),
 ('short-low',88,5),('short-high',88,19),('search-low',92,0),('search-high',92,30),
 ('match-low',96,2),('match-high',96,8),('target-high',100,131073),('floor-after-prefix',104,17),
 ('repeat-zero',108,0),('seed-count',120,1025),('reserved',128,1),('future-seed',132,16)]:
    data=bytearray(packet);struct.pack_into('<I',data,offset,value);packets[name]=bytes(data)
for name,data in packets.items():(out/(name+'.packet')).write_bytes(data)
big=out/'oversize.packet'
with big.open('wb') as f:f.truncate(oracle.MAX_PACKET+1)
packet_paths=[(n,out/(n+'.packet')) for n in packets]+[('oversize',big),('directory',out)]
env={'PATH':os.environ.get('PATH',os.defpath),'LC_ALL':'C','LANG':'C'}
for mode in ('normal','sanitized'):
    current=env|({'ASAN_OPTIONS':'halt_on_error=1:detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'} if mode=='sanitized' else {})
    for name,path in packet_paths:
        label=mode+'-reject-'+name
        command=live.run_command([str(capture/('double-fast-'+mode)),str(path)],out,label,current)
        require(command.get('exit_code')==1 and 'error' not in command,label+' exit')
        require(command['stdout']['bytes']==0,label+' emitted partial observations')
        stderr=(out/command['stderr']['path']).read_text()
        require(stderr.startswith('double-fast oracle [setup]:') and 'Sanitizer' not in stderr,label+' failure origin')
        results.append({'label':label,'rejected':True,'command':command})
# Destination preflights and live-only options must fail without mutation.
for name,destination in [('repository',ROOT/'no-double-fast-output'),('reference',Path('/tmp/zstdoxize-upstream-1.5.7/no-output')),('ancestor',Path('/tmp')),('existing',out)]:
    command=live.run_command([sys.executable,str(ROOT/'scripts/capture_double_fast_tiny.py'),'--upstream','/tmp/zstdoxize-upstream-1.5.7','--output',str(destination)],out,'path-'+name,env)
    require(command.get('exit_code')==1,'path rejection '+name)
    if name in ('repository','reference'):require(not destination.exists(),'preflight created destination')
    results.append({'label':'path-'+name,'rejected':True,'command':command})
command=live.run_command([sys.executable,str(ROOT/'scripts/check_double_fast_tiny.py'),'--check','--upstream','/tmp/zstdoxize-upstream-1.5.7'],out,'offline-live-option',env)
require(command.get('exit_code')==2,'offline option rejected');results.append({'label':'offline-live-option','rejected':True,'command':command})
for name,argv,options,reason in [
 ('missing',['/no-such-zstdoxide-command'],{},'FileNotFoundError'),
 ('cap',[sys.executable,'-c','print("x"*1024)'],{'cap':32},'ValueError'),
 ('timeout',[sys.executable,'-c','import time; time.sleep(2)'],{'timeout':0.03},'TimeoutError')]:
    row=live.run_command(argv,out,'process-'+name,env,**options)
    require(row.get('error','').startswith(reason),name+' diagnostic')
    require(row['stdout']['bytes']<=options.get('cap',oracle.MAX_RECORDS),name+' cap retained')
    results.append({'label':'process-'+name,'rejected':True,'command':row})
report={'status':'passed','python':sys.version,'optimized':sys.flags.optimize,'controls':results,'positive':sum(r.get('passed',False) for r in results),'rejected':sum(r.get('rejected',False) for r in results),'script_sha256':oracle.sha(Path(__file__))}
(out/'results.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:report[k] for k in ('status','optimized','positive','rejected')}))
