from pathlib import Path
import hashlib,json,tarfile,io,subprocess
root=Path('/Users/lanxingcan/Workspace/zstdoxize');capture=Path('/tmp/zstdoxide-double-fast-tiny-initial-2026-10-12')
checks=[Path('/tmp/zstdoxide-double-fast-tiny-controls-'+mode) for mode in ('normal','optimized')]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def require(ok,msg):
 if not ok:raise ValueError(msg)
e=json.loads((capture/'evidence.json').read_text())
require(e['status']=='passed' and len(e['commands'])==37,'complete capture')
require(e['source_before']==e['source_after'],'source before/after')
for row in e['source_before']:
 p=Path(row['path']);require(p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'input changed '+str(p))
for command in e['commands']:
 require(command.get('exit_code')==0 and 'error' not in command,'capture failure')
 for stream in ('stdout','stderr'):
  item=command[stream];p=capture/item['path'];require(p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],'capture log')
controls=[]
for directory in checks:
 report=json.loads((directory/'results.json').read_text());require(report['status']=='passed' and report['positive']==17 and report['rejected']==102,'controls')
 for result in report['controls']:
  if 'command' in result:
   for stream in ('stdout','stderr'):
    row=result['command'][stream];p=directory/row['path'];require(p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],'control log')
 controls.append(report)
files={}
for p in capture.rglob('*'):
 if p.is_file() and p.name not in ('double-fast-normal','double-fast-sanitized') and not any(part.endswith('.dSYM') for part in p.parts):files['capture/'+p.relative_to(capture).as_posix()]=p
for directory,mode in zip(checks,('normal','optimized')):
 for p in directory.rglob('*'):
  if p.is_file():files['controls/'+mode+'/'+p.relative_to(directory).as_posix()]=p
sources=['scripts/oracles/double_fast_direct.c','scripts/oracles/double_fast_direct.py','scripts/capture_double_fast_tiny.py','scripts/check_double_fast_tiny.py','scripts/check.sh','scripts/check_upstream_oracles.sh','scripts/check_upstream_fixtures.py','docs/reference-double-fast-adapter-review.md','docs/reference-double-fast-oracle.md','docs/reference-double-fast-validation.md','TODO.md']
for name in sources:files['repository/'+name]=root/name
for p in (root/'tests/upstream/double-fast-tiny').iterdir():files['repository/'+p.relative_to(root).as_posix()]=p
for p in (Path(__file__),Path('/tmp/check-zstdoxide-double-fast-tiny-controls.py')):files['tools/'+p.name]=p
out=root/'docs/evidence/2026-10-12-double-fast-tiny.tar.gz'
with tarfile.open(out,'w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname='double-fast-tiny/'+name,recursive=False)
with tarfile.open(out,'r:gz') as tar:
 members=tar.getmembers();require(len(members)==len(files),'archive cardinality')
 for member in members:
  require(member.isfile(),'archive type');name=member.name.removeprefix('double-fast-tiny/');require(hashlib.sha256(tar.extractfile(member).read()).hexdigest()==sha(files[name]),'archive bytes')
summary={'schema_version':1,'status':'passed','date':'2026-10-12','git_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':e['scope'],'capture_commands':37,'recipes':15,'padding_patterns':[106,195],'c_case_executions':60,'normal_sanitizer_equal':True,'capture_evidence_sha256':sha(capture/'evidence.json'),'source_before_after_equal':True,'reference_revision':e['reference_revision'],'reference_source_sha256':e['reference_source_sha256'],'support_archive_sha256':e['support_archive_sha256'],'compiler':e['compiler'],'compiler_sha256':e['compiler_sha256'],'instrumentation':e['instrumentation'],'controls':[{'optimized':r['optimized'],'positive':r['positive'],'rejected':r['rejected'],'report_sha256':sha(d/'results.json')} for r,d in zip(controls,checks)],'coordinator_checks':{'offline_checker_normal_and_optimized':'passed','fixture_registry_normal_and_optimized':{'status':'passed','files':545,'collections':17},'clang_format':'passed','cargo_fmt':'passed','git_diff_check':'passed'},'production_rust_changes':False,'repository_source_sha256':{n:sha(root/n) for n in sources},'archive':{'path':out.relative_to(root).as_posix(),'bytes':out.stat().st_size,'sha256':sha(out),'members':len(files),'excluded':'C executables and compiler debug bundles; binary SHA-256 identities remain in capture evidence. Reference C sources remain external; the pinned source catalog is retained.'}}
(root/'docs/evidence/2026-10-12-double-fast-tiny.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({'archive':summary['archive'],'checks':summary['coordinator_checks']},indent=2))
