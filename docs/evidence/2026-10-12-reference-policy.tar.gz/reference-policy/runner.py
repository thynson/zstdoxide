from pathlib import Path
import hashlib,json,subprocess,sys,time,tomllib
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-reference-policy-2026-10-12');OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'scripts'));import benchmark_search
ENV=benchmark_search.effective_environment()|{'CARGO_TARGET_DIR':'/tmp/zstdoxide-double-fast-plan-target','CARGO_NET_OFFLINE':'true','CARGO_TERM_COLOR':'never'}
paths=list((ROOT/'src').rglob('*.rs'))+[ROOT/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/reference_fast_defaults.rs','tests/match_search_defaults.rs','tests/support/double_fast_frame_oracle.rs','tests/fixtures/reference-double-fast-frames/cases.bin','tests/fixtures/reference-double-fast-frames/provenance.json']]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source():return {str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}
e={'date':'2026-10-12','status':'running','scope':'Shared reference literal/gain policy with Fast-only automatic raw literals, unchanged literal/block transactional entropy and allocation order, Fast plan/workspace and exact frame/allocation baselines. No new C capture, public DoubleFast encoding, Miri or timing.','source':source(),'environment':ENV,'commands':[]}
def save():(OUT/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
def run(label,args):
 start=time.monotonic();p=OUT/(label+'.log')
 with p.open('wb') as f:r=subprocess.run(args,cwd=ROOT,env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 e['commands'].append({'label':label,'argv':args,'exit_code':r.returncode,'seconds':time.monotonic()-start,'log':p.name,'log_sha256':sha(p)});save();print(label,r.returncode,flush=True)
 if r.returncode:raise RuntimeError(label)
cargo=['cargo','+nightly-2026-10-08'];flags=[x for x in tomllib.loads((ROOT/'Cargo.toml').read_text())['features'] if x not in ['default','std']]
try:
 run('rustc',['rustc','+nightly-2026-10-08','-vV'])
 for name,features in [('safe',[]),('codebook',['--features','unsafe-huffman-codebook']),('all',['--all-features']),('nostd',['--no-default-features']),('nostd-all',['--no-default-features','--features',','.join(flags)])]:
  for label,module in [('policy','reference_policy'),('literal','literal_encode'),('entropy','block_entropy')]:
   run(label+'-'+name,cargo+['test','--offline','--locked','--lib',module+'::tests::']+features)
 for name,features in [('safe',[]),('all',['--all-features'])]:
  run('fast-plan-'+name,cargo+['test','--offline','--locked','--lib','fast_plan::tests::']+features)
  run('fast-workspace-'+name,cargo+['test','--offline','--locked','--lib','fast_encode::tests::']+features)
  run('baselines-'+name,cargo+['test','--offline','--locked','--test','reference_fast_defaults','--test','match_search_defaults']+features)
  run('clippy-'+name,cargo+['clippy','--offline','--locked','--all-targets']+features+['--','-D','warnings'])
 for name,features in [('safe',[]),('all',['--features',','.join(flags)])]:
  run('nostd-'+name,cargo+['check','--offline','--locked','--no-default-features']+features)
 run('format',['rustfmt','--edition','2024','--config','skip_children=true','--check','src/reference_policy.rs','src/block_entropy.rs','src/literal_encode.rs','src/fast_plan.rs','src/fast_encode.rs','src/lib.rs'])
 e['source_unchanged']=source()==e['source'];assert e['source_unchanged'];e['status']='passed';save()
except BaseException as error:e['status']='failed';e['error']=repr(error);save();raise
