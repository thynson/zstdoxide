from pathlib import Path
import hashlib,io,json,re,tarfile
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');OUT=Path('/tmp/zstdoxide-reference-policy-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
e=json.loads((OUT/'evidence.json').read_bytes());assert e['status']=='passed' and e['source_unchanged']
for n,h in e['source'].items():assert sha((ROOT/n).read_bytes())==h,n
counts_by_label={'policy':1,'literal':14,'entropy':9,'fast-plan':19,'fast-workspace':9}
for c in e['commands']:
 assert c['exit_code']==0;b=(OUT/c['log']).read_bytes();assert sha(b)==c['log_sha256']
 counts=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)
 for label,n in counts_by_label.items():
  if c['label'].startswith(label+'-'):assert counts==[(str(n).encode(),b'0',b'0')],c['label']
 if c['label'].startswith('baselines-'):assert counts==[(b'7',b'0',b'0'),(b'4',b'0',b'0')]
members={p.name:p.read_bytes() for p in OUT.iterdir() if p.is_file()}
members['runner.py']=Path('/tmp/check-zstdoxide-reference-policy.py').read_bytes();members['package.py']=Path(__file__).read_bytes()
for n in ['src/reference_policy.rs','src/literal_encode.rs','src/block_entropy.rs','src/fast_plan.rs','src/fast_encode.rs','src/lib.rs']:
 members['source/'+n]=(ROOT/n).read_bytes()
members['bootstrap.log']=Path('/tmp/zstdoxide-reference-policy-bootstrap.log').read_bytes()
report={'date':'2026-10-12','status':'passed','commands':len(e['commands']),'policy_test_executions':5,'literal_test_executions':70,'block_entropy_test_executions':45,'fast_and_double_fast_plan_test_executions':38,'fast_workspace_test_executions':18,'baseline_test_executions':22,'total_test_executions':198,'ignored':0,'source':e['source'],'scope':e['scope'],'archive':'2026-10-12-reference-policy.tar.gz','initial_test_diagnostics':0,'plan_filter_qualification':'The fast_plan::tests:: substring also matches six double_fast_plan tests, so each plan invocation passes19 tests rather than13. Archive accounting was corrected from the complete logs.'}
members['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode()
members['bundle-manifest.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},sort_keys=True,indent=2)+'\n').encode()
a=ROOT/'docs/evidence'/report['archive'];assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('reference-policy/'+n);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 assert set(t.getnames())=={'reference-policy/'+n for n in members}
 for n,b in members.items():assert t.extractfile('reference-policy/'+n).read()==b
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(members))
(ROOT/'docs/evidence/2026-10-12-reference-policy.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(len(e['commands']),'commands;',len(members),'archive members')
