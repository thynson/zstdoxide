from pathlib import Path
import subprocess,json,time,hashlib
r=Path.cwd();out=Path('/tmp/zstdoxide-optimal-retained-wide-reader-final');out.mkdir(exist_ok=False);records=[]
for label,args in [('malformed',['test','--offline','--locked','--test','reference_optimal_retained_wide_fixture','malformed']),('clippy',['clippy','--all-features','--tests','--','-D','warnings']),('nostd',['check','--no-default-features']),('fmt',['fmt','--all','--','--check'])]:
 start=time.monotonic();p=out/(label+'.log');argv=['cargo',*args]
 with p.open('wb')as f:v=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
 records.append(dict(label=label,argv=argv,exit_code=v.returncode,seconds=time.monotonic()-start,log=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest()));print(label,v.returncode,flush=True)
 if v.returncode:break
(out/'evidence.json').write_text(json.dumps(dict(status='passed'if len(records)==4 and all(v['exit_code']==0 for v in records)else'failed',commands=records),indent=2)+'\n')
