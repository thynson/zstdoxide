from pathlib import Path
import hashlib,json,tarfile,re,subprocess
D=Path(__file__).parent; ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
TEXT={'.rs','.toml','.lock','.md','.json','.py','.sh','.tsv','.csv'}
BASE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
for stage,record,count,label in [('module25-storage','evidence.json',17,'storage'),('module25-engine','evidence.json',17,'engine'),('module25-candidate','public.json',24,'public-api')]:
 S=Path('/private/tmp')/stage;j=json.loads((S/record).read_text());assert j['status']=='passed' and len(j['commands'])==count
 for n,h in j['source'].items():assert sha(S/n)==h,(stage,n)
 source_files=[p for tree in ['src','tests','test-support','benches','examples','scripts'] for p in (S/tree).rglob('*') if p.is_file()]
 source_files += [S/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']]
 complete={str(p.relative_to(S)):sha(p) for p in sorted(set(source_files))}
 omitted={n:h for n,h in complete.items() if Path(n).suffix not in TEXT}
 for n,h in omitted.items():assert (ROOT/n).exists() and sha(ROOT/n)==h,('fixture baseline',n)
 commands=[]
 for c in j['commands']:
  assert c['exit_code']==0
  log=S/((('public-' if record=='public.json' else '')+c['label'])+'.log')
  if not log.exists():log=S/(c['label']+'.log')
  assert log.exists(),log
  groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text());assert all(int(f)==0 for _,f,_ in groups)
  commands.append({**c,'log':log.name,'log_sha256':sha(log),'result_groups':len(groups),'passed':sum(int(a) for a,_,_ in groups),'ignored':sum(int(i) for _,_,i in groups)})
 name='2026-10-26-dictionary-output-'+label;archive=D/(name+'.tar.gz');assert not archive.exists()
 with tarfile.open(archive,'w:gz') as t:
  for p in sorted(S.iterdir()):
   if p.is_file():t.add(p,arcname='campaign/'+p.name)
  for n in complete:
   if Path(n).suffix in TEXT:t.add(S/n,arcname='source/'+n)
  for attempt in sorted(S.glob('attempt-*')):
   for p in sorted(attempt.rglob('*')):
    if p.is_file():t.add(p,arcname='preserved-attempts/'+str(p.relative_to(S)))
  t.add(__file__,arcname='archive-focused.py')
 out=dict(status='passed',source=j['source'],complete_source=complete,commands=commands,fixture_provenance=dict(git_commit=BASE,omitted_binary_files=omitted,qualification='All omitted fixture bytes matched the recorded repository commit working tree before archival; full hashes are retained. No source downloaded for study is included.'),archive=archive.name,archive_sha256=sha(archive),qualification='Isolated staged implementation snapshot. Later staged snapshots separately qualify admission and orchestration; this record does not claim a complete module milestone.')

 (D/(name+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(label,archive.stat().st_size,[(c['label'],c['passed'],c['ignored']) for c in commands],flush=True)
