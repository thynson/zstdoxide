from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize')
def sha(b):return hashlib.sha256(b).hexdigest()
members={};controls=[]
for mode in ('normal','optimized'):
 d=Path('/tmp/zstdoxide-reference-admission-v2-controls-'+mode+'-2026-10-12');e=json.loads((d/'evidence.json').read_bytes())
 assert e['status']=='passed' and e['positive']==8 and e['rejected']==35 and e['child_processes']==0 and e['original_inputs_unchanged'];controls.append(e)
 for p in sorted(d.rglob('*')):
  if p.is_file():members['controls-'+mode+'/'+str(p.relative_to(d))]=p.read_bytes()
 for label in ('controls','check','registry'):
  p=Path('/tmp/zstdoxide-reference-admission-v2-'+label+'-'+mode+'.log');b=p.read_bytes();members['logs/'+p.name]=b
  if label=='check':assert b'61/16/4; interop 85/4/3' in b
  if label=='registry':assert b'838' in b and b'20' in b
for n in ['scripts/check_reference_admission_v2.py', *[str(p.relative_to(R)) for p in (R/'tests/fixtures/reference-admission-v2').iterdir()]]:
 members['source/'+n]=(R/n).read_bytes()
members['controls.py']=Path('/tmp/check-zstdoxide-reference-admission-v2-controls.py').read_bytes();members['package.py']=Path(__file__).read_bytes()
policy=json.loads((R/'tests/fixtures/reference-admission-v2/provenance.json').read_bytes())
for n,h in policy['input_sha256'].items():assert sha((R/n).read_bytes())==h,n
report={'date':'2026-10-12','status':'passed','scope':'Source-only version2 admission expectations, frozen before public DoubleFast execution. Preserves original C selector bytes and historical Rust interop results. No new Rust/C execution, Clippy/no_std, Miri or timing.','controls_per_mode':{'positive':8,'rejected':35,'child_processes':0},'historical_selector':policy['historical_selector'],'successor_selector':policy['successor_selector'],'historical_interop':policy['historical_interop'],'successor_interop':policy['successor_interop'],'loop_classifications':policy['loop_classifications'],'additive_c_required':policy['additive_c_required'],'fixture_registry':{'files':838,'collections':20},'input_sha256':policy['input_sha256'],'generator_sha256':policy['generator_sha256'],'data_sha256':{r['path']:r['sha256'] for r in policy['fixtures']},'archive':'2026-10-12-reference-admission-v2.tar.gz'}
members['report.json']=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();members['bundle-manifest.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},sort_keys=True,indent=2)+'\n').encode()
a=R/'docs/evidence'/report['archive'];assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(members.items()):
  i=tarfile.TarInfo('reference-admission-v2/'+n);i.size=len(b);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 assert set(t.getnames())=={'reference-admission-v2/'+n for n in members}
 for n,b in members.items():assert t.extractfile('reference-admission-v2/'+n).read()==b
report.update(archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(members))
(R/'docs/evidence/2026-10-12-reference-admission-v2.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(len(members),'verified archive members')
