Control copy only.
