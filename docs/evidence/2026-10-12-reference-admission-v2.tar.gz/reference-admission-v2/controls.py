from pathlib import Path
import builtins,importlib.util,json,subprocess,sys,hashlib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');mode='optimized' if sys.flags.optimize else 'normal';O=Path('/tmp/zstdoxide-reference-admission-v2-controls-'+mode+'-2026-10-12');O.mkdir(exist_ok=False)
sys.path.insert(0,str(R/'scripts'));import check_reference_admission_v2 as m
original_popen=subprocess.Popen
def forbidden(*a,**k):raise RuntimeError('offline policy attempted a child process')
subprocess.Popen=forbidden
positive=0;rejected=[]
def need(v,s):
 if not v:raise RuntimeError(s)
def reject(label,f):
 try:f()
 except ValueError:rejected.append(label)
 else:raise RuntimeError('accepted '+label)
files=m.projection();m.verify_files(m.DESTINATION,files);positive+=1
for values,version,expected in [([20,30,18,1,4,0,1],2,'success'),([21,18,18,1,4,131072,2],2,'success'),([21,30,30,1,4,0,3],2,'unsupported'),([21,13,19,1,7,0,2],2,'resource'),([21,19,18,1,4,0,2],2,'resource'),([21,13,18,1,4,0,1],2,'resource'),([21,30,30,1,4,0,2],1,'unsupported')]:
 need(m.classify(values,version)==expected,'policy priority/boundary');positive+=1
base=[19,12,14,1,4,0,2]
for label,value in [('none',None),('tuple',tuple(base)),('short',base[:-1]),('long',base+[0])]:reject(label,lambda v=value:m.classify(v,2))
for i,(lower,upper) in enumerate([(10,31),(6,30),(6,30),(1,30),(3,7),(0,131072),(1,9)]):
 for label,value in [('bool',True),('below',lower-1),('above',upper+1)]:
  values=base[:];values[i]=value;reject(f'{label}-{i}',lambda v=values:m.classify(v,2))
for version in [True,0,3]:reject('version-'+str(version),lambda v=version:m.classify(base,v))
d=O/'forged';d.mkdir();(d/'README.md').write_text('Control copy only.\n')
for n,b in files.items():(d/n).write_bytes(b)
for n,b in files.items():
 (d/n).write_bytes(b+b' ');reject('changed-'+n,lambda:m.verify_files(d,files));(d/n).write_bytes(b)
(d/'extra').write_bytes(b'');reject('extra',lambda:m.verify_files(d,files));(d/'extra').unlink()
(d/'fuzz.tsv').unlink();reject('missing',lambda:m.verify_files(d,files));(d/'fuzz.tsv').write_bytes(files['fuzz.tsv'])
# Verify a corrupted importer is rejected before even a cached import attempt.
original_root=m.ROOT;fake=O/'corrupt-root';(fake/'scripts').mkdir(parents=True);(fake/'scripts/import_reference_fast_fuzz.py').write_text('raise RuntimeError("unexpected import")\n');m.ROOT=fake
original_import=builtins.__import__;attempts=[]
def guarded(name,*args,**kwargs):
 if name in ('import_reference_fast_fuzz','check_reference_fast_interop'):attempts.append(name);raise RuntimeError('import preceded digest check')
 return original_import(name,*args,**kwargs)
builtins.__import__=guarded
try:reject('before-import',m.projection)
finally:builtins.__import__=original_import;m.ROOT=original_root
need(not attempts,'no importer attempted');subprocess.Popen=original_popen
for name,h in m.PINS.items():need(hashlib.sha256((R/name).read_bytes()).hexdigest()==h,'original input unchanged')
report={'status':'passed','mode':mode,'positive':positive,'rejected':len(rejected),'rejection_cases':rejected,'child_processes':0,'original_inputs_unchanged':True}
(O/'evidence.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report,sort_keys=True))
