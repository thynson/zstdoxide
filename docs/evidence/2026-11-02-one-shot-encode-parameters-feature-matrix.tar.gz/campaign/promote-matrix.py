"""Promote the qualified module36 full feature/release matrix item."""
from pathlib import Path
import json, hashlib, subprocess, shutil

D = Path('/private/tmp/module36-matrix')
R = Path('/Users/lanxingcan/Workspace/zstdoxize')
S = D / 'source'
E = R / 'docs/evidence'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
state = Path('/private/tmp/module36-archives/promotion-state.json')
prev = json.loads(state.read_text())
assert prev['stage'] == 'platform'
assert prev['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
assert {str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')} == prev['production_source']
name = '2026-11-02-one-shot-encode-parameters-feature-matrix'
receipt = D / (name + '.json')
r = json.loads(receipt.read_text())
assert r['status'] == 'passed' and sha(D / r['archive']) == r['archive_sha256']
for n, h in r['source'].items():
    assert sha(S / n) == h, n
for q in [receipt, D / r['archive']]:
    assert not (E / q.name).exists()
    shutil.copyfile(q, E / q.name)
p = R / 'TODO.md'
s = p.read_text()
task = '- [ ] Qualify safe, every isolated feature and all features, full/release regression, no_std and strict Clippy.'
assert s.count(task) == 1
s = s.replace(task, task.replace('[ ]', '[x]'))
p.write_text(s)
p = R / 'docs/one-shot-encode-parameters-validation.md'
s = p.read_text()
old = '''Corpus validation, the complete feature/release regression, measurements and
reconciliation remain open.'''
assert s.count(old) == 1
s = s.replace(old, '''Corpus validation, measurements and reconciliation remain open.''')
old = '''Evidence: `evidence/2026-10-30-one-shot-encode-parameters-platform.json`.'''
assert s.count(old) == 1
c = r['full_suite_counts']
s = s.replace(old, old + '''

## Complete feature/release matrix

The frozen module36 candidate runs all 75 commands: safe and all features plus
every isolated opt-in backend execute the complete test suite, true `no_std`
compilation and strict Clippy; safe and all features also run complete release
suites, and formatting runs once. Every complete/release suite reports the same
{c[result_groups]} result groups, {c[passed]} passed and {c[ignored]} ignored
with zero failures. Ignored tests are not credited, and no implementation
change or performance claim is made by this matrix item.
Evidence: `evidence/{name}.json`.'''.format(c=c, name=name))
p.write_text(s)
subprocess.run(['cargo', 'fmt', '--all', '--', '--check'], cwd=R, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', 'TODO.md', 'docs/one-shot-encode-parameters-validation.md', 'docs/evidence/' + receipt.name, 'docs/evidence/' + r['archive']], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Qualify parameterized dictionary calls across all features and release'], cwd=R, check=True)
prev.update(stage='matrix', head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip(), production_source={str(p.relative_to(R)): sha(p) for p in (R / 'src').rglob('*.rs')})
state.write_text(json.dumps(prev, indent=2) + '\n')
print('module36 matrix item promoted at', prev['head'][:12])
