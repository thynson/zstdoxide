"""Module36 final full feature/release regression matrix.

Safe and all features plus every isolated opt-in backend run the complete test
suite, true no_std compilation and strict Clippy. Safe and all features also
run complete release suites, and formatting runs once. Every complete or
release suite must report identical result-group/passed/ignored counts with
zero failures; ignored tests are not credited. No implementation change is
made by this campaign.
"""
from pathlib import Path
import os, subprocess, json, hashlib, time, datetime, re, signal, tomllib

D = Path(__file__).parent
S = D / 'source'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
features = sorted(n for n in tomllib.loads((S / 'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'))
assert len(features) == 22
DEADLINE = '2026-11-02T09:00:00+00:00'
deadline = datetime.datetime.fromisoformat(DEADLINE).timestamp()
assert deadline - time.time() >= 120, 'work window is too short to start'
plan = []
for name, flags in [('safe', []), *[(f, ['--features', f]) for f in features], ('all', ['--all-features'])]:
    plan.append((name + '-full', ['cargo', 'test', '--offline', '--locked', *flags]))
    plan.append((name + '-no-std', ['cargo', 'check', '--offline', '--locked', '--lib', '--no-default-features', *flags]))
    plan.append((name + '-clippy', ['cargo', 'clippy', '--offline', '--locked', '--lib', '--tests', *flags, '--', '-D', 'warnings']))
plan.extend([
    ('safe-release', ['cargo', 'test', '--offline', '--locked', '--release']),
    ('all-release', ['cargo', 'test', '--offline', '--locked', '--release', '--all-features']),
    ('format', ['cargo', 'fmt', '--all', '--', '--check']),
])
assert len(plan) == 75
source = {}
for folder in ['src', 'tests', 'test-support', 'benches']:
    for p in (S / folder).rglob('*'):
        if p.is_file():
            source[str(p.relative_to(S))] = sha(p)
for n in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']:
    source[n] = sha(S / n)
production = {n: h for n, h in source.items() if n.startswith('src/')}
e = dict(status='running', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), deadline_utc=DEADLINE, features=features, source=source, production_source=production, plan=[(label, argv) for label, argv in plan], commands=[], qualification='Module36 final candidate full feature/release matrix. Safe and all features plus every isolated opt-in backend run the complete test suite, true no_std compilation and strict Clippy; safe/all complete release and formatting also run. Every complete/release suite must report identical counts with zero failures; ignored tests are not credited. No implementation change, milestone completion or performance claim is made.')
env = {**os.environ, 'CARGO_TARGET_DIR': str(D / 'target'), 'CARGO_BUILD_JOBS': '6', 'CARGO_INCREMENTAL': '0'}
save = lambda: (D / 'evidence.json').write_text(json.dumps(e, indent=2) + '\n')
done = {c['label'] for c in e['commands']}
for label, _ in plan:
    if label not in done and (D / (label + '.log')).exists():
        (D / (label + '.log')).unlink()
save()
try:
    for label, argv in plan:
        if label in done:
            continue
        remaining = deadline - time.time() - 20
        if remaining < 20:
            raise TimeoutError('deadline before ' + label)
        e['active_command'] = dict(label=label, argv=argv, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
        start = time.monotonic()
        log = D / (label + '.log')
        with log.open('xb') as f:
            proc = subprocess.Popen(argv, cwd=S, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = proc.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                raise TimeoutError('deadline during ' + label)
        row = dict(label=label, argv=argv, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
        text = log.read_text()
        groups = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
        if groups:
            row.update(result_groups=len(groups), passed=sum(int(a) for a, _, _ in groups), failed=sum(int(b) for _, b, _ in groups), ignored=sum(int(c) for _, _, c in groups))
        if label.endswith(('-full', '-release')):
            assert groups and all(b == '0' for _, b, _ in groups), (label, groups)
            counts = (len(groups), row['passed'], row['ignored'])
            baseline = e.get('full_suite_counts')
            if baseline is None:
                e['full_suite_counts'] = dict(result_groups=counts[0], passed=counts[1], ignored=counts[2])
            else:
                assert counts == (baseline['result_groups'], baseline['passed'], baseline['ignored']), (label, counts, baseline)
        e['commands'].append(row)
        e.pop('active_command', None)
        save()
        print(label, code, row.get('passed'), row.get('ignored'), flush=True)
        assert code == 0, (label, text[-4000:])
    for n, h in source.items():
        assert sha(S / n) == h, ('Source changed during the campaign', n)
    e.update(status='passed', finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    save()
except TimeoutError as ex:
    e.update(status='interrupted-at-deadline', error=repr(ex)); save(); raise
except BaseException as ex:
    e.update(status='failed', error=repr(ex)); save(); raise
