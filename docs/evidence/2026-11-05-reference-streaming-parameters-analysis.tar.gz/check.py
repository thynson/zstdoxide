from pathlib import Path
import hashlib,json,subprocess,os,datetime,time
D=Path(__file__).parent;U=Path('/private/tmp/module24-preparation/zstd-git');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e={'status':'running','scope':'Analysis only: nine reset scopes x stages and three bulk-request replacement stages. Uses internal fields only to observe pledge/prefix ownership; not a Rust implementation or upstream migration completion.', 'reference_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=U,text=True).strip(),'helper_sha256':sha(D/'reset_probe.c'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
sources=[str(p) for folder in ['common','compress','decompress'] for p in sorted((U/'lib'/folder).glob('*.c'))]
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 start=time.monotonic()
 with (D/(label+'.log')).open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'})
 e['commands'].append({'label':label,'argv':args,'exit_code':r.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(D/(label+'.log'))});save();assert r.returncode==0,(label,(D/(label+'.log')).read_text())
try:
 for label,flags in [('normal',['-O2']),('sanitized',['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer'])]:
  exe=D/label
  run(label+'-build',['cc','-std=c99','-Wall','-Wextra','-Werror',*flags,'-I'+str(U/'lib'),'-I'+str(U/'lib/common'),str(D/'reset_probe.c'),*sources,'-o',str(exe)])
  run(label+'-capture',[str(exe)])
 assert (D/'normal-capture.log').read_bytes()==(D/'sanitized-capture.log').read_bytes()
 e['rows']=(D/'normal-capture.log').read_text().splitlines();assert len(e['rows'])==12
 e['status']='complete';e['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
except BaseException as ex:e['status']='failed';e['error']=repr(ex);save();raise
