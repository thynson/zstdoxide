/* External analysis probe: no Rust implementation is linked to this helper. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "zstd_errors.h"
#include "compress/zstd_compress_internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void ok(size_t n) { if (ZSTD_isError(n)) {fprintf(stderr,"%s\n",ZSTD_getErrorName(n));exit(2);} }
int main(void) {
    unsigned char prefix[64], output[1024]; int stage,scope;
    memset(prefix,'a',sizeof(prefix));
    for(stage=0;stage<3;stage++) for(scope=0;scope<3;scope++) {
        ZSTD_CCtx *c=ZSTD_createCCtx();size_t ret;int level,checksum;
        ZSTD_ResetDirective modes[3]={ZSTD_reset_session_only,ZSTD_reset_parameters,ZSTD_reset_session_and_parameters};
        if(!c) exit(3);
        ok(ZSTD_CCtx_setParameter(c,ZSTD_c_compressionLevel,9));
        ok(ZSTD_CCtx_setParameter(c,ZSTD_c_checksumFlag,1));
        ok(ZSTD_CCtx_setPledgedSrcSize(c,7));ok(ZSTD_CCtx_refPrefix(c,prefix,sizeof(prefix)));
        if(stage) {
            ZSTD_inBuffer in={"aaaaaaa",stage==2?7:0,0};ZSTD_outBuffer out={output,sizeof(output),0};
            ok(ZSTD_compressStream2(c,&out,&in,stage==2?ZSTD_e_end:ZSTD_e_continue));
        }
        ret=ZSTD_CCtx_reset(c,modes[scope]);
        if((stage==1 && scope==1)!=(ZSTD_getErrorCode(ret)==ZSTD_error_stage_wrong)) exit(4);
        ok(ZSTD_CCtx_getParameter(c,ZSTD_c_compressionLevel,&level));
        ok(ZSTD_CCtx_getParameter(c,ZSTD_c_checksumFlag,&checksum));
        {
            int defaults=scope!=0 && !(stage==1 && scope==1);
            U64 expected_pledge=scope==1 && stage!=2?8:0;
            size_t expected_prefix=stage==0 && scope==0?64:0;
            if(level!=(defaults?3:9) || checksum!=(defaults?0:1) ||
               c->pledgedSrcSizePlusOne!=expected_pledge || c->prefixDict.dictSize!=expected_prefix) exit(5);
            printf("reset\t%d\t%d\t%s\t%d\t%d\t%llu\t%zu\n",stage,scope,
                   ZSTD_isError(ret)?"stage_wrong":"ok",level,checksum,(unsigned long long)c->pledgedSrcSizePlusOne,c->prefixDict.dictSize);
        }
        ZSTD_freeCCtx(c);
    }
    for(stage=0;stage<3;stage++) {
        ZSTD_CCtx *c=ZSTD_createCCtx();ZSTD_CCtx_params *p=ZSTD_createCCtxParams();size_t ret;int level;
        if(!c || !p) exit(6);
        ok(ZSTD_CCtxParams_setParameter(p,ZSTD_c_compressionLevel,5));
        ok(ZSTD_CCtx_refPrefix(c,prefix,sizeof(prefix)));
        if(stage) {ZSTD_inBuffer in={"aaaaaaa",stage==2?7:0,0};ZSTD_outBuffer out={output,sizeof(output),0};ok(ZSTD_compressStream2(c,&out,&in,stage==2?ZSTD_e_end:ZSTD_e_continue));}
        ret=ZSTD_CCtx_setParametersUsingCCtxParams(c,p);
        if((stage==1)!=(ZSTD_getErrorCode(ret)==ZSTD_error_stage_wrong)) exit(7);
        ok(ZSTD_CCtx_getParameter(c,ZSTD_c_compressionLevel,&level));
        if(level!=(stage==1?3:5) || c->prefixDict.dictSize!=(stage==0?64:0)) exit(8);
        printf("replace\t%d\t%s\t%d\t%zu\n",stage,ZSTD_isError(ret)?"stage_wrong":"ok",level,c->prefixDict.dictSize);
        ZSTD_freeCCtx(c);ZSTD_freeCCtxParams(p);
    }
    return 0;
}
