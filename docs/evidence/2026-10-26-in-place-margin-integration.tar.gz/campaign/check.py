from pathlib import Path
import os,subprocess,json,time,hashlib,tomllib
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();features=sorted(n for n in tomllib.loads((S/'Cargo.toml').read_text())['features'] if n.startswith('unsafe-'));env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module28-margin-integration-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
e=dict(status='running',source={str(p.relative_to(S)):sha(p) for p in (S/'src').rglob('*.rs')},preparation_sha256=sha(D/'preparation.json'),commands=[])
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 start=time.monotonic()
 with (D/(label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
save()
try:
 for name,flags,no in [('safe',[],[]),('cursor',['--features','unsafe-byte-cursor'],['--features','unsafe-byte-cursor']),('all',['--all-features'],['--features',','.join(features)])]:
  run(name+'-unit',['cargo','test','--offline','--locked','--lib',*flags,'frame_layout::tests::']);assert '8 passed; 0 failed; 0 ignored' in (D/(name+'-unit.log')).read_text()
  run(name+'-docs',['cargo','test','--offline','--locked','--doc',*flags,'decompression_margin']);assert '1 passed; 0 failed; 0 ignored' in (D/(name+'-docs.log')).read_text()
  run(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*no])
  run(name+'-clippy',['cargo','clippy','--offline','--locked','--lib',*flags,'--','-D','warnings'])
 run('format',['cargo','fmt','--all','--','--check'])
 for n,h in e['source'].items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='Three real-crate integration configurations (safe/cursor/all), eight scanner unit tests and one public Rustdoc each, true no_std, strict production Clippy and formatting. Twenty-two standalone component feature runs and separate native/platform receipts remain distinct. Not whole-codec regression, timing or an in-place decoder milestone.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
