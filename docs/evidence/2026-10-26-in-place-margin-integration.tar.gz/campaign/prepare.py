from pathlib import Path
import shutil,json,hashlib
D=Path(__file__).parent;S=D/'source';S.mkdir();P=Path('/private/tmp/module27-candidate');C=Path('/private/tmp/module28-margin');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((P/'public.json').read_text())['status']=='passed';assert json.loads((C/'evidence.json').read_text())['status']=='passed'
for folder in ['src','tests','test-support','benches','examples','scripts']:
 if (P/folder).exists():shutil.copytree(P/folder,S/folder)
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(P/name,S/name)
base={str(p.relative_to(P)):sha(p) for p in (P/'src').rglob('*.rs')};shutil.copyfile(C/'frame_layout.rs',S/'src/frame_layout.rs');p=S/'src/lib.rs';s=p.read_text();assert s.count('mod frame;')==1;assert s.count('pub use frame::FrameHeader;')==1;s=s.replace('mod frame;','mod frame;\nmod frame_layout;').replace('pub use frame::FrameHeader;','pub use frame::FrameHeader;\npub use frame_layout::decompression_margin;');p.write_text(s)
(D/'preparation.json').write_text(json.dumps(dict(status='passed',predecessor_production=base,component_sha256=sha(C/'evidence.json'),new_source_sha256=sha(S/'src/frame_layout.rs'),qualification='Isolated integration snapshot using qualified Module27 production plus only margin module/export. Predecessor final native/platform/fuzz test merge and full qualification remain separate; promote only after Module27 closure. This does not mutate any source-frozen predecessor.'),indent=2)+'\n')
