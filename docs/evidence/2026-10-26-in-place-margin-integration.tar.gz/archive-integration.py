from pathlib import Path
import json,hashlib,tarfile,subprocess,re
D=Path(__file__).parent;C=Path('/private/tmp/module28-margin-integration');S=C/'source';R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();j=json.loads((C/'evidence.json').read_text());assert j['status']=='passed' and len(j['commands'])==13
for n,h in j['source'].items():assert sha(S/n)==h,n
text={'.rs','.toml','.lock','.md','.json','.py','.sh','.tsv','.csv'};files=[p for p in S.rglob('*') if p.is_file()];complete={str(p.relative_to(S)):sha(p) for p in files};omitted={n:h for n,h in complete.items() if Path(n).suffix not in text}
for n,h in omitted.items():assert sha(R/n)==h,('fixture',n)
commands=[]
for c in j['commands']:
 assert c['exit_code']==0;p=C/(c['label']+'.log');groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.read_text());assert all(int(f)==0 for _,f,_ in groups);commands.append({**c,'log_sha256':sha(p),'passed':sum(int(a) for a,_,_ in groups),'ignored':sum(int(i) for _,_,i in groups)})
name='2026-10-26-in-place-margin-integration';archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in C.iterdir():
  if p.is_file():tar.add(p,arcname='campaign/'+p.name)
 for p in files:
  if p.suffix in text:tar.add(p,arcname='source/'+str(p.relative_to(S)))
 tar.add(__file__,arcname='archive-integration.py')
result=dict(status='passed',source=j['source'],complete_source=complete,commands=commands,preparation=json.loads((C/'preparation.json').read_text()),fixture_provenance=dict(git_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),omitted_binary_files=omitted),archive=archive.name,archive_sha256=sha(archive),qualification=j['qualification'])
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
