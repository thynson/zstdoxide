from pathlib import Path
import shutil,json,hashlib
D=Path(__file__).parent;R=Path('/private/tmp/module32-candidate');I=D/'inputs';I.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={'raw.dict':'tests/upstream/dictionaries/boundary-dictionary.raw','prepared.dict':'tests/upstream/dictionaries/formatted.dict','http.dict':'tests/upstream/data/golden-dictionaries/http-dict-missing-symbols','raw.zst':'tests/upstream/dictionaries/p0-far-dictionary.zst','raw.expected':'tests/upstream/dictionaries/p0-far-dictionary.expected','prepared.zst':'tests/upstream/dictionaries/formatted-id.zst','prepared.expected':'tests/upstream/dictionaries/formatted-id.expected','http.zst':'tests/upstream/data/generated/http-dictionary.zst','http.expected':'tests/upstream/data/golden-compression/http'}
for name,path in files.items():shutil.copyfile(R/path,I/name)
skip=bytes([0x5f,0x2a,0x4d,0x18,3,0,0,0,1,2,3]);(I/'skip.zst').write_bytes(skip);(I/'skip.expected').write_bytes(b'');(I/'empty.zst').write_bytes(b'');(I/'empty.expected').write_bytes(b'');(I/'bad-magic.zst').write_bytes(b'\0'*4)
for n in ['raw','prepared','http']:
 frame=(I/(n+'.zst')).read_bytes();expected=(I/(n+'.expected')).read_bytes();(I/(n+'-twice.zst')).write_bytes(skip+frame+skip+frame);(I/(n+'-twice.expected')).write_bytes(expected*2)
(I/'truncated.zst').write_bytes((I/'http.zst').read_bytes()[:-1]);bad=bytearray((I/'http.zst').read_bytes());bad[-1]^=1;(I/'bad-checksum.zst').write_bytes(bad)
source=bytes((i*37+11)&255 for i in range(120000));raw=bytes.fromhex('28b52ffda0')+len(source).to_bytes(4,'little')+((len(source)<<3)|1).to_bytes(3,'little')+source;(I/'overlap.zst').write_bytes(raw);(I/'overlap.expected').write_bytes(source)
(I/'small.zst').write_bytes(bytes.fromhex('28b52ffd2005')+((5<<3)|1).to_bytes(3,'little')+b'hello');(I/'small.expected').write_bytes(b'hello');(I/'empty.dict').write_bytes(b'')
steps=[]
def add(scenario,action,dictionary='-',frame='-',limit=0,tight=False):
 capacity=0
 if action=='decode':capacity=max((I/(frame+'.zst')).stat().st_size,limit)+(31 if tight else 131072)
 steps.append(dict(id=f'op{len(steps):03}',scenario=scenario,action=action,dictionary=dictionary,frame=frame,limit=limit,capacity=capacity))
def size(frame):return (I/(frame+'.expected')).stat().st_size
for dictionary,mode in [('raw','raw'),('prepared','auto'),('http','auto')]:
 scenario='persistent-'+dictionary;add(scenario,'persistent-'+mode,dictionary)
 for f in [dictionary,dictionary+'-twice',dictionary]:add(scenario,'decode',frame=f,limit=size(f))
 scenario='prefix-'+dictionary;add(scenario,'prefix-'+mode,dictionary);add(scenario,'decode',frame=dictionary+'-twice',limit=size(dictionary+'-twice'));add(scenario,'decode',frame=dictionary,limit=size(dictionary))
for frame,limit in [('skip',0),('empty',0),('bad-magic',0),('truncated',size('http')),('bad-checksum',size('http')),('http',0),('small',5),('overlap',120000)]:
 for prefix in [True,False]:
  scenario=('consume-' if prefix else 'retain-')+frame;add(scenario,'prefix-auto' if prefix else 'persistent-auto','http');add(scenario,'decode',frame=frame,limit=limit,tight=frame=='overlap');add(scenario,'decode',frame='http',limit=size('http'))
scenario='replace-and-clear';add(scenario,'prefix-raw','raw');add(scenario,'persistent-auto','prepared');add(scenario,'decode',frame='prepared',limit=size('prepared'));add(scenario,'prefix-auto','http');add(scenario,'decode',frame='http',limit=size('http'));add(scenario,'decode',frame='http',limit=size('http'));add(scenario,'persistent-raw','raw');add(scenario,'clear');add(scenario,'decode',frame='raw',limit=size('raw'))
scenario='empty-prefix';add(scenario,'prefix-raw','empty');add(scenario,'decode',frame='skip',limit=0);add(scenario,'decode',frame='raw',limit=size('raw'))
(D/'steps.json').write_text(json.dumps(steps,indent=2)+'\n');(D/'steps.tsv').write_text(''.join('\t'.join(str(s[k]) for k in ['id','scenario','action','dictionary','frame','limit','capacity'])+'\n' for s in steps))
(D/'preparation.json').write_text(json.dumps(dict(status='prepared',steps=len(steps),scenarios=len({s['scenario'] for s in steps}),decodes=sum(s['action']=='decode' for s in steps),files={p.name:sha(p) for p in I.iterdir()},qualification='Deterministic supplemental persistent/prefix state schedules. Both output modes repeat each scenario from a fresh context, with actual subsequent-call observations. Raw-overlap cases place a 120KiB raw input at offset31 in the same output allocation; remaining layouts use conservative real buffer capacity. No fabricated native pointer/capacity or invalid Rust coordinate is sent to native.'),indent=2)+'\n');print(len(steps),'steps',sum(s['action']=='decode' for s in steps),'decode attempts')
