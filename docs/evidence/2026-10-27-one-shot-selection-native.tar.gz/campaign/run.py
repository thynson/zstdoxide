from pathlib import Path
import json,hashlib,subprocess,os,time
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();build=json.loads((D/'build.json').read_text());assert build['status']=='passed';pre=json.loads((D/'preparation.json').read_text());assert pre['status']=='prepared'
e=dict(status='running',build_receipt_sha256=sha(D/'build.json'),preparation=pre,steps_sha256=sha(D/'steps.tsv'),commands=[])
def save():(D/'native.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for backend in ['normal','sanitized']:
  assert sha(D/('oracle-'+backend))==build['executables'][backend];out=D/(backend+'-outputs');out.mkdir();args=[str(D/('oracle-'+backend)),str(D),str(D/'steps.tsv'),str(out)];t=time.monotonic()
  with (D/(backend+'.tsv')).open('xb') as f,(D/(backend+'.stderr')).open('xb') as err:p=subprocess.run(args,stdout=f,stderr=err,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
  e['commands'].append(dict(label=backend,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(D/(backend+'.tsv')),stderr_sha256=sha(D/(backend+'.stderr'))));save();assert p.returncode==0;print(backend,'completed',flush=True)
 assert (D/'normal.tsv').read_bytes()==(D/'sanitized.tsv').read_bytes();assert len((D/'normal.tsv').read_text().splitlines())==162
 outputs={p.name:sha(p) for p in (D/'normal-outputs').iterdir()};assert len(outputs)==106;assert outputs=={p.name:sha(p) for p in (D/'sanitized-outputs').iterdir()}
 for n,h in pre['files'].items():assert sha(D/'inputs'/n)==h,n
 e.update(status='passed',outputs=outputs,qualification='Both native builds execute 81 state/setup/decode steps in each of two output modes, yielding 106 genuine decode attempts with observable subsequent-call behavior. Real contexts use by-reference external persistent DDicts or refPrefix_advanced raw/auto selections. Prefix applies to a whole call, including concatenated frames, then is consumed. Outer guards and bytes beyond actual output allowance are checked. Raw-overlap input begins at offset31 within the same allocation. This is a supplemental bounded lifecycle schedule, not an original fuzzer history migration. macOS leak detection is unsupported and disabled; ASan bounds/UBSan remain active.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
