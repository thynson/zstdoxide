/* External v1.5.7 call-level selection oracle. No codec binding is used by Rust. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "zstd_errors.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void check(size_t value) {if(ZSTD_isError(value)){fprintf(stderr,"%s\n",ZSTD_getErrorName(value));exit(10);}}
static unsigned char *load(const char *root,const char *name,const char *suffix,size_t *size) {
    char path[4096];FILE *file;long length;unsigned char *bytes;
    snprintf(path,sizeof(path),"%s/inputs/%s.%s",root,name,suffix);file=fopen(path,"rb");
    if(!file || fseek(file,0,SEEK_END) || (length=ftell(file))<0 || fseek(file,0,SEEK_SET))exit(11);
    *size=(size_t)length;bytes=malloc(*size?*size:1);if(!bytes || fread(bytes,1,*size,file)!=*size || fclose(file))exit(12);return bytes;
}
int main(int argc,char **argv) {
    int mode;
    if(argc!=4 || ZSTD_versionNumber()!=10507)return 2;
    for(mode=0;mode<2;mode++) {
        FILE *steps=fopen(argv[2],"r");char id[128],scenario[128],action[128],dictionary[128],frame[128],previous[128]="";
        size_t limit,capacity;int fields;ZSTD_DCtx *ctx=NULL;ZSTD_DDict *prepared=NULL;unsigned char *dict_bytes=NULL;size_t dict_size=0;
        if(!steps)return 3;
        while((fields=fscanf(steps,"%127s %127s %127s %127s %127s %zu %zu",id,scenario,action,dictionary,frame,&limit,&capacity))==7) {
            if(strcmp(previous,scenario)) {
                ZSTD_freeDCtx(ctx);ZSTD_freeDDict(prepared);free(dict_bytes);prepared=NULL;dict_bytes=NULL;dict_size=0;
                ctx=ZSTD_createDCtx();if(!ctx)return 4;strcpy(previous,scenario);
            }
            if(strcmp(action,"decode")) {
                check(ZSTD_DCtx_refDDict(ctx,NULL));ZSTD_freeDDict(prepared);free(dict_bytes);prepared=NULL;dict_bytes=NULL;dict_size=0;
                if(strcmp(action,"clear")) {
                    ZSTD_dictContentType_e content=strstr(action,"raw")?ZSTD_dct_rawContent:ZSTD_dct_auto;
                    dict_bytes=load(argv[1],dictionary,"dict",&dict_size);
                    if(!strncmp(action,"persistent-",11)) {
                        prepared=ZSTD_createDDict_advanced(dict_bytes,dict_size,ZSTD_dlm_byRef,content,ZSTD_defaultCMem);
                        if(!prepared)return 5;check(ZSTD_DCtx_refDDict(ctx,prepared));
                    } else if(!strncmp(action,"prefix-",7))check(ZSTD_DCtx_refPrefix_advanced(ctx,dict_bytes,dict_size,content));
                    else return 6;
                }
                printf("%s\t%d\tsetup\t0\t0\n",id,mode);
            } else {
                size_t size,i,result;unsigned char *input=load(argv[1],frame,"zst",&size),*storage,*before;const unsigned char *source;char path[4096];FILE *out;
                if(limit>capacity || size>capacity)return 7;
                storage=malloc(capacity+32);before=malloc(capacity+32);if(!storage || !before)return 8;memset(storage,0xa5,capacity+32);
                source=input;if(mode){memcpy(storage+16+capacity-size,input,size);source=storage+16+capacity-size;}
                memcpy(before,storage,capacity+32);result=ZSTD_decompressDCtx(ctx,storage+16,limit,source,size);
                if(memcmp(storage,before,16) || memcmp(storage+16+limit,before+16+limit,capacity+16-limit))return 9;
                if(!ZSTD_isError(result) && result>limit)return 13;
                snprintf(path,sizeof(path),"%s/%s-%d.bin",argv[3],id,mode);out=fopen(path,"wb");
                i=ZSTD_isError(result)?0:result;if(!out || fwrite(storage+16,1,i,out)!=i || fclose(out))return 14;
                printf("%s\t%d\t%s\t%zu\t%u\n",id,mode,ZSTD_isError(result)?"error":"ok",i,(unsigned)ZSTD_getErrorCode(result));
                free(input);free(storage);free(before);
            }
        }
        if(fields!=EOF || ferror(steps) || fclose(steps))return 15;
        ZSTD_freeDCtx(ctx);ZSTD_freeDDict(prepared);free(dict_bytes);
    }
    return 0;
}
