from pathlib import Path
import subprocess,shutil
D=Path(__file__).parent;S=D/'replay-source';assert not S.exists();subprocess.run(['cp','-cR','/private/tmp/module32-candidate',str(S)],check=True);shutil.copyfile(D/'one_shot_selection_native.rs',S/'tests/one_shot_selection_native.rs');subprocess.run(['cargo','fmt','--all'],cwd=S,check=True)
