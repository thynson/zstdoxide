from pathlib import Path
import subprocess,os,json,hashlib,time,re
D=Path(__file__).parent;S=D/'replay-source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native=json.loads((D/'native.json').read_text());assert native['status']=='passed';source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()}
for p in (Path('/private/tmp/module32-candidate')/'src').glob('*.rs'):assert sha(S/'src'/p.name)==sha(p)
e=dict(status='running',source=source,native_receipt_sha256=sha(D/'native.json'),commands=[]);env={**os.environ,'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_TARGET_DIR':str(D/'replay-target'),'ZSTDOXIDE_ONE_SHOT_SELECTION_CASES':str(D)}
def save():(D/'replay.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [('safe',[]),('in-place',['--features','unsafe-in-place-buffer']),('history',['--features','unsafe-slice-history']),('dictionary',['--features','unsafe-dictionary']),('all',['--all-features'])]:
  args=['cargo','test','--offline','--locked','--test','one_shot_selection_native',*flags,'--','--ignored','--nocapture'];t=time.monotonic()
  with (D/(name+'-replay.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(name+'-replay.log'))));save();assert p.returncode==0 and '1 passed; 0 failed; 0 ignored' in (D/(name+'-replay.log')).read_text()
  observed=[line for line in (D/(name+'-replay.log')).read_text().splitlines() if line.startswith('OBS\t')];assert len(observed)==106;ledger='\n'.join(observed)+'\n';(D/(name+'-observations.tsv')).write_text(ledger)
  if name!='safe':assert ledger==(D/'safe-observations.tsv').read_text()
  print(name,'106 observations passed',flush=True)
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='Five Rust backends replay both direct/in-place modes of 81 state/setup/decode steps, including 106 decode attempts. All complete successful output bytes match native and fixtures; outer/allowance guards and stronger Rust success suffix remain unchanged. Observable subsequent calls agree on prefix consumption/persistent retention. Four empty-input attempts retain Rust UnexpectedEof versus native success zero; both consume a prefix on that attempt. Native error-code identity is not equated with typed Rust errors. All per-attempt Rust state/result rows match across five backends. These schedules supplement original groups without upgrading their migration status.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
