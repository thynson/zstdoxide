from pathlib import Path
import json,hashlib,subprocess,os,time,tomllib
D=Path(__file__).parent;N=Path('/private/tmp/module24-native')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
native=json.loads((N/'native.json').read_text());assert native['status']=='passed'
cases=json.loads((N/'cases.json').read_text());rows=[f"{c['name']}\t{c['capacity']}\t{c['chunk']}\t{c['expected']}" for c in cases if c['mode']=='normal'];(N/'rust-cases.tsv').write_text('\n'.join(rows)+'\n')
for n,h in native['inputs'].items():assert sha(N/'inputs'/n)==h
features=sorted(f for f in tomllib.loads((D/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-'))
paths=list((D/'src').rglob('*.rs'))+[D/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/slice_decoder.rs','tests/slice_decoder_native.rs','tests/upstream_decodecorpus.rs']]
e=dict(status='running',source={str(p.relative_to(D)):sha(p) for p in paths},native_sha256=sha(N/'native.json'),native_manifest_sha256=sha(N/'rust-cases.tsv'),common_cases=len(rows),commands=[])
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module24-candidate-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0','ZSTDOXIDE_STABLE_NATIVE_STAGE':str(N)}
def save():(D/'public.json').write_text(json.dumps(e,indent=2)+'\n')
def run(label,args):
 start=time.monotonic()
 with (D/('public-'+label+'.log')).open('xb') as f:p=subprocess.run(args,cwd=D,env=env,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start));save();print(label,p.returncode,flush=True);assert p.returncode==0,label
save()
try:
 for name,flags,no in [('safe',[],[]),('slice',['--features','unsafe-slice-history'],['--features','unsafe-slice-history']),('all',['--all-features'],['--features',','.join(features)])]:
  run(name+'-focused',['cargo','test','--offline','--locked','--test','slice_decoder','--test','caller_output','--test','caller_output_platform','--test','upstream_decodecorpus',*flags])
  run(name+'-native',['cargo','test','--offline','--locked','--test','slice_decoder_native',*flags,'--','--ignored','--nocapture'])
  run(name+'-docs',['cargo','test','--offline','--locked','--doc',*flags])
  run(name+'-no-std',['cargo','check','--offline','--locked','--lib','--no-default-features',*no])
  run(name+'-clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])
 run('format',['cargo','fmt','--all','--','--check'])
 for n,h in e['source'].items():assert sha(D/n)==h,n
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
