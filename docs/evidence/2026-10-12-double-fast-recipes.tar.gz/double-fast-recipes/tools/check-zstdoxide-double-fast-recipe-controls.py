from pathlib import Path
from dataclasses import replace
import json,sys,struct,hashlib
root=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(root/'scripts'))
import check_double_fast_recipes as check
out=Path(sys.argv[1]);out.mkdir();cases=check.check_manifest(check.MANIFEST);rows=[{'label':'complete-positive-envelope','passed':True,'cases':len(cases)}]
byname={c.recipe.name:c for c in cases};base=byname['prefix-tail-10'];packet=base.recipe.packet()
def reject(label,call):
 try:call()
 except (ValueError,KeyError,TypeError,OSError) as e:rows.append({'label':label,'rejected':True,'diagnostic':str(e)});return
 raise ValueError('accepted '+label)
mutations={'magic':b'!'+packet[1:],'id-unknown':packet[:8]+b'unknown'.ljust(64,b'\0')+packet[72:],'id-post-null':packet[:8]+b'a\0b'+bytes(61)+packet[72:],'truncated-header':packet[:131],'truncated-seeds':packet[:137],'truncated-source':packet[:-1],'extra-byte':packet+b'!','altered-source':packet[:-1]+bytes([packet[-1]^255])}
for label,offset,value in [('prefix',72,(2<<20)+1),('block-short',76,6),('block-large',76,(128<<10)+1),('window-low',80,9),('window-high',80,22),('long-log',84,5),('short-log',88,19),('search-low',92,0),('search-high',92,30),('width',96,8),('target',100,131073),('floor',104,65),('repeat-zero',108,0),('long-count',120,1025),('short-count',124,1025),('reserved',128,1),('future-long-seed',132,64),('future-short-seed',136,64)]:
 data=bytearray(packet);struct.pack_into('<I',data,offset,value);mutations[label]=bytes(data)
for label,data in mutations.items():
 (out/(label+'.packet')).write_bytes(data);reject('packet-'+label,lambda data=data:check.check_packet(base,data))
for label,changes in [('bool-log',{'long_log':True}),('negative-floor',{'floor':-1}),('future-floor',{'floor':65}),('zero-repeat',{'repeats':(0,4,8)}),('bool-repeat',{'repeats':(True,4,8)}),('oversized-repeat',{'repeats':(1<<32,4,8)}),('seed-at-block',{'long_seeds':(64,)}),('short-crossing-seed',{'short_seeds':(63,)}),('seed-count',{'long_seeds':(0,)*1025}),('small-window',{'window_log':9}),('large-window',{'window_log':22}),('small-log',{'short_log':5}),('large-log',{'long_log':19}),('negative-target',{'target':-1}),('large-target',{'target':131073}),('low-width',{'min_match':2}),('high-width',{'min_match':8}),('empty-name',{'name':''}),('bad-name',{'name':'MixedCase'}),('long-name',{'name':'a'*64})]:
 r=replace(base.recipe,**changes);reject('recipe-'+label,r.packet)
manifest=json.loads(check.MANIFEST.read_text())
for label,mutate in [('unknown-name',lambda m:m['cases'][0].update(id='unknown')),('duplicate-case',lambda m:m['cases'].append(m['cases'][0])),('missing-case',lambda m:m['cases'].pop()),('unknown-family',lambda m:m['cases'][0].update(family='unknown')),('bool-schema',lambda m:m.update(schema_version=True)),('generator-identity',lambda m:m.update(generator_sha256='0'*64))]:
 m=json.loads(json.dumps(manifest));mutate(m);p=out/(label+'.json');p.write_text(json.dumps(m));reject('manifest-'+label,lambda p=p:check.check_manifest(p))
report={'status':'passed','optimized':sys.flags.optimize,'positive':sum(r.get('passed',False) for r in rows),'rejected':sum(r.get('rejected',False) for r in rows),'controls':rows,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(out/'results.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('status','optimized','positive','rejected')}))
