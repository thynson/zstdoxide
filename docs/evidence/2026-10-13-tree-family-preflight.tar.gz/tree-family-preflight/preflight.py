from pathlib import Path
from types import SimpleNamespace
import hashlib,json,runpy,sys,tempfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');U=Path('/private/tmp/zstdoxide-reference-lazy-1.5.7')
sys.dont_write_bytecode=True;sys.path.insert(0,str(R/'scripts'))
import capture_tree_families as capture,check_tree_families_capture as audit,tree_family_capture_inputs as inputs
attempts=[]
def no_children(event,args):
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec','os.spawn'):
  attempts.append(event);raise RuntimeError('child process forbidden')
sys.addaudithook(no_children)
results=[]
def reject(name,call):
 try:call()
 except (ValueError,TypeError,OSError,KeyError,IndexError):results.append(name)
 else:raise ValueError('accepted malformed plan '+name)
with tempfile.TemporaryDirectory(prefix='zstdoxide-tree-preflight-') as temporary:
 root=Path(temporary).resolve();output=root/'capture'
 args=SimpleNamespace(upstream=U,output=output,cc='clang');prepared=capture.prepare(args)
 if len(prepared[-1])!=25 or len(prepared[2])!=103 or output.exists():raise ValueError('read-only positive preparation')
 oracle,cases,_=inputs.inputs();negatives=inputs.malformed_packets(oracle,cases)
 if len(negatives)!=25:raise ValueError('negative packets')
 for name,changes in [('missing-upstream',{'upstream':None}),('missing-output',{'output':None}),
                      ('repository-upstream',{'upstream':R}),('repository-output',{'output':R/'fresh-tree-output'}),
                      ('upstream-output',{'output':U/'fresh-tree-output'}),('existing-output',{'output':root}),
                      ('missing-compiler',{'cc':'zstdoxide-no-such-compiler-20261013'})]:
  params=vars(args)|changes;reject(name,lambda p=params:capture.prepare(SimpleNamespace(**p)))
 link=root/'linked';link.symlink_to(root,target_is_directory=True)
 reject('symlink-output',lambda:capture.prepare(SimpleNamespace(upstream=U,output=link,cc='clang')))
 old=capture.CHECKER_SHA;capture.CHECKER_SHA='0'*64
 try:reject('changed-reviewed-checker',capture.inputs)
 finally:capture.CHECKER_SHA=old
 old=inputs.PINS['scripts/oracles/tree_direct_v1.c'];inputs.PINS['scripts/oracles/tree_direct_v1.c']='0'*64
 try:reject('changed-reviewed-helper',inputs.inputs)
 finally:inputs.PINS['scripts/oracles/tree_direct_v1.c']=old
 # A minimal incomplete capture exercises schema/source/env gates without
 # inventing successful C commands, observations, object bytes or executables.
 destination=root/'incomplete';destination.mkdir();(destination/'recipes.json').write_bytes((R/inputs.MANIFEST).read_bytes())
 local=set(inputs.PINS)|{inputs.MANIFEST,'scripts/tree_family_capture_inputs.py','scripts/capture_tree_families.py','tests/upstream/manifest.json'}
 sources={n:capture.file_sha(R/n) for n in sorted(local)}
 catalog=oracle.decode_json((R/'tests/upstream/manifest.json').read_bytes())
 c_sources={r['path']:r['sha256'] for r in catalog['sources']+catalog['excluded_sources'] if r['path'].startswith('lib/') and Path(r['path']).suffix in ('.c','.h')}
 base=dict(status='passed',schema_version=1,upstream_revision=oracle.REVISION,support_archive_used=False,
           upstream_sanitizer_annotations_retained=True,source_before=sources,source_after=sources,
           upstream_source_sha256=c_sources,builds={'normal':{},'sanitized':{}},commands=[],
           environment=dict(LANG='C',LC_ALL='C',TZ='UTC',ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'))
 for name,edit in [('missing-commands',lambda e:None),('incomplete-status',lambda e:e.update(status='running')),
                   ('boolean-schema',lambda e:e.update(schema_version=True)),('wrong-revision',lambda e:e.update(upstream_revision='0'*40)),
                   ('support-archive',lambda e:e.update(support_archive_used=True)),('changed-source',lambda e:e.update(source_after={})),
                   ('loader-injection',lambda e:e['environment'].update(DYLD_INSERT_LIBRARIES='/tmp/unused')),
                   ('recovering-sanitizer',lambda e:e['environment'].update(ASAN_OPTIONS='detect_leaks=0:halt_on_error=0'))]:
  e=json.loads(json.dumps(base));edit(e);(destination/'evidence.json').write_text(json.dumps(e));reject('audit-'+name,lambda:audit.audit(destination))
 old=audit.CAPTURE_SHA;audit.CAPTURE_SHA='0'*64
 try:reject('changed-reviewed-controller',lambda:audit.audit(destination))
 finally:audit.CAPTURE_SHA=old
 if len(capture.prepare(args)[-1])!=25:raise ValueError('restored preparation')
if attempts:raise ValueError('child attempted')
report=dict(status='passed',optimized=not __debug__,positive_plans=2,malformed_packets=25,rejected=len(results),cases=results,child_processes=0,
            source={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['scripts/capture_tree_families.py','scripts/check_tree_families_capture.py','scripts/tree_family_capture_inputs.py',*inputs.PINS]},
            qualification='Read-only plan/identity/path checks and deliberately incomplete-capture rejection. No positive C capture, object build, helper execution or search observation.')
print(json.dumps(report,sort_keys=True))
