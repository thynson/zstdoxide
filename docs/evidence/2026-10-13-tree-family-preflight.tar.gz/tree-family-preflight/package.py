from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
reports={m:json.loads(Path('/tmp/zstdoxide-tree-family-preflight-'+m+'.json').read_text()) for m in ('normal','optimized')}
for m,r in reports.items():
 if r['status']!='passed' or r['rejected']!=19 or r['child_processes']!=0 or r['optimized']!=(m=='optimized'):raise ValueError('preflight result')
 for n,h in r['source'].items():
  if sha((R/n).read_bytes())!=h:raise ValueError('source identity '+n)
files={n:(R/n).read_bytes() for n in reports['normal']['source'] if not n.endswith('.tar.gz')}
files.update({m+'.json':Path('/tmp/zstdoxide-tree-family-preflight-'+m+'.json').read_bytes() for m in reports})
files['preflight.py']=Path('/tmp/zstdoxide-tree-family-preflight.py').read_bytes()
files['package.py']=Path(__file__).read_bytes()
a=E/'2026-10-13-tree-family-preflight.tar.gz'
if a.exists():raise ValueError('fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('tree-family-preflight/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:actual={m.name:t.extractfile(m).read() for m in t}
if actual!={'tree-family-preflight/'+n:b for n,b in files.items()}:raise ValueError('archive bytes')
r=dict(status='passed',recipes=103,planned_commands=316,reports=reports,archive=a.name,archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),qualification='Read-only preparation and incomplete capture rejection only; no broader C execution. Thirty predecessor logs are independently reconstructed from the pinned tiny archive without executing its archived code. Complete helper and protocol remain unchanged.')
(E/'2026-10-13-tree-family-preflight.json').write_text(json.dumps(r,sort_keys=True,indent=2)+'\n')
print('Archived both preflight modes')
