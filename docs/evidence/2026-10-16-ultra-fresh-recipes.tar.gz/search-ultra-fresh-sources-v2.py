from pathlib import Path
import sys,json,time,hashlib
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path.cwd()/'scripts'))
from oracles.ultra_fresh import Request
from oracles.optimal_fresh_wide import Request as Original
from oracles.ultra_fresh_validation import records
output=Path('/tmp/ultra-fresh-source-search-v2-1016');output.mkdir();start=time.monotonic();catalog=[];found=[]
for seed in range(64):
 state=0x144f5e+seed;data=bytearray();alphabet=[2,3,4,6][seed%4]
 for index in range(192):
  state^=(state<<13)&0xffffffff;state^=state>>17;state^=(state<<5)&0xffffffff;state&=0xffffffff
  data.append(97+state%alphabet)
 prefix=b''.join(b'abbaabac'+bytes([128+i]) for i in range(48))
 data=bytearray(prefix)+data
 minimum=3 if seed%8<4 else 4
 r=Request(2,Original(bytes(data),(len(data),),window_log=10,hash_log=8,chain_log=8,search_log=6,min_match=minimum,target=128))
 rows,coverage=records(r,(2,));alternatives=[e for e in rows if e.get('alternative')is not None]
 record=dict(seed=seed,source_sha256=hashlib.sha256(bytes(data)).hexdigest(),minimum=minimum,events=sum(e['record']=='event'for e in rows),alternatives=len(alternatives),coverage=sorted(coverage));catalog.append(record)
 if alternatives:
  name=f'seed-{seed}';(output/(name+'.bin')).write_bytes(r.packet());record['packet']=name+'.bin';found.append(record)
 (output/'progress.json').write_text(json.dumps(dict(completed=len(catalog),found=found),indent=2)+'\n')
print(json.dumps(dict(status='passed',seconds=time.monotonic()-start,cases=catalog,found=found,qualification='Deterministic source-only search for additional ordinary Ultra branch recipes; no C or Rust execution.'),indent=2))
