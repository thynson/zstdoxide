#![no_std]
#![deny(unsafe_op_in_unsafe_fn)]
#![deny(clippy::undocumented_unsafe_blocks, clippy::missing_safety_doc)]
#[cfg(test)]
extern crate alloc;
#[allow(dead_code)]
mod cursor;
mod error;
#[allow(dead_code)]
mod frame;
mod frame_layout;
pub use error::{Error, Result};
pub use frame::FrameHeader;
pub use frame_layout::{
    FrameInfo, FrameKind, decompressed_size, decompression_bound, decompression_margin,
    frame_compressed_size, frame_info, is_skippable_frame, skippable_payload,
};
