from pathlib import Path
import argparse,json,hashlib,tarfile,datetime,re
p=argparse.ArgumentParser();p.add_argument('stage',choices=['layout','public-api','native','history','platform','corpus']);a=p.parse_args();D=Path(__file__).parent;T=Path('/private/tmp');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
config={'layout':('module30-layout','source',['evidence.json']),'public-api':('module30-public',None,['evidence.json']),'native':('module30-native','replay-source',['build.json','originals.json','native.json','rust.json','replay.json']),'history':('module30-native-history','replay-source',['capture.json','reference-source-audit.json','replay.json']),'platform':('module30-platform','source',['evidence.json']),'corpus':('module30-corpus','source',['evidence.json'])};folder,sub,receipts=config[a.stage];C=T/folder;S=C/sub if sub else T/'module30-candidate';records={n:json.loads((C/n).read_text()) for n in receipts}
for n,j in records.items():assert j['status']=='passed',(n,j['status']);assert all(r['exit_code']==0 for r in j.get('commands',[])),n
complete={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()};production=records['evidence.json']['production_source'] if a.stage=='platform' else {n:h for n,h in complete.items() if n.startswith('src/')}
for n,j in records.items():
 for path,h in j.get('source',{}).items():
  if path.startswith('src/'):assert production[path]==h,(n,path)
 for row in j.get('commands',[]):
  if 'log_sha256' in row:assert any(sha(p)==row['log_sha256'] for p in C.glob('*.log')),(n,row['label'])
if a.stage in ['layout','public-api']:
 for row in records['evidence.json']['commands']:
  suffix=row['label'].split('-',1)[-1];count={'unit':9,'public':7,'docs':1 if a.stage=='layout' else 4}.get(suffix)
  if count is not None:
   g=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (C/(row['label']+'.log')).read_text());assert sum(int(x) for x,_,_ in g)==count,(row['label'],g)
files={};payloads={};extensions={'.rs','.toml','.lock','.json','.py','.md','.log','.tsv','.stderr','.jsonl','.c','.txt','.ll','.o','.patch'};excluded={'target','rust-target','replay-target','miri-i686','miri-s390x','thumb-check','thumb-safe','thumb-all','source','replay-source','probe','rust-capture','__pycache__'};payload_folders={'inputs','normal-originals','sanitized-originals','normal-fixtures','sanitized-fixtures'}
for p in C.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(C)
 if any(x in excluded or x.endswith('.dSYM') for x in rel.parts):continue
 if rel.parts[0] in payload_folders:continue
 if p.name=='fuzzer-capture.c':continue
 if p.suffix in extensions or p.name.startswith(('oracle-','capture-normal','capture-sanitized')):files['campaign/'+str(rel)]=p
for p in S.rglob('*'):
 if p.is_file() and p.suffix in {'.rs','.toml','.lock','.json','.py','.md','.sh','.csv','.tsv'}:files['source/'+str(p.relative_to(S))]=p
if a.stage in ['native','history']:
 for folder in (['inputs','normal-originals'] if a.stage=='native' else ['normal-fixtures']):
  for p in (C/folder).iterdir():
   if p.is_file():h=sha(p);payloads[str(p.relative_to(C))]=h;files.setdefault('payloads/'+h,p)
if a.stage=='platform':files['probe/lib.rs']=C/'probe/lib.rs'
files['LICENSE.zstd']=Path('/Users/lanxingcan/Workspace/zstdoxize/LICENSE.zstd');files['archive-focused.py']=Path(__file__);name='2026-10-27-frame-query-'+a.stage;archive=D/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
result=dict(status='passed',stage=a.stage,recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,complete_source=complete,records=records,receipt_sha256={n:sha(C/n) for n in receipts},external_fixture_payloads=payloads,members={n:dict(sha256=sha(p),bytes=p.stat().st_size) for n,p in files.items()},archive=archive.name,archive_sha256=sha(archive),qualification='Completed source-bound focused gate; whole feature/release regression, timing and closure remain separate. Downloaded upstream source is excluded; its pinned identities and observation patch reconstruct the external fuzzer. Native fixtures are content-addressed. Preserved helper/test preparation rejections are not passes. Component core-only compilation proves structural-query allocation independence, not whole-codec core-only support. No complete upstream parity is claimed.')
(D/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(name,archive.stat().st_size)
