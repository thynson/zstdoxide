; ModuleID = 'zstdoxide.6fa0709cb792b9c0-cgu.0'
source_filename = "zstdoxide.6fa0709cb792b9c0-cgu.0"
target datalayout = "e-m:e-p:32:32-Fi8-i64:64-v128:64:128-a:0:32-n32-S64"
target triple = "thumbv6m-unknown-none-eabi"

@alloc_49187a1a9102f6fabfbd4ff8645930a8 = private unnamed_addr constant [16 x i8] c"frame_layout.rs\00", align 1, !guid !0
@alloc_5e6a025b48b26689566b9e005edba7db = private unnamed_addr constant <{ ptr, [12 x i8] }> <{ ptr @alloc_49187a1a9102f6fabfbd4ff8645930a8, [12 x i8] c"\0F\00\00\00\E8\00\00\00\17\00\00\00" }>, align 4, !guid !1
@alloc_7435913fe0ee9560e916ffcef5e2af54 = private unnamed_addr constant <{ ptr, [12 x i8] }> <{ ptr @alloc_49187a1a9102f6fabfbd4ff8645930a8, [12 x i8] c"\0F\00\00\00\FC\00\00\00\17\00\00\00" }>, align 4, !guid !2
@alloc_048330390765a63cc99a694538bdf970 = private unnamed_addr constant <{ ptr, [12 x i8] }> <{ ptr @alloc_49187a1a9102f6fabfbd4ff8645930a8, [12 x i8] c"\0F\00\00\00R\01\00\00\17\00\00\00" }>, align 4, !guid !3
@alloc_bdac395b1457309b01119d6ee7241f45 = private unnamed_addr constant [23 x i8] c"invalid codec parameter", align 1, !guid !4
@alloc_a831c82912810798379f6d40f5aa0bba = private unnamed_addr constant [27 x i8] c"invalid codec context state", align 1, !guid !5
@alloc_7b392dc8ea31c8e6782cf57e8779c179 = private unnamed_addr constant [23 x i8] c"unexpected end of input", align 1, !guid !6
@alloc_ac0217ade07e90bc94cc456679817822 = private unnamed_addr constant [19 x i8] c"invalid frame magic", align 1, !guid !7
@alloc_7ff98b587660cdced76113da7cb03293 = private unnamed_addr constant [22 x i8] c"corrupt Zstandard data", align 1, !guid !8
@alloc_d54e75b67645a5578e757e031fa62642 = private unnamed_addr constant [24 x i8] c"a dictionary is required", align 1, !guid !9
@alloc_235b61828294feeeb2172ca04092afbd = private unnamed_addr constant [28 x i8] c"invalid Zstandard dictionary", align 1, !guid !10
@alloc_43353d327e5fe4ba2f2a23fb232c29f0 = private unnamed_addr constant [22 x i8] c"dictionary ID mismatch", align 1, !guid !11
@alloc_358d882c88585a0b91bdd46f073d6817 = private unnamed_addr constant [40 x i8] c"insufficient dictionary training samples", align 1, !guid !12
@alloc_46538b36b8c48fbfe6a4f94227e7fbd0 = private unnamed_addr constant [29 x i8] c"unsupported Zstandard feature", align 1, !guid !13
@alloc_d1b0c6bc606a538edf406f6115094080 = private unnamed_addr constant [23 x i8] c"resource limit exceeded", align 1, !guid !14
@alloc_afc2a81fe13a0b3a87a4890cf54edc49 = private unnamed_addr constant [17 x i8] c"allocation failed", align 1, !guid !15
@alloc_959af6a03cd01ca999bfcd6a252429f4 = private unnamed_addr constant [27 x i8] c"frame content size mismatch", align 1, !guid !16
@alloc_d644fd8040ac32617306136b0f3eecf4 = private unnamed_addr constant [23 x i8] c"frame checksum mismatch", align 1, !guid !17
@switch.table._RNvXNtCs9AbywTnvkjY_9zstdoxide5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt = private unnamed_addr constant [14 x i8] c"\17\1B\17\13\16\18\1C\16(\1D\17\11\1B\17", align 4, !guid !18
@switch.table._RNvXNtCs9AbywTnvkjY_9zstdoxide5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt.3 = private unnamed_addr constant [14 x ptr] [ptr @alloc_bdac395b1457309b01119d6ee7241f45, ptr @alloc_a831c82912810798379f6d40f5aa0bba, ptr @alloc_7b392dc8ea31c8e6782cf57e8779c179, ptr @alloc_ac0217ade07e90bc94cc456679817822, ptr @alloc_7ff98b587660cdced76113da7cb03293, ptr @alloc_d54e75b67645a5578e757e031fa62642, ptr @alloc_235b61828294feeeb2172ca04092afbd, ptr @alloc_43353d327e5fe4ba2f2a23fb232c29f0, ptr @alloc_358d882c88585a0b91bdd46f073d6817, ptr @alloc_46538b36b8c48fbfe6a4f94227e7fbd0, ptr @alloc_d1b0c6bc606a538edf406f6115094080, ptr @alloc_afc2a81fe13a0b3a87a4890cf54edc49, ptr @alloc_959af6a03cd01ca999bfcd6a252429f4, ptr @alloc_d644fd8040ac32617306136b0f3eecf4], align 4, !guid !19

; zstdoxide::frame_queries_codegen_probe
; Function Attrs: noinline nounwind
define dso_local void @_RNvCs9AbywTnvkjY_9zstdoxide27frame_queries_codegen_probe(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #0 !guid !22 {
start:
  %_3.i.i4 = alloca [48 x i8], align 8
  %layout.sroa.7.i.i = alloca [19 x i8], align 1
  %_3.i.i = alloca [48 x i8], align 8
  %_6.sroa.7.i = alloca [8 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %layout.sroa.7.i.i)
  %_331.i = icmp eq i32 %input.1, 0
  br i1 %_331.i, label %bb7.thread, label %bb3.lr.ph.i

bb7.thread:                                       ; preds = %start
  call void @llvm.lifetime.end.p0(ptr nonnull %layout.sroa.7.i.i)
  br label %bb9

bb3.lr.ph.i:                                      ; preds = %start
  %_15.sroa.4.0._3.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i32 8
  %_15.sroa.5.0._3.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i32 9
  %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i32 12
  %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i32 13
  %_15.sroa.6.0._3.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i, i32 32
  %_6.sroa.7.13._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_6.sroa.7.i, i32 5
  %_6.sroa.7.i.4.i.4.i.4._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_6.sroa.7.i, i32 4
  %_6.sroa.7.i.1.i.1.i.1._6.sroa_idx = getelementptr inbounds nuw i8, ptr %_6.sroa.7.i, i32 1
  br label %bb3.i

bb3.i:                                            ; preds = %bb22.i, %bb3.lr.ph.i
  %input.sroa.0.035.i = phi ptr [ %input.0, %bb3.lr.ph.i ], [ %_45.i, %bb22.i ]
  %input.sroa.6.034.i = phi i32 [ %input.1, %bb3.lr.ph.i ], [ %_41.i, %bb22.i ]
  %known.sroa.0.0.off033.i = phi i1 [ true, %bb3.lr.ph.i ], [ %known.sroa.0.1.off0.i, %bb22.i ]
  %total.sroa.0.032.i = phi i64 [ 0, %bb3.lr.ph.i ], [ %total.sroa.0.1.i, %bb22.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_6.sroa.7.i)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !23)
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.i.i), !noalias !26
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCs9AbywTnvkjY_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_3.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.035.i, i32 noundef range(i32 0, -2147483648) %input.sroa.6.034.i) #9, !noalias !31
  %0 = load i64, ptr %_3.i.i, align 8, !range !32, !noalias !26, !noundef !33
  %1 = icmp eq i64 %0, -1
  %_16.i.i = load i8, ptr %_15.sroa.4.0._3.sroa_idx.i.i, align 8, !noalias !26
  br i1 %1, label %bb14.i, label %bb8.i.i

bb8.i.i:                                          ; preds = %bb3.i
  %_15.sroa.5.sroa.0.0.copyload.i.i = load i24, ptr %_15.sroa.5.0._3.sroa_idx.i.i, align 1, !noalias !26
  %_15.sroa.5.sroa.4.0.copyload.i.i = load i8, ptr %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.i, align 4, !noalias !26
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %layout.sroa.7.i.i, ptr noundef nonnull align 1 dereferenceable(19) %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.i, i32 19, i1 false), !noalias !34
  %_15.sroa.6.0.copyload.i.i = load i32, ptr %_15.sroa.6.0._3.sroa_idx.i.i, align 8, !noalias !26
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i.i), !noalias !26
  %.not.i.i = icmp eq i64 %0, 2
  br i1 %.not.i.i, label %bb15.thread.i, label %bb17.i

bb15.thread.i:                                    ; preds = %bb8.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.sroa.7.i)
  br label %bb6.i

bb14.i:                                           ; preds = %bb3.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i.i), !noalias !26
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.sroa.7.i)
  br label %bb6

bb17.i:                                           ; preds = %bb8.i.i
  %layout.sroa.3.sroa.2.0.insert.ext.i.i = zext i24 %_15.sroa.5.sroa.0.0.copyload.i.i to i32
  %layout.sroa.3.sroa.2.0.insert.shift.i.i = shl nuw i32 %layout.sroa.3.sroa.2.0.insert.ext.i.i, 8
  %layout.sroa.3.sroa.0.0.insert.ext.i.i = zext i8 %_16.i.i to i32
  %layout.sroa.3.sroa.0.0.insert.insert.i.i = or disjoint i32 %layout.sroa.3.sroa.2.0.insert.shift.i.i, %layout.sroa.3.sroa.0.0.insert.ext.i.i
  store i32 %layout.sroa.3.sroa.0.0.insert.insert.i.i, ptr %_6.sroa.7.i, align 8, !alias.scope !23, !noalias !35
  store i8 %_15.sroa.5.sroa.4.0.copyload.i.i, ptr %_6.sroa.7.i.4.i.4.i.4._0.sroa_idx, align 4, !alias.scope !23, !noalias !35
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(3) %_6.sroa.7.13._0.sroa_idx.i, ptr noundef nonnull align 1 dereferenceable(3) %layout.sroa.7.i.i, i32 3, i1 false), !noalias !34
  %_6.sroa.7.i.1._6.sroa.7.i.1._6.sroa.7.i.1._6.sroa.7.1._6.sroa.7.1._6.sroa.7.9._20.sroa.5.sroa.0.0.copyload.i = load i56, ptr %_6.sroa.7.i.1.i.1.i.1._6.sroa_idx, align 1, !noalias !34
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.sroa.7.i)
  %info.sroa.3.sroa.2.0.insert.ext.i = zext i56 %_6.sroa.7.i.1._6.sroa.7.i.1._6.sroa.7.i.1._6.sroa.7.1._6.sroa.7.1._6.sroa.7.9._20.sroa.5.sroa.0.0.copyload.i to i64
  %info.sroa.3.sroa.2.0.insert.shift.i = shl nuw i64 %info.sroa.3.sroa.2.0.insert.ext.i, 8
  %info.sroa.3.sroa.0.0.insert.ext.i = zext i8 %_16.i.i to i64
  %info.sroa.3.sroa.0.0.insert.insert.i = or disjoint i64 %info.sroa.3.sroa.2.0.insert.shift.i, %info.sroa.3.sroa.0.0.insert.ext.i
  %2 = trunc nuw i64 %0 to i1
  br i1 %2, label %bb6.i, label %bb8.i

bb6.i:                                            ; preds = %bb17.i, %bb15.thread.i
  %_9.sroa.7.0.i = phi i64 [ %info.sroa.3.sroa.0.0.insert.insert.i, %bb17.i ], [ 0, %bb15.thread.i ]
  %_28.0.i = add i64 %_9.sroa.7.0.i, %total.sroa.0.032.i
  %_28.1.i = icmp ult i64 %_28.0.i, %total.sroa.0.032.i
  br i1 %_28.1.i, label %bb6, label %bb8.i, !prof !36

bb8.i:                                            ; preds = %bb6.i, %bb17.i
  %total.sroa.0.1.i = phi i64 [ %total.sroa.0.032.i, %bb17.i ], [ %_28.0.i, %bb6.i ]
  %known.sroa.0.1.off0.i = phi i1 [ false, %bb17.i ], [ %known.sroa.0.0.off033.i, %bb6.i ]
  %_38.i = icmp ugt i32 %_15.sroa.6.0.copyload.i.i, %input.sroa.6.034.i
  br i1 %_38.i, label %bb21.i, label %bb22.i, !prof !36

bb22.i:                                           ; preds = %bb8.i
  %_41.i = sub nuw nsw i32 %input.sroa.6.034.i, %_15.sroa.6.0.copyload.i.i
  %_45.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.035.i, i32 %_15.sroa.6.0.copyload.i.i
  %_3.i = icmp eq i32 %_41.i, 0
  br i1 %_3.i, label %bb7, label %bb3.i

bb21.i:                                           ; preds = %bb8.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_15.sroa.6.0.copyload.i.i, i32 noundef %input.sroa.6.034.i, i32 noundef %input.sroa.6.034.i, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_5e6a025b48b26689566b9e005edba7db) #10, !noalias !34
  unreachable

bb6:                                              ; preds = %bb6.i, %bb14.i
  %_4.sroa.7.0.ph.off0 = phi i8 [ %_16.i.i, %bb14.i ], [ 10, %bb6.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %layout.sroa.7.i.i)
  br label %bb4

bb7:                                              ; preds = %bb22.i
  %..i = zext i1 %known.sroa.0.1.off0.i to i64
  call void @llvm.lifetime.end.p0(ptr nonnull %layout.sroa.7.i.i)
  %_15.sroa.4.0._3.sroa_idx.i.i6 = getelementptr inbounds nuw i8, ptr %_3.i.i4, i32 8
  %_15.sroa.5.0._3.sroa_idx.i.i7 = getelementptr inbounds nuw i8, ptr %_3.i.i4, i32 9
  %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.i8 = getelementptr inbounds nuw i8, ptr %_3.i.i4, i32 12
  %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.i9 = getelementptr inbounds nuw i8, ptr %_3.i.i4, i32 13
  %layout.sroa.7.i.sroa.4.0._15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i.i4, i32 16
  %_15.sroa.6.0._3.sroa_idx.i.i10 = getelementptr inbounds nuw i8, ptr %_3.i.i4, i32 32
  %_15.sroa.8.0._3.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %_3.i.i4, i32 40
  br label %bb3.i11

bb3.i11:                                          ; preds = %bb18.i18, %bb7
  %input.sroa.0.049.i = phi ptr [ %input.0, %bb7 ], [ %_49.i, %bb18.i18 ]
  %input.sroa.6.048.i = phi i32 [ %input.1, %bb7 ], [ %_45.i19, %bb18.i18 ]
  %total.sroa.0.047.i = phi i64 [ 0, %bb7 ], [ %_32.0.i, %bb18.i18 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.i.i4), !noalias !37
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCs9AbywTnvkjY_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_3.i.i4, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.049.i, i32 noundef range(i32 0, -2147483648) %input.sroa.6.048.i) #9, !noalias !44
  %3 = load i64, ptr %_3.i.i4, align 8, !range !32, !noalias !37, !noundef !33
  %4 = icmp eq i64 %3, -1
  %_16.i.i12 = load i8, ptr %_15.sroa.4.0._3.sroa_idx.i.i6, align 8, !noalias !37
  br i1 %4, label %bb10.i, label %bb8.i.i13

bb8.i.i13:                                        ; preds = %bb3.i11
  %_15.sroa.5.sroa.0.0.copyload.i.i14 = load i24, ptr %_15.sroa.5.0._3.sroa_idx.i.i7, align 1, !noalias !37
  %_15.sroa.5.sroa.4.0.copyload.i.i15 = load i8, ptr %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.i8, align 4, !noalias !37
  %layout.sroa.7.i.sroa.0.0.copyload.i = load i24, ptr %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.i9, align 1, !noalias !37
  %layout.sroa.7.i.sroa.4.0.copyload.i = load i64, ptr %layout.sroa.7.i.sroa.4.0._15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.sroa_idx.i, align 8, !noalias !37
  %_15.sroa.6.0.copyload.i.i16 = load i32, ptr %_15.sroa.6.0._3.sroa_idx.i.i10, align 8, !noalias !37
  %_15.sroa.8.0.copyload.i.i = load i32, ptr %_15.sroa.8.0._3.sroa_idx.i.i, align 8, !noalias !37
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i.i4), !noalias !37
  %.not.i.i17 = icmp eq i64 %3, 2
  br i1 %.not.i.i17, label %bb13.i, label %bb11.i

bb10.i:                                           ; preds = %bb3.i11
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i.i4), !noalias !37
  br label %bb4

bb11.i:                                           ; preds = %bb8.i.i13
  %trunc.i.i = trunc nuw nsw i64 %3 to i2
  %cond.i = icmp eq i2 %trunc.i.i, 0
  br i1 %cond.i, label %bb11.i.i, label %bb5.i14.i

bb5.i14.i:                                        ; preds = %bb11.i
  %.sroa.4.sroa.6.0.insert.ext.i = zext i24 %layout.sroa.7.i.sroa.0.0.copyload.i to i64
  %.sroa.4.sroa.6.0.insert.shift.i = shl nuw i64 %.sroa.4.sroa.6.0.insert.ext.i, 40
  %.sroa.4.sroa.5.0.insert.ext.i = zext i8 %_15.sroa.5.sroa.4.0.copyload.i.i15 to i64
  %.sroa.4.sroa.5.0.insert.shift.i = shl nuw nsw i64 %.sroa.4.sroa.5.0.insert.ext.i, 32
  %.sroa.4.sroa.4.0.insert.ext.i = zext i24 %_15.sroa.5.sroa.0.0.copyload.i.i14 to i64
  %.sroa.4.sroa.4.0.insert.shift.i = shl nuw nsw i64 %.sroa.4.sroa.4.0.insert.ext.i, 8
  %.sroa.4.sroa.0.0.insert.ext.i = zext i8 %_16.i.i12 to i64
  %.sroa.4.sroa.5.0.insert.insert.i = or disjoint i64 %.sroa.4.sroa.4.0.insert.shift.i, %.sroa.4.sroa.0.0.insert.ext.i
  %.sroa.4.sroa.4.0.insert.insert.i = or disjoint i64 %.sroa.4.sroa.5.0.insert.insert.i, %.sroa.4.sroa.5.0.insert.shift.i
  %.sroa.4.sroa.0.0.insert.insert.i = or disjoint i64 %.sroa.4.sroa.4.0.insert.insert.i, %.sroa.4.sroa.6.0.insert.shift.i
  br label %bb13.i

bb11.i.i:                                         ; preds = %bb11.i
  %_11.i.i = tail call i64 @llvm.umin.i64(i64 %layout.sroa.7.i.sroa.4.0.copyload.i, i64 131072)
  %_12.i.i = zext i32 %_15.sroa.8.0.copyload.i.i to i64
  %5 = mul nuw nsw i64 %_11.i.i, %_12.i.i
  br label %bb13.i

bb13.i:                                           ; preds = %bb11.i.i, %bb5.i14.i, %bb8.i.i13
  %.sink.i.i = phi i64 [ %5, %bb11.i.i ], [ %.sroa.4.sroa.0.0.insert.insert.i, %bb5.i14.i ], [ 0, %bb8.i.i13 ]
  %_32.0.i = add i64 %.sink.i.i, %total.sroa.0.047.i
  %_32.1.i = icmp ult i64 %_32.0.i, %total.sroa.0.047.i
  br i1 %_32.1.i, label %bb4, label %bb16.i, !prof !36

bb16.i:                                           ; preds = %bb13.i
  %_42.i = icmp ugt i32 %_15.sroa.6.0.copyload.i.i16, %input.sroa.6.048.i
  br i1 %_42.i, label %bb17.i21, label %bb18.i18, !prof !36

bb18.i18:                                         ; preds = %bb16.i
  %_45.i19 = sub nuw nsw i32 %input.sroa.6.048.i, %_15.sroa.6.0.copyload.i.i16
  %_49.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.049.i, i32 %_15.sroa.6.0.copyload.i.i16
  %_2.i = icmp eq i32 %_45.i19, 0
  br i1 %_2.i, label %bb9, label %bb3.i11

bb17.i21:                                         ; preds = %bb16.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_15.sroa.6.0.copyload.i.i16, i32 noundef %input.sroa.6.048.i, i32 noundef %input.sroa.6.048.i, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_7435913fe0ee9560e916ffcef5e2af54) #10, !noalias !45
  unreachable

bb9:                                              ; preds = %bb18.i18, %bb7.thread
  %_4.sroa.0.034.ph = phi i64 [ 1, %bb7.thread ], [ %..i, %bb18.i18 ]
  %_4.sroa.7.032.ph = phi i64 [ 0, %bb7.thread ], [ %total.sroa.0.1.i, %bb18.i18 ]
  %_8.sroa.826.0.ph = phi i64 [ 0, %bb7.thread ], [ %_32.0.i, %bb18.i18 ]
  store i64 %_4.sroa.0.034.ph, ptr %_0, align 8
  %_2.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i64 %_4.sroa.7.032.ph, ptr %_2.sroa.5.0._0.sroa_idx, align 8
  %_2.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 16
  store i64 %_8.sroa.826.0.ph, ptr %_2.sroa.6.0._0.sroa_idx, align 8
  br label %bb5

bb5:                                              ; preds = %bb4, %bb9
  ret void

bb4:                                              ; preds = %bb13.i, %bb10.i, %bb6
  %_4.sroa.7.0.ph.off0.sink = phi i8 [ %_4.sroa.7.0.ph.off0, %bb6 ], [ %_16.i.i12, %bb10.i ], [ 10, %bb13.i ]
  %6 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_4.sroa.7.0.ph.off0.sink, ptr %6, align 8
  store i64 2, ptr %_0, align 8
  br label %bb5
}

; <zstdoxide::frame_layout::FrameLayout>::read
; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc void @_RNvMNtCs9AbywTnvkjY_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly align 8 captures(none) dereferenceable(48) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #1 !guid !46 {
start:
  %header.sroa.3 = alloca [19 x i8], align 1
  %header.sroa.5 = alloca [3 x i8], align 1
  %_30 = alloca [40 x i8], align 8
  %_21.i = icmp samesign ult i32 %input.1, 4
  br i1 %_21.i, label %bb28, label %bb29

bb28:                                             ; preds = %start
  %0 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %0, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb27

bb29:                                             ; preds = %start
  %word.sroa.0.i.0.copyload = load i32, ptr %input.0, align 1, !alias.scope !47, !noalias !51
  %1 = and i32 %word.sroa.0.i.0.copyload, -16
  %2 = icmp eq i32 %1, 407710288
  br i1 %2, label %bb3, label %bb4

bb3:                                              ; preds = %bb29
  %_21.i52 = icmp samesign ult i32 %input.1, 8
  br i1 %_21.i52, label %bb30, label %bb31

bb4:                                              ; preds = %bb29
  call void @llvm.lifetime.start.p0(ptr nonnull %_30)
; call <zstdoxide::frame::FrameHeader>::parse
  call void @_RNvMNtCs9AbywTnvkjY_9zstdoxide5frameNtB2_11FrameHeader5parse(ptr noalias nofree noundef nonnull sret([40 x i8]) align 8 captures(none) dereferenceable(40) %_30, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef %input.1) #9
  %3 = load i64, ptr %_30, align 8, !range !55, !noundef !33
  %4 = icmp eq i64 %3, 2
  %5 = getelementptr inbounds nuw i8, ptr %_30, i32 8
  %_121 = load i8, ptr %5, align 8
  br i1 %4, label %bb36, label %bb37

bb30:                                             ; preds = %bb3
  %6 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %6, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb27

bb31:                                             ; preds = %bb3
  %_35.i56 = getelementptr inbounds nuw i8, ptr %input.0, i32 4
  %word.sroa.0.i48.0.copyload = load i32, ptr %_35.i56, align 1, !alias.scope !56, !noalias !60
  %_96 = add nsw i32 %input.1, -8
  %_95 = icmp ult i32 %_96, %word.sroa.0.i48.0.copyload
  br i1 %_95, label %bb34, label %bb35

bb35:                                             ; preds = %bb31
  %_99 = add nuw nsw i32 %word.sroa.0.i48.0.copyload, 8
  %7 = trunc i32 %word.sroa.0.i.0.copyload to i8
  %_27 = and i8 %7, 15
  store i64 2, ptr %_0, align 8
  %_23.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 32
  store i32 %_99, ptr %_23.sroa.4.0._0.sroa_idx, align 8
  %_23.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 36
  store i32 %_99, ptr %_23.sroa.5.0._0.sroa_idx, align 4
  %_23.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 40
  store i32 0, ptr %_23.sroa.6.0._0.sroa_idx, align 8
  %_23.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 44
  store i8 %_27, ptr %_23.sroa.7.0._0.sroa_idx, align 4
  br label %bb27

bb34:                                             ; preds = %bb31
  %8 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %8, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb27

bb36:                                             ; preds = %bb4
  call void @llvm.lifetime.end.p0(ptr nonnull %_30)
  %9 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_121, ptr %9, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb27

bb37:                                             ; preds = %bb4
  %_120.sroa.5.0._30.sroa_idx = getelementptr inbounds nuw i8, ptr %_30, i32 9
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %header.sroa.3, ptr noundef nonnull align 1 dereferenceable(19) %_120.sroa.5.0._30.sroa_idx, i32 19, i1 false)
  %_120.sroa.5.sroa.4.0._120.sroa.5.0._30.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_30, i32 28
  %_120.sroa.5.sroa.4.0.copyload = load i8, ptr %_120.sroa.5.sroa.4.0._120.sroa.5.0._30.sroa_idx.sroa_idx, align 4
  %_120.sroa.5.sroa.5.0._120.sroa.5.0._30.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_30, i32 29
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(3) %header.sroa.5, ptr noundef nonnull align 1 dereferenceable(3) %_120.sroa.5.sroa.5.0._120.sroa.5.0._30.sroa_idx.sroa_idx, i32 3, i1 false)
  %_120.sroa.6.0._30.sroa_idx = getelementptr inbounds nuw i8, ptr %_30, i32 32
  %_120.sroa.6.0.copyload = load i32, ptr %_120.sroa.6.0._30.sroa_idx, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %_30)
  %_126 = icmp ugt i32 %_120.sroa.6.0.copyload, %input.1
  br i1 %_126, label %bb38, label %bb7

bb38:                                             ; preds = %bb37
  %10 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %10, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb27

bb7:                                              ; preds = %bb37, %bb48
  %cursor.sroa.16.0 = phi i32 [ %_167, %bb48 ], [ %_120.sroa.6.0.copyload, %bb37 ]
  %block_count.sroa.0.0 = phi i32 [ %_182.0, %bb48 ], [ 0, %bb37 ]
  %_22.i63 = sub i32 %input.1, %cursor.sroa.16.0
  %_21.i64 = icmp ult i32 %_22.i63, 3
  br i1 %_21.i64, label %bb40, label %bb41

bb40:                                             ; preds = %bb7
  %11 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %11, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb27

bb41:                                             ; preds = %bb7
  %_25.i66 = add i32 %cursor.sroa.16.0, 3
  %_35.i68 = getelementptr inbounds nuw i8, ptr %input.0, i32 %cursor.sroa.16.0
  %word.sroa.0.i60.0.copyload = load i24, ptr %_35.i68, align 1, !alias.scope !64, !noalias !68
  %word.sroa.0.i60.0.insert.ext = zext i24 %word.sroa.0.i60.0.copyload to i64
  %_43 = lshr i64 %word.sroa.0.i60.0.insert.ext, 1
  %trunc = trunc i64 %_43 to i2
  switch i2 %trunc, label %bb41.unreachabledefault [
    i2 0, label %bb43
    i2 -2, label %bb43
    i2 1, label %bb12
    i2 -1, label %bb9
  ]

bb41.unreachabledefault:                          ; preds = %bb41
  unreachable

bb9:                                              ; preds = %bb41
  %12 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 4, ptr %12, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb27

bb43:                                             ; preds = %bb41, %bb41
  %_47 = lshr i64 %word.sroa.0.i60.0.insert.ext, 3
  %_155 = trunc nuw nsw i64 %_47 to i32
  br label %bb12

bb12:                                             ; preds = %bb41, %bb43
  %payload_size.sroa.0.0 = phi i32 [ %_155, %bb43 ], [ 1, %bb41 ]
  %_164 = sub i32 %input.1, %_25.i66
  %_163 = icmp ugt i32 %payload_size.sroa.0.0, %_164
  br i1 %_163, label %bb44, label %bb45

bb45:                                             ; preds = %bb12
  %_182.1 = icmp eq i32 %block_count.sroa.0.0, -1
  br i1 %_182.1, label %bb46, label %bb48, !prof !36

bb44:                                             ; preds = %bb12
  %13 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %13, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb27

bb48:                                             ; preds = %bb45
  %_182.0 = add nuw i32 %block_count.sroa.0.0, 1
  %_167 = add i32 %payload_size.sroa.0.0, %_25.i66
  %_59 = and i64 %word.sroa.0.i60.0.insert.ext, 1
  %14 = icmp eq i64 %_59, 0
  br i1 %14, label %bb7, label %bb13

bb46:                                             ; preds = %bb45
  %15 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 10, ptr %15, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb27

bb13:                                             ; preds = %bb48
  %16 = zext i8 %_120.sroa.5.sroa.4.0.copyload to i32
  %. = shl nuw nsw i32 %16, 2
  %_196 = sub i32 %input.1, %_167
  %_195 = icmp ugt i32 %., %_196
  br i1 %_195, label %bb49, label %bb53

bb49:                                             ; preds = %bb13
  %17 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %17, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb27

bb53:                                             ; preds = %bb13
  %_217.0 = add nuw i32 %_120.sroa.6.0.copyload, %.
  %_199 = add i32 %_167, %.
  %_67.sroa.0.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 9
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %_67.sroa.0.sroa.6.0._0.sroa_idx, ptr noundef nonnull align 1 dereferenceable(19) %header.sroa.3, i32 19, i1 false)
  %_67.sroa.0.sroa.8.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 29
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(3) %_67.sroa.0.sroa.8.0._0.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %header.sroa.5, i32 3, i1 false)
  store i64 %3, ptr %_0, align 8
  %_67.sroa.0.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_121, ptr %_67.sroa.0.sroa.5.0._0.sroa_idx, align 8
  %_67.sroa.0.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 28
  store i8 %_120.sroa.5.sroa.4.0.copyload, ptr %_67.sroa.0.sroa.7.0._0.sroa_idx, align 4
  %_67.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 32
  store i32 %_199, ptr %_67.sroa.5.0._0.sroa_idx, align 8
  %_67.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 36
  store i32 %_217.0, ptr %_67.sroa.6.0._0.sroa_idx, align 4
  %_67.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 40
  store i32 %_182.0, ptr %_67.sroa.7.0._0.sroa_idx, align 8
  %_67.sroa.8.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 44
  store i8 0, ptr %_67.sroa.8.0._0.sroa_idx, align 4
  br label %bb27

bb27:                                             ; preds = %bb36, %bb28, %bb30, %bb34, %bb35, %bb40, %bb9, %bb44, %bb46, %bb49, %bb38, %bb53
  ret void
}

; <zstdoxide::frame::FrameHeader>::parse
; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define dso_local void @_RNvMNtCs9AbywTnvkjY_9zstdoxide5frameNtB2_11FrameHeader5parse(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([40 x i8]) align 8 captures(none) dereferenceable(40) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #2 !guid !72 {
start:
  %word.sroa.0.i46 = alloca i64, align 8
  %word.sroa.0.i34 = alloca i64, align 8
  %_29 = alloca [16 x i8], align 4
  %_21.i = icmp samesign ult i32 %input.1, 4
  br i1 %_21.i, label %bb31, label %bb32

bb31:                                             ; preds = %start
  %0 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %0, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb32:                                             ; preds = %start
  %word.sroa.0.i.0.copyload = load i32, ptr %input.0, align 1, !alias.scope !73, !noalias !77
  %1 = icmp eq i32 %word.sroa.0.i.0.copyload, -47205080
  br i1 %1, label %bb4, label %bb3

bb4:                                              ; preds = %bb32
  %_9.i = icmp eq i32 %input.1, 4
  br i1 %_9.i, label %bb33, label %bb34

bb3:                                              ; preds = %bb32
  %2 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 3, ptr %2, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb33:                                             ; preds = %bb4
  %3 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %3, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb34:                                             ; preds = %bb4
  %_23.i = getelementptr inbounds nuw i8, ptr %input.0, i32 4
  %_2.i = load i8, ptr %_23.i, align 1, !noalias !81, !noundef !33
  %_13 = and i8 %_2.i, 8
  %4 = icmp eq i8 %_13, 0
  br i1 %4, label %bb7, label %bb6

bb7:                                              ; preds = %bb34
  %_15 = and i8 %_2.i, 32
  %single_segment.not = icmp eq i8 %_15, 0
  br i1 %single_segment.not, label %bb8, label %bb10

bb6:                                              ; preds = %bb34
  %5 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 4, ptr %5, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb8:                                              ; preds = %bb7
  %_9.i26 = icmp eq i32 %input.1, 5
  br i1 %_9.i26, label %bb35, label %bb36

bb10:                                             ; preds = %bb36, %bb7
  %cursor.sroa.15.0 = phi i32 [ 6, %bb36 ], [ 5, %bb7 ]
  %window_size.sroa.0.0 = phi i64 [ %12, %bb36 ], [ 0, %bb7 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_29)
  store i32 0, ptr %_29, align 4
  %6 = getelementptr inbounds nuw i8, ptr %_29, i32 4
  store i32 1, ptr %6, align 4
  %7 = getelementptr inbounds nuw i8, ptr %_29, i32 8
  store i32 2, ptr %7, align 4
  %8 = getelementptr inbounds nuw i8, ptr %_29, i32 12
  store i32 4, ptr %8, align 4
  %_31 = and i8 %_2.i, 3
  %_30 = zext nneg i8 %_31 to i32
  %9 = getelementptr inbounds nuw [4 x i8], ptr %_29, i32 %_30
  %dictionary_bytes = load i32, ptr %9, align 4, !noundef !33
  call void @llvm.lifetime.end.p0(ptr nonnull %_29)
  %_3.i = icmp ugt i32 %dictionary_bytes, 8
  br i1 %_3.i, label %bb37, label %bb2.i

bb2.i:                                            ; preds = %bb10
  call void @llvm.lifetime.start.p0(ptr nonnull %word.sroa.0.i34)
  store i64 0, ptr %word.sroa.0.i34, align 8, !noalias !84
  %_22.i37 = sub nsw i32 %input.1, %cursor.sroa.15.0
  %_21.i38 = icmp ugt i32 %dictionary_bytes, %_22.i37
  br i1 %_21.i38, label %bb8.i44, label %bb38

bb8.i44:                                          ; preds = %bb2.i
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i34)
  br label %bb37

bb35:                                             ; preds = %bb8
  %10 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %10, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb36:                                             ; preds = %bb8
  %_23.i30 = getelementptr inbounds nuw i8, ptr %input.0, i32 5
  %_2.i31 = load i8, ptr %_23.i30, align 1, !noalias !88, !noundef !33
  %_23 = lshr i8 %_2.i31, 3
  %_22 = add nuw nsw i8 %_23, 10
  %11 = zext nneg i8 %_22 to i64
  %base = shl nuw nsw i64 1, %11
  %_2523 = lshr i64 %base, 3
  %_27 = and i8 %_2.i31, 7
  %_26 = zext nneg i8 %_27 to i64
  %_24 = mul nuw nsw i64 %_2523, %_26
  %12 = add nuw nsw i64 %_24, %base
  br label %bb10

bb37:                                             ; preds = %bb8.i44, %bb10
  %_35.sroa.7.0.ph = phi i8 [ 4, %bb10 ], [ 2, %bb8.i44 ]
  %13 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_35.sroa.7.0.ph, ptr %13, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb38:                                             ; preds = %bb2.i
  %_25.i40 = add nuw nsw i32 %dictionary_bytes, %cursor.sroa.15.0
  %_35.i42 = getelementptr inbounds nuw i8, ptr %input.0, i32 %cursor.sroa.15.0
  call void @llvm.memcpy.p0.p0.i32(ptr nonnull align 8 %word.sroa.0.i34, ptr nonnull readonly align 1 %_35.i42, i32 range(i32 0, 9) %dictionary_bytes, i1 false), !alias.scope !91, !noalias !84
  %word.sroa.0.i34.0.word.sroa.0.i34.0.word.sroa.0.i34.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i43 = load i64, ptr %word.sroa.0.i34, align 8, !noalias !84
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i34)
  %dictionary_id = trunc i64 %word.sroa.0.i34.0.word.sroa.0.i34.0.word.sroa.0.i34.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i43 to i32
  %_40 = lshr i8 %_2.i, 6
  switch i8 %_40, label %default.unreachable90 [
    i8 0, label %bb16
    i8 1, label %bb15
    i8 2, label %bb14
    i8 3, label %bb18
  ]

default.unreachable90:                            ; preds = %bb38
  unreachable

bb16:                                             ; preds = %bb38
  br i1 %single_segment.not, label %bb23, label %bb18

bb15:                                             ; preds = %bb38
  br label %bb18

bb14:                                             ; preds = %bb38
  br label %bb18

bb18:                                             ; preds = %bb38, %bb15, %bb14, %bb16
  %14 = phi i1 [ false, %bb16 ], [ true, %bb15 ], [ false, %bb14 ], [ false, %bb38 ]
  %size_bytes.sroa.0.0 = phi i32 [ 1, %bb16 ], [ 2, %bb15 ], [ 4, %bb14 ], [ 8, %bb38 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %word.sroa.0.i46)
  store i64 0, ptr %word.sroa.0.i46, align 8, !noalias !95
  %_22.i51 = sub nsw i32 %input.1, %_25.i40
  %_21.i52 = icmp ugt i32 %size_bytes.sroa.0.0, %_22.i51
  br i1 %_21.i52, label %bb39, label %bb40

bb23:                                             ; preds = %bb40, %bb16
  %cursor.sroa.15.1 = phi i32 [ %_25.i40, %bb16 ], [ %_25.i54, %bb40 ]
  %content_size.sroa.0.0 = phi i64 [ 0, %bb16 ], [ 1, %bb40 ]
  %content_size.sroa.4.0 = phi i64 [ undef, %bb16 ], [ %_50.sroa.0.0, %bb40 ]
  %window_size.sroa.0.1 = phi i64 [ %window_size.sroa.0.0, %bb16 ], [ %spec.select, %bb40 ]
  %_59 = lshr i8 %_2.i, 2
  %_59.lobit = and i8 %_59, 1
  store i64 %content_size.sroa.0.0, ptr %_0, align 8
  %_56.sroa.0.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i64 %content_size.sroa.4.0, ptr %_56.sroa.0.sroa.4.0._0.sroa_idx, align 8
  %_56.sroa.0.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 16
  store i64 %window_size.sroa.0.1, ptr %_56.sroa.0.sroa.5.0._0.sroa_idx, align 8
  %_56.sroa.0.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 24
  store i32 %dictionary_id, ptr %_56.sroa.0.sroa.6.0._0.sroa_idx, align 8
  %_56.sroa.0.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 28
  store i8 %_59.lobit, ptr %_56.sroa.0.sroa.7.0._0.sroa_idx, align 4
  %_56.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 32
  store i32 %cursor.sroa.15.1, ptr %_56.sroa.4.0._0.sroa_idx, align 8
  br label %bb30

bb39:                                             ; preds = %bb18
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i46)
  %15 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 2, ptr %15, align 8
  store i64 2, ptr %_0, align 8
  br label %bb30

bb40:                                             ; preds = %bb18
  %_25.i54 = add nuw nsw i32 %size_bytes.sroa.0.0, %_25.i40
  %_35.i56 = getelementptr inbounds nuw i8, ptr %input.0, i32 %_25.i40
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 8 dereferenceable(1) %word.sroa.0.i46, ptr noundef nonnull readonly align 1 dereferenceable(1) %_35.i56, i32 range(i32 0, 9) %size_bytes.sroa.0.0, i1 false), !alias.scope !99, !noalias !95
  %word.sroa.0.i46.0.word.sroa.0.i46.0.word.sroa.0.i46.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i57 = load i64, ptr %word.sroa.0.i46, align 8, !noalias !95
  call void @llvm.lifetime.end.p0(ptr nonnull %word.sroa.0.i46)
  %16 = add i64 %word.sroa.0.i46.0.word.sroa.0.i46.0.word.sroa.0.i46.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i57, 256
  %_50.sroa.0.0 = select i1 %14, i64 %16, i64 %word.sroa.0.i46.0.word.sroa.0.i46.0.word.sroa.0.i46.0.word.sroa.0.0.word.sroa.0.0.word.sroa.0.0._13.sroa.0.0.copyload.i57
  %spec.select = select i1 %single_segment.not, i64 %window_size.sroa.0.0, i64 %_50.sroa.0.0
  br label %bb23

bb30:                                             ; preds = %bb37, %bb39, %bb35, %bb33, %bb6, %bb31, %bb3, %bb23
  ret void
}

; zstdoxide::frame_layout::frame_info
; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define dso_local void @_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([40 x i8]) align 8 captures(none) dereferenceable(40) initializes((0, 9)) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #1 !guid !103 {
start:
  %layout.sroa.7 = alloca [19 x i8], align 1
  %kind.sroa.5 = alloca [19 x i8], align 1
  %_3 = alloca [48 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_3)
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCs9AbywTnvkjY_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_3, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef %input.1) #9
  %0 = load i64, ptr %_3, align 8, !range !32, !noundef !33
  %1 = icmp eq i64 %0, -1
  %2 = getelementptr inbounds nuw i8, ptr %_3, i32 8
  %_16 = load i8, ptr %2, align 8
  br i1 %1, label %bb7, label %bb8

bb7:                                              ; preds = %start
  call void @llvm.lifetime.end.p0(ptr nonnull %_3)
  %3 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_16, ptr %3, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb8:                                              ; preds = %start
  %_15.sroa.5.0._3.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 9
  %_15.sroa.5.sroa.0.0.copyload = load i24, ptr %_15.sroa.5.0._3.sroa_idx, align 1
  %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 12
  %_15.sroa.5.sroa.4.0.copyload = load i8, ptr %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx, align 4
  %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 13
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %layout.sroa.7, ptr noundef nonnull align 1 dereferenceable(19) %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx, i32 19, i1 false)
  %_15.sroa.6.0._3.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 32
  %_15.sroa.6.0.copyload = load i32, ptr %_15.sroa.6.0._3.sroa_idx, align 8
  %_15.sroa.8.0._3.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 40
  %_15.sroa.8.0.copyload = load i32, ptr %_15.sroa.8.0._3.sroa_idx, align 8
  %_15.sroa.9.0._3.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 44
  %_15.sroa.9.0.copyload = load i8, ptr %_15.sroa.9.0._3.sroa_idx, align 4
  call void @llvm.lifetime.end.p0(ptr nonnull %_3)
  %.not = icmp eq i64 %0, 2
  br i1 %.not, label %bb3, label %bb4

bb4:                                              ; preds = %bb8
  %layout.sroa.3.sroa.2.0.insert.ext = zext i24 %_15.sroa.5.sroa.0.0.copyload to i32
  %layout.sroa.3.sroa.2.0.insert.shift = shl nuw i32 %layout.sroa.3.sroa.2.0.insert.ext, 8
  %layout.sroa.3.sroa.0.0.insert.ext = zext i8 %_16 to i32
  %layout.sroa.3.sroa.0.0.insert.insert = or disjoint i32 %layout.sroa.3.sroa.2.0.insert.shift, %layout.sroa.3.sroa.0.0.insert.ext
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %kind.sroa.5, ptr noundef nonnull align 1 dereferenceable(19) %layout.sroa.7, i32 19, i1 false)
  br label %bb5

bb3:                                              ; preds = %bb8
  %_10 = add i32 %_15.sroa.6.0.copyload, -8
  br label %bb5

bb5:                                              ; preds = %bb4, %bb3
  %kind.sroa.3.0 = phi i32 [ %layout.sroa.3.sroa.0.0.insert.insert, %bb4 ], [ %_10, %bb3 ]
  %kind.sroa.4.0 = phi i8 [ %_15.sroa.5.sroa.4.0.copyload, %bb4 ], [ %_15.sroa.9.0.copyload, %bb3 ]
  store i64 %0, ptr %_0, align 8
  %_13.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i32 %kind.sroa.3.0, ptr %_13.sroa.4.0._0.sroa_idx, align 8
  %_13.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 12
  store i8 %kind.sroa.4.0, ptr %_13.sroa.5.0._0.sroa_idx, align 4
  %_13.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 13
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %_13.sroa.6.0._0.sroa_idx, ptr noundef nonnull align 1 dereferenceable(19) %kind.sroa.5, i32 19, i1 false)
  %_13.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 32
  store i32 %_15.sroa.6.0.copyload, ptr %_13.sroa.7.0._0.sroa_idx, align 8
  %_13.sroa.8.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 36
  store i32 %_15.sroa.8.0.copyload, ptr %_13.sroa.8.0._0.sroa_idx, align 4
  br label %bb6

bb6:                                              ; preds = %bb7, %bb5
  ret void
}

; zstdoxide::frame_layout::decompressed_size
; Function Attrs: nounwind
define dso_local void @_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout17decompressed_size(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([16 x i8]) align 8 captures(none) dereferenceable(16) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %0, i32 noundef range(i32 0, -2147483648) %1) unnamed_addr #3 !guid !104 {
start:
  %layout.sroa.7.i = alloca [19 x i8], align 1
  %_3.i = alloca [48 x i8], align 8
  %_6.sroa.7 = alloca [8 x i8], align 8
  %_331 = icmp eq i32 %1, 0
  br i1 %_331, label %bb2.thread, label %bb3.lr.ph

bb3.lr.ph:                                        ; preds = %start
  %_15.sroa.4.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 8
  %_15.sroa.5.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 9
  %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 12
  %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 13
  %_15.sroa.6.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 32
  %_6.sroa.7.13._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_6.sroa.7, i32 5
  %_6.sroa.7.4._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_6.sroa.7, i32 4
  %_6.sroa.7.1._6.sroa_idx = getelementptr inbounds nuw i8, ptr %_6.sroa.7, i32 1
  br label %bb3

bb3:                                              ; preds = %bb3.lr.ph, %bb22
  %input.sroa.0.035 = phi ptr [ %0, %bb3.lr.ph ], [ %_45, %bb22 ]
  %input.sroa.6.034 = phi i32 [ %1, %bb3.lr.ph ], [ %_41, %bb22 ]
  %known.sroa.0.0.off033 = phi i1 [ true, %bb3.lr.ph ], [ %known.sroa.0.1.off0, %bb22 ]
  %total.sroa.0.032 = phi i64 [ 0, %bb3.lr.ph ], [ %total.sroa.0.1, %bb22 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_6.sroa.7)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !105)
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.i), !noalias !108
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCs9AbywTnvkjY_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_3.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.035, i32 noundef range(i32 0, -2147483648) %input.sroa.6.034) #9, !noalias !105
  %2 = load i64, ptr %_3.i, align 8, !range !32, !noalias !108, !noundef !33
  %3 = icmp eq i64 %2, -1
  %_16.i = load i8, ptr %_15.sroa.4.0._3.sroa_idx.i, align 8, !noalias !108
  br i1 %3, label %bb14, label %bb8.i

bb8.i:                                            ; preds = %bb3
  %_15.sroa.5.sroa.0.0.copyload.i = load i24, ptr %_15.sroa.5.0._3.sroa_idx.i, align 1, !noalias !108
  %_15.sroa.5.sroa.4.0.copyload.i = load i8, ptr %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i, align 4, !noalias !108
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(19) %layout.sroa.7.i, ptr noundef nonnull align 1 dereferenceable(19) %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i, i32 19, i1 false)
  %_15.sroa.6.0.copyload.i = load i32, ptr %_15.sroa.6.0._3.sroa_idx.i, align 8, !noalias !108
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i), !noalias !108
  %.not.i = icmp eq i64 %2, 2
  br i1 %.not.i, label %bb15.thread, label %bb17

bb15.thread:                                      ; preds = %bb8.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.sroa.7)
  br label %bb6

bb2:                                              ; preds = %bb22
  %. = zext i1 %known.sroa.0.1.off0 to i64
  br label %bb2.thread

bb2.thread:                                       ; preds = %bb2, %start
  %.52 = phi i64 [ 1, %start ], [ %., %bb2 ]
  %4 = phi i64 [ 0, %start ], [ %total.sroa.0.1, %bb2 ]
  store i64 %.52, ptr %_0, align 8
  %5 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i64 %4, ptr %5, align 8
  br label %bb10

bb14:                                             ; preds = %bb3
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i), !noalias !108
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.sroa.7)
  %6 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 %_16.i, ptr %6, align 8
  store i64 2, ptr %_0, align 8
  br label %bb10

bb17:                                             ; preds = %bb8.i
  %layout.sroa.3.sroa.2.0.insert.ext.i = zext i24 %_15.sroa.5.sroa.0.0.copyload.i to i32
  %layout.sroa.3.sroa.2.0.insert.shift.i = shl nuw i32 %layout.sroa.3.sroa.2.0.insert.ext.i, 8
  %layout.sroa.3.sroa.0.0.insert.ext.i = zext i8 %_16.i to i32
  %layout.sroa.3.sroa.0.0.insert.insert.i = or disjoint i32 %layout.sroa.3.sroa.2.0.insert.shift.i, %layout.sroa.3.sroa.0.0.insert.ext.i
  store i32 %layout.sroa.3.sroa.0.0.insert.insert.i, ptr %_6.sroa.7, align 8, !alias.scope !105, !noalias !110
  store i8 %_15.sroa.5.sroa.4.0.copyload.i, ptr %_6.sroa.7.4._0.sroa_idx, align 4, !alias.scope !105, !noalias !110
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(3) %_6.sroa.7.13._0.sroa_idx, ptr noundef nonnull align 1 dereferenceable(3) %layout.sroa.7.i, i32 3, i1 false)
  %_6.sroa.7.1._6.sroa.7.1._6.sroa.7.1._6.sroa.7.9._20.sroa.5.sroa.0.0.copyload = load i56, ptr %_6.sroa.7.1._6.sroa_idx, align 1
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.sroa.7)
  %info.sroa.3.sroa.2.0.insert.ext = zext i56 %_6.sroa.7.1._6.sroa.7.1._6.sroa.7.1._6.sroa.7.9._20.sroa.5.sroa.0.0.copyload to i64
  %info.sroa.3.sroa.2.0.insert.shift = shl nuw i64 %info.sroa.3.sroa.2.0.insert.ext, 8
  %info.sroa.3.sroa.0.0.insert.ext = zext i8 %_16.i to i64
  %info.sroa.3.sroa.0.0.insert.insert = or disjoint i64 %info.sroa.3.sroa.2.0.insert.shift, %info.sroa.3.sroa.0.0.insert.ext
  %7 = trunc nuw i64 %2 to i1
  br i1 %7, label %bb6, label %bb8

bb6:                                              ; preds = %bb15.thread, %bb17
  %_9.sroa.7.0 = phi i64 [ %info.sroa.3.sroa.0.0.insert.insert, %bb17 ], [ 0, %bb15.thread ]
  %_28.0 = add i64 %_9.sroa.7.0, %total.sroa.0.032
  %_28.1 = icmp ult i64 %_28.0, %total.sroa.0.032
  br i1 %_28.1, label %bb18, label %bb8, !prof !36

bb8:                                              ; preds = %bb6, %bb17
  %total.sroa.0.1 = phi i64 [ %total.sroa.0.032, %bb17 ], [ %_28.0, %bb6 ]
  %known.sroa.0.1.off0 = phi i1 [ false, %bb17 ], [ %known.sroa.0.0.off033, %bb6 ]
  %_38 = icmp ugt i32 %_15.sroa.6.0.copyload.i, %input.sroa.6.034
  br i1 %_38, label %bb21, label %bb22, !prof !36

bb18:                                             ; preds = %bb6
  %8 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i8 10, ptr %8, align 8
  store i64 2, ptr %_0, align 8
  br label %bb10

bb22:                                             ; preds = %bb8
  %_41 = sub nuw nsw i32 %input.sroa.6.034, %_15.sroa.6.0.copyload.i
  %_45 = getelementptr inbounds nuw i8, ptr %input.sroa.0.035, i32 %_15.sroa.6.0.copyload.i
  %_3 = icmp eq i32 %_41, 0
  br i1 %_3, label %bb2, label %bb3

bb21:                                             ; preds = %bb8
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_15.sroa.6.0.copyload.i, i32 noundef %input.sroa.6.034, i32 noundef %input.sroa.6.034, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_5e6a025b48b26689566b9e005edba7db) #10
  unreachable

bb10:                                             ; preds = %bb18, %bb14, %bb2.thread
  ret void
}

; zstdoxide::frame_layout::skippable_payload
; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define dso_local void @_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout17skippable_payload(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([12 x i8]) align 4 captures(none) dereferenceable(12) initializes((0, 1), (4, 8)) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #2 !guid !111 {
start:
  %_21.i = icmp samesign ult i32 %input.1, 4
  br i1 %_21.i, label %bb10, label %bb11

bb10:                                             ; preds = %start
  store i8 2, ptr %_0, align 4
  %0 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store ptr null, ptr %0, align 4
  br label %bb9

bb11:                                             ; preds = %start
  %word.sroa.0.i.0.copyload = load i32, ptr %input.0, align 1, !alias.scope !112, !noalias !116
  %1 = and i32 %word.sroa.0.i.0.copyload, -16
  %2 = icmp eq i32 %1, 407710288
  br i1 %2, label %bb4, label %bb3

bb4:                                              ; preds = %bb11
  %_21.i16 = icmp samesign ult i32 %input.1, 8
  br i1 %_21.i16, label %bb12, label %bb13

bb3:                                              ; preds = %bb11
  store i8 3, ptr %_0, align 4
  %3 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store ptr null, ptr %3, align 4
  br label %bb9

bb12:                                             ; preds = %bb4
  store i8 2, ptr %_0, align 4
  %4 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store ptr null, ptr %4, align 4
  br label %bb9

bb13:                                             ; preds = %bb4
  %_35.i20 = getelementptr inbounds nuw i8, ptr %input.0, i32 4
  %word.sroa.0.i12.0.copyload = load i32, ptr %_35.i20, align 1, !alias.scope !120, !noalias !124
  %_47 = add nsw i32 %input.1, -8
  %_46 = icmp ult i32 %_47, %word.sroa.0.i12.0.copyload
  br i1 %_46, label %bb16, label %bb17

bb17:                                             ; preds = %bb13
  %_60 = getelementptr inbounds nuw i8, ptr %input.0, i32 8
  %5 = trunc i32 %word.sroa.0.i.0.copyload to i8
  %_24 = and i8 %5, 15
  store i8 %_24, ptr %_0, align 4
  %_23.sroa.411.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store ptr %_60, ptr %_23.sroa.411.0._0.sroa_idx, align 4
  %_23.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i32 %word.sroa.0.i12.0.copyload, ptr %_23.sroa.5.0._0.sroa_idx, align 4
  br label %bb9

bb16:                                             ; preds = %bb13
  store i8 2, ptr %_0, align 4
  %6 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store ptr null, ptr %6, align 4
  br label %bb9

bb9:                                              ; preds = %bb3, %bb10, %bb16, %bb12, %bb17
  ret void
}

; zstdoxide::frame_layout::is_skippable_frame
; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define dso_local noundef zeroext i1 @_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout18is_skippable_frame(ptr noalias nofree noundef nonnull readonly captures(none) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #4 !guid !128 {
start:
  %_21.i = icmp samesign ugt i32 %input.1, 3
  br i1 %_21.i, label %bb9.i, label %_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian.exit

bb9.i:                                            ; preds = %start
  %word.sroa.0.i.0.copyload = load i32, ptr %input.0, align 1, !alias.scope !129, !noalias !133
  %0 = and i32 %word.sroa.0.i.0.copyload, -16
  %1 = icmp eq i32 %0, 407710288
  br label %_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian.exit

_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian.exit: ; preds = %start, %bb9.i
  %_0.sroa.0.0.off0 = phi i1 [ %1, %bb9.i ], [ false, %start ]
  ret i1 %_0.sroa.0.0.off0
}

; zstdoxide::frame_layout::decompression_bound
; Function Attrs: nounwind
define dso_local void @_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout19decompression_bound(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([16 x i8]) align 8 captures(none) dereferenceable(16) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %0, i32 noundef range(i32 0, -2147483648) %1) unnamed_addr #3 !guid !137 {
start:
  %_3.i = alloca [48 x i8], align 8
  %_246 = icmp eq i32 %1, 0
  br i1 %_246, label %bb2, label %bb3.lr.ph

bb3.lr.ph:                                        ; preds = %start
  %_15.sroa.4.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 8
  %_15.sroa.5.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 9
  %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 12
  %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 13
  %layout.sroa.7.i.sroa.4.0._15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_3.i, i32 16
  %_15.sroa.6.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 32
  %_15.sroa.8.0._3.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_3.i, i32 40
  br label %bb3

bb3:                                              ; preds = %bb3.lr.ph, %bb18
  %input.sroa.0.049 = phi ptr [ %0, %bb3.lr.ph ], [ %_49, %bb18 ]
  %input.sroa.6.048 = phi i32 [ %1, %bb3.lr.ph ], [ %_45, %bb18 ]
  %total.sroa.0.047 = phi i64 [ 0, %bb3.lr.ph ], [ %_32.0, %bb18 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.i), !noalias !138
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCs9AbywTnvkjY_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_3.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.049, i32 noundef range(i32 0, -2147483648) %input.sroa.6.048) #9, !noalias !142
  %2 = load i64, ptr %_3.i, align 8, !range !32, !noalias !138, !noundef !33
  %3 = icmp eq i64 %2, -1
  %_16.i = load i8, ptr %_15.sroa.4.0._3.sroa_idx.i, align 8, !noalias !138
  br i1 %3, label %bb10, label %bb8.i

bb8.i:                                            ; preds = %bb3
  %_15.sroa.5.sroa.0.0.copyload.i = load i24, ptr %_15.sroa.5.0._3.sroa_idx.i, align 1, !noalias !138
  %_15.sroa.5.sroa.4.0.copyload.i = load i8, ptr %_15.sroa.5.sroa.4.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i, align 4, !noalias !138
  %layout.sroa.7.i.sroa.0.0.copyload = load i24, ptr %_15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i, align 1, !noalias !138
  %layout.sroa.7.i.sroa.4.0.copyload = load i64, ptr %layout.sroa.7.i.sroa.4.0._15.sroa.5.sroa.5.0._15.sroa.5.0._3.sroa_idx.sroa_idx.i.sroa_idx, align 8, !noalias !138
  %_15.sroa.6.0.copyload.i = load i32, ptr %_15.sroa.6.0._3.sroa_idx.i, align 8, !noalias !138
  %_15.sroa.8.0.copyload.i = load i32, ptr %_15.sroa.8.0._3.sroa_idx.i, align 8, !noalias !138
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i), !noalias !138
  %.not.i = icmp eq i64 %2, 2
  br i1 %.not.i, label %bb13, label %bb11

bb2:                                              ; preds = %bb18, %start
  %total.sroa.0.0.lcssa = phi i64 [ 0, %start ], [ %_32.0, %bb18 ]
  %4 = getelementptr inbounds nuw i8, ptr %_0, i32 8
  store i64 %total.sroa.0.0.lcssa, ptr %4, align 8
  br label %bb9

bb10:                                             ; preds = %bb3
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.i), !noalias !138
  %5 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 %_16.i, ptr %5, align 1
  br label %bb9

bb11:                                             ; preds = %bb8.i
  %trunc.i = trunc nuw nsw i64 %2 to i2
  %cond = icmp eq i2 %trunc.i, 0
  br i1 %cond, label %bb11.i, label %bb5.i14

bb5.i14:                                          ; preds = %bb11
  %.sroa.4.sroa.6.0.insert.ext = zext i24 %layout.sroa.7.i.sroa.0.0.copyload to i64
  %.sroa.4.sroa.6.0.insert.shift = shl nuw i64 %.sroa.4.sroa.6.0.insert.ext, 40
  %.sroa.4.sroa.5.0.insert.ext = zext i8 %_15.sroa.5.sroa.4.0.copyload.i to i64
  %.sroa.4.sroa.5.0.insert.shift = shl nuw nsw i64 %.sroa.4.sroa.5.0.insert.ext, 32
  %.sroa.4.sroa.4.0.insert.ext = zext i24 %_15.sroa.5.sroa.0.0.copyload.i to i64
  %.sroa.4.sroa.4.0.insert.shift = shl nuw nsw i64 %.sroa.4.sroa.4.0.insert.ext, 8
  %.sroa.4.sroa.0.0.insert.ext = zext i8 %_16.i to i64
  %.sroa.4.sroa.5.0.insert.insert = or disjoint i64 %.sroa.4.sroa.4.0.insert.shift, %.sroa.4.sroa.0.0.insert.ext
  %.sroa.4.sroa.4.0.insert.insert = or disjoint i64 %.sroa.4.sroa.5.0.insert.insert, %.sroa.4.sroa.5.0.insert.shift
  %.sroa.4.sroa.0.0.insert.insert = or disjoint i64 %.sroa.4.sroa.4.0.insert.insert, %.sroa.4.sroa.6.0.insert.shift
  br label %bb13

bb11.i:                                           ; preds = %bb11
  %_11.i = tail call i64 @llvm.umin.i64(i64 %layout.sroa.7.i.sroa.4.0.copyload, i64 131072)
  %_12.i = zext i32 %_15.sroa.8.0.copyload.i to i64
  %6 = mul nuw nsw i64 %_11.i, %_12.i
  br label %bb13

bb13:                                             ; preds = %bb8.i, %bb11.i, %bb5.i14
  %.sink.i = phi i64 [ %6, %bb11.i ], [ %.sroa.4.sroa.0.0.insert.insert, %bb5.i14 ], [ 0, %bb8.i ]
  %_32.0 = add i64 %.sink.i, %total.sroa.0.047
  %_32.1 = icmp ult i64 %_32.0, %total.sroa.0.047
  br i1 %_32.1, label %bb7, label %bb16, !prof !36

bb16:                                             ; preds = %bb13
  %_42 = icmp ugt i32 %_15.sroa.6.0.copyload.i, %input.sroa.6.048
  br i1 %_42, label %bb17, label %bb18, !prof !36

bb18:                                             ; preds = %bb16
  %_45 = sub nuw nsw i32 %input.sroa.6.048, %_15.sroa.6.0.copyload.i
  %_49 = getelementptr inbounds nuw i8, ptr %input.sroa.0.049, i32 %_15.sroa.6.0.copyload.i
  %_2 = icmp eq i32 %_45, 0
  br i1 %_2, label %bb2, label %bb3

bb17:                                             ; preds = %bb16
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_15.sroa.6.0.copyload.i, i32 noundef %input.sroa.6.048, i32 noundef %input.sroa.6.048, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_7435913fe0ee9560e916ffcef5e2af54) #10
  unreachable

bb7:                                              ; preds = %bb13
  %7 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %7, align 1
  br label %bb9

bb9:                                              ; preds = %bb7, %bb10, %bb2
  %.sink = phi i8 [ 1, %bb7 ], [ 1, %bb10 ], [ 0, %bb2 ]
  store i8 %.sink, ptr %_0, align 8
  ret void
}

; zstdoxide::frame_layout::decompression_margin
; Function Attrs: nounwind
define dso_local void @_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout20decompression_margin(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([8 x i8]) align 4 captures(none) dereferenceable(8) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %0, i32 noundef range(i32 0, -2147483648) %1) unnamed_addr #3 !guid !143 {
start:
  %_6 = alloca [48 x i8], align 8
  %_331 = icmp eq i32 %1, 0
  br i1 %_331, label %bb11, label %bb3.lr.ph

bb3.lr.ph:                                        ; preds = %start
  %_24.sroa.5.sroa.4.0._24.sroa.5.0._6.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_6, i32 16
  %_24.sroa.6.0._6.sroa_idx = getelementptr inbounds nuw i8, ptr %_6, i32 32
  %_24.sroa.7.0._6.sroa_idx = getelementptr inbounds nuw i8, ptr %_6, i32 36
  %_24.sroa.7.sroa.4.0._24.sroa.7.0._6.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_6, i32 40
  br label %bb3

bb3:                                              ; preds = %bb3.lr.ph, %bb22
  %input.sroa.0.035 = phi ptr [ %0, %bb3.lr.ph ], [ %_47, %bb22 ]
  %input.sroa.6.034 = phi i32 [ %1, %bb3.lr.ph ], [ %_43, %bb22 ]
  %maximum_block.sroa.0.033 = phi i32 [ 0, %bb3.lr.ph ], [ %_15.sroa.0.0, %bb22 ]
  %overhead.sroa.0.032 = phi i32 [ 0, %bb3.lr.ph ], [ %_31.0.i, %bb22 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_6)
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCs9AbywTnvkjY_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_6, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.035, i32 noundef %input.sroa.6.034) #9
  %2 = load i64, ptr %_6, align 8, !range !32, !noundef !33
  %3 = icmp eq i64 %2, -1
  br i1 %3, label %bb12, label %bb13

bb2:                                              ; preds = %bb22
  %_20.0 = add i32 %_15.sroa.0.0, %_31.0.i
  %_20.1 = icmp ult i32 %_20.0, %_31.0.i
  br i1 %_20.1, label %bb9, label %bb11, !prof !144

bb12:                                             ; preds = %bb3
  %4 = getelementptr inbounds nuw i8, ptr %_6, i32 8
  %_25 = load i8, ptr %4, align 8, !range !145, !noundef !33
  call void @llvm.lifetime.end.p0(ptr nonnull %_6)
  %5 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 %_25, ptr %5, align 1
  br label %bb8

bb13:                                             ; preds = %bb3
  %_24.sroa.5.sroa.4.0.copyload = load i64, ptr %_24.sroa.5.sroa.4.0._24.sroa.5.0._6.sroa_idx.sroa_idx, align 8
  %_24.sroa.6.0.copyload = load i32, ptr %_24.sroa.6.0._6.sroa_idx, align 8
  %_24.sroa.7.sroa.0.0.copyload = load i32, ptr %_24.sroa.7.0._6.sroa_idx, align 4
  %_24.sroa.7.sroa.4.0.copyload = load i32, ptr %_24.sroa.7.sroa.4.0._24.sroa.7.0._6.sroa_idx.sroa_idx, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %_6)
  %6 = tail call { i32, i1 } @llvm.umul.with.overflow.i32(i32 %_24.sroa.7.sroa.4.0.copyload, i32 3)
  %_14.0.i = extractvalue { i32, i1 } %6, 0
  %_14.1.i = extractvalue { i32, i1 } %6, 1
  br i1 %_14.1.i, label %bb14, label %bb4.i, !prof !36

bb4.i:                                            ; preds = %bb13
  %_23.0.i = add i32 %_24.sroa.7.sroa.0.0.copyload, %overhead.sroa.0.032
  %_23.1.i = icmp ult i32 %_23.0.i, %overhead.sroa.0.032
  br i1 %_23.1.i, label %bb14, label %bb7.i, !prof !36

bb7.i:                                            ; preds = %bb4.i
  %_31.0.i = add i32 %_14.0.i, %_23.0.i
  %_31.1.i = icmp ult i32 %_31.0.i, %_23.0.i
  br i1 %_31.1.i, label %bb14, label %bb15, !prof !36

bb14:                                             ; preds = %bb4.i, %bb7.i, %bb13
  %7 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %7, align 1
  br label %bb8

bb15:                                             ; preds = %bb7.i
  %.not = icmp eq i64 %2, 2
  br i1 %.not, label %bb16, label %bb18

bb18:                                             ; preds = %bb15
  %_35 = tail call i64 @llvm.umin.i64(i64 %_24.sroa.5.sroa.4.0.copyload, i64 131072)
  %8 = trunc nuw nsw i64 %_35 to i32
  %9 = tail call i32 @llvm.umax.i32(i32 %maximum_block.sroa.0.033, i32 %8)
  br label %bb16

bb16:                                             ; preds = %bb15, %bb18
  %_15.sroa.0.0 = phi i32 [ %9, %bb18 ], [ %maximum_block.sroa.0.033, %bb15 ]
  %_40 = icmp ugt i32 %_24.sroa.6.0.copyload, %input.sroa.6.034
  br i1 %_40, label %bb21, label %bb22, !prof !36

bb22:                                             ; preds = %bb16
  %_43 = sub nuw nsw i32 %input.sroa.6.034, %_24.sroa.6.0.copyload
  %_47 = getelementptr inbounds nuw i8, ptr %input.sroa.0.035, i32 %_24.sroa.6.0.copyload
  %_3 = icmp eq i32 %_43, 0
  br i1 %_3, label %bb2, label %bb3

bb21:                                             ; preds = %bb16
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef %_24.sroa.6.0.copyload, i32 noundef %input.sroa.6.034, i32 noundef %input.sroa.6.034, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16) @alloc_048330390765a63cc99a694538bdf970) #10
  unreachable

bb8:                                              ; preds = %bb11, %bb9, %bb14, %bb12
  %.sink = phi i8 [ 1, %bb14 ], [ 1, %bb12 ], [ 0, %bb11 ], [ 1, %bb9 ]
  store i8 %.sink, ptr %_0, align 4
  ret void

bb11:                                             ; preds = %start, %bb2
  %_20.049 = phi i32 [ %_20.0, %bb2 ], [ 0, %start ]
  %10 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %_20.049, ptr %10, align 4
  br label %bb8

bb9:                                              ; preds = %bb2
  %11 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 10, ptr %11, align 1
  br label %bb8
}

; zstdoxide::frame_layout::frame_compressed_size
; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define dso_local void @_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout21frame_compressed_size(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([8 x i8]) align 4 captures(none) dereferenceable(8) initializes((0, 1)) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %input.0, i32 noundef range(i32 0, -2147483648) %input.1) unnamed_addr #1 !guid !146 {
start:
  %_3 = alloca [48 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_3)
; call <zstdoxide::frame_layout::FrameLayout>::read
  call fastcc void @_RNvMNtCs9AbywTnvkjY_9zstdoxide12frame_layoutNtB2_11FrameLayout4read(ptr noalias nofree noundef align 8 captures(none) dereferenceable(48) %_3, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.0, i32 noundef %input.1) #9
  %0 = load i64, ptr %_3, align 8, !range !32, !noundef !33
  %1 = icmp eq i64 %0, -1
  br i1 %1, label %bb4, label %bb5

bb4:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %_3, i32 8
  %_7 = load i8, ptr %2, align 8, !range !145, !noundef !33
  call void @llvm.lifetime.end.p0(ptr nonnull %_3)
  %3 = getelementptr inbounds nuw i8, ptr %_0, i32 1
  store i8 %_7, ptr %3, align 1
  br label %bb3

bb5:                                              ; preds = %start
  %_6.sroa.6.0._3.sroa_idx = getelementptr inbounds nuw i8, ptr %_3, i32 32
  %_6.sroa.6.0.copyload = load i32, ptr %_6.sroa.6.0._3.sroa_idx, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %_3)
  %4 = getelementptr inbounds nuw i8, ptr %_0, i32 4
  store i32 %_6.sroa.6.0.copyload, ptr %4, align 4
  br label %bb3

bb3:                                              ; preds = %bb4, %bb5
  %storemerge = phi i8 [ 0, %bb5 ], [ 1, %bb4 ]
  store i8 %storemerge, ptr %_0, align 4
  ret void
}

; <zstdoxide::error::Error as core::fmt::Display>::fmt
; Function Attrs: nounwind
define dso_local noundef zeroext i1 @_RNvXNtCs9AbywTnvkjY_9zstdoxide5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt(ptr noalias nofree noundef readonly captures(none) dereferenceable(1) %self, ptr noalias nofree noundef align 4 dereferenceable(16) %f) unnamed_addr #3 !guid !147 {
start:
  %0 = load i8, ptr %self, align 1, !range !145, !noundef !33
  %1 = zext nneg i8 %0 to i32
  %switch.gep = getelementptr inbounds nuw i8, ptr @switch.table._RNvXNtCs9AbywTnvkjY_9zstdoxide5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt, i32 %1
  %switch.load = load i8, ptr %switch.gep, align 1
  %switch.ext = zext i8 %switch.load to i32
  %2 = zext nneg i8 %0 to i32
  %switch.gep2 = getelementptr inbounds nuw [4 x i8], ptr @switch.table._RNvXNtCs9AbywTnvkjY_9zstdoxide5errorNtB2_5ErrorNtNtCsavDHSl9k1eG_4core3fmt7Display3fmt.3, i32 %2
  %switch.load3 = load ptr, ptr %switch.gep2, align 4
; call <core::fmt::Formatter>::write_str
  %_0 = tail call noundef zeroext i1 @_RNvMsa_NtCsavDHSl9k1eG_4core3fmtNtB5_9Formatter9write_str(ptr noalias nofree noundef nonnull align 4 dereferenceable(16) %f, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %switch.load3, i32 noundef %switch.ext) #9
  ret i1 %_0
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i32, i1 immarg) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #5

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i32, i1 } @llvm.umul.with.overflow.i32(i32, i32) #6

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nounwind
declare dso_local void @_RNvNtNtCsavDHSl9k1eG_4core5slice5index16slice_index_fail(i32 noundef, i32 noundef, i32 noundef, ptr noalias nofree noundef readonly align 4 captures(address, read_provenance) dereferenceable(16)) unnamed_addr #7

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #6

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #6

; <core::fmt::Formatter>::write_str
; Function Attrs: nounwind
declare dso_local noundef zeroext i1 @_RNvMsa_NtCsavDHSl9k1eG_4core3fmtNtB5_9Formatter9write_str(ptr noalias nofree noundef align 4 dereferenceable(16), ptr noalias nofree noundef nonnull readonly captures(address, read_provenance), i32 noundef) unnamed_addr #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #8

attributes #0 = { noinline nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #1 = { nofree norecurse nosync nounwind memory(argmem: readwrite) "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #2 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #3 = { nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #7 = { cold noinline noreturn nounwind "frame-pointer"="all" "target-cpu"="generic" "target-features"="+strict-align,+atomics-32" }
attributes #8 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #9 = { nounwind }
attributes #10 = { noreturn nounwind }

!llvm.module.flags = !{!20}
!llvm.ident = !{!21}

!0 = !{i64 5006767548799629787}
!1 = !{i64 -5509362093959075840}
!2 = !{i64 -3294839040618178404}
!3 = !{i64 -3457412876302297959}
!4 = !{i64 -3638608384182981063}
!5 = !{i64 -3604409757474543038}
!6 = !{i64 -4396383174709710655}
!7 = !{i64 -4758734958500830658}
!8 = !{i64 -783994065832915096}
!9 = !{i64 -2883065882483350059}
!10 = !{i64 403436118575671142}
!11 = !{i64 -9077209005486638430}
!12 = !{i64 3146012198505393387}
!13 = !{i64 5754046429042264590}
!14 = !{i64 -98581597798989335}
!15 = !{i64 -7716042470057411487}
!16 = !{i64 -4304195733517422753}
!17 = !{i64 2959222843853629196}
!18 = !{i64 4488622388194646185}
!19 = !{i64 -6319171256013718502}
!20 = !{i32 7, !"frame-pointer", i32 2}
!21 = !{!"rustc version 1.101.0-nightly (1d81eb4ad 2026-10-07)"}
!22 = !{i64 -5413763632284732670}
!23 = !{!24}
!24 = distinct !{!24, !25, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info: %_0"}
!25 = distinct !{!25, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info"}
!26 = !{!24, !27, !28, !30}
!27 = distinct !{!27, !25, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info: %input.0"}
!28 = distinct !{!28, !29, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout17decompressed_size: %_0"}
!29 = distinct !{!29, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout17decompressed_size"}
!30 = distinct !{!30, !29, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout17decompressed_size: argument 1"}
!31 = !{!24, !28}
!32 = !{i64 -1, i64 3}
!33 = !{}
!34 = !{!28, !30}
!35 = !{!27, !28, !30}
!36 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!37 = !{!38, !40, !41, !43}
!38 = distinct !{!38, !39, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info: %_0"}
!39 = distinct !{!39, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info"}
!40 = distinct !{!40, !39, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info: %input.0"}
!41 = distinct !{!41, !42, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout19decompression_bound: %_0"}
!42 = distinct !{!42, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout19decompression_bound"}
!43 = distinct !{!43, !42, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout19decompression_bound: argument 1"}
!44 = !{!38, !41}
!45 = !{!41, !43}
!46 = !{i64 -1073189526433645665}
!47 = !{!48, !50}
!48 = distinct !{!48, !49, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %dest.0"}
!49 = distinct !{!49, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide"}
!50 = distinct !{!50, !49, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %src.0"}
!51 = !{!52, !54}
!52 = distinct !{!52, !53, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!53 = distinct !{!53, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!54 = distinct !{!54, !53, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!55 = !{i64 0, i64 3}
!56 = !{!57, !59}
!57 = distinct !{!57, !58, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %dest.0"}
!58 = distinct !{!58, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide"}
!59 = distinct !{!59, !58, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %src.0"}
!60 = !{!61, !63}
!61 = distinct !{!61, !62, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!62 = distinct !{!62, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!63 = distinct !{!63, !62, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!64 = !{!65, !67}
!65 = distinct !{!65, !66, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %dest.0"}
!66 = distinct !{!66, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide"}
!67 = distinct !{!67, !66, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %src.0"}
!68 = !{!69, !71}
!69 = distinct !{!69, !70, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!70 = distinct !{!70, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!71 = distinct !{!71, !70, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!72 = !{i64 -2935127719126135188}
!73 = !{!74, !76}
!74 = distinct !{!74, !75, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %dest.0"}
!75 = distinct !{!75, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide"}
!76 = distinct !{!76, !75, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %src.0"}
!77 = !{!78, !80}
!78 = distinct !{!78, !79, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!79 = distinct !{!79, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!80 = distinct !{!80, !79, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!81 = !{!82}
!82 = distinct !{!82, !83, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor4byte: %self"}
!83 = distinct !{!83, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor4byte"}
!84 = !{!85, !87}
!85 = distinct !{!85, !86, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!86 = distinct !{!86, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!87 = distinct !{!87, !86, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!88 = !{!89}
!89 = distinct !{!89, !90, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor4byte: %self"}
!90 = distinct !{!90, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor4byte"}
!91 = !{!92, !94}
!92 = distinct !{!92, !93, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %dest.0"}
!93 = distinct !{!93, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide"}
!94 = distinct !{!94, !93, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %src.0"}
!95 = !{!96, !98}
!96 = distinct !{!96, !97, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!97 = distinct !{!97, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!98 = distinct !{!98, !97, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!99 = !{!100, !102}
!100 = distinct !{!100, !101, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %dest.0"}
!101 = distinct !{!101, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide"}
!102 = distinct !{!102, !101, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %src.0"}
!103 = !{i64 681536903161425357}
!104 = !{i64 -2183984027093705768}
!105 = !{!106}
!106 = distinct !{!106, !107, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info: %_0"}
!107 = distinct !{!107, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info"}
!108 = !{!106, !109}
!109 = distinct !{!109, !107, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info: %input.0"}
!110 = !{!109}
!111 = !{i64 4108665668569588173}
!112 = !{!113, !115}
!113 = distinct !{!113, !114, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %dest.0"}
!114 = distinct !{!114, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide"}
!115 = distinct !{!115, !114, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %src.0"}
!116 = !{!117, !119}
!117 = distinct !{!117, !118, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!118 = distinct !{!118, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!119 = distinct !{!119, !118, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!120 = !{!121, !123}
!121 = distinct !{!121, !122, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %dest.0"}
!122 = distinct !{!122, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide"}
!123 = distinct !{!123, !122, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %src.0"}
!124 = !{!125, !127}
!125 = distinct !{!125, !126, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!126 = distinct !{!126, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!127 = distinct !{!127, !126, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!128 = !{i64 3095051820899946762}
!129 = !{!130, !132}
!130 = distinct !{!130, !131, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %dest.0"}
!131 = distinct !{!131, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide"}
!132 = distinct !{!132, !131, !"_RINvNtCsavDHSl9k1eG_4core5slice20copy_from_slice_implhECs9AbywTnvkjY_9zstdoxide: %src.0"}
!133 = !{!134, !136}
!134 = distinct !{!134, !135, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %_0"}
!135 = distinct !{!135, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian"}
!136 = distinct !{!136, !135, !"_RNvMNtCs9AbywTnvkjY_9zstdoxide6cursorNtB2_10ByteCursor13little_endian: %self"}
!137 = !{i64 4393852089413798760}
!138 = !{!139, !141}
!139 = distinct !{!139, !140, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info: %_0"}
!140 = distinct !{!140, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info"}
!141 = distinct !{!141, !140, !"_RNvNtCs9AbywTnvkjY_9zstdoxide12frame_layout10frame_info: %input.0"}
!142 = !{!139}
!143 = !{i64 2707880422638926975}
!144 = !{!"branch_weights", !"expected", i32 2424395, i32 2145059253}
!145 = !{i8 0, i8 14}
!146 = !{i64 3862251456883578811}
!147 = !{i64 2318107798694718055}
