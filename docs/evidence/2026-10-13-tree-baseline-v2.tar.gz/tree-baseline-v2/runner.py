from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-tree-baseline-v2-checks');O.mkdir();env=os.environ.copy();env.update(CARGO_TARGET_DIR='/tmp/zstdoxide-tree-baseline-target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',PYTHONDONTWRITEBYTECODE='1')
paths=list((R/'src').rglob('*.rs'))+[R/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/reference_tree_defaults.rs','test-support/allocator/src/lib.rs','scripts/check_reference_tree_baseline.py','scripts/check_reference_tree_baseline_controls.py']]+list((R/'tests/fixtures/reference-tree-baseline').iterdir());source={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};rows=[]
def run(label,args,tests=None):
 log=O/(label+'.log');start=time.monotonic();print('START',label,flush=True)
 with log.open('wb') as f:p=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 b=log.read_bytes();r=dict(label=label,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(b).hexdigest());rows.append(r);print('END',label,p.returncode,flush=True)
 if tests is not None:
  counts=[tuple(map(int,x)) for x in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',b)];r['tests']=counts
  if counts!=[tests]:raise ValueError('test totals '+label)
 if p.returncode:raise ValueError(label)
for name,flags in [('safe',[]),('tree',['--features','unsafe-reference-tree']),('all',['--all-features']),('release-all',['--release','--all-features'])]:
 run('baseline-'+name,['cargo','test','--offline','--locked',*flags,'--test','reference_tree_defaults'],(7,0,0))
for name,flags in [('safe',[]),('all',['--all-features'])]:run('clippy-'+name,['cargo','clippy','--offline','--locked','--test','reference_tree_defaults',*flags,'--','-D','warnings'])
run('format',['cargo','fmt','--all','--','--check'])
for name,flags in [('normal',[]),('optimized',['-O'])]:run('controls-'+name,['python3',*flags,'scripts/check_reference_tree_baseline_controls.py'])
if source!={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in source}:raise ValueError('source changed')
(O/'evidence.json').write_text(json.dumps(dict(status='passed',commands=rows,source=source,tests=28,initial_failure='First controls attempted an unchanged zero frame offset; corrected to an actually different field value. Original harness and logs retained.',qualification='Additive pre-Optimal tree baseline tests, outside the already running immutable Module 16 full matrix. Complete frames and qualified allocator records across safe/tree/all/release-all; normal and optimized offline corruption controls.'),sort_keys=True,indent=2)+'\n')
