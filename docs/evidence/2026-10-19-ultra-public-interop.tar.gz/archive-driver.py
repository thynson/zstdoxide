"""Lossless content-addressed archive of all regular public-capture artifacts."""
import gzip,hashlib,io,json,os,tarfile
from pathlib import Path
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');CAP=Path('/private/tmp/zstdoxide-ultra-public-capture-1019');OUT=ROOT/'docs/evidence/2026-10-19-ultra-public-interop.tar.gz'
def need(v,m):
 if not v:raise ValueError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def fsha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
e=json.loads((CAP/'evidence.json').read_text());a=json.loads((CAP/'independent-audit.json').read_text());need(e['status']=='passed' and e['source_before']==e['source_after'] and a['status']=='passed' and a['capture_evidence_sha256']==fsha(CAP/'evidence.json'),'complete unchanged audited capture')
for mode in ['normal','optimized']:
 c=json.loads((CAP/('controls-'+mode+'-v3.json')).read_text());need(c['child_attempts']==0 and len(c['controls'])==56 and c['positive']==a['totals'],'complete adversarial controls')
files={};chunks={};expanded=0
for p in sorted(CAP.rglob('*')):
 if p.is_dir():continue
 need(p.is_file() and not p.is_symlink(),'regular capture artifact')
 n=p.relative_to(CAP).as_posix();length=p.stat().st_size;expanded+=length;need(length<=256<<20 and expanded<=5<<30,'bounded capture')
 ids=[];digest=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(65536),b''):
   h=sha(b);digest.update(b);ids.append(h)
   if h not in chunks:chunks[h]=b
 files[n]={'bytes':length,'sha256':digest.hexdigest(),'chunks':ids}
print('indexed',len(files),expanded,'unique',len(chunks),sum(map(len,chunks.values())),flush=True)
reconstruct='''import hashlib,json\nfrom pathlib import Path\nroot=Path(__file__).resolve().parent\nfiles=json.loads((root/'file-map.json').read_text())\nfor name,row in files.items():\n p=root/'capture'/name\n if p.is_absolute() and not p.resolve().is_relative_to((root/'capture').resolve()):raise ValueError('unsafe path')\n data=b''.join((root/'chunks'/h).read_bytes() for h in row['chunks'])\n if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('corrupt artifact')\n p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)\nprint('Reconstructed',len(files),'verified regular artifacts; inspect source before executing any captured program.')\n'''
metadata={'file-map.json':(json.dumps(files,sort_keys=True,indent=2)+'\n').encode(),'reconstruct.py':reconstruct.encode(),'archive-driver.py':Path(__file__).read_bytes()}
with OUT.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as z,tarfile.open(fileobj=z,mode='w|') as tar:
 for n,b in sorted(metadata.items())+[(f'chunks/{h}',b) for h,b in sorted(chunks.items())]:
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b))
# Independently read compressed members and reconstruct every source digest.
read={}
with tarfile.open(OUT,'r|gz') as tar:
 for m in tar:
  need(m.isfile() and m.name not in read,'unique regular archive member');read[m.name]=tar.extractfile(m).read()
need(set(read)==set(metadata)|{'chunks/'+h for h in chunks},'exact member inventory')
for n,b in metadata.items():need(read[n]==b,'metadata bytes')
for n,row in json.loads(read['file-map.json']).items():
 h=hashlib.sha256();size=0
 for c in row['chunks']:
  b=read['chunks/'+c];need(sha(b)==c,'chunk digest');h.update(b);size+=len(b)
 need(size==row['bytes'] and h.hexdigest()==row['sha256'] and fsha(CAP/n)==row['sha256'],'complete archived reconstruction')
report=dict(status='passed',archive=OUT.name,archive_bytes=OUT.stat().st_size,archive_sha256=fsha(OUT),regular_files=len(files),expanded_bytes=expanded,unique_chunks=len(chunks),unique_chunk_bytes=sum(map(len,chunks.values())),file_map_sha256=sha(metadata['file-map.json']),capture_evidence_sha256=fsha(CAP/'evidence.json'),totals=a['totals'],commands=len(e['commands']),controls_per_mode=56,omissions='None. Every regular capture artifact is reconstructed exactly; chunk deduplication changes storage only.',qualification='Complete normal/sanitized C and safe/all Rust bidirectional interoperability, independently audited with immutable predecessor frame comparisons. No C/Rust compression-byte identity claim.')
OUT.with_suffix('').with_suffix('.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n');print(json.dumps(report),flush=True)
