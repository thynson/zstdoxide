import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
files=json.loads((root/'file-map.json').read_text())
for name,row in files.items():
 p=root/'capture'/name
 if p.is_absolute() and not p.resolve().is_relative_to((root/'capture').resolve()):raise ValueError('unsafe path')
 data=b''.join((root/'chunks'/h).read_bytes() for h in row['chunks'])
 if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('corrupt artifact')
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
print('Reconstructed',len(files),'verified regular artifacts; inspect source before executing any captured program.')
