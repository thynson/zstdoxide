from pathlib import Path
import argparse,json,hashlib,datetime,subprocess,tarfile
p=argparse.ArgumentParser();p.add_argument('module',choices=['23','24','25','26']);a=p.parse_args();R=Path('/Users/lanxingcan/Workspace/zstdoxize');E=R/'docs/evidence';T=Path('/private/tmp');D=T/('module'+a.module+'-reconciliation');D.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
slugs={'23':'caller-output','24':'stable-output','25':'dictionary-output','26':'stable-dictionary-output'};slug=slugs[a.module]
patterns={'23':['2026-10-23-caller-output-*.json','2026-10-26-caller-output-*.json'],'24':['2026-10-26-stable-output-*.json'],'25':['2026-10-26-dictionary-output-*.json'],'26':['2026-10-26-stable-dictionary-output-*.json']}[a.module]
records={}
for pattern in patterns:
 for path in sorted(E.glob(pattern)):
  if path.name.endswith('-closure.json'):continue
  j=json.loads(path.read_text());assert j['status']=='passed',path
  if 'archive' in j:assert sha(E/j['archive'])==j['archive_sha256'],path
  records[path.name]=dict(sha256=sha(path),archive=j.get('archive'),archive_sha256=j.get('archive_sha256'))
required=['feature-matrix','benchmarks','native','platform','public-api']+(['isolated-full'] if a.module=='23' else ['storage','engine','streaming-corpus' if a.module=='24' else 'corpus'])
for label in required:assert any(n.endswith('-'+label+'.json') for n in records),(label,records)
production={str(p.relative_to(R)):sha(p) for p in (R/'src').rglob('*.rs')}
bench=json.loads((E/('2026-10-26-'+slug+'-benchmarks.json')).read_text())
benchmark_production=({n:h for n,h in bench['build']['source'].items() if n.startswith('src/') and n.endswith('.rs')} if a.module=='23' else bench['build']['production_source'])
assert benchmark_production==production

matrix=json.loads((E/('2026-10-26-'+slug+'-feature-matrix.json')).read_text())
for n,h in production.items():assert matrix['complete_source' if a.module=='23' else 'source'][n]==h,n
platform=json.loads(next(E.glob('*-'+slug+'-platform.json')).read_text())
for n,h in production.items():assert platform['source'][n]==h,('platform',n)
native=json.loads(next(E.glob('*-'+slug+'-native.json')).read_text())
if a.module in ['25','26']:
 for n,h in production.items():assert native['rust']['source'][n]==h,('native Rust replay',n)
elif a.module=='23':
 recorded={n:h for n,h in native['source'].items() if n.startswith('src/') and n.endswith('.rs')}
 assert set(production)-set(recorded)=={'src/parameters/presets.rs'}
 for n,h in recorded.items():assert production[n]==h,('native Rust replay',n)
 # Retain the original shallow native manifest honestly. The omitted file is
 # an encoder parameter table, not a caller-output decoder implementation.
 # Other retained campaigns bind it explicitly; do not invent a native hash.
 name='src/parameters/presets.rs'
 isolated=json.loads((E/'2026-10-26-caller-output-isolated-full.json').read_text())
 assert isolated['complete_source'][name]==production[name]
 with tarfile.open(E/bench['archive'],'r:gz') as benchmark_archive:
  original_build=benchmark_archive.extractfile('evidence.json').read()
 assert json.loads(original_build)==bench['build']
 assert hashlib.sha256(original_build).hexdigest()==bench['repeat_build']['source_evidence_sha256']
 source_audit=dict(status='passed-with-explicit-legacy-omission',path=name,current_sha256=production[name],matrix_sha256=matrix['complete_source'][name],isolated_full_sha256=isolated['complete_source'][name],benchmark_primary_sha256=bench['build']['source'][name],benchmark_repeat_source_evidence_sha256=bench['repeat_build']['source_evidence_sha256'],platform_sha256=platform['source'][name],legacy_native_recorded_production_files=len(recorded),qualification='The historical native receipt used a shallow src glob and did not hash the nested encoder parameter presets. All recorded decoder/native source hashes still match. Complete matrix and benchmark snapshots plus platform evidence explicitly bind this file. No missing native hash or fresh native execution is asserted; original evidence remains unchanged.')
 (D/'recursive-source-inventory-audit.json').write_text(json.dumps(source_audit,indent=2)+'\n')
else:
 public=json.loads((E/'2026-10-26-stable-output-public-api.json').read_text())
 with tarfile.open(E/public['archive'],'r:gz') as tar:
  original=tar.extractfile('campaign/public.json').read()
 assert hashlib.sha256(original).hexdigest()==native['public_evidence_sha256']
 for n,h in production.items():assert json.loads(original)['source'][n]==h,('native public replay',n)
if a.module!='23':
 corpus=json.loads((E/('2026-10-26-'+slug+('-streaming-corpus' if a.module=='24' else '-corpus')+'.json')).read_text())
 for n,h in production.items():assert corpus['focused']['source'][n]==h,('corpus',n)

# Final inventories may change only metadata after frozen full-suite checks.
for n,h in matrix['source'].items():
 if n!='tests/upstream/manifest.json':assert sha(R/n)==h,('final matrix',n)
if a.module=='24':
 fuzz=json.loads((E/'2026-10-26-stable-output-streaming-corpus.json').read_text())
 assert sha(R/'tests/stable_stream_fuzz.rs')==fuzz['focused']['source']['tests/stable_stream_fuzz.rs']
if a.module!='23':
 inv=json.loads((D/'evidence.json').read_text());assert inv['status']=='passed' and sha(R/'tests/upstream/manifest.json')==inv['final_manifest_sha256']
previous={'23':'2026-10-23-ultra2-retained-closure.json','24':'2026-10-26-caller-output-closure.json','25':'2026-10-26-stable-output-closure.json','26':'2026-10-26-dictionary-output-closure.json'}[a.module]
if previous:assert json.loads((E/previous).read_text())['status']=='passed'
args=['python3','scripts/audit_upstream_tests.py','--upstream',str(T/'module24-preparation/zstd-f8745da6ff1ad1e7bab384bd1f9d742439278e99')]
with (D/'integrated-inventory.log').open('xb') as f:q=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
assert q.returncode==0
out=E/('2026-10-26-'+slug+'-closure.json');assert not out.exists()
result=dict(status='passed',module=int(a.module),recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_source=production,verified_evidence=records,predecessor_closure=previous,predecessor_closure_sha256=sha(E/previous) if previous else None,integrated_manifest_sha256=sha(R/'tests/upstream/manifest.json'),inventory_log_sha256=sha(D/'integrated-inventory.log'),driver_sha256=sha(Path(__file__)),qualification='This bounded module has completed focused, full safe/isolated/all, no_std, Clippy, native/corpus/platform and measured primary/repeat gates. Every current-module archive/report pair above is rehashed; earlier historical implementation snapshots remain separate and are not relabelled as final-source runs. Current production matches final matrix, platform and timed executable snapshots. Module23 additionally records a historical native shallow-source-manifest omission for nested encoder presets; no omitted native hash is inferred. Inventory-only reconciliation leaves codec/test source unchanged except separately qualified Module24 additive fuzz. Complete upstream migration and unsupported contracts remain open; no universal unsafe speedup is claimed.')
archive=out.with_suffix('.tar.gz')
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 tar.add(__file__,arcname='reconcile-closure.py')
 for item in sorted(D.iterdir()):
  if item.is_file():tar.add(item,arcname='reconciliation/'+item.name)
result.update(archive=archive.name,archive_sha256=sha(archive),integration_commit_before_closure=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip())
out.write_text(json.dumps(result,indent=2)+'\n');print(out)
