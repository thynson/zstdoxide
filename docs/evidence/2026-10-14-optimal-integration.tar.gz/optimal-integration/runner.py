from pathlib import Path
import hashlib,json,os,subprocess,tomllib
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-optimal-integration-checks');O.mkdir()
env=dict(os.environ,CARGO_TARGET_DIR='/tmp/zstdoxide-optimal-integration-target',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',PYTHONDONTWRITEBYTECODE='1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source():return {str(p.relative_to(R)):sha(p) for d in ['src','tests','scripts'] for p in sorted((R/d).rglob('*')) if p.is_file() and '__pycache__' not in str(p)} | {n:sha(R/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']}
before=source();rows=[];commands=[('format',['cargo','fmt','--all','--','--check'],None)]
for label,flags in [('safe',[]),('frequency',['--features','unsafe-optimal-frequencies']),('all',['--all-features'])]:
 commands.append(('frequency-'+label,['cargo','test','--offline','--locked','--lib','optimal_frequencies::tests',*flags],8))
for label,flags in [('safe',[]),('all',['--all-features'])]:
 commands.append(('public-'+label,['cargo','test','--offline','--locked','--test','reference_tree','--test','reference_tree_defaults','--test','upstream_reference_fast',*flags],27))
 commands.append(('fixtures-'+label,['cargo','test','--offline','--locked','--test','reference_optimal_match_fixture','--test','reference_optimal_prices','--test','reference_optimal_price_fixture',*flags],12))
 commands.append(('clippy-'+label,['cargo','clippy','--offline','--locked','--all-targets',*flags,'--','-D','warnings'],None))
features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'std','default'})
commands.extend([('nostd-safe',['cargo','check','--offline','--locked','--no-default-features'],None),('nostd-all',['cargo','check','--offline','--locked','--no-default-features','--features',','.join(features)],None)])
e=dict(status='running',source=before,commands=rows,unsafe_features=features)
def save():(O/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
try:
 for label,argv,count in commands:
  import re
  print('START',label,flush=True);log=O/(label+'.log')
  with log.open('xb') as f:r=subprocess.run(argv,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  data=log.read_bytes();counts=[tuple(map(int,m)) for m in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed;',data)]
  row=dict(label=label,argv=argv,exit_code=r.returncode,log=log.name,sha256=sha(log),passed=sum(v[0] for v in counts));rows.append(row);save()
  if r.returncode or count is not None and row['passed']!=count:raise RuntimeError(label)
  print('PASS',label,row['passed'],flush=True)
 e['source_unchanged']=before==source()
 if not e['source_unchanged']:raise RuntimeError('source changed')
 e['status']='passed';save()
except BaseException as error:
 e.update(status='failed',error=repr(error));save();raise
