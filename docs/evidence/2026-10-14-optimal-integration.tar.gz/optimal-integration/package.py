from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');O=Path('/tmp/zstdoxide-optimal-integration-checks')
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def sha(b):return hashlib.sha256(b).hexdigest()
e=json.loads((O/'evidence.json').read_text())
if e['status']!='passed' or not e['source_unchanged'] or sum(r['passed'] for r in e['commands'])!=102:raise ValueError('complete integration checks')
for row in e['commands']:
 if row['exit_code']!=0 or sha((O/row['log']).read_bytes())!=row['sha256']:raise ValueError('command identity')
for name,digest in e['source'].items():
 if sha((R/name).read_bytes())!=digest:raise ValueError('source changed '+name)
files={'checks/'+p.name:p.read_bytes() for p in O.iterdir() if p.is_file()}
for name in ['src/optimal_frequencies.rs','src/optimal_price.rs','src/lib.rs','Cargo.toml','Cargo.lock','scripts/check.sh']:
 files['source/'+name]=(R/name).read_bytes()
files['runner.py']=Path('/tmp/zstdoxide-optimal-integration-checks.py').read_bytes();files['package.py']=Path(__file__).read_bytes()
report=dict(status='passed',focused_tests=102,frequency_tests=24,public_predecessor_tests=54,fixture_price_tests=24,format=True,strict_clippy=['safe','all'],true_no_std=['safe','all-unsafe-leaves'],unsafe_features=e['unsafe_features'],source_unchanged=True,qualification='Post-merge integration checks after completed Module16 closure. Frequency ownership is private; public strategy7 remains unsupported. The historical Module16 matrix and benchmark sources remain qualified to their own immutable checkpoint.')
files['report.json']=enc(report);files['file-manifest.json']=enc({n:dict(bytes=len(b),sha256=sha(b)) for n,b in sorted(files.items())})
a=R/'docs/evidence/2026-10-14-optimal-integration.tar.gz'
if a.exists():raise ValueError('fresh archive')
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo('optimal-integration/'+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:
 if {m.name:t.extractfile(m).read() for m in t}!={'optimal-integration/'+n:b for n,b in files.items()}:raise ValueError('archive verification')
report.update(archive=a.name,archive_sha256=sha(a.read_bytes()),archive_bytes=a.stat().st_size,archive_members=len(files));(R/'docs/evidence/2026-10-14-optimal-integration.json').write_bytes(enc(report))
p=R/'TODO.md';p.write_text(p.read_text().replace('- [ ] Merge the isolated private frequency branch after Module 16 matrix and measurement closure.','- [x] Merge the isolated private frequency branch after Module 16 matrix and measurement closure.'))
p=R/'docs/reference-optimal-validation.md';s=p.read_text();s+='''\n## Private integration after tree closure\n\nAfter Module16 matrix and measurement closure, the isolated frequency branch\nmerges into the main library graph privately. Post-merge checks pass102tests:\n24frequency checks across safe/frequency/all,54public/predecessor checks and\n24fixture/price checks across safe/all. Strict safe/all Clippy, formatting and\ntwo true no_std configurations pass with every source input unchanged.\n`evidence/2026-10-14-optimal-integration.json` retains exact logs and source hashes.\nPublic strategy7 remains unsupported pending sorted search, path parsing, ordinary\nretained-state observations and admission/interoperability qualification.\n''';p.write_text(s)
print(a.name,a.stat().st_size)
