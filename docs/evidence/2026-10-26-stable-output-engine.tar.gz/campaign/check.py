from pathlib import Path
import os,subprocess,json,time,hashlib
D=Path(__file__).parent
env={**os.environ,'CARGO_TARGET_DIR':'/private/tmp/module24-engine-target','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
e=dict(status='running',commands=[],source={str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (D/'src').rglob('*.rs')})
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [('safe',[]),('slice',['--features','unsafe-slice-history']),('all',['--all-features'])]:
  for suffix,args in [('storage',['cargo','test','--offline','--locked','--lib','slice_decode',*flags]),('one-shot',['cargo','test','--offline','--locked','--test','caller_output','--test','caller_output_platform',*flags]),('clippy',['cargo','clippy','--offline','--locked','--lib','--tests',*flags,'--','-D','warnings'])]:
   start=time.monotonic()
   with (D/(name+'-'+suffix+'.log')).open('xb') as f:p=subprocess.run(args,cwd=D,env=env,stdout=f,stderr=subprocess.STDOUT)
   e['commands'].append(dict(label=name+'-'+suffix,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start));save();print(name,suffix,p.returncode,flush=True);assert p.returncode==0
 args=['cargo','check','--offline','--locked','--lib','--no-default-features']
 with (D/'no-std.log').open('xb') as f:p=subprocess.run(args,cwd=D,env=env,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label='no-std',argv=args,exit_code=p.returncode));assert p.returncode==0
 for n,h in e['source'].items():assert hashlib.sha256((D/n).read_bytes()).hexdigest()==h
 e['status']='passed';save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
