from pathlib import Path
import datetime,hashlib,json
R=Path.cwd();paths=dict(platform='/tmp/optimal-public-platform-barrier.json',matrix='/tmp/optimal-public-matrix-barrier.json',native='/tmp/optimal-public-native-barrier.json',clock_free='/private/tmp/zstdoxide-optimal-benchmark-clock-free-1016/evidence.json');completed={};records={}
def need(v,why):
 if not v:raise ValueError(why)
for name,path in paths.items():
 p=Path(path);raw=p.read_text();v=json.loads(raw);need(v['status']=='passed'and v['source_unchanged']is True,'completed '+name);records[name]=v;completed[name]=dict(path=str(p),sha256=hashlib.sha256(raw.encode()).hexdigest(),json=raw)
source=records['matrix']['source'];maps=[records['native']['source'],records['clock_free']['source']]+[c['json']['source']for c in records['platform']['components']]
for other in maps:
 for name in source.keys()&other.keys():need(source[name]==other[name],'common tested source '+name)
for name,digest in source.items():need(hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,'unchanged tested source '+name)
report=dict(schema_version=1,recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),task_owned_jobs_remaining=[],completed=completed,qualification='Coordinator confirmed all task-owned native, foreign-platform, full-feature regression, offline reconstruction/control and archive jobs exited before timing. Common source identities agree across prerequisite campaigns. This records task-owned completion, not unrelated desktop idleness or thermal/clock control.')
p=Path('/tmp/optimal-public-timing-barrier.json');need(not p.exists(),'fresh timing barrier');p.write_text(json.dumps(report,indent=2)+'\n');print(p)
