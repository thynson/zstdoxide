from pathlib import Path
import hashlib,io,json,tarfile
R=Path.cwd();files={};sha=lambda b:hashlib.sha256(b).hexdigest()
def need(v,why):
 if not v:raise ValueError(why)
def add(name,p):
 need(name not in files and p.is_file(),'unique existing input '+name);files[name]=p
roots=dict(clock_free=Path('/private/tmp/zstdoxide-optimal-benchmark-clock-free-1016'),timed=Path('/private/tmp/zstdoxide-optimal-benchmark-timed-1016'),repeat=Path('/private/tmp/zstdoxide-optimal-benchmark-repeat-1016'))
source=None;executable_count=0
for campaign,root in roots.items():
 e=json.loads((root/'evidence.json').read_text());need(e['status']=='passed'and e['source_unchanged']is True,'passed campaign')
 if source is None:source=e['source']
 need(source==e['source'],'identical source')
 for p in root.rglob('*'):
  if p.is_file()and p.relative_to(root).parts[0]!='targets':add('campaigns/'+campaign+'/'+str(p.relative_to(root)),p)
 executable_count+=len(e['executables'])
 for config,record in e['executables'].items():
  p=Path(record['path']);need(sha(p.read_bytes())==record['sha256'],'original executable bytes');add('executables/'+campaign+'/'+config,p)
for name,digest in source.items():
 p=R/name;need(sha(p.read_bytes())==digest,'unchanged source '+name);add('source/'+name,p)
for mode in ['normal','optimized']:
 root=Path('/private/tmp/zstdoxide-optimal-timed-controls-'+mode+'-1016');v=json.loads((root/'summary.json').read_text());need(v['status']=='passed'and v['checks']==26 and v['rejected']==24 and v['child_attempts']==0 and v['optimized']is(mode=='optimized') and v['source_sha256']==sha((R/'scripts/check_optimal_timed_controls.py').read_bytes()),'complete timed controls')
 for p in root.rglob('*'):
  if p.is_file():add('controls/'+mode+'/'+str(p.relative_to(root)),p)
for name in ['scripts/check_optimal_timed_controls.py','docs/evidence/2026-10-16-optimal-frame-measurements.json','docs/evidence/2026-10-16-optimal-frame-measurements.csv']:add('report/'+name,R/name)
for name in ['/tmp/optimal-public-timing-barrier.json','/tmp/optimal-public-timing-repeat-barrier.json','/tmp/create-optimal-timing-barrier.py','/tmp/summarize-optimal-measurements.py',__file__]:add('coordination/'+Path(name).name,Path(name))
for label in ['timed','repeat']:
 for mode in ['normal','optimized']:add('validation/'+label+'-'+mode+'.log',Path('/tmp/optimal-benchmark-'+label+'-validate-'+mode+'.log'))
need(executable_count==44,'complete executable inventory')
a=R/'docs/evidence/2026-10-16-optimal-frame-timed.tar.gz';need(not a.exists(),'fresh immutable archive');rows=[]
with tarfile.open(a,'w:gz')as archive:
 for name,p in sorted(files.items()):
  b=p.read_bytes();item=tarfile.TarInfo(name);item.size=len(b);item.mode=0o755 if name.startswith('executables/')else 0o644;archive.addfile(item,io.BytesIO(b));rows.append(dict(path=name,bytes=len(b),sha256=sha(b)))
expected={r['path']:r for r in rows};found=set()
with tarfile.open(a,'r|gz')as archive:
 for item in archive:
  need(item.isfile()and item.name in expected and item.name not in found,'exact archive member');b=archive.extractfile(item).read();r=expected[item.name];need(len(b)==r['bytes']and sha(b)==r['sha256'],'verified archive bytes');found.add(item.name)
need(found==set(expected),'complete archive')
report=dict(status='passed',archive=a.name,archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),retained_executables=executable_count,files=rows,qualification='Complete three-campaign logs/frames/source, all44actual measured-or-clock-free executables, and both26-case offline timing-control campaigns. All archive members verified. Compiler/toolchain and external Cargo configs remain hash-identified external dependencies.')
a.with_name(a.name.removesuffix('.tar.gz')+'.json').write_text(json.dumps(report,indent=2)+'\n');print(len(rows),report['archive_bytes'],report['archive_sha256'])
