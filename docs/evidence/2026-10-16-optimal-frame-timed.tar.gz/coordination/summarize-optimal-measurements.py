from pathlib import Path
import csv,hashlib,json,math,sys
sys.dont_write_bytecode=True;sys.path.insert(0,str(Path.cwd()/'scripts'))
import benchmark_optimal_frames as m
roots=dict(clock_free=Path('/private/tmp/zstdoxide-optimal-benchmark-clock-free-1016'),timed=Path('/private/tmp/zstdoxide-optimal-benchmark-timed-1016'),repeat=Path('/private/tmp/zstdoxide-optimal-benchmark-repeat-1016'));data={}
for name,p in roots.items():
 e=m.shared.load_json(p/'evidence.json');m.validate(p,e);data[name]=e
m.require(data['timed']['configs']==['safe',*m.FEATURES,'all']and data['repeat']['configs']==['safe','all'],'complete separate campaigns')
m.require(data['timed']['timed']is True and data['repeat']['timed']is True and data['clock_free']['timed']is False,'campaign modes')
reference=data['clock_free'];rows=[];comparisons={};identities={}
for name,e in data.items():
 m.require(e['source']==reference['source']and e['compiler_sha256']==reference['compiler_sha256']and e['cargo_configs']==reference['cargo_configs']and e['host']==reference['host'],'same complete source/compiler/Cargo/host')
 identities[name]={}
 for config in e['configs']:
  identities[name][config]=e['executables'][config]['sha256']==reference['executables'][config]['sha256']
  for i,r in enumerate(e['summary'][config]):
   base=reference['summary']['safe'][i];m.require({k:v for k,v in r.items()if k!='timing'}=={k:v for k,v in base.items()if k!='timing'},'complete cross-campaign frames and owners')
   if name=='clock_free':continue
   rows.append(dict(campaign=name,config=config,workload=r['workload'],source_bytes=m.INPUT_PINS[r['workload']]['bytes'],frame_bytes=r['frame_bytes'],compressed_size_ratio=r['compressed_size_ratio'],allocation_attempts=r['allocation']['attempts'],peak_bytes=r['allocation']['peak_bytes'],**r['timing'],ratio_to_safe=r['timing']['median_ns_per_byte']/e['summary']['safe'][i]['timing']['median_ns_per_byte']))
 if name!='clock_free':
  ratios=[r['timing']['median_ns_per_byte']/e['summary']['safe'][i]['timing']['median_ns_per_byte']for i,r in enumerate(e['summary']['all'])]
  comparisons[name]=dict(all_over_safe_geometric_mean=math.exp(sum(map(math.log,ratios))/len(ratios)),minimum=min(ratios),maximum=max(ratios),case_ratios=ratios)
report=dict(status='passed',source_unchanged=True,campaigns={n:dict(path=str(p),evidence_sha256=m.sha(p/'evidence.json'))for n,p in roots.items()},clock_free_cases=504,timed_cases=len(rows),samples=len(rows)*5,comparisons=comparisons,executable_identity_with_clock_free=identities,source=reference['source'],qualification='Identical complete frames and allocator records across all backends and campaigns. Five >=100ms samples per timed case. Fixed-order single-host diagnostics; no stable unsafe-speedup or C/Rust performance comparison claim. Loop/clock overhead remains inside the measured interval.')
m.require(len(rows)==552 and report['samples']==2760,'complete sample inventory')
p=Path('docs/evidence/2026-10-16-optimal-frame-measurements.json');m.require(not p.exists(),'fresh report');p.write_text(json.dumps(report,indent=2)+'\n')
with p.with_suffix('.csv').open('w',newline='')as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps(comparisons,sort_keys=True))
