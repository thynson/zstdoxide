from pathlib import Path
import hashlib,json,sys
R=Path('/Users/lanxingcan/Workspace/zstdoxize');C=Path('/private/tmp/zstdoxide-lazy-tiny-2026-10-12');sys.path.insert(0,str(R/'scripts'))
import check_lazy_tiny_recipes as inputs
import check_lazy_tiny_capture as audit
report=audit.audit(C);e=json.loads((C/'evidence.json').read_bytes());g,cases,_=inputs.inputs()
def sha(b):return hashlib.sha256(b).hexdigest()
parts=[];records={};cursor=0
for name,label in [(c.name,'normal-case-'+c.name) for c in cases]+[(f'salt-{mode}-{d}',f'{mode}-fresh-salt-{d}') for mode in ['normal','sanitized'] for d in range(3)]:
 raw=(C/'logs'/(label+'.stdout')).read_bytes();records[name]={'offset':cursor,'bytes':len(raw),'sha256':sha(raw)};parts.append(raw);cursor+=len(raw)
pack=b''.join(parts)
manifest={'schema_version':1,'upstream_revision':g.REVISION,'source':e['source_before'],'auditor_sha256':sha((R/'scripts/check_lazy_tiny_capture.py').read_bytes()),'raw_evidence_sha256':sha((C/'evidence.json').read_bytes()),'compiler':(C/'logs/compiler-version.stdout').read_text(),'compiler_sha256':e['compiler_sha256'],'pack_bytes':len(pack),'pack_sha256':sha(pack),'records':records,'audit':report,'qualification':'Real normal/sanitized pinned C observations. Every direct byte agrees across builds. Fresh-context peaks are retained separately because upstream ASan workspace redzones differ. Full final tables/frontiers are not chronological probe traces. No Rust Lazy execution or complete-frame interoperability is claimed.'}
dest=R/'tests/fixtures/reference-lazy-tiny'
for name,data in [('observations.ndjson',pack),('capture.json',(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode())]:
 p=dest/name
 if p.exists():raise ValueError('fresh output required')
 p.write_bytes(data);print(name,len(data),sha(data))
