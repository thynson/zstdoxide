from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize');C=Path('/private/tmp/zstdoxide-lazy-tiny-2026-10-12')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,s):
 if not v:raise ValueError(s)
e=json.loads((C/'evidence.json').read_bytes());need(e['status']=='passed' and len(e['commands'])==422 and e['source_before']==e['source_after'],'capture')
files={'capture/'+str(p.relative_to(C)):p.read_bytes() for p in sorted(C.rglob('*')) if p.is_file()}
for n,h in e['source_before'].items():
 data=(R/n).read_bytes();need(sha(data)==h,'unchanged source '+n);files['source/'+n]=data
for n in ['scripts/check_lazy_tiny_capture.py','scripts/check_lazy_tiny_fixture.py','tests/fixtures/reference-lazy-tiny/capture.json','tests/fixtures/reference-lazy-tiny/observations.ndjson']:files['source/'+n]=(R/n).read_bytes()
for mode in ['normal','optimized']:
 for family,count in [('capture',50),('fixture',15)]:
  p=Path('/tmp/zstdoxide-lazy-'+family+'-controls-'+mode+'.json');v=json.loads(p.read_bytes());need(v['status']=='passed' and (v['positive'],v['rejected'],v['child_processes'])==(2,count,0),'offline controls');files['controls/'+family+'-'+mode+'.json']=p.read_bytes()
  if family=='capture':need(not Path('/tmp/zstdoxide-lazy-capture-controls-'+mode+'.stderr').read_bytes(),'control diagnostics')
 p=Path('/tmp/zstdoxide-lazy-tiny-audit-'+mode+'.json');v=json.loads(p.read_bytes());need(v['commands']==422 and len(v['predecessor_controls'])==36 and all(r['exact_owner_layout_qualified'] for r in v['predecessor_controls']),'audit');files['audit-'+mode+'.json']=p.read_bytes()
need(files['audit-normal.json']==files['audit-optimized.json'],'offline audit equality')
for n in ['freeze-zstdoxide-lazy-tiny.py','zstdoxide-lazy-capture-controls.py','check-zstdoxide-lazy-fixture-controls.py','package-zstdoxide-lazy-tiny.py']:files['runners/'+n]=(Path('/tmp')/n).read_bytes()
files['controls/initial-driver-setup-error.json']=enc({'status':'failed','stage':'temporary offline forgery-driver setup','exception':'FileNotFoundError: normal-negative-depth-high.stderr','reason':'The frozen malformed-packet label is depth-three, not depth-high. The first normal run reached this nonexistent control setup filename; the corrected driver was rerun completely in normal and optimized modes.','affected_capture':False,'changed_oracle_or_expected_output':False})
report={'date':'2026-10-12','status':'passed','commands':422,'totals':e['totals'],'predecessor_controls':36,'exact_predecessor_owner_layouts':36,'observed_tail_cases':30,'direct_build_bytes_identical':True,'context_peak_guarded_bytes':e['context_peak_guarded_bytes'],'source_unchanged':True,'capture_auditor_sha256':sha((R/'scripts/check_lazy_tiny_capture.py').read_bytes()),'fixture_checker_sha256':sha((R/'scripts/check_lazy_tiny_fixture.py').read_bytes()),'pack_bytes':576102,'pack_sha256':sha((R/'tests/fixtures/reference-lazy-tiny/observations.ndjson').read_bytes()),'offline_controls_per_mode':{'capture_positive':2,'capture_rejected':50,'fixture_positive':2,'fixture_rejected':15,'child_processes':0},'compiled_translation_units_per_mode':26,'all_linked_units_instrumented_in_sanitized_build':True,'upstream_sanitizer_annotations_retained':True,'leak_sanitizer':False,'raw_capture_files':len([n for n in files if n.startswith('capture/')]),'binary_retention':'Every used compiled object and executable retained with SHA256 identities. Reference C source remains outside the repository; its pinned revision, source/header hashes, dependency closure and exact build commands are retained.','qualification':'Real private direct Greedy/Lazy/Lazy2 observations and fresh-context salt only. Complete final maps/frontiers do not establish chronological probes. No Rust Lazy parser or ordinary/public-frame interoperability or timing claim. Initial temporary control-driver filename typo is preserved; no C capture failure occurred.','archive':'2026-10-12-lazy-tiny.tar.gz'}
files['review.json']=enc(report);files['bundle-manifest.json']=enc({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())})
a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh archive');prefix='lazy-tiny/'
with tarfile.open(a,'w:gz') as t:
 for n,b in sorted(files.items()):
  i=tarfile.TarInfo(prefix+n);i.size=len(b);i.mode=0o644;t.addfile(i,io.BytesIO(b))
with tarfile.open(a) as t:found={v.name:t.extractfile(v).read() for v in t}
need(found=={prefix+n:b for n,b in files.items()},'archive exact file bytes')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files),archive_uncompressed_bytes=sum(map(len,files.values())));(R/'docs/evidence/2026-10-12-lazy-tiny.json').write_bytes(enc(report));print(report['archive_members'],report['archive_bytes'])
