from pathlib import Path
import hashlib,io,json,tarfile
R=Path('/Users/lanxingcan/Workspace/zstdoxize')
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def need(v,s):
 if not v:raise ValueError(s)
checks={mode:json.loads(Path('/tmp/zstdoxide-lazy-tiny-inputs-'+mode+'.json').read_bytes()) for mode in ['normal','optimized']}
for mode,e in checks.items():
 need(e['status']=='passed' and e['python_optimized']==(mode=='optimized') and e['positive_runs']==2 and e['rejected_input_forgeries']==23 and e['child_processes']==0,'input controls')
 need(e['positive']=={'recipes':138,'packet_bytes':25581,'source_bytes':4449,'malformed_packets_rejected':39,'closed_form_hash_controls':31,'reference_executions':0},'exact input counts')
 for n,h in e['source'].items():need(sha((R/n).read_bytes())==h,'unchanged input '+n)
report={'date':'2026-10-12','status':'passed','source':checks['normal']['source'],'recipes':138,'source_bytes':4449,'packet_bytes':25581,'predecessor_controls':36,'additional_tail_cases':30,'per_depth_cases':46,'malformed_packets_per_positive_check':39,'hash_boundary_controls_per_positive_check':31,'positive_runs_per_mode':2,'rejected_input_forgeries_per_mode':23,'child_processes':0,'reference_executions':0,'qualification':'Frozen source hypotheses and independent input controls only. No C observations, Rust Lazy parser or expected Lazy output. Tail geometry is an input hypothesis to verify in the future capture.','archive':'2026-10-12-lazy-tiny-inputs.tar.gz'}
files={'controls-'+mode+'.json':enc(e) for mode,e in checks.items()}
for n in report['source']:files['source/'+n]=(R/n).read_bytes()
files['source/tests/fixtures/reference-lazy-tiny/README.md']=(R/'tests/fixtures/reference-lazy-tiny/README.md').read_bytes()
for n in ['check-zstdoxide-lazy-tiny-inputs.py','package-zstdoxide-lazy-tiny-inputs.py']:files['runners/'+n]=(Path('/tmp')/n).read_bytes()
files['review.json']=enc(report);files['bundle-manifest.json']=enc({n:{'bytes':len(v),'sha256':sha(v)} for n,v in files.items()})
a=R/'docs/evidence'/report['archive'];need(not a.exists(),'fresh archive');prefix='lazy-tiny-inputs/'
with tarfile.open(a,'w:gz') as t:
 for n,v in sorted(files.items()):
  i=tarfile.TarInfo(prefix+n);i.size=len(v);i.mode=0o644;t.addfile(i,io.BytesIO(v))
with tarfile.open(a) as t:found={v.name:t.extractfile(v).read() for v in t}
need(found=={prefix+n:v for n,v in files.items()},'archive bytes')
report.update(archive_bytes=a.stat().st_size,archive_sha256=sha(a.read_bytes()),archive_members=len(files));(R/'docs/evidence/2026-10-12-lazy-tiny-inputs.json').write_bytes(enc(report));print(report['recipes'],report['archive_members'],report['archive_bytes'])
