from pathlib import Path
import json,subprocess,os,hashlib,time
D=Path(__file__).parent;S=D/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
e=dict(status='running',source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()},commands=[])
def save():(D/'evidence.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [('safe',[]),('move',['--features','unsafe-in-place-buffer']),('history',['--features','unsafe-slice-history']),('combined',['--features','unsafe-in-place-buffer,unsafe-slice-history']),('all',['--all-features'])]:
  args=['cargo','test','--offline','--locked','--test','upstream_decodecorpus',*flags,'every_generated_frame_decodes_in_place_with_exact_margin_and_guarded_limits','--','--exact'];start=time.monotonic()
  with (D/(name+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-start,log_sha256=sha(D/(name+'.log'))));save();assert p.returncode==0,name
  assert '1 passed; 0 failed; 0 ignored' in (D/(name+'.log')).read_text()
 for n,h in e['source'].items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='In-place supplement traverses every existing official decodecorpus frame using exact sufficient margins, full bytes and unused tails, plus one-byte-short options limits. Existing upstream generator metadata and attribution are retained. This supplement is separately labelled from the original two in-place fuzzer groups.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
