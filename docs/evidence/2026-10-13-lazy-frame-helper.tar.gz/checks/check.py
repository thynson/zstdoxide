from pathlib import Path
import subprocess,json,hashlib
root=Path('/tmp/zstdoxide-lazy-frame-helper')
u=Path('/private/tmp/zstdoxide-reference-lazy-1.5.7')
h=Path('scripts/oracles/lazy_frame_v1.c')
catalog=json.loads(Path('tests/upstream/manifest.json').read_text())
revision=subprocess.check_output(['git','-C',str(u),'rev-parse','HEAD'],text=True).strip()
if revision!='f8745da6ff1ad1e7bab384bd1f9d742439278e99':raise ValueError('revision')
source_map={r['path']:r['sha256'] for r in catalog['sources']+catalog['excluded_sources'] if r['path'].startswith('lib/') and Path(r['path']).suffix in ('.c','.h')}
for name,digest in source_map.items():
 if hashlib.sha256((u/name).read_bytes()).hexdigest()!=digest:raise ValueError(name)
common=['clang','-std=c11','-Wall','-Wextra','-Werror','-Wno-deprecated-declarations','-fsyntax-only','-I',str(u/'lib'),'-I',str(u/'lib/common'),'-I',str(u/'lib/compress'),'-UZSTD_MULTITHREAD','-DZSTD_DISABLE_ASM','-DZSTD_LEGACY_SUPPORT=0','-DXXH_NAMESPACE=ZSTD_']
results=[]
for name,flags in [('normal',['-O2']),('sanitized',['-O1','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer'])]:
 cmd=common+flags+[str(h)]
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (root/(name+'.stdout')).write_bytes(r.stdout);(root/(name+'.stderr')).write_bytes(r.stderr)
 results.append({'mode':name,'command':cmd,'status':r.returncode});print(name,r.returncode,r.stderr.decode())
 if r.returncode:raise SystemExit(r.returncode)
(root/'syntax.json').write_text(json.dumps({'helper_sha256':hashlib.sha256(h.read_bytes()).hexdigest(),'reference':str(u),'revision':revision,'source_map':source_map,'commands':results,'codec_executions':0},indent=2)+'\n')
