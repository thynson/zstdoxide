from pathlib import Path
import datetime, hashlib, json, os, re, signal, subprocess, time
D=Path('/private/tmp/module40-matrix')
S=D/'source'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((D/'evidence.json').read_text())
assert e['status']=='running' and len(e['commands'])==72
source=e['source'];plan=e['plan'];COUNTS=(129,1878,81)
for n,h in source.items():assert sha(S/n)==h
for row in e['commands']:
 assert row['exit_code']==0
 assert sha(D/(row['label']+'.log'))==row['log_sha256']
deadline=datetime.datetime.fromisoformat(e['deadline_utc']).timestamp()
env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'6',
     'CARGO_INCREMENTAL':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_PROFILE_TEST_OPT_LEVEL':'1','CARGO_PROFILE_DEV_DEBUG':'0'}
e['resumed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
def counts(text):
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert rows and all(int(f) == 0 for _, f, _ in rows), 'A test group failed'
    return len(rows), sum(int(p) for p, _, _ in rows), sum(int(i) for _, _, i in rows)


def save():
    p = D / 'evidence.pending.json'
    p.write_text(json.dumps(e, indent=2) + '\n')
    p.replace(D / 'evidence.json')


save()
try:
    for label, args in plan[len(e['commands']):]:
        remaining = deadline - time.time() - 30
        if remaining < 30:
            raise TimeoutError('User work window reached before ' + label)
        e['active_command'] = dict(label=label, argv=args, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save()
        start = time.monotonic()
        log = D / (label + '.log')
        with log.open('xb') as f:
            proc = subprocess.Popen(args, cwd=S, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = proc.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait()
                raise TimeoutError('User work window reached during ' + label)
        row = dict(label=label, argv=args, exit_code=code, seconds=time.monotonic() - start, log_sha256=sha(log))
        if label.endswith(('-full', '-release')) and code == 0:
            result = counts(log.read_text())
            assert result == COUNTS, (label, result)
            row.update(result_groups=result[0], passed=result[1], ignored=result[2])
        if label.endswith('-objects') and code == 0:
            e['artifacts'] = e.get('artifacts', {})
            for suffix in ['.ll', '.o']:
                candidates = sorted((D / (label.replace('-objects', '').replace('thumb-', 'target-'))).rglob('*' + suffix), key=lambda p: p.stat().st_mtime)
                assert candidates, (label, suffix)
                e['artifacts'][label.replace('-objects', '') + suffix] = sha(candidates[-1])
        e['commands'].append(row)
        e.pop('active_command', None)
        save()
        print(label, code, flush=True)
        assert code == 0, label
    for n, h in source.items():
        assert sha(S / n) == h, ('Final source changed during matrix', n)
    assert len(e['commands']) == len(plan)
    e['status'] = 'complete'
    e['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    print('complete', flush=True)
except BaseException as error:
    e['status'] = 'failed'
    e['error'] = repr(error)
    save()
    raise
