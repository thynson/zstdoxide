from pathlib import Path
import hashlib,json,tarfile
D=Path(__file__).parent;R=Path('/Users/lanxingcan/Workspace/zstdoxize');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((D/'evidence.json').read_text());assert e['status']=='complete';assert len(e['commands'])==79
assert all(r['exit_code']==0 for r in e['commands'])
for n,h in e['source'].items():assert sha(R/n)==h,('source mismatch',n)
for row in e['commands']:
 assert sha(D/(row['label']+'.log'))==row['log_sha256']
 if row['label'].endswith(('-full','-release')):assert (row['result_groups'],row['passed'],row['ignored'])==(129,1878,81)
archive=R/'docs/evidence/2026-11-05-reference-streaming-feature-matrix.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n in ['check.py','resume.py','finalize.py','evidence.json','driver.log','driver-initial.log','safe-release-initial.log']:t.add(D/n,arcname=n)
 for row in e['commands']:t.add(D/(row['label']+'.log'),arcname=row['label']+'.log')
e['archive']={'path':str(archive.relative_to(R)),'sha256':sha(archive)}
e['note']='All-features host no_std explicitly enables the 22 unsafe features without std; --all-features itself would re-enable std. ARM also uses the explicit feature list. Earlier receipts are not rewritten.'
(R/'docs/evidence/2026-11-05-reference-streaming-feature-matrix.json').write_text(json.dumps(e,indent=2)+'\n')
p=R/'TODO.md';s=p.read_text().replace('- [ ] Qualify atomic-free ARM, every isolated feature/all features, release,','- [x] Qualify atomic-free ARM, every isolated feature/all features, release,');p.write_text(s)
p=R/'docs/reference-streaming-validation.md';s=p.read_text();a=s.index('## Remaining qualification gates');b=s.index('## Bounded scope',a)
s=s[:a]+'''## Full feature, release and platform matrix

All 79 commands pass on the frozen final codec/test source: safe/all and each
of 22 isolated unsafe features run complete tests, host no_std and strict
Clippy; safe/all release suites, safe/all atomic-free ARM checks and release
LLVM IR/object emission, and formatting also pass. Every full/release suite
reports 129 result groups, 1,878 passed and 81 ignored, with zero failures.
The native campaign runs its ignored adapter explicitly; other ignored tests
remain uncredited.

For all-feature host no_std, the command explicitly enables all 22 unsafe
features while disabling defaults. Using `--all-features` there would also
enable `std`; this campaign avoids that ambiguity. Atomic-free
`thumbv6m-none-eabi` uses the same explicit feature list with
`-Zbuild-std=core,alloc`, including concrete release IR and object output.
The first safe-release attempt exhausted temporary disk space during
compilation/linking. Its failure log is preserved separately. After removing
the completed debug build cache, the controller verified all 72 prior log
hashes and the immutable source, then reran release and the remaining gates.
Only successful final attempts count toward the 79-command result.

The source manifest and object hashes are retained in
`evidence/2026-11-05-reference-streaming-feature-matrix.json`; the matching
archive contains the controller and every raw log. No Miri ran because this
module added or changed no unsafe code, following the standing directive.

The separate timing comparison remains an independent gate until its receipt
is reconciled. Full matrix success alone is not a performance claim.

'''+s[b:];p.write_text(s)
print('matrix archive and report prepared')
