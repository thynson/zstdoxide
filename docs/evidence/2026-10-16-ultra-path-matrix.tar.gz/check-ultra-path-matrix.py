from pathlib import Path
import subprocess,os,json,hashlib,time,tomllib
R=Path.cwd();O=Path('/tmp/zstdoxide-ultra-path-matrix-1016');O.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def sources():return {str(p.relative_to(R)):sha(p)for folder in ['src','tests','examples','test-support']for p in sorted((R/folder).rglob('*.rs'))}|{n:sha(R/n)for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','test-support/allocator/Cargo.toml']}
source=sources();records=[];features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'})
env=os.environ|dict(CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_TARGET_DIR='/tmp/zstdoxide-ultra-frequencies-target');commands=[]
for mode,flags in [('safe',[]),*[(f,['--features',f])for f in features],('all',['--all-features'])]:
 commands += [(mode+'-optimal',['cargo','test',*flags,'--lib','optimal_parse::']), (mode+'-fixtures',['cargo','test',*flags,'--test','reference_ultra_path_fixture','--test','reference_optimal'])]
 flags=[]if mode=='safe'else['--features',','.join(features)if mode=='all'else mode]
 commands.append((mode+'-nostd',['cargo','check','--no-default-features',*flags]))
commands += [('full-safe',['cargo','test']),('full-all',['cargo','test','--all-features']),('release-all',['cargo','test','--release','--all-features','--lib','optimal_parse::']),('clippy-safe',['cargo','clippy','--all-targets','--','-D','warnings']),('clippy-all',['cargo','clippy','--all-targets','--all-features','--','-D','warnings']),('fmt',['cargo','fmt','--all','--check'])]
def save(status,error=None):(O/'evidence.json').write_text(json.dumps(dict(status=status,error=error,source=source,environment={k:env[k]for k in ['CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_TARGET_DIR']},source_unchanged=sources()==source,commands=records),indent=2)+'\n')
save('running')
try:
 for name,argv in commands:
  print('START',name,flush=True);p=O/(name+'.log');start=time.monotonic()
  with p.open('w')as f:r=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
  records.append(dict(label=name,argv=argv,exit_code=r.returncode,seconds=time.monotonic()-start,log=p.name,sha256=sha(p)));save('running')
  if r.returncode:raise ValueError(name)
  print('END',name,flush=True)
 if sources()!=source:raise ValueError('source changed')
 save('passed')
except BaseException as error:save('failed',repr(error));raise
