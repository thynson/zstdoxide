from pathlib import Path
import json,hashlib,re,tomllib
R=Path.cwd();O=Path('/tmp/zstdoxide-ultra-path-matrix-1016');doc=json.loads((O/'evidence.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if doc['status']!='passed' or not doc['source_unchanged']:raise ValueError('incomplete matrix')
for p,h in doc['source'].items():
 if sha(R/p)!=h:raise ValueError('changed source '+p)
features=sorted(set(tomllib.loads((R/'Cargo.toml').read_text())['features'])-{'default','std'});expected=[m+'-'+s for m in ['safe',*features,'all']for s in ['optimal','fixtures','nostd']]+['full-safe','full-all','release-all','clippy-safe','clippy-all','fmt']
if [r['label']for r in doc['commands']]!=expected:raise ValueError('command inventory')
counts={};inventories={};total=ignored=0
for row in doc['commands']:
 p=O/row['log']
 if row['exit_code'] or sha(p)!=row['sha256']:raise ValueError(row['label'])
 text=p.read_text();outcomes=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 passed=sum(int(r[0])for r in outcomes);skip=sum(int(r[2])for r in outcomes)
 if any(int(r[1])for r in outcomes):raise ValueError('failed tests')
 target=21 if row['label'].endswith('-optimal')or row['label']=='release-all'else 9 if row['label'].endswith('-fixtures')else None if row['label'].startswith('full-')else 0
 if target is not None and (passed!=target or skip):raise ValueError('selected test count '+row['label'])
 if row['label'].startswith('full-'):
  inventory=re.findall(r'^test (.+?) \.\.\. (ok|ignored)(?:,.*)?$',text,re.M);inventories[row['label']]=sorted(inventory)
  if sum(status=='ok'for _,status in inventory)!=passed or sum(status=='ignored'for _,status in inventory)!=skip:raise ValueError('full outcome inventory')
 counts[row['label']]=dict(passed=passed,ignored=skip);total+=passed;ignored+=skip
if inventories['full-safe']!=inventories['full-all']:raise ValueError('full inventories differ')
report=dict(status='passed',source_unchanged=True,successful_commands=len(expected),features=features,passing_executions=total,ignored_executions=ignored,counts=counts,full_inventory=inventories['full-safe'],qualification='Selected parser/independent path fixture/public Optimal cases on all21configurations, complete safe/all suites with equal per-test outcomes, release Optimal regressions, true no_std and strict lint/format checks. Ignored migration gaps are not successes.')
Path('/tmp/ultra-path-matrix-reconciliation.json').write_text(json.dumps(report,indent=2)+'\n');print({k:report[k]for k in ['status','successful_commands','passing_executions','ignored_executions']})
