from pathlib import Path
import sys,json,struct
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(ROOT/'scripts'))
from oracles import greedy_interop_protocol as p
attempts=[]
def audit(event,args):
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec','os.spawn'):
  attempts.append(event);raise RuntimeError('child creation forbidden')
sys.addaudithook(audit)
controls=[]
def reject(name,action):
 try:action()
 except ValueError:controls.append(name)
 else:raise ValueError('accepted '+name)
valid=b'ZGOC0001'+bytes(36)
p.require(p.response(valid,b'ZGOC0001')==(0,[0]*7,b''),'valid response control')
for name,data in [('old-magic',b'ZDOC0001'+valid[8:]),('truncated',valid[:-1]),('trailing',valid+b'x'),('oversized',valid+bytes(p.MAX_RESPONSE)),('unknown-status',valid[:8]+struct.pack('<I',3)+valid[12:]),('c-scalar',valid[:12]+struct.pack('<I',1)+valid[16:])]:
 reject(name,lambda:p.response(data,b'ZGOC0001'))
reject('unknown-response-kind',lambda:p.response(valid,b'ZDOC0001'))
reject('rejected-payload',lambda:p.response(b'ZGOR0001'+struct.pack('<9I',1,10,6,6,1,4,0,3,1)+b'x',b'ZGOR0001'))
controls_tuple=(4,14,6,6,1,4,0,3,0)
for name,src,request,frame,mode in [('mutable-source',bytearray(),controls_tuple,b'',0),('source-cap',bytes(p.MAX_SOURCE+1),controls_tuple,b'',0),('frame-cap',b'',controls_tuple,bytes(p.MAX_FRAME+1),1),('mode',b'',controls_tuple,b'',True),('encode-frame',b'',controls_tuple,b'x',0),('decode-no-frame',b'',controls_tuple,b'',1),('tuple',b'',list(controls_tuple),b'',0),('level',b'',(1<<31,*controls_tuple[1:]),b'',0)]:
 reject(name,lambda:p.packet(src,request,frame,mode))
negative=p.negative_packets();p.require(len(negative)==39 and len({n for n,_ in negative})==39,'unique malformed requests')
p.require(not attempts,'no children')
print(json.dumps({'optimized':not __debug__,'controls':controls,'negative_packets':len(negative),'child_attempts':len(attempts)},sort_keys=True,indent=2))
