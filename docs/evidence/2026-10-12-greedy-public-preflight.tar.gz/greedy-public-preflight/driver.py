from pathlib import Path
import csv,hashlib,io,json,os,selectors,subprocess,sys,time
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(ROOT/'scripts'))
import check_greedy_interop_recipes as checker
from oracles import greedy_interop as generator,greedy_interop_protocol as protocol
import check_reference_admission_v3 as policy
OUTPUT=Path('/tmp/zstdoxide-greedy-public-preflight/results')
if OUTPUT.exists():raise ValueError('fresh output required')
manifest=checker.check();cases=generator.recipes()
OUTPUT.mkdir()
executables={mode:Path('/tmp/zstdoxide-greedy-public-preflight')/mode/'release/examples/reference_greedy_oracle' for mode in ('safe','all')}
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=[ROOT/'examples/reference_greedy_oracle.rs',ROOT/'scripts/oracles/greedy_interop_protocol.py',ROOT/'scripts/oracles/reference_greedy_frames.c',*sorted((ROOT/'src').rglob('*.rs'))]
before={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths}
report={'status':'running','source_before':before,'executable_sha256':{n:sha(p.read_bytes()) for n,p in executables.items()},'commands':[],'cases':[],'negative':[],'scope':'Rust only and C syntax check; no C codec execution.'}
def save():
 (OUTPUT/'evidence.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
def run(label,exe,data,expected=0):
 pth=OUTPUT/(label+'.input');pth.write_bytes(data)
 start=time.monotonic();buffers={name:bytearray() for name in ('stdout','stderr')}
 with pth.open('rb') as incoming:
  p=subprocess.Popen([str(exe)],stdin=incoming,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=ROOT)
  try:
   with selectors.DefaultSelector() as selector:
    selector.register(p.stdout,selectors.EVENT_READ,'stdout');selector.register(p.stderr,selectors.EVENT_READ,'stderr')
    while selector.get_map():
     if time.monotonic()-start>30:raise ValueError('bounded command timeout')
     for key,_ in selector.select(0.1):
      data=os.read(key.fileobj.fileno(),65536)
      if not data:selector.unregister(key.fileobj);continue
      cap=protocol.MAX_RESPONSE if key.data=='stdout' else 2<<20
      checker.require(len(buffers[key.data])+len(data)<=cap,'bounded child output')
      buffers[key.data].extend(data)
   code=p.wait(timeout=max(.001,30-(time.monotonic()-start)))
  finally:
   if p.poll() is None:p.kill()
   p.wait();p.stdout.close();p.stderr.close()
 out,err=bytes(buffers['stdout']),bytes(buffers['stderr'])
 report['commands'].append({'label':label,'executable':str(exe),'exit':code,'input_sha256':sha(pth.read_bytes()),'output_sha256':sha(out),'stderr':err.decode('utf8'),'output_bytes':len(out)})
 pth.unlink()
 checker.require(code==expected,'expected exit: '+label)
 if expected==0:checker.require(not err,'quiet success')
 else:checker.require(not out and err.startswith(b'reference Greedy adapter:'),'negative diagnostic')
 return out
try:
 for mode,exe in executables.items():
  for name,packet in protocol.negative_packets():
   run(mode+'-negative-'+name,exe,packet,2);report['negative'].append(mode+'-'+name)
 historical={}
 for table,prefix in [('broader.tsv',''),('interop.tsv','historical-')]:
  for row in csv.DictReader(io.StringIO((policy.DESTINATION/table).read_text()),delimiter='\t'):
   historical[prefix+row['case']]=list(map(int,row['historical_resolved_tuple'].split(',')))
 frames={};counts={'success':0,'unsupported':0,'resource':0};decodes=0
 for index,case in enumerate(cases):
  results=[]
  for mode,exe in executables.items():
   wire=run(f'{index:03}-{mode}-encode',exe,protocol.packet(case.source,case.request))
   status,scalars,frame=protocol.response(wire,b'ZGOR0001')
   checker.require(status=={'success':0,'unsupported':1,'resource':2}[case.expected],'frozen result: '+case.name)
   checker.require(policy.classify(scalars)==case.expected,'independent scalar admission')
   if case.name in historical:checker.require(scalars==historical[case.name],'historical scalar tuple')
   if status==0:
    protocol.frame_info(frame,len(case.source))
    reply=run(f'{index:03}-{mode}-decode',exe,protocol.packet(case.source,case.request,frame,1))
    s,zeros,decoded=protocol.response(reply,b'ZGOR0001')
    checker.require(s==0 and zeros==[0]*7 and decoded==case.source,'exact decoded source');decodes+=1
   results.append((status,scalars,frame))
  checker.require(results[0]==results[1],'safe/all complete equality')
  status,scalars,frame=results[0];counts[case.expected]+=1
  if status==0:frames[case.name]=frame
  report['cases'].append({'name':case.name,'status':case.expected,'resolved':scalars,'frame_bytes':len(frame),'frame_sha256':sha(frame)})
  if (index+1)%25==0:save();print(index+1,'/',len(cases),flush=True)
 for group in manifest['expected_rust_frame_equivalence']:
  checker.require(all(frames[name]==frames[group[0]] for name in group),'frame equivalence: '+str(group))
 after={str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths}
 checker.require(before==after,'unchanged sources')
 report.update(status='passed',source_after=after,counts=counts,decodes=decodes,equivalence_groups=len(manifest['expected_rust_frame_equivalence']))
 save();print(json.dumps({k:report[k] for k in ('status','counts','decodes','equivalence_groups')},sort_keys=True),flush=True)
except BaseException as error:
 report.update(status='failed',error=repr(error));save();raise
