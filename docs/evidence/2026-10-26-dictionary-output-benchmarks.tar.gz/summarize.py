from pathlib import Path
import json,statistics,math,csv,hashlib
D=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[];index={};aggregates=[]
for campaign,folder,names in [('primary',D,[r['name'] for r in json.loads((D/'evidence.json').read_text())['builds']]),('repeat',D/'repeat',['safe','all'])]:
 t=json.loads((folder/'timed.json').read_text());assert t['status']=='passed'
 for name in names:
  groups={}
  for line in (folder/(name+'-timed.tsv')).read_text().splitlines():
   case,mode,sample,iterations,elapsed=line.split('\t');groups.setdefault((case,mode),[]).append(int(elapsed)/int(iterations))
  for (case,mode),samples in groups.items():
   assert len(samples)==5
   row=dict(campaign=campaign,backend=name,case=case,mode=mode,median_ns=statistics.median(samples),minimum_ns=min(samples),maximum_ns=max(samples));records.append(row);index[campaign,name,case,mode]=row['median_ns']
with (D/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
cases=[line.split('\t')[0] for line in (D/'safe-qualify.tsv').read_text().splitlines() if line.split('\t')[1]=='direct']
for campaign in ['primary','repeat']:
 for backend in (['safe','all'] if campaign=='repeat' else [r['name'] for r in json.loads((D/'evidence.json').read_text())['builds']]):
  direct_owned={case:index[campaign,backend,case,'direct']/index[campaign,backend,case,'owned'] for case in cases}
  direct_safe={case:index[campaign,backend,case,'direct']/index[campaign,'safe',case,'direct'] for case in cases}
  gm=lambda values:math.exp(sum(math.log(v) for v in values)/len(values))
  aggregates.append(dict(campaign=campaign,backend=backend,direct_over_owned=direct_owned,direct_over_safe=direct_safe,nonempty_geomean_direct_over_owned=gm([v for k,v in direct_owned.items() if k!='empty']),nonempty_geomean_direct_over_safe=gm([v for k,v in direct_safe.items() if k!='empty'])))
(D/'summary.json').write_text(json.dumps(dict(samples_per_row=5,unit='nanoseconds per decode',aggregation='Geometric mean of per-case median latency ratios, ten nonempty workloads equally weighted; empty case reported separately. Lower ratio means lower observed latency. No confidence interval or universal speedup claim.',rows=records,comparisons=aggregates),indent=2)+'\n')
for a in aggregates:
 if a['backend'] in ['safe','all','unsafe-slice-history']:print(a['campaign'],a['backend'],'direct/owned',round(a['nonempty_geomean_direct_over_owned'],4),'direct/safe',round(a['nonempty_geomean_direct_over_safe'],4))
