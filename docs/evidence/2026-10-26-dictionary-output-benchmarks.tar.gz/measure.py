from pathlib import Path
import argparse,hashlib,json,subprocess,time,datetime
R=Path('/private/tmp/module25-candidate');D=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def validate():
 b=json.loads((D/'evidence.json').read_text());assert b['status']=='qualified-not-timed' and len(b['builds'])==22
 for n,h in b['production_source'].items():assert sha(R/n)==h,('production',n)
 for n,h in b['source'].items():assert sha(D/'source'/n)==h,('snapshot',n)
 for row in b['builds']:
  assert sha(D/row['executable'])==row['sha256']
  assert sha(D/(row['name']+'-qualify.tsv'))==row['qualification_sha256']
  assert (D/(row['name']+'-qualify.tsv')).read_bytes()==(D/'safe-qualify.tsv').read_bytes()
 gates={}
 for label,path,count in [('matrix','module25-matrix/evidence.json',69),('public','module25-candidate/public.json',24),('platform','module25-platform/evidence.json',8),('native-rust','module25-native/rust.json',5),('fuzz-focused','module25-fuzz/focused.json',7),('fuzz-corpus','module25-fuzz/corpus.json',2)]:
  p=Path('/private/tmp')/path;j=json.loads(p.read_text());assert j['status']=='passed',label
  assert len(j['commands'])==count and all(c['exit_code']==0 for c in j['commands']),label
  for n,h in b['production_source'].items():assert j['source'][n]==h,(label,n)
  gates[label]=sha(p)
 p=Path('/private/tmp/module25-native/native.json');n=json.loads(p.read_text());assert n['status']=='passed' and len(n['results'])==476;gates['native']=sha(p)
 p=D/'harness-check.json';h=json.loads(p.read_text());assert h['status']=='passed' and all(c['exit_code']==0 for c in h['commands']);assert h['source_sha256']==sha(D/'source/benches/dictionary_output.rs');gates['harness']=sha(p)
 p=D/'cpu-barrier.json';assert p.exists();gates['cpu-barrier']=sha(p)
 return b,gates
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--validate-only',action='store_true');args=p.parse_args()
 b,gates=validate()
 if args.validate_only:print('all source, executable, qualification and completed check gates passed');raise SystemExit(0)
 assert not (D/'timed.json').exists(),'fresh timing output'
 e=dict(status='running',gates=gates,build_evidence_sha256=sha(D/'evidence.json'),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),runs=[],qualification='Sequential fixed-order timing after task-owned builds/checks completed; this does not assert desktop idleness. Five samples per mode/case; direct caller allocation and persistent dictionary preparation excluded; cold codec scratch, owned result allocation/destruction and its shared handle clone included. Global allocator timed; tracking ledger excluded.')
 def save():(D/'timed.json').write_text(json.dumps(e,indent=2)+'\n')
 save()
 try:
  for row in b['builds']:
   name=row['name'];t=time.monotonic();p=subprocess.run([str(D/row['executable']),'measure'],capture_output=True)
   (D/(name+'-timed.tsv')).write_bytes(p.stdout);(D/(name+'-timed.stderr')).write_bytes(p.stderr)
   assert p.returncode==0,(name,p.stderr)
   lines=p.stdout.decode().splitlines();assert len(lines)==110
   seen=set()
   for line in lines:
    case,mode,sample,iterations,elapsed=line.split('\t');sample=int(sample);iterations=int(iterations);elapsed=int(elapsed)
    assert mode in ['direct','owned'] and 0<=sample<5 and 8<=iterations<=4096 and elapsed>0
    key=(case,mode,sample);assert key not in seen;seen.add(key)
   expected={(line.split('\t')[0],line.split('\t')[1],sample) for line in (D/'safe-qualify.tsv').read_text().splitlines() for sample in range(5)}
   assert seen==expected
   e['runs'].append(dict(name=name,rows=len(lines),seconds=time.monotonic()-t,sha256=sha(D/(name+'-timed.tsv')),executable_sha256=row['sha256']));save();print(name,'110 samples',flush=True)
  validate();e['status']='passed';save()
 except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
