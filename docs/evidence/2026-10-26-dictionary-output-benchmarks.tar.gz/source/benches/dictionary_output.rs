//! Cold decode calls with a persistent prepared dictionary; setup stays outside clocks.
//! Direct destination allocation and dictionary preparation are excluded. Owned
//! result allocation/drop, dictionary handle cloning and codec scratch are timed.
//! Tracking allocators qualify scratch separately from Global timing.
use std::{hint::black_box, time::Instant};
use zstdoxide::{
    DecodeOptions, Dictionary, SharedDictionary, decompress_into_with_dictionary,
    decompress_into_with_dictionary_in, decompress_with_dictionary, decompress_with_dictionary_in,
};
use zstdoxide_test_allocator::{AllocatorConfig, TrackingAllocator};
struct Case {
    name: &'static str,
    frame: &'static [u8],
    source: &'static [u8],
    dictionary: SharedDictionary,
}
fn fingerprint(bytes: &[u8]) -> u64 {
    bytes.iter().fold(0xcbf29ce484222325, |h, b| {
        (h ^ u64::from(*b)).wrapping_mul(0x100000001b3)
    })
}
fn cases() -> Vec<Case> {
    let mut cases = Vec::new();
    macro_rules! fixture {
        ($name:literal,$dictionary:literal) => {
            cases.push(Case {
                name: $name,
                frame: include_bytes!(concat!("../tests/upstream/dictionaries/", $name, ".zst")),
                source: include_bytes!(concat!(
                    "../tests/upstream/dictionaries/",
                    $name,
                    ".expected"
                )),
                dictionary: Dictionary::from_bytes(include_bytes!(concat!(
                    "../tests/upstream/dictionaries/",
                    $dictionary
                )))
                .unwrap()
                .into_shared(),
            });
        };
    }
    fixture!("raw-small-window", "boundary-dictionary.raw");
    fixture!("p0-far-dictionary", "boundary-dictionary.raw");
    fixture!("p-window-equal", "boundary-dictionary.raw");
    fixture!("dictionary-to-frame-eviction", "boundary-dictionary.raw");
    fixture!("formatted-id", "formatted.dict");
    fixture!("dictionary-treeless-four-streams", "formatted.dict");
    fixture!("dictionary-repeat-sequences", "trained.dict");
    fixture!("duplicate-reps-initial", "duplicate-reps.dict");
    fixture!("persistent-concatenation", "formatted.dict");
    cases.push(Case {
        name: "http",
        frame: include_bytes!("../tests/upstream/data/generated/http-dictionary.zst"),
        source: include_bytes!("../tests/upstream/data/golden-compression/http"),
        dictionary: Dictionary::from_bytes(include_bytes!(
            "../tests/upstream/data/golden-dictionaries/http-dict-missing-symbols"
        ))
        .unwrap()
        .into_shared(),
    });
    cases.push(Case {
        name: "empty",
        frame: &[0x28, 0xb5, 0x2f, 0xfd, 0x20, 0, 1, 0, 0],
        source: &[],
        dictionary: Dictionary::from_bytes(include_bytes!(
            "../tests/upstream/dictionaries/formatted.dict"
        ))
        .unwrap()
        .into_shared(),
    });
    cases
}
fn main() {
    let command = std::env::args().nth(1).expect("qualify or measure");
    assert!(command == "qualify" || command == "measure");
    for Case {
        name,
        frame,
        source,
        dictionary,
    } in cases()
    {
        let options = DecodeOptions::new(source.len());
        let mut output = vec![0xa5; source.len() + 16];
        assert_eq!(
            decompress_into_with_dictionary(frame, &mut output, &dictionary, options).unwrap(),
            source.len()
        );
        assert_eq!(&output[..source.len()], source);
        assert_eq!(&output[source.len()..], &[0xa5; 16]);
        assert_eq!(
            decompress_with_dictionary(frame, &dictionary, options).unwrap(),
            source
        );
        for mode in ["direct", "owned"] {
            if command == "qualify" {
                let allocator = TrackingAllocator::new(AllocatorConfig::default()).unwrap();
                let monitor = allocator.monitor();
                if mode == "direct" {
                    assert_eq!(
                        decompress_into_with_dictionary_in(
                            frame,
                            &mut output,
                            &dictionary,
                            options,
                            allocator
                        )
                        .unwrap(),
                        source.len()
                    );
                    assert_eq!(&output[..source.len()], source);
                } else {
                    let decoded =
                        decompress_with_dictionary_in(frame, &dictionary, options, allocator)
                            .unwrap();
                    assert_eq!(&decoded[..], source);
                    drop(decoded);
                }
                monitor.assert_released();
                let s = monitor.snapshot();
                assert_eq!(s.identities_created, s.owners_dropped);
                assert_eq!(SharedDictionary::strong_count(&dictionary), 1);
                println!(
                    "{name}\t{mode}\t{}\t{:016x}\t{}\t{}\t{}\t{}",
                    source.len(),
                    fingerprint(source),
                    s.attempts,
                    s.requested_bytes,
                    s.peak_bytes,
                    s.deallocate_calls
                );
            } else {
                let iterations = (1024 * 1024 / source.len().max(1)).clamp(8, 4096);
                for sample in 0..5 {
                    let start = Instant::now();
                    for _ in 0..iterations {
                        if mode == "direct" {
                            black_box(
                                decompress_into_with_dictionary(
                                    black_box(frame),
                                    black_box(&mut output),
                                    black_box(&dictionary),
                                    black_box(options),
                                )
                                .unwrap(),
                            );
                        } else {
                            black_box(
                                decompress_with_dictionary(
                                    black_box(frame),
                                    black_box(&dictionary),
                                    black_box(options),
                                )
                                .unwrap(),
                            );
                        }
                    }
                    let elapsed = start.elapsed().as_nanos();
                    assert_eq!(&output[..source.len()], source);
                    assert_eq!(&output[source.len()..], &[0xa5; 16]);
                    assert_eq!(SharedDictionary::strong_count(&dictionary), 1);
                    println!("{name}\t{mode}\t{sample}\t{iterations}\t{elapsed}");
                }
            }
        }
    }
}
