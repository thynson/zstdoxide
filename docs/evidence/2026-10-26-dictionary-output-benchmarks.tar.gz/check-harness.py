from pathlib import Path
import subprocess,json,hashlib,os
D=Path(__file__).parent;S=D/'source';e=dict(status='running',source_sha256=hashlib.sha256((S/'benches/dictionary_output.rs').read_bytes()).hexdigest(),commands=[])
env={**os.environ,'CARGO_TARGET_DIR':str(D/'target'),'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0'}
for name,args in [('clippy',['cargo','clippy','--offline','--locked','--bench','dictionary_output','--all-features','--','-D','warnings']),('format',['rustfmt','--edition','2024','--check','benches/dictionary_output.rs'])]:
 with (D/('harness-verified-'+name+'.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
 e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode))
 if p.returncode:e['status']='failed';break
else:e['status']='passed'
(D/'harness-check.json').write_text(json.dumps(e,indent=2)+'\n');print(e['status'])
assert e['status']=='passed'
