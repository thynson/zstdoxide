from pathlib import Path
import copy,hashlib,json,os,subprocess,sys
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(ROOT/'scripts'));children=[]
def forbidden(*a,**k):children.append('blocked');raise RuntimeError('child execution forbidden')
subprocess.Popen=forbidden
for name in ['system','fork','forkpty','posix_spawn','posix_spawnp','spawnl','spawnle','spawnlp','spawnlpe','spawnv','spawnve','spawnvp','spawnvpe','execl','execle','execlp','execlpe','execv','execve','execvp','execvpe']:
 if hasattr(os,name):setattr(os,name,forbidden)
import check_lazy_frames as m
import check_lazy_frame_capture as audit
loaded=audit.inputs();audit.inputs=lambda:loaded
manifest,artifacts=m.check();read=audit.read;root=m.COLLECTION.resolve();rejected=[]
def reject(name,changes):
 audit.read=lambda r,n,cap=64<<20:changes[n] if r==root and n in changes else read(r,n,cap)
 try:m.check()
 except (ValueError,KeyError,TypeError):rejected.append(name)
 else:raise ValueError('changed immutable fixture accepted: '+name)
 finally:audit.read=read
for key,value in [('schema_version',True),('upstream_revision','0'*40),('checker_sha256','0'*64),('controller_sha256','0'*64),('pack_bytes',True),('pack_sha256','0'*64)]:
 forged=copy.deepcopy(manifest);forged[key]=value;reject(key,{'capture.json':json.dumps(forged).encode()})
for label,change in [('offset',lambda x:next(iter(x['artifacts'].values())).__setitem__('offset',1)),
                     ('duplicate_case',lambda x:x['cases'].append(x['cases'][0])),
                     ('coverage',lambda x:x['coverage'].__setitem__('recipes',509)),
                     ('missing_artifact',lambda x:x['artifacts'].pop(next(iter(x['artifacts']))))]:
 forged=copy.deepcopy(manifest);change(forged);reject(label,{'capture.json':json.dumps(forged).encode()})
pack=read(root,'artifacts.bin',256<<20)
reject('truncated_pack',{'artifacts.bin':pack[:-1]})
reject('trailing_pack',{'artifacts.bin':pack+b'x'})
for name in ['d1_chain_first_uniform.stdout','d2_row_first_uniform.zst']:
 item=manifest['artifacts'][name];forged=bytearray(pack);forged[item['offset']]^=1
 reject('changed_'+name,{'artifacts.bin':forged})
need=lambda ok:None if ok else (_ for _ in ()).throw(ValueError('control count'))
need(len(rejected)==14 and not children)
print(json.dumps({'status':'passed','optimization':sys.flags.optimize,'positive':1,'rejections':rejected,'child_attempts':len(children),'pack_sha256':manifest['pack_sha256'],'checker_sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()},sort_keys=True))
