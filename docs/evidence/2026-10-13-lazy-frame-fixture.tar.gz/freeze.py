from pathlib import Path
import hashlib,json
ROOT=Path('/Users/lanxingcan/Workspace/zstdoxize')
source=Path('/private/tmp/zstdoxide-lazy-frame-audited')
report=json.loads((ROOT/'docs/evidence/2026-10-13-lazy-frames.json').read_text())
audit=json.loads((source/'audit.json').read_text());pack=(source/'artifacts.bin').read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
if len(pack)!=audit['pack_bytes'] or sha(pack)!=audit['pack_sha256'] or audit['coverage']!=report['coverage']:raise ValueError('audited export binding')
raw=Path('/private/tmp/zstdoxide-lazy-frames-2026-10-13/evidence.json').read_bytes()
if sha(raw)!=audit['capture_evidence_sha256'] or report['capture_evidence_sha256']!=sha(raw):raise ValueError('capture evidence binding')
collection=ROOT/'tests/fixtures/reference-lazy-frame-capture'
if collection.exists():raise ValueError('fresh collection required')
manifest={'schema_version':1,'upstream_revision':'f8745da6ff1ad1e7bab384bd1f9d742439278e99',**audit,
          'capture_archive':report['capture_archive'],'controls_archive':report['controls_archive'],
          'policy':'Frozen ordinary explicit-parameter C observations. All 26 units and helper instrumented, exact cross-build and depth-zero predecessor checks. No public Rust request resolution, collector, intermediate probe trace, LeakSanitizer or timing claim.'}
encoded=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
collection.mkdir();(collection/'artifacts.bin').write_bytes(pack);(collection/'capture.json').write_bytes(encoded)
(collection/'README.md').write_text('''# Frozen ordinary lazy-family observations

The 510 source-only recipes were captured from unchanged facebook/zstd v1.5.7
with the reviewed version-one helper and controller. All 26 used codec units and
the helper were compiled separately in normal and ASan/UBSan builds. Every
observation and complete frame agrees across builds. All 138 ordinary depth-zero
predecessors retain exact records (apart from the documented name prefix) and
complete frame bytes.

`capture.json` indexes consecutive SHA256-bound extents in `artifacts.bin`:
510 NDJSON trajectories, 510 scheduled frames, 39 aligned whole frames, one
metadata record and 45 qualified incomplete-header observations. The pack is
103,211,609 bytes. Run `python3 scripts/check_lazy_frames.py --check` to replay
all maps, sequences, publications and frames independently without executing C.

Actual coverage: 1,377 positive blocks (633 raw, 114 RLE, 630 compressed), 1,293
fresh candidates and 201 changed-repeat fallback witnesses (165 raw, 36 RLE).
Each build decoded 549 complete frames / 41,165,274 source bytes and rejected
51 malformed commands. Header-only observations are incomplete and undecoded.
The manifest identifies the complete raw capture archive and offline controls.
Concatenate its three archive parts in listed order to recover the gzip stream;
the full SHA256 and all part identities are retained and checked on publication.

This is internal explicit-parameter evidence. It does not establish public
parameter resolution, per-probe tracing, collector equivalence, performance or
complete Zstandard replacement support. Source hypotheses are retained even
when their named outcome was not observed.
''')
(collection/'NOTICE').write_text('''Fixtures are derived from facebook/zstd v1.5.7, revision
f8745da6ff1ad1e7bab384bd1f9d742439278e99.
Copyright (c) Meta Platforms, Inc. and affiliates.
Upstream source is licensed under the BSD license or GPLv2. See LICENSE-BSD
in the pinned external source. Deterministic recipe sources are project inputs;
archived outputs are observations of the unmodified official codec.
''')
p=ROOT/'scripts/check_lazy_frames.py';s=p.read_text()
if 'MANIFEST_PLACEHOLDER' not in s:raise ValueError('already frozen')
p.write_text(s.replace('MANIFEST_PLACEHOLDER',sha(encoded)))
print(json.dumps({'bytes':len(pack),'pack_sha256':sha(pack),'manifest_sha256':sha(encoded),'artifacts':len(audit['artifacts'])},sort_keys=True))
