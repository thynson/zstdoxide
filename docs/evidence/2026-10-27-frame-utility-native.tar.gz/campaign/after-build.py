from pathlib import Path
import json,subprocess,time
D=Path(__file__).parent
while True:
 j=json.loads((D/'build.json').read_text())
 if j['status']=='passed':break
 assert j['status']=='running',j['status'];time.sleep(5)
subprocess.run(['python3',str(D/'run.py')],check=True)
subprocess.run(['python3','/private/tmp/module31-native-history/capture.py'],check=True)
