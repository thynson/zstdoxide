from pathlib import Path
import shutil,subprocess
D=Path(__file__).parent;S=D/'replay-source';shutil.copytree('/private/tmp/module31-candidate',S)
shutil.copyfile(D/'frame_utilities_native.rs',S/'tests/frame_utilities_native.rs');shutil.copyfile('/private/tmp/module31-native-history/frame_utilities_history.rs',S/'tests/frame_utilities_history.rs');subprocess.run(['cargo','fmt','--all'],cwd=S,check=True)
