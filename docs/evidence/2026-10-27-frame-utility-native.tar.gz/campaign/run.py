from pathlib import Path
import subprocess,json,hashlib,os,time
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();build=json.loads((D/'build.json').read_text());assert build['status']=='passed'
e=dict(status='running',build_receipt_sha256=sha(D/'build.json'),helper_sha256=sha(D/'frame_utilities_oracle.c'),cases_sha256=sha(D/'cases.tsv'),sizes_sha256=sha(D/'sizes.txt'),commands=[])
def save():(D/'native.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for backend in ['normal','sanitized']:
  assert sha(D/('oracle-'+backend))==build['executables'][backend];out=D/(backend+'-outputs');out.mkdir()
  for mode,file in [('bounds','sizes.txt'),('write','cases.tsv')]:
   args=[str(D/('oracle-'+backend)),mode,str(D/file),str(out)];t=time.monotonic()
   with (D/(backend+'-'+mode+'.tsv')).open('xb') as f,(D/(backend+'-'+mode+'.stderr')).open('xb') as err:p=subprocess.run(args,stdout=f,stderr=err,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'})
   e['commands'].append(dict(label=backend+'-'+mode,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,stdout_sha256=sha(D/(backend+'-'+mode+'.tsv')),stderr_sha256=sha(D/(backend+'-'+mode+'.stderr'))));save();assert p.returncode==0
  print(backend,'real layouts and original scalar assertions passed',flush=True)
 for mode in ['bounds','write']:assert (D/('normal-'+mode+'.tsv')).read_bytes()==(D/('sanitized-'+mode+'.tsv')).read_bytes()
 inventory={p.name:sha(p) for p in (D/'normal-outputs').iterdir()};assert len(inventory)==343
 assert inventory=={p.name:sha(p) for p in (D/'sanitized-outputs').iterdir()}
 e.update(status='passed',outputs=inventory,scalar_cases=280,writer_layouts=343,qualification='External pinned v1.5.7 normal/sanitized helpers execute exact original scalar compressBound assertions plus supplemental boundary sizes and real guarded writer layouts. Every native destination is genuinely allocated to the supplied capacity. No gigantic fabricated buffers or out-of-range pointers are used. Writer cases preserve independent source, outer guards, rejected outputs and success suffix. Original preceding fuzzer writer history remains a separate qualification. This macOS ASan runtime does not support leak detection; it remains disabled, with bounds and undefined-behavior checks active. Helper allocations are explicitly freed; no dynamic leak-check pass is claimed.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
