/* External-only oracle for pinned facebook/zstd v1.5.7 utilities. */
#define ZSTD_STATIC_LINKING_ONLY
#include "zstd.h"
#include "zstd_errors.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
static void original_bound(void) {
    unsigned shift;
    /* Exact scalar assertions from tests/fuzzer.c:test_compressBound. */
    for (shift=0;shift<30;shift++) {
        size_t n=(size_t)1<<shift;
        if (ZSTD_compressBound(n)!=ZSTD_COMPRESSBOUND(n)) exit(10);
    }
    { size_t n=ZSTD_MAX_INPUT_SIZE+1;
      if (!ZSTD_isError(ZSTD_compressBound(n)) || ZSTD_COMPRESSBOUND(n)!=0) exit(11); }
}
int main(int argc,char **argv) {
    FILE *list; char name[128]; int fields;
    if (argc!=4 || ZSTD_versionNumber()!=10507)return 2;
    original_bound();list=fopen(argv[2],"r");if(!list)return 3;
    if(!strcmp(argv[1],"bounds")) {
        unsigned long long raw;
        while((fields=fscanf(list,"%llu",&raw))==1) {
            size_t n,result;if(raw>SIZE_MAX)return 4;n=(size_t)raw;result=ZSTD_compressBound(n);
            printf("%llu\t%s\t%zu\t%zu\t%zu\n",raw,ZSTD_isError(result)?"error":"ok",ZSTD_isError(result)?0:result,(size_t)ZSTD_COMPRESSBOUND(n),result);
        }
    } else if(!strcmp(argv[1],"write")) {
        size_t length,capacity,i,result;unsigned variant,seed;
        while((fields=fscanf(list,"%127s %zu %zu %u %u",name,&length,&capacity,&variant,&seed))==5) {
            unsigned char *source=malloc(length?length:1),*storage=malloc(capacity+32);char path[4096];FILE *out;
            if(!source || !storage)return 5;
            for(i=0;i<length;i++)source[i]=(unsigned char)((seed+i)%256);
            memset(storage,0xa5,capacity+32);result=ZSTD_writeSkippableFrame(storage+16,capacity,source,length,variant);
            for(i=0;i<16;i++)if(storage[i]!=0xa5 || storage[16+capacity+i]!=0xa5)return 6;
            for(i=0;i<length;i++)if(source[i]!=(unsigned char)((seed+i)%256))return 7;
            if(ZSTD_isError(result)) { for(i=0;i<capacity;i++)if(storage[16+i]!=0xa5)return 8; }
            else {
                if(result!=length+8 || result>capacity || memcmp(storage+24,source,length))return 9;
                for(i=result;i<capacity;i++)if(storage[16+i]!=0xa5)return 12;
            }
            snprintf(path,sizeof(path),"%s/%s.bin",argv[3],name);out=fopen(path,"wb");
            if(!out || fwrite(storage,1,capacity+32,out)!=capacity+32 || fclose(out))return 13;
            printf("%s\t%s\t%zu\t%u\n",name,ZSTD_isError(result)?"error":"ok",ZSTD_isError(result)?0:result,(unsigned)ZSTD_getErrorCode(result));
            free(source);free(storage);
        }
    } else return 14;
    if(fields!=EOF || ferror(list) || fclose(list))return 15;
    return 0;
}
