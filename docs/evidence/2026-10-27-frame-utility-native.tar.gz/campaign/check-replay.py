from pathlib import Path
import subprocess,os,json,hashlib,time,re
D=Path(__file__).parent;S=D/'replay-final';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native=json.loads((D/'native.json').read_text());assert native['status']=='passed';source={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()}
for p in (Path('/private/tmp/module31-candidate')/'src').glob('*.rs'):assert sha(S/'src'/p.name)==sha(p)
e=dict(status='running',source=source,native_receipt_sha256=sha(D/'native.json'),commands=[]);env={**os.environ,'CARGO_BUILD_JOBS':'2','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_TARGET_DIR':str(D/'replay-target'),'ZSTDOXIDE_FRAME_UTILITY_CASES':str(D)}
def save():(D/'replay.json').write_text(json.dumps(e,indent=2)+'\n')
save()
try:
 for name,flags in [('safe',[]),('cursor',['--features','unsafe-byte-cursor']),('all',['--all-features'])]:
  args=['cargo','test','--offline','--locked','--test','frame_utilities_native',*flags,'--','--ignored'];t=time.monotonic()
  with (D/(name+'-replay.log')).open('xb') as f:p=subprocess.run(args,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  e['commands'].append(dict(label=name,argv=args,exit_code=p.returncode,seconds=time.monotonic()-t,log_sha256=sha(D/(name+'-replay.log'))));save();assert p.returncode==0 and '2 passed; 0 failed; 0 ignored' in (D/(name+'-replay.log')).read_text();print(name,'passed',flush=True)
 for n,h in source.items():assert sha(S/n)==h,n
 e.update(status='passed',qualification='Three Rust backends replay all 280 native scalar rows and 343 real writer layouts, comparing every output/guard byte with native. Native scalar formula/function raw values agree with Rust bounds. One maximal-admitted numeric bound overlaps the C error-code range; Rust returns its typed numeric value and the explicit sentinel difference is retained. Both writers reject the same supplied layouts, but Rust variant-first versus native capacity-first error identity is deliberately not equated. Numeric impossible-slice lengths are separately checked in Rust scalar helper unit/Miri tests.');save()
except BaseException as ex:e.update(status='failed',error=repr(ex));save();raise
