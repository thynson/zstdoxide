import datetime,hashlib,json,os,shutil,subprocess,time,tomllib
from pathlib import Path
root=Path('/Users/lanxingcan/Workspace/zstdoxize');out=Path('/private/tmp/ultra-fresh-platform-checks');out.mkdir();(out/'logs').mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
source={str(p.relative_to(root)):sha(p) for directory in ['src','tests/support','test-support'] for p in (root/directory).rglob('*.rs')}
source.update({n:sha(root/n) for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','tests/fixtures/reference-ultra-fresh/cases.bin']})
features=[f for f in tomllib.loads((root/'Cargo.toml').read_text())['features'] if f.startswith('unsafe-')]
env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR','RUSTUP_HOME','CARGO_HOME','DEVELOPER_DIR','SDKROOT'] if k in os.environ}
env.update(LANG='C',LC_ALL='C',TZ='UTC',CARGO_BUILD_JOBS='2')
e=dict(status='running',started_at=now(),source=source,commands=[])
def save():(out/'evidence.json').write_text(json.dumps(e,sort_keys=True,indent=2)+'\n')
def run(label,args,cwd,extra,timeout=1200):
 current=dict(env,**extra);start=time.monotonic();path=out/'logs'/(label+'.log')
 with path.open('xb') as log:done=subprocess.run(args,cwd=cwd,env=current,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 e['commands'].append(dict(label=label,argv=args,cwd=str(cwd),environment=current,exit_code=done.returncode,seconds=time.monotonic()-start,log=dict(path=str(path.relative_to(out)),bytes=path.stat().st_size,sha256=sha(path))))
 save();print(label,done.returncode,flush=True)
 if done.returncode:raise ValueError(label)
save()
try:
 for target,sysroot in [('i686-unknown-linux-gnu','/private/tmp/zstdoxide-ultra-miri-i686'),('s390x-unknown-linux-gnu','/private/tmp/zstdoxide-ultra-miri-s390x')]:
  for mode,flags in [('safe',[]),('all',['--all-features'])]:
   for test in ['ordinary_ultra_admission_preserves_scripted_and_planning_gates','fresh_borrowed_owners_never_allocate_during_parse_or_reset']:
    full='optimal_parse::ultra_fresh_tests::'+test
    run(target+'-'+mode+'-'+test,['cargo','miri','test','--target',target,*flags,'--lib',full,'--','--exact'],root,
        dict(CARGO_TARGET_DIR='/private/tmp/zstdoxide-ultra-miri-target',MIRI_SYSROOT=sysroot,MIRIFLAGS='-Zmiri-strict-provenance'))
 probe=out/'probe';probe.mkdir()
 for n in ['src','test-support','benches']:shutil.copytree(root/n,probe/n)
 for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']:shutil.copyfile(root/n,probe/n)
 with (probe/'src/lib.rs').open('a') as stream:stream.write('''
// Concrete ordinary Ultra construction, parsing, reset and drop for code generation.
#[inline(never)]
pub fn ordinary_ultra_codegen_probe(source: &[u8]) -> Result<usize> {
    use alloc::alloc::Global;
    use optimal_parse::{OptimalParser, PathEvent, PathObserver};
    struct Observer(usize);
    impl PathObserver for Observer {
        fn event<P: core::alloc::Allocator, F: core::alloc::Allocator>(&mut self, event: PathEvent,
            _: &optimal_paths::OptimalPaths<P>, _: &optimal_frequencies::OptimalFrequencies<F>,
            _: &[optimal_search_layout::OptimalMatch]) -> Result<()> {
            self.0 += usize::from(event.appended.is_some()); Ok(())
        }
    }
    let layout=optimal_search_layout::OptimalSearchLayout::new(14,12,12,6,3,4095,Some(14))?;
    let mut parser=OptimalParser::from_ultra_fresh_parts(source,3,4095,
        optimal_frequencies::OptimalFrequencies::new_with_policy_in(optimal_price::PricePolicy::Ultra,false,Global)?,
        optimal_paths::OptimalPaths::new_in(Global)?, optimal_matches::OptimalMatches::new_in(Global)?)?;
    let mut search=optimal_search::OptimalSearch::from_parts(source,layout,
        reference_tree::ReferenceTree::new_in(layout.tree(),Global,Global)?,
        optimal_short_key::OptimalShortKey::new_in(layout.short_log(),Global)?,
        optimal_matches::OptimalMatches::new_in(Global)?)?;
    let mut observer=Observer(0);
    let result=parser.parse_ultra_fresh(&mut search,&mut observer)?;
    parser.reset()?; search.reset();
    Ok(core::hint::black_box(result.sequences + observer.0))
}
''')
 for mode,flags in [('safe',[]),('all',['--features',','.join(features)])]:
  common=['-Zbuild-std=core,alloc','--target','thumbv6m-none-eabi','--no-default-features',*flags,'--lib']
  run('thumb-'+mode+'-check',['cargo','check',*common],root,dict(CARGO_TARGET_DIR='/private/tmp/zstdoxide-ultra-thumb-target'))
  run('thumb-'+mode+'-concrete',['cargo','rustc','--release',*common,'--','--emit=llvm-ir,obj'],probe,dict(CARGO_TARGET_DIR=str(out/('target-'+mode))))
  ir=[p for p in (out/('target-'+mode)).rglob('*.ll') if any(line.startswith(b'define ') and b'ordinary_ultra_codegen_probe' in line for line in p.read_bytes().splitlines())]
  if len(ir)!=1:raise ValueError('exact concrete probe definition')
  e.setdefault('concrete_ir',{})[mode]=dict(path=str(ir[0].relative_to(out)),sha256=sha(ir[0]))
  objects=list(ir[0].parent.glob('*.o'))
  if not objects:raise ValueError('concrete ARM objects')
  for obj in objects:
   h=obj.read_bytes()[:20]
   if h[:6]!=b'\x7fELF\x01\x01' or int.from_bytes(h[18:20],'little')!=40:raise ValueError('ARM ELF object identity')
  e.setdefault('concrete_objects',{})[mode]=[dict(path=str(obj.relative_to(out)),sha256=sha(obj)) for obj in sorted(objects)]
 if {n:sha(root/n) for n in source}!=source:raise ValueError('source changed')
 e.update(status='passed',completed_at=now(),source_unchanged=True);save()
except BaseException as error:e.update(status='failed',error=repr(error),completed_at=now());save();raise
