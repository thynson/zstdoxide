import json,pathlib,sys,tempfile
ROOT=pathlib.Path('/Users/lanxingcan/Workspace/zstdoxize');sys.path.insert(0,str(ROOT/'scripts'))
import check_lazy_interop_recipes as checker
attempts=[]
def no_child(event,args):
 if event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec','os.spawn'):
  attempts.append(event);raise RuntimeError('children prohibited')
sys.addaudithook(no_child)
value=checker.check()
from oracles import lazy_interop as m
from oracles import greedy_interop as prior
old=prior.recipes();new=m.recipes()
for a,b in zip(old,new[:422],strict=True):
 m.require((a.name,a.source,a.request)==(b.name,b.source,b.request),'predecessor exact inputs')
controls=[]
def reject(label,fn):
 try:fn()
 except (ValueError,FileNotFoundError,TypeError,StopIteration):controls.append(label)
 else:raise ValueError('accepted '+label)
base=(6,21,18,19,8,4,0,4,0)
for size in [-1,True,1.0,None,m.MAX_SOURCE+1]:reject('size-'+repr(size),lambda:m.selected_status(size,base))
for v in [[],list(base),base[:-1],base+(0,),None]:reject('request-'+repr(v),lambda:m.selected_status(32,v))
for i in range(9):
 for v in [True,1.0,'1']:
  r=list(base);r[i]=v;r=tuple(r);reject(f'type-{i}-{v!r}',lambda:m.selected_status(32,r))
for i,v in [(0,0),(0,23),(1,9),(1,32),(2,5),(2,31),(3,5),(3,31),(4,31),(5,2),(5,8),(6,131073),(7,10),(8,1<<31)]:
 r=list(base);r[i]=v;r=tuple(r);reject(f'bound-{i}-{v}',lambda:m.selected_status(32,r))
with tempfile.TemporaryDirectory(prefix='lazy-public-recipe-controls-') as d:
 p=pathlib.Path(d)/'recipes.json';data=checker.MANIFEST.read_bytes();p.write_bytes(data);checker.check(p)
 for label,b in [('changed',data+b'\n'),('truncated',data[:-1]),('duplicate',b'{"x":0,"x":0}'),('nonfinite',b'{"x":NaN}')]:
  p.write_bytes(b);reject(label,lambda:checker.check(p))
 p.unlink();p.symlink_to(checker.MANIFEST);reject('linked-manifest',lambda:checker.check(p))
 m.require(not attempts,'no child attempts')
print(json.dumps(dict(optimized=not __debug__,recipes=len(new),predecessor_inputs=len(old),controls=controls,child_attempts=len(attempts),classifications=value['classifications'],equivalences=len(value['expected_rust_frame_equivalence'])),sort_keys=True,indent=2))
